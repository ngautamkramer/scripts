const fs = require('fs');
const path = require('path');

// Log file path
const logFilePath = path.join(__dirname, 'log.txt');

// Function to write log messages to the log file
function log(message, level = 'INFO') {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] [${level}] ${message}\n`;

  // Append log message to file
  fs.appendFile(logFilePath, logMessage, (err) => {
    if (err) {
      console.error('Error writing to log file:', err);
    }
  });
}

// Export the log function
module.exports = { log };