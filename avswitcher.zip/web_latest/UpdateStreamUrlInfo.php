<?php 
// error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
// ini_set('display_errors', true);
class UpdateStreamUrlInfo {
	private $fileName = "input-data.json";
	private $duplicateFileName = "d-input-data.json";
	private $jsonData = "";
	private $postData = "";
	private $sampleJson = "";
	public function __construct($postData) {
		$this->postData = $postData;
		$this->getSampleJson();
		$this->readFileData();
	}

	public function getSampleJson() {
		$sampleArray = array();
		$sampleArray["inputs"] = array();
		$sampleArray["inputs"]["command"] = "AVoIP-TO-HDMI-1";
		$sampleArray["inputs"]["url"] = "";
		$sampleArray["inputs"]["previewstatus"] = 0;
		$sampleArray["inputs"]["inputaction"] = "stop";
		$sampleArray["inputs"]["stream_information"] = array();
		$sampleArray["inputs"]["stream_information"]["resolution"] = "";
		$sampleArray["inputs"]["stream_information"]["aspectRatio"] = "";
		$sampleArray["inputs"]["stream_information"]["frame_rate"] = "";
		$sampleArray["inputs"]["stream_information"]["audio_channel"] = "";
		$sampleArray["inputs"]["stream_information"]["audio_rate"] = "";
		$this->sampleJson = json_encode($sampleArray);
	}

	public function readFileData() {
		$this->jsonData = file_get_contents($this->fileName);
		$this->jsonData = json_decode($this->jsonData, true);
	}

	public function updateJson() {
		foreach($this->postData as $key => $value) {
			if(is_array($value)) {
				foreach($value as $vKey => $vValue) {
					if(is_array($this->jsonData["inputs"][$key])) {
						if(array_key_exists($vKey, $this->jsonData["inputs"][$key])) {
							$this->jsonData["inputs"][$key][$vKey] = trim($vValue);	
						}	
					}
				}
			} else {
				if(is_array($this->jsonData["inputs"])) {
					if (array_key_exists($key, $this->jsonData["inputs"])) {
						$this->jsonData["inputs"][$key] = trim($value);	
					}	
				}
			}
		}
		$this->writeJson();
	}

	Public function writeJson(){

		$jsonStr = json_encode($this->jsonData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
		if($jsonStr === false){
		    die("JSON encoding error");
		}
		file_put_contents($this->fileName, trim($jsonStr), LOCK_EX);

		//check if json is blank then this will copy from the duplicate json
		$currentJson = file_get_contents($this->fileName);
		$currentJsonArray = json_decode($currentJson, true);
		if($currentJsonArray === null){
			if(filesize($this->duplicateFileName) > 0){
				copy($this->duplicateFileName, $this->fileName);
			}
			die("Invalid JSON");
		}else{
			$this->writeJsonDuplicate();
		}
		//end check if json is blank

		echo strlen($jsonStr);
	}

	public function writeJsonDuplicate(){
		//file_put_contents($this->duplicateFileName, json_encode($this->jsonData, JSON_UNESCAPED_SLASHES));
		if(filesize($this->fileName) > 0){
			copy($this->fileName, $this->duplicateFileName);
		}
	}

}
usleep(500000);//for half second delay
$jsonData = file_get_contents('php://input');
$requestData = json_decode($jsonData, true);
$obj = new UpdateStreamUrlInfo($requestData);
$obj->updateJson();
?>