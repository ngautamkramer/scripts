<?php 

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
ini_set('display_errors', false);

class DeviceSettings{

	//private $fileName = "../../Collab8/config/AVSwitcher-dir/data/Settings.json";
    private $fileName = "Settings.json";
    private $requestedData = "";

    public function __construct($requestedData) {
        $this->requestedData = $requestedData;
    }


    /*****
     *  @Function Name      : sendResponse
     *  @description        : This function send response to the client
     *  @Author             : Niraj
     *  @Date               : 22 April, 2025
    *****/
    function sendResponse($responseArray, $status = 200){
        //http_response_code($status);
        echo json_encode($responseArray, true); die;
    }



    /*****
     *  @Function Name      : writeJSON
     *  @description        : This function write the json data into Settings.json
     *  @Author             : Niraj
     *  @Date               : 22 April, 2025
    *****/
    function writeJSON($data){

        if(empty($data) || !is_array($data)){
            $this->sendResponse(['status' => 'error', 'message' => 'Unsupported data provided'], 400);
        }else{

            $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

            if ($json === false || json_last_error() !== JSON_ERROR_NONE) {
                $this->sendResponse(['status' => 'error', 'message' => 'JSON encoding failed: ' . json_last_error_msg()], 400);
            }

            // Open file with write permission
            $fp = fopen($this->fileName, 'w');
            if (!$fp) {
                $this->sendResponse(['status' => 'error', 'message' => 'Could not open file for writing'], 400);
            }

            // Lock file (exclusive lock)
            if (flock($fp, LOCK_EX)) {
                // Write and release lock
                fwrite($fp, $json);
                fflush($fp);            // flush output before releasing lock
                flock($fp, LOCK_UN);    // unlock
                fclose($fp);
            } else {
                fclose($fp);
                $this->sendResponse(['status' => 'error', 'message' => 'Could not lock the file'], 400);
            }
        }
    }



    /*****
     *  @Function Name      : get_settings
     *  @description        : This function returns the device settings based on the requested parameters.
     *  @Author             : Niraj
     *  @Date               : 22 April, 2025
    *****/
	function get_settings(){

        if(count($this->requestedData) == 2 && isset($this->requestedData['type']) && isset($this->requestedData['value'])){

            //opening files
            $file = fopen($this->fileName, "r");
            if (!$file) {
                $this->sendResponse(['status' => 'error', 'message' => 'Unable to open settings file.'], 400);
            }

            //reading files
			$json_data 	   =   json_decode(fread($file, filesize($this->fileName)), true);
            fclose($file);
            
            //check json decoding
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->sendResponse(['status' => 'error', 'message' => 'Error decoding JSON: ' . json_last_error_msg()], 400);
            }

            //check manulate key value as per our Settings.json
            $typeParameter = ($this->requestedData['type'] == "input") ? "inputs" : (($this->requestedData['type'] == "output") ? "outputs" : "");

            //chekcking if requested parameter exist into the json
            if(isset($json_data[$typeParameter]) && isset($json_data[$typeParameter][$this->requestedData['value']])){

                $this->sendResponse(['status' => 'success', 'data' => $json_data[$typeParameter][$this->requestedData['value']]], 200);

            }else{
                $this->sendResponse(['status' => 'error', 'message' => 'Unsupported type or value provided.'], 400);
            }

        }else{
            $this->sendResponse(['status' => 'error', 'message' => 'Invalid parameters.'], 400);
        }

	}


    /*****
     *  @Function Name      : save_settings
     *  @description        : This function save the device settings based on the requested parameters.
     *  @Author             : Niraj
     *  @Date               : 22 April, 2025
    *****/
    function save_settings(){
        // Get the raw POST data
        $dataArray = json_decode($this->requestedData, true);

        if(json_last_error() != JSON_ERROR_NONE){
            $this->sendResponse(['status' => 'error', 'message' => 'Invalid request.'], 400);
        }

        if(count($dataArray) == 3 && isset($dataArray['type']) && isset($dataArray['value']) && isset($dataArray['data'])){

            //opening files
            $file = fopen($this->fileName, "r");
            if(!$file){
                $this->sendResponse(['status' => 'error', 'message' => 'Unable to open settings file.'], 400);
            }

            //reading files
            $json_data     =   json_decode(fread($file, filesize($this->fileName)), true);
            fclose($file);

            //check json decoding
            if (json_last_error() !== JSON_ERROR_NONE) {
                $this->sendResponse(['status' => 'error', 'message' => 'Error decoding JSON: ' . json_last_error_msg()], 400);
            }

            //check manulate key value as per our Settings.json
            $typeParameter = ($dataArray['type'] == "input") ? "inputs" : (($dataArray['type'] == "output") ? "outputs" : "");

            //chekcking if requested parameter exist into the json
            if(isset($json_data[$typeParameter]) && isset($json_data[$typeParameter][$dataArray['value']])){
                
                if(!empty($dataArray['data']) && is_array($dataArray['data'])){
                    
                    foreach($dataArray['data'] as $key => $value) {
                        if(isset($json_data[$typeParameter][$dataArray['value']][$key])){
                            $json_data[$typeParameter][$dataArray['value']][$key] = $value;
                        }
                    }

                    $this->writeJSON($json_data);
                    $this->sendResponse(['status' => 'success', 'message' => 'ok'], 200);
                
                }else{
                    $this->sendResponse(['status' => 'error', 'message' => 'Unsupported data provided'], 400);
                }

            }else{
                $this->sendResponse(['status' => 'error', 'message' => 'Unsupported type or value provided.'], 400);
            }

        }else{
            $this->sendResponse(['status' => 'error', 'message' => 'Invalid parameters.'], 400);
        }
    }



}


if($_SERVER['REQUEST_METHOD'] == "GET"){

    $apiObj = new DeviceSettings($_GET);
    $apiObj->get_settings();

}else if($_SERVER['REQUEST_METHOD'] == "POST"){

    $request =  file_get_contents('php://input');
    $apiObj = new DeviceSettings($request);
    $apiObj->save_settings();

}else{
    $apiObj->sendResponse(["status" => 'error', "message" => 'Method Not Allowed'], 405);
}


?>