<?php
$url = trim($_POST['url']);
$resolution = trim($_POST['resolution']);
$aspect_ratio = trim($_POST['aspect_ratio']);
$frame_rate = trim($_POST['frame_rate']);
$audio_channel = trim($_POST['audio_channel']);
$audio_rate = trim($_POST['audio_rate']);

$input_popup_arr = array(
	"inputs" => array(
		"command" => "AVoIP-TO-HDMI-1",
		"url" => $url,
		"stream_information" => array(
			"resolution" => $resolution, 
			"aspectRatio" => $aspect_ratio, 
			"frame_rate" => $frame_rate,
			"audio_channel" => $audio_channel,
			"audio_rate" => $audio_rate
		)  
	) 
);
$json_data = json_encode($input_popup_arr, JSON_UNESCAPED_SLASHES); 
file_put_contents('input-data.json', $json_data);
echo "saved";exit;;
?>