<?php 
class SaveInputSettings {
	private $postData = "";
	private $fileName = "input_settings.json"; 
	private $jsonData = "";
	public function __construct($postData) {
		$this->postData = $postData;
	}

	public function readFileData() {
		$this->jsonData = file_get_contents($this->fileName);
		$this->jsonData = json_decode($this->jsonData, true);
		$this->jsonData = $this->jsonData["settings"]["audioSettings"];
	}

	public function saveData() {
		$this->readFileData();
		foreach($this->postData["settings"] as $key => $value) {
			$this->jsonData[$key] = $value;
		}
       
		$saveData = array();
		$saveData["settings"]["audioSettings"] = $this->jsonData;
		file_put_contents($this->fileName, json_encode($saveData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
	}
}
$jsonData = file_get_contents('php://input');
$requestData = json_decode($jsonData, true);
$obj = new SaveInputSettings($requestData);
$obj->saveData();
?>