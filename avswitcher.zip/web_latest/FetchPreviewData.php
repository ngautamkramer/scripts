<?php 
class FetchPreviewData {
	private $postReqData = "";
	public function __construct($postReqData) {
		$this->postReqData = $postReqData;
		print_r($this->postReqData);
	}
}
$obj = new FetchPreviewData($_POST);
print_r($obj);
?>