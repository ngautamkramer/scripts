<?php 
class SaveOutputSettings {
	private $postData = "";
	private $fileName = "output_settings.json"; 
	private $jsonData = "";
	public function __construct($postData) {
		$this->postData = $postData;
	}

	public function readFileData() {
		$this->jsonData = file_get_contents($this->fileName);
		$this->jsonData = json_decode($this->jsonData, true);
		$this->jsonData = $this->jsonData["settings"];
	}

	public function saveData() {
		$this->readFileData();
		foreach($this->postData as $key => $value) {
			if($key == "castingMode") {
				if($value == "Unicast") {
					$this->jsonData["unicast"]["host"] = $this->postData["host"];
					$this->jsonData["unicast"]["port"] = $this->postData["port"];
				} else if($value == "Multicast") {
					$this->jsonData["multicast"]["host"] = $this->postData["host"];
					$this->jsonData["multicast"]["port"] = $this->postData["port"];
				}
			}
			if($key != "host" && $key != "port") {
				$this->jsonData[$key] = $value;	
			}
		}
		$saveData = array();
		$saveData["settings"] = $this->jsonData;
		file_put_contents($this->fileName, json_encode($saveData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
	}
}
$jsonData = file_get_contents('php://input');
$requestData = json_decode($jsonData, true);
$obj = new SaveOutputSettings($requestData);
$obj->saveData();
?>