<?php 
$latestJson = file_get_contents('latest.json'); 
$latestJsonData = json_decode($latestJson, true); 
foreach($latestJsonData as $key => $value) {
	echo "<pre>";
	print_r($value);
	echo "</pre>";
}
// print_r($latestJsonData);
?>