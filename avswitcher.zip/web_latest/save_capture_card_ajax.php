<?php
$devicename=trim($_POST['devicename']);
$capture_card_status=trim($_POST['capture_card_status']);
$explode_devices=explode("#",$devicename);
$boxname=$explode_devices[0];
$boxname_value=$explode_devices[1];

//reading json file
$input_devices_json = file_get_contents('/home/Collab8/config/AVSStatus.json'); 
// Decode the JSON file 
$json_data = json_decode($input_devices_json,true);
//print_r($json_data['inputs']);die;

$ccard_old_value=$json_data['inputs']['ccard']['name'];
//die($ccard_old_value);

//Replacing ccard value with selected
  $json_data['inputs']['ccard']['name'] = $boxname_value;
//Replacing selected box value with capture card
  //$json_data['inputs'][$boxname]['name']=$ccard_old_value;
if(array_key_exists('ccard', $json_data['inputs'])) {	
	//$json_data['inputs'][$boxname] = $json_data['inputs']['ccard'];
	$json_data['inputs'][$boxname]['name'] = $ccard_old_value;
	
    // Remove the old key
    //unset($json_data['inputs']['ccard']);	
}
//When capture_card_status is 0 then making capture_card_status enabled and making other to 0 
if($capture_card_status==0){
	$json_data['inputs']['ccard']['status'] = 1;
	$json_data['inputs'][$boxname]['status'] = 0;
}
//print_r($json_data['inputs']);die;

//print_r($json_data);die;

$json_data_devices=json_encode($json_data, JSON_UNESCAPED_SLASHES); 
file_put_contents('/home/Collab8/config/AVSStatus.json', $json_data_devices);
//print_r($json_data);die;

//reading json file
/*$input_devices_json = file_get_contents('input-devices.json'); 
// Decode the JSON file 
$json_data = json_decode($input_devices_json,true);
$ccard_old_value=$json_data['ccard'];
//Replacing ccard value with selected
$json_data['ccard'] = $boxname_value;
//Replacing selected box value with capture card
$json_data[$boxname] = $ccard_old_value;
//print_r($json_data);
$json_data_devices=json_encode($json_data, JSON_UNESCAPED_SLASHES); 
file_put_contents('input-devices.json', $json_data_devices);

*/

die('Saved successfully');
?>