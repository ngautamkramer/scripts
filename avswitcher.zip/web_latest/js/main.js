var avSwichterObj = {};
avSwichterObj.saveTestUrlAction = "save";
avSwichterObj.discovererVideoInput = "";
avSwichterObj.socket = "";
avSwichterObj.currentPlayingUrlBoxId = "";

avSwichterObj.outputVideoData = {};
avSwichterObj.outputVideoData["aspectRatio"] = "";
avSwichterObj.outputVideoData["format"] = "";
avSwichterObj.outputVideoData["frameRate"] = "";
avSwichterObj.outputVideoData["resolution"] = "";

avSwichterObj.outputAudioData = {};
avSwichterObj.outputAudioData["channels"] = "";
avSwichterObj.outputAudioData["format"] = "";
avSwichterObj.outputAudioData["sampleRate"] = "";

avSwichterObj.inputVideoData = {};
avSwichterObj.inputVideoData["aspectRatio"] = "";
avSwichterObj.inputVideoData["format"] = "";
avSwichterObj.inputVideoData["frameRate"] = "";
avSwichterObj.inputVideoData["resolution"] = "";

avSwichterObj.inputAudioData = {};
avSwichterObj.inputAudioData["channels"] = "";
avSwichterObj.inputAudioData["format"] = "";
avSwichterObj.inputAudioData["sampleRate"] = "";

avSwichterObj.jsonFile = "";
avSwichterObj.boxCommandArray = {}
avSwichterObj.boxCommandArray["box1"] = "USB-1-TO-HDMI-1";
avSwichterObj.boxCommandArray["box2"] = "USB-1-TO-HDMI-2";
avSwichterObj.boxCommandArray["box3"] = "USB-1-TO-AVoIP";
avSwichterObj.boxCommandArray["box4"] = "USB-2-TO-HDMI-1";
avSwichterObj.boxCommandArray["box5"] = "USB-2-TO-HDMI-2";
avSwichterObj.boxCommandArray["box6"] = "USB-2-TO-AVoIP";
avSwichterObj.boxCommandArray["box7"] = "USB-3-TO-HDMI-1";
avSwichterObj.boxCommandArray["box8"] = "USB-3-TO-HDMI-2";
avSwichterObj.boxCommandArray["box9"] = "USB-3-TO-AVoIP";
avSwichterObj.boxCommandArray["box10"] = "AVoIP-TO-HDMI-1";
avSwichterObj.boxCommandArray["box11"] = "AVoIP-TO-HDMI-2";
avSwichterObj.boxCommandArray["box12"] = "AVoIP-TO-AVoIP";
avSwichterObj.boxCommandName = "";
avSwichterObj.requestSendToSwitcher = "";
avSwichterObj.saveUrlNoResponseTimer = "";
avSwichterObj.outputProtcol = "RTMP"; 
avSwichterObj.outputAudio = true;
avSwichterObj.outputSettingsSave = {};
avSwichterObj.inputSettingsSave = {};
avSwichterObj.inputSettingsSave["settings"] = {};
avSwichterObj.currentInputId = "";
avSwichterObj.currentInputMute = true;
avSwichterObj.outputUrl = ""; 
avSwichterObj.setPreviewTime = "";
avSwichterObj.ajaxPreviewRequests = [];
avSwichterObj.latestOutputSettings = [];
avSwichterObj.saveUrl = (timeout = 7000) => {	
	let streamurl = $('#streamurl').val();
	let postData = {};
	postData["url"] = streamurl;
	if(avSwichterObj.currentPlayingUrlBoxId == "box10" || avSwichterObj.jsonFile.inputs.boxid == 'box10') {
		postData["boxid"] = "";
		postData["boxcommand"] = "";
		postData["inputaction"] = "stop";
	}
	postData["stream_information"] = {}; 
	postData["stream_information"]["resolution"] = streamurl == "" ? "" : avSwichterObj.discovererVideoInput.resolution;
	postData["stream_information"]["aspectRatio"] = streamurl == "" ? "" : avSwichterObj.discovererVideoInput.aspectRatio;
	postData["stream_information"]["frame_rate"] = streamurl == "" ? "" : avSwichterObj.discovererVideoInput.fps;
	postData["stream_information"]["audio_channel"] = streamurl == "" ? "" : avSwichterObj.discovererVideoInput.channels;
	postData["stream_information"]["audio_rate"] = streamurl == "" ? "" : avSwichterObj.discovererVideoInput.bitrate;
	jQuery.ajax({
		type:'POST',
		url:'UpdateStreamUrlInfo.php',
		data: JSON.stringify(postData),
		dataType: 'json',
		contentType:'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			setTimeout(() => {
				if(avSwichterObj.currentPlayingUrlBoxId == "box10" || avSwichterObj.jsonFile.inputs.boxid == 'box10') {
					$("#box10, #box11").removeClass("boxactive matrix-play-btn pointer");
					avSwichterObj.currentPlayingUrlBoxId = "";
					avSwichterObj.jsonFile.inputs.boxid = "";
				}
				if(streamurl == "") {
					//$("#input_avoip_value").text("Empty Settings");
					//$("#input_avoip_value img").attr('src', 'images/grid_settings.svg');
					$(".input_warning_circle").show();
					//$("#input_avoip_value").css("color", "");
					$("#input_avoip_status").removeClass("green-circle");
					$("#input_avoip_status").addClass("red-circle");
					// if(avSwichterObj.currentPlayingUrlBoxId == "box10") {
					// 	avSwichterObj.currentPlayingUrlBoxId = "";
					// 	avSwichterObj.jsonFile.inputs.boxid = "";	
					// }
					// $("#input_streamurl_value").html("");
					$("#audio_avoip_status").addClass('inactive_class');
					$('.test-url-info-empty').css('display', 'grid');
					$('.test-url-info').css('display', 'none');
				} else {
					avSwichterObj.jsonFile.inputs.url = streamurl;
					//$("#input_avoip_value").text("Settings");
					//$("#input_avoip_value img").attr('src', 'images/grid_settings_active.svg');
					$("#box10").addClass("boxactive pointer");
					$(".input_warning_circle").hide();
					//$("#input_avoip_value").css("color", "#69FFC3");
					$("#input_avoip_status").removeClass("red-circle");
					$("#input_avoip_status").addClass("green-circle");
					// $("#input_streamurl_value").html(streamurl);
					$("#audio_avoip_status").removeClass('inactive_class');
				}
				document.getElementById('overlay').style.display = 'none';
				$('#via-modal-inputpopup, .model-drop-shadow').hide();
				avSwichterObj.unset_active_box();
				$('#loadingError').hide();
				$('#streamurl').val("");
			}, timeout)	
		}					
	});
}

avSwichterObj.getJsonFileData = () => {
	jQuery.ajax({
		type:'GET',    
		url:'GetStreamUrlInfo.php',
		contentType:'application/json',
		dataType:'html',
		success:function(responseData, status, XMLHttpRequest) {
			avSwichterObj.jsonFile = JSON.parse(responseData);
		}					
	});
}

avSwichterObj.saveOutputSettings = () => {
	jQuery.ajax({
		type:'POST',   
		data: JSON.stringify(avSwichterObj.outputSettingsSave),
		url:'SaveOutputSettings.php',
		dataType:'json',
		contentType: 'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			console.log(JSON.stringify(avSwichterObj.outputSettingsSave));
		}					
	});
}

avSwichterObj.saveInputSettings = () => {
	jQuery.ajax({
		type:'POST',   
		data: JSON.stringify(avSwichterObj.inputSettingsSave),
		url:'SaveInputSettings.php',
		dataType:'json',
		contentType: 'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			console.log(responseData)
		}					
	});
}



avSwichterObj.getSavedUrlInfo = () => {
	jQuery.ajax({
		type:'GET',    
		url:'GetStreamUrlInfo.php',
		contentType:'application/json',
		dataType:'html',
		beforeSend : function() {
			$("#via-modal-inputpopup .modal-content-data").hide();
			$("#via-modal-inputpopup #overlay").attr("style", 'display:flex;background-color:transparent;height: calc(100% - 60px);top:60px;padding-bottom:60px;');
			$('#via-modal-inputpopup, .model-drop-shadow').show();
		},
		success:function(responseData, status, XMLHttpRequest) {
			responseData = JSON.parse(responseData);
			$("#input_resolution_div").text(responseData.inputs.stream_information.resolution);
			$("#input_frame_rate_div").text(responseData.inputs.stream_information.frame_rate);
			$("#input_audio_rate_div").text(responseData.inputs.stream_information.audio_rate);

			$("#input_aspect_ratio_div").text(responseData.inputs.stream_information.aspectRatio);
			$("#input_audio_channel_div").text(responseData.inputs.stream_information.audio_channel);

			$('#streamurl').val(responseData.inputs.url);
			$("#loadingError").hide();
			//$('#via-modal-inputpopup, .model-drop-shadow').show();
			$("#via-modal-inputpopup .modal-content-data").show();
			$("#via-modal-inputpopup #overlay").removeAttr('style');
		}					
	});
}

avSwichterObj.getOutputSettingsUrl = (callback) => {
	jQuery.ajax({
		type:'GET',    
		url:'GetOutputSettings.php',
		contentType:'application/json',
		dataType:'html',
		success:function(responseData, status, XMLHttpRequest) {
			responseData = JSON.parse(responseData);
			responseData = responseData["settings"]
			let protocol = responseData["protocol"];
			let postNumber = responseData["unicast"]["port"];
			if(responseData["castingMode"] == "Multicast") {
				postNumber = responseData["multicast"]["port"]
			}
			if(protocol == "RTMP") { 
				let lastCharInLocation = responseData["location"].charAt(responseData["location"].length - 1);
				avSwichterObj.outputUrl = lastCharInLocation == "/" ? responseData["location"] + responseData["key"] : responseData["location"] + "/" + responseData["key"];
			} else if(protocol == "UDP") {
				avSwichterObj.outputUrl = "udp://@:" + postNumber;
			} else if(protocol == "RTP") {
				avSwichterObj.outputUrl = "rtp://@:" + postNumber;
			}
			callback(responseData);
		}					
	});
}

avSwichterObj.getSavedOutputSettings = () => {
	jQuery.ajax({
		type:'POST',
		url:'GetOutputSettings.php',
		data:'',
		dataType:'json',
		beforeSend : function() {
			$('#avoip_output_settings').html('<div id="overlay" style="display:flex;background-color:transparent;height: calc(100% - 60px);top:60px;padding-bottom:60px;"><div><img src="images/bar-circle.gif" width="56px" height="56px"></div></div><div class="via-modal-header-output"><div>AVoIP OUTPUT Settings</div><div><span class="modal-close-icon"><img src="images/x_button.svg" width="20px" height="20px"><img class="display-none" id="closebtn_output" src="images/x_button-hover.svg" width="20px" height="20px"></span></div></div>');
			$('#avoip_output_settings, .model-drop-shadow').css("display","grid");
		},
		success:function(responseData, status, XMLHttpRequest) { 		
			let settings = responseData["settings"];
			avSwichterObj.latestOutputSettings = settings;
			avSwichterObj.outputProtcol = settings["protocol"];
			let defaultResolutions = settings["supportedResolution"]; 
			let defaultFrameRates = settings["supportedFrameRate"];
			let defualtProfiles  = settings["supportedProfile"];
			let defaultProtocols = settings["supportedProtocol"];
			let defaultAudioRates = settings["supportedAudioRate"];
			let defaultCastingModes = settings["supportedCastingMode"];
			//added by ashu to show casting drop down based on json and checking multicast and unicast ip
			// let casting_div_view='none';
			// let castingSelectedOption1 = "";
			// let castingSelectedOption2 = "";
			//alert(settings["protocol"]);
			// if(settings["protocol"]=='UDP' || settings["protocol"]=='RTP'){
			// 	casting_div_view='flex';
			// 	let casting_host=settings["host"].split('.');
			// 	//alert(casting_host[0])				
			// 	//alert(settings["host"]);
			// 	if(casting_host[0]<224){
			// 		//unicast
			// 		castingSelectedOption1 = 'selected="selected"';					
			// 	}else{
			// 		//multicast
			// 		castingSelectedOption2 = 'selected="selected"';
			// 	}
				
			// }
			
			let responseText = "";
			responseText += '<div id="overlay">';       
				responseText += '<div>';
					responseText += '<img src="images/bar-circle.gif" width="56px" height="56px">';
				responseText += '</div>';
    		responseText += '</div>';
			responseText += '<div class="via-modal-header-output">';
				responseText += '<div>AVoIP OUTPUT Settings</div>';
				responseText += '<div>'; 
					responseText += '<span class="modal-close-icon"><img src="images/x_button.svg" width="20px" height="20px"><img class="display-none" id="closebtn_output" src="images/x_button-hover.svg" width="20px" height="20px"></span>'; 
				responseText += '</div>';
			responseText += '</div>';
			responseText += '<div style="display: grid; padding-right:24px; padding-left:24px;">';
				responseText += '<div style="color: #FFF; display: flex; justify-content:flex-start;">Encoder</div>';
				responseText += '<div style="height:1px; width: 100%; background-color: #52555D;"></div>';	
			responseText += '</div>';
			responseText += '<div style="padding-left: 24px; padding-right: 24px; display: grid; grid-template-columns: 1fr 1fr;">';
				responseText += '<div>';
					responseText += '<div class="text-color-B2B9BF-bold-16">Video</div>';
					responseText += '<div style="display: flex; flex-direction: column; row-gap: 10px; padding-top: 10px;">';
						responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Codec</div>';
					responseText += '<div>';
        					responseText += '<div style="color: #B2B9BF;" class="figtree-font">'+ settings["videoCodec"] +'</div>';
						responseText += '</div>';
					responseText += '</div>';
					responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Resolution</div>';
						responseText += '<div>';
							responseText += '<select id="output_resolution" class="select-input-output-popup select-input-width" style="width:160px; height:30px;">';
								for(const resolutionKey in defaultResolutions) {
									let selectedOption = "";
									if(resolutionKey == settings["resolution"]) {
										selectedOption = 'selected="selected"';
									}
									responseText += '<option '+ selectedOption +' value="'+ resolutionKey +'">'+ resolutionKey +'</option>';
								}
							responseText += '</select>';
						responseText += '</div>';		
					responseText += '</div>';
					responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Frame Rate</div>';
						responseText += '<div>';
							responseText += '<select id="output_frame_rate" class="select-input-output-popup" style="width:85px; height:30px;">';
          						for(const frameRateKey in defaultFrameRates) {
          							let selectedOption = "";
									if(frameRateKey == settings["frameRate"]) {
										selectedOption = 'selected="selected"';
									}
									responseText += '<option '+ selectedOption +' value="'+ frameRateKey +'">'+ frameRateKey +'</option>';
								}
        					responseText += '</select>';
						responseText += '</div>';
					responseText += '</div>';
					responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Profile</div>';
						responseText += '<div>';
							responseText += '<select id="output_profile" class="select-input-output-popup select-input-width-mid" style="width:120px; height:30px;">';
								for(const profileKey in defualtProfiles) {	
									let selectedOption = "";
									if(profileKey == settings["profile"]) {
										selectedOption = 'selected="selected"';
									}
									responseText += '<option '+ selectedOption +' value="'+ profileKey +'">'+ profileKey +'</option>';
								}
        					responseText += '</select>';
						responseText += '</div>';
					responseText += '</div>';
				responseText += '</div>';
			responseText += '</div>';
			responseText += '<div>';
				responseText += '<div class="text-color-B2B9BF-bold-16">';
					responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div>Audio</div>';
						// responseText += '<div>';
						// 	responseText += '<div class="right-bottom-top-first">';
						// 		let checkedAudio = settings["audioEnabled"] ? 'checked="checked"' : "";
						// 		responseText += '<div>';
	    				// 			responseText += '<label class="onoffswitch">';
						// 				responseText += '<input type="checkbox" '+ checkedAudio +' name="enable_audio" class="onoffswitch-checkbox" id="enable_audio" tabindex="0">';
						// 				responseText += '<label class="onoffswitch-label" for="enable_audio"></label>';
						// 			responseText += '</label>';
						// 		responseText += '</div>';
						// 	responseText += '</div>';
						// responseText += '</div>';
					responseText += '</div>';
				responseText += '</div>';
				let checkedAudioInactive = settings["audioEnabled"] ? "" : "inactive_class";
				responseText += '<div id="audio_data" class="'+ checkedAudioInactive +'" style="display: flex; flex-direction: column; row-gap: 10px; padding-top: 10px;">';
					responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Codec</div>';
						responseText += '<div style="color: #B2B9BF;" class="figtree-font">'+ settings["audioCodec"] +'</div>';
					responseText += '</div>';
					responseText += '<div style="display: grid; grid-template-columns: 3.5fr 6.5fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Audio Rate</div>';
						responseText += '<div>';
							responseText += '<select id="output_audio_rate" class="select-input-output-popup" style="width:120px; height: 30px;">';
								for(const audioRatekey in defaultAudioRates) {
									let selectedOption = "";
									if(audioRatekey == settings["audioRate"]) {
										selectedOption = 'selected="selected"';
									}
									responseText += '<option '+ selectedOption +' value="'+ audioRatekey +'">'+ audioRatekey +'</option>';
								}
       						responseText += '</select>';
						responseText += '</div>';
					responseText += '</div>';
				responseText += '</div>';
			responseText += '</div>';
		responseText += '</div>';
		responseText += '<div style="display: grid; padding-right:24px; padding-left:24px;padding-top: 10px;row-gap: 8px;">';
			responseText += '<div style="color: #FFF; display: flex; justify-content:flex-start;">Stream</div>';
			responseText += '<div style="height:1px; width: 100%; background-color: #52555D;"></div>';	
		responseText += '</div>';
		responseText += '<div style="padding-left: 24px; padding-right: 24px; display: flex; flex-direction: column; row-gap: 10px; padding-top: 5px;">';
			responseText += '<div style="display: grid; grid-template-columns: 1.75fr 8.25fr;">';
				responseText += '<div class="text-color-868E96-14 flex-align-center">Protocol</div>';
				responseText += '<div style="display: grid; grid-template-columns: 4fr 6fr;">';
				
					responseText += '<div>';
						responseText += '<select id="output_protocol" class="select-input-output-popup select-input-width-mid" style="width:120px; height:30px;">';
							for(const protocolKey in defaultProtocols) {
								let selectedOption = "";
								if(protocolKey == settings["protocol"]) {
									selectedOption = 'selected="selected"';
								}
								responseText += '<option '+ selectedOption +' value="'+ protocolKey +'">'+ protocolKey +'</option>';
							}
						responseText += '</select>';
					responseText += '</div>';
					let showCastingModes = settings["protocol"] != "RTMP" ? "flex" : "none"
					responseText += '<div class="right-bottom-top-first" id="castingdiv" style="display:'+ showCastingModes +';">';
							responseText += '<div class="text-color-868E96-14 flex-align-center">IP Casting Mode</div>';
							responseText += '<div>';
								responseText += '<select id="casting_mode" class="select-input-output-popup select-input-width-mid" style="width:120px; height: 30px;">';
									for(const castingModeKey in defaultCastingModes) {
										let selectedOption = "";
										if(castingModeKey == settings["castingMode"]) {
											selectedOption = 'selected="selected"';
										}
										responseText += '<option '+ selectedOption +' value="'+ castingModeKey +'">'+ castingModeKey +'</option>';
									}	
								responseText += '</select>';
							responseText += '</div>';
						responseText += '</div>';
					responseText += '</div>';
				responseText += '</div>';
			responseText += '<div>';
				let protocolLocation = settings["protocol"] == "RTMP" ? "grid" : "none";
				responseText += '<div id="location_rtmp" style="display: '+ protocolLocation +'; grid-template-rows: 1fr 1fr; row-gap:10px;">';
					responseText += '<div style="display: grid; grid-template-columns:1.75fr 8.25fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Location</div>';
						responseText += '<div>';
							responseText += '<input value="'+ settings["location"] +'"placeholder="rtmp://a.rtmp.youtube.com/live2/" id="protocol_location" type="text" class="popup-txtbox">';
						responseText += '</div>';	
					responseText += '</div>';
					responseText += '<div style="display: grid; grid-template-columns:1.75fr 8.25fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Key</div>';
						responseText += '<div>';
							responseText += '<input value="'+ settings["key"] +'" placeholder="9dpf-9dpf-9dpf-9dpf-9dpf" id="protocol_key" type="text" class="popup-txtbox">';
						responseText += '</div>';
					responseText += '</div>';
				responseText += '</div>';
				let protocolHost = settings["protocol"] != "RTMP" ? "grid" : "none";
				let hostValue = settings["castingMode"] == "Unicast" ? settings["unicast"]["host"] : settings["multicast"]["host"];
				let hostPlaceHolder = settings["castingMode"] == "Unicast" ? "192.168.1.10" : "224.0.0.0 - 239.255.255.255";
				let portValue = settings["castingMode"] == "Unicast" ? settings["unicast"]["port"] : settings["multicast"]["port"] ;
				responseText += '<div id="host_port" style="display: '+ protocolHost +'; grid-template-rows: 1fr 1fr; row-gap:10px;">';
					responseText += '<div style="display: grid; grid-template-columns: 1.75fr 8.25fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Host</div>';
						responseText += '<div>';
							responseText += '<input value="'+ hostValue +'" placeholder="'+ hostPlaceHolder+'" id="protocol_host" type="text" class="popup-txtbox">';
						responseText += '</div>';
					responseText += '</div>';
					responseText += '<div style="display: grid; grid-template-columns: 1.75fr 8.25fr;">';
						responseText += '<div class="text-color-868E96-14 flex-align-center">Port</div>';
						responseText += '<div>';
							responseText += '<input value="'+ portValue +'" placeholder="5000" type="text" class="popup-txtbox" id="protocol_port">';
						responseText += '</div>';
					responseText += '</div>';
				responseText += '</div>';
			responseText += '</div>';
		responseText += '</div>';
		responseText += '<div style="padding-bottom: 16px;padding-left:24px;padding-right:24px;">';
			responseText += '<div class="flex-align-justify-center" style="height: 100%; column-gap:8px;align-items:end;">';
				//responseText += '<div>';
					responseText += '<button type="button" class="btn btn-outline-secondary btn-width btn-height pointer" id="cancelbtn-output">Cancel</button>';
				//responseText += '</div>';
				//responseText += '<div>';
					responseText += '<button type="button" class="btn btn-outline-primary btn-width btn-height pointer" id="save_output_settings">Save</button>';
				//responseText += '</div>';
			responseText += '</div>';
	    responseText += '</div>';
		$("#avoip_output_settings").html(responseText);
		//$('#avoip_output_settings, .model-drop-shadow').css("display","grid");
		

			// let defaultAudioCodec = responseData["default_settings"]["audioCodec"];
			// let defualtVideoCodec = responseData["default_settings"]["videoCodec"]; 

			// let savedAudio = responseData["saved_settings"]["audio"]; 
			// let savedFrameRate = responseData["saved_settings"]["frameRate"];
			// let savedAudioCodec = responseData["saved_settings"]["audioCodec"];
			// let savedVideoCodec = responseData["saved_settings"]["videoCodec"];
			// let savedResolution = responseData["saved_settings"]["resolution"];
			// let savedProfile = responseData["saved_settings"]["profile"];
			// let savedProtocol = responseData["saved_settings"]["protocol"];
			// let savedLocation = responseData["saved_settings"]["location"];
			// let savedKey = responseData["saved_settings"]["key"];
			// let savedHost = responseData["saved_settings"]["host"];
			// let savedPort = responseData["saved_settings"]["port"];   

			// console.log(resolution, responseData);	
		}					
	});
}

avSwichterObj.updatePlayingUrlBoxId = () => { 
	let postData = {};
	postData["boxid"] = avSwichterObj.currentPlayingUrlBoxId;
	postData["boxcommand"] = avSwichterObj.boxCommandName;
	if(avSwichterObj.currentPlayingUrlBoxId == "") {
		postData["input_video_data"] = {}; 
		postData["input_video_data"]["resolution"] = "";
		postData["input_video_data"]["aspectRatio"] = "";
		postData["input_video_data"]["format"] = "";
		postData["input_video_data"]["frameRate"] = "";

		postData["input_audio_data"] = {}; 
		postData["input_audio_data"]["channels"] = "";
		postData["input_audio_data"]["format"] = "";
		postData["input_audio_data"]["sampleRate"] = "";

		postData["output_video_data"] = {}; 
		postData["output_video_data"]["resolution"] = "";
		postData["output_video_data"]["aspectRatio"] = "";
		postData["output_video_data"]["format"] = "";
		postData["output_video_data"]["frameRate"] = "";

		postData["output_audio_data"] = {}; 
		postData["output_audio_data"]["channels"] = "";
		postData["output_audio_data"]["format"] = "";
		postData["output_audio_data"]["sampleRate"] = "";
		
	}
	jQuery.ajax({
		type:'POST',   
		data: JSON.stringify(postData),
		url:'UpdateStreamUrlInfo.php',
		dataType:'json',
		contentType:'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			// console.log(responseData)
		}					
	});
}

avSwichterObj.updatePreviewStatus = () => {
	let postData = {};
	postData["previewstatus"] = avSwichterObj.jsonFile.inputs.previewstatus;
	jQuery.ajax({
		type:'POST',  
		data: JSON.stringify(postData), 
		url:'UpdateStreamUrlInfo.php',
		dataType:'json',
		contentType:'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			console.log(responseData)
		}					
	});
}

avSwichterObj.updatePlayPauseStatus = () => {
	let postData = {};
	postData["inputaction"] = avSwichterObj.jsonFile.inputs.inputaction;
	jQuery.ajax({
		type:'POST',  
		data: JSON.stringify(postData),
		url:'UpdateStreamUrlInfo.php',
		dataType:'json',
		contentType:'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			console.log(responseData)
		}					
	});	
}

avSwichterObj.updateInputOutputAV = () => {
	let postData = {};
	postData["input_video_data"] = avSwichterObj.inputVideoData;
	postData["output_video_data"] = avSwichterObj.outputVideoData;
	postData["input_audio_data"] = avSwichterObj.inputAudioData;
	postData["output_audio_data"] = avSwichterObj.outputAudioData;	
	jQuery.ajax({
		type:'POST',  
		data: JSON.stringify(postData), 
		url:'UpdateStreamUrlInfo.php',
		dataType:'json',
		contentType:'application/json',
		success:function(responseData, status, XMLHttpRequest) {
			
			avSwichterObj.outputAudioData["channels"] = "";
			avSwichterObj.outputAudioData["format"] = "";
			avSwichterObj.outputAudioData["sampleRate"] = "";

			avSwichterObj.inputAudioData["channels"] = "";
			avSwichterObj.inputAudioData["format"] = "";
			avSwichterObj.inputAudioData["sampleRate"] = "";
			console.log(responseData)
		}					
	});	
}


avSwichterObj.fetchPreviewData = () => {
	jQuery.ajax({
		type:'POST',
		url:'getpreviewfilesajax.php',
		data:'',
		dataType:'json',
		beforeSend : function() {
		
		},
		success:function(responseData, status, XMLHttpRequest) { 
			let fileChangedTime = responseData["changedTimeStamp"];
			let fileName = responseData["file"];
			if(responseSendTime == "") {
				responseSendTime = responseData["currentTimeStamp"];;
			}

			if(fileChangedTime > responseSendTime) {
				$('#txtdiv').html('');
				$('#previewcontent').attr({'src':fileName +'?'+d.getTime()});	
			}
			//alert(responseData);
			console.log('running1',timeinterval, fileChangedTime, responseSendTime);	
		}					
	});
}

avSwichterObj.getPreview = (callback) => {
	let d = new Date();	
	const runningPreviewRQ = jQuery.ajax({
		type:'POST',
		url:'getpreviewfilesajax.php',
		data:'',
		dataType:'json',
		beforeSend : function(xhr) {
			avSwichterObj.ajaxPreviewRequests.push(xhr);
		},
		success:function(responseData, status, XMLHttpRequest) { 
			let fileChangedTime = responseData["changedTimeStamp"];
			let fileName = responseData["file"];
			if(avSwichterObj.setPreviewTime == "") {
				avSwichterObj.setPreviewTime = responseData["currentTimeStamp"];;
			}

			// if(fileChangedTime > avSwichterObj.setPreviewTime) {
				// console.log(fileChangedTime, fileName);
				// $('#txtdiv').html('');
				// document.getElementById("previewcontent").src = fileName;	
			callback(fileName);
			// }
			
		}					
	});
}


avSwichterObj.cancelPreviewRequests = () => {
	if (avSwichterObj.ajaxPreviewRequests.length > 0) {
    	avSwichterObj.ajaxPreviewRequests.forEach(xhr => xhr.abort());
    	avSwichterObj.ajaxPreviewRequests = [];
    	console.log("preview ajax cleared");
	}else{
		console.log("No preview ajax in queue");
	}
}


avSwichterObj.set_active_box = (this_element) => {
	this_element.attr("src", "images/grid_settings_active.svg");
	this_element.closest('.section-row-top-box').addClass('border-green');
}


avSwichterObj.unset_active_box = () => {	
	if($('.section-row-top-box.border-green').find('.red-circle').length > 0){
		$('.section-row-top-box.border-green').find('.settings-img').attr("src", "images/grid_settings.svg");
	}
	$('.section-row-top-box').removeClass('border-green');
}

avSwichterObj.unset_settings = () => {
	if(!$("#input_hdmi_in_status").hasClass("green-circle")){
		$("#setting_hdmiin_div").html('<img class="grid_setting inactive_class" src="images/grid_settings.svg">');
		$("#audio_hdmiin_div").html('<img class="inactive_class" src="images/speaker.svg">');
		if($("#input_hdmi_in_status").closest('.section-row-top-box').hasClass('border-green')){
			$("#via-modal-input-settings, .model-drop-shadow").hide();
		}
		$("#input_hdmi_in_status").closest('.section-row-top-box').removeClass('border-green');
	}
	if(!$("#input_usb1_status").hasClass("green-circle")){
		$("#setting_usb1_div").html('<img class="grid_setting inactive_class" src="images/grid_settings.svg">');
		$("#audio_usb1_div").html('<img class="inactive_class" src="images/speaker.svg">');
		if($("#input_usb1_status").closest('.section-row-top-box').hasClass('border-green')){
			$("#via-modal-input-settings, .model-drop-shadow").hide();
		}
		$("#input_usb1_status").closest('.section-row-top-box').removeClass('border-green');
	}
	if(!$("#input_usb2_status").hasClass("green-circle")){
		$("#setting_usb2_div").html('<img class="grid_setting inactive_class" src="images/grid_settings.svg">');
		$("#audio_usb2_div").html('<img class="inactive_class" src="images/speaker.svg">');
		if($("#input_usb2_status").closest('.section-row-top-box').hasClass('border-green')){
			$("#via-modal-input-settings, .model-drop-shadow").hide();
		}
		$("#input_usb2_status").closest('.section-row-top-box').removeClass('border-green');
	}
	if(!$("#input_usb3_status").hasClass("green-circle")){
		$("#setting_usb3_div").html('<img class="grid_setting inactive_class" src="images/grid_settings.svg">');
		$("#audio_usb3_div").html('<img class="inactive_class" src="images/speaker.svg">');
		if($("#input_usb3_status").closest('.section-row-top-box').hasClass('border-green')){
			$("#via-modal-input-settings, .model-drop-shadow").hide();
		}
		$("#input_usb3_status").closest('.section-row-top-box').removeClass('border-green');
	}
}

avSwichterObj.custom_alert = (msg, type = 'success') => {
	$('.update-message, .danger-message').remove();
	let htmlContent = '';
	if(type == 'success'){
		htmlContent = '<div class="update-message closeNotifier"><span style="font-size:15px;">' + msg + '</span><button type="button" title="dismiss" class="close_btn_alert"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></button></div>';
	}else{
		htmlContent = '<div class="danger-message closeNotifier"><span style="font-size:15px;">' + msg + '</span><button type="button" title="dismiss" class="close_btn_alert"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></button></div>';
	}
	$('body').append(htmlContent);
	setTimeout(function() {
		$(".update-message, .danger-message").remove(); 
	}, 3000);
}


avSwichterObj.set_html_for_streaminfo = (status, json_data = '') => {
	if(status == true){
		$("#input_streamurl_value").text(avSwichterObj.outputUrl);
		$("#stream_protocal_type").text(json_data['protocol']);
		if(json_data.protocol == 'RTMP'){
			$(".udp-rtp-info-div").hide();
			//$(".rtmp-info-div").show();
			//$("#stream_location").text(json_data['location']);
			//$("#stream_key").text(json_data['key']);
			$(".stream-info-area").removeClass('content-space-between').addClass('content-space-45');
		}else{
			//$(".rtmp-info-div").hide();
			$(".udp-rtp-info-div").show();
			$("#stream_casting_type").text(json_data['castingMode']);
			if(json_data['castingMode'] == "Multicast") {
				$("#stream_casting_host").text(json_data['multicast']['host']);
				$("#stream_casting_port").text(json_data['multicast']['port']);
			}else{
				$("#stream_casting_host").text(json_data['unicast']['host']);
				$("#stream_casting_port").text(json_data['unicast']['port']);
			}
			//$(".stream-info-area").removeClass('content-space-45').addClass('content-space-between');
		}
		$(".stream-info-container").css("display", "flex");
	}else{
		$(".stream-info-container").hide();					
		$("#input_streamurl_value, #stream_protocal_type, #stream_casting_type, #stream_casting_host, #stream_casting_port, #stream_location, #stream_key").text('');
	}
}


avSwichterObj.get_input_output_settings = (type, value, callback) => {
	jQuery.ajax({
		type:'GET',
		url:'device_settings.php',
		dataType: 'json',
		data: "type="+ encodeURIComponent(type) + "&value="+ encodeURIComponent(value),
		beforeSend : function() {
		},
		success:function(responseData, status, XMLHttpRequest) { 
			callback(responseData);
		}
	});

};


avSwichterObj.set_input_popup_settings = (responseData) => {

	let jsonObj = responseData;

	if(jsonObj.status == "success"){

		$("#via-modal-input-settings .modal-content-data-custom").show();
		$("#via-modal-input-settings #overlay").removeAttr('style');
		$("#via-modal-input-settings .via-modal").css("height", "auto");

		console.log(jsonObj.data);
		let json_data = jsonObj.data;

		let htmlCode = '';
		htmlCode += '<div class="box-settings-container">';
		   	htmlCode += '<div class="box-settings-area-left">';
		    	htmlCode += '<div class="box-settings-left">Device</div>';
		    	htmlCode += '<div class="box-settings-left">Name</div>';
		    	htmlCode += '<div class="box-settings-left">Video</div>';
		    	htmlCode += '<div class="box-settings-left">Quality</div>';
		   	htmlCode += '</div>';
		   	htmlCode += '<div class="box-settings-area-right">';
		     	htmlCode += '<div class="box-settings-right">';
		        	htmlCode += '<label id="input-setting-box-name" class="figtree-font">'+ json_data["name"] +'</label>';
		     	htmlCode += '</div>';
		     	htmlCode += '<div class="box-settings-right">';
		       	htmlCode += '<div>';
		        	htmlCode += '<label id="input-setting-device-name" class="figtree-font">' + json_data["deviceName"] + '</label>';
		       	htmlCode += '</div>';
		    htmlCode += '</div>'
		    htmlCode += '<div class="box-settings-right">';
		       	htmlCode += '<div class="box-right-22">';
		         	htmlCode += '<div class="box-right-3">';
		           		htmlCode += '<label class="onoffswitch width-auto">';
		             		let statusVideo = json_data["cameraEnabled"] == true ? "checked" : "";
		             		htmlCode += '<input type="checkbox" name="videoCheckStatus" class="onoffswitch-checkbox" id="videoCheckStatus" tabindex="0" '+statusVideo+'>';
		             		htmlCode += '<label class="onoffswitch-label" for="videoCheckStatus"></label>';
		           		htmlCode += '</label>';
		        	htmlCode += '</div>';
		        	htmlCode += '<div class="box-right-11">';
		           		htmlCode += '<div class="bg-gray-chips">Audio</div>';
		           		htmlCode += '<div class="box-right-3">';
		             		htmlCode += '<label class="onoffswitch width-auto">';
			               		let statusAudio = json_data["audioEnabled"] == true ? "checked" : "";
			               		htmlCode += '<input type="checkbox" name="audioCheckStatus" class="onoffswitch-checkbox" id="audioCheckStatus" tabindex="0" '+statusAudio+'>';
			               		htmlCode += '<label class="onoffswitch-label" for="audioCheckStatus"></label>';
		             		htmlCode += '</label>';
		          		htmlCode += '</div>';
		         	htmlCode += '</div>';
		    	htmlCode += '</div>';
		    htmlCode += '</div>';
		    htmlCode += '<div class="box-settings-right box-grid-3-7">';
		       	htmlCode += '<select class="select-input-output-popup" id="setting-quality-type">';
		       	let qualityList = json_data["supportedQualities"];
		        $.each(qualityList, function(key, value) {
				 	let selectedOption = (value == json_data["quality"]) ? 'selected="selected"' : "";
				 	htmlCode += '<option value="'+value+'" '+selectedOption+'>'+value+'</option>';
				});
		       	htmlCode += '</select>';
		    htmlCode += '</div>';
		   htmlCode += '</div>';
		htmlCode += '</div>';

		let customQulaityDiv = json_data["quality"] == "Custom" ? '' : 'style="display:none"';
		htmlCode += '<div class="box-settings-container input-custom-options" '+customQulaityDiv+'>';
			htmlCode += '<div class="box-settings-area-left">';
		    	htmlCode += '<div class="box-settings-left">Format</div>';
		    	htmlCode += '<div class="box-settings-left">Resolution</div>';
		    	htmlCode += '<div class="box-settings-left">Profile</div>';
			htmlCode += '</div>';
		  	htmlCode += '<div class="box-settings-area-right">';
		     	htmlCode += '<div class="box-settings-right box-grid-3-7">';
		       		htmlCode += '<select class="select-input-output-popup" id="setting-media-type">';
		         	$.each(json_data["supportedMediaTypes"], function(key, value) {
		         		let selectedOption = (value == json_data["mediaType"]) ? 'selected="selected"' : "";
				 		htmlCode += '<option value="'+value+'" '+selectedOption+'>'+value+'</option>';
				 	});
		    		htmlCode += '</select>';
		    	htmlCode += '</div>';
		    	htmlCode += '<div class="box-settings-right">';
		       		htmlCode += '<div class="box-right-2">';
		         		htmlCode += '<div class="box-right-3">';
		           			htmlCode += '<select class="select-input-output-popup" id="settings-resolutions">';
		           				$.each(json_data["supportedResolutions"], function(key, value) {
		           					let selectedOption = (value == json_data["resolution"]) ? 'selected="selected"' : "";
				 					htmlCode += '<option value="'+value+'" '+selectedOption+'>'+value+'</option>';
				 				});
		           			htmlCode += '</select>';
		         		htmlCode += '</div>';
		       		htmlCode += '</div>';
		    	htmlCode += '</div>';
		    	htmlCode += '<div class="box-settings-right">';
		       		htmlCode += '<select class="select-input-output-popup" style="width:375px;" id="settings-profiles">';
		        		$.each(json_data["supportedProfiles"], function(key, value) {
							let selectedOption = (value == json_data["profile"]) ? 'selected="selected"' : "";
				 			htmlCode += '<option title="'+value+'" value="'+value+'" '+selectedOption+'>'+value+'</option>';
						});
		       		htmlCode += '</select>';
		    	htmlCode += '</div>';
			htmlCode += '</div>';
		htmlCode += '</div>';
		htmlCode += '<div class="box-settings-container-2 input-custom-options"  '+customQulaityDiv+'>';
		   	htmlCode += '<div class="box-settings-area-left">';
		     	htmlCode += '<div class="box-settings-left">StreamName</div>';
		     	htmlCode += '<div class="box-settings-left inactive_class">A/V Latency Sync</div>';
		     	htmlCode += '<div class="box-settings-left inactive_class">Automatic Switching</div>';
		   	htmlCode += '</div>';
		   	htmlCode += '<div class="box-settings-area-right">';
		     	htmlCode += '<div class="box-settings-right">';
		       		htmlCode += '<div class="box-right-22">';
		         		htmlCode += '<div class="box-right-3">';
		           			htmlCode += '<label class="onoffswitch width-auto">';
		           	 			let statusDiagonstics = json_data["showDiagnostics"] == true ? "checked" : "";
		             			htmlCode += '<input type="checkbox" name="diagnosticsCheckStatus" class="onoffswitch-checkbox" id="diagnosticsCheckStatus" tabindex="0" '+statusDiagonstics+'>';
		             			htmlCode += '<label class="onoffswitch-label" for="diagnosticsCheckStatus"></label>';
		           			htmlCode += '</label>';
		         		htmlCode += '</div>';
		        		htmlCode += '<div class="box-right-1">';
		           			htmlCode += '<div class="bg-gray-chips">Diagnostics</div>';
		           				htmlCode += '<div class="box-right-3">';
		             				htmlCode += '<label class="onoffswitch width-auto">';
		               					let statusShowStream = json_data["showStreamName"] == true ? "checked" : "";
		               					htmlCode += '<input type="checkbox" name="streamnameCheckStatus" class="onoffswitch-checkbox" id="streamnameCheckStatus" tabindex="0" '+statusShowStream+'>';
		               					htmlCode += '<label class="onoffswitch-label" for="streamnameCheckStatus"></label>';
		             				htmlCode += '</label>';
		           				htmlCode += '</div>';
		         			htmlCode += '</div>';
		       			htmlCode += '</div>';
		     		htmlCode += '</div>';
		     	htmlCode += '<div class="box-settings-right inactive_class" style="grid-template-columns: 9fr 1fr;">';
		       		htmlCode += '<div class="slider-input">';
		         		htmlCode += '<input type="range" value="50" min="0" max="100" class="latency-range" style="background: linear-gradient(to right, rgb(105, 255, 195) 50%, rgb(134, 142, 150) 50%);">';
		       		htmlCode += '</div>';
		       		htmlCode += '<div id="latency-range-txt" align="right" class="figtree-font">50</div>';
		     	htmlCode += '</div>';
		     	htmlCode += '<div class="box-settings-right inactive_class">';
		       		htmlCode += '<div class="box-grid-3-7">';
		         		htmlCode += '<div class="box-right-3">';
		           			htmlCode += '<label class="onoffswitch width-auto">';
		             			htmlCode += '<input type="checkbox" name="checkbox-10" class="onoffswitch-checkbox" id="checkbox-10" tabindex="0" checked="">';
		             			htmlCode += '<label class="onoffswitch-label" for="checkbox-10"></label>';
		          	 		htmlCode += '</label>';
		         		htmlCode += '</div>';
		        		htmlCode += '<div class="grid-center">';
		           			htmlCode += '<select class="select-input-output-popup width-auto">';
		            			htmlCode += '<option>Fixed</option>';
		             			htmlCode += '<option>Dynamic</option>';
		           			htmlCode += '</select>';
		        		htmlCode += '</div>';
		       		htmlCode += '</div>';
		    	htmlCode += '</div>';
		   	htmlCode += '</div>';
		htmlCode += '</div>';
		htmlCode += '<div class="via-modal-footer" style="padding-top: 30px;">';
		   	htmlCode += '<div class="modal-content-button grid-gap-16" style="display: flex; justify-content: center;">';
		     	htmlCode += '<button type="button" class="btn btn-outline-secondary btn-width btn-height pointer" id="cancelbtn-inputsettings">Cancel</button>';
		     	htmlCode += '<button type="button" class="btn btn-outline-primary btn-width btn-height pointer" id="savebtn-inputsettings">Save</button>';
		   	htmlCode += '</div>';
		htmlCode += '</div>';
		$("#via-modal-input-settings .modal-content-data-custom").html(htmlCode);
		
	}else{
		
		$("#closebtn-input-settings").click();
		avSwichterObj.custom_alert(jsonObj.message, "danger");
	}
};


avSwichterObj.save_input_output_settings = (type, value, data, callback) => {
	jQuery.ajax({
		type:'POST',
		url:'device_settings.php',
		dataType: 'json',
		data: JSON.stringify({type: type, value: value, data: data}),
		beforeSend : function() {
		},
		success:function(responseData, status, XMLHttpRequest) { 
			callback(responseData);
		}
	});

};