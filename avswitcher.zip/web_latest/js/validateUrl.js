function validateUrl(url) {
  const result = {
      isValid: false,
      reason: ""
  };

  // Step 1: Check for invalid characters (non-URL-safe characters)
  const invalidCharsRegex = /[^a-zA-Z0-9\-_\.\:\/\?=]/;
  if (invalidCharsRegex.test(url)) {
      result.reason = "URL contains invalid characters.";
      return result;
  }

  // Step 2: Check if the URL starts with a valid protocol and includes '://'
  const protocolRegex = /^(udp|rtsp|rtp):\/\//;
  if (!protocolRegex.test(url)) {
      result.reason = "URL must start with udp://, rtsp://, or rtp:// followed by '://'.";
      return result;
  }

  // Ensure that the protocol is followed by exactly "://"
  if (!url.startsWith("udp://") && !url.startsWith("rtsp://") && !url.startsWith("rtp://")) {
      result.reason = "Invalid protocol or missing '://'.";
      return result;
  }

  try {
      const urlObj = new URL(url); // Try parsing the URL
      // Step 4: If the protocol is rtp://, check for a valid IP or domain
      if (urlObj.protocol === "rtp:" || urlObj.protocol === "udp:" || urlObj.protocol === "rtsp:") {
          const hostname = urlObj.hostname;

          // Validate if it's a valid IP address (IPv4)
          const ipRegex = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
          const ipMatch = hostname.match(ipRegex);

          if (ipMatch) {
              // Check if the IP address octets are valid (0-255)
              const validIP = ipMatch.slice(1).every(octet => {
                  const num = parseInt(octet, 10);
                  return num >= 0 && num <= 255;
              });

              if (!validIP) {
                  result.reason = "Invalid IP address format.";
                  return result;
              }
          } else {
              // If not IP, check for domain validation (only letters, numbers, hyphens, and dots)
              const domainRegex = /^[a-zA-Z0-9]+([\-\.]{1}[a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
              if (!domainRegex.test(hostname)) {
                  result.reason = "Invalid domain name format in RTP URL.";
                  return result;
              }
          }
      }

      // Step 5: If all checks pass, the URL is valid
      result.isValid = true;
      return result;

  } catch (error) {
      result.reason = "Invalid URL format.";
      return result;
  }
}

// Test cases
// const testUrls = [
//   "https://www.example.com",        // Valid: Starts with https:// and contains www.
//   "http://www.example.com",         // Valid: Starts with http:// and contains www.
//   "https://example.com",            // Invalid: Starts with https:// but no www.
//   "http://example.com",             // Invalid: Starts with http:// but no www.
//   "rtp://192.168.1.1",              // Valid: Starts with rtp:// and contains valid IP
//   "rtp://192.168.1.256",            // Invalid: Invalid IP (octet > 255)
//   "rtp://example.com",              // Valid: Starts with rtp:// and contains a valid domain
//   "rtp://example_domain.com",       // Invalid: Domain contains an underscore
//   "rtp://example-domain.com",       // Valid: Starts with rtp:// and contains a valid domain
//   "https:/www.example.com",         // Invalid: Missing one slash after https:
//   "https:/www.youtube.com/watch?v=es4x5R-rV9s&ab_channel=ScenicScenes", // Invalid: Missing one slash after https:
//   "ftp://www.example.com",          // Invalid: Protocol is not http/https or rtp
//   "https://www.ex@ample.com",       // Invalid: Invalid character (@)
//   "http://example#.com",            // Invalid: Invalid character (#)
//   "not a url"                       // Invalid: Invalid format
// ];

// Run tests
// testUrls.forEach(url => {
//   const result = validateUrl(url);
//   console.log(`URL: ${url}`);
//   console.log(`Valid: ${result.isValid}`);
//   if (!result.isValid) {
//       console.log(`Reason: ${result.reason}`);
//   }
//   console.log("---");
// });
