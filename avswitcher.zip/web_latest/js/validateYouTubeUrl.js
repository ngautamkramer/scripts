function validateYouTubeUrl(url) {
    const result = {
        isValid: false,
        reason: ""
    };

    // Step 1: Ensure the URL starts with https://www.youtube.com/
    if (!url.startsWith("https://www.youtube.com/")) {
        result.reason = "URL must start with https://www.youtube.com/";
        return result;
    }

    // Step 2: Check if it's a valid YouTube video URL
    const videoRegex = /^https:\/\/www\.youtube\.com\/watch\?v=[\w-]{11}(&[a-zA-Z0-9\-\_&=%]+)*$/;
    const channelRegex = /^https:\/\/www\.youtube\.com\/(channel\/[A-Za-z0-9_-]{24}|c\/[A-Za-z0-9_-]+)$/;

    if (videoRegex.test(url)) {
        result.isValid = true;
    }
    // Step 3: Check if it's a valid YouTube channel URL
    else if (channelRegex.test(url)) {
        result.isValid = true;
    } else {
        result.reason = "Invalid YouTube URL format.";
    }

    return result;
}

// Test cases
// const testUrls = [
//     "https://www.youtube.com/watch?v=dQw4w9WgXcQ",     // Valid video URL
//     "https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=30s", // Valid video URL with time
//     "https://www.youtube.com/channel/UC_x5XG1OV2P6uZZ5b6r0A", // Valid channel URL
//     "https://www.youtube.com/c/ScenicScenes",           // Valid custom channel URL
//     "https://www.youtube.com/watch?v=V6pG@nSFKt6g&ab_channel=SitBack%26RelaxGaming", // Valid URL with URL-encoded `&`
//     "https://www.youtube.com/c/Invalid Channel",       // Invalid custom channel URL with spaces
//     "https://www.youtub.com/watch?v=dQw4w9WgXcQ",      // Invalid domain
//     "https://www.youtube.com/watch?dQw4w9WgXcQ",       // Invalid video URL (missing 'v=')
//     "https://www.youtube.com/channel/123456",           // Invalid channel URL
//     "https://www.youtube.com/someotherpath"             // Invalid path
// ];

// // Run tests
// testUrls.forEach(url => {
//     const result = validateYouTubeUrl(url);
//     console.log(`URL: ${url}`);
//     console.log(`Valid: ${result.isValid}`);
//     if (!result.isValid) {
//         console.log(`Reason: ${result.reason}`);
//     }
//     console.log("---");
// });
