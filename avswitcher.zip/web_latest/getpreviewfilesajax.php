<?php

$file = '../../Collab8/config/AVSwitcher-dir/preview/preview.png';
$changedTimeStamp = strtotime(date("Y-m-d h:i:s", filemtime($file)));
$currentTimeStamp = strtotime(date("Y-m-d h:i:s"));

//changed version in every request
//$file = $file.'?v='.time();
if (file_exists($file)) {
	$imageData = file_get_contents($file);
	$base64String = base64_encode($imageData);
	$file = "data:image/png;base64," . $base64String;
}else{
	$file = "images/no-img.svg";
}

$response = array("file" => $file, "changedTimeStamp" => $changedTimeStamp, "currentTimeStamp" => $currentTimeStamp);
echo json_encode($response); exit;

//echo strtotime($changedTimeStamp) . "~" . $file . "~" . $currentTimeStamp;	

?>