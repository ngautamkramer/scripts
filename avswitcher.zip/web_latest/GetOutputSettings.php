<?php 
class GetOutputSettings {
	private $fileName = "output_settings.json";
	public function __construct() {
		
	}

	public function readFileData() {
		$file = fopen($this->fileName, "r") or die("Unable to open file!");
		return fread($file, filesize($this->fileName));
		// fclose($file);
	}

}
$obj = new GetOutputSettings();
$data = $obj->readFileData(); 
echo $data;
?>