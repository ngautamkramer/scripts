<?php

//php websocket library
require  __DIR__ . '/lib/websocket/vendor/autoload.php';

// error_reporting(E_ALL);
// ini_set('display_errors', true);

/**
 * Class Api
 *
 * This class is responsible for managing the API for AV Switcher.
 * It provides functionalities to send commands to the WSS server and update data into a web status file (input-data.json)..
 *
 * API Response Codes:
 * 200 : Success
 * 400 : Bad Request
 * 405 : Method Not Allowed
 * 500 : Internal Server Error
 */

class Api{

    private $serverIp;
    private $clientInputBoxes;
    private $webStatusJson;
    private $duplicateWebStatusJson;

    public function __construct() {

        $this->serverIp = $_SERVER['SERVER_ADDR'];

        $this->webStatusJson = "input-data.json";

        $this->duplicateWebStatusJson = "d-input-data.json";
        
        $this->clientInputBoxes = [
            "USB-1-TO-HDMI-1" => "box1",
            "USB-1-TO-HDMI-2" => "box2",
            "USB-1-TO-AVoIP" => "box3",
            "USB-2-TO-HDMI-1" => "box4",
            "USB-2-TO-HDMI-2" => "box5",
            "USB-2-TO-AVoIP" => "box6",
            "USB-3-TO-HDMI-1" => "box7",
            "USB-3-TO-HDMI-2" => "box8",
            "USB-3-TO-AVoIP" => "box9",
            "AVoIP-TO-HDMI-1" => "box10",
            "AVoIP-TO-HDMI-2" => "box11",
            "AVoIP-TO-AVoIP" => "box12",
        ];
    }


    /*****
     *  @Function Name      : sendRequestToWebsocketServer
     *  @description        : This function send requests to node server (wss://)
     *  @Author             : Niraj
     *  @Date               : 20 Sep, 2024
    *****/

    public function sendRequestToWebsocketServer($dataArray, $responseRequire){

        try{

            $jsonString = json_encode($dataArray, true);
            
            $client = new WebSocket\Client("wss://".$this->serverIp.":8080?source=clientConnection");

            /* if($timeout > 0){
                $client->setTimeout($timeout);
            }*/

            $client->setContext([
                "ssl" => ["verify_peer" => false, "verify_peer_name" => false]
            ]);
            
            // Send a message
            $client->text($jsonString);

            //get response
            $messageContent = '';
            if($responseRequire == true){
                $message = $client->receive();
                $messageContent = $message->getContent();
            }

            // Close connection
            $client->close();

            return $messageContent;

        }catch (Exception $e) {

            http_response_code(400);
            echo json_encode(["status" => 'error', "message" => $e->getMessage()], true); die;

        }

    }




    /*****
     *  @Function Name      : checkDeviceActive
     *  @description        : this will check requested input or output device is active or not
     *  @Author             : Niraj
     *  @Date               : 23 Sep, 2024
    *****/

    public function checkDeviceActive($input, $output){

        $input_device = strtolower($input);
        $output_device = strtolower($output);

        //getting all devices status
        $cmdArrayRefresh = ["command" => "statusUpdate"];
        $wssResponse  = $this->sendRequestToWebsocketServer($cmdArrayRefresh, true);
        $wssResponse = json_decode($wssResponse, true);

        if(strtolower($wssResponse['status']) == "success" && isset($wssResponse['data'])){

            $inputOutputArray = json_decode($wssResponse['data'], true);
            
            if(isset($inputOutputArray['inputs'][$input_device]['status']) && isset($inputOutputArray['outputs'][$output_device]['status'])){
                
                if($inputOutputArray['inputs'][$input_device]['status'] == 1 && $inputOutputArray['outputs'][$output_device]['status'] == 1){
                    return true;
                }else{
                    return false;
                }

            }else{
                return false;
            }
            
        }else{
            http_response_code(400);
            echo json_encode(['status' => $wssResponse['status'], 'message' => $wssResponse['errMessage']], true); die;
        }

    }



    /*****
     *  @Function Name      : getPlayerCommand
     *  @description        : return the command (for player) from the requested input & output device
     *  @Author             : Niraj
     *  @Date               : 25 Sep, 2024
    *****/

    public function getPlayerCommand($input, $output){
        $requestedInput = strtoupper($input);
        $requestedOutput = strtoupper($output);
        //check because all command values are capital expect AVoIP
        $requestedInput = $requestedInput == "AVOIP" ? "AVoIP" : $requestedInput;
        $requestedOutput = $requestedOutput == "AVOIP" ? "AVoIP" : $requestedOutput;
        return $requestedInput.'-TO-'.$requestedOutput;
    }



     /*****
     *  @Function Name      : copyContentInDuplicateFile
     *  @description        : copy input-data.json into d-input-data.json
     *  @Author             : Niraj
     *  @Date               : 23 Sep, 2024
    *****/

    public function copyContentInDuplicateFile(){
        if(file_exists($this->webStatusJson) && file_exists($this->duplicateWebStatusJson)){
            if(filesize($this->webStatusJson) > 0){
                copy($this->webStatusJson, $this->duplicateWebStatusJson);
            }
        }
    }



    /*****
     *  @Function Name      : writeJSON
     *  @description        : write json into input-data.json
     *  @Author             : Niraj
     *  @Date               : 23 Sep, 2024
    *****/

    public function writeJSON($statusJsonContent){
        $jsonStr = json_encode($statusJsonContent, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if($jsonStr === false || $jsonStr == null){
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'JSON encoding error.'], true); die;
        }
        file_put_contents($this->webStatusJson, trim($jsonStr), LOCK_EX);
        $this->copyContentInDuplicateFile();
        return true;
    }



    /*****
     *  @Function Name      : handlePostRequest
     *  @description        : Handle get request
     *  @Author             : Niraj
     *  @Date               : 20 Sep, 2024
    *****/

    public function handleGetRequest(){
        http_response_code(405);
        echo json_encode(["status" => 'error', "message" => 'Method Not Allowed'], true); die;
    }




     /*****
     *  @Function Name      : handlePostRequest
     *  @description        : This function send request to wss server
     *  @Author             : Niraj
     *  @Date               : 20 Sep, 2024
     *****/

     public function handlePostRequest($requestData){

        //check user input json is valid or not
        $requestData = json_decode($requestData, true);

        if(json_last_error() != JSON_ERROR_NONE){
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid request.'], true); die;
        }


        //check if web status json (input-data.json) is exist or not 
        if(file_exists($this->webStatusJson)){

            $statusJsonContent = file_get_contents($this->webStatusJson);
            if($statusJsonContent === false){
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Failed to read web status file.'], true); die;
            } 


            $statusJsonContent = json_decode($statusJsonContent, true);

            if($statusJsonContent !== null && json_last_error() === JSON_ERROR_NONE){

                $requestedCommand = isset($requestData['command']) ? trim(strtolower($requestData['command'])) : '';

                //check if command is play or stop URL
                if($requestedCommand == "play" || $requestedCommand == "stop"){

                    $requestedInputDevice =  isset($requestData['input']) ? trim($requestData['input']) : '';
                    $requestedOutputDevice = isset($requestData['output']) ? trim($requestData['output']) : '';

                    //check input and output request set
                    if($requestedInputDevice == "" || $requestedOutputDevice == "") {
                        http_response_code(400);
                        echo json_encode(['status' => 'error', 'message' => 'Invalid request.'], true); die;
                    }

                    //getting command from input and output value
                    $inputCommand = $this->getPlayerCommand($requestedInputDevice, $requestedOutputDevice);

                    //getting box id by command value if command value is valid then return a value                   
                    $inputBoxId = $this->clientInputBoxes[$inputCommand] ?? '';
                   
                    if(!empty($inputBoxId)){

                        //check input and output device active or not
                        if(!$this->checkDeviceActive($requestedInputDevice, $requestedOutputDevice)){
                            http_response_code(400);
                            echo json_encode(['status' => 'error', 'message' => 'Device is not active.'], true); die;
                        }
                        
                        //if any media is not playing and send stop command
                        if($statusJsonContent['inputs']['inputaction'] == "stop" && $requestedCommand == "stop"){
                            http_response_code(400);
                            echo json_encode(['status' => 'error', 'message' => 'Stream not available'], true); die;
                        }

                        //manupulate values for save current status into input-data.json
                        $statusJsonContent['inputs']['boxid'] = $requestedCommand == "play" ? $inputBoxId : "";
                        $statusJsonContent['inputs']['inputaction'] = $requestedCommand;
                        $statusJsonContent['inputs']['boxcommand'] = $inputCommand;
                        $this->writeJSON($statusJsonContent);
                        //end manupulate values for save current status into input-data.json

                        //sending command to wss server
                        $commandName = $requestedCommand == "play" ? "playurl" : "stopurl";
                        $cmdArrayTest = ["command" => $commandName, "input" => $inputCommand, "output" => 'hdmi'];

                        $isResponseRequire = ($commandName == "playurl") ? true : false; 
                        $wssResponse  = $this->sendRequestToWebsocketServer($cmdArrayTest, $isResponseRequire);
                        $wssResponse = json_decode($wssResponse, true);
                        
                        //removeing command key from the response which is comes from the player
                        if(isset($wssResponse['command'])){ unset($wssResponse['command']); }

                        //sending response as per play and stop URL command
                        if($commandName == "playurl"){
                            echo json_encode(['status' => 'success', 'data' => $wssResponse], true); die;
                        }else{
                            echo json_encode(['status' => 'success'], true); die;
                        }

                    }else{
                        http_response_code(400);
                        echo json_encode(['status' => 'error', 'message' => 'Invalid input or output device value.'], true); die;
                    }

                }else if($requestedCommand == "testurl"){ //for test URL

                    $streamURL =  isset($requestData['url']) ? trim($requestData['url']) : '';
                    $cmdArray = ["command" => 'testurl', "input" => $streamURL, "length" => strlen($streamURL)];
                    $wssResponseTestURL  = $this->sendRequestToWebsocketServer($cmdArray, true); 
                    $testURLData = json_decode($wssResponseTestURL, true);
                    
                    //removeing command key from the response which is comes from the player
                    if(isset($testURLData['command'])){ unset($testURLData['command']); }

                    //check if URL is valid
                    $urlStatus = $testURLData['info']['discoverer']['uriInfo']['status'] ?? '';
                    if($urlStatus == "VALID"){
                        echo json_encode(['status' => 'success', 'data' => $testURLData], true); die;
                    }else{
                        echo json_encode(['status' => 'error', 'message' => 'Invalid URL'], true); die;
                    }

                }else if($requestedCommand == "saveurl"){ //for save URL

                    $streamURL =  isset($requestData['url']) ? trim($requestData['url']) : '';

                    //send test URL command
                    $cmdArrayTest = ["command" => "testurl", "input" => $streamURL, "length" => strlen($streamURL)];
                    $wssResponseTestURL  = $this->sendRequestToWebsocketServer($cmdArrayTest, true);
                    $testURLData = json_decode($wssResponseTestURL, true);
                    
                    //removeing command key from the response which is comes from the player
                    if(isset($testURLData['command'])){ unset($testURLData['command']); }

                    //check if URL is valid
                    $urlStatus = $testURLData['info']['discoverer']['uriInfo']['status'] ?? '';
                    if($urlStatus == "VALID"){

                        $wssResponseInput = $testURLData['info']['discoverer']['streamInfo']['videoInfo']['input'];
                        
                        //manupulate values for save current status into input-data.json
                        $statusJsonContent['inputs']['url'] = $streamURL;
                        $streamInfo = array();
                        $streamInfo['resolution']   = $streamURL != "" && isset($wssResponseInput['resolution']) ? $wssResponseInput['resolution'] : "";
                        $streamInfo['aspectRatio']  = $streamURL != "" && isset($wssResponseInput['aspectRatio']) ? $wssResponseInput['aspectRatio'] : "";
                        $streamInfo['frame_rate']   = $streamURL != "" && isset($wssResponseInput['fps']) ? $wssResponseInput['fps'] : "";
                        $streamInfo['audio_channel']= $streamURL != "" && isset($wssResponseInput['channels']) ? $wssResponseInput['channels'] : "";
                        $streamInfo['audio_rate']   = $streamURL != "" && isset($wssResponseInput['bitrate']) ? $wssResponseInput['bitrate'] : "";
                        $statusJsonContent['inputs']['stream_information'] = $streamInfo;
                        $this->writeJSON($statusJsonContent);
                        //end manupulate values for save current status into input-data.json

                        //send save URL command
                        $cmdArraySave = ["command" => "saveurl", "input" => $streamURL, "length" => strlen($streamURL)];
                        $wssResponseSaveURL  = $this->sendRequestToWebsocketServer($cmdArraySave, false);

                        echo json_encode(['status' => 'success', 'data' => $testURLData], true); die;

                    }else{

                        http_response_code(400);
                        echo json_encode(['status' => 'error', 'message' => 'Invalid URL'], true); die;

                    }

                }else{

                    http_response_code(400);
                    echo json_encode(['status' => 'error', 'message' => 'Invalid request.'], true); die;
                }

            }else{

                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Invalid web status json.'], true); die;
            }

        }else{

            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'File does not exist.'], true); die;
        }


    }


}




/*****
 *  @description        : Initialize class and send to function according to GET and POST methods, 
 *  @Author             : Niraj
 *  @Date               : 20 Sep, 2024
 *****/
header("X-Frame-Options: SAMEORIGIN");
header("Content-Type: application/json");
$method = $_SERVER['REQUEST_METHOD'];


$apiObj = new Api();
//only GET & POST method allowd
switch($method){
    case 'GET':
    $apiObj->handleGetRequest();
    break;
    case 'POST':
    $request =  file_get_contents('php://input');
    $apiObj->handlePostRequest($request);
    break;
    default:
    http_response_code(405);
    echo json_encode(["status" => 'error', "message" => 'Method Not Allowed'], true); die;
    break;
}


?>
