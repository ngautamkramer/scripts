var server = require('websocket').server;
var https = require('https');
var fs = require('fs');


var port=8080;
// certificate path
const options = {
    key: fs.readFileSync('/etc/pki/tls/private/localhost.key', 'utf8'),
    cert: fs.readFileSync('/etc/pki/tls/certs/localhost.crt', 'utf8')
};
var httpsNodeServer = https.createServer(options, (req, res) => {
    res.writeHead(200);
    res.end('hello world\n');
});
// comment above and uncomment below code if required unsecure server
//var http = require('http');
//var httpsNodeServer = http.createServer();

// Start listening
httpsNodeServer.listen(port, function () {
    console.log("Server is listening on port: " + port);
});

wsServer = new server({
    httpServer: httpsNodeServer
});
let webConnections = {};
let switcherConnection = "";
 
wsServer.on('request', function (request) {
    let sourceOrigin = request.resourceURL.query.source;
    console.log(sourceOrigin);
    // this is the request come from web browser for connection single time
    if (sourceOrigin == "clientConnection") {
        webConnections[request.key] = request.accept(null, request.origin);
        handleWebClientConnection(request);
    }
    // this is the request come from avswichter app from gateway on its start 
    else if (sourceOrigin == "AVSwitcherConnection") {
        handleSwitcherConnection(request);
    let response = {};
    response.command = "Socket Connected";
    if(Object.keys(webConnections).length > 0) {
                for (const prop in webConnections) {
                    webConnections[prop].sendUTF(JSON.stringify(response));
            }
        }

    
    }
})


function handleWebClientConnection(request) {
    webConnections[request.key].on('message', function (data) {
        let response = JSON.parse(data.utf8Data);
        // on the sucessfull web socket connection request come for latest update in json to show on web  
        if(response.command == 'statusUpdate') {
            // reading the file and semd its response on web
            // fs.readFile('/home/Collab8/config/AVSStatus.json', 'utf8', (err, data) => {
            fs.readFile('/home/Collab8/config/AVSStatus.json', 'utf8', (err, data) => {
                let response = {};
                if (err) {
                    response.status = "Error";
                   if (err.code === "ENOENT") {
                        response.errMessage = "File not found";
                    } else {
                        response.errMessage = "Error reading file";
                    }
                } else {
                    response.status = "Success";
                    response.data = data; 
                }
                webConnections[request.key].sendUTF(JSON.stringify(response));
            });
        } else if (response.command == 'playurl' || response.command == 'stopurl' 
            || response.command == 'testurl' || response.command == 'saveurl') {
            if(switcherConnection) {
              let result = JSON.parse(data.utf8Data);
              result["key"] = request.key;
              result = JSON.stringify(result);
                // receive the request from browser ans send it to avswitcher
                switcherConnection.sendUTF(result);    
            } else {
                let response = {};
                response["status"] = "avSwitcherDown";
                response["message"] = "Av switcher is not connected to the server";
                webConnections[request.key].sendUTF(JSON.stringify(response));
            }
        } else if (response.command == "refresh") {
            const { exec } = require('child_process');
            const startUpCommand = 'cd /home/Collab8/config/AVSwitcher-dir/bin; export DISPLAY=:0; ./AVSwitcher > ../logs/AVSwitcher.txt &';
            function checkAndStartAVSwitcher() {
              exec('ps -x | grep AVSwitcher', (error, stdout, stderr) => {
                if (error) {
                  console.error(`Error checking AVSwitcher status: ${error}`);
                  return;
                }

                const processes = stdout.split('\n');
                const isRunning = processes.some(process => {
                    const parts = process.trim().split(/\s+/);
                    return parts[parts.length - 1] === './AVSwitcher' && !process.includes('grep');
                });

                if (isRunning) {
                  console.log('AVSwitcher is already running');
                } else {
                  console.log('AVSwitcher is not running. Starting it now...');
                  exec(startUpCommand, (err, stdout, stderr) => {
                    if (err) {
                      console.error(`Error starting AVSwitcher: ${err}`);
                      return;
                    } console.log('AVSwitcher started successfully');
                  });
                }
              });
            }
            console.log('Checking AVSwitcher Status');
            checkAndStartAVSwitcher();
        }
    });

    webConnections[request.key].on('close', function (event) {
        delete webConnections[request.key];
    });

    webConnections[request.key].on('error', function (event) {
        // delete webConnections[jid];
        // console.log("Error", request.key)
    });
}

function handleSwitcherConnection(request) {
    switcherConnection = request.accept(null, request.origin);
    switcherConnection.on('message', function (data) {
        let response = JSON.parse(data.utf8Data);
    console.log(response);
        // request come from avswitcher ans send the status update to web client 
        if(response.command == 'refreshstatus') {
            // fs.readFile('/home/Collab8/config/AVSStatus.json', 'utf8', (err, data) => {
                fs.readFile('/home/Collab8/config/AVSStatus.json', 'utf8', (err, data) => {
                let response = {};
                if (err) {
                    response.status = "Error";
                   if (err.code === "ENOENT") {
                        response.errMessage = "File not found";
                    } else {
                        response.errMessage = "Error reading file";
                    }
                } else {
                    response.status = "Success";
                    response.data = data; 
                }
                if(Object.keys(webConnections).length > 0) {
                    for (const prop in webConnections) {
                        webConnections[prop].sendUTF(JSON.stringify(response));
                    }
                }
            });
        } else if((response.command == 'playurlstatus' && response.length > 0) 
            || response.command == 'playurldata' || response.command == 'testurlstatus' 
            || response.command == 'saveurlstatus') {
            if(Object.keys(webConnections).length > 0) {
                for (const prop in webConnections) {
                    webConnections[prop].sendUTF(JSON.stringify(response));
                }
            }
        }
    });

    switcherConnection.on('close', function () {
    let response = {};
    response.command = "Socket Close";
    if(Object.keys(webConnections).length > 0) {
            for (const prop in webConnections) {
                    webConnections[prop].sendUTF(JSON.stringify(response));
                }
        }
        console.log("switcher connection is closed.");  
    });

    switcherConnection.on('error', function (e) {
    let response = {};
    response.command = "Socket Error";
    if(Object.keys(webConnections).length > 0) {
                for (const prop in webConnections) {
                    webConnections[prop].sendUTF(JSON.stringify(response));
            }
        }
        console.log("Error occured in switcher.");
    });
}
