<?php //getting ip address
error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
ini_set('display_errors', false);
// $ipadd_file="ipadd.txt";
$ipadd_file="/var/www/html/Collab8/config/ipadd.txt";

 $open_ip_addfile = fopen($ipadd_file, "r") or die("Unable to open file!");
 $ipadd=trim(fread($open_ip_addfile,filesize($ipadd_file)));
 fclose($open_ip_addfile);
// Read the JSON file 
// it will set from input pop up and store json in input-data.json
$json = file_get_contents('input-data.json');
// Decode the JSON file 
$json_data = json_decode($json,true);

//if json is null then this will fetch from duplicate json
if($json_data === null) {
	$json = file_get_contents('d-input-data.json'); 
	$json_data = json_decode($json,true);
}
// Display data 
// echo "<pre>";
// print_r($json_data);
// echo "</pre>";
foreach($json_data as $k=>$v) {
	$input_command = $k;	
}
$jsonInputSettings = file_get_contents('input_settings.json'); 
// Decode the JSON file 
// $jsonInputSettingsData = json_decode($jsonInputSettings,true);
$command = $json_data[$input_command]['command'];
$url = trim($json_data[$input_command]['url']);
$streamInfo = $json_data[$input_command]['stream_information'];
$lastUrlPlayedBoxId = trim($json_data[$input_command]['boxid']);
$resolution = trim($streamInfo['resolution']);
$aspectRatio = trim($streamInfo['aspectRatio']);
$frame_rate = trim($streamInfo['frame_rate']);
$audio_channel = trim($streamInfo['audio_channel']);
$audio_rate = trim($streamInfo['audio_rate']);
$previewStatus = trim($json_data[$input_command]['previewstatus']);
$inputAction = trim($json_data[$input_command]['inputaction']);

//getting command length
//$json_arr = array("input"=>$command, "inputparam"=>array("inputurl"=>$url), "output"=>"hdmi","outputparam"=>array("outputurl"=>""));
$json_arr = array("input"=>$command, "inputparam"=>array("inputurl"=>"$url"), "output"=>"hdmi","outputparam"=>array());
$input_play_button_json = json_encode($json_arr, JSON_UNESCAPED_SLASHES); 

//echo "<pre>" . $input_play_button_json . "<pre/>"; 
$json_command_length=mb_strlen(json_encode($json_arr, JSON_NUMERIC_CHECK), '8bit');

//usb1 json and getting length
$usb1_json_arr = array("input"=>"usb-1", "inputparam"=>array("inputurl"=>""), "output"=>"hdmi","outputparam"=>array());
$json_encode_usb1 = json_encode($usb1_json_arr, JSON_UNESCAPED_SLASHES); 

//echo "<pre>" . $json_encode_usb1 . "<pre/>"; 
$usb1_length=mb_strlen(json_encode($usb1_json_arr, JSON_NUMERIC_CHECK), '8bit');

//usb2 json and getting length
$usb2_json_arr = array("input"=>"usb-2", "inputparam"=>array("inputurl"=>""), "output"=>"hdmi","outputparam"=>array());
$json_encode_usb2 = json_encode($usb2_json_arr, JSON_UNESCAPED_SLASHES); 

//echo "<pre>" . $json_encode_usb2 . "<pre/>"; 
$usb2_length=mb_strlen(json_encode($usb2_json_arr, JSON_NUMERIC_CHECK), '8bit');

//Reading AVSStatus.json
$avs_status_json = file_get_contents('/home/Collab8/config/AVSStatus.json'); 
// Decode the JSON file 
$avs_json_data = json_decode($avs_status_json,true);
// Display data 
//echo"<pre>";print_r($avs_json_data);
//echo $avs_json_data['inputs']['avoip']['status']." and ".$avs_json_data['inputs']['ccard']['status']." and ".$avs_json_data['inputs']['usb-1']['status']." and ".$avs_json_data['inputs']['usb-2']['status'];
$input_device_array=array();
foreach($avs_json_data as $k=>$v){
	if($k=='inputs'){
		//echo "<pre>";print_r($v);
		foreach($v as $k1=>$v1){
			//echo "<pre>";print_r($v1);			
			//echo 'Status='.$k1[1];
			if($v1['status']==1 && $v1['name']!=""){
				//echo "<br>".$k1.'   '.'Name='.$v1['name'];
				$input_device_array[$k1]=$v1['name'];
			}
		}
		
	}
}
//echo "<pre>";print_r($input_device_array);
//$input_device_array=array("avoip"=>"172.30.92.79","usb1"=>"x","usb2"=>"y","ccard"=>"HDMI-IN");
//$json_data_devices=json_encode($input_device_array, JSON_UNESCAPED_SLASHES); 
//file_put_contents('input-devices.json', $json_data_devices);

//echo "<pre>";print_r($input_device_array);

//reading json file
//$read_input_devices_json = file_get_contents('input-devices.json'); 
//$input_devices_json_arr = json_decode($read_input_devices_json,true);
//echo "<pre>";print_r($input_devices_json_arr);

?>
<!DOCTYPE html>
<html lang="en">
	<head>
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="css/style.css?time=<?php echo time();?>">
		<link rel="stylesheet" type="text/css" href="css/media-query.css?time=<?php echo time();?>"> 
		<link href="css/font-awesome.min.css?time=<?php echo time();?>" media="screen" rel="stylesheet" type="text/css">
		<link href="css/font.css?time=<?php echo time();?>" media="screen" rel="stylesheet" type="text/css">
		<link href="css/main.css?time=<?php echo time();?>" media="screen" rel="stylesheet" type="text/css">
		<link href="css/input-popup.css?time=<?php echo time();?>" media="screen" rel="stylesheet" type="text/css">
		<link href="css/output_popup.css?time=<?php echo time();?>" media="screen" rel="stylesheet" type="text/css">
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/validateUrl.js"></script>
		<script type="text/javascript" src="js/validateYouTubeUrl.js"></script>
		<script type="text/javascript" src="js/main.js"></script>
    </head>
    <body>
    	<!-- avoip output setting starts  -->

    	<div class="via-modal" id="avoip_output_settings" style="display: none; width: 700px; height: 550px; row-gap: 5px; grid-template-rows: 1fr 0.5fr 2fr 0.5fr 2fr 1.5fr;">
    	</div>
    	

    	<!-- avoip output settings ends  -->
 <div class="container">
    		<div class="header">
    			<div style="display: flex; align-items: center; padding-left: 10px;">
                    <img src="images/logo.svg">    
                </div>
                <div style="color: #FFFFFF; font-size: 26px; display: flex; align-items: center; margin-left: 40px;">AV Switcher</div>
    			
    		</div>
    		<div class="data-container">
    			<div style="background-color: #272B34; display: grid; grid-template-rows: 0.5fr 9.5fr;">
    				<div style="display: flex;">
    					<div class="left-top-first">
    						<div class="left-top-first-div">Routing</div>
    						<div class="left-top-second-div">
    							<!-- <div class="auto-switch">Auto Switching</div>
    							<div class="overflow-hidden">
    								<label class="onoffswitch">
										<input type="checkbox" name="autoswitchonoff" class="onoffswitch-checkbox" id="autoswitchonoff" tabindex="0" checked>
										<label class="onoffswitch-label" for="autoswitchonoff"></label>
									</label>
						
    							</div>
    							<div  class="text-on">On</div> -->
    						</div>
	    					<div class="left-top-third-div">
	    						<div class="refresh-button-container pointer refreshbtn" id="refreshbtn">
	    							<div>
	    								<!-- <img class="refresh-img" src="images/refresh.svg"> -->
										<svg class="refresh-img" width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
										<path d="M7.00095 14C3.13954 14 0 10.859 0 7C0 5.65576 0.37812 4.36116 1.09617 3.23841L3.08034 6.80906H1.05606V7C1.05606 8.16858 1.39599 9.30087 2.04147 10.2766C2.68695 11.2523 3.59405 12.0085 4.66921 12.4667C5.41018 12.7818 6.19506 12.9422 7.00095 12.9422C7.35807 12.9422 7.719 12.9097 8.07039 12.8448C9.13982 12.65 10.1252 12.1688 10.9349 11.4528L11.4582 12.3942C10.2092 13.4291 8.63566 13.9962 7.0105 13.9962H7.00095V14ZM10.9216 7.19094H12.9458V7C12.9458 5.83142 12.6059 4.69722 11.9604 3.7234C11.3169 2.74768 10.4079 1.99154 9.3327 1.53328C8.59173 1.21822 7.80685 1.05783 7.00095 1.05783C6.64384 1.05783 6.28291 1.09029 5.93152 1.15521C4.86209 1.34997 3.87669 1.83115 3.06698 2.54719L2.54372 1.60584C3.79266 0.569013 5.36434 0 6.9895 0C10.8605 0 14 3.13912 14 7C14 8.34424 13.6219 9.63884 12.9038 10.7616L10.9197 7.19094H10.9216Z" fill="#868E96"/>
										</svg>

	    							</div>
	    							<div class="refresh-text">Reload</div>
	    						</div>
	    					</div>
    					</div>
    				</div>
    				<div class="grid-section-container-left">
						
						<div class="input-line">
						<div></div>
						<div class="input-container">
								<div style="display: grid; grid-template-rows: repeat(5, 1fr);" class="overflow-hidden">
									<div></div>
									<div class="overflow-hidden" style="position:relative"><div class="text-imputs">Inputs</div></div>
									<div></div>
									<div></div>
									<div></div>
								</div>
								<div style="display: grid; grid-template-rows: repeat(5, 1fr); width: 1px;">
									<div></div>
									<div style="background-color: #868E96;width: 0.5px;"></div>
									<div style="background-color: #868E96;width: 0.5px;"></div>
									<div style="background-color: #868E96;width: 0.5px;"></div>
									<div style="background-color: #868E96;width: 0.5px;"></div>
								</div>
								
							</div>
							<div></div>
						</div>
    					<div style="display: grid; grid-template-rows: 0.4fr 7.2fr 2.4fr; height: 100%;">
    					<!-- outputs text and line -->
    					<div class="output-container">
    						<div></div>
    						<div class="overflow-hidden" style="display: grid; grid-template-rows: 8fr 2fr; row-gap: 5px;">
								<div style="display: grid; grid-template-columns: repeat(4, 1fr);">
									<div></div>
									<div style="color: #868E96;">Outputs</div>
									<div></div>
									<div></div>
								</div>	
								<div class="outputs-divider">
									<div></div>
									<div style="height: 0.5px; width: 100%; background-color: #868E96;"></div>
									<div style="height: 0.5px; width: 100%; background-color: #868E96;"></div>
									<div style="height: 0.5px; width: 100%; background-color: #868E96;"></div>
								</div>	
							</div>
    					</div>
						<!-- outputs text and line -->

						<div class="grid-section-container-bottom">
							<!-- <div class="input-container">
								<div style="display: grid; grid-template-rows: repeat(5, 1fr);" class="overflow-hidden">
									<div></div>
									<div class="overflow-hidden"><div class="text-imputs">Inputs</div></div>
									<div></div>
									<div></div>
									<div></div>
								</div>
								<div style="display: grid; grid-template-rows: repeat(5, 1fr); width: 1px;">
									<div></div>
									<div style="background-color: #868E96;"></div>
									<div style="background-color: #868E96;"></div>
									<div style="background-color: #868E96;"></div>
									<div style="background-color: #868E96;"></div>
								</div>
								
							</div> -->
							<div class="grid-container">
								<div class="grid-container-section">
	    							<div></div>
	    							<div class="section-row-top-box">
	    								<div class="section-row-top">
	    									<div class="section-row-top-left">HDMI-1</div>
	    									<div class="section-row-top-right">
	    										<div class="red-circle" id="output_hdmi1_status"></div>
	    									</div>
	    									
	    								</div>
	    								<div class="section-row-bottom">
	    									<div class="section-row-bottom-single" id="output_hdmi1_name"></div>
	    								</div>
	    							</div>
	    							<div class="section-row-top-box">
	    								<div class="section-row-top">
	    									<div class="section-row-top-left">HDMI-2</div>
	    									<div class="section-row-top-right">
	    										<div class="red-circle" id="output_hdmi2_status"></div>
	    									</div>
	    									
	    								</div>
	    								<div class="section-row-bottom">
	    									<div class="section-row-bottom-single" id="output_hdmi2_name"></div>
	    								</div>
	    							</div>
	    							<div class="section-row-top-box">
	    								<div class="section-row-top">
	    									<div class="section-row-top-left">AVoIP Stream</div>
	    									<div class="section-row-top-right">
	    										<div class="red-circle" id="output_avoip_status"></div>
	    									</div>
	    									
	    								</div>
	    								<?php 
	    									$dependenncy = true;
    										$outputAvoipText = $dependenncy == false ? "Empty Settings" : "Settings";
    										//ouput_avoip_value
    										$outputFontColor = $dependenncy == false ? "" : "#69FFC3";
    										$outputAvoipWarningCirle = $dependenncy == false ? "flex" : "none"; 
    									?>

    									<div class="section-row-bottom">
	    									<div class="section-bottom-empty-setting-left avoip_output_pop_css pointer" style="color:<?php echo $outputFontColor;?>" id="ouput_avoip_value">
	    										<?php echo $outputAvoipText;?>
	    									</div>
	    									<div style="display: <?php echo $outputAvoipWarningCirle;?>" class="section-bottom-empty-setting-right avoip_output_pop_css ouput_warning_circle">
	    										<img src="images/warning_circle_line.svg">
	    									</div>
    									</div>
	    							</div>
		    					</div>

								<div class="grid-container-section">
	    							<div class="section-row-top-box">
	    								<div class="section-row-top">
	    									<div class="section-row-top-left">
												<div>USB-1</div>
												<div id="audio_usb1_div"></div>
											</div>
	    									<div class="section-row-top-right">
	    										<div class="red-circle" id="input_usb1_status"></div>
	    									</div>
	    									
	    								</div>
	    								<div class="section-row-bottom">
	    									<div class="section-row-bottom-single text-overflow" id="input_usb1_name"></div>
	    								</div>
	    							</div>
	    							<div class="section-row" id="box1"></div>
	    							<div class="section-row" id="box2"></div>
	    							<div class="section-row" id="box3"></div>
    							</div>
    							<div class="grid-container-section">
    							<div class="section-row-top-box">
    								<div class="section-row-top">
    									<div class="section-row-top-left">
											<div>USB-2</div>
											<div id="audio_usb2_div"></div>
										</div>
    									<div class="section-row-top-right">
    										<div class="red-circle" id="input_usb2_status"></div>
    									</div>
    								</div>
    								<div class="section-row-bottom">
    									<div class="section-row-bottom-single text-overflow" id="input_usb2_name"></div>
    								</div>
    							</div>
    							<div class="section-row" id="box4"></div>
    							<div class="section-row" id="box5"></div>
    							<div class="section-row" id="box6"></div>
    						</div>
							<div class="grid-container-section">
    							<div class="section-row-top-box">
    								<div class="section-row-top">
    									<div class="section-row-top-left">
											<div>USB-3</div>
											<div id="audio_usb3_div"></div>
										</div>
    									<div class="section-row-top-right">
    										<div class="red-circle" id="input_usb3_status"></div>
    									</div>
    									
    								</div>
    								<div class="section-row-bottom">
    									<div class="section-row-bottom-single text-overflow" id="input_usb3_name"></div>
    								</div>
    							</div>
    							<div class="section-row" id="box7"></div>
    							<div class="section-row" id="box8"></div>
    							<div class="section-row" id="box9"></div>
    						</div>

							<div class="grid-container-section">
    							<div class="section-row-top-box">
    								<div class="section-row-top">
    									<div class="section-row-top-left">Network Stream</div>
    									<div class="section-row-top-right">
    										<?php 
											if($url != "") { ?>
    											<div class="green-circle" id="input_avoip_status"></div>
    										<?php 
											} else { ?>	
												<div class="red-circle" id="input_avoip_status"></div>
											<?php 
											}?>	
    									</div>
    								</div>
    								<?php 
    									$inputAvoipText = $url == "" ? "Empty Settings" : "Settings";
    									$fontColor = $url == "" ? "" : "#69FFC3";
    									$inputAvoipWarningCirle = $url == "" ? "flex" : "none"; 
    								?>
   									<div class="section-row-bottom">
    									<div class="section-bottom-empty-setting-left pointer avoip_input_pop_css" style="color:<?php echo $fontColor;?>" id="input_avoip_value">
    										<?php echo $inputAvoipText;?>
    									</div>
    									<div style="display: <?php echo $inputAvoipWarningCirle;?>" class="section-bottom-empty-setting-right avoip_input_pop_css input_warning_circle">
    										<img src="images/warning_circle_line.svg">
    									</div>
    								</div>
									
									
    							</div>
    							<div class="section-row" id="box10"></div>
    							<div class="section-row" id="box11"></div>
    							<div></div>
    						</div></div>

							
						</div>
						<div>
							<!-- <div style="height:1px; width: 100%; background-color: #52555D"></div> -->
							<div style="display: grid; grid-template-columns: 1fr 1fr; padding-top: 15px;">
								<div class="divider-left">
									
										<div class="right-bottom-divider-heading">Video Information</div>
    									<div class="right-bottom-divider-container">
    										<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Video Format</div>
	    										<div class="overflow-hidden" id="left_input_video_info_format_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Resolution</div>
	    										<div class="overflow-hidden" id="left_input_video_info_resolution_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Aspect Ratio</div>
	    										<div class="overflow-hidden" id="left_input_video_info_aspectratio_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Frame Rate</div>
	    										<div class="overflow-hidden" id="left_input_video_info_framerate_value"></div>
	    									</div>
    									</div>
									
								</div>
								<div>
									<div class="divider-right">
										<div class="right-bottom-divider-heading">Audio Information</div>
	    								<div class="right-bottom-divider-container">
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Audio Format</div>
	    										<div class="overflow-hidden" id="left_input_audio_info_format_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Audio Channel</div>
	    										<div class="overflow-hidden" id="left_input_audio_info_channel_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Audio Rate</div>
	    										<div class="overflow-hidden" id="left_input_audio_info_rate_value"></div>
	    									</div>
    									</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div></div>
    				</div>
    			</div>
    			<div style="background-color: #272B34; display: grid; grid-template-rows: 0.5fr 9.5fr;">
    				<div style="border-bottom: 1px solid #52555D; display: flex; height:70px;">
    					<div class="video-details-text">Output Statistics</div>
    				</div>
    				<div class="grid-section-container-right">
						<div></div>
    					<div class="right-section-bottom-first">
						<!-- <div>
						<div class="overflow-hidden" style="display: grid; grid-template-rows: repeat(2, 1fr); row-gap: 10px;">
    						<div>
    							<div class="right-bottom-top-first">
    								<div class="preview-text">Preview</div>
    								<div>
		    							<label class="onoffswitch">
											<input type="checkbox" name="previewonoff" class="onoffswitch-checkbox" id="previewonoff" tabindex="0">
											<label class="onoffswitch-label" for="previewonoff"></label>
										</label>
    								</div>
    								<div class="on-text">On</div>
    							</div>
    							<div></div>
    						</div>
							</div>
							</div> -->
    						
    						<div>
    							<div class="right-bottom-divider">
    								<div class="divider-left">
    									<div class="right-bottom-divider-heading">Video Information</div>
    									<div class="right-bottom-divider-container">
    										<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Video Format</div>
	    										<div class="overflow-hidden" id="input_video_info_format_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Resolution</div>
	    										<div class="overflow-hidden" id="input_video_info_resolution_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Aspect Ratio</div>
	    										<div class="overflow-hidden" id="input_video_info_aspectratio_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Frame Rate</div>
	    										<div class="overflow-hidden" id="input_video_info_framerate_value"></div>
	    									</div>
    									</div>
    								</div>
    								<div class="divider-right">
    									<div class="right-bottom-divider-heading">Audio Information</div>
	    								<div class="right-bottom-divider-container">
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Audio Format</div>
	    										<div class="overflow-hidden" id="input_audio_info_format_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Audio Channel</div>
	    										<div class="overflow-hidden" id="input_audio_info_channel_value"></div>
	    									</div>
	    									<div class="flex-column-gap-10">
	    										<div class="text-color-868E96 width_40">Audio Rate</div>
	    										<div class="overflow-hidden" id="input_audio_info_rate_value"></div>
	    									</div>
    									</div>
    								</div>
    							</div>
    							<div class="stream-info-container" style="display:none;">
    								<div class="overflow: hidden;" style="font-weight:600">Stream Information</div>
    								<div class="flex-column-gap-10">
    									<div class="overflow: hidden;"><img src="images/copy.svg"></div>
    									<div class="text-color-868E96" style="font-size: 14px;">URL</div>
    									<div style="font-size: 14px; color:#FFFFFF;" class="overflow-hidden">
											<span id="input_streamurl_value"></span>
										</div>
    								</div>
    							</div>

    						</div>


							<div class="right-section-bottom-last">
								<div style="height:1px; width: 100%; background-color: #52555D; margin-top: 0px; margin-bottom: 10px;"></div>

    							<div class="video-container overflow-hidden" style="position:relative">
    								<img class="video-image" src="images/no-img.svg" id="previewcontent">
									<div style="position: absolute;display: block;text-align: center;width: 100%;top: 50%;left: 50%;transform: translate(-50%, -50%); font-size:16px; color:#868E96" id="txtdiv"></div>
    							</div>
    							<div class="play_stop_container">
    								<div class="video-play pointer" id="playresume" action="play">
    									<img class="play-preview-icon" src="images/play.svg">
    									<img class="stop-preview-icon" src="images/stop.svg" style="display:none;">
    								</div>
    								<div id="play_resume_text" class="fontsize14">Play</div>
    								
    							</div>
								<div></div>
    						</div>

    					</div>
						<div></div>
    				</div>
    				
    			</div>
    		</div>	
    		
    	</div>   	
		
<div class="via-modal-main-container" id="via-modal-inputpopup" click-outside="false" style="display:none; overflow:hidden">
		
	
  <div class="via-modal">
    <div id="overlay">       
		<div>
			<img src="images/bar-circle.gif" width="56px" height="56px">
		</div>
		<div><span id="stream_url_status"></span></div>
    </div>
	<div class="via-modal-header">
      <div>AVoIP INPUT Settings</div>
      <div> <span class="modal-close-icon" id="closebtn"> <img src="images/x_button.svg" width="20px" height="20px"> <img class="display-none" src="images/x_button-hover.svg" width="20px" height="20px"> </span> </div>
    </div>
	
    <div class="modal-content-data">
      <div class="modal-content-text font-info-text">
        <div style="margin:0px">
          <div class="row-gap">
            <label class="fontsize14" style="width:80px; height:19px;">Stream URL</label>
            <div style="display: flex;">
              <div style="width:100%" class="txt-opacity">
                <input type="text" class="popup-txtbox" id="streamurl" value="<?php echo $url;?>" style="padding:5px 0px 5px 8px; font-size:14px; border:1px solid #868E96">
              </div>
            </div>
            <div style="display: flex;">
              <div class="txt-opacity fontsize12" style="width:65%; font-style:italic; text-align: left;">Supported Formats: HTTP | RTP | RTSP | UDP </div>
			  <div style="width:15%; height:20px"><span id="loadingImg" style="text-align:center; color:#FF0000"><!--<img src="images/bar-circle.gif" width="20px" height="20px">--></span></div>
              <div style="width:20%; text-align:right; color:#69FFC3; cursor:pointer;" class="fontsize14"><span id="testurl">Test URL</span></div>
            </div>
          </div>
        </div>
        <div class="left row-gap fontsize14" id="stream_info" style="padding-top:35px;width: 100%;text-align: left;">
          <label class="fontsize14" style=" color:#B2B9BF">Stream Information</label>
          <div style="display: grid; grid-template-columns: 3.5fr 6.5fr; padding-top:12px;">
		  	<div>
		  		<div style="display: grid; grid-template-columns: 1fr 1fr;">
					<span style="color:#868E96">Resolution</span>
					<span id="input_resolution_div"><?php echo $resolution;?></span>
				</div>

				<div style="display: grid; grid-template-columns: 1fr 1fr; padding-top:12px;">
					<span style="color:#868E96">Frame Rate</span>
					<span id="input_frame_rate_div"><?php echo $frame_rate;?></span>
				</div>

			
		  		<div style="display: grid; grid-template-columns: 1fr 1fr; padding-top:12px;">
					<span style="color:#868E96">Audio Rate</span>
					<span id="input_audio_rate_div"><?php echo $audio_rate;?></span>
				</div>	
		  	</div>
		  
          <div>
		  	<div style="display: grid; grid-template-columns: 2.5fr 7.5fr;">
				<span style="color:#868E96">Aspect Ratio</span>
				<span id="input_aspect_ratio_div"><?php echo $aspectRatio;?></span>
			</div>
			<div style="display: grid; grid-template-columns: 2.5fr 7.5fr;  padding-top:12px;">
				<span style="color:#868E96">Audio channel</span>
				<span id="input_audio_channel_div"><?php echo $audio_channel;?></span>
			</div>
          </div>
          
        
        </div>      </div>
    </div>
    <div class="via-modal-footer">
	  <div style="height:32px; display:flex; justify-content:center;">
	  	<div style="background-color:#F74D6B; height:24px; width:416px; padding-left:8px;border-radius:4px; align-items:center; justify-content:center; font-size:14px;color:#FFFFFF; display:none" id="loadingError"></div>
	  </div>
      <div class="modal-content-button grid-gap-16" style="display: flex; justify-content: center;">
	  		
		 <div>
			<button type="button" class="btn btn-outline-secondary btn-width btn-height pointer" style="border:1px solid #868E96; color:#B2B9BF; font-size:16px;background-color:transparent;border-radius:4px;" id="input-popup-cancelbtn">Cancel</button>
		  </div>
		  <div>
			<button type="button" class="btn btn-outline-secondary btn-width btn-height pointer" style="background-color:#272B34;font-size:16px; border:1px solid #272B34; color:#FFFFFF;border-radius:4px;" id="input-popup-savebtn">Save</button>
		  </div><!--<span id="loadingImg" style="text-align:center"></span>-->
      </div>
	  
    </div>
  </div>
</div>

<div class="via-modal-main-container" id="via-modal-outputpopup" click-outside="false" style="display:none;">
  <div class="via-modal-output-css">
    <div class="via-modal-header-output">
      <div class="fontsize20">AVoIP OUTPUT Settings</div>
      <div> <span class="modal-close-icon" id="closebtn_output"> <img src="images/x_button.svg"> </span> </div>
    </div>
    <div class="modal-content-data-output fontsize14">
      <div class="modal-content-text flex-center font-info-text">
        <div style="display: grid;grid-template-columns: 6.25fr 3.75fr;gap: 5px;" class="row">
          <div class="left row-gap" style="padding-left:32px;text-align:left;">
            <label class="fontsize16">Video</label>
            <div class="inp-group" style="width:257px; height:30px">
              <div class="txt-opacity">Resolution</div>
              <div class="display-block">
                <select class="select-input-output-popup select-input-width" style="width:160px; height:30px;">
                  <option>3180x2160</option>
                </select>
              </div>
            </div>
            <div class="inp-group" style="width:182px; height:30px">
              <div class="txt-opacity">Frame Rate</div>
              <div class="display-block">
                <select class="select-input-output-popup select-input-width-small" style="width:85px; height:30px;">
                  <option>30</option>
                </select>
              </div>
            </div>
            <div class="inp-group" style="width:257px; height:30px">
              <div class="txt-opacity">Video Format</div>
              <div class="display-block">
                <select class="select-input-output-popup select-input-width" style="width:160px; height:30px;">
                  <option>H.264</option>
                </select>
              </div>
            </div>
            <div class="inp-group" style="width:257px; height:30px">
              <div class="txt-opacity">Protocol</div>
              <div class="display-block">
                <select class="select-input-output-popup select-input-width-mid" style="width:120px; height:30px;">
                  <option>RTSP</option>
                </select>
              </div>
            </div>
            <div class="inp-group" style="width:257px; height:30px">
              <div class="txt-opacity">IP Casting</div>
              <div class="display-block" style="display: grid;grid-template-columns: 4fr 3.3fr 2.7fr">
                <select class="select-input-output-popup" style="width:120px;height:30px;">
                  <option>Multicast</option>
                </select>
                <div style="display:flex;gap:5px;align-items: center;">
                  <div style="width: 55px; height:19px; padding-left:16px;">Prefix</div>
                  <input type="text" class="popup-txtbox-output" style="width:40px; height:30px;">
                </div>
                <div style="display:flex;gap:5px;align-items: center;">
                  <div style="width:40px; padding-left:16px;">TTL</div>
                  <input type="text" class="popup-txtbox-output" style="width:40px; height:30px;" >
                </div>
              </div>
            </div>
          </div>
          <div class="right row-gap" style="text-align:left;">
            <label class="fontsize16">Audio</label>
            <div class="inp-group">
              <div  class="txt-opacity">Channel</div>
              <div >
                <select class="select-input-output-popup select-input-width-mid" style="width:120px; height:30px;">
                  <option>Stereo</option>
                </select>
              </div>
            </div>
            <div class="inp-group">
              <div class="txt-opacity">Audio Rate</div>
              <div >
                <select class="select-input-output-popup select-input-width-mid" style="width:120px; height: 30px;">
                  <option>48000</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
 
		<div class="via-modal-footer">
		  <div class="modal-content-button grid-gap-16" style="display: flex;">
			<div>
			  <button type="button" class="btn btn-outline-secondary btn-width btn-height pointer" style="border:1px solid #868E96; color:#B2B9BF; font-size:16px;background-color:transparent;border-radius:4px;" id="output-popup-cancelbtn">Cancel</button>
			</div>
			<div>
			  <button type="button" class="btn btn-outline-secondary btn-width btn-height pointer" style="background-color:#272B34; border:1px solid #272B34; color:#FFFFFF;padding-left:16px;border-radius:4px;" id="closebtnoutput">Save</button>
			</div>
			
		  </div>
		</div> 
    
  </div>
</div>		
		
<div class="via-modal-main-container" id="via-modal-settings" click-outside="false" style="display:none;">
  <div class="via-modal-output-css">
    <div class="via-modal-header-output">
      <div class="fontsize20">Capture Card Settings</div>
      <div> <span class="modal-close-icon" id="closebtn_settings"> <img src="images/x_button.svg"> </span> </div>
    </div>
    <div class="modal-content-data-output fontsize14">
      <div class="modal-content-text font-info-text">
        <div style="display: grid;gap: 5px;" class="row">
          <div class="left row-gap" style="padding-left:16px;text-align:left;">
            <label class="fontsize16">Select Device</label>
            <div class="inp-group" style="width:257px; height:30px">              
              <div class="display-block">
                <select class="select-input-output-popup select-input-width" style="width:230px; height:30px;" name="devicebox" id="devicebox">
						<option value="">Select</option>
					<?php foreach($input_device_array as $key=>$val){
						if(strtolower($key)!='avoip'){?>
						  <option value="<?php echo $key."#".$val;?>"><?php echo $val;?></option>
				  <?php }
				  }?>			  
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="via-modal-footer" style="padding:39px 0px 0px 48px">
      <div class="modal-content-button grid-gap-16" style="display: flex;">
        <div>
          <button type="button" class="btn btn-outline-secondary pointer" style="border:1px solid #868E96; color:#B2B9BF; font-size:16px;background-color:transparent;border-radius:4px; width:100px; height:40px;" id="settings-popup-cancelbtn">Cancel</button>
        </div>
        <div>
          <button type="button" class="btn btn-outline-secondary pointer" style="background-color:#272B34; border:1px solid #272B34; color:#FFFFFF;padding-left:16px;border-radius:4px; width:100px; height:40px" id="settings-popup-savebtn">Save</button>
        </div>
      </div>
    </div>
  </div>
</div>			
		
		
    </body>	
</html> 
<style>
#overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    flex-direction: column;
    color: #868E96;
    background: rgba(0, 0, 0, 0.6);
    display: none; /* Hidden by default */
    align-items: center;
    justify-content: center;
    z-index: 1000;
    font-size: 14px;
}


</style> 

<script type="text/javascript"> 
$(document).ready(function() {
	var stopPreviewTimer = "";
	var timeinterval = 1000;
	let inputSavedSettings = '<?php echo $jsonInputSettings;?>';
	inputSavedSettings = JSON.parse(inputSavedSettings);
	let data = `<?php echo $json;?>`;
	avSwichterObj.jsonFile = JSON.parse(data);
	let allPreviewAjaxReqests = [];
	function manageJsonValuesOnHtml() {
		if(avSwichterObj.jsonFile.inputs.boxid) {
			// $("#ouput_avoip_value").removeClass("inactive_class");
			$(".stream-info-container").hide();
			if( avSwichterObj.jsonFile.inputs.boxid == "box3" || avSwichterObj.jsonFile.inputs.boxid == "box6" || avSwichterObj.jsonFile.inputs.boxid == "box9") {
				$("#ouput_avoip_value").addClass("inactive_class");
				$(".stream-info-container").css("display", "flex");
			}
			$('#left_input_video_info_format_value').html(avSwichterObj.jsonFile.inputs.input_video_data.format);
			$('#left_input_video_info_resolution_value').html(avSwichterObj.jsonFile.inputs.input_video_data.resolution);
			$('#left_input_video_info_aspectratio_value').html(avSwichterObj.jsonFile.inputs.input_video_data.aspectRatio);
			$('#left_input_video_info_framerate_value').html(avSwichterObj.jsonFile.inputs.input_video_data.frameRate);

			$('#input_video_info_format_value').html(avSwichterObj.jsonFile.inputs.output_video_data.format);
			$('#input_video_info_resolution_value').html(avSwichterObj.jsonFile.inputs.output_video_data.resolution);
			$('#input_video_info_aspectratio_value').html(avSwichterObj.jsonFile.inputs.output_video_data.aspectRatio);
			$('#input_video_info_framerate_value').html(avSwichterObj.jsonFile.inputs.output_video_data.frameRate);
			//added by ashu for showing audio input info
			$('#left_input_audio_info_format_value').html(avSwichterObj.jsonFile.inputs.input_audio_data.format);
			$('#left_input_audio_info_channel_value').html(avSwichterObj.jsonFile.inputs.input_audio_data.channels);
			$('#left_input_audio_info_rate_value').html(avSwichterObj.jsonFile.inputs.input_audio_data.sampleRate);
			//added by ashu for showing audio output info
			$('#input_audio_info_format_value').html(avSwichterObj.jsonFile.inputs.output_audio_data.format);
			$('#input_audio_info_channel_value').html(avSwichterObj.jsonFile.inputs.output_audio_data.channels);
			$('#input_audio_info_rate_value').html(avSwichterObj.jsonFile.inputs.output_audio_data.sampleRate);
			avSwichterObj.getOutputSettingsUrl();
			setTimeout(() => {	
				if(avSwichterObj.jsonFile.inputs.boxid == "box3" || avSwichterObj.jsonFile.inputs.boxid == "box6" || avSwichterObj.jsonFile.inputs.boxid == "box9") {
					$(".stream-info-container").css("display", "flex");
					$("#input_streamurl_value").text(avSwichterObj.outputUrl);
				} 
				$("#" + avSwichterObj.jsonFile.inputs.boxid).addClass("matrix-play-btn pointer");	
			}, 1000);
		} else {
			$('#input_video_info_format_value').html('...')
			$('#input_video_info_resolution_value').html('...')
			$('#input_video_info_aspectratio_value').html('...')
			$('#input_video_info_framerate_value').html('...')

			$('#input_audio_info_format_value').html('...')
			$('#input_audio_info_channel_value').html('...')
			$('#input_audio_info_rate_value').html('...')

			$('#left_input_video_info_format_value').html('...')
			$('#left_input_video_info_resolution_value').html('...')
			$('#left_input_video_info_aspectratio_value').html('...')
			$('#left_input_video_info_framerate_value').html('...')

			$('#left_input_audio_info_format_value').html('...')
			$('#left_input_audio_info_channel_value').html('...')
			$('#left_input_audio_info_rate_value').html('...')
		}
		
		$(document).on("mouseover", ".boxactive", function () {
			$(this).addClass("matrix-play-btn-hover");
		});	

		$(document).on("mouseout", ".boxactive", function () {
			$(this).removeClass("matrix-play-btn-hover");
		});	
		

		//maintaining last state of preview button
		if(avSwichterObj.jsonFile.inputs.previewstatus == 1) {
			if(avSwichterObj.jsonFile.inputs.inputaction == "play" && avSwichterObj.jsonFile.inputs.boxid) {
				setTimeout(() => {
					$("#playresume").trigger("click");	
				}, 1000);	
			} else if (avSwichterObj.jsonFile.inputs.inputaction == "stop") {
				setTimeout(() => {
					$('#txtdiv').html('Preview not available');	
				}, 1000);
			}
			$('#previewonoff').prop("checked", true);
			//Change play button image active
			//$('#playresume').attr('src','images/play.svg');
			//$('#play_resume_text').text("Play");
			updatePreviewPlayPauseIcon('play');
			
		} else {
			$('#txtdiv').html('Turn the preview toggle ON to see a picture');
		}
	}

	$(document).on("click", ".mute_unmute",  (event) => {
		let audioUsbName = event.target.attributes["data-id"].value;
		avSwichterObj.currentInputId = event.target.id;
		avSwichterObj.currentInputMute = JSON.parse(event.target.attributes["data-mute-status"].value);
		// console.log(avSwichterObj.currentInputMute);
		if(avSwichterObj.currentInputMute) {
			$("#" + avSwichterObj.currentInputId).attr("data-mute-status", !avSwichterObj.currentInputMute);
			$("#" + avSwichterObj.currentInputId).attr('src','images/mute.svg');
		} else {
			$("#" + avSwichterObj.currentInputId).attr("data-mute-status", !avSwichterObj.currentInputMute);
			$("#" + avSwichterObj.currentInputId).attr('src','images/speaker.svg');
		}
		
		avSwichterObj.inputSettingsSave["settings"][avSwichterObj.currentInputId] = !avSwichterObj.currentInputMute;
		console.log(avSwichterObj.inputSettingsSave);
		avSwichterObj.saveInputSettings();

		let sendData = {}
		sendData["command"] = "setSettings";
		sendData["settingsType"] = {};
		sendData["settingsType"]["inputs"] = {}
		
		sendData["settingsType"]["inputs"][audioUsbName] = {};
		sendData["settingsType"]["inputs"][audioUsbName]["audioEnabled"] =  !avSwichterObj.currentInputMute;
		console.log(sendData);
		socket.send(JSON.stringify(sendData));
	})

	manageJsonValuesOnHtml();

	// $("#input_streamurl_value").html("<?php echo $url;?>");
	var intervalSetting = null;
	var intervalSetting1 = null;
	$(document).on('click', '#enable_audio', (event) => {
		avSwichterObj.outputAudio = event.target.checked;
		if(avSwichterObj.outputAudio) {
			$("#audio_data").removeClass("inactive_class");
		} else {
			$("#audio_data").addClass("inactive_class");
		}
	})

	$(document).on('change', '#output_protocol', (event) => {
		let selectedValue = event.target.value;
		avSwichterObj.outputProtcol = selectedValue;
		if(selectedValue == "RTMP") {
			$("#location_rtmp").css("display", "grid");
			$("#host_port").hide();
			$("#protocol_location").removeClass("error_textbox");
			$("#protocol_key").removeClass("error_textbox");
			//added by ashu for showing unicast/multicast block
			$("#castingdiv").hide();
			
		} else if(selectedValue == "UDP" || selectedValue == "RTP") {
			$("#location_rtmp").hide();
			$("#host_port").css("display", "grid");
			$("#protocol_port").removeClass("error_textbox");
			$("#protocol_host").removeClass("error_textbox");
			
			
			// if($('#protocol_host').val()=="" && $('#casting_dd').val()=='unicast'){
			// 	$("#protocol_host").attr("placeholder", "Enter unicast IP address");
			// }
			// if($('#protocol_host').val()=="" && $('#casting_dd').val()=='multicast'){
			// 	$("#protocol_host").attr("placeholder", "Enter multicast IP address");
			// }
			
			// //added by ashu for showing unicast/multicast block
			// let casting_host=$('#protocol_host').val().split('.');
			// //alert(casting_host[0]);
			// if(casting_host[0]<224){
			// 	//unicast
			// 	$('#casting_dd').val('unicast');					
			// }else{
			// 	//multicast
			// 	$('#casting_dd').val('multicast');	
			// }
			
			$("#castingdiv").show();
		}
	})
	$(document).on('change', '#casting_mode', (event) => {
		let selectedValue = event.target.value;
		$("#protocol_host").val(avSwichterObj.latestOutputSettings["unicast"]["host"]);
		$("#protocol_port").val(avSwichterObj.latestOutputSettings["unicast"]["port"]);
		let hostPlaceHolder = "192.168.1.10";
		if(selectedValue == 'Multicast') {
			hostPlaceHolder = "224.0.0.0 - 239.255.255.255";
			$("#protocol_host").val(avSwichterObj.latestOutputSettings["multicast"]["host"]);
			$("#protocol_port").val(avSwichterObj.latestOutputSettings["multicast"]["port"]);
		}
		$("#protocol_host").attr("placeholder", hostPlaceHolder);
	});
					
    //var content = document.getElementById('content');
    socket = new WebSocket('wss://<?php echo $ipadd;?>:8080?source=clientConnection');
    socket.onopen = function () {	
        socket.send('{"command": "statusUpdate"}');
    };

	$(document).on('click', '.refreshbtn',function() {
		//removing swap_last_state
		//localStorage.removeItem("swap_last_state");
		$(".refresh-img").addClass("loading");
		socket.send('{"command": "refresh"}');
		avSwichterObj.getJsonFileData();	
		setTimeout(() => {
			socket.send('{"command": "statusUpdate"}');
			$(".refresh-img").removeClass("loading");
			$('div').removeClass('matrix-play-btn');
			manageJsonValuesOnHtml();
		}, 3000)
		
	});

	function getTestPlayUrlJson(commandName) {
		let testurl = $('#streamurl').val();
		let testurl_length = $('#streamurl').val().length;
		let sendData = {};
		sendData["command"] = commandName;
		sendData["length"] = testurl_length;
		sendData["input"] = testurl; 
		console.log(sendData);
		return JSON.stringify(sendData);
	}

	$('#streamurl').on('input', function() {
    	$("#loadingError").hide();
		$("#loadingError").text("");
	});


	$("#testurl").on('click', () => {		
		// Get the value from the input field with ID 'streamurl'
		let testurl = $('#streamurl').val();
		let result = "";
		
		// Check if the URL contains "http", "https", or "youtube" and call the appropriate validation function
		if (testurl.includes("http") || testurl.includes("https") || testurl.includes("youtube")) {
			result = validateYouTubeUrl(testurl);  // Assuming this function returns an object with 'isValid' and 'reason'
		} else {
			result = validateUrl(testurl);  // Assuming this function also returns an object with 'isValid' and 'reason'
		}

		// If the result is not valid, show the error message and stop further actions
		if (!result.isValid) {
			$("#loadingError").css("display", "flex");
			$("#loadingError").text(result.reason);  // Display the reason for the invalid URL
			console.log(result);  // Log the result object for debugging
			return false;  // Prevent further execution if the URL is invalid
		}
    
		// If the URL is valid, prepare to send the test URL and show the loading overlay
		avSwichterObj.saveTestUrlAction = "test";
		$('#loadingError').hide();  // Hide the loading error message
		document.getElementById('overlay').style.display = 'flex';  // Show the overlay with the loading message
		$("#stream_url_status").html("Analyzing URL");  // Update the status to "Analyzing URL"
		
		// Send the test URL data via socket (assuming 'getTestPlayUrlJson' is defined)
		let sendDataJson = getTestPlayUrlJson("testurl");
		socket.send(sendDataJson);

		// Set up a timeout for 30 seconds to handle network connection issues
		avSwichterObj.testUrlNoResponseTimer = setTimeout(() => { 
			document.getElementById('overlay').style.display = 'none';  // Hide the overlay after timeout
			$("#loadingError").css("display", "flex");  // Show the error message
			$("#loadingError").text("Network connection error");  // Display timeout message
			console.log("Test URL timeout");  // Log the timeout for debugging
		}, 30 * 1000);

		// Optionally, you can clear the timeout if the request succeeds
		socket.on('response', (data) => {
			// Assuming 'response' event is received with the test results
			clearTimeout(avSwichterObj.testUrlNoResponseTimer);  // Clear the timeout if response is received
			// Handle the response here, such as updating the UI with the result
		});
	});

	//playurl
	//$(document).on('click', '.boxactive',function() {
	$(document).on('click', '.boxactive:not(.matrix-play-btn)',function() {
		//added below code for restricting avoip matrix in case of blank url
		if(avSwichterObj.jsonFile.inputs.url == "" && $(this).attr('id') == 'box10') {				
			return false;
		}
		$("#ouput_avoip_value").removeClass("inactive_class");
		if($(this).attr('id') == "box3" || $(this).attr('id') == "box6" || $(this).attr('id') == "box9") {
			$("#ouput_avoip_value").addClass("inactive_class");
		}

		//cancel all preview requests
		if($('#playresume').attr('action') == 'stop') {
			stopPreview();
		}

		$('#input_video_info_format_value').html('...')
		$('#input_video_info_resolution_value').html('...')
		$('#input_video_info_aspectratio_value').html('...')
		$('#input_video_info_framerate_value').html('...')

		$('#input_audio_info_format_value').html('...')
		$('#input_audio_info_channel_value').html('...')
		$('#input_audio_info_rate_value').html('...')

		$('#left_input_video_info_format_value').html('...')
		$('#left_input_video_info_resolution_value').html('...')
		$('#left_input_video_info_aspectratio_value').html('...')
		$('#left_input_video_info_framerate_value').html('...')

		$('#left_input_audio_info_format_value').html('...')
		$('#left_input_audio_info_channel_value').html('...')
		$('#left_input_audio_info_rate_value').html('...')
		// $("#left_input_video_info_format_value").html("");
		// $("#left_input_video_info_format_value").addClass("loader");
		
		//$('#previewcontent').attr({'src':'images/no-img.svg'});
		$('#previewcontent').attr({'src':'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTkyIiBoZWlnaHQ9IjMzMiIgdmlld0JveD0iMCAwIDU5MiAzMzIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI1OTIiIGhlaWdodD0iMzMyIiBmaWxsPSIjMzIzNzQzIi8+Cjwvc3ZnPgo='});
		// if(avSwichterObj.jsonFile.inputs.boxid == "") {
		// 	$('#txtdiv').html('Preview not available');	
		// }
		// $('#txtdiv').html('');
		//clear interval
		clearInterval(intervalSetting1);
		// localStorage.setItem("matrix_last_state", $(this).attr('id'));
		avSwichterObj.currentPlayingUrlBoxId = $(this).attr('id');
		if(avSwichterObj.currentPlayingUrlBoxId == "box3" || avSwichterObj.currentPlayingUrlBoxId == "box6"
			|| avSwichterObj.currentPlayingUrlBoxId == "box9"
		) {
			avSwichterObj.getOutputSettingsUrl();
			setTimeout(() => {	
				$(".stream-info-container").css("display", "flex");
				$("#input_streamurl_value").text(avSwichterObj.outputUrl);
			}, 1000);
		} else {
			$(".stream-info-container").hide()
			$("#input_streamurl_value").text("");
		}
		// $("#" + boxClickedId).removeClass('boxactive');	
		console.log("Start playing");
		let sendData = {};
		sendData["command"] = "playurl";
		sendData["input"] = avSwichterObj.boxCommandArray[avSwichterObj.currentPlayingUrlBoxId];
		sendData["outputs"] = "hdmi";
		if($(this).hasClass("matrix-play-btn") == false) {
			avSwichterObj.requestSendToSwitcher = "playurl";
			socket.send(JSON.stringify(sendData));
		}
		$('div').removeClass('matrix-play-btn');
		$(this).addClass('matrix-play-btn');
		avSwichterObj.boxCommandName = avSwichterObj.boxCommandArray[avSwichterObj.currentPlayingUrlBoxId];
		avSwichterObj.updatePlayingUrlBoxId();
		if(avSwichterObj.jsonFile.inputs.previewstatus == 1) {
			// if(avSwichterObj.jsonFile.inputs.inputaction = "play") {
			// 	setTimeout(() => {
			// 		avSwichterObj.updatePlayPauseStatus();
			// 	}, 1000)
			// }
			//stopping play on resume
			if($('#playresume').attr('action')=='play'){
				return false;
			}
			$('#txtdiv').html('Fetching information. Please wait...');
			$('#previewcontent').attr({'src':'images/no-img.svg'});
			//alert($('#previewcontent').attr('src'))

			//$('#playresume').attr('src','images/stop.svg');
			//$('#play_resume_text').text("Stop");
			updatePreviewPlayPauseIcon('stop');
			clearInterval(intervalSetting1);		
			intervalSetting1 = setInterval(function () {
				avSwichterObj.getPreview();
			}, timeinterval);			
			
		}
		
	});
	
	//stopurl
	$(document).on('click', '.matrix-play-btn',function() { 
		let boxClickedId = $(this).attr('id'); 
		$(this).removeClass('matrix-play-btn');		
		$("#" + boxClickedId).addClass('boxactive');
		$(".boxactive").off('mouseover');
		$("#" + boxClickedId).removeClass('matrix-play-btn-hover');
		// $("#ouput_avoip_value").removeClass("inactive_class");
		if($(this).attr('id') == "box3" || $(this).attr('id') == "box6" || $(this).attr('id') == "box9") {
			$("#ouput_avoip_value").removeClass("inactive_class");
		}

		avSwichterObj.currentPlayingUrlBoxId = "";
		avSwichterObj.jsonFile.inputs.boxid = "";
		avSwichterObj.updatePlayingUrlBoxId();
		// if(avSwichterObj.jsonFile.inputs.boxid == 0) {
		// 	$('#txtdiv').html('Preview not available');
		// }
		$(".stream-info-container").hide();
		$("#input_streamurl_value").text("");
		
		//localStorage.removeItem("preview_last_state");
		//make previeew button off
		clearInterval(intervalSetting);
		clearInterval(intervalSetting1);
		// if(avSwichterObj.jsonFile.inputs.previewstatus == 1) {
		// 	$('#playresume').attr('src','images/play.svg');
		// }
		//$('#previewstatus').html('Off');		
		//$('#previewonoff').prop("checked", false);	
		
		$('#previewcontent').attr({'src':'images/no-img.svg'});	
		
		let sendData = {};
		sendData["command"] = "stopurl";
		sendData["input"] = avSwichterObj.boxCommandArray[boxClickedId];
		sendData["outputs"] = "hdmi";

		socket.send(JSON.stringify(sendData));
		stopPreview(1000);
		$('#input_video_info_format_value').html('...')
		$('#input_video_info_resolution_value').html('...')
		$('#input_video_info_aspectratio_value').html('...')
		$('#input_video_info_framerate_value').html('...')

		$('#input_audio_info_format_value').html('...')
		$('#input_audio_info_channel_value').html('...')
		$('#input_audio_info_rate_value').html('...')

		$('#left_input_video_info_format_value').html('...')
		$('#left_input_video_info_resolution_value').html('...')
		$('#left_input_video_info_aspectratio_value').html('...')
		$('#left_input_video_info_framerate_value').html('...')

		$('#left_input_audio_info_format_value').html('...')
		$('#left_input_audio_info_channel_value').html('...')
		$('#left_input_audio_info_rate_value').html('...')

	
	})

	function makeCellActiveDeactive(boxId, action) {
		if(action == "show") {
			$("#" + boxId).addClass('boxactive pointer');
		} else if(action == "hide") {
			$("#" + boxId).removeClass('boxactive pointer');
		}
	}

	function fillValueOfInputAndOutput(dataArray, action) {
		if(action == "show") {
			$("#" + dataArray["statusField"]).attr('class', 'green-circle');
		} else if(action == "hide") {
			$("#" + dataArray["statusField"]).attr('class', 'red-circle');
		}
		if(dataArray["nameValue"] != undefined) {
			$("#" + dataArray["nameField"]).html(dataArray["nameValue"]);
			$("#" + dataArray["nameField"]).attr({'title': dataArray["nameValue"]});	
		}
	}

   	socket.onmessage = function (message) {
		let getData = JSON.parse(message.data);	
		let responseStatus = getData.status;
		console.log(responseStatus);
		if(responseStatus == "Error") {
			return false;
		}
		let jsonData = "";
		if('status' in getData) {
			jsonData = JSON.parse(getData.data);	
		} else {
			jsonData = JSON.parse(message.data);
		}
		let youTubeUrl = "<?php echo $url?>";
		console.log(jsonData);
		if(jsonData.command == "playurldata") {
			console.log(avSwichterObj.requestSendToSwitcher);
			if(avSwichterObj.requestSendToSwitcher == "playurl") {
				avSwichterObj.requestSendToSwitcher = "";
				avSwichterObj.inputVideoData = jsonData['info']['streamInfo']['videoInfo']['input'];
				$('#left_input_video_info_format_value').html(avSwichterObj.inputVideoData.format != undefined ? avSwichterObj.inputVideoData.format : "");
				$('#left_input_video_info_resolution_value').html(avSwichterObj.inputVideoData.resolution != undefined ? avSwichterObj.inputVideoData.resolution : "");
				$('#left_input_video_info_aspectratio_value').html(avSwichterObj.inputVideoData.aspectRatio != undefined ? avSwichterObj.inputVideoData.aspectRatio : "");
				$('#left_input_video_info_framerate_value').html(avSwichterObj.inputVideoData.frameRate != undefined ? avSwichterObj.inputVideoData.frameRate : "");

				avSwichterObj.outputVideoData = jsonData['info']['streamInfo']['videoInfo']['output'];
				$('#input_video_info_format_value').html(avSwichterObj.outputVideoData.format != undefined ? avSwichterObj.outputVideoData.format : "");
				$('#input_video_info_resolution_value').html(avSwichterObj.outputVideoData.resolution != undefined ? avSwichterObj.outputVideoData.resolution : "");
				$('#input_video_info_aspectratio_value').html(avSwichterObj.outputVideoData.aspectRatio != undefined ? avSwichterObj.outputVideoData.aspectRatio : "");
				$('#input_video_info_framerate_value').html(avSwichterObj.outputVideoData.frameRate != undefined ? avSwichterObj.outputVideoData.frameRate : "");

				if(jQuery.isEmptyObject(jsonData['info']['streamInfo']['audioInfo']) == false) {
					if(jQuery.isEmptyObject(jsonData['info']['streamInfo']['audioInfo']['input']) == false) {
					avSwichterObj.inputAudioData = jsonData['info']['streamInfo']['audioInfo']['input'];
					$('#left_input_audio_info_format_value').html(avSwichterObj.inputAudioData.format != undefined ? avSwichterObj.inputAudioData.format : "");
					$('#left_input_audio_info_channel_value').html(avSwichterObj.inputAudioData.channels != undefined ? avSwichterObj.inputAudioData.channels : "");
					$('#left_input_audio_info_rate_value').html(avSwichterObj.inputAudioData.sampleRate != undefined ? avSwichterObj.inputAudioData.sampleRate : "");
					}

					if(jQuery.isEmptyObject(jsonData['info']['streamInfo']['audioInfo']['output']) == false) {
						avSwichterObj.outputAudioData = jsonData['info']['streamInfo']['audioInfo']['output'];
						$('#input_audio_info_format_value').html(avSwichterObj.outputAudioData.format != undefined ? avSwichterObj.outputAudioData.format : "");
						$('#input_audio_info_channel_value').html(avSwichterObj.outputAudioData.channels != undefined ? avSwichterObj.outputAudioData.channels : "");
						$('#input_audio_info_rate_value').html(avSwichterObj.outputAudioData.sampleRate != undefined ? avSwichterObj.outputAudioData.sampleRate : "");	
					}
				}
				avSwichterObj.updateInputOutputAV();
			}
		} else if(jsonData.command == "testurlstatus") {
			$('#loadingImg').html("");
			document.getElementById('overlay').style.display = 'none';
			if(jsonData['info']['discoverer']['uriInfo'].status == 'VALID') {
				$('#loadingImg').html("");
				$('#loadingError').hide();	
				avSwichterObj.discovererVideoInput = jsonData['info']['discoverer']['streamInfo']['videoInfo']['input'];
				$('#input-popup-savebtn').prop('disabled',false);			
				$('#input_resolution_div').html(avSwichterObj.discovererVideoInput.resolution);
				$('#input_aspect_ratio_div').html(avSwichterObj.discovererVideoInput.aspectRatio);
				$('#input_frame_rate_div').html(avSwichterObj.discovererVideoInput.fps);
				$('#input_audio_channel_div').html(avSwichterObj.discovererVideoInput.channels);
				$('#input_audio_rate_div').html(avSwichterObj.discovererVideoInput.bitrate);
				if(avSwichterObj.requestSendToSwitcher == "testurl") {
					if (avSwichterObj.saveTestUrlAction == "save") { 
						clearTimeout(avSwichterObj.saveUrlNoResponseTimer);
						avSwichterObj.requestSendToSwitcher = "";
						$("#stream_url_status").html("Saving URL");
						let sendSaveUrlDataJson = getTestPlayUrlJson("saveurl");
						socket.send(sendSaveUrlDataJson);
						document.getElementById('overlay').style.display = 'flex';		
						avSwichterObj.saveUrl();
					}
				}

			} else {
				$('#input_resolution_div').html("");
				$('#input_aspect_ratio_div').html("");
				$('#input_frame_rate_div').html("");
				$('#input_audio_channel_div').html("");
				$('#input_audio_rate_div').html("");
				$('#loadingError').css("display","flex");	
				if(jsonData['info']['discoverer']['uriInfo'].status) {
					$('#loadingError').html(jsonData['info']['discoverer']['uriInfo'].status);
				} else {
					$('#loadingError').html("Unknown Error");
				}
			}

			//clear test url timeout
			if(avSwichterObj.requestSendToSwitcher == "" && avSwichterObj.saveTestUrlAction == "test"){
				console.log("Test URL timout cleared");
				clearTimeout(avSwichterObj.testUrlNoResponseTimer);
			}

		} else if (jsonData.command == "Socket Connected") { 
			console.log("Connected");
		} else if (jsonData.command == "Socket Close" || jsonData.command == "Socket Error") {
			console.log("Close Error");
		} else { 
			if(responseStatus = "Success") {
				let input_usb1_status = jsonData.inputs['usb-1'].status;
				let input_usb1_name = jsonData.inputs['usb-1'].name;
				
				let contentArrayUsb1 = {};
				contentArrayUsb1["statusField"] = "input_usb1_status";
				contentArrayUsb1["nameField"] = "input_usb1_name";
				contentArrayUsb1["nameValue"] = input_usb1_name;
				
				let input_usb2_status = jsonData.inputs['usb-2'].status;
				let input_usb2_name = jsonData.inputs['usb-2'].name;
				let contentArrayUsb2 = {};
				contentArrayUsb2["statusField"] = "input_usb2_status";
				contentArrayUsb2["nameField"] = "input_usb2_name";
				contentArrayUsb2["nameValue"] = input_usb2_name;
				
				let input_usb3_status = jsonData.inputs['usb-3'].status;
				let input_usb3_name = jsonData.inputs['usb-3'].name;
				let contentArrayUsb3 = {};
				contentArrayUsb3["statusField"] = "input_usb3_status";
				contentArrayUsb3["nameField"] = "input_usb3_name";
				contentArrayUsb3["nameValue"] = input_usb3_name;

				let input_avoip_status = jsonData.inputs['avoip'].status;
				let input_avoip_name = jsonData.inputs['avoip'].name;
				let sendArrayContenAvoipInput = {};
				sendArrayContenAvoipInput["statusField"] = "input_avoip_status";
				
				let output_hdmi1_status = jsonData.outputs["hdmi-1"].status;
				let output_hdmi1_name = jsonData.outputs["hdmi-1"].name;
				let contentArrayHdmi1 = {};
				contentArrayHdmi1["statusField"] = "output_hdmi1_status";
				contentArrayHdmi1["nameField"] = "output_hdmi1_name";
				contentArrayHdmi1["nameValue"] = output_hdmi1_name;


				let output_hdmi2_status = jsonData.outputs['hdmi-2'].status;
				let output_hdmi2_name = jsonData.outputs['hdmi-2'].name;
				let contentArrayHdmi2 = {};
				contentArrayHdmi2["statusField"] = "output_hdmi2_status";
				contentArrayHdmi2["nameField"] = "output_hdmi2_name";
				contentArrayHdmi2["nameValue"] = output_hdmi2_name;		
				
				let output_avoip_status = jsonData.outputs['avoip'].status;
				let output_avoip_name = jsonData.outputs['avoip'].name;
				let sendArrayContenAvoipOutput = {};
				sendArrayContenAvoipOutput["statusField"] = "output_avoip_status";
				let savedInputAudioSettings = inputSavedSettings["settings"]["audioSettings"];
				console.log(savedInputAudioSettings);

				if(input_usb1_status == 1) { 
					let htmlAdd = "";
					htmlAdd = '<img id="audio_usb1_status" data-id="USB-1" data-mute-status="true" class="mute_unmute" src="images/speaker.svg">';
					if(savedInputAudioSettings["audio_usb1_status"] == false) {
						htmlAdd = '<img id="audio_usb1_status" data-id="USB-1" data-mute-status="false" class="mute_unmute" src="images/mute.svg">';	
					}
					$("#audio_usb1_div").html(htmlAdd);
				}

				if(input_usb2_status == 1) {
					let htmlAdd = "";
					htmlAdd = '<img id="audio_usb2_status" data-id="USB-2" data-mute-status="true" class="mute_unmute" src="images/speaker.svg">';
						if(savedInputAudioSettings["audio_usb2_status"] == false) {
							htmlAdd = '<img id="audio_usb2_status" data-id="USB-2" data-mute-status="false" class="mute_unmute" src="images/mute.svg">';	
						}
					$("#audio_usb2_div").html(htmlAdd);
				} 

				if(input_usb3_status == 1) {
					let htmlAdd = "";
					htmlAdd = '<img id="audio_usb3_status" data-id="USB-3" data-mute-status="true" class="mute_unmute" src="images/speaker.svg">';
						if(savedInputAudioSettings["audio_usb3_status"] == false) {
							htmlAdd = '<img id="audio_usb3_status" data-id="USB-3" data-mute-status="false" class="mute_unmute" src="images/mute.svg">';	
						}
					$("#audio_usb3_div").html(htmlAdd);
				}

				if(output_hdmi1_status == 1) {
					fillValueOfInputAndOutput(contentArrayHdmi1, "show");
					//adding else part by ashu for managing status
					if(input_usb1_status == 1) { 
						makeCellActiveDeactive("box1", "show");
					} else {
						$("#input_usb1_status").attr('class', 'red-circle');					
						$("#box1").removeClass("boxactive matrix-play-btn pointer");
						$("#input_usb1_name").text("");
					}
					//adding else part by ashu for managing status
					if(input_usb2_status == 1) {
						makeCellActiveDeactive("box4", "show");
					} else {
						$("#input_usb2_status").attr('class', 'red-circle');
						$("#box4").removeClass("boxactive matrix-play-btn pointer");
						$("#input_usb2_name").text("");
					}
					//adding else part by ashu for managing status
					if(input_usb3_status == 1) {
						makeCellActiveDeactive("box7", "show");
					} else {
						$("#input_usb3_status").attr('class', 'red-circle');
						$("#box7").removeClass("boxactive matrix-play-btn pointer");
						$("#input_usb3_name").text("");
					}


					if(youTubeUrl != "") {
						makeCellActiveDeactive("box10", "show")
					}
					// if(input_avoip_status == 1) {
					// 	makeCellActiveDeactive("box10", "show")
					// }
				} else {
					fillValueOfInputAndOutput(contentArrayHdmi1, "hide");
					makeCellActiveDeactive("box1", "hide");
					makeCellActiveDeactive("box4", "hide");
					makeCellActiveDeactive("box7", "hide");
					makeCellActiveDeactive("box10", "hide");
				}

				if(output_hdmi2_status == 1) {
					$('#output_hdmi2_status').attr('class', 'green-circle');
					$('#output_hdmi2_name').html(output_hdmi2_name);
					fillValueOfInputAndOutput(contentArrayHdmi2, "show");
					//adding else part by ashu for managing status
					if(input_usb1_status == 1) {
						makeCellActiveDeactive("box2", "show");
					} else {
						$("#input_usb1_status").attr('class', 'red-circle');
					}
					//adding else part by ashu for managing status
					if(input_usb2_status == 1) {
						makeCellActiveDeactive("box5", "show");
					} else {
						$("#input_usb2_status").attr('class', 'red-circle');
					}
					//adding else part by ashu for managing status
					if(input_usb3_status == 1) {
						makeCellActiveDeactive("box8", "show");
					} else {
						$("#input_usb3_status").attr('class', 'red-circle');
					}

					if(input_avoip_status == 1) {
						makeCellActiveDeactive("box11", "show");
					} else {
						$("#input_avoip_status").attr('class', 'red-circle');
					}
				} else {
					fillValueOfInputAndOutput(contentArrayHdmi2, "hide");
					makeCellActiveDeactive("box2", "hide");
					makeCellActiveDeactive("box5", "hide");
					makeCellActiveDeactive("box8", "hide");
					makeCellActiveDeactive("box11", "hide");
				}

				if(output_avoip_status == 1) {
					fillValueOfInputAndOutput(sendArrayContenAvoipOutput, "show");
					//adding else part by ashu for managing status				
					if(input_usb1_status == 1) {
						makeCellActiveDeactive("box3", "show");
					} else {
						$("#input_usb1_status").attr('class', 'red-circle');
					}
					//adding else part by ashu for managing status
					if(input_usb2_status == 1) {
						makeCellActiveDeactive("box6", "show");
					} else {
						$("#input_usb2_status").attr('class', 'red-circle');
					}
					//adding else part by ashu for managing status
					if(input_usb3_status == 1) {
						makeCellActiveDeactive("box9", "show");
					} else {
						$("#input_usb3_status").attr('class', 'red-circle');
					}
				} else {
					makeCellActiveDeactive("box3", "hide");
					makeCellActiveDeactive("box6", "hide");
					makeCellActiveDeactive("box9", "hide");
				}

				// if(input_avoip_status == 1) {
				// 	fillValueOfInputAndOutput(sendArrayContenAvoipInput, "show");
				// }

				if(youTubeUrl != "") {
					fillValueOfInputAndOutput(sendArrayContenAvoipInput, "show");
				}

				if(input_usb1_status == 1) {
					fillValueOfInputAndOutput(contentArrayUsb1, "show");
				}
				if(input_usb2_status == 1) {
					fillValueOfInputAndOutput(contentArrayUsb2, "show");
				}
				if(input_usb3_status == 1) {
					fillValueOfInputAndOutput(contentArrayUsb3, "show");	
				}	

			} else if (responseStatus = "Error") {
				console.log(getData.errMessage);
			}		
		}
     };
		

    socket.onerror = function (error) {
        console.log(error);
    };
	
	socket.onclose = function (error) {
		// alert("Close");
        console.log("close");
        location.reload();
    };
	
	
	$(document).on('click', '#input_usb1_name',function(){
		//$('#streamurl').val('<?php //echo $url;?>');
		$('#via-modal-settings').show();		
	})
	

	$(document).on('click', '#input_avoip_value',function() {
		avSwichterObj.getSavedUrlInfo();
		// return false;
		// $('#streamurl').val('<?php echo $url;?>');
		// $('#via-modal-inputpopup').show();
		// $('#loadingImg').html("");	
	})

	$(document).on('click', '#ouput_avoip_value',function() {
		avSwichterObj.getSavedOutputSettings();
	})


	$(".section-row").removeClass("matrix-play-btn");

	$("#protocol_location").on("keyup", (event) => {
		if(event.target.value) {
			if($("#protocol_location").hasClass("error_textbox")) {
				$("#protocol_location").removeClass("error_textbox");
			}
		}
	})

	$("#protocol_key").on("keyup", (event) => {
		if(event.target.value) {
			if($("#protocol_key").hasClass("error_textbox")) {
				$("#protocol_key").removeClass("error_textbox");
			}
		}
	})

	$("#protocol_host").on("keyup", (event) => {
		if(event.target.value) {
			if($("#protocol_host").hasClass("error_textbox")) {
				$("#protocol_host").removeClass("error_textbox");
			}
		}
	})

	$("#protocol_port").on("keyup", (event) => {
		if(event.target.value) {
			if($("#protocol_port").hasClass("error_textbox")) {
				$("#protocol_port").removeClass("error_textbox");
			}
		}
	})

	$(document).on("click", "#save_output_settings", () => {	
		//added by ashu . getting casting value	
		let castingboxvalue = $('#casting_mode').val();
		
		
		let protocolValue = $("#output_protocol").val();
		let response = true;
		if(protocolValue == "RTMP") {
			let protocolLocation = $("#protocol_location").val();
			let protocolKey = $("#protocol_key").val();
			if(protocolLocation == "") {
				response = false;
				$("#protocol_location").addClass("error_textbox");
			}

			if(protocolKey == "") {
				response = false;
				$("#protocol_key").addClass("error_textbox");
			}

		} if(protocolValue == "UDP" || protocolValue == "RTP") {
			let protocolHost = $("#protocol_host").val();
			let protocolPort = $("#protocol_port").val();

			if(protocolHost == "") {
				response = false;
				$("#protocol_host").addClass("error_textbox");
			}

			if(protocolPort == "") {
				response = false;
				$("#protocol_port").addClass("error_textbox");
			}

			//added by ashu to validate IP in case of RTP and UDP
			let splitHost=$("#protocol_host").val().split('.').map(Number);
			if (splitHost.length !== 4 || splitHost.some(num => num < 0 || num > 255 || isNaN(num))) {
				response = false;
				$("#protocol_host").addClass("error_textbox");
			}	
			// Extract first octet for classification
			 const firstValue = splitHost[0];
			 
			// Check for multicast range (Class D: 224.0.0.0 to 239.255.255.255)
			if(castingboxvalue == 'Unicast'){
				if (firstValue >= 224 && firstValue <= 239) {
					response = false;
					$("#protocol_host").addClass("error_textbox");
					//$("#protocol_host").val('');
					//$("#protocol_host").attr("placeholder", "Enter unicast ip");
				}
			}
			if(castingboxvalue == 'Multicast'){
				// Check for unicast (Valid IPs excluding multicast, broadcast, and reserved ranges)
				if ((firstValue >= 1 && firstValue <= 223)) {
					response = false;
					$("#protocol_host").addClass("error_textbox");
					//$("#protocol_host").val('');
					//$("#protocol_host").attr("placeholder", "Enter multicast ip");
					
				}
			}			
		}
		
		if(response) {
			let sendData = {};
			sendData["command"] = "setSettings";
			sendData["settingsType"] = {}
			sendData["settingsType"]["outputs"] = {};
			sendData["settingsType"]["outputs"]["AVoIP"] = {};
			sendData["settingsType"]["outputs"]["AVoIP"]["audioEnabled"] = avSwichterObj.outputAudio;
			avSwichterObj.outputSettingsSave["audioEnabled"] = avSwichterObj.outputAudio;
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"] = {};

			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["video"] = {};
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["video"]["codec"] = "h264";
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["video"]["resolution"] = $("#output_resolution").val();
			avSwichterObj.outputSettingsSave["resolution"] = $("#output_resolution").val();
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["video"]["framerate"] = parseInt($("#output_frame_rate").val());
			avSwichterObj.outputSettingsSave["frameRate"] = parseInt($("#output_frame_rate").val());;
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["video"]["profile"] = $("#output_profile").val();
			avSwichterObj.outputSettingsSave["profile"] = $("#output_profile").val();
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["audio"] = {};
			// if(avSwichterObj.outputAudio) {
				sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["audio"]["codec"] = "AAC";
				sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["audio"]["bitrate"] = parseInt($("#output_audio_rate").val());
				avSwichterObj.outputSettingsSave["audioRate"] = parseInt($("#output_audio_rate").val());;
			// } 

			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["network"] = {};
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["network"]["networkProtocol"] = avSwichterObj.outputProtcol;
			avSwichterObj.outputSettingsSave["protocol"] = avSwichterObj.outputProtcol;
			sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["network"][avSwichterObj.outputProtcol] = {};
			if(avSwichterObj.outputProtcol == "RTMP") {
				let lastCharInLocation = $("#protocol_location").val().charAt($("#protocol_location").val().length - 1);
				let completeUrl = lastCharInLocation == "/" ? $("#protocol_location").val() + $("#protocol_key").val() : $("#protocol_location").val() + "/" + $("#protocol_key").val();
				sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["network"][avSwichterObj.outputProtcol]["location"] = completeUrl;
				avSwichterObj.outputSettingsSave["location"] = $("#protocol_location").val();
				avSwichterObj.outputSettingsSave["key"] = $("#protocol_key").val();
			} else if (avSwichterObj.outputProtcol == "UDP" || avSwichterObj.outputProtcol == "RTP") {
				sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["network"][avSwichterObj.outputProtcol]["host"] = $("#protocol_host").val();
				sendData["settingsType"]["outputs"]["AVoIP"]["encoder"]["network"][avSwichterObj.outputProtcol]["port"] = parseInt($("#protocol_port").val()); 
				avSwichterObj.outputSettingsSave["castingMode"] = $("#casting_mode").val();
				avSwichterObj.outputSettingsSave["host"] = $("#protocol_host").val();;
				avSwichterObj.outputSettingsSave["port"] = parseInt($("#protocol_port").val());;
			}
			avSwichterObj.saveOutputSettings();
			document.getElementById('overlay').style.display = 'flex';	
			socket.send(JSON.stringify(sendData));
			setTimeout(() => {
				document.getElementById('overlay').style.display = 'none';
				$("#loadingError").css("display", "flex");
				$("#avoip_output_settings").hide();	
			} ,3 * 1000)	
		} 
	})

	//store value in json file 
	$(document).on('click', '#input-popup-savebtn',function() {
		let testurl = $('#streamurl').val();
		let result = "";
		
		// Check if the URL contains "http", "https", or "youtube" and call the appropriate validation function
		if (testurl.includes("http") || testurl.includes("https") || testurl.includes("youtube")) {
			result = validateYouTubeUrl(testurl);  // Assuming this function returns an object with 'isValid' and 'reason'
		} else {
			result = validateUrl(testurl);  // Assuming this function also returns an object with 'isValid' and 'reason'
		}

		// If the result is not valid, show the error message and stop further actions
		if (!result.isValid) {
			$("#loadingError").css("display", "flex");
			$("#loadingError").text(result.reason);  // Display the reason for the invalid URL
			console.log(result);  // Log the result object for debugging
			return false;  // Prevent further execution if the URL is invalid
		}
		
		$('#loadingImg').html("");
		$('#loadingError').hide();
		let streamurl = $('#streamurl').val();
		document.getElementById('overlay').style.display = 'flex';
		let boxClickedId = $(".matrix-play-btn").attr("id");
		if(boxClickedId == "box10") { 
			let sendData = {};
			sendData["command"] = "stopurl";
			sendData["input"] = avSwichterObj.boxCommandArray[boxClickedId];
			sendData["outputs"] = "hdmi";
			socket.send(JSON.stringify(sendData));	
		}
		if(streamurl) {
			let sendTestUrlDataJson = "";
			$("#loadingError").hide();
			$("#loadingError").text("");
			avSwichterObj.saveTestUrlAction = "save";
			//direct save action first test then save code is in socket reposne of testurl 
			// if(avSwichterObj.saveTestUrlAction == "save") {
			$("#stream_url_status").html("Analyzing URL");
			avSwichterObj.requestSendToSwitcher = "testurl";
			sendTestUrlDataJson = getTestPlayUrlJson("testurl");
			socket.send(sendTestUrlDataJson);
			avSwichterObj.saveUrlNoResponseTimer = setTimeout(() => { 
				document.getElementById('overlay').style.display = 'none';
				$("#loadingError").css("display", "flex");
				$("#loadingError").text("Network connection error");
			}, 45 * 1000);
			// } else {
			// 	$("#stream_url_status").html("Saving URL");
			// 	sendTestUrlDataJson = getTestPlayUrlJson("saveurl");			
			// 	socket.send(sendTestUrlDataJson);		
			// 	avSwichterObj.saveUrl();
			// }
		} else {
			$("#stream_url_status").html("Saving URL");
			//stoppreview when url is blank in case of avoip			
			if(avSwichterObj.currentPlayingUrlBoxId=='box10'){
				stopPreview(7100);
			}
			avSwichterObj.saveUrl();
		}
		
	})
	
	 
	$(document).on('click', '#cancelbtn-output, #closebtn_output', () => {
		$('#avoip_output_settings').hide();
	})

	$(document).on('click', '#input-popup-cancelbtn, #closebtn',function(){
		$('#streamurl').val('');
		$("#input_resolution_div,#input_frame_rate_div, #input_audio_rate_div, #input_aspect_ratio_div, #input_audio_channel_div").html("");
		$("#loadingError").hide();	 
		$('#via-modal-inputpopup').hide();
	})

	$(document).on('click', '#output_avoip_value',function(){	
		$('#via-modal-outputpopup').show();
	})
	
	$(document).on('click', '#output-popup-cancelbtn',function(){			
		$('#via-modal-outputpopup').hide();
	})
	
	
	$(document).on('click', '#settings-popup-cancelbtn',function(){			
		$('#via-modal-settings').hide();
	});
	
	$(document).on('click', '#closebtn_settings',function(){
		$('#via-modal-settings').hide();	
	});
	
	function stopPreview(timeoutVal = 10) {
		//$('#playresume').attr('src', "images/play.svg");
		//$('#play_resume_text').text("Play");
		updatePreviewPlayPauseIcon('play');
		avSwichterObj.cancelPreviewRequests();
		clearInterval(intervalSetting);
		clearInterval(intervalSetting1);
		$('#txtdiv').html('Preview not available');
		$('#previewcontent').attr({'src':'images/no-img.svg'});
		avSwichterObj.setPreviewTime = "";
		//Clear all ajax preview
		// allPreviewAjaxReqests.forEach((xhr) => xhr.abort());
    	// allPreviewAjaxReqests = [];
		clearTimeout(stopPreviewTimer);
		setTimeout(function(e){
			avSwichterObj.jsonFile.inputs.inputaction = "stop";
			avSwichterObj.updatePlayPauseStatus();
		},timeoutVal);
		console.log('stop playing')
	}

	function updatePreviewPlayPauseIcon(action){
		if(action == "play") {
			$('.stop-preview-icon').hide();
			$('.play-preview-icon').show();
			$('#play_resume_text').text("Play");
			$('#playresume').attr('action', 'play');
		}else{
			$('.play-preview-icon').hide();
			$('.stop-preview-icon').show();
			$('#play_resume_text').text("Stop");
			$('#playresume').attr('action', 'stop');
		}
	}

	$("#playresume").on("click", function() {
		//restrict play button if preview burton is OFF
		if(avSwichterObj.jsonFile.inputs.previewstatus == 0) {
			return false;
		}	
		// if(avSwichterObj.jsonFile.inputs.previewstatus == "") {
		// 	$('#txtdiv').html('Preview not available');			
		// 	$('#previewcontent').attr({'src':'images/no-img.svg','width': '100%','height': 'auto'});
		// 	return false;
		// }
		
		if($('#playresume').attr('action')=='play' && avSwichterObj.jsonFile.inputs.previewstatus == 1 && (avSwichterObj.currentPlayingUrlBoxId || avSwichterObj.jsonFile.inputs.boxid)) {	
			// user click on matrix button
			//console.log(avSwichterObj.currentPlayingUrlBoxId+$('#input_avoip_status').attr('class'))
			//condition added by ashu on 17Sept for fixing preview issue when url is blank
			if($('#input_avoip_status').hasClass('red-circle') && avSwichterObj.currentPlayingUrlBoxId == 'box10') {
				return false;
			}
			
			$('#txtdiv').html('Fetching information. Please wait...');
			if(avSwichterObj.jsonFile.inputs.inputaction == "stop") {
				avSwichterObj.jsonFile.inputs.inputaction = "play";
				avSwichterObj.updatePlayPauseStatus();	
			}
				

			// if(avSwichterObj.currentPlayingUrlBoxId) {
			// 	if(avSwichterObj.currentPlayingUrlBoxId != avSwichterObj.jsonFile.inputs.boxid) {
			// 		avSwichterObj.updatePlayingUrlBoxId();
			// 	}
			// } else { 
			// 	if(avSwichterObj.jsonFile.inputs.boxid) {
			// 		avSwichterObj.jsonFile.inputs.inputaction = "play";
			// 		avSwichterObj.updatePlayPauseStatus();	
			// 	}
			// }	
			//$('#playresume').attr('src','images/stop.svg');
			//$('#play_resume_text').text("Stop");
			console.log("Start Preview");
			updatePreviewPlayPauseIcon('stop');
			clearInterval(intervalSetting1);
			stopPreviewTimer = setTimeout(()=> {
				stopPreview();
			}, 60 * 1000);
						
			intervalSetting1 = setInterval(function () {
				avSwichterObj.getPreview();
			}, timeinterval);
			
		} else {
			if($('#playresume').attr('action') == 'stop') {
				stopPreview();	
			}
			// d = new Date();	
			// if(localStorage.getItem("preview_last_state")==1){
			// 	$('#playresume').attr('src','images/play.svg')	
			// 	$('#play_resume_text').text("Play");
			// }		
			// clearInterval(intervalSetting);
			// clearInterval(intervalSetting1);
			// $('#txtdiv').html('');
			// $('#previewcontent').attr({'src':'images/no-img.svg','width': '100%','height': 'auto'});			
			//clearInterval(intervalSetting1);		
			//$('#previewcontent').attr({'src':'../../Collab8/config/AVSwitcher-dir/preview/preview.png?'+d.getTime(),'width': '100%','height': 'auto'});	
			
		}
		
	})
		
	$('#autoswitchonoff').on('click',function(){
		if($('#autoswitchonoff').is(':checked')==true){
			$('#autoswitchstatus').html('On');
		}else{
			$('#autoswitchstatus').html('Off');
		}
		
	})

	$('#previewonoff').on('click',function() {
		if($('#previewonoff').is(':checked') == true) {
			if(avSwichterObj.jsonFile.inputs.boxid == "") {
				$('#txtdiv').html('Preview not available');			
				$('#previewcontent').attr({'src':'images/no-img.svg'});
			} else {
				$('#playresume').attr('src','images/play.svg')
				$('#play_resume_text').text("Play");
				$('#txtdiv').html('Preview not available');
			}
			avSwichterObj.jsonFile.inputs.previewstatus = 1;
		} else {
			if($('#playresume').attr('src') != 'images/play.svg') {
				stopPreview();	
			}
			avSwichterObj.jsonFile.inputs.previewstatus = 0;
			$('#txtdiv').html('Turn the preview toggle ON to see a picture');
		}
		avSwichterObj.updatePreviewStatus();
	})	


	$(document).on('click', '#settings-popup-savebtn',function(){		
		var devicename=$('#devicebox').val();
		if(devicename==''){
			alert('Please select device name');
			return false;
		}else{
		var capture_card_status=($('#input_usb1_status').attr('class')=='red-circle')?0:1;
		
			var split_devicename=devicename.split('#');
			localStorage.setItem("swap_last_state", 'capturecard#'+split_devicename[0]);
			jQuery.ajax({
					type:'POST',
					url:'save_capture_card_ajax.php',
					data:'devicename='+devicename+'&capture_card_status='+capture_card_status,
					dataType:'html',
					beforeSend : function(){
						//$('#loadingImg').html("<img src='images/bar-circle.gif' width='20px' height='20px'>");
							
					},
					success:function(responseData, status, XMLHttpRequest){
						//alert(responseData)
						$(window.location).attr('href','main.php');
						
					}					
				});
		
		}
	})	
	
	
})

       function get_input_outputData(callback) {
            $.ajax({
                url: 'read_input_output_data.php', // Replace with your API endpoint
                method: 'GET',
                success: function(response) {
                    callback(response); // Call the callback function with the response data
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error('Error fetching data:', textStatus, errorThrown);
                }
            });
        }


</script>
