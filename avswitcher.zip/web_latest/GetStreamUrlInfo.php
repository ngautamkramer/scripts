<?php 
class GetStreamUrlInfo {
	private $fileName = "input-data.json";
	public function __construct() {
		
	}

	public function readFileData() {
		$file = fopen($this->fileName, "r") or die("Unable to open file!");
		return fread($file, filesize($this->fileName));
		// fclose($file);
	}

}
$obj = new GetStreamUrlInfo();
$data = $obj->readFileData(); 
echo $data;
?>