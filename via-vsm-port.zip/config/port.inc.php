<?php //Cloud server Port configuration file.
if(strtoupper(substr(PHP_OS, 0, 3))=='LIN' && PRODUCT_TYPE=='vsm'){
	$xmldata=file_get_contents($_SERVER["DOCUMENT_ROOT"]."/../bin/config/serverconfig.xml");
	$xml=simplexml_load_string($xmldata);
	$DBHost=trim($xml->DBHost);
	$DBName=trim($xml->DBName);
	$DBUserName=trim($xml->DBUserName);
	$ApiSrvrLoclPort=trim($xml->ApiSrvrLoclPort);
	$ApiServerPort=trim($xml->ApiServerPort);
	$DSSPort=trim($xml->DSSPort);
	$PollPort=trim($xml->PollPort);
	$FileSrvrPort=trim($xml->FileSrvrPort);
	$ContentPath=trim($xml->ContentPath);
	$MemcachePort=trim($xml->MemcachePort);
}elseif(strtoupper(substr(PHP_OS, 0, 3))=='WIN' && PRODUCT_TYPE=='vsm'){
	$DBHost='localhost';
	$DBName='vsm';
	$DBUserName='root';	
	$ApiSrvrLoclPort=9982;	
	$DSSPort=5557;
	$MemcachePort=11211;
}else{
	$DBHost='localhost';
	$DBName='wpg_live_db';
	$DBUserName='postgres';
	$DBPort=5432;
	$DBPass='root';
	/*$DBHost='localhost';
	$DBName='wpg';
	$DBUserName='viadbuser';	
	$DBPass='w0wAdm1n8';*/
	$ApiSrvrLoclPort=9982;	
	$DSSPort=5557;
	$MemcachePort=11211;
}	
?>