<?php

/*return array(
    'db' => array(
        'driver' => 'Pdo',
        'dsn' => 'mysql:dbname=zf2_test;host=localhost',
        'username' => 'root',
        'password' => '',
        'driver_options' => array(
            PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'Zend\Db\Adapter\Adapter'
            => 'Zend\Db\Adapter\AdapterServiceFactory',
        ),
    ),
);*/


return array ( 
    'db' => array ( 
      'driver' => 'Pdo', 
      'dsn' =>'pgsql:host='.HOST_NAME.';port='.DB_PORT.';dbname='.DB_NAME.';user='.DB_USER.';password='.DB_PASSWORD, 
      'driver_options' => array () 
      ),
      'service_manager' => array('factories' => array('Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory')
    )
  );
