<?php 

return array ( 
  'db' => array ( 
    'driver' => 'Pdo', 
    'dsn' =>'pgsql:host='.HOST_NAME.';port='.DB_PORT.';dbname='.DB_NAME.';user='.DB_USER.';password='.DB_PASSWORD, 
    'driver_options' => array () 
    ),
    'service_manager' => array(
      'factories' => array(
          'Zend\Db\Adapter\Adapter'
          => 'Zend\Db\Adapter\AdapterServiceFactory',
    )
  )
);