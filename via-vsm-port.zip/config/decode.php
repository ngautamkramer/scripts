<?php
require("mypass.php");
//echo $password; 
$key = pack('H*', "bcb04b42e2130233a2232c323d2afde76c55abe029ebae5e1d417e2ffb2a00a3");
$method = 'aes-256-cbc';	
$key = substr(hash('sha256', $key, true), 0, 32);
// IV must be exact 16 chars (128 bit)
$iv = chr(0xA) . chr(0xB) . chr(0x0) . chr(0xC) . chr(0x0) . chr(0xD) . chr(0xE) . chr(0xc) . chr(0x9) . chr(0x3) . chr(0x0) . chr(0x0) . chr(0xC) . chr(0xd) . chr(0x0) . chr(0xB);	
$plaintext_dec = trim(openssl_decrypt(base64_decode($password), $method, $key, OPENSSL_RAW_DATA, $iv));
// this is to be used in place of password 
// echo  $plaintext_dec . "\n";
?>