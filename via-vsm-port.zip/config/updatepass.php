<?php
require("mypass.php");
//echo $password;

 
	$key = pack('H*', "bcb04b42e2130233a2232c323d2afde76c55abe029ebae5e1d417e2ffb2a00a3");
    
	 # create a random IV to use with CBC encoding
    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);

	# === WARNING ===

    # Resulting cipher text has no integrity or authenticity added
    # and is not protected against padding oracle attacks.
    
    # --- DECRYPTION ---
    
    $ciphertext_dec = base64_decode($password);
    
    # retrieves the IV, iv_size should be created using mcrypt_get_iv_size()
    $iv_dec = substr($ciphertext_dec, 0, $iv_size);
    
    # retrieves the cipher text (everything except the $iv_size in the front)
    $ciphertext_dec = substr($ciphertext_dec, $iv_size);

    # may remove 00h valued characters from end of plain text
    $plaintext_dec = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key,
                                    $ciphertext_dec, MCRYPT_MODE_CBC, $iv_dec);

		 # show key size use either 16, 24 or 32 byte keys for AES-128, 192
    # and 256 respectively
   
    
    # show key size use either 16, 24 or 32 byte keys for AES-128, 192
    # and 256 respectively
  
  //  echo "Key size: " . $key_size . "\n";
    //echo $argv[1];
    $plaintext =$plaintext_dec;
	//"My encyrted";

	
	$method = 'aes-256-cbc';
	
	$key = substr(hash('sha256', $key, true), 0, 32);
	// IV must be exact 16 chars (128 bit)
	$iv = chr(0xA) . chr(0xB) . chr(0x0) . chr(0xC) . chr(0x0) . chr(0xD) . chr(0xE) . chr(0xc) . chr(0x9) . chr(0x3) . chr(0x0) . chr(0x0) . chr(0xC) . chr(0xd) . chr(0x0) . chr(0xB);

	
	// av3DYGLkwBsErphcyYp+imUW4QKs19hUnFyyYcXwURU=
	$ciphertext = base64_encode(openssl_encrypt($plaintext, $method, $key, OPENSSL_RAW_DATA, $iv));
	$fpWrite=@fopen("C:\\HQServer\\httpd\\htdocs\\config\\mypass.php","w");
	@fputs($fpWrite,"<?php\n");
	@fputs($fpWrite,"\$password=\"".$ciphertext."\"\n");
	@fputs($fpWrite,"?>\n");

   
	
	?>