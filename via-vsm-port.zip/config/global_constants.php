<?php //for production server

	define('PROD_MODE', true);

	if(PROD_MODE == true) {
		define('ROOT_BASE_PATH',$_SERVER['DOCUMENT_ROOT']);
		//for development 
	}else{
		define('ROOT_BASE_PATH',$_SERVER['DOCUMENT_ROOT'].'/VIA-VSM-PORT');
	}

	$hostname = $_SERVER['HTTP_HOST'];	
	define('HOSTNAME',$_SERVER['HTTP_HOST']);
	define('PROTOCOL',$_SERVER['REQUEST_SCHEME']);
	define('BASE_PATH',getcwd());
	
	define("GET_OS",strtoupper(substr(PHP_OS, 0, 3)));
	if(GET_OS=='WIN'){
		define('SYSTEM_PATH_FILE',ROOT_BASE_PATH.'/../../systempath.json');
	}else{
		define('SYSTEM_PATH_FILE',file_exists(ROOT_BASE_PATH.'/systempath.json')?ROOT_BASE_PATH.'/systempath.json':ROOT_BASE_PATH.'/../bin/config/systempath.json');
	}
	
	if(file_exists(SYSTEM_PATH_FILE)){
		$jsonStr = file_get_contents(SYSTEM_PATH_FILE);
		$json_arr=json_decode($jsonStr,true);
		define('DEST_PATH',trim($json_arr['config_dir']).'/');	
		define('CLIENT_SYSLOG_DIR',trim($json_arr['log_dir']));
		define('PRODUCT_TYPE',trim($json_arr['product_type']));	
		define('HTML_PUBLIC_DIR',trim($json_arr['html_public_dir']));
		define('WEB_DATA_PATH',PROTOCOL."://".$hostname.'/'.trim($json_arr['webdatapath']));				
	}	
	include_once('port.inc.php');
	if(PRODUCT_TYPE=='vsm'){
		//getting password form decode.php for vsm		
		include_once('decode.php');		
	}
	

	if(PROD_MODE == true) {
		//for production server
		define("BASE_URL",PROTOCOL."://".$hostname);
		define("PUBLIC_URL",PROTOCOL."://".$hostname."/public");
		define("OLD_URL","https://".HOSTNAME."/");	
	}else{
		//for development 
		define("BASE_URL",PROTOCOL."://".$hostname."/VIA-VSM-PORT");
		define("PUBLIC_URL",PROTOCOL."://".$hostname."/VIA-VSM-PORT/public");
		define("OLD_URL","https://".HOSTNAME."/VIA-VSM-PORT/");
	}
	
	define("DIR_NAME", dirname(__DIR__));
	if(PRODUCT_TYPE=='via' || PRODUCT_TYPE=='collab8'){
		define("PRODUCT", "via");
		define("WEB_VERSION","WEB-4.2.0.932");
		define("PRODUCT_MODEL_TYPE",0);		
	}else if(PRODUCT_TYPE=='kds'){
		define("PRODUCT", "kds");
		define("WEB_VERSION","WEB-3.0.0820.790");
		//using for model_type field in tbl_templates.
		define("PRODUCT_MODEL_TYPE",1);	
	}else if(PRODUCT_TYPE=='vsm'){
		define("PRODUCT", "vsm");
		define("WEB_VERSION_STR","VIA Server");
		define("WEB_VERSION",WEB_VERSION_STR." Version W-4.1.0.367");
		$getFullUrl=trim($_SERVER['REQUEST_URI']);		
		define("PRODUCT_MODEL_TYPE",(strstr($getFullUrl,'wallpaper/') || strstr($getFullUrl,'/uploadWallpaper') || strstr($getFullUrl,'kdsconfigurations/'))?1:0);
	}else{
		define("PRODUCT", "vsm");
		define("WEB_VERSION_STR","Collab8 Server");
		define("WEB_VERSION",WEB_VERSION_STR." Version W-3.0.0820.284");
		$getFullUrl=trim($_SERVER['REQUEST_URI']);		
		define("PRODUCT_MODEL_TYPE",(strstr($getFullUrl,'wallpaper/') || strstr($getFullUrl,'/uploadWallpaper') || strstr($getFullUrl,'kdsconfigurations/'))?1:0);	
	}
	//using for working on all environent like via/kds/vsm
	define('PRODUCT_MODEL',(PRODUCT_TYPE=='kds' || PRODUCT_MODEL_TYPE==1)?'kds':PRODUCT_TYPE);
	
	if(PRODUCT_TYPE=='via' || PRODUCT_TYPE=='vsm' || PRODUCT_TYPE=='kds'){
		define('PRODUCT_IMG_PATH', 'via');
	}else{
		define('PRODUCT_IMG_PATH', 'collab8');
	}
	if(PRODUCT_TYPE=='via' || PRODUCT_TYPE=='collab8' || PRODUCT_TYPE=='kds'){
		define('SECOND_DEST_PATH',$_SERVER["DOCUMENT_ROOT"]."/../bin/");
		define('FULL_UPLOAD_PATH',$_SERVER["DOCUMENT_ROOT"]."/uploads/");
	}else{
		if(GET_OS=='WIN'){
			define('SECOND_DEST_PATH','C:/HQServer/');
			define('FULL_UPLOAD_PATH',"C:/Collab8/httpd/htdocs/uploads/");
			define('LICENSE_UPLOAD_PATH',"C:/HQServer/httpd/htdocs/");
			define('VSM_VERSION_FILE',"hq_version.txt");
			define('CHECK_VSM_VERSION_FILE',file_exists(SECOND_DEST_PATH.VSM_VERSION_FILE)?1:0);
		}else{
			define('SECOND_DEST_PATH',DEST_PATH);
			define('FULL_UPLOAD_PATH',HTML_PUBLIC_DIR."/uploads/");
			define('LICENSE_UPLOAD_PATH',HTML_PUBLIC_DIR);
			define('VSM_VERSION_FILE',"hq_version.txt");
			define('CHECK_VSM_VERSION_FILE',file_exists(SECOND_DEST_PATH.VSM_VERSION_FILE)?1:0);
		}
	}
		
	define("TBUSER","appuserlist");
	define("TBMEDIA","recording");
	define("TVIRMODULE","IRModules");
	define("IRCOMMANDS","IRCommands");
	define("IRPLAYERCOMMAND","IRController");
	define("PLISTMASTER","streamingmaster");
	define("CLIENTPORT","14000");
	define("KEY_SEED","WPG L1nux Pr0t3ct10n by @td1g1s1gn T3chN0l0g13s and Proj3ct Mgrs C0nf1gur@t1on F1l3");
	define("RABBIT_MQ_KEY_SEED","WPG rab@itmq Pr0t3ct10n by @td1g1s1gn T3chN0l0g13s and Proj3ct Mgrs C0nf1gur@t1on F1l3");
	
	define("IMG_DIR","uploads/");	
	define("FONT_PATH","fonts/");
	// UPLOAD_PATH_INTERNAL is using for internal path. Currently using for ntp/auth file in manage configuration  
	define("UPLOAD_PATH_INTERNAL", DIR_NAME.'/public/'.IMG_DIR);	
	//change path as per systempath.json
	define("UPLOAD_PATH", HTML_PUBLIC_DIR.'/'.IMG_DIR);		
	define("LARGE_IMG_PATH", HTML_PUBLIC_DIR."/uploads/large/");
	define("SMALL_IMG_PATH",HTML_PUBLIC_DIR."/uploads/small/");
	define("USER_AGENT",$_SERVER['HTTP_USER_AGENT']);
	define('VIAGO_FILE',"viago.txt");
	define('HOST_NAME',$DBHost);
	define('DB_USER',$DBUserName);
	define('DB_PORT',$DBPort);
	if(PRODUCT_TYPE=='vsm'){
		define('DB_PASSWORD',trim($plaintext_dec));
	}else{
		//define('DB_PASSWORD','w0wAdm1n8');
		define('DB_PASSWORD', $DBPass);
	}
	define('DB_NAME',$DBName);
	
	
	define('DEFAULT_SERVER_IP',$_SERVER['HTTP_HOST']);			
	define('DEFAULT_SERVER_PORT',$ApiSrvrLoclPort);	
	define('SSL_SERVER_PORT',$DSSPort);	
	
	define('BRIDGE_KEYWORD','C0LLAB@ADM1NBR1DGEL0G1N');
	define('LANG_DIR','lang/');
	define('WIFISECURITY_KEYWORD','1324587099345678');
	define('PING_DOMAIN','discovery.wowvision.com');
	define('PING_DOMAIN_PORT',443);
	define('FILE_GWAY_AUTHENTICATION','gateway_authentication.txt');

	define('FILE_LICENSE_DETAILS',BASE_PATH.'/configs/licdetails.txt');
	define('CHECK_FILE_LICENSE_DETAILS',file_exists(FILE_LICENSE_DETAILS)?1:0);
	define('KEY_SEED_NEW','WPG L1nux Pr0t3ct10n by @td1g1s1gn T3chN0l0g13s and Proj3ct Mgrs C0nf1gur@t1on F1l3');
	define('LICENSE_FILE_PATH',BASE_PATH.'/configs/');
	define('COUNT_GWAY_FILE',BASE_PATH.'/configs/loglc.txt');
	define('CHECK_TOTAL_GATEWAYS',file_exists(COUNT_GWAY_FILE)?1:0);
	define('WebSite_AppName','Website');
	define('FILE_DOMAIN','domain.txt');
	define('POLL_ENCRYPTION_KEY','WOWASKSDFNSDFKEISDJAHDLDSDF1235UUUiidfsdfVISION');
	define('RECORDING_PATH',BASE_PATH.'/Recording');
	
	define('READFILE_ROOMNAME',"roomname.txt");
	define('READFILE_ROOMCODE',"roomcode.txt");
	define('READFILE_ROOMCODESHOW',"roomcodeshow.txt");
	define('READFILE_STRDATETIME',"strDateTime.txt");
	define('READFILE_PIP',"PIP.txt");
	define('READFILE_ENABLELOG',"enabllog.txt");
	define('READFILE_CHKPRESENTATION_MODE',"chkPresentationMode.txt");
	define('READFILE_MEDIA',"Media.txt");
	define('READFILE_QUICK',"quick.txt");
	define('READFILE_REFRESHTIME',"refreshtime.txt");
	define('READFILE_IPADD',"ipadd.txt");
	define('READFILE_ROOMNAMEVALUESHOW',"roomnamevalueshow.txt");
	define('READFILE_ROOMNAME_VALUESHOW',"roomnamevalueshow.txt");	
	define('READFILE_PIPSETTINGS',"PIPSetting.txt");
	define('READFILE_SECOND_DISPLAY',"roomcodebothscreen.txt");
	define('READFILE_CAMPUSPLUS',"campusplus.txt");
	define('READFILE_OLDCHROME',"oldchrome.txt");
	define('READFILE_STROUGROUP','strOU_GroupFile.txt');
	define('READFILE_STRADSETTINGS','strADSettings.txt');
	define('READFILE_DEFINEDSERVERIP','serverIP.txt');
	define('READFILE_IPADD1',"ipadd1.txt");
	define('READFILE_LANGTXT',"language.txt");
	define('READFILE_ROOMCODEVALUE_SHOW','roomcodevalue.txt');

	/****************** Checking File Exist or not ******************* */
	define('CHECKFILE_ROOMNAME',file_exists(DEST_PATH.READFILE_ROOMNAME)?1:0);
	define('CHECKFILE_ROOMCODE',file_exists(DEST_PATH.READFILE_ROOMCODE)?1:0);
	define('CHECKFILE_ROOMCODESHOW',file_exists(DEST_PATH.READFILE_ROOMCODESHOW)?1:0);
	define('CHECKFILE_STRDATETIME',file_exists(DEST_PATH.READFILE_STRDATETIME)?1:0);
	define('CHECKFILE_PIP',file_exists(DEST_PATH.READFILE_PIP)?1:0);
	define('CHECKFILE_ENABLELOG',file_exists(DEST_PATH.READFILE_ENABLELOG)?1:0);
	define('CHECKFILE_CHKPRESENTATION_MODE',file_exists(DEST_PATH.READFILE_CHKPRESENTATION_MODE)?1:0);
	define('CHECKFILE_QUICK',file_exists(DEST_PATH.READFILE_QUICK)?1:0);
	define('CHECKFILE_MEDIA',file_exists(DEST_PATH.READFILE_MEDIA)?1:0);
	define('CHECKFILE_REFRESHTIME',file_exists(DEST_PATH.READFILE_REFRESHTIME)?1:0);
	define('CHECKFILE_PIPSETTINGS',file_exists(DEST_PATH.READFILE_PIPSETTINGS)?1:0);
	define('CHECKFILE_SECONDDISPLAY',file_exists(DEST_PATH.READFILE_SECOND_DISPLAY)?1:0);
	define('CHECKFILE_OUGROUP',file_exists(DEST_PATH.READFILE_STROUGROUP)?1:0);
	define('CHECKFILE_ADSETTINGS',file_exists(DEST_PATH.READFILE_STRADSETTINGS)?1:0);
	define('CHECKFILE_DEFINEDSERVERIP',file_exists(DEST_PATH.READFILE_DEFINEDSERVERIP)?1:0);
	define('CHECK_FILE_LANGTXT',file_exists(DEST_PATH.READFILE_LANGTXT)?1:0);
	//define('TEMPLATE_DIR_ZEND',BASE_PATH."/public/uploads/templates/");
	define('TEMPLATE_DIR_ZEND',HTML_PUBLIC_DIR."/uploads/templates/");
	//define('UPLOAD_DIR_ZEND',BASE_PATH."/public/");
	define('UPLOAD_DIR_ZEND',HTML_PUBLIC_DIR."/");
	define("UPLOAD_PATH_VIA_SAVEAS", DIR_NAME.'/');
	//Google credeatials
	define('GOOGLE_CLIENT_ID','1034894911045-j16uiqf05jtuk8n57bt0qv1rp7lscqh0.apps.googleusercontent.com');
    define('GOOGLE_CLIENT_SECRET','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');
    define('GOOGLE_REDIRECT_URL','https://rbsdev.wowvision.com/getGooglecode.php');
	define('GOOGLE_SCOPES','https://www.googleapis.com/auth/calendar,https://www.googleapis.com/auth/plus.login,https://www.googleapis.com/auth/userinfo.email,https://www.googleapis.com/auth/userinfo.profile');
	
    define('OPEN_SSL_PATH',__DIR__.'/cacert.pem');
	define('SLEEP_ARR', array('5'=>5,'10'=>10,'30'=>30));	
	define('TEMPLATE_DIR_CONFIG',"config_templates/");
	
	
	define('VSM_CHECK_UPDATE_FILE',"checkUpdate.txt");
	define('CHECK_VSM_UPDATE_FILE',file_exists(DEST_PATH.VSM_CHECK_UPDATE_FILE)?1:0);
	//define("FONT_UPLOAD_PATH",BASE_PATH."/public/fonts/");
	//define('UPLOAD_CONTENT_MEDIA',BASE_PATH."/public/media/");
	//define('UPLOAD_DSS_CAMPAIGN',BASE_PATH."/public/campaign/");
	define("FONT_UPLOAD_PATH",HTML_PUBLIC_DIR."/fonts/");
	define('UPLOAD_CONTENT_MEDIA',HTML_PUBLIC_DIR."/media/");
	define('UPLOAD_DSS_CAMPAIGN',HTML_PUBLIC_DIR."/campaign/");	
	define('UPLOAD_DSS_LICENSE',BASE_PATH."/public/uploads/");



	//Constants for VIA
	if(file_exists(DEST_PATH."model.json")){
		$jsonStr = file_get_contents(DEST_PATH."model.json");
		$json_arr=json_decode($jsonStr,true);
	}
	if(file_exists(DEST_PATH."model.json")){
		$jsonStr = file_get_contents(DEST_PATH."model.json");
		$json_arr=json_decode($jsonStr,true);
	}
	if(file_exists(DEST_PATH.'network.json')){
		$strJson=file_get_contents(DEST_PATH.'network.json');
		$arraynetworkJson = (array)json_decode($strJson);		
	}	
	
	//modified condition by ashu on 11July24. now using modellike in place of model
	define('CHECK_VIAGO_FILE',(trim($json_arr['modellike'])==3)?1:0);	
	if(GET_OS=='WIN'){
		// added by ashu		
		define('SYSTEM_DEFAULT_IMG',"windowDefault.jpg");
		define('SYSTEM_DEFAULT_TEMP',"windowDefault.json");	
		define('VIA_DEFAULT_IMG',"default.jpg");	
		define('FILE_MIRROR_MAX_CONN',(CHECK_VIAGO_FILE==0)?4:1);		
		define('DD_MAX_CONN',(CHECK_VIAGO_FILE==0)?13:3);
		define('UPLOAD_CERTIFICATE_PATH',"uploads/certificate/");	
	}else{
		define('SYSTEM_DEFAULT_IMG',"linuxDefault.png");
		define('SYSTEM_DEFAULT_TEMP',"linuxDefault.json");
		define('VIA_DEFAULT_IMG',"default.png");
		define('FILE_MIRROR_MAX_CONN',(CHECK_VIAGO_FILE==0)?2:1);
		define('DD_MAX_CONN',(CHECK_VIAGO_FILE==0)?3:3);
		define('UPLOAD_CERTIFICATE_PATH',"/var/www/html/uploads/certificate/");
	}	

	define('LIN_WIFI_PATH',DEST_PATH."wifi/");
	define('VERSION_PATH',DEST_PATH."version/");
	define('VERSION_DIR_PATH',"website/");
	define('MODEL_PATH',"configs/");		
	define('FC23_FILE',"fc23.txt");		
	define('CHECK_FC23_FILE',(trim(strtolower($json_arr['ostype']))=='fc23')?1:0);
		
	define('NETWORK_SETTINGS_FILE',DEST_PATH."network_settings.txt");		
	define('GATEWAY_AUTHENTICATION_FILE',DEST_PATH.FILE_GWAY_AUTHENTICATION);
	define('FILE_GATEWAY_FEATURES',"fileGatewayFeatues.txt");
	define('FILE_CLIENT_FEATURES',"fileClientFeatues.txt");
	define('FILE_CLIENT_SERVER',"checkClientServer.txt");	
	define('CHECK_MODEL_FILE',"C:/tc/config/checkgateway.txt");	
	//define('BRIDGE_KEYWORD',"C0LLAB@ADM1NBR1DGEL0G1N");
	
	$GLOBALS['refreshTimeArr']=array(array(1=>3,2=>5,3=>10,4=>20,5=>30,6=>50,7=>60));
	define('FILE_ROOMNAME',file_exists(DEST_PATH.READFILE_ROOMNAME)?1:0);
	define('FILE_ROOMCODE',file_exists(DEST_PATH.READFILE_ROOMCODE)?1:0);
	define('FILE_ROOMCODESHOW',file_exists(DEST_PATH.READFILE_ROOMCODESHOW)?1:0);
	define('FILE_STROUGROUP',file_exists(DEST_PATH.READFILE_STROUGROUP)?1:0);
	define('FILE_STRADSETTINGS',file_exists(DEST_PATH.READFILE_STRADSETTINGS)?1:0);
	define('FILE_STRDEFINED_SERVERIP',file_exists(DEST_PATH.READFILE_SECOND_DISPLAY)?1:0);
	define('FILE_ASSOCIATE_FILE',"whiteboardapp.txt");
	define('FILE_BROWSE_ASSOCIATE',"browserapp.txt");
	define('FILE_AUTO_POWEROFF',"powerOfftime.txt");
	define('CHECK_FILE_AUTO_POWEROFF',file_exists(DEST_PATH.FILE_AUTO_POWEROFF)?1:0);
	define('FILE_AUTO_REBOOT',"autoreboot.txt");
	define('CHECK_FILE_AUTO_REBOOT',file_exists(DEST_PATH.FILE_AUTO_REBOOT)?1:0);
	define('FILE_ENERGYSAVER_MODE',"energysaver.txt");
	define('FILE_NEW',"newfile.txt");
	define('FILE_CHECKWIFI',"1.txt");
	define('FILE_WIFI_ONOFF',"wifionoff.txt");
	define('FILE_WIFI_SSID',"wifissid.txt");
	define('FILE_WIFI_PASS',"wifipass.txt");

	define('FILE_NOPIP',"NOPIP.txt");
	define('CHECK_FILE_NOPIP',file_exists(DEST_PATH.FILE_NOPIP)?1:0);
	define('FILE_STR24HOUR_FORMAT',"24hour.txt");
	define('CHECK_FILE_STR24HOUR_FORMAT',file_exists(DEST_PATH.FILE_STR24HOUR_FORMAT)?1:0);
	define('FILE_MIRRORNAME',"AirMirror.txt");
	define('FILE_MIRROR_MAXCON',"AirMirrorMaxCon.txt");

	/*VINEET*/
	define('FILE_PATCOUNT','patcount.txt');
	define('FILE_CAPTURECARD_RUNNING','running.txt');
	define('CHECK_FILE_PATCOUNT',file_exists(DEST_PATH.FILE_PATCOUNT) || file_exists(DEST_PATH.FILE_CAPTURECARD_RUNNING)?1:0);

	//define('CHECK_FILE_LANGTXT',file_exists(DEST_PATH.READFILE_LANGTXT)?1:0);
	define('FILE_WALLPAPERSETTING',"wallpaperSettings.txt");
	define('CHECK_FILE_WALLPAPERSETTING',file_exists(DEST_PATH.FILE_WALLPAPERSETTING)?1:0);
	define('FILE_GWAY_FEATURESETTING',"gatewayFeatureSettings.txt");
	define('CHECK_FILE_GWAY_FEATURESETTING',file_exists(DEST_PATH.FILE_GWAY_FEATURESETTING)?1:0);
	define('FILE_CLIENT_FEATURESETTING',"clientFeatureSettings.txt");
	define('CHECK_FILE_CLIENT_FEATURESETTING',file_exists(DEST_PATH.FILE_CLIENT_FEATURESETTING)?1:0);
	define('FILE_CONFIGSETTING_FILE',"configSettingFile.txt");
	define('FILE_AUTHSETTING_FILE',"authSettingFile.txt");

	define('FILE_DATEFORMAT',"dateFormat.txt");
	define('CHECK_FILE_DATEFORMAT',file_exists(DEST_PATH.FILE_DATEFORMAT)?1:0);
	define('FILE_TIMEFORMAT',"timeFormat.txt");
	define('FILE_TIMEAMPM',"showTimeAMPM.txt");
	define('FILE_DND',"dndbutton.txt");
	define('FILE_CHAT',"chatbutton.txt");
	define('CHECK_FILE_CHAT',file_exists(DEST_PATH.FILE_CHAT)?1:0);
	define('FILE_DYNAMICLAYOUT',"nohidewindow.txt");
	define('CHECK_FILE_DYNAMICLAYOUT',file_exists(DEST_PATH.FILE_DYNAMICLAYOUT)?1:0);

	define('FILE_DHCP_FILE',"dhcpd.txt");
	define('FILE_GWAYBOXID_FILE',"boxID.txt");
	define('FILE_VERSION_FILE',"myversion.txt");
	define('SERIALNO_FILE',"strSerialnumber.txt");
	define('CHECK_SERIALNO_FILE',file_exists(DEST_PATH.SERIALNO_FILE)?1:0);
	define('FILE_LAYOUT',"layout.txt");
	define('CHECK_FILE_LAYOUT',file_exists(DEST_PATH.FILE_LAYOUT)?1:0);
	define('WIFI_SECURITY_KEY',"VFYTKJGHDSWBGFQONl12345w0W");
	define('FILE_THIRDPARTYSHORTCUT',"tpshortcut.txt");
	define('FILE_DISABLE_ONTOP',"disableontop.txt");
	define('FILE_MOBILE_FEATURES',"fileMobileFeatues.txt");
	define('FILE_WIFISECURITY_FILE',"viaPadWifi.txt");
	//Ranjan
	define('FILE_HDMIMODE',"defhdmimod.txt");
	define('CHECK_FILE_HDMIMODE',file_exists(DEST_PATH.FILE_HDMIMODE)?1:0);
	define('CHECK_FILE_DISABLE_ONTOP',file_exists(DEST_PATH.FILE_DISABLE_ONTOP)?1:0);
	define('CHECK_FILE_ENERGYSAVER_MODE',file_exists(DEST_PATH.FILE_ENERGYSAVER_MODE)?1:0);
	define('CHECK_FILE_THIRDPARTYSHORTCUT',file_exists(DEST_PATH.FILE_THIRDPARTYSHORTCUT)?1:0);
	define('CHECK_FILE_MIRRORNAME',file_exists(DEST_PATH.FILE_MIRRORNAME)?1:0);
	define('CHECK_FILE_MIRROR_MAXCON',file_exists(DEST_PATH.FILE_MIRROR_MAXCON)?1:0);
	define('IMAGE_QRCODE',"qrcode.png");
	define('CHECK_IMAGE_QRCODE',file_exists(DEST_PATH.IMAGE_QRCODE)?1:0);
	define('FILE_SERIALNO',"strSerialnumber.txt");
	define('CHECK_FILE_SERIALNO',file_exists(DEST_PATH.FILE_SERIALNO)?1:0);
	define('CHECK_FILE_DND',file_exists(DEST_PATH.FILE_DND)?1:0);
	define('FILE_QRTOP', 'qrtop.txt');
	define('CHECK_FILE_QRTOP',file_exists(DEST_PATH.FILE_QRTOP)?1:0);
	define('FILE_QRCODE', 'qrcode.txt');
	define('CHECK_FILE_QRCODE',file_exists(DEST_PATH.FILE_QRCODE)?1:0);
	define('FILE_QRBYPASS', 'qrbypass.txt');
	define('CHECK_FILE_QRBYPASS',file_exists(DEST_PATH.FILE_QRBYPASS)?1:0);
	define('FILE_QRPOINT', 'qrpoint.txt');
	define('CHECK_FILE_QRPOINT',file_exists(DEST_PATH.FILE_QRPOINT)?1:0);
	define('FILE_FREE_FLOW', 'FreeFlow.txt');
	define('CHECK_FILE_FREE_FLOW',file_exists(DEST_PATH.FILE_FREE_FLOW)?1:0);
	define('FILE_DPI', 'dpi.txt');
	define('CHECK_FILE_DPI',file_exists(DEST_PATH.FILE_DPI)?1:0);
	define('FILE_FC23_UBUNTU', 'ubuntu.txt');
	define('CHECK_FILE_FC23_UBUNTU',(trim(strtolower($json_arr['ostype']))=='ubuntu')?1:0);

	define('ARR_DEFAULT_FILE_TYPES', array('avi','mpeg','mpg','wmv','vob','mkv','prs','mp4','M4v','mov','divx','flv','rmv','rmvb','mp3','rm','wma','m4a','wav','ppt','pptx','doc','docx','wps','wpt','dot','rtf','txt','html','mht','xls','xml','ett','xlt','dbt','jpg','png','bmp','gif','tiff','svg','jpeg','pdf'));
	define('CHECK_FILE_ASSOCIATE_FILE',file_exists(DEST_PATH.FILE_ASSOCIATE_FILE)?1:0);
	define('CHECK_FILE_BROWSE_ASSOCIATE',file_exists(DEST_PATH.FILE_BROWSE_ASSOCIATE)?1:0);
	define('FILE_LYNC_ASSOCIATE', 'microsoftLyncapp.txt');
	define('CHECK_FILE_LYNC_ASSOCIATE',file_exists(DEST_PATH.FILE_LYNC_ASSOCIATE)?1:0);
	define('FILE_SKYPE_ASSOCIATE', 'skypeapp.txt');
	define('CHECK_FILE_SKYPE_ASSOCIATE',file_exists(DEST_PATH.FILE_SKYPE_ASSOCIATE)?1:0);

	//ashu
	define('FILE_USB',"USB.txt");
	define('FILE_NETWORK_PATH',"NetworkPath.txt");
	define('FILE_SHARE_DIR_PATH',"ShareDirPath.txt");
	define('FILE_FIND_WIFI',"wifie.txt");
	define('FILE_NEW_AP_CONFIG',"newapconfig.txt");
	define('SESSION_EXPIRED_MSG',"Your session has expired. Please login again.");
	define('UPLOADPATH',"media/");
	define('DATE_FORMAT',"%d/%m/%Y");
	define('FILE_DISP_ON',"dispon.txt");
	define('FILE_2955',"2955.txt");
	define('CHECK_FILE_2955',(trim(strtolower($json_arr['hardware']))=='2955')?1:0);
	define('FILE_DUAL_NETWORK',"dualnetwork.txt");

	define('FILE_HIDDEN_NETWORK',"HiddenNetwork.txt");
	define('FILE_GUEST_MODE',"guestmode.txt");
	define('FILE_CHROME_STATUS',"chromestatus.txt");
	define('FILE_DISPLAYCOUNT',"displaycount.txt");
	define('CHECK_FILE_DISPLAYCOUNT',file_exists(DEST_PATH.FILE_DISPLAYCOUNT)?1:0);
	
	define('FILE_CHROMERUN',"chromerun.txt");
	define('FILE_WIZARD',"wizard.txt");
	define('CHECK_FILE_WIZARD',file_exists(DEST_PATH.FILE_WIZARD)?1:0);
	
	define('FILE_CONNECTPLUS','connectplus.txt');
	define('CHECK_FILE_CONNECTPLUS',(trim(strtolower($json_arr['model']))=='connectplus')?1:0);	
	define('FILE_MIRACAST','miracast.txt');
	define('CHECK_FILE_MIRACAST',file_exists(DEST_PATH.FILE_MIRACAST)?1:0);
	define('CHECK__MIRACAST_SUPPORT',(trim(strtolower($arraynetworkJson['Miracast']))==1)?1:0);
	define('FILE_LG','SourceSwitch.txt');
	define('FILE_LG_OPTIONS','SwitchSource.txt');
	define('CHECK_FILE_LGOPTIONS',file_exists(DEST_PATH.FILE_LG_OPTIONS)?1:0);
	define('FILE_CHROME_PORT','chromeport.txt');
	define('FILE_CHROME_SERVER','chromeserver.txt');
	define('FILE_CHROME_HOST','chromehost.txt');
	define('FILE_VSM_STATUS','vsmstatus.txt');
	define('FILE_WUSB6300','wusb6300.txt');
	define('FILE_brains','brain.txt');
	define('FILE_BROADCAST_IP','broadcastip.txt');
	define('TEMPLATE_DIR','templatedesigner/templates/');
	define('FILE_MIRACAST_FREQUENCY','miracastband.txt');
	define('FILE_CAMPUS','campus.txt');
	define('CHECK_FILE_CAMPUS',file_exists(DEST_PATH.FILE_CAMPUS)?1:0);

	define('FILE_CAMPUS2','campus2.txt');
	define('FILE_CAMPUS2PLUS','campus2plus.txt');
	define('FILE_BRAIN_SERIAL','brainserial.txt');
	define('FILE_LIC_DETAILS','licdetails.txt');
	define('CHECK_FILE_CAMPUS2',(trim(strtolower($json_arr['model']))=='campus2')?1:0);	
	define('CHECK_FILE_CAMPUS2PLUS',(trim(strtolower($json_arr['model']))=='campus2plus')?1:0);	
	define('CHECK_FILE_CAMPUSPLUS',(trim(strtolower($json_arr['model']))=='campusplus')?1:0);

	$basepath = getcwd();
	define('PASSWORD_NOT_MATCH','Password not match');
	define('USERNAME_MIN_LENGTH','Username should contains at least 4 characters!');
	define("SPECIAL_NOT_ALLOWED","Invalid Format!.");
	//wifi files check. added on 6jan2020
	define('CHECK_WIFI_FILE',file_exists(LIN_WIFI_PATH.FILE_CHECKWIFI)?1:0);
	define('CHECK_WIFI_ONOFF',file_exists(LIN_WIFI_PATH.FILE_FIND_WIFI)?1:0);
	define('CHECK_WIFI_NEWAP_CONFIG',file_exists(LIN_WIFI_PATH.FILE_NEW_AP_CONFIG)?1:0);
	define('CHECK_DUAL_NETWORK',file_exists(DEST_PATH.FILE_DUAL_NETWORK)?1:0);
	define('FILE_APCLIENT','apclient.txt');
	define('CHECK_APICLIENT',file_exists(LIN_WIFI_PATH.FILE_APCLIENT)?1:0);
	define('CHECK_DHCP',file_exists(DEST_PATH.FILE_DHCP_FILE)?1:0);
	define('CHECK_LIC_DETAILS',file_exists(DEST_PATH.FILE_LIC_DETAILS)?1:0);
	define("LOG_URL",BASE_PATH."/data/logs/error.log");
	//File upload pathinfo   
	define("WALLPAPER_UPLOAD_PATH",BASE_PATH."/public/uploads/wallpaper");	
	define('FILE_APMODE_SSID','ssid.txt');
	define('FILE_AP_KEY','apkey.txt');
	if(PRODUCT_TYPE == 'via'){
		define('FILE_MIRRORNAME_TEXT', 'VIA_AirMirror');
	}else{
		define('FILE_MIRRORNAME_TEXT', 'Collab');
	}
	define('FILE_APMODE_CHANNEL', 'channel.txt');
	define('FILE_APMODE_ENABLE_INTERNET', 'allowinternet.txt');
	define('CHECK_ENABLE_INTERNET',file_exists(LIN_WIFI_PATH.FILE_APMODE_ENABLE_INTERNET)?1:0);
	define('FILE_APMODE_READ_STANDALONE', 'wifiOnly.txt');
	define('CHECK_APMODE_READ_STANDALONE',file_exists(LIN_WIFI_PATH.FILE_APMODE_READ_STANDALONE)?1:0);

	define('CHECK_APMODE_GUESTMODE',file_exists(LIN_WIFI_PATH.FILE_GUEST_MODE)?1:0);
	define('CHECK_HIDDEN_NETWORK',file_exists(LIN_WIFI_PATH.FILE_HIDDEN_NETWORK)?1:0);
	define('FILE_DEVICE_REGISTER', 'register.txt');
	define('CHECK_DEVICE_REGISTER',file_exists(DEST_PATH.FILE_DEVICE_REGISTER)?1:0);
	define("CERTIFICATE_UPLOAD_PATH",BASE_PATH."/public/uploads/certificate");
	define('FILE_UPDATES_AVAILABLE', 'UpdatesAvailable.txt');
	define('CHECK_FILE_UPDATES_AVAILABLE',file_exists(DEST_PATH.FILE_UPDATES_AVAILABLE)?1:0);

	define("FILE_TIMEZONE",'timezone.txt');
	define('FILE_MAC_ADDRESS','macAddrs.txt');
	define('CHECK_FILE_WUSB6300',file_exists(DEST_PATH.FILE_WUSB6300)?1:0);
	define("UPLOAD_PATH_VIA", DIR_NAME.'/'.IMG_DIR);
	if(PRODUCT_TYPE=='via' || PRODUCT_TYPE == 'vsm'){
		define('HELP_URL',"https://www1.kramerav.com/in/products/presentation-collaboration/via");
	}else{
		define('HELP_URL',"http://www.wowvision.com/products/collab8/");
	}	
	define('REDIRECT_SERVER_IP',$_SERVER['SERVER_NAME']);
	define('WIN_TABLE_COUNT',124);
	define('LIN_TABLE_COUNT',125);
	define('POLL_ENCRPTION_KEY','WOWASKSDFNSDFKEISDJAHDLDSDF1235UUUiidfsdfVISION');
	//vsm index page varaibles
	define('HOME_PG_TOPBAR_BG_COLOR','#414141');
	define('HOME_PG_WELCOME_BG_COLOR','#35ACF8');
	define('HOME_PG_SEARCHBAR_BG_COLOR','#F7F7F6');
	define('HOME_PG_VIA_LIST_BG_COLOR','#ffffff');
	define('HOME_PG_FOOTER_BG_COLOR','#414141');
	define('HOME_PG_SEARCH_VIALIST_FLAG',1);
	define('HOME_PG_INSTALL_MSG_FLAG',1);
	define('LAST_SYNC_DATE','LastSyncDate.txt');
	define('FILE_LIC_STATUS','lic_status.txt');
	define('FILE_FIREBASE','firebaseon.txt');
	define('VIA_SETTINGS_DEFAULT_JSON_FILE','settings_default.json');
	define('FILE_SYSWIZARD',"syswizard.txt");
	define('CHECK_FILE_SYSWIZARD',file_exists(DEST_PATH.FILE_SYSWIZARD)?1:0);	

	//office 365 OAuth application token
    if(file_exists(DEST_PATH."sessionmanager.json")){
    	//session manager credentials
    	define("OAUTH_APP_ID","6063225b-afdf-4f7a-b31e-cc5144e2a9d6");
    	define("OAUTH_APP_PASSWORD","ds78Q~HwkjgXSVlsPRFC9oSemoaSQajSJFCTZdcu");
    	define("OAUTH_SCOPES","https://graph.microsoft.com/.default offline_access");
	}else{
		//VIA credentials 
		define("OAUTH_APP_ID","dcf904ce-7572-40be-bfc1-2239c28b3de9");
    	define("OAUTH_APP_PASSWORD","ilr8Q~YfgeZkxdRX3Z3gzb2b_2nWlyimvmFULdtJ");
    	define("OAUTH_SCOPES","openid profile offline_access user.readwrite calendars.readwrite");
	}
    //define("OAUTH_REDIRECT_URI","https://192.168.100.114/Roombooking/Source/web/calendar2.0/callback.php");
	define("OAUTH_REDIRECT_URI","https://rbsdev.wowvision.com/getoffice365code.php");	
  	//define("OAUTH_REDIRECT_URI","https://login.microsoftonline.com/common/oauth2/nativeclient");
    define("OAUTH_AUTHORITY","https://login.microsoftonline.com/common");
    define("OAUTH_AUTHORIZE_ENDPOINT","/oauth2/v2.0/authorize");
    define("OAUTH_TOKEN_ENDPOINT","/oauth2/v2.0/token");
	
	//added missing constant by niraj on 02/03/2023
	define('FILE_REFRESHTIME',0);	
	define('FILE_STRDATETIME',0);	
	define('FILE_SECOND_DISPLAY',0);	
	define('FILE_PIP',0);	
	define('FILE_MEDIA',0);	
	define('FILE_QUICK',0);	
	define('FILE_CHKPRESENTATION_MODE',0);
	define('FILE_WIFI_QUICK_CONNECT',"wifiquickconnect.txt");

	define('FILE_WIFIDIRECT',"wifidirectsupported.txt");
	define('FILE_AP_KEY_WD',"apkeywd.txt");
	define('FILE_WD_SSID',"ssidwd.txt");
	define('FILE_WD_FEQWD',"feqwd.txt");
	define('FILE_WD_ENABLE',"wifidirectenable.txt");
	define('FILE_WD_ONLY',"wifidirectonly.txt");
	define('CHECK_CONNECT2_FILE', trim($json_arr['modellike'])==4) ? 1 : 0;
	define('FILE_SESSION_MANAGER',"sessionmanager.json");
?>