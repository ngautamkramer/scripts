<?php
ini_set('max_execution_time',0);
error_reporting(E_ALL);
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
//error_reporting(0);
putenv('GDFONTPATH=' . dirname(__FILE__));
require_once '../config/global_constants.php';
require_once '../templatedesignfunction.php';
$DBServer=HOST_NAME;
$DBUser=DB_USER;
$DBPass=DB_PASSWORD;
//database for backup 
$database='wpg';
$content_dir = dirname(__FILE__);
$domain=trim($_POST['domain_name']);
if($domain!=''){
	$domain=trim($_POST['domain_name']);
	//Production
	$cust_db_backup_path=$content_dir.'/'.$domain.'_dump.sql';
	//Development
	//$cust_db_backup_path2='../public/'.$domain.'_dump.sql';
	
	//write data into file	
	$store_domainInfo_path=$content_dir.'/cust_domain_info.txt';
	$fh = fopen($store_domainInfo_path, 'w') or die("can't open file");
	fwrite($fh, $domain);
	fclose($fh);	
	
	//database backup
	$dir = dirname(__FILE__) .'/'.$domain.'_'.date('Y-m-d').'_dump.sql';
	//Production
	//exec("C:/xampp/mysql/bin/mysqldump.exe --user={$DBUser} --password={$DBPass} --host={$DBServer} {$database} --result-file={$cust_db_backup_path} 2>&1", $output);
	exec('"C:\MySQL\MySQL Server 5.5\bin\mysqldump" -u root -p'.DB_PASSWORD.' wpg > '.$cust_db_backup_path.'');
	
	//Development
	//exec("C:/xampp/mysql/bin/mysqldump.exe --user={$DBUser} --password={$DBPass} --host={$DBServer} {$database} --result-file={$cust_db_backup_path2} 2>&1", $output);
	
	//Data backup
	require_once 'backupData.php';
	
	//execute bat files
	sleep(10);
	exec("migration_data_script.bat");

	//web service call to import database
	//Production
	$url="https://".$domain.".cloudvsm.com"."/migratedb.php";
	//Development
	//$url="http://".HOSTNAME."/VIA-VSM/migratedb.php?domain=".$domain;		
	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_SSL_VERIFYPEER=>false,
		CURLOPT_URL => $url,		
		CURLOPT_POST => 1,
		CURLOPT_POSTFIELDS => array(
			domain =>$domain,
			key=>'w0wll11ll11databasel1l1',
		)
	));
    $resp = curl_exec($curl);
	curl_close($curl);
	//delete migration script
	unlink("migration_data_script.bat");
	die('success');
}
?>