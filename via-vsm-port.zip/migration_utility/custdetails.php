<?php ini_set('max_execution_time',0);
error_reporting(E_ALL);
?>

<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en" class="app">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<title>VIA - 192.168.1.7</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- Le styles -->
<link href="<?php echo "../public/css/bootstrap-table.min.css?tc=".time(); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/stylish_checkbox.css?tc=".time();?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/via_custom.css?tc=".time(); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/bootstrap.css?tc=".time(); ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/font-awesome.min.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/js/fuelux/fuelux.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/font.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/animate.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/layout.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/app.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/jquery-ui.min.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/css/toggle_switch.css?tc=".time() ?>" media="screen" rel="stylesheet" type="text/css">
<link href="<?php echo "../public/img/VIA-Favicon.ico" ?>" rel="shortcut icon" type="/public/image/vnd.microsoft.icon">
<script type="text/javascript" src="<?php echo "../public/js/jquery.min.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/sessionout/js/jquery-idleTimeout.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/sessionout/js/store.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/sessionout/js/jquery-ui-new.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/jquery-ui.min.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/bootstrap.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/function.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/charts/easypiechart/jquery.easy-pie-chart.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/slimscroll/jquery.slimscroll.min.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/app.plugin.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/app.js?tc=".time(); ?>"></script>
<script type="text/javascript" src="<?php echo "../public/js/bootstrap-table.min.js?tc=".time(); ?>"></script>
</head>
<body class="skin-3">
<section class="vbox">
  <!--license details-->
  
  <section>
    <section class="hbox stretch">
      <section id="content">
        <!DOCTYPE html>
        <section class="vbox">
          <section class="scrollable padder">
            <div class="m-b-md heading">
              <div>
                <h3 class="m-b-none hText">Migrate Data</h3>
              </div>
            </div>
            <div class="row">
              <section class="m-t-n-md m-b-none">
                <div class="row wrapper m-sm">
                  <div class="col-md-3 top_nav p-l-none"></div>
                  <div class="col-md-6 m-t-xs"> <span id="successmsg" style="display:none;" class="text-danger text-center font-bold"></span>
                   <!-- <form method="POST" name="dataMigrationform" class="form-horizontal" id="dataMigrationform" action="<?php //echo $_SERVER['PHP_SELF'];?>">-->
                      <section id="sourceSwitch">
					  
						 <div class="row m-t-n m-r-n" id="processbar" style="height:80px" align="center">&nbsp;</div>						 
						 <div class="row text-danger m-t-n m-r-n" id="msgdiv" style="height:50px; padding-left:20px"></div>
					  
                        <div class="row">
                          <div class="form-group m-b col-md-12">
                            <fieldset class="form-group">
                            <input type="text" name="domain_name" id="domain_name" autocomplete="off" class="form-control&#x20;&#x20;styl" value="">
                            <label for="domain_name" class="animate-lbl">Domain</label>
                            </fieldset>
                            <span id="errdomain" class="text-danger pull-right m-t-n m-r-n"></span> </div>
                         </div>

<!--                        <div class="row">
                          <div class="form-group m-b col-md-12">
                            <fieldset class="form-group">
                            <input type="text" name="domain_name" id="domain_name" autocomplete="off" class="form-control&#x20;&#x20;styl" value="">
                            <label for="domain_name" class="animate-lbl">Domain</label>
                            </fieldset>
                            <span id="errip" class="text-danger pull-right m-t-n m-r-n"></span> </div>
                         </div>

                        <div class="row">
                          <div class="form-group m-b col-md-12">
                            <fieldset class="form-group">
                            <input type="text" name="domain_name" id="domain_name" autocomplete="off" class="form-control&#x20;&#x20;styl" value="">
                            <label for="domain_name" class="animate-lbl">Domain</label>
                            </fieldset>
                            <span id="errip" class="text-danger pull-right m-t-n m-r-n"></span> </div>
                         </div>

-->						 
						 
                        <div class="form-group m-b col-md-12">
                          <input type="button" class="btn btn-vialink pull-right boxEnabled m-r-n" name="migrateBtn" id="migrateBtn" value="Migrate">
                        </div>
                      </section>
                    <!--</form>-->
                  </div>
                </div>
                

              </section>
            </div>
          </section>
        </section>
        <script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','#migrateBtn',function(){		
	   	var domain_name=$('#domain_name').val();
		if(domain_name==""){
			$('#errdomain').html('Domain name is required');
			$('#domain_name').focus();
			$('#domain_name').addClass('errorClass');
			 return false;
		}else{
			var domain_name=$('#domain_name').val();
			$('#errdomain').html('');
			$('#migrateBtn').val('Please wait...');
			$('#migrateBtn').prop("disabled",true);
			$('#msgdiv').html('Please wait. We are migrating data from Prem to Cloud. It will take 3-4 hours. Also Please do not refresh the page or use back key');
			var url="custAjaxCall.php";
               $.ajax({
				   type : 'POST',
				   url:url,
				   data:'domain_name='+domain_name,
				   dataType:'html',				   
				   beforeSend : function(){
						$('#processbar').html('<img src="../public/img/bar-circle.gif" class="pull-center">');
					},				   
				   success : function(response,status,XMLHttoRequest){				   
					   //alert(response);
					   $('#processbar').html('');
					   $('#migrateBtn').val('Migrate');
					   $('#msgdiv').html('Data migrate successfully')
				   }
		     });
			
		}
		
	})

		
});

</script>
      </section>
    </section>
  </section>
</section>
<!--<div class="footerMain"><span style="font-size: 11px;">WEB-3.2.1121.821 | Model: Campus PLUS | Serial Number: C6D1-543E-A5-C2C4-858D | Copyright � 2021. All Rights Reserved. KRAMER.</span></div>-->
</body>
</html>