<?php  //Data backup
function custom_copy($src, $dst) {   
    // open the source directory
    $dir = opendir($src);   
    // Make the destination directory if not exist
    @mkdir($dst);   
    // Loop through the files in source directory
    while( $file = readdir($dir) ) {   
        if (( $file != '.' ) && ( $file != '..' )) { 
            if ( is_dir($src . '/' . $file) ){   
                // Recursively calling custom copy function
                // for sub directory 
                custom_copy($src . '/' . $file, $dst . '/' . $file);  
            } 
            else { 
                copy($src . '/' . $file, $dst . '/' . $file); 
            } 
        } 
    }   
    closedir($dir);
} 
  
$src = "../public/uploads";  
$dst = "../public/customer_backup";  

$srcRecording = "../Recording";  
$dstRecording = "../public/customer_backup/recording_backup";  
custom_copy($src, $dst);
custom_copy($srcRecording, $dstRecording);
?>