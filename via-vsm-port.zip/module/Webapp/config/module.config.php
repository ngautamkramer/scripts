<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Webapp;

return array(
    'router' => array(
        'routes' => array(  
            'homeDeafult' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Webapp\Controller\Index',
                        'action'     => 'index',
                    ),
                ),
            ),
            'Webapp' => array(
               'type'    => 'Literal',
                'options' => array(
                        'route'    => '/Webapp',
                        'defaults' => array(
                            '__NAMESPACE__' => 'Webapp\Controller',
                            'controller'    => 'Index',
                            //'action'        => 'addorganisation',
                            'action'        => 'index',
                        ),
                ), 
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:controller[/:action]]',
                            'constraints' => array(
                                    'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                    'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
			//route for via index
            'viaIndex' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/viaIndex[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ViaIndex',
                        'action'        => 'product',
                    ),
                ),
            ),
			//route for user Manager
            'viauser' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/viauser[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ViaUser',
                        'action'        => 'userList',
                    ),
                ),
            ),

            'vsmuser' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/vsmuser[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'VsmUser',
                        'action'        => 'userList',
                    ),
                ),
            ),
			
			//route for gateways
            'gateways' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/gateways[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Gateways',
                        'action'        => 'list',
                    ),
                ),
            ),
			
			//route for VSM Settings
            'groups' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/groups[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Groups',
                        'action'        => 'group-list',
                    ),
                ),
            ),
			
			//route for Screeneditor
            'screeneditor' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/screeneditor[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Screeneditor',
                        'action'        => 'templateList',
                    ),
                ),
            ),
			
			'wallpaper' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/wallpaper[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Screeneditor',
                        'action'        => 'templateList',
                    ),
                ),
            ),
			
			
			//route for reports
            'reports' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/reports[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Reports',
                        'action'        => 'viaActivity',
                   ),
		
                ),
            ),
			
			//route for reports
            'reports2' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/reports2[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Reports',
                        'action'        => 'vsmActivity',
                   ),
		
                ),
            ),
			
			//route for index Manager
            'index' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/index[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
            ),
				
			'home' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/home[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Home',
                        'action'        => 'systemInfo',
                    ),
                ),
            ),
			//route for calendar(Added by Dileep Date:25-Jan-2020)
            'calendar' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/calendar[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Calendar',
                        'action'        => 'calendarList',
                    ),
                ),
            ),
			//route for update firmware(Added by Dileep Date:28-Jan-2020)
            'firmware' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/firmware[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Firmware',
                        'action'        => 'updateFirmware',
                    ),
                ),
            ),
			
			//route for system reports
            'systemreports' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/systemreports[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Systemreports',
                        'action'        => 'Index',
                    ),
                ),
            ),



            //route for license
            'getrecording' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/getrecording[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Recording',
                        'action'        => 'recordingList',
                    ),
                ),
            ),

            //route for Modify VSM Homepage
            'homepage' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/homepage[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                     'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'HomePage',
                        'action'        => 'modify-home-page',
                    ),
                ),
            ),

            //route for license
            'license' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/license[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'License',
                        'action'        => 'licenseDetails',
                    ),
                ),
            ),

			//route for vsm settings
            'vsmsettings' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/vsmsettings[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'VsmSettings',
                        'action'        => '',
                    ),
                ),
            ),

            //route for register via unit
            'registerunit' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/registerunit[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'RegisterUnit',
                        'action'        => 'registerViaUnit',
                    ),
                ),
            ),

            //route for alert
            'alert' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/alert[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Alert',
                        'action'        => 'alertList',
                    ),
                ),
            ),


              //route for smtp
              'smtp' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/smtp[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Smtp',
                        'action'        => 'smtpConfiguration',
                    ),
                ),
            ),

            
              //route for instant alert
              'instantalert' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/instantalert[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'InstantAlert',
                        'action'        => 'emegencyAlert',
                    ),
                ),
            ),

            //route for report users
            'reportusers' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/reportusers[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ReportUsers',
                        'action'        => 'topActiveUsers',
                    ),
                ),
            ),

            //route for report feature
            'reportfeature' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/reportfeature[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ReportFeature',
                        'action'        => 'viaFeatureUsage',
                    ),
                ),
            ),

            //route for report gateways
            'reportgateways' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/reportgateways[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ReportGateways',
                        'action'        => 'mostUsedGateways',
                    ),
                ),
            ),


             //route for report via sessions
             'reportviasessions' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/reportviasessions[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ReportViaSessions',
                        'action'        => 'longestViaSessions',
                    ),
                ),
            ),

             //route for via mgmt
             'manageconfigurations' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/manageconfigurations[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ManageConfigurations',
                        'action'        => 'templateList',
                    ),
                ),
            ),
			//route for kds mgmt
             'kdsconfigurations' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/kdsconfigurations[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ManageConfigurations',
                        'action'        => 'templateList',
                    ),
                ),
            ),

            //route for web service
            'webservice' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/webservice[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Webservice',
                        'action'        => 'webserviceResponse',
                    ),
                ),
            ),

            'dss' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dss[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Dss',
                        'action'        => 'liscenceInfo',
                    ),
                ),
            ),

            'dssfont' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dssfont[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'DssFont',
                        'action'        => 'fontInfo',
                    ),
                ),
            ),

            'dsstemplate' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dsstemplate[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'DssTemplate',
                        'action'        => 'templateList',
                    ),
                ),
            ),

            'dsscontent' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dsscontent[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'DssContent',
                        'action'        => 'contentList',
                    ),
                ),
            ),
            
            'dsscampaign' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dsscampaign[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'DssCampaign',
                        'action'        => 'campaignList',
                    ),
                ),
            ),

            'dssschedule' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dssschedule[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'DssSchedule',
                        'action'        => 'scheduleList',
                    ),
                ),
            ),

            //route for network settings
            'networksettings' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/networksettings[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Networksettings',
                        'action'        => 'shownetworkSettings',
                    ),
                ),
            ),

            //route for via settings
            'viasettings' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/viasettings[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Viasettings',
                        'action'        => 'viaConfiguration',
                    ),
                ),
            ),

            //route for VIA Pad settings
            'viapad' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/viapad[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Viapad',
                        'action'        => 'viapadSettings',
                    ),
                ),
            ),

			//route for VSM Settings
            'vsm' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/vsm[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Vsm',
                        'action'        => 'vsmSettings',
                    ),
                ),
            ),
            
            //route for reports
            'utility' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/utility[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Utility',
                        'action'        => 'resetUnit',
                    ),
                ),
            ),

            'brain' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/brain[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Brain',
                        'action'        => 'uploadBrainlicense',
                    ),
                ),
            ),

            //route for display control settings
            'displaycontrol' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/displaycontrol[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Displaycontrol',
                        'action'        => 'sourceSwitch',
                    ),
                ),
            ),

            //route for services
            'services' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/services[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Services',
                        'action'        => 'createViaSettingsTemplateOnUpgrade',
                    ),
                ),
            ),
			
			
            'cloudlicense' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/cloudlicense[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'CloudLicense',
                        'action'        => 'licence',
                    ),
                ),
            ),
			
			
			
            //route for via db restore
            'dbrestore' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/dbrestore[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Dbrestore',
                        'action'        => 'index',
                    ),
                ),
            ),
             //route for gateway status by rajeev
             'vsmdashboard' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/vsmdashboard[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'VsmDashboard',
                        'action'        => 'report',
                    ),
                ),
            ),

			//route for TPA
            'thirdpartyapp' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/thirdpartyapp[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'ThirdPartyApp',
                        'action'        => 'tpaList',
                    ),
                ),
            ),
            //route for API
            'api' => array(
                'type'    => 'literal',
                'options' => array(
                    'route'    => '/api',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Api'
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'calendar-info' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/calendar-info',
                            'defaults' => array(
                                'action' => 'calendarInfo',
                            )
                        )
                    ),
                    'publish-screen' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/publish-screen',
                            'defaults' => array(
                                'action' => 'publishScreen',
                            )
                        )
                    ),
                    'launch-meeting' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/launch-meeting',
                            'defaults' => array(
                                'action' => 'launchMeeting',
                            )
                        )
                    ),
                    'screen-info' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/screen-info',
                            'defaults' => array(
                                'action' => 'screenInfo',
                            )
                        )
                    ),
                    'update-roomname' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/update-roomname',
                            'defaults' => array(
                                'action' => 'updateRoomName',
                            )
                        )
                    ),
                    'pair-via' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/pair-via',
                            'defaults' => array(
                                'action' => 'pairVia',
                            )
                        )
                    ),
                    'unpair-via' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/unpair-via',
                            'defaults' => array(
                                'action' => 'unpairVia',
                            )
                        )
                    ),
                    'settings' => array(
                        'type' => 'literal',
                        'options' => array(
                            'route' => '/settings',
                            'defaults' => array(
                                'action' => 'settings',
                            )
                        )
                    )
                )
            ),
            //route for gateway status by rajeev
            'migration' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/migration[/:action][/:id]',
                     'constraints' => array(
                     'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                      'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Webapp\Controller',
                        'controller'    => 'Migration',
                        'action'        => 'start',
                    ),
                ),
            ),

        ),
    ),
    'service_manager' => array(
        'abstract_factories' => array(
            'Zend\Cache\Service\StorageCacheAbstractServiceFactory',
            'Zend\Log\LoggerAbstractServiceFactory',
        ),
        'factories' => array(
            'translator' => 'Zend\Mvc\Service\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_file_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'Webapp\Controller\Index' => Controller\IndexController::class,
            'Webapp\Controller\ViaIndex' => Controller\ViaIndexController::class,
			'Webapp\Controller\ViaUser' => Controller\ViaUserController::class,
            'Webapp\Controller\VsmUser' => Controller\VsmUserController::class,
			'Webapp\Controller\Gateways' => Controller\GatewaysController::class,
			'Webapp\Controller\Groups' => Controller\GroupsController::class,
			'Webapp\Controller\Home' => Controller\HomeController::class,
			'Webapp\Controller\Calendar' => Controller\CalendarController::class,
            'Webapp\Controller\Screeneditor' => Controller\ScreeneditorController::class,
            'Webapp\Controller\Reports' => Controller\ReportsController::class,
            'Webapp\Controller\HomePage' => Controller\HomePageController::class,
            'Webapp\Controller\VsmSettings' => Controller\VsmSettingsController::class,
            'Webapp\Controller\License' => Controller\LicenseController::class,
            'Webapp\Controller\RegisterUnit' => Controller\RegisterUnitController::class,
            'Webapp\Controller\Alert' => Controller\AlertController::class,
            'Webapp\Controller\Smtp' => Controller\SmtpController::class,
            'Webapp\Controller\InstantAlert' => Controller\InstantAlertController::class,
            'Webapp\Controller\Recording' => Controller\RecordingController::class,
            'Webapp\Controller\ReportUsers' => Controller\ReportUsersController::class,
            'Webapp\Controller\ReportFeature' => Controller\ReportFeatureController::class,
            'Webapp\Controller\ReportGateways' => Controller\ReportGatewaysController::class,
            'Webapp\Controller\ReportViaSessions' => Controller\ReportViaSessionsController::class,
			'Webapp\Controller\ManageConfigurations' => Controller\ManageConfigurationsController::class,
			'Webapp\Controller\Firmware' => Controller\FirmwareController::class,
            'Webapp\Controller\Webservice' => Controller\WebserviceController::class,
            'Webapp\Controller\Dss' => Controller\DssController::class,
            'Webapp\Controller\DssFont' => Controller\DssFontController::class,
            'Webapp\Controller\DssTemplate' => Controller\DssTemplateController::class,
            'Webapp\Controller\DssContent' => Controller\DssContentController::class,
            'Webapp\Controller\DssCampaign' => Controller\DssCampaignController::class,
            'Webapp\Controller\DssSchedule' => Controller\DssScheduleController::class,
            'Webapp\Controller\Networksettings' => Controller\NetworksettingsController::class,
            'Webapp\Controller\Viasettings' => Controller\ViasettingsController::class,
            'Webapp\Controller\Viapad' => Controller\ViapadController::class,
            'Webapp\Controller\Vsm' => Controller\VsmController::class,
            'Webapp\Controller\Brain' => Controller\BrainController::class,
            'Webapp\Controller\Utility' => Controller\UtilityController::class,
            'Webapp\Controller\Viasettings' => Controller\ViasettingsController::class,
            'Webapp\Controller\Displaycontrol' => Controller\DisplaycontrolController::class,
            'Webapp\Controller\Services' => Controller\ServicesController::class,
            'Webapp\Controller\Dbrestore' => Controller\DbrestoreController::class,
			'Webapp\Controller\CloudLicense' => Controller\CloudLicenseController::class,
            'Webapp\Controller\VsmDashboard' => Controller\VsmDashboardController::class,
			'Webapp\Controller\ThirdPartyApp' => Controller\ThirdPartyAppController::class,
            'Webapp\Controller\Api' => Controller\ApiController::class,
            'Webapp\Controller\Migration' => Controller\MigrationController::class,
			
        ),
    ),
    'view_manager' => array(
	 'strategies' => array('ViewJsonStrategy',), 
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'Webapp/index/index' => __DIR__ . '/../view/Webapp/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
    // Placeholder for console routes
    'console' => array(
        'router' => array(
            'routes' => array(
            ),
        ),
    ),
);
