<?php 
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
$appObj = new ApplicationController();
$session = new Container('userinfo');
$screenwidth=$session->offsetGet('screenwidth');

$remainingTimeTopTextFontSize=($remainingTimeTopTextFontSize!='')?$remainingTimeTopTextFontSize:'18px';
$remainingTimeMiddleTextFontSize=($remainingTimeMiddleTextFontSize!='')?$remainingTimeMiddleTextFontSize:'36px';
$setResolutionFont=($screenwidth>1920)?72:36;
?>

         <div id="remainingTimeFeatureDiv" style="display:none; width:100%">
            <div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
                    <ul>
                        <li class="propertytab active_tab tab1 templatefamily" id="remainingTime-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>						
                        <li class="propertytab inactive_tab tab2 templatefamily" id="remainingTime-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
                    </ul>
            </div> 					
            <div class="remainingTime-1-propertytab" style='width:101%; display:block'>	  
                <table width="100%">
                    <tr style="display:none;">
                        <td width="100%" class='gridtxt' align="left" colspan="2">
                            <table width="100%" cellpadding="0" cellspacing="0">
                                    <tr height="30px">
                                            <td width="100%" colspan="2" class="gridtxt"><?php echo STR_TIMER_ON_SECOND_DISPLAY;?></td>																
                                    </tr>
                                    <tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplayTimer',$showSecondDisplayTimer,2);?></td></tr>														
                            </table>
                        </td>
                    </tr>											

                    <tr><td width="100%" colspan="2" class="gridtxt"><?php echo MSG_CHOOSE_TOP_BOTTOM_SIZE?></td></tr>
                    <tr>
                        <td width="100%" colspan="2">
                                <select name="remainingTime-1_toptextfontsize" rev='remainingTime-1_toptextfontsize' id="remainingTime-1_toptextfontsize" class="gridtxtbox changeFontcss">
                                <?php
                                foreach($fontsizeArray as $fontkey=>$fontval){
                                    $getFontIntVal=intval($fontval);
                                    if($getFontIntVal<=$setResolutionFont){
                                        $sel='';
                                        if($fontkey==$remainingTimeTopTextFontSize) $sel='selected';
                                        echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
                                    }
                                }
                                ?>																	 
                        </select>
                        </td>
                    </tr>

                    <tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>
                    <tr><td width="100%" colspan="2" class="gridtxt"><?php echo MSG_CHOOSE_MIDDLE_TEXT_FONT_SIZE; ?></td></tr>
                    <tr>
                            <td width="100%" colspan="2">
                                    <select name="remainingTime-1_middletextfontsize" rev='remainingTime-1_middletextfontsize' id="remainingTime-1_middletextfontsize" class="gridtxtbox changeFontcss">
                                    <?php
                                    foreach($fontsizeArray as $fontkey=>$fontval){
										$getFontIntVal=intval($fontval);
										if($getFontIntVal<=$setResolutionFont){
											$sel='';
											if($fontkey==$remainingTimeMiddleTextFontSize) $sel='selected';
											echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
										}
                                    }
                                    ?>																		 
                            </select>
                            </td>
                    </tr>
                </table>

            </div>
            <div id="commonProperties_remainingTime-1" class="remainingTime-1-colortab" style='width:101%; display:none'>
                    <table width="100%">
                        <tr>
                          <td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
                          <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_remainingTime-1" rel="backgroundColor_remainingTime-1" rev="<?php echo 'backgroundColor_remainingTime-1';?>" style="background:<?php echo ($remainingTimeBackgroundColor!='')?$remainingTimeBackgroundColor:'#000000'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                        </tr>
                        <tr>
                            <td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>

                            <td width="45%"><select name="remainingTime-1_opacity" rev='remainingTime-1' id="remainingTime-1_opacity" class="gridtxtbox changeOpacitycss" style="margin-left:5px;">
                                    <?php
                                    foreach($opacityArr as $val){
										$sel='';																			
										if(($val/100)==$remainingTimeOpacity) $sel='selected';
										else if(($val/100)=='0.4') $sel='selected';
                                    ?>
                                    <option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
                                    <?php } ?></select>
                            </td>
                        </tr>
                        <tr>
                          <td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
                          <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_remainingTime-1" rel="fontColor_remainingTime-1" rev="<?php echo 'fontColor_remainingTime-1';?>" style="background:<?php echo ($remainingTimeFontColor!='')?$remainingTimeFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                        </tr>
                        <tr>
                                <td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
                                <td width="45%" align="left" style="padding-left:5px"><?php echo $appObj->createOnOffToggle('remainingTime-1-bordercolornone',$remainingTimeBorderNoneChkbox,2);?></td>
                        </tr>

                        <tr id="remainingTime-1-html" style="display:none;">
                          <td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
                          <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_remainingTime-1" rel="borderColor_remainingTime-1" rev="<?php echo 'borderColor_remainingTime-1';?>" style="background:<?php echo ($remainingTimeBorderColor!='')?$remainingTimeBorderColor:$defaultBorderColor?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                        </tr>			  
                    </table>
            </div>
        </div>
