<?php 
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
$appObj = new ApplicationController();
$session = new Container('userinfo');
$screenwidth=$session->offsetGet('screenwidth');

$meetingNotifyTopTextFontSize=($meetingNotifyTopTextFontSize!='')?$meetingNotifyTopTextFontSize:'18px';
$meetingNotifyMiddleTextFontSize=($meetingNotifyMiddleTextFontSize!='')?$meetingNotifyMiddleTextFontSize:'36px';
$setResolutionFont=($screenwidth>1920)?72:36;
?>									
                                                                                
<div id="meetingNotifyFeatureDiv" style="display:none; width:100%">
   <div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
      <ul>
         <li class="propertytab active_tab tab1" id="meetingNotify-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>
         <li class="propertytab inactive_tab tab2" id="meetingNotify-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
      </ul>
   </div>
   <div class="meetingNotify-1-propertytab" style='width:101%; display:block'>
      <table width="100%">
         <tr>
            <td width="100%" colspan="2" class="gridtxt"><?php echo MSG_CHOOSE_TOP_BOTTOM_SIZE;?></td>
         </tr>
         <tr>
            <td width="100%" colspan="2">
               <select name="meetingNotify-1_toptextfontsize" rev='meetingNotify-1_toptextfontsize' id="meetingNotify-1_toptextfontsize" class="gridtxtbox changeFontcss">
               <?php
                  foreach($fontsizeArray as $fontkey=>$fontval){
					  $sel='';
					  if($fontkey==$meetingNotifyTopTextFontSize) $sel='selected';
					  echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
                  }
                  ?>																	 
               </select>
            </td>
         </tr>
         <tr height="20px">
            <td colspan="2" width="100%">
               <div style="width:90%; border-bottom: 1px solid #52555d"></div>
            </td>
         </tr>
         <tr>
            <td width="100%" colspan="2" class="gridtxt"><?php echo MSG_CHOOSE_MIDDLE_TEXT_FONT_SIZE;?></td>
         </tr>
         <tr>
            <td width="100%" colspan="2">
               <select name="meetingNotify-1_middletextfontsize" rev='meetingNotify-1_middletextfontsize' id="meetingNotify-1_middletextfontsize" class="gridtxtbox changeFontcss">
               <?php
                  foreach($fontsizeArray as $fontkey=>$fontval){
					  $sel='';
					  if($fontkey==$meetingNotifyMiddleTextFontSize || $fontkey=='36px') $sel='selected';
					  echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
                  }
                  ?>																		 
               </select>
            </td>
         </tr>
         <tr height="20px">
            <td colspan="2" width="100%">
               <div style="width:90%; border-bottom: 1px solid #52555d"></div>
            </td>
         </tr>
      </table>
      <table width="100%">
         <tr>
            <td width="100%" colspan="2" class="gridtxt"><?php echo STR_MEETING_ALERT_DISPLAY;?></td>
         </tr>
         <tr>
            <td width="100%" colspan="2">
               <?php 
                  $displayalertArr=array(3,5,10,15);
                  ?>
               <select name="meetingNotify-1_meetingalert" rev='meetingNotify-1_meetingalert' id="meetingNotify-1_meetingalert" class="gridtxtbox">
                  <?php
                     foreach($displayalertArr as $val){	
                     $sel='';
                     if($val==$meetingNotifyDisplayAlert) $sel='selected';							
                     ?>
                  <option value="<?php echo $val;?>" <?php echo $sel;?>><?php echo $val.' Minutes';?></option>
                  <?php }
                     ?>																	
               </select>
            </td>
         </tr>
         <tr style="display:none;">
            <td width="100%" class='gridtxt' align="left" colspan="2">
               <table width="100%" cellpadding="0" cellspacing="0">
                  <tr>
                     <td width="100%"><?php echo STR_SHOW_AVAILABILTY;?></td>
                  </tr>
                  <tr height="50px">
                     <td width="100%"><?php echo $appObj->createOnOffToggle('meetingNotify-1-availability',$meetingNotifyAvailability,2);?></td>
                  </tr>
               </table>
            </td>
         </tr>
      </table>
      <table width="100%" class="gridtxt" style="display:none;">
         <tr>
            <td><input name="shownotifytext" id="singleLine" value="single" class="radio3 pointer shownotifytextcss" type="radio" <?php echo ($meetingLineProperty=='single')?"checked":""; ?> ><label for="singleLine" style="vertical-align:middle"></label>&nbsp;&nbsp;Single Line</td>
            <td><input name="shownotifytext" id="multiLine" value="multiple" class="radio3 pointer shownotifytextcss" type="radio"  <?php echo ($meetingLineProperty=='multiple' || $meetingLineProperty=='')?"checked":""; ?> ><label for="multiLine" style="vertical-align:middle"></label>&nbsp;&nbsp;Multiple Line</td>
         </tr>
      </table>
   </div>
   <div id="commonProperties_meetingNotify-1" class="meetingNotify-1-colortab" style='width:101%; display:none'>
      <table width="100%">
         <tr>
            <td width="55%" class='style14'><?php echo STR_BACKGROUND_COLOR;?></td>
            <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_meetingNotify-1" rel="backgroundColor_meetingNotify-1" rev="<?php echo 'backgroundColor_meetingNotify-1';?>" style="background:<?php echo ($meetingNotifyBackgroundColor!='')?$meetingNotifyBackgroundColor:'#000000'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
         </tr>
         <tr>
            <td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>
            <td width="45%">
               <select name="meetingNotify-1_opacity" rev='meetingNotify-1' id="meetingNotify-1_opacity" class="gridtxtbox changeOpacitycss" style="margin-left:5px;">
                  <?php
                     foreach($opacityArr as $val){
                     $sel='';																			
                     if(($val/100)==$meetingNotifyOpacity) $sel='selected';
                     else if(($val/100)=='0.4') $sel='selected';
                     ?>
                  <option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
                  <?php }
                     ?>
               </select>
            </td>
         </tr>
         <tr>
            <td width="55%" class='style14'><?php echo BTN_FONT_COLOR;?></td>
            <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_meetingNotify-1" rel="fontColor_meetingNotify-1" rev="<?php echo 'fontColor_meetingNotify-1';?>" style="background:<?php echo ($meetingNotifyFontColor!='')?$meetingNotifyFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
         </tr>
         <tr>
            <td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
            <td width="45%" align="left" style="padding-left:5px">
               <?php echo $appObj->createOnOffToggle('meetingNotify-1-bordercolornone',$meetingNotifyBorderNoneChkbox,2);?>			
            </td>
         </tr>
         <tr id="meetingNotify-1-html" style="display:none;">
            <td width="55%" class='style14'><?php echo STR_BORDER_COLOR;?></td>
            <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_meetingNotify-1" rel="borderColor_meetingNotify-1" rev="<?php echo 'borderColor_meetingNotify-1';?>" style="background:<?php echo ($meetingNotifyBorderColor!='')?$meetingNotifyBorderColor:$defaultBorderColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
         </tr>
      </table>
   </div>
</div>																				
