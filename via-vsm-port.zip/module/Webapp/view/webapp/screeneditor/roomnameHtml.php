<?php 
use Webapp\Controller\ApplicationController;
$appObj = new ApplicationController();
$roomname1Fontsize=($roomname1Fontsize!='')?$roomname1Fontsize:'18px';
$roomname2Fontsize=($roomname2Fontsize!='')?$roomname2Fontsize:'18px';
$roomcodeFontsize=($roomcodeFontsize!='')?$roomcodeFontsize:'18px';
$dateFontsize=($dateFontsize!='')?$dateFontsize:'18px';
$timeFontsize=($timeFontsize!='')?$timeFontsize:'18px';
$datetimecombinedFontsize=($datetimecombinedFontsize!='')?$datetimecombinedFontsize:'18px';
$meetingTitleFontsize=($meetingTitleFontsize!='')?$meetingTitleFontsize:'18px';
$meetingNotifyTopTextFontSize=($meetingNotifyTopTextFontSize!='')?$meetingNotifyTopTextFontSize:'18px';
if(PRODUCT=='via'){
	$showHide = 'none';
	$customNameText=$file_roomnamevalueshow;
}else{
	$showHide = 'none';
	$customNameText=file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?trim($appObj->file_read(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)):'';
}

$refreshTimeArr=array(1=>1,2=>3,3=>5,4=>10,5=>20,6=>30,7=>50,8=>60);
?>
<div id="roomnameFeatureDiv" style="display:none; width:100%">
	<div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
		<ul>
			<li class="propertytab active_tab tab1" id="roomname-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>						
			<li class="propertytab inactive_tab tab2" id="roomname-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
		</ul>
	</div> 
									
	<div class="roomname-1-propertytab" style='width:101%; display:block'>
		<table width="100%">
			<tr>													
				<td width="100%" align="left" colspan="2" class="gridtxt"> <input type="text" id="roomname-1-textbox" name="roomname-1-textbox" autocomplete="off" maxlength="50" class="gridtxtbox inputBoxwidth" value="<?php echo $primaryRoomName1Text;?>" readonly="" /></td>
			</tr>												
			<tr style="display:<?php echo $showHide ?>">				  
				<td width="100%" align="left" colspan="2"><input type="text" name="roomname-1-ipAddress" id="roomname-1-ipAddress" class="gridtxtbox inputBoxwidth" placeholder="Custom Room name" maxlength="50" value="<?php //echo $customNameText;?>" />&nbsp;</td>				  
			</tr>													
			
			<tr style="display:none;">
				<td width="70%" class='gridtxt' align="left"><?php echo STR_SHOW_ROOM_NAME_WALLPAPER;?></td>
				<td width="30%" align="left"><input type="checkbox" name="showRoomName" id="showRoomName" rel="showRoomName" rev="showRoomName" value="<?php echo $activate_RoomName;?>" class="chkbox makeDisabled" <?php echo ($activate_RoomName==1)?'checked':'';?> /><label for="showRoomName"><span></span></label></td>
			</tr>
			
			<?php if(PRODUCT_TYPE=="vsm" || GET_OS=='WIN'){?>	
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
							<td width="100%" colspan="2"><?php echo STR_TEMPLATE_ROOM_NAME_SECOND_DISPLAY;?></td>
						</tr>
					<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplay',$activate_RoomName_SecondDisplay,2);?></td></tr>
					</table>
				</td>											
				
			</tr>
			<tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>										
			<?php }?>
			                                    
			<tr height="20px"><td width="100%" colspan="2" class='gridtxt'>
				<table width="100%">
					<tr height="30px"><td width="100%" colspan="2"><strong><?php echo STR_ROOM_NAME_OVERLAY;?></strong></td></tr>
					<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_ACTIVATE;?></td></tr>
					<tr height="4px"></tr>
					<tr>																
						<td width="100%" colspan="2">
							<?php
							  $overlayValuesArr=array('Always show','Auto hide in 20 sec','Show only with DSS');  
						  ?>															
							<div class="custom-control custom-switch">
								<input type="checkbox" class="custom-control-input overlayCss" name="getOverlay" id="getOverlay" <?php echo ($activateRoomOverlay==1)?'checked':''; ?> >
								<label class="custom-control-label" for="getOverlay"></label>
								&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span id="ss2Help" class="userTooltip" rev="ss2Help" rel="<?php echo TOOLTIP_OVERLAY;?>" style="font-size:14px; font-weight:bold; cursor:pointer; color:#B2B9BF; margin-top: 2px;position: absolute;">?</span>
							</div>	
						</td>
					</tr>															
					<tr height="3px"></tr>
					<tr><td width="100%" colspan="2" align="left" class='gridtxt'><?php echo STR_AUTO_HIDE;?></td></tr>
						
					<tr>																
						<td width="100%" colspan="2">																			
							<select name="autoHideDD" id="autoHideDD" disabled="disabled" class="gridtxtbox enabledElements makeDisabled" style="padding: 5px 5px 5px 5px;">
							 <?php foreach($overlayValuesArr as $overlayKey=>$overlayVal){
								$overlaySel="";
								if($RoomOverlayValue==$overlayKey) $overlaySel='selected';
								echo "<option $overlaySel value='$overlayKey'>$overlayVal</option>";
							  }?>
							</select>
						</td>
					</tr>	
				</table>
				</td></tr>	
				<tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>															
				<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td></tr>
				<tr>
					<td width="100%" colspan="2">
						<select name="roomname-1_fontsize" rev='roomname-1' id="roomname-1_fontsize" class="gridtxtbox changeFontcss">
						<?php
						foreach($fontsizeArray as $fontkey=>$fontval){
							$sel='';
							if($fontkey==$roomname1Fontsize) $sel='selected';
							echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
						} ?>																	 
						</select>
					</td>
				</tr>
				<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_TEXT_ALIGNMENT;?></td></tr>
				<tr>																
					<td width="100%" colspan="2">
						<select name="roomname-1_align" rev='roomname-1' id="roomname-1_align" class="gridtxtbox changeAligncss">																
						<?php
							foreach($textalignArray as $alignkey=>$alignval){
								$sel='';
								if($alignkey==$roomname1txtAlign) $sel='selected';
								echo '<option value='.$alignkey.' '.$sel.'>'.$alignval.'</option>';
							}
							?>			
						</select>
					</td>
				</tr>		
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
							<td width="100%" colspan="2"><?php echo STR_AUTO_RESIZE;?></td>
						</tr>
						<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('roomName1AutoResize',$roomname1AutoResize,2);?></td></tr>
					</table>
				</td>
			</tr>
	 </table>	
	 </div>
	 <div id="commonProperties_roomname-1" class="roomname-1-colortab">					
		<table width="100%">										
			<tr>
			  <td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
			  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_roomname-1" rel="backgroundColor_roomname-1" rev="<?php echo 'backgroundColor_roomname-1';?>" style="background:<?php echo $getroomname1BackgroundColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
			<tr><td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>													
				<td width="45%"><?php //echo $roomname1Opacity;?>
					<select name="roomname-1_opacity" rev='roomname-1' id="roomname-1_opacity" class="gridtxtbox changeOpacitycss" <?php echo ($getroomname1BackgroundColor=='transparent')?'disabled':'';?> style="margin-left:5px;">
						<?php
						foreach($opacityArr as $val){																	
							$sel='';
							if(($val/100)==$roomname1Opacity) $sel='selected';
						?>
							<option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
						<?php }
						?>																
					</select>
				</td>
			</tr>
			<tr>
			  <td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
			  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_roomname-1" rel="fontColor_roomname-1" rev="<?php echo 'fontColor_roomname-1';?>" style="background:<?php echo ($roomname1FontColor!='')?$roomname1FontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
			<tr>
				<td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
				<td width="45%" align="left" style="padding-left:5px">
				<?php echo $appObj->createOnOffToggle('roomname-1-bordercolornone',$roomname1BorderNoneChkbox,2);?>
				</td>
			</tr>								
			<tr id="roomname-1-html" style="display:none;">
			  <td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
			  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_roomname-1" rel="borderColor_roomname-1" rev="<?php echo 'borderColor_roomname-1';?>" style="background:<?php echo ($roomname1BorderColor!='')?$roomname1BorderColor:$defaultBorderColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
		</table>
	</div>								
</div>
									
<div id="roomname2FeatureDiv" style="display:none; width:100%">
	<div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
		<ul>
			<li class="propertytab active_tab tab1" id="roomname-2-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>						
			<li class="propertytab inactive_tab tab2" id="roomname-2-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
		</ul>
	</div> 
	<div class="roomname-2-propertytab" style='width:101%; display:block'>		
		<table width="100%">
			<tr>
				<td width="100%" align="left" colspan="2" class="gridtxt"><input type="text" id="roomname-2-textbox" name="roomname-2-textbox" autocomplete="off" maxlength="50" class="gridtxtbox inputBoxwidth" value="<?php echo $secondayRoomNameText;?>"/></td>
			</tr>
			<?php if(PRODUCT_TYPE=="vsm" || GET_OS=='WIN'){?>							
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr height="30px">
							<td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_ROOM_NAME_SECOND_DISPLAY;?></td>																
						</tr>
						<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplayroomname2',$showSecondDisplayroomname2,2);?></td></tr>														
					</table>
				</td>
			</tr>											
			<?php }?>
			<tr style="display:none;">
			  <td width="70%" class='gridtxt'><?php echo STR_SHOW_ROOM_NAME_WALLPAPER;?></td>
			  <td width="30%"><input type="checkbox" name="showRoomName2" id="showRoomName2" rel="showRoomName2" rev="showRoomName2" value="<?php echo $activate_RoomName2;?>" class="chkbox makeDisabled" <?php echo ($activate_RoomName2==1)?'checked':'';?> />
				<label for="showRoomName2"><span></span></label></td>
			</tr>
			<tr style="display:none;">
			  <td width="100%" align="left" colspan="2"><input type="text" name="roomname-2-ipAddress" id="roomname-2-ipAddress" class="chkbox enableIPBox gridtxtbox inputBoxwidth" placeholder="Custom Roomname" maxlength="50" disabled="disabled"/>
				&nbsp; </td>
			</tr>								
			<tr>
				<td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td>
			</tr>
			<tr>
				<td width="100%" colspan="2">
					<select name="roomname-2_fontsize" rev='roomname-2' id="roomname-2_fontsize" class="gridtxtbox changeFontcss">
					<?php
					foreach($fontsizeArray as $fontkey=>$fontval){
						$sel='';
						if($fontkey==$roomname2Fontsize) $sel='selected';
						echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
					}
					?>
				  </select>
				</td>
			</tr>
			<tr>
				<td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_TEXT_ALIGNMENT;?></td>
			</tr>
			<tr>
				<td width="100%" colspan="2">
					<select name="roomname-2_align" rev='roomname-2' id="roomname-2_align" class="gridtxtbox changeAligncss">
					<?php
					foreach($textalignArray as $alignkey=>$alignval){
						$sel='';
						if($alignkey==$roomname2txtAlign) $sel='selected';
						echo '<option value='.$alignkey.' '.$sel.'>'.$alignval.'</option>';
					} ?>
				   </select>
				</td>
			</tr>
											  
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
							<td width="100%" colspan="2"><?php echo STR_AUTO_RESIZE;?></td>
						</tr>
						<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('roomName2AutoResize',$roomname2AutoResize,2);?></td></tr>
					</table>
				</td>
			</tr>
		</table>
	</div> 
										  
	<div id="commonProperties_roomname-2" class="roomname-2-colortab">
		<table width="100%">
			<tr>
				<td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
				<td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_roomname-2" rel="backgroundColor_roomname-2" rev="<?php echo 'backgroundColor_roomname-2';?>" style="background:<?php echo $getroomname2BackgroundColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
			<tr>
				<td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>
				<td width="45%" >
					<select name="roomname-2_opacity" rev='roomname-2' id="roomname-2_opacity" class="gridtxtbox changeOpacitycss" <?php echo ($getroomname2BackgroundColor=='transparent')?'disabled':'';?> style="margin-left:5px;">
						<?php
							foreach($opacityArr as $val){
								$sel='';																		
								if(($val/100)==$roomname2Opacity) $sel='selected';
							?>
						<option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
						<?php }
							?>
					</select>
				</td>
			</tr>
			<tr>
				<td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
				<td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_roomname-2" rel="fontColor_roomname-2" rev="<?php echo 'fontColor_roomname-2';?>" style="background:<?php echo ($roomname2FontColor!='')?$roomname2FontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
			<tr>
				<td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
				<td width="45%" align="left" style="padding-left:5px">
				<?php echo $appObj->createOnOffToggle('roomname-2-bordercolornone',$roomname2BorderNoneChkbox,2);?>		
				</td>
			</tr>
		   <tr id="roomname-2-html" style="display:none;">
				<td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
				<td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_roomname-2" rel="borderColor_roomname-2" rev="<?php echo 'borderColor_roomname-2';//$readfile_strDateTime;?>" style="background:<?php echo ($roomname2BorderColor!='')?$roomname2BorderColor:$defaultBorderColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		  </tr>
		  
		</table>
	</div>
	<?php if(PRODUCT=='via'){ ?>
	<br><br>
	<div class="templatefamily templateFontsize15px"><div style="border-bottom: 1px solid #52555d;"></div><br><?php echo '<span class="text-green note-span">'.MSG_LINK6_NOTE.'</span>'.STR_ROOM_NAME2_NOTE;?></div>
<?php } ?>
</div>

<div id="roomcodeFeatureDiv" style="display:none; width:100%">
	<div class="tab_section" id="tab_section" style='width:101%; display:block;'>
		<ul>
			<li class="propertytab active_tab tab1" id="roomcode-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>						
			<li class="propertytab inactive_tab tab2" id="roomcode-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
		</ul>
	</div>

	<div class="roomcode-1-propertytab" style='width:101%; display:block'>
		<table width="100%">
			<tr><td width="100%" align="left" colspan="2"> <input type="text" id="roomcode-1-textbox" name="roomcode-1-textbox" autocomplete="off" maxlength="50" class="gridtxtbox inputBoxwidth" placeholder="Roomcode Text" value="<?php echo ($roomcodeTextBoxVal!='')?$roomcodeTextBoxVal:'Code:#roomcode#';?>"/></td></tr>
			<tr style="display:none;">
				<td width="80%" class='gridtxt'><?php echo $CONF_RoomName_TxtChkBox2;?></td>
				<td width="20%"><input type="checkbox" name="activationRoomCode" id="activationRoomCode" rel="activationRoomCode" rev="activationRoomCode" value="<?php echo $activate_RoomCode;?>" class="chkbox makeDisabled" <?php //echo ($activate_RoomCode==1)?'checked':'';?> checked="checked" /><label for="activationRoomCode"><span></span></label></td>
			</tr>

	<?php if(PRODUCT_TYPE=="vsm" || GET_OS=='WIN'){?>										
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2"><?php echo STR_TEMPLATE_ROOM_CODE_SECOND_DISPLAY;?></td>											
			</tr>										
			<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showRoomcodeSecondDisplay',$roomcodeShowDualDisplay,2);?></td></tr>		
			<?php }?>
			<tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>
			<tr style="display:block;">				
				<td width="100%" class='gridtxt' colspan="2"><?php echo STR_ALWAYS_SHOW_WALLPAPER;?> &nbsp;</td>													
			</tr>
			<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('alwaysShowOnWallp',$activate_ShowOnWallpaper,2);?></td></tr>
			<tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>
			<tr><td width="100%" class='gridtxt' colspan="2"><?php echo STR_ROOM_CODE_REFRESH_TIME;?></td></tr>
			<tr>
				<td width="100%" colspan="2">
					<select id="refreshTime" name="refreshTime" rel="refreshTime" rev="refreshTime" class="gridtxtbox pointer makeDisabled activationRoomCodeGrouping" <?php echo ($activate_RoomCode==0)?'disabled':'';?>>
					  <?php 
						foreach($refreshTimeArr as $arrval){
							$sel='';
							if(empty($roomcoderefreshTime) && $arrval==3) $sel='selected';
							if($roomcoderefreshTime==$arrval) $sel='selected';
							echo "<option value='$arrval' ".$sel.">$arrval</option>";
						}?>
					</select>
				</td>
			</tr>
			<tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>
			<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td></tr>
			<tr>
				<td width="100%" colspan="2">
					<select name="roomcode-1_fontsize" rev='roomcode-1' id="roomcode-1_fontsize" class="gridtxtbox changeFontcss">
					<?php 
					foreach($fontsizeArray as $fontkey=>$fontval){
						$sel='';
						if($fontkey==$roomcodeFontsize) $sel='selected';
						echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
					}
					?>
				</select>
				</td>
			</tr>
			<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_TEXT_ALIGNMENT;?></td></tr>
			<tr>																
				<td width="100%" colspan="2">
					<select name="roomcode-1_align" rev='roomcode-1' id="roomcode-1_align" class="gridtxtbox changeAligncss">
					<?php
						foreach($textalignArray as $alignkey=>$alignval){
							$sel='';
							if($alignkey==$roomcodetxtAlign) $sel='selected';
							echo '<option value='.$alignkey.' '.$sel.'>'.$alignval.'</option>';
						}
						?>
					</select>
				</td>
			</tr>
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
							<td width="100%" colspan="2"><?php echo STR_AUTO_RESIZE;?></td>
						</tr>
						<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('roomcodeAutoResize',$roomcodeAutoResize,2);?></td></tr>
					</table>
				</td>
			</tr>
		</table>
	</div>
	
	<div id="commonProperties_roomcode-1" class="roomcode-1-colortab">							
		<table width="100%">										
			<tr>
			  <td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
			  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_roomcode-1" rel="backgroundColor_roomcode-1" rev="<?php echo 'backgroundColor_roomcode-1';?>" style="background:<?php echo $getroomcodeBackgroundColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
			<tr><td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>								
				<td width="45%">
					<select name="roomcode-1_opacity" rev='roomcode-1' id="roomcode-1_opacity" class="gridtxtbox changeOpacitycss" <?php echo ($getroomcodeBackgroundColor=='transparent')?'disabled':'';?> style="margin-left:5px;">
						<?php
						foreach($opacityArr as $val){
							$sel='';																		
							if(($val/100)==$roomcodeOpacity) $sel='selected';
						?>
							<option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
						
						<?php }
						?>																
					</select>
				</td>
			</tr>
			<tr>
				<td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
				<td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_roomcode-1" rel="fontColor_roomcode-1" rev="<?php echo 'fontColor_roomcode-1';?>" style="background:<?php echo ($roomcodeFontColor!='')?$roomcodeFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
			<tr>
				<td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
				<td width="45%" align="left" style="padding-left:5px;">
				<?php echo $appObj->createOnOffToggle('roomcode-1-bordercolornone',$roomcodeBorderNoneChkbox,2);?>
				</td>
			</tr>
													
			<tr id="roomcode-1-html" style="display:none;">
			  <td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
			  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_roomcode-1" rel="borderColor_roomcode-1" rev="<?php echo 'borderColor_roomcode-1';//$readfile_strDateTime;?>" style="background:<?php echo ($roomcodeBorderColor!='')?$roomcodeBorderColor:$defaultBorderColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
			</tr>
		</table>
	</div>								
</div>
														
<div id="dateTimeFeatureDiv" style="display:none; width:100%">
	<div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
		<ul>
			<li class="propertytab active_tab tab1" id="datetime-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>						
			<li class="propertytab inactive_tab tab2" id="datetime-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
		</ul>
	</div> 
	
	<div class="datetime-1-propertytab" style='width:101%; display:block'>
	  <table width="100%">
	  <?php if(PRODUCT_TYPE=="vsm" || GET_OS=='WIN'){?>
		<tr>
			<td width="100%" class='gridtxt' align="left" colspan="2">
				<table width="100%" cellpadding="0" cellspacing="0">
					<tr height="30px">
						<td width="100%" colspan="2" class="gridtxt"><?php echo STR_DATE_DUAL_DISPLAY;?></td>																
					</tr>
					<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplayDate',$showSecondDisplayDate,2);?></td></tr>														
				</table>
			</td>
		</tr>
		<?php }?>
		<tr><td colspan="2" width="100%" class="gridtxt"><?php echo STR_CHOOSE_DATE_FORMAT;?></td></tr>
		<tr>
			<td colspan="2" width="100%">
				<select name="datetime-1_dateformat" rev='datetime-1' id="datetime-1_dateformat" class="gridtxtbox inputBoxwidth changeDateformatcss">
					 <option value="<?php echo 'DD/MM/YYYY';?>" <?php echo ($getdateformat=='DD/MM/YYYY')?'selected':'';?>>DD MON, YYYY</option>
					 <option value="<?php echo 'MM/DD/YYYY';?>" <?php echo ($getdateformat=='MM/DD/YYYY')?'selected':'';?>>MON DD, YYYY</option>
					 <option value="<?php echo 'DD/MM';?>" <?php echo ($getdateformat=='DD/MM')?'selected':'';?>>DD MON</option>	
					 <option value="<?php echo 'MM/DD';?>" <?php echo ($getdateformat=='MM/DD')?'selected':'';?>>MON DD</option>																
				</select>
			</td>
		</tr>
		<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td></tr>
		<tr>
			<td width="100%" colspan="2">
				<select name="datetime-1_fontsize" rev='datetime-1' id="datetime-1_fontsize" class="gridtxtbox changeFontcss">
				<?php
				foreach($fontsizeArray as $fontkey=>$fontval){
					$sel='';
					if($fontkey==$dateFontsize) $sel='selected';
					echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
				}
				?>
			</select>
			</td>
		</tr>
		<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_TEXT_ALIGNMENT;?></td></tr>
		<tr>																
			<td width="100%" colspan="2">
			<select name="datetime-1_align" rev='datetime-1' id="datetime-1_align" class="gridtxtbox changeAligncss">
				<?php
					foreach($textalignArray as $alignkey=>$alignval){
						$sel='';
						if($alignkey==$datetxtAlign) $sel='selected';
						echo '<option value='.$alignkey.' '.$sel.'>'.$alignval.'</option>';
					}
					?>
			</select>
			
			</td>
		</tr>
		<tr>
			<td width="100%" class='gridtxt' align="left" colspan="2">
				<table width="100%" cellpadding="0" cellspacing="0">
					<tr>
						<td width="100%" colspan="2"><?php echo STR_AUTO_RESIZE;?></td>
					</tr>
					<tr height="50px"><td width="100%"><?php echo $appObj->createOnOffToggle('dateAutoResize',$dateAutoResize,2);?></td></tr>
				</table>
			</td>
		</tr>										

		<tr style="display:none;">
			<td width="80%" class='gridtxt'><?php echo 'Show Date on wallpaper';?>&nbsp;</td>
			<td width="20%"><input type="checkbox" name="showDateTime" id="showDateTime" rel="showDateTime" rev="showDateTime" value="<?php echo $activate_DateTime;?>" class="chkbox makeDisabled" <?php echo ($activate_DateTime==1)?'checked':'';?> /><label for="showDateTime"><span></span></label></td>
		</tr>
	  </table>
	</div> 

	<div id="commonProperties_datetime-1" class="datetime-1-colortab">
									
	  <table width="100%">										
		<tr>
		  <td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
		  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_datetime-1" rel="backgroundColor_datetime-1" rev="<?php echo 'backgroundColor_datetime-1';//$readfile_strDateTime;?>" style="background:<?php echo $getdateBackgroundColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		</tr>
		<tr><td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>								
			<td width="45%">
			<select name="datetime-1_opacity" rev='datetime-1' id="datetime-1_opacity" class="gridtxtbox changeOpacitycss" <?php echo ($getdateBackgroundColor=='transparent')?'disabled':'';?> style="margin-left:5px;">
				<?php
				foreach($opacityArr as $val){

					$sel='';																	
					if(($val/100)==$dateOpacity) $sel='selected';
				?>
					<option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
				
				<?php }
				?>
																				
			</select>
			
			</td>
		</tr>
																	<tr>
		  <td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
		  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_datetime-1" rel="fontColor_datetime-1" rev="<?php echo 'fontColor_datetime-1';//$readfile_strDateTime;?>" style="background:<?php echo ($dateFontColor!='')?$dateFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		</tr>
		<tr>
			<td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
			<td width="45%" align="left" style="padding-left:5px"><!--<input type="checkbox" name="datetime-1-bordercolornone" id="datetime-1-bordercolornone" rel="datetime-1-bordercolornone" rev="datetime-1-bordercolornone" value="0" class="chkbox borderchkboxcss"  <?php echo ($dateBorderNoneChkbox==1)?'checked':'';?>/><label for="datetime-1-bordercolornone"><span></span></label>-->
			<?php echo $appObj->createOnOffToggle('datetime-1-bordercolornone',$dateBorderNoneChkbox,2);?>																	
			</td>
		</tr>															
												
		<tr id="datetime-1-html" style="display:none;">
		  <td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
		  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_datetime-1" rel="borderColor_datetime-1" rev="<?php echo 'borderColor_datetime-1';//$readfile_strDateTime;?>" style="background:<?php echo ($dateBorderColor!='')?$dateBorderColor:$defaultBorderColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		</tr>
	  </table>
	</div>	
</div>
														
<div id="timeFeatureDiv" style="display:none; width:100%">
	<div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
		<ul>
			<li class="propertytab active_tab tab1" id="time-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>						
			<li class="propertytab inactive_tab tab2" id="time-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
		</ul>
	</div> 
												
	<div class="time-1-propertytab" style='width:101%; display:block'>
		<table width="100%">
		<?php if(PRODUCT_TYPE=="vsm" || GET_OS=='WIN'){?>	
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr height="30px">
							<td width="100%" colspan="2" class="gridtxt"><?php echo STR_SHOW_TIME_DISPLAY;?></td>																
						</tr>
						<tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplayTime',$showSecondDisplayTime,2);?></td></tr>														
					</table>
				</td>											
			</tr>											
			<?php }?>																											  
			<tr><td colspan="2" width="100%" class="gridtxt"><?php echo STR_CHOOSE_TIME_FORMAT;?></td></tr>
			<tr>
				<td colspan="2" width="100%">
					<select name="time-1_timeformat" rev='time-1' id="time-1_timeformat" class="gridtxtbox changeTimeformatcss">
						 <option value="<?php echo '24hours';?>" <?php echo ($gettimeformat=='24hours')?'selected':'';?>>24 Hours</option>
						 <option value="<?php echo 'AM/PM';?>" <?php echo ($gettimeformat=='AM/PM')?'selected':'';?>>AM/PM</option>
					</select>
				</td>
			</tr>
			<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td></tr>
			<tr>
				<td width="100%" colspan="2">
					<select name="time-1_fontsize" rev='time-1' id="time-1_fontsize" class="gridtxtbox changeFontcss">
					<?php
					foreach($fontsizeArray as $fontkey=>$fontval){
						$sel='';
						if($fontkey==$timeFontsize) $sel='selected';
						echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
					}
					?>
				</select>
				</td>
			</tr>
			<tr><td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_TEXT_ALIGNMENT;?></td></tr>
			<tr>																
				<td width="100%" colspan="2">
				<select name="time-1_align" rev='time-1' id="time-1_align" class="gridtxtbox changeAligncss">
					<?php
						foreach($textalignArray as $alignkey=>$alignval){
							$sel='';
							if($alignkey==$timetxtAlign) $sel='selected';
							echo '<option value='.$alignkey.' '.$sel.'>'.$alignval.'</option>';
						}
						?>
				</select>
				
				</td>
			</tr>
			<tr>
				<td width="100%" class='gridtxt' align="left" colspan="2">
					<table width="100%" cellpadding="0" cellspacing="0">
						<tr>
							<td width="100%" colspan="2"><?php echo STR_AUTO_RESIZE;?></td>
						</tr>
						<tr height="50px"><td width="100%"><?php echo $appObj->createOnOffToggle('timeAutoResize',$timeAutoResize,2);?></td></tr>
					</table>
				</td>
			</tr>										
			
			<tr style="display:none;">
			  <td width="80%" class='gridtxt'><?php echo 'Show Time on wallpaper';?>&nbsp;</td>
				<td width="20%"><input type="checkbox" name="showTime" id="showTime" rel="showTime" rev="showTime" value="<?php echo $activate_Time;?>" class="chkbox makeDisabled" <?php echo ($activate_Time==1)?'checked':'';?> /><label for="showTime"><span></span></label></td>
			</tr>
		</table>
	</div>  
										
	<div id="commonProperties_time-1" class="time-1-colortab">								
	  <table width="100%">										
		<tr>
		  <td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
		  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_time-1" rel="backgroundColor_time-1" rev="<?php echo 'backgroundColor_time-1';//$readfile_strDateTime;?>" style="background:<?php echo $gettimeBackgroundColor?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		</tr>
		<tr><td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>								
			<td width="45%">
				<select name="time-1_opacity" rev='time-1' id="time-1_opacity" class="gridtxtbox changeOpacitycss" <?php echo ($getdateBackgroundColor=='transparent')?'disabled':'';?> style="margin-left:5px;">
					<?php
					foreach($opacityArr as $val){
						$sel='';
						if(($val/100)==$timeOpacity) $sel='selected';
					?>
						<option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
					
					<?php }
					?>																
				</select>
			</td>
		</tr>
		<tr>
		  <td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
		  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_time-1" rel="fontColor_time-1" rev="<?php echo 'fontColor_time-1';?>" style="background:<?php echo ($timeFontColor!='')?$timeFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		</tr>
		<tr>
			<td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
			<td width="45%" align="left" style="padding-left:5px">
			<?php echo $appObj->createOnOffToggle('time-1-bordercolornone',$timeBorderNoneChkbox,2);?>
			</td>
		</tr>
												
		<tr id="time-1-html" style="display:none;">
		  <td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
		  <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_time-1" rel="borderColor_time-1" rev="<?php echo 'borderColor_time-1';//$readfile_strDateTime;?>" style="background:<?php echo ($timeBorderColor!='')?$timeBorderColor:$defaultBorderColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
		</tr>
	  </table>
	</div>
</div>
														
																																																			