<?php

   $meetingTitleFontsize=($meetingTitleFontsize!='')?$meetingTitleFontsize:'18px';
   $meetingFontSize=($meetingFontSize!='')?$meetingFontSize:'18px';
   $setResolutionFont=36;
   if($session->offsetGet('screenwidth')>=1280 && $session->offsetGet('screenwidth')<1366){
   	$setResolutionFont=18;
   }elseif($session->offsetGet('screenwidth')>=1366 && $session->offsetGet('screenwidth')<1920){
   	$setResolutionFont=22;
   }
   
   //$setResolutionFont=($session['screenwidth']>=1920)?36:22;
       if(!isset($_POST['btnOk']) || isset($_POST['btnExchangeOk'])){
	   		/*$propertiesDataArr=$appObj->returnQueryData('SELECT * FROM tbl_calendar_properties');
	   		
            $propertiesData = mysql_query("SELECT * FROM tbl_calendar_properties");
			 if(count($propertiesDataArr) > 0){
			 	foreach($propertiesDataArr as $propertiesData){
					 $inusecolorcal=$propertiesData['inuse_color'];
					 $availablecolorcal=$propertiesData['available_color'];
					 $upcomingcolorcal=$propertiesData['upcoming_color'];
					 $upcomingfontcolorcal=$propertiesData['upcoming_font_color'];
					 $inusefontcolorcal=$propertiesData['inuse_font_color'];
					 $availablefontcolorcal=$propertiesData['available_font_color'];
					 $showtitlecal=$propertiesData['show_title'];
					 $showorgnizercal=$propertiesData['show_orgnizer'];
					 $calShowVal=$propertiesData['show_on_via'];
					 $noofrecordscal=$propertiesData['show_no_of_record'];	
					 			
				}
			 }
			 if($inusecolorcal==""){$inusecolorcal='#F74D6B';}if($availablecolorcal==""){$availablecolorcal='#32CD32';}if($upcomingcolorcal==""){$upcomingcolorcal='#C0C0C0';}
			 if($upcomingfontcolorcal==""){$upcomingfontcolorcal='#FFFFFF';}if($inusefontcolorcal==""){$inusefontcolorcal='#FFFFFF';}
			 if($availablefontcolorcal==""){$availablefontcolorcal='#FFFFFF';}
			 if($noofrecordscal==""){$noofrecordscal=3;}if($calShowVal==""){$calShowVal=0;}*/
   	
			 $resultDataArr=$appObj->returnQueryData('SELECT * FROM tbl_calender_account');
			 $count=count($resultDataArr);
			 if($templateid!=''){
			 	 if(PRODUCT!='vsm'){				
					 $activeTempSqlArr=$appObj->returnQueryData("SELECT status FROM tbl_templates WHERE id=".trim($templateid));				 
					 foreach($activeTempSqlArr as $activeTempData){
						 $activeTemp= $activeTempData['status'];
					 }
				 }
			 }	 
       }
	   
   ?>
<div id="upcomingMeetingProperties" style="display:none;">
<div class="tab_section" id="tab_section" style='width:101%; display:block; height:60px;'>
   <ul>
      <li class="propertytab active_tab tab1 templatefamily" id="meeting-1-propertytab"><span><?php echo STR_PROPERTIES;?></span></li>
      <li class="propertytab inactive_tab tab2 templatefamily" id="meeting-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
   </ul>
</div>
<div class="meeting-1-propertytab" style='width:101%; display:block'>
	<table width="100%">
		<tr>													
			<td width="100%" align="left" colspan="2" class="gridtxt"> <input type="text" id="meeting-1-textbox" name="meeting-1-textbox" autocomplete="off" maxlength="25" class="gridtxtbox inputBoxwidth" value="<?php echo $meeting_1_text;?>" /></td>
		</tr>												
		
        <?php if($getOS=='WIN' || PRODUCT=='vsm'){ ?>
        <tr style="display:none;">
           <td width="100%" class='gridtxt' align="left" colspan="2">
              <table width="100%" cellpadding="0" cellspacing="0">
                 <tr height="30px">
                    <td width="100%" colspan="2" class="gridtxt"><?php echo STR_CAL_CODE_DUAL_DISPLAY;?></td>
                 </tr>
                 <tr height="50px"><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplayCal',$showSecondDisplayCal,2);?></td></tr>
              </table>
           </td>
        </tr>
        <?php } ?>

        <tr><td colspan="2" width="100%" class="gridtxt"><?php echo STR_CHOOSE_TIME_FORMAT;?></td></tr>
        <tr>
           <td colspan="2" width="100%">
              <select name="meetingtitle-1_timeformat" rev='meetingtitle-1' id="meetingtitle-1_timeformat" class="gridtxtbox">
                 <option value="24" <?php echo ($meetingtimeformat==24)?'selected':'';?>>24 Hours</option>
                 <option value="12" <?php echo ($meetingtimeformat==12)?'selected':'';?>>AM/PM</option>
              </select>
           </td>
        </tr>

        <tr>
           <td colspan="2" class="gridtxt" style="padding-left:5px"><?php echo STR_SHOW_TITLE;?></td>
        </tr>
      									
        <tr><td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showTitleBtn',$meetingShowTitle,2);?></td></tr>

        <tr height="5px"><td colspan="2" width="100%"></td></tr>
        <tr>
           <td colspan="2" class="gridtxt" style="padding-left:5px"><?php echo STR_SHOW_ORGANIZER;?></td>
        </tr>															
        <tr>
           <td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showOrgBtn',$meetingOrganisor,2);?></td>
        </tr>
        <!--<tr height="10px"></tr>-->
        <tr style="display:none;">
           <td class="gridtxt" width="60%" style="padding-left:5px"><?php echo 'Show Calendar on VIA';?></td>
           <td width="40%"><input type="checkbox" name="showcalonvia" id="showcalonvia" rev="showcalonvia" rel="showcalonvia" <?php echo ($showcalonvia==1)?'checked':'';?>><label for="showcalonvia"><span></span></label>

           </td>
        </tr>
        <tr height="5px"><td colspan="2" width="100%"></td></tr>
        <tr>
           <td width="100%" class='gridtxt' colspan="2"><?php echo STR_NO_OF_DISPLAY_RECORD;?></td>
        </tr>

        <tr>
           <td width="100%" colspan="2">
              <select name="showEventsRecords" id="showEventsRecords" class="gridtxtbox">
                 <option value="3" <?php echo ($meetingRecords==3)?'selected':''?>>3</option>
                 <option value="5" <?php echo ($meetingRecords==5)?'selected':''?>>5</option>
              </select>
           </td>
        </tr>

        <tr>
           <td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td>
        </tr>
        <tr>
           <td width="100%" colspan="2"><select name="meetingtitle-1_fontsize" rev='meeting-1' id="meetingtitle-1_fontsize" class="gridtxtbox changeFontcss">
              <?php 
                 foreach($fontsizeArray as $fontkey=>$fontval){
                    $getFontIntVal=intval($fontval);
                    if($getFontIntVal<=$setResolutionFont){
                      $sel='';
                     if($fontkey==$meetingTitleFontsize) $sel='selected';
                      echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
                   }
                 }
                 ?>
              </select>
           </td>
        </tr>

        <tr style="display:none;"><td width="100%" colspan="2" class="gridtxt"><?php echo STR_CAL_MEETING_FONT_SIZE;?></td></tr>
        <tr style="display:none;">
           <td width="100%" colspan="2">
              <select name="meeting-1_meetingfontsize" rev='meeting-1_meetingfontsize' id="meeting-1_meetingfontsize" class="gridtxtbox changeFontcss">																	
              <?php
                 //Warning remove: check array condition 20-may-2019 
                 if(is_array($calendarFontsizeArray)){
                 foreach($calendarFontsizeArray as $fontkey=>$fontval){
                        $sel='';
                        if($fontkey==$meetingFontSize) $sel='selected';
                        echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
                 }}
                 ?>
              </select>
           </td>
        </tr>
		<?php if(PRODUCT=='via'){ ?>
        <tr height="20px">
           <td colspan="2" width="100%">
              <div style="width:90%; border-bottom:1px solid #52555d"></div>
           </td>
        </tr>
		<?php } ?>
    </table>
	<?php if(PRODUCT=='via'){ ?>
        <div class="googletab show_tab showdisable">
           <table width="100%" id="calTable">
              <tr>
                 <td colspan="2" valign="middle">
                    <span class="templateNoteColor fontSize14px fontFamily1" id="caleSettingNote"> </span>
                 </td>
              </tr>
               <tr height="20px"><td></td></tr>
              <?php if($count > 0){ 
					$rsltTokenArr=$appObj->returnQueryData("SELECT id FROM tbl_access_token");
					$accountCount=count($rsltTokenArr);
					if($accountCount > 0){

						$rsltCalArr=$appObj->returnQueryData("SELECT name,convert_from(decrypt(email,'".POLL_ENCRYPTION_KEY."','aes'),'utf-8') as email,account_type FROM tbl_calendars INNER JOIN tbl_calender_account ON tbl_calender_account.account_id=tbl_calendars.account_id");
						
                  if(count($rsltCalArr) > 0){
							//$calType=STR_GOOGLE;
							foreach($rsltCalArr as $rsltCalData){
							  $uname=$rsltCalData['name'];
							  $gmail=$rsltCalData['email'];
							  $accountType=$rsltCalData['account_type'];
							  if($accountType==1){
							 	 $calType=STR_GOOGLE;
							  }
							  if($accountType==2){
							  	$calType='Office 365';
							  }
							  if($accountType==4){
							  	$calType='Office 365 OAuth 2.0';
							  }
							  
							}
							
						}else{
							 $appObj->truncateTable('tbl_calendars');
							 $appObj->truncateTable('tbl_access_token');
							 $appObj->truncateTable('tbl_calender_account');
							 header("location:templatedesignupdate.php?id=$_GET[id]&destWidth=$destWidth;&destHeight=$destHeight");
						}
					}else{
						$rsltArr=$appObj->returnQueryData("SELECT convert_from(decrypt(tbl_calender_account.email,'".POLL_ENCRYPTION_KEY."','aes'),'utf-8') as email, convert_from(decrypt(tbl_calender_account.password,'".POLL_ENCRYPTION_KEY."','aes'),'utf-8') as password,tbl_calendars.name,tbl_calender_account.permission_type,tbl_calender_account.account_type FROM tbl_calender_account LEFT JOIN tbl_calendars ON tbl_calendars.account_id=tbl_calender_account.account_id");
						foreach($rsltArr as $rsltData){
							 $calType=STR_OFFICE365_BASIC_AUTH;
							 $uname=$rsltData['email'];
							 $calpassword=$rsltData['password'];
							 $calname=$rsltData['name'];
							 $permissionType=$rsltData['permission_type'];
							 $accountType=$rsltData['account_type'];
											
							 if($permissionType==1){
								 $permissonShowTxt=STR_IMPERSONATION;
							 }else if($permissionType==2){
								 $permissonShowTxt=STR_DELEGATE;
							 }else{
								 $permissonShowTxt="";
							 }

							 if($accountType==3){
								 $calType=STR_MS_EXCHANGE;
								 $serverDataArr=$appObj->returnQueryData("SELECT host_url,version FROM tbl_host_url ORDER BY id DESC LIMIT 1");
								 foreach($serverDataArr as $serverData){
									$hostServerURL=$serverData['host_url'];
									$hostServerVersion=$serverData['version'];
								 }
							 }
						}                   
					}  
					
            ?>
             
              <tr>
                 <td valign="middle" width='100%' align="left"><span class="gridtxt"><?php echo STR_CALENDAR_TYPE;?></span> </td>
              </tr>
              <tr>
                 <td  width='100%' style="color:#FFF;"> <span class="gridtxt"><?php echo $calType; ?> </span></td>
              </tr>
              <?php if(strtolower($calType) == "google" || strtolower($calType) =="office 365 oauth 2.0"){ ?> 
              <tr height="10px"></tr>
              <tr>
                 <td valign="middle" align="left"><span class="gridtxt">
                    <?php echo STR_USERMAME; ?>
                    </span>
                 </td>
              </tr>
              <tr>
                 <td style="color:#FFF;"> <span class="gridtxt"><?php echo $gmail; ?></span> </td>
              </tr>
              <?php } ?>
              <?php if($accountType==3){ ?>
              <tr height="10px"></tr>
              <tr>
                 <td valign="middle" align="left"><span class="gridtxt">
                    <?php echo STR_MS_EXCHANGE_SERVER_URL; ?>
                    </span>
                 </td>
              </tr>
              <tr>
                 <td  style="color:#FFF;"> <span class="gridtxt"><?php echo $hostServerURL; ?></span> </td>
              </tr>
              <?php } ?>	
              <tr height="10px"></tr>
              <tr>
                 <td valign="middle" align="left"><span class="gridtxt">
                    <?php if(strtolower($calType) =="google" || strtolower($calType) =="office 365 oauth 2.0"){ 
                       echo STR_TEMP_DESIGN_CALENDAR; 
                       }else{
                       echo STR_USERMAME ;
                       } 	
                       ?>
                    </span>
                 </td>
              </tr>
              <tr>
                 <td style="color:#FFF;"> <span class="gridtxt"> <?php echo $uname; ?></span> </td>
              </tr>
              <?php if($calname){ ?>
              <tr height="5px"></tr>
              <tr>
                 <td valign="middle" align="left"><span class="gridtxt">
                    <?php echo STR_RESOURCE_CALENDAR; ?>
                    </span>
                 </td>
              </tr>
              <tr>
                 <td style="color:#FFF;"> <span class="gridtxt"> <?php echo $calname; ?></span> </td>
              </tr>
              <?php } ?>
              <?php if($permissonShowTxt){ ?>
              <tr height="5px"></tr>
              <tr>
                 <td valign="middle" width='100%' align="left"> <span class="gridtxt">
                    <?php echo STR_PERMISSION_TYPE; ?>
                    </span>
                 </td>
              </tr>
              <tr>
                  <td  width='100%' style="color:#FFF;">  <span class="gridtxt"><?php echo $permissonShowTxt; ?></span> </td>
              </tr>
              <?php } ?>
              <tr height="5px"></tr>
              <tr>
                 <td valign="middle" align="left"><input type="button" class="resetcalendar makedisable btn-via-secondary btnWidth194Px gridtxtbox gridtxt" style="width:142px;" value="<?php echo STR_RESET_ACCOUNT; ?>">
                 </td>
              </tr>
              <tr>
                 <td align="left">
                    <?php if(strtolower($calType) !="google" && strtolower($calType) !="office 365 oauth 2.0"){ ?>                    
                    <input name="hosturl" type="hidden" value="<?php echo $hostServerURL;?>" id="hosturl" />
                    <input name="exchangeVer" type="hidden"  value="<?php echo $hostServerVersion;?>" id="exchangeVer" />
                    <input name="caluserid" type="hidden" value="<?php echo $uname;?>" id="caluserid" />
                    <input name="caluserpass" type="hidden"  value="<?php echo $calpassword;?>" id="caluserpass" />
                    <?php }
					
					if(strtolower($calType) !="google" && strtolower($calType) !="office 365 oauth 2.0"){ ?>
                    <input value="Test Connection" id="testBtn" class="btn-via-border-default btnWidth194Px makedisable gridtxtbox gridtxt" type="button" style="width:142px;">
                    
                    <?php } ?> 
                 </td>
              </tr>
              <?php }else{ ?>
              <tr>
                 <td width="100%" colspan="2">
                    <form name="calform" method="post" action="<?php $_SERVER["PHP_SELF"] ?>" id="calform" autocomplete="off">
                       <table width="100%">
                          <tr>
                             <td valign="middle" width='100%' align="left"><span class="gridtxt"><?php echo STR_CALENDAR_TYPE;?></span> </td>
                          </tr>
                          <tr>
                             <td  width='100%' align="left">
                                <select id="calType" name="calType" class="mytxtbox btnHeight30Px makedisable gridtxtbox gridtxt" style="width:250px;">                                   
                                   <option value="msexchange"><?php echo STR_MS_EXCHANGE; ?></option>
                                   <option value="google"><?php echo STR_GOOGLE; ?></option>
								   <option value="office365auth2"><?php echo STR_OFFICE365; ?></option>
                                </select>
                             </td>
                          </tr>
                          
                          <tr>
                             <td colspan="2" width="100%">
                                <div class="googlecls" style="display:none; width:100%">
                                   <table width="100%">
                                      <tr>
                                         <td valign="middle" width='100%' style="padding-top:7px;"><span class="gridtxt"><?php echo STR_STEP1; ?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%'><span class="gridtxt"><a href="<?php echo $this->url('calendar', array('action' => 'accountLogin'));?>" target="_blank" style="color: #399ffe"><?php echo STR_CLICK_GET_CODE; ?></a></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" width='100%' style="padding-top:7px;"><span class="gridtxt"><?php echo STR_STEP2; ?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%'><input name="code" type="text" placeholder="Please enter the code*" id="code" class="mytxtbox btnHeight30Px steptwo gridtxtbox gridtxt" style="width: 250px;" />
                                         </td>
                                      </tr>
                                     
                                      <tr>
                                         <td width='100%'>
                                            <input type="button" value="<?php echo STR_GET_CALENDAR; ?>" class="btn-via-border-default btnWidth93Px btnHeight32Px getCodeClass steptwo" style="width:132px;">
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" width='100%' style="padding-top:7px;"><span class="gridtxt"><?php echo STR_STEP3; ?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%'>
                                            <select id="selCal" name="selCal" class="mytxtbox btnHeight30Px stepthree gridtxtbox gridtxt" style="width: 250px;">
                                               <option name="" value="" ><?php echo STR_SELECT_CALENDER; ?></option>
                                            </select>
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td width='100%'>
                                            <input type="button" value="<?php echo STR_ASSOCIATE; ?>" class="btn-via-border-default btnWidth93Px btnHeight32Px associateCal stepthree" style="width:132px;">
                                         </td>
                                      </tr>
                                   </table>
                                </div>
                                <div class="officecls" style="display: none">
                                   <table width="100%">
                                      <tr>
                                         <td valign="middle" width='100%' align="left"><span class="gridtxt"><?php echo STR_USERMAME;?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%' align="left"><input name="caluserid" type="text" maxlength="100" value="<?php echo $usernamecal;?>" id="caluserid" class="mytxtbox btnHeight30Px makedisable gridtxtbox gridtxt"  autocomplete="off" style="width: 250px;"/>
                                            <span id="erruname" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_PASSWORD;?></span></td>
                                      </tr>
                                      <tr>
                                         <td  align="left"><input name="caluserpass" type="password" maxlength="50" value="<?php echo $passwordcal;?>" id="caluserpass" class="mytxtbox democsspass btnHeight30Px makedisable gridtxtbox gridtxt"  autocomplete="off" style="width: 250px;"/>
                                            <span class="icon" style="vertical-align:middle;"><img src="<?php echo PUBLIC_URL.'/img/passwordView.png'?>" style="cursor:pointer;"></span>
                                            <span id="errpassword" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_PERMISSION_TYPE;?></span> </td>
                                      </tr>
                                      <tr>
                                         <td align="left">
                                            <select id="access_type" name="access_type" class="mytxtbox btnHeight30Px makedisable gridtxtbox gridtxt" style="width: 250px;">
                                               <option value=0><?php echo STR_ATD_NONE; ?></option>
                                               <option value=1><?php echo STR_IMPERSONATION; ?></option>
                                               <option value=2><?php echo STR_DELEGATE; ?></option>
                                            </select>
                                            &nbsp;&nbsp;<span id="ss2Help" class="userTooltip" rev="ss2Help" rel="<?php echo STR_OFFICE_ACCOUNT_PERMISSION;?>" style="font-size:14px; font-weight:bold; cursor:pointer; color:#B2B9BF">?</span>
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_RESOURCE_CALENDAR;?></span> </td>
                                      </tr>
                                      <tr>
                                         <td align="left"><input name="calname" type="text" maxlength="50" id="calname" class="makedisable gridtxtbox gridtxt"  autocomplete="off" placeholder="Ex. democalendar@wow.com" disabled style="width:250px;box-shadow: inset 0 1px 3px #ddd;"/>
                                            <span id="errcalname" class="registererror"></span> 
                                           
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td colspan="2" width="100%">
                                            <input type="button" name="btnOk" value="<?php echo STR_BTN_TEST_SAVE;?>" id="btnOk" class="btn-via-border-default btnWidth93Px btnHeight32Px makedisable" style="width:132px;" />&nbsp;&nbsp;&nbsp;
                                         </td>
                                      </tr>
                                   </table>
                                </div>
                                <!-- Conditions for exchange -->
                                <div class="exchangecls" style="display:block;">
                                   <table width="100%">
                                      <tr>
                                         <td valign="middle" width='100%' align="left"><span class="gridtxt"><?php echo STR_MS_EXCHANGE_SERVER_URL;?>*</span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%' align="left">
                                            <input name="hosturl" type="text" maxlength="255" id="hosturl" class="mytxtbox btnHeight30Px gridtxtbox gridtxt" style="width: 250px;"/>
                                            <span id="errhosturl" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_MS_EXCHANGE_VERSION;?></span> </td>
                                      </tr>
                                      <tr>
                                         <td align="left">
                                            <select name="exchangeVer" id="exchangeVer" class="mytxtbox btnHeight30Px makedisable gridtxtbox gridtxt" style="width: 250px;">
                                               <!--<option value=""><?php echo STR_SELECT; ?></option>-->
                                               <?php 
											  	 $getCalDataArr=$appObj->returnQueryData("SELECT exchange_verison,exchange_name FROM tbl_exchange_version WHERE status=1");
												 if(count($getCalDataArr)>0){
												 	foreach($getCalDataArr as $getCalData){?>
														<option value="<?php echo $getCalData['exchange_name']; ?>"><?php echo $getCalData['exchange_verison']; ?></option>
													<?php }
												 }                       
                          ?>
                                        </select>
                                            <span id="errhostverison" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_USERMAME;?>*</span> </td>
                                      </tr>
                                      <tr>
                                         <td align="left"><input name="caluserid1" type="text" maxlength="50" value="<?php echo $usernamecal;?>" id="caluserid1" class="mytxtbox btnHeight30Px makedisable gridtxtbox gridtxt"  autocomplete="off" style="width: 250px;"/>
                                            <span id="erruname1" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle"  align="left"><span class="gridtxt"><?php echo STR_PASSWORD;?>*</span></td>
                                      </tr>
                                      <tr>
                                         <td align="left"><input name="caluserpass1" type="password" maxlength="50" value="<?php echo $passwordcal;?>" id="caluserpass1" class="mytxtbox democsspass btnHeight30Px makedisable gridtxtbox gridtxt"  autocomplete="off" style="width: 250px;"/>
                                            <span class="icon2" style="vertical-align:middle;"><img src="<?php echo PUBLIC_URL.'/img/passwordView.png'?>" style="cursor:pointer;"></span>
                                            <span id="errpassword1" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_PERMISSION_TYPE;?></span> </td>
                                      </tr>
                                      <tr>
                                         <td align="left">
                                            <select id="access" name="access" class="mytxtbox btnHeight30Px makedisable gridtxtbox gridtxt" style="width: 250px;">
                                               <option value=0><?php echo STR_ATD_NONE; ?></option>
                                               <option value=1><?php echo STR_IMPERSONATION; ?></option>
                                               <option value=2><?php echo STR_DELEGATE; ?></option>
                                            </select>
                                            &nbsp;&nbsp;<span id="ss2Help" class="userTooltip" rev="ss2Help" rel="<?php echo STR_EXCHANGE_ACCOUNT_PERMISSION_TYPE;?>" style="font-size:14px; font-weight:bold; cursor:pointer; color:#B2B9BF">?</span>
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" align="left"><span class="gridtxt"><?php echo STR_RESOURCE_CALENDAR;?></span> </td>
                                      </tr>
                                      <tr>
                                         <td align="left"><input name="calname1" type="text" maxlength="50" id="calname1" class="makedisable gridtxtbox gridtxt"  autocomplete="off" placeholder="Ex. democalendar@wow.com" disabled style="width: 250px;"/>
                                            <span id="errcalname" class="registererror"></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td colspan="2" width="100%">
                                            <input type="button" name="btnExchangeOk" value="<?php echo 'Test & Save';?>" id="btnExchangeOk" class="btn-via-border-default btnWidth93Px btnHeight32Px makedisable"  style="width:132px;"/>&nbsp;&nbsp;&nbsp;
                                         </td>
                                      </tr>
                                   </table>
                                </div>
								
								

		<div class="office365auth2cls" style="display:none; width:100%">
                                   <table width="100%">
                                      <tr>
                                         <td valign="middle" width='100%' style="padding-top:7px;"><span class="gridtxt"><?php echo STR_STEP1; ?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%'><span class="gridtxt"><a href="<?php echo BASE_URL."/calendar2.0/auth.php "?>" target="_blank" style="color: #399ffe;"><?php echo "Get Office 365 OAuth 2.0"; ?></a></span> 
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" width='100%' style="padding-top:7px;"><span class="gridtxt"><?php echo STR_STEP2; ?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%'><input name="office365code" type="text" placeholder="Please enter the code*" id="office365code" class="mytxtbox btnHeight30Px office365auth2steptwo gridtxtbox gridtxt" style="width: 250px;" />
                                         </td>
                                      </tr>
                                     
                                      <tr>
                                         <td width='100%'>
                                            <input type="button" value="<?php echo STR_GET_CALENDAR; ?>" class="btn-via-border-default btnWidth93Px btnHeight32Px getoffice365CodeClass office365auth2steptwo" style="width:132px;">
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td valign="middle" width='100%' style="padding-top:7px;"><span class="gridtxt"><?php echo STR_STEP3; ?></span> </td>
                                      </tr>
                                      <tr>
                                         <td width='100%'>
                                            <select id="selOffice365Cal" name="selOffice365Cal" class="mytxtbox btnHeight30Px office365stepthree gridtxtbox gridtxt" style="width: 250px;">
                                               <option name="" value="" ><?php echo STR_SELECT_CALENDER; ?></option>
                                            </select>
                                         </td>
                                      </tr>
                                      
                                      <tr>
                                         <td width='100%'>
                                            <input type="button" value="<?php echo STR_ASSOCIATE; ?>" class="btn-via-border-default btnWidth93Px btnHeight32Px associateOffice365Cal office365auth2stepthree" style="width:132px;">
                                         </td>
                                      </tr>
                                   </table>
                                </div>

								
								
                             </td>
                          </tr>
                       </table>
                       <input type="hidden" name="_csrf_token" value="<?php echo md5(time()); ?>"/>
                    </form>
                 </td>
              </tr>
              <?php } ?>
           </table>
        </div>
        <?php } ?>
      </div>
    
      <div id="commonProperties_meeting-1" class="meeting-1-colortab" style='width:101%; display:none'>
         <table width="100%">
            <tr>
               <td colspan="2" width="100%">
                  <!--<fieldset class="fieldsetCss">-->
                  <table width="100%">
																
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_BACKGROUND_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_meeting-1" rel="backgroundColor_meeting-1" rev="<?php echo 'backgroundColor_meeting-1';?>" style="background:<?php echo ($getmeetingBackgroundColor=='')?'#000000':$getmeetingBackgroundColor;?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
                                                                                                                                    
                     <tr>
                        <td width="60%" class="gridtxt"><?php echo STR_OPACITY;?></td>
                        <td width="40%" ><select name="meeting-1_opacity" rev='meeting-1' id="meeting-1_opacity" class="gridtxtbox changeOpacitycss" style="width: 100px;margin-left:10px;">
                              <?php 
                                 foreach($opacityArr as $val){
                                 $sel='';																		
                                 if(($val/100)==$meetingOpacity) $sel='selected';
                                 ?>
                              <option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
                              <?php }
                                 ?>
                           </select>
                        </td>
                     </tr>
																
                     <tr>
																	<td width="60%" class='gridtxt'><?php echo STR_MEETING_TITLE_FONT_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_meetingtitle-1" rel="fontColor_meetingtitle-1" rev="<?php echo 'fontColor_meetingtitle-1';?>" style="background:<?php echo ($meetingTitleFontColor!='')?$meetingTitleFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
                  </table>
                  <!--</fieldset>-->
               </td>
            </tr>
															
            <tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom:1px solid #52555d"></div></td></tr>
            
            <tr>
               <td colspan="2" width="100%">
          			<table width="100%" border="0" cellpadding="0" cellspacing="0">
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_IN_USE_EVENTS_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="inusecolorSpan" rel="inusecolorSpan" rev="<?php echo 'inusecolorSpan';//$readfile_strDateTime;?>" style="background:<?php echo ($meetinginuseEventsColor!='')?$meetinginuseEventsColor:'#F74D6B'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
																	
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_CAL_INUSE_EVENTS_FONT_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="inusefontcolorSpan" rel="inusefontcolorSpan" rev="<?php echo 'inusefontcolorSpan';//$readfile_strDateTime;?>" style="background:<?php echo ($meetinginusefontcolor!='')?$meetinginusefontcolor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
                     
                     <tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom:1px solid #52555d"></div></td></tr>
                     
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_CAL_AVAIL_EVENTS_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="availablecolorSpan" rel="availablecolorSpan" rev="<?php echo 'availablecolorSpan';//$readfile_strDateTime;?>" style="background:<?php echo ($meetingavailableEventsColor!='')?$meetingavailableEventsColor:'#32CD32'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_AVAILABLE_MEETINGS_FONT_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="availablefontcolorSpan" rel="availablefontcolorSpan" rev="<?php echo 'availablefontcolorSpan';//$readfile_strDateTime;?>" style="background:<?php echo ($meetingavailablefontcolor!='')?$meetingavailablefontcolor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
                     
					<tr height="20px"><td colspan="2" width="100%"><div style="width:90%; border-bottom: 1px solid #52555d"></div></td></tr>
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_MEETING_BAR_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="upcomingcolorSpan" rel="upcomingcolorSpan" rev="<?php echo 'upcomingcolorSpan';//$readfile_strDateTime;?>" style="background:<?php echo ($meetingupcomingEventsColor!='')?$meetingupcomingEventsColor:'#C0C0C0'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>
                     
                     <tr>
                        <td width="60%" class='gridtxt'><?php echo STR_CAL_UPCOMING_EVENTS_FONT_COLOR;?></td>
                        <td width="40%" style="padding-left:10px"><span class="<?php echo $colPickCss;?> makeDisabled" id="upcomingfontcolorSpan" rel="upcomingfontcolorSpan" rev="<?php echo 'upcomingfontcolorSpan';//$readfile_strDateTime;?>" style="background:<?php echo ($meetingupcomingfontColor!='')?$meetingupcomingfontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
                     </tr>	
                  </table>
                  <!--</fieldset>-->
               </td>											
            </tr>												
         </table>
      </div>
    <br><br>
       </div>
      <input type="hidden" name="calSettingMsgTxt" id="calSettingMsgTxt" value="<?php echo STR_CALENDAR_CONFIGURATION;?>" />
      <input type="hidden" name="jqryMsgEntrName" id="jqryMsgEntrName" value="<?php echo $jqryMsgEntrName;?>" />
      <input type="hidden" name="calType" id="calType" value="<?php echo $calType;?>" />
      <input type="hidden" name="templateId" id="templateId" value="<?php echo $_GET['id'];?>" />
      <input type="hidden" name="destWidth" id="destWidth" value="<?php echo $destWidth;?>" />
      <input type="hidden" name="destHeight" id="destHeight" value="<?php echo $destHeight;?>" />
      <input type="hidden" name="activeTemp" id="activeTemp" value="<?php echo $activeTemp;?>" />
      
      <style>
         #calname::placeholder { /* Firefox, Chrome, Opera */ 
         color: rgb(191, 189, 189); 
         }  
         #calname:-ms-input-placeholder { /* Internet Explorer 10-11 */ 
         color: rgb(191, 189, 189); 
         } 
         #calname::-ms-input-placeholder { /* Microsoft Edge */ 
         color: rgb(191, 189, 189); 
         }
         #calname1::placeholder { /* Firefox, Chrome, Opera */ 
         color: rgb(191, 189, 189); 
         } 
         #calname1:-ms-input-placeholder { /* Internet Explorer 10-11 */ 
         color: rgb(191, 189, 189); 
         }
         #calname1::-ms-input-placeholder { /* Microsoft Edge */ 
         color: rgb(191, 189, 189); 
         }
      </style>
      
      