<?php 
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
$appObj = new ApplicationController();
$datetimecombinedFontsize=($datetimecombinedFontsize!='')?$datetimecombinedFontsize:'18px';
?>

<div id="datetimecombinedFeatureDiv" style="display:none; width:100%">
   <div class="tab_section" id="tab_section" style='width:100%; display:block; height:60px;'>
      <ul>
         <li class="propertytab active_tab tab1 templatefamily" id="datetimecombined-1-propertytab"><span><?php echo STR_TEMPLATE_PROPERTY_TAB;?></span></li>
         <li class="propertytab inactive_tab tab2 templatefamily" id="datetimecombined-1-colortab"><span><?php echo STR_TEMPLATE_COLOR_TAB;?></span></li>
      </ul>
   </div>
   <div class="datetimecombined-1-propertytab" style='width:101%; display:block'>
      <table width="100%">
         <?php if(PRODUCT_TYPE=="vsm" || GET_OS=='WIN'){?>
         <tr>
            <td width="100%" class='gridtxt' align="left" colspan="2">
               <table width="100%" cellpadding="0" cellspacing="0">
                  <tr height="30px">
                     <td width="100%" colspan="2" class="gridtxt"><?php echo STR_DATE_TIME_DUAL_DISPLAY;?></td>
                  </tr>
                  <tr height="50px">
                     <td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('showSecondDisplayDatetimeCombined',$showSecondDisplayDatetimeCombined,2);?></td>
                  </tr>
               </table>
            </td>
         </tr>
         <?php } ?>
         <tr>
            <td colspan="2" width="100%" class="gridtxt"><?php echo STR_CHOOSE_TIME_FORMAT;?></td>
         </tr>
         <tr>
            <td colspan="2" width="100%">
               <select name="datetimecombined-1_timeformat" rev='datetimecombined-1' id="datetimecombined-1_timeformat" class="gridtxtbox changeTimeformatcss">
                  <option value="<?php echo '24hours';?>" <?php echo ($getdatetimecombinedformat=='24hours')?'selected':'';?>>24 Hours</option>
                  <option value="<?php echo 'AM/PM';?>" <?php echo ($getdatetimecombinedformat=='AM/PM')?'selected':'';?>>AM/PM</option>
               </select>
            </td>
         </tr>
         <tr>
            <td width="100%" colspan="2" class="gridtxt"><?php echo STR_PLEASE_CHOOSE_FONTSIZE;?></td>
         </tr>
         <tr>
            <td width="100%" colspan="2">
               <select name="datetimecombined-1_fontsize" rev='datetimecombined-1' id="datetimecombined-1_fontsize" class="gridtxtbox changeFontcss">
               <?php
                  foreach($fontsizeArray as $fontkey=>$fontval){
                  		$sel='';
                  		if($fontkey==$datetimecombinedFontsize) $sel='selected';
                  		echo '<option value='.$fontkey.' '.$sel.'>'.$fontkey.'</option>';
                  }
                  ?>																	 
               </select>
            </td>
         </tr>
         <tr>
            <td width="100%" colspan="2" class="gridtxt"><?php echo STR_TEMPLATE_TEXT_ALIGNMENT;?></td>
         </tr>
         <tr>
            <td width="100%" colspan="2">
               <select name="datetimecombined-1_align" rev='datetimecombined-1' id="datetimecombined-1_align" class="gridtxtbox changeAligncss">
               <?php
                  foreach($textalignArray as $alignkey=>$alignval){
                  	$sel='';
                  	if($alignkey==$datetimecombinedtxtAlign) $sel='selected';
                  	echo '<option value='.$alignkey.' '.$sel.'>'.$alignval.'</option>';
                  }
                  ?>
               </select>
            </td>
         </tr>
         <tr>
            <td width="100%" class='gridtxt' align="left" colspan="2">
               <table width="100%" cellpadding="0" cellspacing="0">
                  <tr>
                     <td width="100%" class='gridtxt'><?php echo STR_AUTO_RESIZE;?></td>
                     <!--<td width="10%"><input type="checkbox" name="datetimeAutoResize" id="datetimeAutoResize" rel="datetimeAutoResize" rev="datetimeAutoResize" class="chkbox makeDisabled" <?php echo ($datetimecombinedAutoResize==1)?'checked':'';?> /><label for="datetimeAutoResize"><span></span></label></td>-->
                  </tr>
                  <tr height="50px">
                     <td colspan="2" width="100%"><?php echo $appObj->createOnOffToggle('datetimeAutoResize',$datetimecombinedAutoResize,2);?></td>
                  </tr>
               </table>
            </td>
         </tr>
      </table>
   </div>
   <div id="commonProperties_datetimecombined-1" class="datetimecombined-1-colortab" style='width:101%; display:none'>
      <table width="100%">
         <tr>
            <td width="55%" class='gridtxt'><?php echo BTN_BACK_COLOR;?></td>
            <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="backgroundColor_datetimecombined-1" rel="backgroundColor_datetimecombined-1" rev="<?php echo 'backgroundColor_datetimecombined-1';//$readfile_strDateTime;?>" style="background:<?php echo ($datetimecombinedBackgroundColor!='')?$datetimecombinedBackgroundColor:'transparent'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
         </tr>
         <tr>
            <td width="55%" class="gridtxt"><?php echo STR_OPACITY;?></td>
            <td width="45%">
               <select name="datetimecombined-1_opacity" rev='datetimecombined-1' id="datetimecombined-1_opacity" class="gridtxtbox changeOpacitycss" <?php echo ($getdatetimecombinedBackgroundColor=='transparent')?'disabled':'';?> style="width: 100px;margin-left:5px;">
                  <?php
                     foreach($opacityArr as $val){
                     	$sel='';
                     	if(($val/100)==$datetimecombinedOpacity) $sel='selected';
                     ?>
                  <option value="<?php echo ($val/100);?>" <?php echo $sel;?>><?php echo $val.'%';?></option>
                  <?php }
                     ?>
               </select>
            </td>
         </tr>
         <tr>
            <td width="55%" class='gridtxt'><?php echo BTN_FONT_COLOR;?></td>
            <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="fontColor_datetimecombined-1" rel="fontColor_datetimecombined-1" rev="<?php echo 'fontColor_datetimecombined-1';//$readfile_strDateTime;?>" style="background:<?php echo ($datetimecombinedFontColor!='')?$datetimecombinedFontColor:'#ffffff'?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
         </tr>
         <tr>
            <td width="55%" class='gridtxt' align="left"><?php echo STR_BORDER;?></td>
            <td width="45%" align="left" style="padding-left:5px">
				<?php echo $appObj->createOnOffToggle('datetimecombined-1-bordercolornone',$datetimecombinedBorderNoneChkbox,2);?>
            </td>
         </tr>
         <tr id="datetimecombined-1-html" style="display:none;">
            <td width="55%" class='gridtxt'><?php echo STR_BORDER_COLOR;?></td>
            <td width="45%"><span class="<?php echo $colPickCss;?> makeDisabled" id="borderColor_datetimecombined-1" rel="borderColor_datetimecombined-1" rev="<?php echo 'borderColor_datetimecombined-1';//$readfile_strDateTime;?>" style="background:<?php echo ($datetimecombinedBorderColor!='')?$datetimecombinedBorderColor:$defaultBorderColor?>; width:25px; height:25px; no-repeat; cursor:pointer"></span></td>
         </tr>
      </table>
   </div>
</div>											
