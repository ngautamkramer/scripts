<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Webapp;

//use Zend\Mvc\ModuleRouteListener;
//use Zend\Mvc\MvcEvent;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;


//POckage for User Manager

use Webapp\Model\TblAppuserListTable;
use Webapp\Model\TblAppuserList;

use Webapp\Model\TblAppUserGroupsTable;
use Webapp\Model\TblAppUserGroups;

use Webapp\Model\TblAutoDiscoverVsmTable;
use Webapp\Model\TblAutoDiscoverVsm;

use Webapp\Model\TblDeviceDnsnameTable;
use Webapp\Model\TblDeviceDnsname;

use Webapp\Model\TblDevicegroupTable;
use Webapp\Model\TblDevicegroup;

use Webapp\Model\TblGatewayCustomizeHomepageTable;
use Webapp\Model\TblGatewayCustomizeHomepage;

use Webapp\Model\TblGatewayCustomizeHomepageMapping;
use Webapp\Model\TblGatewayCustomizeHomepageMappingTable;

use Webapp\Model\TblAdvanceConfigurationTable;
use Webapp\Model\TblAdvanceConfiguration;

use Webapp\Model\TblAdvanceConfigurationMappingTable;
use Webapp\Model\TblAdvanceConfigurationMapping;



use Webapp\Model\TblAdvanceMoreFeaturesTable;
use Webapp\Model\TblAdvanceMoreFeatures;

use Webapp\Model\TblBasicAuthenticationTable;
use Webapp\Model\TblBasicAuthentication;

use Webapp\Model\TblMobileFeaturesTable;
use Webapp\Model\TblMobileFeatures;

use Webapp\Model\TblGatewayFeaturesTable;
use Webapp\Model\TblGatewayFeatures;

use Webapp\Model\TblClientsFeaturesTable;
use Webapp\Model\TblClientsFeatures;

use Webapp\Model\TblHqConfigurationTable;
use Webapp\Model\TblHqConfiguration;

use Webapp\Model\TblHqMoreConfigurationTable;
use Webapp\Model\TblHqMoreConfiguration;

use Webapp\Model\TblDisplaySettingsTable;
use Webapp\Model\TblDisplaySettings;

use Webapp\Model\TblTimezonesTable;
use Webapp\Model\TblTimezones;

use Webapp\Model\TblAuthFileFormatTable;
use Webapp\Model\TblAuthFileFormat;

use Webapp\Model\TblFeatureTempTable;
use Webapp\Model\TblFeatureTemp;

use Webapp\Model\TblProxySettingTable;
use Webapp\Model\TblProxySetting;

use Webapp\Model\TblDeviceInventoryTable;
use Webapp\Model\TblDeviceInventory;

use Webapp\Model\TblStreamingSettingsTable;
use Webapp\Model\TblStreamingSettings;

use Webapp\Model\TblRecordingTransferTable;
use Webapp\Model\TblRecordingTransfer;

use Webapp\Model\TblTemplatesTable;
use Webapp\Model\TblTemplates;

use Webapp\Model\TblActivityLogMasterTable;
use Webapp\Model\TblActivityLogMaster;

use Webapp\Model\TblGatewayFeaturesPositionTable;
use Webapp\Model\TblGatewayFeaturesPosition;

use Webapp\Model\TblClientsFeaturesPositionTable;
use Webapp\Model\TblClientsFeaturesPosition;

use Webapp\Model\TblClientsFeatureTempTable;
use Webapp\Model\TblClientsFeatureTemp;

use Webapp\Model\TblMobileFeaturesPositionTable;
use Webapp\Model\TblMobileFeaturesPosition;

use Webapp\Model\TblMobileFeatureTempTable;
use Webapp\Model\TblMobileFeatureTemp;

use Webapp\Model\TblFeatureConfigSettingTable;
use Webapp\Model\TblFeatureConfigSetting;

use Webapp\Model\TblSessionSettingsTable;
use Webapp\Model\TblSessionSettings;

use Webapp\Model\TblCertificatesTable;
use Webapp\Model\TblCertificates;

use Webapp\Model\TblNtpServerTable;
use Webapp\Model\TblNtpServer;

use Webapp\Model\TblProjectorLogTable;
use Webapp\Model\TblProjectorLog;

use Webapp\Model\TblWallpaperTable;
use Webapp\Model\TblWallpaper;

use Webapp\Model\TblScreenTemplateMasterTable;
use Webapp\Model\TblScreenTemplateMaster;

use Webapp\Model\TblCalendarTable;
use Webapp\Model\TblCalendarAccountTable;
use Webapp\Model\TblCalendarAccount;
use Webapp\Model\TblCalendar;

use Webapp\Model\TblSettingsTable;
use Webapp\Model\TblSettings;

use Webapp\Model\TblRecordingMasterTable;
use Webapp\Model\TblRecordingMaster;

use Webapp\Model\TblRecordingChildTable;
use Webapp\Model\TblRecordingChild;


use Webapp\Model\TblBuildInfoTable;
use Webapp\Model\TblBuildInfo;

use Webapp\Model\TblVersionInfoTable;
use Webapp\Model\TblVersionInfo;

use Webapp\Model\TblUserAccessTable;
use Webapp\Model\TblUserAccess;

use Webapp\Model\TblAlertInfoTable;
use Webapp\Model\TblAlertInfo;

use Webapp\Model\TblAlertMappingTable;
use Webapp\Model\TblAlertMapping;

use Webapp\Model\TblEmergencyAlertTable;
use Webapp\Model\TblEmergencyAlert;

use Webapp\Model\TblEmergencyAlertExecuteTable;
use Webapp\Model\TblEmergencyAlertExecute;


use Webapp\Model\TblComplexPasswordTable;
use Webapp\Model\TblComplexPassword;
//for via setting template
use Webapp\Model\TblViaSettingsTemplatesTable;
use Webapp\Model\TblViaSettingsTemplates;
use Webapp\Model\TblViaSettingsTemplatesMappingTable;
use Webapp\Model\TblViaSettingsTemplatesMapping;
//mobile_linux
use Webapp\Model\TblMobileFeaturesLinuxTable;
use Webapp\Model\TblMobileFeaturesLinux;

//client_linux
use Webapp\Model\TblClientFeaturesLinuxTable;
use Webapp\Model\TblClientFeaturesLinux;

use Webapp\Model\TblMediaInventoryTable;
use Webapp\Model\TblMediaInventory;

use Webapp\Model\TblMediaComponentMasterTable;
use Webapp\Model\TblMediaComponentMaster;

use Webapp\Model\TblMediaTypeMasterTable;
use Webapp\Model\TblMediaTypeMaster;

use Webapp\Model\TblMediaInventryTable;
use Webapp\Model\TblMediaInventry;

use Webapp\Model\TblCampaignListTable;
use Webapp\Model\TblCampaignList;

use Webapp\Model\TblPlaylistScheduleMasterTable;
use Webapp\Model\TblPlaylistScheduleMaster;

use Webapp\Model\TblPlaylistNowTable;
use Webapp\Model\TblPlaylistNow;

use Webapp\Model\TblCampaignMediaTable;
use Webapp\Model\TblCampaignMedia;

use Webapp\Model\TblCampaignTemplateTable;
use Webapp\Model\TblCampaignTemplate;

use Webapp\Model\TblSessionCheckTable;
use Webapp\Model\TblSessionCheck;

use Webapp\Model\TblScreenTemplateDetailsTable;
use Webapp\Model\TblScreenTemplateDetails;

use Webapp\Model\TblDssInfoTable;
use Webapp\Model\TblDssInfo;

use Webapp\Model\TblDssFontInfoTable;
use Webapp\Model\TblDssFontInfo;

use Webapp\Model\TblLicenseMasterTable;
use Webapp\Model\TblLicenseMaster;

use Webapp\Model\TblLicenseUsedTable;
use Webapp\Model\TblLicenseUsed;

use Webapp\Model\TblDssLicenseMasterTable;
use Webapp\Model\TblDssLicenseMaster;

use Webapp\Model\TblThirdpartyappsTable;
use Webapp\Model\TblThirdpartyapps;


//use Webapp\Model\CityTable;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\TableGateway\TableGateway;

class Module
{
    public function onBootstrap(MvcEvent $e)
    {
        $eventManager        = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
	
    public function getServiceConfig() {
        return array(
        'factories' => array(			
		   'Webapp\Model\TblAppuserListTable' =>   function($sm) {
			$tableGateway = $sm->get('TblAppuserListTableGateway');
			$table = new TblAppuserListTable($tableGateway);
			return $table;
			},
			'TblAppuserListTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAppuserList());
			return new TableGateway('appuserlist', $dbAdapter, null, $resultSetPrototype);
			},
			
		   'Webapp\Model\TblAppUserGroupsTable' =>   function($sm) {
			$tableGateway = $sm->get('TblAppUserGroupsTableGateway');
			$table = new TblAppUserGroupsTable($tableGateway);
			return $table;
			},
			'TblAppUserGroupsTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAppUserGroups());
			return new TableGateway('appusergroups', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblAutoDiscoverVsmTable' =>   function($sm) {
			$tableGateway = $sm->get('TblAutoDiscoverVsmTableGateway');
			$table = new TblAutoDiscoverVsmTable($tableGateway);
			return $table;
			},
			'TblAutoDiscoverVsmTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAutoDiscoverVsm());
			return new TableGateway('tbl_auto_discover_vsm', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblDeviceDnsnameTable' =>   function($sm) {
			$tableGateway = $sm->get('TblDeviceDnsnameTableGateway');
			$table = new TblDeviceDnsnameTable($tableGateway);
			return $table;
			},
			'TblDeviceDnsnameTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblDeviceDnsname());
			return new TableGateway('tbl_device_dnsname', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblDevicegroupTable' =>   function($sm) {
			$tableGateway = $sm->get('TblDevicegroupTableGateway');
			$table = new TblDevicegroupTable($tableGateway);
			return $table;
			},
			'TblDevicegroupTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblDevicegroup());
			return new TableGateway('devicegroup', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblDeviceInventoryTable' =>   function($sm) {
			$tableGateway = $sm->get('TblDeviceInventoryTableGateway');
			$table = new TblDeviceInventoryTable($tableGateway);
			return $table;
			},
			'TblDeviceInventoryTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblDeviceInventory());
			return new TableGateway('deviceinventory', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblGatewayCustomizeHomepageTable' =>   function($sm) {
			$tableGateway = $sm->get('TblGatewayCustomizeHomepageTableGateway');
			$table = new TblGatewayCustomizeHomepageTable($tableGateway);
			return $table;
			},
			'TblGatewayCustomizeHomepageTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblGatewayCustomizeHomepage());
			return new TableGateway('gateway_customize_homepage', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblGatewayCustomizeHomepageMappingTable' =>   function($sm) {
			$tableGateway = $sm->get('TblGatewayCustomizeHomepageMappingTableGateway');
			$table = new TblGatewayCustomizeHomepageMappingTable($tableGateway);
			return $table;
			},
			'TblGatewayCustomizeHomepageMappingTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblGatewayCustomizeHomepageMapping());
			return new TableGateway('gateway_customize_homepage_mapping', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblAdvanceConfigurationTable' =>   function($sm) {
			$tableGateway = $sm->get('TblAdvanceConfigurationTableGateway');
			$table = new TblAdvanceConfigurationTable($tableGateway);
			return $table;
			},			
			'TblAdvanceConfigurationTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAdvanceConfiguration());
			return new TableGateway('tbl_advance_configuration', $dbAdapter, null, $resultSetPrototype);
			},

			'Webapp\Model\TblAdvanceConfigurationMappingTable' =>   function($sm) {
			$tableGateway = $sm->get('TblAdvanceConfigurationMappingTableGateway');
			$table = new TblAdvanceConfigurationMappingTable($tableGateway);
			return $table;
			},			
			'TblAdvanceConfigurationMappingTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAdvanceConfigurationMapping());
			return new TableGateway('tbl_advance_configuration_mapping', $dbAdapter, null, $resultSetPrototype);
			},
			
			
			
			
			'Webapp\Model\TblAdvanceMoreFeaturesTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblAdvanceMoreFeaturesTableGateway');
			$table = new TblAdvanceMoreFeaturesTable($tableGateway);
			return $table;
			},			
			'TblAdvanceMoreFeaturesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAdvanceMoreFeatures());
			return new TableGateway('tbl_advance_more_features', $dbAdapter, null, $resultSetPrototype);
			},
			
			
			'Webapp\Model\TblBasicAuthenticationTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblBasicAuthenticationTableGateway');
			$table = new TblBasicAuthenticationTable($tableGateway);
			return $table;
			},			
			'TblBasicAuthenticationTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblBasicAuthentication());
			return new TableGateway('tbl_basicauthentication', $dbAdapter, null, $resultSetPrototype);
			},			
			
			'Webapp\Model\TblComplexPasswordTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblComplexPasswordTableGateway');
			$table = new TblComplexPasswordTable($tableGateway);
			return $table;
			},	
			'TblComplexPasswordTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblComplexPassword());
			return new TableGateway('complexpassword', $dbAdapter, null, $resultSetPrototype);
			},		
		
			'Webapp\Model\TblMobileFeaturesTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblMobileFeaturesTableGateway');
			$table = new TblMobileFeaturesTable($tableGateway);
			return $table;
			},		
			'TblMobileFeaturesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblMobileFeatures());
			return new TableGateway('tbl_mobile_features', $dbAdapter, null, $resultSetPrototype);
			},
		
			'Webapp\Model\TblGatewayFeaturesTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblGatewayFeaturesTableGateway');
			$table = new TblGatewayFeaturesTable($tableGateway);
			return $table;
			},		
			'TblGatewayFeaturesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblGatewayFeatures());
			return new TableGateway('tbl_gateway_features', $dbAdapter, null, $resultSetPrototype);
			},
		
		
			'Webapp\Model\TblClientsFeaturesTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblClientsFeaturesTableGateway');
			$table = new TblClientsFeaturesTable($tableGateway);
			return $table;
			},		
			'TblClientsFeaturesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblClientsFeatures());
			return new TableGateway('tbl_clients_features', $dbAdapter, null, $resultSetPrototype);
			},		
		
			'Webapp\Model\TblHqConfigurationTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblHqConfigurationTableGateway');
			$table = new TblHqConfigurationTable($tableGateway);
			return $table;
			},
			'TblHqConfigurationTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblHqConfiguration());
			return new TableGateway('tbl_hq_configuration', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblDisplaySettingsTable' =>   function($sm) {
			$tableGateway = $sm->get('TblDisplaySettingsTableGateway');
			$table = new TblDisplaySettingsTable($tableGateway);
			return $table;
			},
			'TblDisplaySettingsTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblDisplaySettings());
			return new TableGateway('tbl_display_settings', $dbAdapter, null, $resultSetPrototype);
			},
                                
             'Webapp\Model\TblTimezonesTable' =>   function($sm) {
			$tableGateway = $sm->get('TblTimezonesTableGateway');
			$table = new TblTimezonesTable($tableGateway);
			return $table;
			},
			'TblTimezonesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblTimezones());
			return new TableGateway('tbl_timezones', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblAuthFileFormatTable' =>   function($sm) {
			$tableGateway = $sm->get('TblAuthFileFormatTableGateway');
			$table = new TblAuthFileFormatTable($tableGateway);
			return $table;
			},
			'TblAuthFileFormatTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblAuthFileFormat());
			return new TableGateway('tbl_auth_fileformat', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblProxySettingTable' =>   function($sm) {
			$tableGateway = $sm->get('TblProxySettingTableGateway');
			$table = new TblProxySettingTable($tableGateway);
			return $table;
			},
			'TblProxySettingTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblProxySetting());
			return new TableGateway('tbl_proxy_setting', $dbAdapter, null, $resultSetPrototype);
			}, 
                              
            'Webapp\Model\TblStreamingSettingsTable' =>   function($sm) {
			$tableGateway = $sm->get('TblStreamingSettingsTableGateway');
			$table = new TblStreamingSettingsTable($tableGateway);
			return $table;
			},
			'TblStreamingSettingsTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblStreamingSettings());
			return new TableGateway('tbl_streaming_settings', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblRecordingTransferTable' =>   function($sm) {
			$tableGateway = $sm->get('TblRecordingTransferTableGateway');
			$table = new TblRecordingTransferTable($tableGateway);
			return $table;
			},
			'TblRecordingTransferTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblRecordingTransfer());
			return new TableGateway('tbl_recording_transfer', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblTemplatesTable' =>   function($sm) {
			$tableGateway = $sm->get('TblTemplatesTableGateway');
			$table = new TblTemplatesTable($tableGateway);
			return $table;
			},
			'TblTemplatesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblTemplates());
			return new TableGateway('tbl_templates', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblClientsFeaturesTable' =>   function($sm) {
			$tableGateway = $sm->get('TblClientsFeaturesTableGateway');
			$table = new TblClientsFeaturesTable($tableGateway);
			return $table;
			},
			'TblClientsFeaturesTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblClientsFeatures());
			return new TableGateway('tbl_clients_features', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblActivityLogMasterTable' =>   function($sm) {
			$tableGateway = $sm->get('TblActivityLogMasterTableGateway');
			$table = new TblActivityLogMasterTable($tableGateway);
			return $table;
			},
			'TblActivityLogMasterTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblActivityLogMaster());
			return new TableGateway('activitylogmaster', $dbAdapter, null, $resultSetPrototype);
			},
                                
                        
            'Webapp\Model\TblGatewayFeaturesPositionTable' =>   function($sm) {
			$tableGateway = $sm->get('TblGatewayFeaturesPositionTableGateway');
			$table = new TblGatewayFeaturesPositionTable($tableGateway);
			return $table;
			},
			'TblGatewayFeaturesPositionTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblGatewayFeaturesPosition());
			return new TableGateway('tbl_gateway_features_position', $dbAdapter, null, $resultSetPrototype);
			},
                                
                        
            'Webapp\Model\TblClientsFeaturesPositionTable' =>   function($sm) {
			$tableGateway = $sm->get('TblClientsFeaturesPositionTableGateway');
			$table = new TblClientsFeaturesPositionTable($tableGateway);
			return $table;
			},
			'TblClientsFeaturesPositionTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblClientsFeaturesPosition());
			return new TableGateway('tbl_client_features_position', $dbAdapter, null, $resultSetPrototype);
			},
                                
            'Webapp\Model\TblMobileFeaturesPositionTable' =>   function($sm) {
			$tableGateway = $sm->get('TblMobileFeaturesPositionTableGateway');
			$table = new TblMobileFeaturesPositionTable($tableGateway);
			return $table;
			},
			'TblMobileFeaturesPositionTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblMobileFeaturesPosition());
			return new TableGateway('tbl_mobile_features_position', $dbAdapter, null, $resultSetPrototype);
			},
                                
                                
            'Webapp\Model\TblFeatureConfigSettingTable' =>   function($sm) {
			$tableGateway = $sm->get('TblFeatureConfigSettingTableGateway');
			$table = new TblFeatureConfigSettingTable($tableGateway);
			return $table;
			},
			'TblFeatureConfigSettingTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblFeatureConfigSetting());
			return new TableGateway('tbl_feature_config_settings', $dbAdapter, null, $resultSetPrototype);
			},
                                
                       'Webapp\Model\TblSessionSettingsTable' =>   function($sm) {
			$tableGateway = $sm->get('TblSessionSettingsTableGateway');
			$table = new TblSessionSettingsTable($tableGateway);
			return $table;
			},
			'TblSessionSettingsTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblSessionSettings());
			return new TableGateway('tbl_session_settings', $dbAdapter, null, $resultSetPrototype);
			},
                                
                                
                       'Webapp\Model\TblNtpServerTable' =>   function($sm) {
			$tableGateway = $sm->get('TblNtpServerTableGateway');
			$table = new TblNtpServerTable($tableGateway);
			return $table;
			},
			'TblNtpServerTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblNtpServer());
			return new TableGateway('ntp_server', $dbAdapter, null, $resultSetPrototype);
			},
			
			
			
			'Webapp\Model\TblProjectorLogTable' =>   function($sm) {
			$tableGateway = $sm->get('TblProjectorLogTableGateway');
			$table = new TblProjectorLogTable($tableGateway);
			return $table;
			},
			
			'TblProjectorLogTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblProjectorLog());
			return new TableGateway('projectorlog', $dbAdapter, null, $resultSetPrototype);
			},
                                
                       'Webapp\Model\TblHqMoreConfigurationTable' =>   function($sm) {
			$tableGateway = $sm->get('TblHqMoreConfigurationTableGateway');
			$table = new TblHqMoreConfigurationTable($tableGateway);
			return $table;
			},
			'TblHqMoreConfigurationTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblHqMoreConfiguration());
			return new TableGateway('tbl_hq_more_configuration', $dbAdapter, null, $resultSetPrototype);
			},
                                
                       'Webapp\Model\TblWallpaperTable' =>   function($sm) {
			$tableGateway = $sm->get('TblWallpaperTableGateway');
			$table = new TblWallpaperTable($tableGateway);
			return $table;
			},
			'TblWallpaperTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblWallpaper());
			return new TableGateway('tbl_wallpaper', $dbAdapter, null, $resultSetPrototype);
			},
                       
                       'Webapp\Model\TblScreenTemplateMasterTable' =>   function($sm) {
			$tableGateway = $sm->get('TblScreenTemplateMasterTableGateway');
			$table = new TblScreenTemplateMasterTable($tableGateway);
			return $table;
			},
			'TblScreenTemplateMasterTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblScreenTemplateMaster());
			return new TableGateway('screentemplatemaster', $dbAdapter, null, $resultSetPrototype);
			},
			//Create the Result set object for calendar account (Added By Dileep)
			'Webapp\Model\TblCalendarAccountTable' =>  function($sm) {
				 $tableGateway = $sm->get('TblCalendarAccountTableGateway');
				 $table = new TblCalendarAccountTable($tableGateway);
				 return $table;
			 },
			'TblCalendarAccountTableGateway' => function ($sm) {
				 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				 $resultSetPrototype = new ResultSet();
				 $resultSetPrototype->setArrayObjectPrototype(new TblCalendarAccount());
				 return new TableGateway('tbl_calender_account', $dbAdapter, null, $resultSetPrototype);
			 },
			 'Webapp\Model\TblCalendarTable' =>  function($sm) {
				 $tableGateway = $sm->get('TblCalendarTableGateway');
				 $table = new TblCalendarTable($tableGateway);
				 return $table;
			 },
			'TblCalendarTableGateway' => function ($sm) {
				 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				 $resultSetPrototype = new ResultSet();
				 $resultSetPrototype->setArrayObjectPrototype(new TblCalendar());
				 return new TableGateway('tbl_calendars', $dbAdapter, null, $resultSetPrototype);
			 },
			 
			 //Create the Result set object for settings
		   'Webapp\Model\TblSettingsTable' =>   function($sm) {
			$tableGateway = $sm->get('TblSettingsTableGateway');
			$table = new TblSettingsTable($tableGateway);
			return $table;
			},
			'TblSettingsTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblSettings());
			return new TableGateway('settings', $dbAdapter, null, $resultSetPrototype);
			},
			 
			 'Webapp\Model\TblRecordingMasterTable' =>  function($sm) {
				 $tableGateway = $sm->get('TblRecordingMasterTableGateway');
				 $table = new TblRecordingMasterTable($tableGateway);
				 return $table;
			 },
			 
			 		'TblRecordingMasterTableGateway' => function ($sm) {
				 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				 $resultSetPrototype = new ResultSet();
				 $resultSetPrototype->setArrayObjectPrototype(new TblRecordingMaster());
				 return new TableGateway('recordingmaster', $dbAdapter, null, $resultSetPrototype);
			 },
                        
				'Webapp\Model\TblRecordingChildTable' =>  function($sm) {
				 $tableGateway = $sm->get('TblRecordingChildTableGateway');
				 $table = new TblRecordingChildTable($tableGateway);
				 return $table;
			 },	

		 		'TblRecordingChildTableGateway' => function ($sm) {
				 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				 $resultSetPrototype = new ResultSet();
				 $resultSetPrototype->setArrayObjectPrototype(new TblRecordingChild());
				 return new TableGateway('recordingchild', $dbAdapter, null, $resultSetPrototype);
			 },		
			 
			 	'Webapp\Model\TblBuildInfoTable' =>  function($sm) {
				 $tableGateway = $sm->get('TblBuildInfoTableGateway');
				 $table = new TblBuildInfoTable($tableGateway);
				 return $table;
			 },	

				'TblBuildInfoTableGateway' => function ($sm) {
				 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				 $resultSetPrototype = new ResultSet();
				 $resultSetPrototype->setArrayObjectPrototype(new TblBuildInfo());
				 return new TableGateway('tbl_buildinfo', $dbAdapter, null, $resultSetPrototype);
			 },	

				'Webapp\Model\TblVersionInfoTable' =>  function($sm) {
				 $tableGateway = $sm->get('TblVersionInfoTableGateway');
				 $table = new TblVersionInfoTable($tableGateway);
				 return $table;
			 },			
			 
			 	'TblVersionInfoTableGateway' => function ($sm) {
				 $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				 $resultSetPrototype = new ResultSet();
				 $resultSetPrototype->setArrayObjectPrototype(new TblVersionInfo());
				 return new TableGateway('tbl_versioninfo', $dbAdapter, null, $resultSetPrototype);
			 },		
			 	
			
			'Webapp\Model\TblUserAccessTable' =>  function($sm) {
				$tableGateway = $sm->get('TblUserAccessTableGateway');
				$table = new TblUserAccessTable($tableGateway);
				return $table;
			},			
			
				'TblUserAccessTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblUserAccess());
				return new TableGateway('tbl_user_access', $dbAdapter, null, $resultSetPrototype);
			},	


			'Webapp\Model\TblAlertInfoTable' =>  function($sm) {
				$tableGateway = $sm->get('TblAlertInfoTableGateway');
				$table = new TblAlertInfoTable($tableGateway);
				return $table;
			},			
			
				'TblAlertInfoTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblAlertInfo());
				return new TableGateway('tbl_alert_info', $dbAdapter, null, $resultSetPrototype);
			},	
			
			'Webapp\Model\TblAlertMappingTable' =>  function($sm) {
				$tableGateway = $sm->get('TblAlertMappingTableGateway');
				$table = new TblAlertMappingTable($tableGateway);
				return $table;
			},			
			
				'TblAlertMappingTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblAlertMapping());
				return new TableGateway('tbl_alert_mapping', $dbAdapter, null, $resultSetPrototype);
			},	

			'Webapp\Model\TblEmergencyAlertTable' =>  function($sm) {
				$tableGateway = $sm->get('TblEmergencyAlertTableGateway');
				$table = new TblEmergencyAlertTable($tableGateway);
				return $table;
			},			
			
				'TblEmergencyAlertTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblEmergencyAlert());
				return new TableGateway('tbl_emergency_alert', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblEmergencyAlertExecuteTable' =>  function($sm) {
				$tableGateway = $sm->get('TblEmergencyAlertExecuteTableGateway');
				$table = new TblEmergencyAlertTable($tableGateway);
				return $table;
			},			
			
				'TblEmergencyAlertExecuteTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblEmergencyAlertExecute());
				return new TableGateway('tbl_emergency_alert_execute', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblViaSettingsTemplatesTable' =>  function($sm) {
				$tableGateway = $sm->get('TblViaSettingsTemplatesTableGateway');
				$table = new TblViaSettingsTemplatesTable($tableGateway);
				return $table;
			},			
			
			'TblViaSettingsTemplatesTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblViaSettingsTemplates());
				return new TableGateway('tbl_via_settings_templates', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblViaSettingsTemplatesMappingTable' =>  function($sm) {
				$tableGateway = $sm->get('TblViaSettingsTemplatesMappingTableGateway');
				$table = new TblViaSettingsTemplatesMappingTable($tableGateway);
				return $table;
			},			
			
			'TblViaSettingsTemplatesMappingTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblViaSettingsTemplatesMapping());
				return new TableGateway('tbl_via_settings_templates_mapping', $dbAdapter, null, $resultSetPrototype);
			},
			//mobile feaures Linux
			'Webapp\Model\TblMobileFeaturesLinuxTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblMobileFeaturesLinuxTableGateway');
			$table = new TblMobileFeaturesLinuxTable($tableGateway);
			return $table;
			},		
			'TblMobileFeaturesLinuxTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblMobileFeaturesLinux());
			return new TableGateway('tbl_mobile_features_linux', $dbAdapter, null, $resultSetPrototype);
			},
			
			//Client Feature linux
			'Webapp\Model\TblClientFeaturesLinuxTable' =>   function($sm) {
			 $tableGateway = $sm->get('TblClientFeaturesLinuxTableGateway');
			$table = new TblClientFeaturesLinuxTable($tableGateway);
			return $table;
			},		
			'TblClientFeaturesLinuxTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblClientFeaturesLinux());
			return new TableGateway('tbl_clients_features_linux', $dbAdapter, null, $resultSetPrototype);
			},
			 'Webapp\Model\TblMediaInventoryTable' =>  function($sm) {
				$tableGateway = $sm->get('TblMediaInventoryTableGateway');
				$table = new TblMediaInventoryTable($tableGateway);
				return $table;
			},
			'TblMediaInventoryTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblMediaInventory());
				return new TableGateway('mediainventory', $dbAdapter, null, $resultSetPrototype);
			},
			
			'Webapp\Model\TblMediaComponentMasterTable' =>  function($sm) {
				$tableGateway = $sm->get('TblMediaComponentMasterTableGateway');
				$table = new TblMediaComponentMasterTable($tableGateway);
				return $table;
			},
			'TblMediaComponentMasterTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblMediaComponentMaster());
				return new TableGateway('mediacomponentmaster', $dbAdapter, null, $resultSetPrototype);
			},
			'Webapp\Model\TblMediaTypeMasterTable' =>  function($sm) {
				$tableGateway = $sm->get('TblMediaTypeMasterTableGateway');
				$table = new TblMediaTypeMasterTable($tableGateway);
				return $table;
			},			
			 
			'TblMediaTypeMasterTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblMediaTypeMaster());
				return new TableGateway('mediatypemaster', $dbAdapter, null, $resultSetPrototype);
			},	
            'Webapp\Model\TblMediaInventryTable' =>  function($sm) {
				$tableGateway = $sm->get('TblMediaInventryTableGateway');
				$table = new TblMediaInventryTable($tableGateway);
				return $table;
			},			
			 
			'TblMediaInventryTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblMediaInventry());
				return new TableGateway('mediainventry', $dbAdapter, null, $resultSetPrototype);
			},	

			'TblMediaInventryTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblMediaInventry());
				return new TableGateway('mediainventry', $dbAdapter, null, $resultSetPrototype);
			},

			'Webapp\Model\TblCampaignListTable' =>  function($sm) {
				$tableGateway = $sm->get('TblCampaignListTableGateway');
				$table = new TblCampaignListTable($tableGateway);
				return $table;
			},			
			 
			'TblCampaignListTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblCampaignList());
				return new TableGateway('campaignlist', $dbAdapter, null, $resultSetPrototype);
			},	       

			'Webapp\Model\TblPlaylistScheduleMasterTable' =>  function($sm) {
				$tableGateway = $sm->get('TblPlaylistScheduleMasterTableGateway');
				$table = new TblPlaylistScheduleMasterTable($tableGateway);
				return $table;
			},			
			 
			'TblPlaylistScheduleMasterTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblPlaylistScheduleMaster());
				return new TableGateway('playlist_schedule_master', $dbAdapter, null, $resultSetPrototype);
			},	  

			'Webapp\Model\TblPlaylistNowTable' =>  function($sm) {
				$tableGateway = $sm->get('TblPlaylistNowTableGateway');
				$table = new TblPlaylistNowTable($tableGateway);
				return $table;
			},			
			 
			'TblPlaylistNowTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblPlaylistNow());
				return new TableGateway('playlist_now', $dbAdapter, null, $resultSetPrototype);
			},

			'Webapp\Model\TblCampaignMediaTable' =>  function($sm) {
				$tableGateway = $sm->get('TblCampaignMediaTableGateway');
				$table = new TblCampaignMediaTable($tableGateway);
				return $table;
			},			
			 
			'TblCampaignMediaTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblCampaignMedia());
				return new TableGateway('campaign_media', $dbAdapter, null, $resultSetPrototype);
			},

			'Webapp\Model\TblCampaignTemplateTable' =>  function($sm) {
				$tableGateway = $sm->get('TblCampaignTemplateTableGateway');
				$table = new TblCampaignTemplateTable($tableGateway);
				return $table;
			},			
			 
			'TblCampaignTemplateTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblCampaignTemplate());
				return new TableGateway('campaign_template', $dbAdapter, null, $resultSetPrototype);
			},

			'Webapp\Model\TblSessionCheckTable' =>  function($sm) {
				$tableGateway = $sm->get('TblSessionCheckTableGateway');
				$table = new TblSessionCheckTable($tableGateway);
				return $table;
			},			
			 
			'TblSessionCheckTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblSessionCheck());
				return new TableGateway('tbl_session_check', $dbAdapter, null, $resultSetPrototype);
			}, 
			'Webapp\Model\TblDssInfoTable' =>  function($sm) {
				$tableGateway = $sm->get('TblDssInfoTableGateway');
				$table = new TblDssInfoTable($tableGateway);
				return $table;
			},
			'TblDssInfoTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblDssInfo());
				return new TableGateway('dss_info', $dbAdapter, null, $resultSetPrototype);
			},
			'Webapp\Model\TblDssFontInfoTable' =>  function($sm) {
				$tableGateway = $sm->get('TblDssFontInfoTableGateway');
				$table = new TblDssFontInfoTable($tableGateway);
				return $table;
			},
			'TblDssFontInfoTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblDssFontInfo());
				return new TableGateway('dss_font', $dbAdapter, null, $resultSetPrototype);
			},
            'Webapp\Model\TblScreenTemplateDetailsTable' =>   function($sm) {
			$tableGateway = $sm->get('TblScreenTemplateDetailsTableGateway');
			$table = new TblScreenTemplateDetailsTable($tableGateway);
			return $table;
			},
			'TblScreenTemplateDetailsTableGateway' => function ($sm) {
			$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
			$resultSetPrototype = new ResultSet();
			$resultSetPrototype->setArrayObjectPrototype(new TblScreenTemplateDetails());
				return new TableGateway('screentemplatedetails', $dbAdapter, null, $resultSetPrototype);
			}, 
			'Webapp\Model\TblLicenseMasterTable' =>  function($sm) {
				$tableGateway = $sm->get('TblLicenseMasterTableGateway');
				$table = new TblLicenseMasterTable($tableGateway);
				return $table;
			},
			'TblLicenseMasterTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblLicenseMaster());
				return new TableGateway('license_master', $dbAdapter, null, $resultSetPrototype);
			},
			'Webapp\Model\TblLicenseUsedTable' =>  function($sm) {
				$tableGateway = $sm->get('TblLicenseUsedTableGateway');
				$table = new TblLicenseUsedTable($tableGateway);
				return $table;
			},
			'TblLicenseUsedTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblLicenseUsed());
				return new TableGateway('license_used', $dbAdapter, null, $resultSetPrototype);
			},      
			'Webapp\Model\TblDssLicenseMasterTable' =>  function($sm) {
				$tableGateway = $sm->get('TblDssLicenseMasterTableGateway');
				$table = new TblDssLicenseMasterTable($tableGateway);
				return $table;
			},
			'TblDssLicenseMasterTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblDssLicenseMaster());
				return new TableGateway('dss_license_master', $dbAdapter, null, $resultSetPrototype);
			},    
			
			'Webapp\Model\TblThirdpartyappsTable' =>  function($sm) {
				$tableGateway = $sm->get('TblThirdpartyappsTableGateway');
				$table = new TblThirdpartyappsTable($tableGateway);
				return $table;
			},
			'TblThirdpartyappsTableGateway' => function ($sm) {
				$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
				$resultSetPrototype = new ResultSet();
				$resultSetPrototype->setArrayObjectPrototype(new TblThirdpartyapps());
				return new TableGateway('thirdpartyapps', $dbAdapter, null, $resultSetPrototype);
			},  
       	 ),
     	);
	  
    }	


}
