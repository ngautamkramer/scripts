<?php
namespace Webapp\Validator;

use Webapp\Validator\Validator;

class ServicesValidator extends Validator
{
	
	/*****
	 *	Function Name		: Check the register company
	 *  description			: check the input parameter.
     *	Author			    : Dileep Kumar
	 *  Date                : 8-Aug-2019
	 *****/
	
    public function userRegisterInputValidate($username,$password,$conf_password){
	    $error = '';
		$validate     = new Validator();
        if($username != ""){ 
			$error = $validate->validateLength($username);
			if($error != ""){
			    return $error;
			}				
			$error2  = $validate->validateUsername($username);
			if($error2 != ""){
			    return $error2;
			}	
			
		}else{
			return 'Username name can not blank';
		}
		
		if($password != ""){
			$error  = $validate->validatePassword($password,$conf_password);
			if($error != "")
			    return $error;
		
		}
				
        return $error;
	
	
	}
	
	
	/*****
	 *	Function Name		: Check the add license
	 *  description			: check the input parameter.
     *	Author			    : Dileep Kumar
	 *  Date                : 8-Aug-2019
	 *****/
	
    public function licenseInputValidate($kcid,$noOfLicense,$numberOfMonths,$licenseType,$orderId){
	    $error = '';
		$validate     = new Validator();
        if($kcid != ""){ 
			$error  = $validate->validateLength($kcid);
			if($error != "")
			    return $error;
		}
		if($noOfLicense != ""){ 
			$error  = $validate->validateNumber($noOfLicense);
			if($error != "")
			    return $error;
		}
		if($numberOfMonths != ""){ 
			$error  = $validate->validateNumber($numberOfMonths);
			if($error != "")
			    return $error;
		}
		if($noOfLicense != ""){ 
			$error  = $validate->validateNumberLenght($noOfLicense);
			if($error != "")
			    return $error;
		}
		if($numberOfMonths != ""){ 
			$error  = $validate->validateNumberLenght($numberOfMonths);
			if($error != "")
			    return $error;
		}
		if($licenseType != ""){ 
			if($licenseType !=1 || $licenseType !=1){
				$error = LICENSE_TYPE_TXT;
		        return $error;
			}
		}
		if($orderId != ""){ 
			$error  = $validate->validateOrderIdLength($orderId);
			if($error != "")
			    return $error;
		}
        return $error;
	}

}
