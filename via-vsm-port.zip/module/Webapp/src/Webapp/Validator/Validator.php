<?php
namespace Webapp\Validator;


class Validator
{
	/****
		@method: validateLength
		$param:  kcid
		@return: string
		@author:Dileep Kumar
    ****/

	public function validateLength($kcid){
		$error='';
		if( strlen($kcid) < 4 ) {
			$error =USERNAME_MIN_LENGTH;
			return $error;
		}else if( strlen($kcid) > 25 ) {
			$error = USERNAME_MIN_LENGTH;
			return $error;
		}else{
			return $error;
		}
	}

	public function validateUsername($username){
		$error='';	
		//$userLength=$this->validateLength($username);			
		if(preg_match('/[^a-z_.\-0-9]/i', $username)){
		  $error = SPECIAL_NOT_ALLOWED;
		  return $error;
		}
		return $error;
	}
	public function validatePassword($password,$conf_password){
		$error='';		
		if($password!=$conf_password){
		  $error = PASSWORD_NOT_MATCH;
		  return $error;
		}
		return $error;
	}

	
	/****
		@method: validateEmail
		$param:  email
		@return: string
		@author:Dileep Kumar
    ****/

	public function validateEmail($email){
		$error='';
		if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
		  $error = INVALID_EMAIL;
		  return $error;
		}
		return $error;
	}

    /****
		@method: validateCompanyName
		$param:  name
		@return: string
		@author:Dileep Kumar
    ****/

	public function validateCompanyName($name){
		$error='';
		if (strlen($name) > 100 ) {
		  $error = COMPANY_CHAR_LENGTH_TEXT;
		  return $error;
		}
		return $error;
	}
	
	 /****
		@method: validateSpecialChar
		$param:  name
		@return: string
		@author:Dileep Kumar
    ****/

	public function validateSpecialChar($name){
		$error='';
		if (preg_match('/[\'^£$%&*()}{@#~?><>,|=_+¬-]/', $name)){
		  $error = SPECIAL_NOT_ALLOWED;
		  return $error;
		}
		return $error;
	}
	
	public function validatePin($pinCode){
		$error='';
		if (strlen($pinCode) > 20 ) {
		  $error = PINCODE_LENGTH_TEXT;
		  return $error;
		}
		return $error;
	}
	
	
	//check the number
	public function validateNumber($number){
		$error='';
		if( !is_numeric($number)) {
			$error = LICENSE_NUMERIC_TEXT;
		    return $error;
		}
		return $error;
	}
	
	//check lenth
	public function validateNumberLenght($number){
		$error='';
		if (strlen($number) > 5 ) {
		  $error = LICENSE_CHAR_LENGTH_TEXT;
		  return $error;
		}
		return $error;
	}
	
	public function validateOrderIdLength($orderId){
		$error='';
		if( strlen($orderId) < 10 ) {
			$error ="Take more than 10 character in order id.";
			return $error;
		}else if( strlen($orderId) > 50 ) {
			$error = "Take less than 50 character in order id.";
			return $error;
		}else{
			return $error;
		}
	}
	
	
	
	
	
	
}
