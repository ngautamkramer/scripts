<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;

 class TblTemplatesTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }	
       
	   public function fetchAll($template) {
	   		$appObj=new ApplicationController();
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('*'));
			$select->where(array('model_type'=>PRODUCT_MODEL_TYPE));			
            if($template!=''){
                //$select->where->like('template_name', '%'.$template.'%');
                $select->where->expression("template_name ILIKE ?",  '%'.$template.'%');
            }			
			$select->order('id ASC');	
            $resultSet = $this->tableGateway->selectWith($select);
             // create a new pagination adapter object
            $paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
            $resultSet = new Paginator($paginatorAdapter); 			       
            return $resultSet;
        }

  		public function truncateTable() { 
            $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable(). ' RESTART IDENTITY');
            $query->execute();
        }

        public function getData($condition){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where($condition);
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
            $resultSet = $statement->execute(); 
            return $resultSet;
        }
        
        public function updateData($data,$where){
            $this->tableGateway->update($data, $where); 
        }
        
        public function insertData($data){
            $this->tableGateway->insert($data);
        }
  		
		//insert and return last insert id
        public function insertAndGetId($insertArr){
            $this->tableGateway->insert($insertArr);
            /*$insertId = $this->tableGateway->lastInsertValue; 
            return $insertId;*/
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('tbl_templates_id_seq');
            
        }
		
		
	
 }