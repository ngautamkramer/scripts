<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;

 class TblSettingsTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

		
        public function fetchAll(){
			$appObj = new ApplicationController();
			$sqlSelect = $this->tableGateway->getSql()->select();
		   	$sqlSelect->columns(array('field3'));			
			$sqlSelect->order('id ASC LIMIT 1');			
		    $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
		    return $resultSet;			
         }
		 
		 public function fetchAllRows()
		 {
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('logoutTIme','pageSize','field3','field4','startTime','endTime'));
            $select->order('id DESC LIMIT 1');
            $resultSet =$this->tableGateway->selectWith($select);
            $resultCount = $resultSet->count();

            if($resultCount>0){
                $result = $resultSet->current();
                $sessionArr['logoutTime'] = $result->logoutTIme;
                $sessionArr['field3'] = $result->field3;
                $sessionArr['field4'] = $result->field4;
                //$sessionArr['frequencyAlert'] = $result->frequencyAlert;
                $sessionArr['startTime']=$result->startTime;
                $sessionArr['endTime']=$result->endTime;
            }
            else{
                $sessionArr['logoutTime'] = 1440;
                $sessionArr['field1'] = 0;
                //$sessionArr['frequencyAlert']=10;
                $sessionArr['startTime']= date("H:i", strtotime("6:00 AM"));
                $sessionArr['endTime']=date("H:i", strtotime("8:00 PM"));;
                $this->tableGateway->insert(array('logoutTIme' => $sessionArr['logoutTime'], 
                'field1' => $sessionArr['field1'],'startTime'=> $sessionArr['startTime'],'endTime'=>$sessionArr['endTime']));
            }
		    return $sessionArr;	
		 }
		 
		 public function insertSessionTime($timeVal,$gwayVal,$user_id)
		 {
			$select = $this->tableGateway->getSql()->select();
            $select->columns(array('logoutTIme','pageSize','field3','field4'));
            $select->order('id DESC LIMIT 1');
            $resultSet =$this->tableGateway->selectWith($select);
            $resultCount = $resultSet->count();
            if($resultCount>0){
					
					$this->tableGateway->update(array('logoutTIme' => $timeVal,'field4'=>$gwayVal));
           }
       
			else
			{
				
			  $this->tableGateway->insert(array('logoutTIme' => $timeVal,'field4'=>$gwayVal,'field1'=>$user_id));
           
		 }
		
 }
  public function updateCaptcha($captchaArr){
			$select = $this->tableGateway->getSql()->select();
            $select->columns(array('field3'));
            $select->order('id DESC LIMIT 1');
            $resultSet =$this->tableGateway->selectWith($select);
            $resultCount = $resultSet->count();
            if($resultCount>0){
				$this->tableGateway->update($captchaArr);
			}else{
				$this->tableGateway->insert($captchaArr);
			}
            
        }

        // /*****
	    //  *	@function Name		: insertFrequencyAlert
	    //  *  @description	    : insert/update frequency alert
	    //  *	@Author			    : Vineet
	    //  *  @Date               : 15-may-2020
	    //  *****/
        // public function insertFrequencyAlert($alertVal){
           
        //     $select = $this->tableGateway->getSql()->select();
        //     $select->columns(array('frequencyAlert'));
        //     $select->order('id DESC LIMIT 1');
        //     $resultSet =$this->tableGateway->selectWith($select);
        //     $resultCount = $resultSet->count();
        //     if($resultCount>0){
        //         $this->tableGateway->update(array('frequencyAlert'=>$alertVal));
        //     }
        //     else{
        //         $this->tableGateway->insert(array( 
        //             'frequencyAlert'=>$alertVal));
        //     } 
        // }


         /*****
	     *	@function Name		: insertStartEndTime
	     *  @description	    : insert start/endtime for business hour
	     *	@Author			    : Vineet
	     *  @Date               : 24-dec-2020
	     *****/
        public function insertStartEndTime($timeVal,$time){
            $select = $this->tableGateway->getSql()->select();
            if($time=="starttime") {
                $select->columns(array('startTime'));
                $select->order('id DESC LIMIT 1');
                $resultSet =$this->tableGateway->selectWith($select);
                $resultCount = $resultSet->count();
                if($resultCount>0){
                    $this->tableGateway->update(array('startTime'=>$timeVal));
                }
                else{
                    $this->tableGateway->insert(array( 
                        'startTime'=>$timeVal));
                } 
            }else{
                $select->columns(array('endTime'));
                $select->order('id DESC LIMIT 1');
                $resultSet =$this->tableGateway->selectWith($select);
                $resultCount = $resultSet->count();
                if($resultCount>0){
                    $this->tableGateway->update(array('endTime'=>$timeVal));
                }
                else{
                    $this->tableGateway->insert(array( 
                        'endTime'=>$timeVal));
                } 
            }
        }

        public function getSessionCheckData() {
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('logoutTIme'));
            $select->order('id desc');
            $select->limit(1);
            $resultSet = $this->tableGateway->selectWith($select);
            return $resultSet;
        }

        public function insertSessionValue($insertArr){
            $this->tableGateway->insert($insertArr);
        }
 }