<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;

 class TblScreenTemplateMasterTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }   
        
        public function deleteScreenTemplate($where) {
            $appObj = new ApplicationController(); 
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Delete','Delete template by'.' '.$name);
            }else{
                $appObj->ActivityLogVSM(5,'Delete template by'.' '.$name,19);
            }  
            $this->tableGateway->delete($where);  
        }

        public function getPredefinedDssTempaltes() {
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT stm.screentemplateid, stm.screentemplatename, stm.audioframeid,
                stm.aspectratio, stm.backgroundcolor, stm.framecount, std.frameid, std.framename, std.frameheight, 
                std.framewidth, std.strechmediatofit, std.frameleft, std.frametop
                FROM screentemplatemaster as stm
                INNER JOIN screentemplatedetails as std 
                    ON stm.screentemplateid = std.screentemplateid
                WHERE stm.active = 'Y' AND stm.screentemplateid <= 6
                ORDER BY stm.screentemplateid ASC";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

        public function getCustomDssTempaltes() {
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT stm.screentemplateid, stm.screentemplatename, stm.audioframeid,
                stm.aspectratio, stm.backgroundcolor, stm.framecount, std.frameid, std.framename, std.frameheight, 
                std.framewidth, std.strechmediatofit, std.frameleft, std.frametop, ct.id, ct.campaign_id, ct.template_id
                FROM screentemplatemaster as stm
                INNER JOIN screentemplatedetails as std 
                    ON stm.screentemplateid = std.screentemplateid
                LEFT JOIN campaign_template as ct ON stm.screentemplateid = ct.template_id
                WHERE stm.active = 'Y' AND stm.screentemplateid > 6
                ORDER BY stm.screentemplateid DESC";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }
		//Modified by ashu on 17Aug2022 to change this function according to zend
        public function getTemplateDetails($id) {
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('screentemplateid','screentemplatename','audioframeid','aspectratio','backgroundcolor','framecount'));
			$sqlSelect->join('screentemplatedetails', 'screentemplatemaster.screentemplateid = screentemplatedetails.screentemplateid', array('frameid','framename','frameheight','framewidth','strechmediatofit','frameleft','frametop'), 'INNER');
			$sqlSelect->where(array("screentemplatemaster.active" => 'Y',"screentemplatemaster.screentemplateid"=>$id));
			$sqlSelect->order(array('screentemplatedetails.frameid  ASC'));
			// echo $sql->getSqlstringForSqlObject($sqlSelect); die ;			
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
            return $resultSet; 
        }
		
		//Modified by ashu on 17Aug2022 to change this function according to zend
        public function checkTemplateUniqueName($data) {
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('screentemplateid'));
			if($data["ScreenTemplateID"]){
				//$sqlSelect->where(array("screentemplatename" => $data["ScreenTemplateName"],"screentemplateid!= ".$data["ScreenTemplateID"].""  ));
                $sqlSelect->where(array("screentemplateid!= ".$data["ScreenTemplateID"]."" ));
                $sqlSelect->where->expression("screentemplatename ILIKE ?",  $data["ScreenTemplateName"]);
			}else{
				//$sqlSelect->where(array("screentemplatename" => $data["ScreenTemplateName"]));
                $sqlSelect->where->expression("screentemplatename ILIKE ?",  $data["ScreenTemplateName"]);

			}		
			//echo $sql->getSqlstringForSqlObject($sqlSelect); die ;
			$sql->getSqlstringForSqlObject($sqlSelect); 	
			$resultSet = $this->tableGateway->selectWith($sqlSelect);		
            return $resultSet; 
        }

        public function insertScreenTemplateMaster($data) {
            $appObj = new ApplicationController();
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Create','Template Name: '. $data['screentemplatename']);
            }else{
                $appObj->ActivityLogVSM(3,'Template Name: '. $data['screentemplatename'],19);
            }
            
            $this->tableGateway->insert($data);
            //return $lastInsertid = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('screentemplatemaster_screentemplateid_seq');
            
        }   

        public function updateScreenTemplateMaster($whereCondition, $userData) {
            $appObj = new ApplicationController();
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');
            if(PRODUCT=='via') {
                $appObj->ActivityLog('Update','Template Name: '. $userData['screentemplatename']);
            } else {
                $appObj->ActivityLogVSM(4,'Template Name: '. $userData['screentemplatename'],19);
            }
            $result = $this->tableGateway->update($userData, $whereCondition);
            return $result;
        }
      
 }