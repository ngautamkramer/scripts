<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class TblVersionInfoTable {
	protected $tableGateway;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}

	public function fetchAll($id) {
		if($id == "") {
		} else {
			$rowset = $this->tableGateway->select(array('client_version_fk' => $id));
			return $rowset;
		}
	}

	public function getDataByAppName($appName) {
		$rowset = $this->tableGateway->select(array('appname' => $appName));
		return $rowset;
		
	}
	public function deleteRecord($id)
	{
		$this->tableGateway->delete(array('client_version_fk' =>(int)$id));	
	}
}
