<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
 class TblDssFontInfoTable
 {
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }      

    public function inserDataForDssFont($userData) {     
        $appObj = new ApplicationController();
        if(PRODUCT=='via'){
            $appObj->ActivityLog('Upload','Font Name: ' . $userData["fontname"] ); 
        }else{
            $appObj->ActivityLogVSM(6,'Font Name: ' . $userData["fontname"],18); 
        }
            

        $this->tableGateway->insert($userData);
        //return $lastInsertid = $this->tableGateway->lastInsertValue;
        // for return last inserted id from pgsql
		return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('dss_font_fontid_seq');
    }

    // public function getUploadedDssFonts() {   
    //     $appObj = new ApplicationController();
    //     $sqlSelect = $this->tableGateway->getSql()->select();
    //     $sqlSelect->columns(array('*'));            
    //     $sqlSelect->where(array('fontstatus' => 1));
    //     $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
    //     $resultSet = $statement->execute();
    //     return $resultSet;                  
    // }

    public function getUploadedDssFonts() {   
        // this function bring the all font along with the association            
        $appObj = new ApplicationController();            
        $sqlQuery = "SELECT distinct df.fontfilename, df.fontname, df.fontid, ds.fontid_fk  
            FROM dss_font as df 
            LEFT JOIN dss_scrollerinfo as ds 
                on df.fontid = ds.fontid_fk 
            WHERE df.fontstatus = 1 
            ORDER BY df.fontid";
        $resultSet = $appObj->returnQueryData($sqlQuery);  
        return $resultSet;                  
    }

    public function checkIsFontDuplicate($fontName) {
        $sqlSelect = $this->tableGateway->getSql()->select();
        $sqlSelect->columns(array('fontid'));
        $sqlSelect->where(array("fontname" => $fontName, "fontstatus" => 1));
        $resultSet = $this->tableGateway->selectWith($sqlSelect);            
        return $resultSet; 
    }

    public function getDssFontIdByFontName($fontName) {
        $sqlSelect = $this->tableGateway->getSql()->select();
        $sqlSelect->columns(array('fontid'));
        $sqlSelect->where(array(" fontname" => $fontName));
        $resultSet = $this->tableGateway->selectWith($sqlSelect);            
        return $resultSet; 
    }
	//Modified by ashu on 18Aug2022 to change this function according to zend
    function checkFontAssociation($fontId) {
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('fontid'));
			$sqlSelect->join('dss_scrollerinfo', 'dss_font.fontid = dss_scrollerinfo.fontid_fk', array(), 'INNER');
			$sqlSelect->where(array("dss_font.fontstatus" => 1,"dss_font.fontid"=>$fontId));			
			//echo $sql->getSqlstringForSqlObject($sqlSelect); die ;			
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
            return $resultSet; 
    }

    function updateDssFonts($userData, $whereCondition) {  
        $appObj = new ApplicationController();
        if($whereCondition["fontname"]) {
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Upload','Font Name: ' . $userData["fontname"] ); 
            }else{
                $appObj->ActivityLogVSM(6,'Font Name: ' . $userData["fontname"],18);
            }
                 
        }
        $result = $this->tableGateway->update($userData, $whereCondition);
        return $result;
    }

    function updateDssFontsAndSendMsgToApi($userData, $whereCondition, $logincmd, $actionCmd) {
        $this->updateDssFonts($userData, $whereCondition);
        $appObj = new ApplicationController(); 
        $session = new Container('userinfo');
        $name = $session->offsetGet('LoginName');
        if(PRODUCT=='via'){
            $appObj->ActivityLog('Delete','Delete font by'.' '.$name);
        }else{
            $appObj->ActivityLogVSM(5,'Delete font by'.' '.$name,18);
        }           
        $appObj->sendMsgToAPIserver($logincmd, $actionCmd);                    
    }
    
    function getFontNameWithStyles() {
        $appObj = new ApplicationController();            
        $sqlQuery = "SELECT distinct df.fontname, df.fontid, df.fontitalic, df.fontbolditalic, df.fontbold, 
                df.fontnormal, df.fontblack, df.fontblackitalic, df.fontlight, df.fontlightitalic, ds.fontid_fk  
            FROM dss_font as df 
            LEFT JOIN dss_scrollerinfo as ds 
                on df.fontid = ds.fontid_fk 
            WHERE df.fontstatus = 1 
            ORDER BY df.fontid";
        $resultSet = $appObj->returnQueryData($sqlQuery);  
        return $resultSet;  
    }
    
 }