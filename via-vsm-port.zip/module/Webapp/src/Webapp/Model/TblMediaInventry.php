<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblMediaInventry implements InputFilterAwareInterface
{
    public $mediaid;
    public $medianame;
    public $mediatypeid;
    public $mediaoriginalname;
    public $mediapath;
    public $playlength;
    public $autotype;
    public $isfiller;
    public $clientid;
    public $appname;
    public $username;
    public $hostname;
    public $modifydate;
    public $isdeleted;
    public $mediachecksum;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->mediaid= (isset($data['mediaid']))? $data['mediaid']: null;
        $this->medianame= (isset($data['medianame']))? $data['medianame']: null;
        $this->mediatypeid = (isset($data['mediatypeid'])) ? $data['mediatypeid'] : null;
        $this->mediaoriginalname= (isset($data['mediaoriginalname']))? $data['mediaoriginalname']: null;
        $this->mediapath= (isset($data['mediapath']))? $data['mediapath']: null;
        $this->playlength = (isset($data['playlength'])) ? $data['playlength'] : null;
        $this->autotype= (isset($data['autotype']))? $data['autotype']: null;
        $this->isfiller= (isset($data['isfiller']))? $data['isfiller']: null;
        $this->clientid = (isset($data['clientid'])) ? $data['clientid'] : null;
        $this->appname= (isset($data['appname']))? $data['appname']: null;
        $this->username= (isset($data['username']))? $data['username']: null;
        $this->hostname = (isset($data['hostname'])) ? $data['hostname'] : null;
        $this->modifydate= (isset($data['modifydate']))? $data['modifydate']: null;
        $this->isdeleted= (isset($data['isdeleted']))? $data['isdeleted']: null;
        $this->mediachecksum = (isset($data['mediachecksum'])) ? $data['mediachecksum'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
