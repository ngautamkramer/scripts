<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;

 class TblCampaignTemplateTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }      

        public function insertTemplateAssociationInCampaign($data) {
            $appObj = new ApplicationController();  
            //$appObj->ActivityLog('Insert Campaign Template Association','Campaign Id: '. $data['campaign_id']. ' Template Id: '. $data['template_id']);
            $this->tableGateway->insert($data);
            //return $lastInsertid = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('campaign_template_id_seq');
        } 

        public function deleteTemplateAssociationInCampaign($whereCondition) {
            $appObj = new ApplicationController();  
            //$appObj->ActivityLog('Delete Campaign Template Association','Campaign Id: '. $whereCondition['campaign_id']);
            $this->tableGateway->delete($whereCondition);  
        }

        public function getTemplateAsssociationInCampaign($templatetId) {
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('*'));
            $sqlSelect->where(array("template_id" => $templatetId));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);            
            return $resultSet; 
        }
 }