<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblHqConfigurationTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
		
		public function getAllHqConfig()
		{
			$select = $this->tableGateway->getSql()->select();
			 $select->columns(array('*'));	
			 $resultSet =$this->tableGateway->selectWith($select);	
			 return $resultSet;
		}
                
                public function updateConfiguration($updateArr){
                    $sqlupdate = $this->tableGateway->update($updateArr);
                    return $sqlupdate;
                }
	
 }