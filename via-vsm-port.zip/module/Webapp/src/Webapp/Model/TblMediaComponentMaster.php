<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblMediaComponentMaster
{
    public $mediacomponentid;
    public $mediacomponentname;
    public $comments;
    public $os;
    public $active;  
    public $orderid;

    public function exchangeArray($data){
        $this->mediacomponentid = (isset($data['mediacomponentid']))? $data['mediacomponentid']: null;
        $this->mediacomponentname = (isset($data['mediacomponentname']))? $data['mediacomponentname']: null;
        $this->comments = (isset($data['comments'])) ? $data['comments'] : null;
        $this->os  = (isset($data['os']))  ? $data['os']  : null;
	    $this->active  = (isset($data['active']))  ? $data['active']  : null;	    
	    $this->orderid = (isset($data['orderid']))? $data['orderid']: null;
    }
       

	 
}
