<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblVersionInfo 
{
    public $version_id;
    public $client_version_fk;
    public $appname;
    public $version_no;
	public $modifydate;
	public $appmappingname;
    


    public function exchangeArray($data){
        $this->version_id= (isset($data['version_id']))? $data['version_id']: null;
        $this->client_version_fk= (isset($data['client_version_fk']))? $data['client_version_fk']: null;
        $this->appname = (isset($data['appname'])) ? $data['appname'] : null;
        $this->version_no = (isset($data['version_no'])) ? $data['version_no'] : null;
		$this->modifydate = (isset($data['modifydate'])) ? $data['modifydate'] : null;
		$this->appmappingname = (isset($data['appmappingname'])) ? $data['appmappingname'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:



}
