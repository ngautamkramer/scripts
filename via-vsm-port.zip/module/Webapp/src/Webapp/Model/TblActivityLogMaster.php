<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblActivityLogMaster
{
    public $activityid;
    public $userid;
    public $actiontaken;
    public $activitydate;
    public $remarks;
    public $hostname;
    public $modulename;
    
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->activityid= (isset($data['activityid']))? $data['activityid']: null;
        $this->userid= (isset($data['userid']))? $data['userid']: null;
        $this->actiontaken = (isset($data['actiontaken'])) ? $data['actiontaken'] : null;
        $this->activitydate  = (isset($data['activitydate']))  ? $data['activitydate']  : null;
		$this->remarks  = (isset($data['remarks']))  ? $data['remarks']  : null;
		$this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null;
        if(PRODUCT=='vsm'){
            $this->modulename  = (isset($data['modulename']))  ? $data['modulename']  : null;
        }     
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }
	 
}
