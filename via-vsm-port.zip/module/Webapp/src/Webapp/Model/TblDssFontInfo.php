<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblDssFontInfo
{
  	public $fontid;
    public $fontname;
    public $fontitalic;
    public $fontbolditalic;
    public $fontbold;
    public $fontnormal;    
    public $fontblack;    
    public $fontblackitalic;    
    public $fontlight;    
    public $fontlightitalic;    
    public $fontfilename;    
    public $fontstatus;    
    public $modifydate; 
    public $fontuuid;

    public function exchangeArray($data){
        $this->fontid = (isset($data['fontid']))? $data['fontid']: null;
        $this->fontname = (isset($data['fontname']))? $data['fontname']: null;
        $this->fontitalic = (isset($data['fontitalic'])) ? $data['fontitalic'] : null;
        $this->fontbolditalic  = (isset($data['fontbolditalic']))  ? $data['fontbolditalic']  : null;
	    $this->fontbold  = (isset($data['fontBold']))  ? $data['fontBold']  : null;	    
        $this->fontnormal  = (isset($data['fontnormal']))  ? $data['fontnormal']  : null;
        $this->fontblack  = (isset($data['fontblack']))  ? $data['fontblack']  : null;
        $this->fontblackitalic  = (isset($data['fontblackitalic']))  ? $data['fontblackitalic']  : null;
        $this->fontlight  = (isset($data['fontlight']))  ? $data['fontlight']  : null;
        $this->fontlightitalic  = (isset($data['fontlightitalic']))  ? $data['fontlightitalic']  : null;
        $this->fontfilename  = (isset($data['fontfilename']))  ? $data['fontfilename']  : null;
        $this->fontstatus  = (isset($data['fontstatus']))  ? $data['fontstatus']  : null;
        $this->modifydate  = (isset($data['modifydate']))  ? $data['modifydate']  : null;
        $this->fontuuid  = (isset($data['fontuuid']))  ? $data['fontuuid']  : null;       
    }
       

	 
}
