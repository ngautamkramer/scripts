<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblProjectorLog implements InputFilterAwareInterface
{
    public $projectorlogid;
    public $username;
    public $activitydate;
    public $starttime;
    public $endtime;
    public $deviceid; 
	public $playedtype; 
	public $comments;
	public $userprofile;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->projectorlogid= (isset($data['projectorlogid']))? $data['projectorlogid']: null;
        $this->username= (isset($data['username']))? $data['username']: null;
        $this->activitydate= (isset($data['activitydate'])) ? $data['activitydate'] : null;
        $this->starttime  = (isset($data['starttime']))  ? $data['starttime']  : null;
	    $this->endtime  = (isset($data['endtime']))  ? $data['endtime']  : null;
	    $this->deviceid  = (isset($data['deviceid']))  ? $data['deviceid']  : null;     
		$this->playedtype  = (isset($data['playedtype']))  ? $data['playedtype']  : null;     
		$this->comments  = (isset($data['comments']))  ? $data['comments']  : null;     
		$this->userprofile  = (isset($data['userprofile']))  ? $data['userprofile']  : null;     
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}