<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblGatewayCustomizeHomepageMapping
 {
	  public $id;
	  public $FrameID;
	  public $ScreenTemplateID;
	  public $FrameName;   
	  public $FrameHeight;   
	  public $FrameWidth;
	  public $FrameLeft;
	  public $FrameTop;
	  public $AspectRatio;
	  public $UserName;
	  public $hostname;
	  public $isGrpOrDeviceId;
	  public $entryType;
	  public $os_type;
	  public $modifydate;
	  public $field1;
	  public $field2;
	  public $field3;
	  public $field4;
	  public $field5;
	  public $field6;
	  public $field7;
	  public $field8;
	  public $field9;
	  public $field10;
	  
      public function exchangeArray($data){
		 $this->id = (isset($data['id']))? $data['id']: null;
		 $this->FrameID = (isset($data['FrameID']))? $data['FrameID']: null;
		 $this->ScreenTemplateID = (isset($data['ScreenTemplateID']))? $data['ScreenTemplateID']: null;
		 $this->FrameName = (isset($data['FrameName']))? $data['FrameName']: null;
		 $this->FrameHeight = (isset($data['FrameHeight']))? $data['FrameHeight']: null; 
		 $this->FrameWidth = (isset($data['FrameWidth']))? $data['FrameWidth']: null;
		 $this->FrameLeft = (isset($data['FrameLeft']))? $data['FrameLeft']: null;
		 $this->FrameTop = (isset($data['FrameTop']))? $data['FrameTop']: null;
		 $this->AspectRatio = (isset($data['AspectRatio']))? $data['AspectRatio']: null;
		 $this->UserName = (isset($data['UserName']))? $data['UserName']: null;
		 $this->hostname = (isset($data['hostname']))? $data['hostname']: null;
		 $this->isGrpOrDeviceId = (isset($data['isGrpOrDeviceId']))? $data['isGrpOrDeviceId']: null;
		 $this->entryType = (isset($data['entryType']))? $data['entryType']: null;
		 $this->os_type = (isset($data['os_type']))? $data['os_type']: null;
		 $this->modifydate = (isset($data['modifydate']))? $data['modifydate']: null;
		 $this->field1 = (isset($data['field1']))? $data['field1']: null;
		 $this->field2 = (isset($data['field2']))? $data['field2']: null;
		 $this->field3 = (isset($data['field3']))? $data['field3']: null;
		 $this->field4 = (isset($data['field4']))? $data['field4']: null;
		 $this->field5 = (isset($data['field5']))? $data['field5']: null;
		 $this->field6 = (isset($data['field6']))? $data['field6']: null;
		 $this->field7 = (isset($data['field7']))? $data['field7']: null;
		 $this->field8 = (isset($data['field8']))? $data['field8']: null;
		 $this->field9 = (isset($data['field9']))? $data['field9']: null;
		 $this->field10 = (isset($data['field10']))? $data['field10']: null;
	}
        
	public function getArrayCopy()
	{
		return get_object_vars($this);
	}

 }