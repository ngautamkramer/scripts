<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblGatewayFeaturesPosition
 {
	  public $id;
	  public $gateway_feature_fk;
  
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->gateway_feature_fk= (isset($data['gateway_feature_fk']))? $data['gateway_feature_fk']: null;
		 
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }