<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;

 class TblCampaignMediaTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }      

        public function insertMediaAssociationInCampaign($data) {
            $appObj = new ApplicationController();  
            //$appObj->ActivityLog('Insert Campaign Media Association','Campaign Id: '. $data['campaign_id']. ' Media Id: '. $data['media_id']);
            $this->tableGateway->insert($data);
            //return $lastInsertid = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('campaign_media_id_seq');
        } 

        public function deleteMediaAssociationInCampaign($whereCondition) {
            $appObj = new ApplicationController();  
            //$appObj->ActivityLog('Delete Campaign Media Association','Campaign Id: '. $whereCondition['campaign_id']);
            $this->tableGateway->delete($whereCondition);  
        }

        public function getMediaAssociationInCampaign($mediaId) {
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('*'));
            $sqlSelect->where(array("media_id" => $mediaId));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);            
            return $resultSet; 
        }
 }