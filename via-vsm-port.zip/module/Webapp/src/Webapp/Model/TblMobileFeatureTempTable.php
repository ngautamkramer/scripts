<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblMobileFeatureTempTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function clearTableData(){
            $resultSet = $this->tableGateway->select();
            $count = $resultSet->count();
            if($count>0){
                $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
                $query->execute();
            }
        }
        
        public function truncateTable(){
            $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
            $query->execute();
        }
        
        public function getDeletedFeatures($delete_flag){
            $sqlQry = $this->tableGateway->getSql()->select();
            $sqlQry->where(array('delete_flag'=>$delete_flag));
            $resultSet =$this->tableGateway->selectWith($sqlQry);
            $rows = $resultSet->count();
            $result['count'] = $rows;
            if($rows>0){
                foreach($resultSet as $key => $feature){
                    $result['data'][$key]['feature_deleted_id'] =  $feature->feature_deleted_id;
                }
            }
                return $result;           
        }
	
        public function insertData($valueArr){
            $this->tableGateway->insert($valueArr);
        }
 }