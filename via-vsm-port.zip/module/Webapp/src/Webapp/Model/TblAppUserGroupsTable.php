<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Webapp\Model\UserPermission;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
/*****
 *	@Class Name			: appusergroups
 *  @description	    : Using for database actions                       
 *	@Author			    : Ashu 
 *  @Date               : 17-Dec-2019
 *****/ 
 class TblAppUserGroupsTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }       
		
        public function deleteUserPermission($usrid){            
            $this->tableGateway->delete(array('appuserid' => (int) $usrid));
        }
		
		public function fetchUserPermissionsById($usrid) {
			 $usrid  = (int) $usrid;			
			 $resultSet = $this->tableGateway->select(array('appuserid' => $usrid));
			 return $resultSet;
		}
		

        public function saveUserPermission($userData,$lastInsertId,$sessionLoginName){
			if($userData['otherusr']!=""){
				$data = array(
	                 'appuserid' => $lastInsertId,
	                 'appgroupid'  => $userData['otherusr'],                 
					 'modifydate'=>date("Y-m-d H:i:s"),
					 'hostname'=>HOSTNAME,
					 'username'=>$sessionLoginName,	
	             );	
				 $this->tableGateway->insert($data);		
			}
		
			if($userData['chkAdministrator']==1){
				$data = array(
	                 'appuserid' => $lastInsertId,
	                 'appgroupid'  => 1,                 
					 'modifydate'=>date("Y-m-d H:i:s"),
					 'hostname'=>HOSTNAME,
					 'username'=>$sessionLoginName,	
	             );	
				 $this->tableGateway->insert($data);
			}
			if($userData['audianceResponse']==40){
				$data = array(
	                 'appuserid' => $lastInsertId,
	                 'appgroupid'  => 40,                 
					 'modifydate'=>date("Y-m-d H:i:s"),
					 'hostname'=>HOSTNAME,
					 'username'=>$sessionLoginName,	
	             );	
				$this->tableGateway->insert($data);
			
			}
			if($userData['dss']==41){
				$data = array(
	                 'appuserid' => $lastInsertId,
	                 'appgroupid'  => 41,                 
					 'modifydate'=>date("Y-m-d H:i:s"),
					 'hostname'=>HOSTNAME,
					 'username'=>$sessionLoginName,	
	             );	
				 $this->tableGateway->insert($data);
			}	 
     	}

 }