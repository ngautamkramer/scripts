<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblHqConfiguration
 {
	  public $HQ_Config_Id;
	  public $HQ_WallpaperSetting;
	  public $HQ_AuthSetting;   
	  public $HQ_ConfigSetting;   
	  public $HQ_GwayFeatureSetting;   
	  public $HQ_ClientFeatureSetting;   
	  public $HQ_MobileFeatureSetting;   
	  
   public function exchangeArray($data)
	{
		 $this->HQ_Config_Id= (isset($data['HQ_Config_Id']))? $data['HQ_Config_Id']: null;
		 $this->HQ_WallpaperSetting= (isset($data['HQ_WallpaperSetting']))? $data['HQ_WallpaperSetting']: null;
		 $this->HQ_AuthSetting= (isset($data['HQ_AuthSetting']))? $data['HQ_AuthSetting']: null;
		 $this->HQ_ConfigSetting= (isset($data['HQ_ConfigSetting']))? $data['HQ_ConfigSetting']: null; 
		 $this->HQ_GwayFeatureSetting= (isset($data['HQ_GwayFeatureSetting']))? $data['HQ_GwayFeatureSetting']: null;
		 $this->HQ_ClientFeatureSetting= (isset($data['HQ_ClientFeatureSetting']))? $data['HQ_ClientFeatureSetting']: null;
		 $this->HQ_MobileFeatureSetting= (isset($data['$HQ_MobileFeatureSetting']))? $data['HQ_MobileFeatureSetting']: null;
		 
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }