<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblGatewayFeatures
 {
	  public $id;
	  public $feature_name;
	  public $feature_btn_name;   
	  public $feature_status;   
	  public $date_time;   
	  public $feature_type;
	  public $field1;
	  
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->feature_name= (isset($data['feature_name']))? $data['feature_name']: null;
		 $this->feature_btn_name= (isset($data['feature_btn_name']))? $data['feature_btn_name']: null;
		 $this->feature_status= (isset($data['feature_status']))? $data['feature_status']: null; 
		 $this->date_time= (isset($data['date_time']))? $data['date_time']: null;
		 $this->feature_type= (isset($data['feature_type']))? $data['feature_type']: null;
		 $this->field1= (isset($data['field1']))? $data['field1']: null;	
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }