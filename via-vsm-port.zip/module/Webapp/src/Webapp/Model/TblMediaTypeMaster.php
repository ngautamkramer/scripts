<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblMediaTypeMaster implements InputFilterAwareInterface
{
    public $MediaTypeID;
    public $MediaType;
    public $MediaComponentID;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->MediaTypeID= (isset($data['MediaTypeID']))? $data['MediaTypeID']: null;
        $this->MediaType= (isset($data['MediaType']))? $data['MediaType']: null;
        $this->MediaComponentID = (isset($data['MediaComponentID'])) ? $data['MediaComponentID'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
