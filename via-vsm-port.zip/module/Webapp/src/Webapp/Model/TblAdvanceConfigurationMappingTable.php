<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblAdvanceConfigurationMappingTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		public function updateAdvanceConfiguration($value,$checkBoxName)
		{
			if($checkBoxName=="presentationMode")
			{
				$result=$this->tableGateway->update(array('feature6' => 0,'feature8'=>0)); 
			}
			
			else if($checkBoxName=="participantConfChkbox")
			{
				$result=$this->tableGateway->update(array('feature6'=>$value)); 
			}
			
			else if($checkBoxName=="setPollingConfiguration")
			{
				//$result=$this->tableGateway->update(array('feature8'=>$value,'last_updated'=>now())); 
				$result=$this->tableGateway->update(array('feature8'=>$value)); 
			}
			return $result;
		}
		public function getData($condition){
			  $sqlSelect = $this->tableGateway->getSql()->select();
			  $sqlSelect->where($condition);
			  $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
			  $resultSet = $statement->execute();	
			  return  $resultSet;
		}
		
		public function deleteData($condition){
			  $this->tableGateway->delete($condition);
		}
                
		public function fetchAll() { 
			$select = $this->tableGateway->getSql()->select();
			$resultSet = $this->tableGateway->selectWith($select);
			return $resultSet;
		}
        
        public function updateFeatures($data){
            $this->tableGateway->update($data);  
        }
 }