<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblMobileFeaturesPositionTable
 {
        protected $tableGateway;
	public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	public function getMobileFeaturesPositionCount()
        {
            $select = $this->tableGateway->select();
            $count = $select->count();
            return  $count ;
        }
        
        public function insertFeaturesPosition($mobile_feature){
            $select = $this->tableGateway->insert(array('mobile_feature_fk'=>$mobile_feature));
        }
        
        public function truncateTable(){
            $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
            $query->execute();
        }
 }


