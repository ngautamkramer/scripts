<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblDisplaySettings implements InputFilterAwareInterface
{
    public $id;
    public $activate_RoomName;
    public $show_RoomName_Color;
    public $activate_RoomCode;
    public $active_showOnWallpaper;
    public $activate_RefreshTime; 
    public $activate_DateTime;	 
    public $show_DateTime_Wallp_Color;	
    public $activate_RoomName_SecondDisplay;
    public $twentyfourHoursFormat;
    public $mirrorMaxCon;
    public $mirrorName;
    public $activateDynamicLayout;
    public $qrcode;
    public $qrbypass;
    public $qrtop;
    public $activateRoomOverlay;
    public $RoomOverlayValue;
    public $os_type;
    public $field1;
    public $field2;
    public $field3;
    public $field4;
    public $field5;
    public $field6;
    public $field7;
    public $field8;
    public $field9;
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->activate_RoomName= (isset($data['activate_RoomName']))? $data['activate_RoomName']: null;
        $this->show_RoomName_Color = (isset($data['show_RoomName_Color'])) ? $data['show_RoomName_Color'] : null;
        $this->activate_RoomCode  = (isset($data['activate_RoomCode']))  ? $data['activate_RoomCode']  : null;
	$this->active_showOnWallpaper  = (isset($data['active_showOnWallpaper']))  ? $data['active_showOnWallpaper']  : null;
	$this->activate_RefreshTime  = (isset($data['activate_RefreshTime']))  ? $data['activate_RefreshTime']  : null;
	$this->activate_DateTime  = (isset($data['activate_DateTime']))  ? $data['activate_DateTime']  : null;
	$this->show_DateTime_Wallp_Color  = (isset($data['show_DateTime_Wallp_Color']))  ? $data['show_DateTime_Wallp_Color']  : null;
	$this->activate_RoomName_SecondDisplay  = (isset($data['activate_RoomName_SecondDisplay']))  ? $data['activate_RoomName_SecondDisplay']  : null;
        $this->twentyfourHoursFormat  = (isset($data['24HoursFormat']))  ? $data['24HoursFormat']  : null;
        $this->mirrorMaxCon  = (isset($data['mirrorMaxCon']))  ? $data['mirrorMaxCon']  : null;
        $this->mirrorName  = (isset($data['mirrorName']))  ? $data['mirrorName']  : null;
        $this->activateDynamicLayout  = (isset($data['activateDynamicLayout']))  ? $data['activateDynamicLayout']  : null;
	$this->qrcode  = (isset($data['qrcode']))  ? $data['qrcode']  : null;	 
	$this->qrbypass  = (isset($data['qrbypass']))  ? $data['qrbypass']  : null;	 
	$this->qrtop  = (isset($data['qrtop']))  ? $data['qrtop']  : null;
        $this->activateRoomOverlay  = (isset($data['activateRoomOverlay']))  ? $data['activateRoomOverlay']  : null;
        $this->RoomOverlayValue  = (isset($data['RoomOverlayValue']))  ? $data['RoomOverlayValue']  : null;
        $this->os_type  = (isset($data['os_type']))  ? $data['os_type']  : null;
        $this->field1  = (isset($data['field1']))  ? $data['field1']  : null;
        $this->field2  = (isset($data['field2']))  ? $data['field2']  : null;
        $this->field3  = (isset($data['field3']))  ? $data['field3']  : null;
        $this->field4  = (isset($data['field4']))  ? $data['field4']  : null;
        $this->field5  = (isset($data['field5']))  ? $data['field5']  : null;
        $this->field6  = (isset($data['field6']))  ? $data['field6']  : null;
        $this->field7  = (isset($data['field7']))  ? $data['field7']  : null;
        $this->field8  = (isset($data['field8']))  ? $data['field8']  : null;
        $this->field9  = (isset($data['field9']))  ? $data['field9']  : null;
        
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
