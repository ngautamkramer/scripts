<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class TblRecordingMasterTable {
	protected $tableGateway;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}

	public function fetchAll($userid, $deviceId) {
		$select = $this->tableGateway->getSql()->select();
		if(PRODUCT=="vsm"){
		if($userid != 1) {
			$select->columns(array('rmasterId', 'rmaster', 'reserved1', 'sessionname', 'description'));
			$select->join('recordingchild', 'recordingchild.rmaster = recordingmaster.rmaster AND recordingchild.reserved1= recordingmaster.reserved1', array('user'), 'inner')->join('DeviceInventory', 'DeviceInventory.DID = recordingmaster.reserved1', array('DeviceGroupID'), 'inner');
			$select->columns(array('*', 'filename' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(recordingchild.filename SEPARATOR ',')")));
			$select->where(array("DeviceInventory.DeviceGroupID IN ($deviceId)"));
		} else {
			$select->columns(array('rmasterId', 'rmaster', 'reserved1', 'sessionname', 'description'));
			$select->join('recordingchild', 'recordingchild.rmaster = recordingmaster.rmaster AND recordingchild.reserved1= recordingmaster.reserved1', array('user'), 'inner');
			$select->columns(array('*', 'filename' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(recordingchild.filename SEPARATOR ',')")));
		}
		$select->group(array('recordingchild.rmaster', 'recordingchild.reserved1'));
	}else{
		
		$select->columns(['description', 'sessionname']);
		$select->join(
		    'recordingchild', 
		    'recordingchild.rmaster = recordingmaster.rmaster', 
		    [
		        'rmaster' => new \Zend\Db\Sql\Expression("array_to_string(array_agg(DISTINCT recordingchild.rmaster), ',')"),
		        'starttime' => new \Zend\Db\Sql\Expression("array_to_string(array_agg(DISTINCT recordingchild.starttime), ',')"),
		        'duration' => new \Zend\Db\Sql\Expression("array_to_string(array_agg(DISTINCT recordingchild.duration), ',')"),
		        'user' => new \Zend\Db\Sql\Expression("array_to_string(array_agg(DISTINCT recordingchild.user), ',')")
		    ], 
		    'left'
		);
		$select->columns([ '*',
			'reserved21' => new \Zend\Db\Sql\Expression("string_agg(recordingchild.reserved2, ',')"),
    		'filename' => new \Zend\Db\Sql\Expression("string_agg(recordingchild.filename, ',')")
		]);
		//MAX() used to aggrigate in postgresql
		$select->where(['recordingchild.status' => 3]);
		$select->group('recordingmaster.rmaster');
		//echo $select->getSqlString();

	}
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		$resultSet = $statement->execute();
		$result['count'] = $resultSet->count();
		$paginatorAdapter = new DbSelect($select, $this->tableGateway->getAdapter(), $resultSetPrototype);
		$resultSet = new Paginator($paginatorAdapter);
		$result['data']=$resultSet;	       
		return $result; 
	}

	public function getRecording($userid, $deviceId, $searchKey) {
		$select = $this->tableGateway->getSql()->select();
		if(PRODUCT=='vsm'){
		if($userid != 1) {
			$select->columns(array('rmasterId', 'rmaster', 'reserved1', 'sessionname', 'description'));
			$select->join('recordingchild', 'recordingchild.rmaster = recordingmaster.rmaster AND recordingchild.reserved1= recordingmaster.reserved1', array('user'), 'inner')->join('DeviceInventory', 'DeviceInventory.DID = recordingmaster.reserved1', array('DeviceGroupID'), 'inner');
			$select->columns(array('*', 'filename' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(recordingchild.filename SEPARATOR ',')")));
			$select->where->expression("CONCAT(recordingmaster.sessionname,recordingchild.user) ILIKE ?",  '%'.$searchKey.'%');
			$select->where(array("DeviceInventory.DeviceGroupID IN ($deviceId)"));
			
		} else {
			$select->columns(array('rmasterId', 'rmaster', 'reserved1', 'sessionname', 'description'));
			$select->join('recordingchild', 'recordingchild.rmaster = recordingmaster.rmaster AND recordingchild.reserved1= recordingmaster.reserved1', array('user'), 'inner');
			$select->columns(array('*', 'filename' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(recordingchild.filename SEPARATOR ',')")));
			$select->where->expression("CONCAT(recordingmaster.sessionname,recordingchild.user) ILIKE ?",  '%'.$searchKey.'%');
		}
			$select->group(array('recordingchild.rmaster', 'recordingchild.reserved1'));
	}else{

		$select->columns(['sessionname']);
		$select->join(
		    'recordingchild', 
		    'recordingchild.rmaster = recordingmaster.rmaster', 
		    ['user' => new \Zend\Db\Sql\Expression("array_to_string(array_agg(DISTINCT recordingchild.user), ',')")], 
		    'left'
		);
		$select->columns([ '*',
			'reserved21' => new \Zend\Db\Sql\Expression("string_agg(recordingchild.reserved2, ',')"),
    		'filename' => new \Zend\Db\Sql\Expression("string_agg(recordingchild.filename, ',')")
		]);
		//MAX() used to aggrigate in postgresql
		$select->where(['recordingchild.status' => 3]);
		$select->where->expression("CONCAT(recordingmaster.sessionname,recordingchild.user) ILIKE ?",  '%'.$searchKey.'%');
		$select->group(array('recordingmaster.rmaster'));

	}
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$resultSet = $statement->execute();
			$result['count'] = $resultSet->count();
			$paginatorAdapter = new DbSelect($select, $this->tableGateway->getAdapter(), $resultSetPrototype);
			$resultSet = new Paginator($paginatorAdapter);
			$result['data']=$resultSet;	       
			return $result; 
	}

	public function getRecordingDataById($recordingid) {
		$recordingid = (int) $recordingid;
		if(PRODUCT=='vsm'){
			$rowset = $this->tableGateway->select(array('rmasterId' => $recordingid));
		}else{
			$rowset = $this->tableGateway->select(array('rmaster' => $recordingid));
		}
		
		$row = $rowset->current();
		if(!$row) {
			throw new \Exception("Could not find row");
		}
		return $row;
	}

	public function updateRecording($recordingId, $session, $description) {
		$recordingId = (int) $recordingId;
		$data = array('sessionname' =>htmlspecialchars($session),
					  'description' =>htmlspecialchars($description),
					 );
		if(PRODUCT=='vsm'){
			$result = $this->tableGateway->update($data, array('rmasterId' => $recordingId));
		}else{
			$result = $this->tableGateway->update($data, array('rmaster' => $recordingId));
		}
		
		return $result;
	}

	public function deleteRecording($recordingId) {
		$recordingId = (int) $recordingId;
		$this->tableGateway->delete(array('rmaster' => $recordingId));
	}
}
