<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;

 class TblMediaComponentMasterTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }        

        function getActiveMediaComponents() {
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT mediacomponentid, mediacomponentname, active, orderid
                FROM mediacomponentmaster
                    WHERE active = '1'
                ORDER BY orderid ASC";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

    
 }