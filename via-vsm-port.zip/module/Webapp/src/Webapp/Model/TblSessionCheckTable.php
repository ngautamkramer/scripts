<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
 class TblSessionCheckTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

        public function getSessionCheckData($data) {
			$appObj = new ApplicationController();  
        	$sessionLoginName = $data['sessionLoginName'];
        	$sessionid = session_id();
        	$sessionTimeOut = $data["sessionTimeOut"] * 60;
            $sqlQuery = "SELECT * FROM tbl_session_check WHERE userid = '".$sessionLoginName."' AND sessionid = '".$sessionid."' AND extract(epoch FROM NOW())- datetime < $sessionTimeOut ";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

        public function updateSessionCheckData($data) {
        	$appObj = new ApplicationController();  
        	$sessionLoginName = $data['sessionLoginName'];
        	$sessionid = session_id();
        	$sqlQuery = "UPDATE tbl_session_check SET userid = '".$sessionLoginName."', sessionid = '".$sessionid."', datetime = extract(epoch FROM NOW()) WHERE userid = '".$sessionLoginName."' AND sessionid = '".$sessionid."'";
        	$resultSet = $appObj->returnQueryData($sqlQuery);
        }
	
 }