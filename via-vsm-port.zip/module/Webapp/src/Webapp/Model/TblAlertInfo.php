<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblAlertInfo
 {
    public $id;
    public $userid_fk;
    public $grpid_fk;
    public $entrytype;
    public $alertid_fk;
    public $min_threshold_value;
    public $max_threshold_value;
    public $description;
    public $start_date;
    public $end_date;

    public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		$this->userid_fk= (isset($data['userid_fk']))? $data['userid_fk']: null;
		$this->grpid_fk= (isset($data['grpid_fk']))? $data['grpid_fk']: null;
		$this->entrytype= (isset($data['entrytype']))? $data['entrytype']: null;
        $this->alertid_fk= (isset($data['alertid_fk']))? $data['alertid_fk']: null;
        $this->min_threshold_value= (isset($data['min_threshold_value']))? $data['min_threshold_value']: null;
        $this->max_threshold_value= (isset($data['max_threshold_value']))? $data['max_threshold_value']: null;
        $this->description= (isset($data['description']))? $data['description']: null;
        $this->start_date= (isset($data['start_date']))? $data['start_date']: null;
        $this->end_date= (isset($data['end_date']))? $data['end_date']: null;
    }
    public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }