<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblLicenseUsed
{
  	public $lic_id;
    public $uniqueid;
    public $did;
    public $expiry_date;
    public $license_issued_date;
	public $gateway_name;

    public function exchangeArray($data){
        $this->lic_id = (isset($data['lic_id']))? $data['lic_id']: null;
        $this->uniqueid = (isset($data['uniqueid']))? $data['uniqueid']: null;
        $this->did = (isset($data['did'])) ? $data['did'] : null;
        $this->expiry_date  = (isset($data['expiry_date']))  ? $data['expiry_date']  : null;
	    $this->license_issued_date  = (isset($data['license_issued_date']))  ? $data['license_issued_date']  : null;
		$this->gateway_name  = (isset($data['gateway_name']))  ? $data['gateway_name']  : null;	    
    }
       

	 
}
