<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
/*****
 *	@Class Name			: Thirdpartyapps
 *  @description	    : Using for database actions                       
 *	@Author			    : Ashu
 *  @Date               : 23-Aug-2022
 *****/ 
 class TblThirdpartyappsTable
 {
        protected $tableGateway;
        public function __construct(TableGateway $tableGateway){
            $this->tableGateway = $tableGateway;
        }

		/*****
		 *	@Function Name		: fetchAll
		 *  @description	    : It works return all table data.
		 *****/		
		 public function fetchAll(){
			//$resultSet = $this->tableGateway->select();			 
			 //return $resultSet;
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT * FROM thirdpartyapps";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
			 
		 }
		
		/*****
		 *	@Function Name		: checkAppName
		 *  @description	    : It checks unique appname
		 *****/				 
        public function checkAppName($postData){
             $rowset = $this->tableGateway->select(array('tpname' => strtolower($postData['tpaname'])));
             return $rowset;
        }
		
		/*****
		 *	@Function Name		: checkAppNameById
		 *  @description	    : It checks unique appname by id
		 *****/	
        public function checkAppNameById($data){//echo "<pre>";print_r($postData);die;
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('tpname'));			
			$sqlSelect->where(array("tpname" => strtolower($data["tpaname"]),"tpsn!= ".$data["tpa_id"].""  ));					
			//echo $sql->getSqlstringForSqlObject($sqlSelect); die ;
			$sql->getSqlstringForSqlObject($sqlSelect); 	
			$resultSet = $this->tableGateway->selectWith($sqlSelect);		
            return $resultSet; 	
		
        }

		/*****
		 *	@Function Name		: checkAppUrl
		 *  @description	    : It checks appurl
		 *****/			
        public function checkAppUrl($postData){
             $rowset = $this->tableGateway->select(array('tppath'=>strtolower($postData['tpaurl']) ));
             return $rowset;
        }

		/*****
		 *	@Function Name		: checkAppUrlById
		 *  @description	    : It checks appurl by id
		 *****/	
        public function checkAppUrlById($data){//echo "<pre>";print_r($postData);die;
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('tppath'));			
			$sqlSelect->where(array("tppath" => strtolower($data["tpaurl"]),"tpsn!= ".$data["tpa_id"].""  ));					
			//echo $sql->getSqlstringForSqlObject($sqlSelect); die ;
			$sql->getSqlstringForSqlObject($sqlSelect); 	
			$resultSet = $this->tableGateway->selectWith($sqlSelect);		
            return $resultSet; 	
		
        }
		 
		/*****
		 *	@Function Name		: saveApp
		 *  @description	    : It is storing data in table
		 *****/	
        public function saveApp($appData,$sessionLoginName){
		    $txtRemarks="Added By ".$sessionLoginName;
		    $appObj = new ApplicationController();	
			$tpiconArr=explode('/',$appData['iconname']);	
			$iconName = strtolower(end($tpiconArr));	
            $data = array(
                 'tpname' => htmlspecialchars(trim($appData['tpaname'])),
				 'tppath' => htmlspecialchars(trim($appData['tpaurl'])),
                 'tpimage'=> '',
				 'param1'=>'URL'
             );		 
             $this->tableGateway->insert($data);   
         }

		/*****
		 *	@Function Name		: getTpaDataById
		 *  @description	    : It is returning all data by id
		 *****/			 
         public function getTpaDataById($tpaid){
             $tpaid  = (int) $tpaid;
             $rowset = $this->tableGateway->select(array('tpsn' => $tpaid));
             $row = $rowset->current();
             if (!$row) {
                 throw new \Exception("Could not find row $tpaid");
             }		 
             return $row;
         }
		 
		/*****
		 *	@Function Name		: updateApp
		 *  @description	    : It is updating data in table by id
		 *****/	
        public function updateApp($postData,$sessionLoginName){ //echo $data["tpa_id"];die;
			$tpiconArr=explode('/',$postData['iconname']);	
			$iconName = strtolower(end($tpiconArr));
		   $data = array(
				 'tpname'=>htmlspecialchars(trim($postData["tpaname"])),
				 'tppath'=>htmlspecialchars(trim($postData["tpaurl"])),
				 'tpimage'=> '',
				 'param1'=>'URL',				  
		   );		   	
		   $this->tableGateway->update($data, array('tpsn' => $postData["tpa_id"]));		  	
        }
		
		/*****
		 *	@Function Name		: deleteApp
		 *  @description	    : It is deleting data in table by id
		 *****/			
        public function deleteApp($appid){            
            $this->tableGateway->delete(array('tpsn' => (int) $appid));			
        }
		 
 }