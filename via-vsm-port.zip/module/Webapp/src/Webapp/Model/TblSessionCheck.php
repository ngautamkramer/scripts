<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblSessionCheck implements InputFilterAwareInterface
{
    public $id;
    public $userid;
    public $sessionid;
    public $datetime;
    public $field1;
    public $field2; 
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id = (isset($data['id'])) ? $data['id']: null;
        $this->userid = (isset($data['userid'])) ? $data['userid'] : null;
        $this->sessionid = (isset($data['sessionid'])) ? $data['sessionid'] : null;
        $this->datetime = (isset($data['datetime'])) ? $data['datetime'] : null;
    	$this->field1 = (isset($data['field1'])) ? $data['field1'] : null;  
        $this->field2 = (isset($data['field2'])) ? $data['field2'] : null;  
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
