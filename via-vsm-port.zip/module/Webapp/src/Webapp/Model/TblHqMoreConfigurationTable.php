<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblHqMoreConfigurationTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
		
		
        public function updateHqMoreConfiguration($updateArr){
            $sqlupdate = $this->tableGateway->update($updateArr);
        }
	
 }