<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblClientsFeaturesPositionTable
 {
        protected $tableGateway;
	public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	public function getClientsFeaturesPositionCount()
        {
            $select = $this->tableGateway->select();
            $count = $select->count();
            return  $count ;
        }
        
        public function insertFeaturesPosition($client_feature){
            $select = $this->tableGateway->insert(array('client_feature_fk'=>$client_feature));
        }
        
        public function truncateTable(){
            $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
            $query->execute();
        }
 }


