<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
 class TblMediaInventryTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

        public function getAllMediaInventory($mediaComponentId) {
            $appObj = new ApplicationController();  
            $mediaComponentIdChk = $mediaComponentId != "" ? "AND mtm.mediacomponentid = '".$mediaComponentId."'" : "" ;           
            $sqlQuery = "SELECT mv.mediaid, mv.medianame, mv.mediatypeid, mv.mediaoriginalname, mv.playlength, mv.mediasize, mv.playlength, mv.autotype, mv.isdeleted, mv.mediasize, mv.mediachecksum, mtm.mediatype, mcm.mediacomponentid, mcm.mediacomponentname, cm.media_id
                FROM mediainventry as mv 
                    INNER JOIN mediatypemaster as mtm
                        ON mv.mediatypeid = mtm.mediatypeid
                    INNER JOIN mediacomponentmaster as mcm  
                        ON mtm.mediacomponentid = mcm.mediacomponentid AND mv.mediatypeid = mtm.mediatypeid AND mcm.active = '1'  
                    LEFT JOIN (SELECT DISTINCT(media_id) as media_id  FROM campaign_media) as cm
                        ON mv.mediaid = cm.media_id
                WHERE isdeleted = 'N' $mediaComponentIdChk ORDER BY mv.mediaid DESC";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

        public function getMediaInventory($txtFileName) {
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT * FROM mediainventry 
                WHERE  medianame = '".$txtFileName."' AND isdeleted = 'N'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

        public function insertMediaInventory($data) {
            $appObj = new ApplicationController();   
            if (PRODUCT == 'via') {
                $appObj->ActivityLog('Upload', 'Media: '. $data['medianame']);
            }else{
                $appObj->ActivityLogVSM(6, 'Media: '.$data['medianame'], 18);
            }
            //$appObj->ActivityLog('Create Media','Media Name: '. $data['medianame']);

            $this->tableGateway->insert($data);
            //return $lastInsertid = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('mediainventry_mediaid_seq');
        } 

        public function updateMediaInventory($whereCondition, $userData) {
            $appObj = new ApplicationController();   
            if($userData['MediaName']) {
                if (PRODUCT == 'via') {
                    $appObj->ActivityLog('Update', 'Media: '. $userData['medianame']);
                }else{
                    $appObj->ActivityLogVSM(4, 'Media: '.$userData['medianame'], 18);
                }
                //$appObj->ActivityLog('Update Media','Media Name: '. $userData['medianame']);    
            }
            $result = $this->tableGateway->update($userData, $whereCondition);
            return $result;
        }

        public function updateDssScrollerInfo($userData) {
            $fontId_fk = $userData['fontId_fk'];
            $scrollfileName = $userData['scrollfileName'];
            $modifydatetime =  $userData['modifydatetime'];
            $appObj = new ApplicationController(); 
            //$appObj->ActivityLog('Insert Media Font','Font Id: '. $userData['MediaName']. 'File Name: '. $scrollfileName);
            $sqlQuery = "INSERT INTO dss_scrollerinfo(fontid_fk,scrollfilename,modifydatetime) values('".$fontId_fk."','".$scrollfileName."','".$modifydatetime."')";
            $appObj->executeQueries($sqlQuery);   
        }

        public function getContentDetail($data) {
            $contentId = $data["contentId"];
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT * FROM mediainventry as mi 
               INNER JOIN mediatypemaster as mtm
                    on mi.mediatypeid = mtm.mediatypeid
                INNER JOIN mediacomponentmaster as mcm 
                    on mtm.mediacomponentid = mcm.mediacomponentid
                WHERE  mi.mediaid = '".$contentId."' AND mi.isdeleted = 'N'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }
		
		//Change this function according to zend
        public function checkMediaUniqueName($data) {
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('mediaid'));
			if($data["mediaid"]){
				$sqlSelect->where(array("mediaid!= ".$data["mediaid"]."" ));
                $sqlSelect->where->expression("medianame ILIKE ?",  $data["MediaName"]);
			}else{
				//$sqlSelect->where(array("medianame" => $data["MediaName"]));
                $sqlSelect->where->expression("medianame ILIKE ?",  $data["MediaName"]);

			}		
			$sql->getSqlstringForSqlObject($sqlSelect); 	
			$resultSet = $this->tableGateway->selectWith($sqlSelect);		
            return $resultSet; 
        }

        public function checkFontWithMedia($userData) {
            $fontId_fk = $userData['fontId_fk'];
            $scrollfileName = $userData['scrollfileName'];
            $appObj = new ApplicationController(); 
            $sqlQuery = "SELECT * FROM dss_scrollerinfo 
                WHERE fontid_fk = '".$fontId_fk."' AND scrollfilename ILIKE '".$scrollfileName."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

        public function deleteMediaInventory($userData) {
            $mediaId = $userData['mediaId'];
            $appObj = new ApplicationController(); 
            //$appObj->ActivityLog('Delete Media','mediaid: '. $mediaId);
            $sqlQuery = "DELETE FROM mediainventry WHERE mediaid = '".$mediaId."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

        public function getMediaFilenameFromId($userData) {
            $mediaId = $userData['mediaId'];
            $appObj = new ApplicationController(); 
            $sqlQuery = "SELECT mediaoriginalname FROM mediainventry WHERE mediaid = '".$mediaId."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

        public function deleteDssScrollerInfo($userData) {
            $scrollfileName = $userData['scrollFileName'];
            $appObj = new ApplicationController(); 
            if (PRODUCT == 'via') {
                $appObj->ActivityLog('Delete', 'Media: '. $scrollfileName);
            }else{
                $appObj->ActivityLogVSM(5, 'Media: '.$scrollfileName, 18);
            }
            //$appObj->ActivityLog('Delete Media Font','File Name: '. $scrollfileName);
            $sqlQuery = "DELETE FROM dss_scrollerinfo WHERE scrollfilename ILIKE '".$scrollfileName."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

 }