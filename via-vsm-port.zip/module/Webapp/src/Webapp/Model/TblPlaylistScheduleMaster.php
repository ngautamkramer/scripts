<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblPlaylistScheduleMaster
{
    
    public $OID;
    public $CID;
    public $OrderDate;
    public $StartTime;
    public $EndTime;
    public $StartDate;
    public $EndDate;
    public $ModifyDateTime;    
    public $UserName;   
    public $hostname;    


    public function exchangeArray($data) {
        $this->OID = (isset($data['OID']))? $data['OID']: null;
        $this->CID = (isset($data['CID'])) ? $data['CID'] : null;
        $this->OrderDate  = (isset($data['OrderDate']))  ? $data['OrderDate']  : null;
        $this->StartTime = (isset($data['StartTime']))? $data['StartTime']: null;
        $this->EndTime = (isset($data['EndTime']))? $data['EndTime']: null;
        $this->StartDate = (isset($data['StartDate'])) ? $data['StartDate'] : null;
        $this->EndDate  = (isset($data['EndDate']))  ? $data['EndDate']  : null;
        $this->ModifyDateTime  = (isset($data['ModifyDateTime']))  ? $data['ModifyDateTime']  : null;    
        $this->UserName  = (isset($data['UserName']))  ? $data['ModifyDateTime']  : null;    
        $this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null;    
    }
       

	 
}
