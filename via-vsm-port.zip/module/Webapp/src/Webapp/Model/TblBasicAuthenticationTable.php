<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblBasicAuthenticationTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		public function updateInsertAuthentication($pass)
		{
			  $select = $this->tableGateway->getSql()->select();
			  $select->columns(array('*'));	
               $resultSet = $this->tableGateway->selectWith($select);
			   if($resultSet->count()==0)
			   {
				  $result=  $this->tableGateway->insert(array('password'=>$pass));
			   }
			   else
			   {
				    $result=  $this->tableGateway->update(array('password'=>$pass));
			   }
			  return $result;

		}
 }