<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblCampaignMedia
{
    public $id;
    public $campaign_id;
    public $media_id;

    public function exchangeArray($data){
        $this->id = (isset($data['id']))? $data['id']: null;
        $this->campaign_id = (isset($data['campaign_id']))? $data['campaign_id']: null;
        $this->media_id = (isset($data['media_id'])) ? $data['media_id'] : null;    
    }
}
