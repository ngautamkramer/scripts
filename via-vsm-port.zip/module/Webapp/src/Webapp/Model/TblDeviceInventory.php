<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblDeviceInventory implements InputFilterAwareInterface
{
    public $DID;
    public $DeviceID;
    public $DeviceName;
    public $DeviceIP;
    public $remarks;
    public $UserName;
    public $hostname;
    public $modifydate;
    public $DeviceGroupID;
    public $active;
    public $MacAddress;
    public $oldIPAddress;
    public $os_type;
    public $global_sync_status;
    public $Version;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->did = (isset($data['did']))? $data['did']: null;
        $this->deviceid = (isset($data['deviceid']))? $data['deviceid']: null;
        $this->devicename = (isset($data['devicename'])) ? $data['devicename'] : null;
        $this->deviceip  = (isset($data['deviceip']))  ? $data['deviceip']  : null;
        $this->remarks  = (isset($data['remarks']))  ? $data['remarks']  : null; 
        $this->username  = (isset($data['username']))  ? $data['username']  : null; 
        $this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null; 
        $this->modifydate  = (isset($data['modifydate']))  ? $data['modifydate']  : null; 
        $this->devicegroupid  = (isset($data['devicegroupid']))  ? $data['devicegroupid']  : null; 
        $this->active  = (isset($data['active']))  ? $data['active']  : null; 
        $this->macaddress  = (isset($data['macaddress']))  ? $data['macaddress']  : null; 
        $this->oldIPAddress  = (isset($data['oldIPAddress']))  ? $data['oldIPAddress']  : null;
	$this->os_type  = (isset($data['os_type']))  ? $data['os_type']  : null;  
        $this->global_sync_status  = (isset($data['global_sync_status']))  ? $data['global_sync_status']  : null;
	$this->Version  = (isset($data['Version']))  ? $data['Version']  : null; 
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
