<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblAdvanceConfigurationTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		public function updateAdvanceConfiguration($value,$checkBoxName)
		{
			if($checkBoxName=="presentationMode")
			{
				$result=$this->tableGateway->update(array('feature6' => 0,'feature8'=>0)); 
			}
			
			else if($checkBoxName=="participantConfChkbox")
			{
				$result=$this->tableGateway->update(array('feature6'=>$value)); 
			}
			
			else if($checkBoxName=="setPollingConfiguration")
			{
				//$result=$this->tableGateway->update(array('feature8'=>$value,'last_updated'=>now())); 
				$result=$this->tableGateway->update(array('feature8'=>$value)); 
			}
			return $result;
		}
		public function getParticipantCheckboxVal()
		{
			  $select = $this->tableGateway->getSql()->select();
			  $select->columns(array('*'));	
               $resultSet = $this->tableGateway->selectWith($select);	
			  return  $resultSet ;
		}
                
                public function fetchAll() {
                    $resultSet = $this->tableGateway->select();
                    foreach($resultSet as $fetchConfigData){
                        $advanceConfig['feature1']=($fetchConfigData->feature1!=''?$fetchConfigData->feature1:0);
                        $advanceConfig['feature2']=($fetchConfigData->feature2!=''?$fetchConfigData->feature2:0);
                        $advanceConfig['feature3']=($fetchConfigData->feature3!=''?$fetchConfigData->feature3:0);
                        $advanceConfig['feature4']=($fetchConfigData->feature4!=''?$fetchConfigData->feature4:0);
                        $advanceConfig['feature5']=($fetchConfigData->feature5!=''?$fetchConfigData->feature5:0);
                        $advanceConfig['feature7']=($fetchConfigData->feature7!=''?$fetchConfigData->feature7:0);
                        $advanceConfig['feature8']=($fetchConfigData->feature8!=''?$fetchConfigData->feature8:0);  //for ePolling
                        $advanceConfig['feature9']=($fetchConfigData->feature9!=''?$fetchConfigData->feature9:0);  //for chrome setting
                    }
                    return $advanceConfig;
                }
        
        public function updateFeatures($data){
            $this->tableGateway->update($data);  
		}
				/*****
	 *	@Function Name: getAdvanceConfigData
	 *  @description  : get feature4 value 
	 *	@Author		  : Vineet
	 *  @Date         : 14-feb-2020
	 *****/
	public function getAdvanceConfigData() {
		$select = $this->tableGateway->getSql()->select();
		$select->columns(array('feature4'));
		$resultSet = $this->tableGateway->selectWith($select);
		$row = $resultSet->current();
		return $row;
	}
	
				/*****
	 *	@Function Name: getAdvanceConfigData
	 *  @description  : get feature4 value 
	 *	@Author		  : Vineet
	 *  @Date         : 14-feb-2020
	 *****/
		public function updateConfiguration($value) {
		$value = (int) $value;
		$data = array('feature4' =>$value,
		'last_updated'=>date("Y-m-d H:i:s"),
					 );
		$result = $this->tableGateway->update($data, array());
		return $result;
	}
 }