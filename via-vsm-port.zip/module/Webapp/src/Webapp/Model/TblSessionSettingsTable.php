<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblSessionSettingsTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function getOrInsertSessionValue($loginName) { 
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('sessionTimeOut', 'captcha', 'field1'));
            $select->order('id desc');
            $select->limit(1);
            $resultSet =$this->tableGateway->selectWith($select);
            $resultCount = $resultSet->count();
            if($resultCount>0){
                $result = $resultSet->current();
                $sessionArr['sessionTimeOut'] = $result->sessionTimeOut;
                $sessionArr['captcha'] = $result->captcha;
                $sessionArr['field1'] = $result->field1;
            }else{
                $sessionArr['sessionTimeOut'] = 10;
                $sessionArr['captcha'] = 0;
                $sessionArr['field1'] = 0;
                $this->tableGateway->insert(array('sessionTimeOut' => $sessionArr['sessionTimeOut'], 'captcha' => $sessionArr['captcha'], 'created_by' => $loginName, 'field1' => $sessionArr['field1']));
            }
            return $sessionArr;
        }
        
        public function insertOrUpdateSessionValue($timeVal,$broadcastValue,$loginName) { 
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('sessionTimeOut', 'field1'));
            $select->order('id desc');
            $select->limit(1);
            $resultSet =$this->tableGateway->selectWith($select);
            $resultCount = $resultSet->count();
            if($resultCount>0){
                $result = $resultSet->current();
                $this->tableGateway->update(array('sessionTimeOut' => $timeVal, 'created_by' => $loginName, 'field1' => $broadcastValue));
            }else{
                $this->tableGateway->insert(array('sessionTimeOut' => $timeVal, 'created_by' => $loginName, 'field1' => $broadcastValue));
            }
        }
        
        public function updateCaptcha($captchaArr){
            $this->tableGateway->update($captchaArr);
        }

         public function getSessionCheckData() {
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('sessionTimeOut'));
            $select->order('id desc');
            $select->limit(1);
            $resultSet = $this->tableGateway->selectWith($select);
            return $resultSet;
        }
 }