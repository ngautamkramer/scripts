<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblDeviceDnsnameTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
        public function getData($condition){
            $select = $this->tableGateway->getSql()->select();
            $select->where($condition);
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
		    $resultSet = $statement->execute();
            return $resultSet;
        }
		
		public function insert($insertArr){
            $this->tableGateway->insert($insertArr);
        }
 }