<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class TblActivityLogMasterTable {
	protected $tableGateway;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}

	public function setActivity($userName, $actionTaken, $logMsgSysLog, $hostname) {
		$data = array('userid' =>$userName,
					  'actiontaken' =>$actionTaken,
					  'activitydate' => date("Y-m-d H:i:s"),
					  //  'ActivityDate'=>',now()', commented by vineet
		'remarks' =>$logMsgSysLog. ' ' .$userName, 'hostname' =>$hostname);
		$this->tableGateway->insert($data);
		//return $lastInsertid = $this->tableGateway->lastInsertValue;
		// for return last inserted id from pgsql
		return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('activitylogmaster_activityid_seq');
	}


	/*****
	 *	@Function Name:  getUserLogList
	 *  @description  : get user log list on page load
	 *	@Author		  : Vineet
	 *  @Date         : 15-april-2020
	 *****/
	public function getUserLogList()
	{
		$select = $this->tableGateway->getSql()->select();
		$startDate=$startDate. '00:00:00';
		$endDate=$endDate. '23:59:00';
		$startDate =date('Y-m-d H:i:s', strtotime($startDate));
		$endDate=date('Y-m-d H:i:s', strtotime($endDate));
		$select->columns(array('*'));
		$select->where->between('activitydate', $startDate,$endDate);
		if(PRODUCT=='via'){
			$select->where->notEqualTo('userid', '');
		}
		$select->order('activitydate DESC');
		$resultSet = $this->tableGateway->selectWith($select);
		$result['count'] = $resultSet->count();
		$paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
		$resultSet = new Paginator($paginatorAdapter); 
		$result['data']=$resultSet;	       
		return $result;       
	}

	/*****
	 *	@Function Name:  getUserLogListSearch
	 *  @description  : loglist search
	 *	@Author		  : Vineet
	 *  @Date         : 27-jan-2020
	 *****/
	public function getUserLogListSearch($name,$startDate,$endDate,$export)
	{
		 $select = $this->tableGateway->getSql()->select();
		if($name=="" && $startDate=="" && $endDate=="")
		{
			$startDateTime=date("Y-m-d").' 00:00:00';
			$endDateTime=date("Y-m-d").' 23:59:00';
			$select->columns(array('*'));
			//$select->where->between('ActivityDate',  $startDateTime,  $endDateTime);
			if(PRODUCT=='via'){
				$select->where->notEqualTo('userid', '');
			}
			$select->order('activitydate DESC');
		}
		else if($name=="" && $startDate!="" && $endDate!="")
		{
			$startDate=$startDate. '00:00:00';
			$endDate=$endDate. '23:59:00';
			$startDate =date('Y-m-d H:i:s', strtotime($startDate));
			$endDate=date('Y-m-d H:i:s', strtotime($endDate));
			$select->columns(array('*'));
			$select->where->between('activitydate',  $startDate,  $endDate);
			if(PRODUCT=='via'){
				$select->where->notEqualTo('userid', '');
			}
			$select->order('activitydate DESC');
		}
		
		else if($name!="" && $startDate=="" && $endDate=="")
		{
			$select = $this->tableGateway->getSql()->select();
			$select->columns(array('*'));
			//$select->where->like('UserID','%'.$name.'%');
			$select->where->expression("CONCAT(userid, actiontaken) ILIKE ?",  '%'.$name.'%');
			if(PRODUCT=='via'){
				$select->where->notEqualTo('userid', '');
			}
			$select->order('activitydate DESC');
		}
		else
		{
			$startDate=$startDate. '00:00:00';
			$endDate=$endDate. '23:59:00';
			$startDate =date('Y-m-d H:i:s', strtotime($startDate));
			$endDate=date('Y-m-d H:i:s', strtotime($endDate));
		    $select->columns(array('*'));
			if(PRODUCT=='vsm'){
				$select->Where->between('activitydate',  $startDate, $endDate)
				->andwhere->expression("CONCAT(userid, actiontaken, modulename) ILIKE ?",  '%'.$name.'%');
			}else{
				$select->Where->between('activitydate',  $startDate, $endDate)
				->andwhere->expression("CONCAT(userid, actiontaken) ILIKE ?",  '%'.$name.'%');
			}
			if(PRODUCT=='via'){
				$select->where->notEqualTo('userid', '');
			}
			$select->order('activitydate DESC');
		}
		
		  $resultSet = $this->tableGateway->selectWith($select);
		 
		  $result['count'] = $resultSet->count();
		  $result['data']=$resultSet;	
		  if($export==null)
		  {
				$paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
				$resultSet = new Paginator($paginatorAdapter);
				$result['data']=$resultSet;	       

		  }
		  return $result; 
	}
	
}
