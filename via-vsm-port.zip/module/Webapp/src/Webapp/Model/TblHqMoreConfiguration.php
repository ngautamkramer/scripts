<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblHqMoreConfiguration
 {
	  public $id;
	  public $featureStatus1;
	  public $featureStatus2;   
	  public $featureStatus3;   
	  public $featureStatus4;   
	  public $featureStatus5;   
	  public $featureStatus6;
          public $featureStatus7;
          public $featureStatus8;
          public $featureStatus9;
          public $featureStatus10;
	  
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->featureStatus1 = (isset($data['featureStatus1']))? $data['featureStatus1']: null;
		 $this->featureStatus2 = (isset($data['featureStatus2']))? $data['featureStatus2']: null;
		 $this->featureStatus3 = (isset($data['featureStatus3']))? $data['featureStatus3']: null; 
		 $this->featureStatus4 = (isset($data['featureStatus4']))? $data['featureStatus4']: null;
		 $this->featureStatus5 = (isset($data['featureStatus5']))? $data['featureStatus5']: null;
		 $this->featureStatus6 = (isset($data['featureStatus6']))? $data['featureStatus6']: null;
                 $this->featureStatus7 = (isset($data['featureStatus7']))? $data['featureStatus7']: null;
                 $this->featureStatus8 = (isset($data['featureStatus8']))? $data['featureStatus8']: null;
                 $this->featureStatus9 = (isset($data['featureStatus9']))? $data['featureStatus9']: null;
                 $this->featureStatus10 = (isset($data['featureStatus10']))? $data['featureStatus10']: null;
		 
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }