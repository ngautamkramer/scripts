<?php
namespace Webapp\Model;
// Add these import statements
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class TblRecordingMaster {
	public $rmasterId;
	public $rmaster;
	public $deviceid;
	public $sessionname;
	public $description;
	public $keyword;
	public $reserved1;
	public $reserved2;
	public $date;

	public function exchangeArray($data) {
		$this->rmasterId =(isset($data['rmasterid']))? $data['rmasterid'] : null;
		$this->rmaster =(isset($data['rmaster']))? $data['rmaster'] : null;
		$this->deviceid =(isset($data['deviceid']))? $data['deviceid'] : null;
		$this->sessionname =(isset($data['sessionname']))? $data['sessionname'] : null;
		$this->description =(isset($data['description']))? $data['description'] : null;
		$this->keyword =(isset($data['keyword']))? $data['keyword'] : null;
		$this->reserved1 =(isset($data['reserved1']))? $data['reserved1'] : null;
		$this->reserved2 =(isset($data['reserved2']))? $data['reserved2'] : null;
		$this->date =(isset($data['date']))? $data['date'] : null;
	}
}
