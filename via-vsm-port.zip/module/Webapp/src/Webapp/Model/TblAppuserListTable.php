<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
/*****
 *	@Class Name			: appuserlist
 *  @description	    : Using for database actions                       
 *	@Author			    : Ashu
 *  @Date               : 17-Dec-2019
 *****/ 
 class TblAppuserListTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
        public function checkLoginUser($postData){
			$appObj = new ApplicationController();
			$sqlSelect = $this->tableGateway->getSql()->select();
		    $sqlSelect->columns(array('*'));
			$sqlSelect->join("appusergroups", "appusergroups.appuserid = appuserlist.appuserid", array('appgroupid'), 'inner');
			$sqlSelect->order('appusergroups.appgroupid ASC');
			//print_r($postData);
			//die;
			$sqlSelect->where(array('apploginname' =>trim($postData['login_name']),'password'=>$appObj->securePassword(trim($postData['login_password'])),'active'=>$postData['status']));
		    $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
			$resultSet = $statement->execute();
		    return $resultSet;			
        }
		
		

        public function fetchAll($searchText) { 
			$select = $this->tableGateway->getSql()->select();
            $select->columns(array('*'));
			if($searchText){
				$select->where(array('apploginname ILIKE ?'=>'%'.$searchText.'%'));
			}
			$select->order('appuserlist.apploginname ASC');	
            $resultSet = $this->tableGateway->selectWith($select);
             // create a new pagination adapter object
            $paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
            $resultSet = new Paginator($paginatorAdapter); 			       
            return $resultSet;
        }

        public function fetchAllViaUsers() {
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('*'));
			$select->join('appusergroups', 'appusergroups.appuserid = appuserlist.appuserid', [], 'left');
			//$select->columns(array('*','AppGroupIDs' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(appusergroups.appgroupid SEPARATOR ',')")));			
			$select->columns(array('*','appgroupids' => new \Zend\Db\Sql\Expression("array_to_string(array_agg(appusergroups.appgroupid), ',')")));
			//$select->group(array('appusergroups.appuserid','appuserlist.appuserid','appusergroups.appgroupid'));
			$select->group(array('appusergroups.appuserid','appuserlist.appuserid'));
			$select->order('appuserlist.apploginname ASC');	
            $resultSet = $this->tableGateway->selectWith($select);
             // create a new pagination adapter object
            $paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
            $resultSet = new Paginator($paginatorAdapter); 			       
            return $resultSet;
        }
		
        public function deleteUser($usrid){            
            $this->tableGateway->delete(array('appuserid' => (int) $usrid));			
        }

        public function checkUser($apploginname){
             //$rowset = $this->tableGateway->select(array('apploginname' => $apploginname));
			 $select = $this->tableGateway->getSql()->select();
			 $select->where->expression("apploginname ILIKE ?", $apploginname);
			 $resultSet = $this->tableGateway->selectWith($select);
             return $resultSet;
        }

        public function saveUser($userData,$sessionLoginName){
		    $txtRemarks="Added By ".$sessionLoginName;
		    $appObj = new ApplicationController();
            $data = array(
                 'apploginname' => $userData['txtUserId'],
				 'email' => $userData['txtEmail'],
                 'password'  => $appObj->securePassword($userData['txtPassword']),
				 'changepassword' => "",
                 'active'  => 'Y',
				 'modifydate'=>date("Y-m-d H:i:s"),
				 'hostname'=>HOSTNAME,
				 'name'=>$sessionLoginName,
				 'remarks'=>$txtRemarks,
				 'alert_type' => '1,2,3,4'
             );		 
             $this->tableGateway->insert($data);
			 // for return last inserted id from pgsql
			 return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('appuserlist_appuserid_seq');
             //return $lastInsertid = $this->tableGateway->lastInsertValue;
         }

         public function getUserDataById($userid){
             $userid  = (int) $userid;
             $rowset = $this->tableGateway->select(array('appuserid' => $userid));
             $row = $rowset->current();
             if (!$row) {
                 throw new \Exception("Could not find row $userid");
             }		 
             return $row;
         }

         public function updateUser($userid,$txtPassword){ 
		    $appObj = new ApplicationController();
			$data = array(
				  'password'=>$appObj->securePassword($txtPassword),
			 );			 	
		  	 $this->tableGateway->update($data, array('appuserid' => $userid)); 
         }
		
	  //Update password(12-Sept-2018)
	  public function updateUserPassword($userid,$password){
		   $appObj = new ApplicationController();
		   $data = array(
				 'password'=>$appObj->securePassword($password),
		   );
		  $this->tableGateway->update($data, array('usrid' => $userid)); 
	  }
	  
	  
	  public function ChangePassword($oldPassword,$newPassword,$usrid){  
	         $appObj = new ApplicationController();
			 if($newPassword){
					$data = array(
						  'password'=>$appObj->securePassword($newPassword),
					 );
			 }
		  	 $result=$this->tableGateway->update($data, array('password' => $appObj->securePassword($oldPassword),'usrid'=>$usrid)); 
			 return $result;
         }
	 
	 public function checkUserByNameAndPass($condition){
	     $selectQry = $this->tableGateway->getSql()->select();
	     $selectQry->where($condition);
	     $resultSet = $this->tableGateway->selectWith($selectQry);
	     return $resultSet->count();
	 }
	 
	 public function updateUserByName($userid,$password){
		   $appObj = new ApplicationController();
		   $data = array(
				 'password'=>$appObj->securePassword($password),
				  'modifydate'=>date("Y-m-d h:i:s"),
		   );
		  $this->tableGateway->update($data, array('apploginname' => $userid)); 
	  }

	  //added by vineet
	  public function checkCollab8LoginUser($user,$password){
		$appObj = new ApplicationController();
		$sqlSelect = $this->tableGateway->getSql()->select();
		$sqlSelect->columns(array('*'));
		$sqlSelect->join('appusergroups', 'appusergroups.appuserid = appuserlist.appuserid', array('appgroupid'), 'inner');
		$sqlSelect->order('appusergroups.appgroupid ASC');
		//print_r($postData);
		//die;
		$sqlSelect->where(array('apploginname' =>$user,'password'=>$appObj->securePassword($password),'active'=>'Y'));
		$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		$resultSet = $statement->execute();
		return $resultSet;			
	 }
 
 }