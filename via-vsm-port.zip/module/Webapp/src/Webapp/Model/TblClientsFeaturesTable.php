<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblClientsFeaturesTable
 {
	    protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		public function getClientFeatures()
		{
			 $select = $this->tableGateway->getSql()->select();
			 $select->columns(array('feature_status'));	
			 $select->where(array('feature_name'=>'Chat'));
			 $resultSet =$this->tableGateway->selectWith($select);	
			 return  $resultSet ;
		}
                
                public function featureStatus($featureName) { 
                    $sqlSelect = $this->tableGateway->getSql()->select();
                    $sqlSelect->columns(array('feature_status'));
                    $sqlSelect->where(array('feature_name' => $featureName));
                    $resultSet = $this->tableGateway->selectWith($sqlSelect);
                    foreach($resultSet as $feature){
                       $result['feature_status'] =  $feature->feature_status;
                    }
                    return $result;
                }
                
                public function updateAll($feature_status){
                    $this->tableGateway->update(array('feature_status' => $feature_status,'date_time'=>date("Y-m-d h:i:s")));
                }
                
                public function updateFeatureStatus($feature_status){
                    $this->tableGateway->update(array('feature_status' => $feature_status));
                }
                
                public function updateStatusWhere($feature_status,$where){
                    $select = $this->tableGateway->update(array('feature_status' => $feature_status,'date_time'=>date("Y-m-d h:i:s")),array('id'=>$where));
                }
				
				
  			public function fetchAll($type){
				$select = $this->tableGateway->getSql()->select();
				$select->columns(array('*'));
				//if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
					$select->where(array('feature_type' =>$type));
				//}	
				$select->order('id ASC');
				$selectAll = $this->tableGateway->selectWith($select);
                    foreach($selectAll as $key => $feature){
                       $result[$key]['id'] =  $feature->id;
                       $result[$key]['feature_name'] =  $feature->feature_name;
					   //set by default 1 to feature_status
                       $result[$key]['feature_status'] =  1;//$feature->feature_status;
					   $result[$key]['feature_btn_name'] =  $feature->feature_btn_name;
                    }
				
				return $result;
			}
                
      public function fetchAllWithPosition(){
        $sqlSelect = $this->tableGateway->getSql()->select();
		    $sqlSelect->columns(array('*'));
        $sqlSelect->join('tbl_client_features_position', 'tbl_clients_features.id=tbl_client_features_position.client_feature_fk', array('client_feature_fk'), 'inner');
        $sqlSelect->order('feature_status DESC, tbl_client_features_position.id');
		    $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
        foreach($resultSet as $key => $feature){
           $result[$key]['id'] =  $feature['id'];
           $result[$key]['feature_name'] =  $feature['feature_name'];
           $result[$key]['feature_status'] =  $feature['feature_status'];
           $result[$key]['feature_btn_name'] =  $feature['feature_btn_name'];
        }
		    return $result;
      }
                
      public function getChatInfo(){
        $sqlSelect = $this->tableGateway->getSql()->select();
		    $sqlSelect->columns(array('*'));
        $sqlSelect->join('tbl_feature_client_temp', 'tbl_clients_features.id=tbl_feature_client_temp.feature_deleted_id', array('feature_deleted_id'), 'inner');
        $sqlSelect->where(array('feature_name' => 'Chat', 'delete_flag' => 1));
		    $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
        $rowCount = $resultSet->count();
        return $rowCount;
      }
 }