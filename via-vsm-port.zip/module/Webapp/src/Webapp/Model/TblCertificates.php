<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblCertificates
 {
	  public $id;
	  public $cert_file_name;
	  public $cert_file_md5;   
	  public $key_file_name;   
	  public $key_file_md5;
          public $status;
          public $modifydatetime;
          
          protected $inputFilter;    // Add this variable
	  
        public function exchangeArray($data) {
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->cert_file_name = (isset($data['cert_file_name']))? $data['cert_file_name']: null;
		 $this->cert_file_md5 = (isset($data['cert_file_md5']))? $data['cert_file_md5']: null;
		 $this->key_file_name = (isset($data['key_file_name']))? $data['key_file_name']: null; 
		 $this->key_file_md5 = (isset($data['key_file_md5']))? $data['key_file_md5']: null;
                 $this->status = (isset($data['status']))? $data['status']: null;
                 $this->modifydatetime = (isset($data['modifydatetime']))? $data['modifydatetime']: null;
		 
	}
	public function getArrayCopy(){
            return get_object_vars($this);
	}
        
        public function getInputFilter()
        {
                if (!$this->inputFilter) {
                         $inputFilter = new InputFilter();
                         $inputFilter->add(
                                    array(
                                        'name' => 'cert_file_name',
                                        'required' => false,
                                        'validators' => array(
                                            array(
                                                'name' => 'Zend\Validator\File\Size',
                                                'options' => array(
                                                        'min' => 50,
                                                        'max' => 200000,
                                                ),
                                            ),
                                            array(
                                                'name' => 'Zend\Validator\File\Extension',
                                                'options' => array(
                                                        'extension' => 'crt',
                                                ),
                                            ),
                                        ),
                                    )
                                );
                         
                         $inputFilter->add(
                                    array(
                                        'name' => 'key_file_name',
                                        'required' => false,
                                        'validators' => array(
                                            array(
                                                'name' => 'Zend\Validator\File\Size',
                                                'options' => array(
                                                        'min' => 50,
                                                        'max' => 200000,
                                                ),
                                            ),
                                            array(
                                                'name' => 'Zend\Validator\File\Extension',
                                                'options' => array(
                                                        'extension' => 'key',
                                                ),
                                            ),
                                        ),
                                    )
                                );

                         $this->inputFilter = $inputFilter;
                 }
                return $this->inputFilter;
            }

 }