<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblTemplates implements InputFilterAwareInterface
{
    public $id;
    public $template_name;
	public $created_at;
	public $wallpaper_name;
	public $modifydatetime;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->template_name= (isset($data['template_name']))? $data['template_name']: null;
        $this->status = (isset($data['status'])) ? $data['status'] : null;  
		$this->created_at = (isset($data['created_at'])) ? $data['created_at'] : null;
		$this->wallpaper_name = (isset($data['wallpaper_name'])) ? $data['wallpaper_name'] : null;
		$this->modifydatetime = (isset($data['modifydatetime'])) ? $data['modifydatetime'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
