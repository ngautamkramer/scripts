<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblCertificatesTable
 {
                protected $tableGateway;
                public function __construct(TableGateway $tableGateway) {
                    $this->tableGateway = $tableGateway;
                }
		
                public function checkCertificate($whereArr){
                    $sqlSelect = $this->tableGateway->getSql()->select();
                    $sqlSelect->where($whereArr);
		    $resultSet =$this->tableGateway->selectWith($sqlSelect);
                    $rowCount = $resultSet->count();
                    return $rowCount;
                }
                
                public function getCertificateCount(){
                    $sqlSelect = $this->tableGateway->select();
                    $count = $sqlSelect->count();
                    if($count>0){
                        foreach($sqlSelect as $value){
                            $result['cert_file_name'] = $value->cert_file_name;
                            $result['key_file_name'] = $value->key_file_name;
                        }
                        
                    }
                    $result['count'] = $count;
                    return $result;
                }
                
                public function insertOrTruncateCertificate($certificate){
                    $sqlSelect = $this->tableGateway->select();
                    $status = 0;
                    if($sqlSelect->count()==0){
                        $this->tableGateway->insert($certificate);
                        $status = 1;
                    }else{
                        $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
                        $query->execute();
                        $this->tableGateway->insert($certificate);
                        $status = 1;
                    }
                    return $status;
                }
                
                public function truncateTable(){
                    $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
                    $query->execute();
                }
 }