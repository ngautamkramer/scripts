<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblDssInfo
{
    public $id;
    public $filename;
    public $datetime;
    public $field1;
    public $field2;    

    public function exchangeArray($data){
        $this->id = (isset($data['id']))? $data['id']: null;
        $this->filename = (isset($data['filename']))? $data['filename']: null;
        $this->datetime = (isset($data['datetime'])) ? $data['datetime'] : null;
        $this->field1  = (isset($data['field1']))  ? $data['field1']  : null;
	    $this->field2  = (isset($data['field2']))  ? $data['field2']  : null;	    
    }
       

	 
}
