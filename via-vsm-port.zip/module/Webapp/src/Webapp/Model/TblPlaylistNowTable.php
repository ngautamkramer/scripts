<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;

 class TblPlaylistNowTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }      

        public function insertPlaylistNow($data) {
            $appObj = new ApplicationController(); 
           // $appObj->ActivityLog('Create Schedule PlayList Now','OID: '. $data['OID']);
            $this->tableGateway->insert($data);
            //return $lastInsertid = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('playlist_now_id_seq');
        } 

         public function deletePlaylistNow($whereCondition) {
            $appObj = new ApplicationController(); 
            //$appObj->ActivityLog('Delete Schedule PlayList Now','OID: '. $whereCondition['OID']);
            $this->tableGateway->delete($whereCondition); 
        }

        public function updatePlaylistNow($whereCondition, $userData) {
            $appObj = new ApplicationController(); 
           // $appObj->ActivityLog('Update Schedule PlayList Now','OID: '. $whereCondition['OID']);
            $result = $this->tableGateway->update($userData, $whereCondition);
            return $result;
        }

        public function getAllOrderIdsByDid($did) {
            $appObj = new ApplicationController();
            $sqlQuery = "SELECT OID FROM playlist_now WHERE DID = ".$did."";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

 }