<?php

namespace Webapp\Model;  // define namespace for current file

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Expression;
use Zend\Paginator\Adapter\DbTableGateway;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

/*********
 * @Name   : TblCalendarTable
 * @Desc   : It is for custom functions related to TblCalendarTable model
 * @Author : Dileep Kumar
 * @Date   : 24 APR 2018
 * ******/
 
class TblCalendarTable
{
     protected $tableGateway;
	// object of tablegateway is flushed to constructor
     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }
	 
	 /*****
	 *	@Function Name		: fetchAll
	 *  @description	    : get the all calendars for particular account
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-April-2018
	 *****/
	 public function fetchAll($accountId,$compId)
     { 
	     $sqlSelect = $this->tableGateway->getSql()->select();
		 $sqlSelect->join('tbl_room_manager', 'tbl_room_manager.calander_id = tbl_calendars.calender_id',array(),'left');
		 $sqlSelect->where(array('tbl_calendars.account_id'=>"$accountId"));
		 $sqlSelect->columns(array('*','room_name' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(room_name SEPARATOR ',')")));
		 $sqlSelect->group(array('tbl_calendars.calender_id'));
		 $sqlSelect->order('room_name ASC');	
		 $paginatorAdapter = new DbSelect(
			$sqlSelect,
			$this->tableGateway->getAdapter()
		  );
		 $pagination = new Paginator($paginatorAdapter);
		 return $pagination;
        /* $resultSet = $this->tableGateway->select(array('account_id'=>"$accountId"));
         $return_array = array();
         $final_return_array = array();
         if($resultSet->count() > 0) {
			 foreach($resultSet as $index => $value) {
				 $return_array['id'] = $value->id;
				 $return_array['name'] = $value->name;
				 $return_array['account_id'] = $value->account_id;
				 $return_array['calender_id'] = $value->calender_id;
				 $return_array['created_at'] = $value->created_at;
				 $final_return_array[]=$return_array;
			 }
		 }
         return $final_return_array;*/
     }
	 
	  /*****
	 *	@Function Name		: fetchAllByCompId
	 *  @description	    : get the all calendars for a company
     *	@Author			    : Dileep Yadav
	 *  @Date               : 26-April-2018
	 *****/
	 public function fetchAllByCompId($condition)
     { 
         $dbTableGatewayAdapter = new DbTableGateway($this->tableGateway);
		 $sqlSelect = $this->tableGateway->getSql()->select();
		 $sqlSelect->columns(array('*'));
		 $sqlSelect->join('tbl_company_calender_account', 'tbl_company_calender_account.account_id = tbl_calendars.account_id',array('email'),'left');
		 $sqlSelect->where($condition);
		 $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		 $resultSet = $statement->execute();
		 return $resultSet;
     }
	 
	  /*****
	 *	@Function Name		: getPermissionType
	 *  @description	    : get the permission type for office 365
     *	@Author			    : Dileep Yadav
	 *  @Date               : 26-Nov-2018
	 *****/
	 public function getPermissionType($accountId)
     { 
	     $condition=array('tbl_company_calender_account.account_id'=>$accountId);
         $dbTableGatewayAdapter = new DbTableGateway($this->tableGateway);
		 $sqlSelect = $this->tableGateway->getSql()->select();
		 $sqlSelect->columns(array('*'));
		 $sqlSelect->join('tbl_company_calender_account', 'tbl_company_calender_account.account_id = tbl_calendars.account_id',array('permission_type','account_type'),'RIGHT');
		 $sqlSelect->where($condition);
		 $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		 $resultSet = $statement->execute();
		 return $resultSet;
     }
	 

	
}