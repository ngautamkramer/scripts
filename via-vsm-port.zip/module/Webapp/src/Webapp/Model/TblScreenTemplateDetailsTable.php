<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;

 class TblScreenTemplateDetailsTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }	
        
        public function deleteScreenTemplateDetails($whereCondition){
            $this->tableGateway->delete($whereCondition);  
        }

        public function insertsScreenTemplateDetails($userData) {
            $this->tableGateway->insert($userData);            
        }     
      
 }