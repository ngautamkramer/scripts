<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblScreenTemplateDetails implements InputFilterAwareInterface
{
    public $frameid;
    public $screentemplateid;
    public $framename;
    public $frameheight;
    public $framewidth;
    public $frameleft; 
    public $frametop; 
    public $strechmediatofit; 
    public $zorder;
    public $transparency;
    public $framecolor;
    public $defaultmedia;
    public $defaultbackground;
    public $originalmedia; 
    public $originalbackground; 
    public $aspectratio; 
    public $appname;
    public $username;
    public $hostname;
    public $modifydate;

    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->frameid = (isset($data['frameid']))? $data['frameid']: null;
        $this->screentemplateid = (isset($data['screentemplateid']))? $data['screentemplateid']: null;
        $this->framename = (isset($data['framename'])) ? $data['framename'] : null;
        $this->frameheight  = (isset($data['frameheight']))  ? $data['frameheight']  : null;
        $this->framewidth  = (isset($data['framewidth']))  ? $data['framewidth']  : null;
        $this->frameleft  = (isset($data['frameleft']))  ? $data['frameleft']  : null;  
        $this->frametop  = (isset($data['frametop']))  ? $data['frametop']  : null;   
        $this->strechmediatofit  = (isset($data['strechmediatofit']))  ? $data['strechmediatofit']  : null; 
        $this->zorder  = (isset($data['zorder']))  ? $data['zorder']  : null; 

        $this->transparency  = (isset($data['transparency']))  ? $data['transparency']  : null;
        $this->framecolor  = (isset($data['framecolor']))  ? $data['framecolor']  : null;  
        $this->defaultmedia  = (isset($data['defaultmedia']))  ? $data['defaultmedia']  : null;   
        $this->defaultbackground  = (isset($data['defaultbackground']))  ? $data['defaultbackground']  : null; 
        $this->originalmedia  = (isset($data['originalmedia']))  ? $data['originalmedia']  : null; 

        $this->originalbackground  = (isset($data['originalbackground']))  ? $data['originalbackground']  : null; 
        $this->aspectratio  = (isset($data['aspectratio']))  ? $data['aspectratio']  : null; 

        $this->appname  = (isset($data['appname']))  ? $data['appname']  : null;  
        $this->username  = (isset($data['username']))  ? $data['username']  : null;  
        $this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null;  
        $this->modifydate  = (isset($data['modifydate']))  ? $data['modifydate']  : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
