<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
/*****
 *	@Class Name			: TblUserAccessTable
 *  @description	    : Using for user permission                      
 *	@Author			    : Dileep
 *  @Date               : 29-April-2020
 *****/ 
 class TblUserAccessTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
        public function saveUserPermission($userData,$userid){
			 $userPermission = $userData['userPermission'];
			 $vsmPermission = $userData['vsmPermission'];
			 $globalSettings = $userData['globalSettings'];
			 if(!empty($userPermission)){
				 $userArr=explode(",",$userPermission);
				 foreach($userArr as $userVal){
					 $data = array(
					           'module_id_fk' => 1,
					           'menu_id_fk' => $userVal,
					           'access_id_fk' => 0,
					           'user_id_fk' => $userid,
					           'group_id_fk' => 0,
					 );
					 $this->tableGateway->insert($data);
				 }
			 }
              if(!empty($vsmPermission)){
				 $vsmArr=explode(",",$vsmPermission);
				  foreach($vsmArr as $vsmVal){
					 $data = array(
					           'module_id_fk' => 5,
					           'menu_id_fk' => $vsmVal,
					           'access_id_fk' => 0,
					           'user_id_fk' => $userid,
					           'group_id_fk' => 0,
					 );
					 $this->tableGateway->insert($data);
				 }
			 }
             if(!empty($globalSettings)){
				  $data = array(
						   'module_id_fk' => 2,
						   'menu_id_fk' => $globalSettings,
						   'access_id_fk' => 0,
						   'user_id_fk' => $userid,
						   'group_id_fk' => 0,
				  );
				  $this->tableGateway->insert($data);
			 }	 			 
             //return $lastInsertid = $this->tableGateway->lastInsertValue; 
			 // for return last inserted id from pgsql
			 return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('tbl_user_access_id_seq');
            
         }
		 //Save the all permission
		 public function saveAllPermission($data){
			  foreach($data as $val){
				  $data = array(
					   'module_id_fk' => $val['module_id'],
					   'menu_id_fk' => $val['menu_id'],
					   'access_id_fk' => $val['access_id'],
					   'user_id_fk' => $val['user_id'],
					   'group_id_fk' => $val['group_id'],
				  );
				  $this->tableGateway->insert($data);
			  }
		 }
		 
		//Delete user permission
		public function deletePermission($usrid){            
            $this->tableGateway->delete(array('user_id_fk' => $usrid));			
        }
		
		public function fetchPermissionsById($usrid) {
			 $usrid  = (int) $usrid;			
			 $resultSet = $this->tableGateway->select(array('user_id_fk' => $usrid));
			 return $resultSet;
		}

 }