<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblGatewayCustomizeHomepageMappingTable
 {
		protected $tableGateway;
		public function __construct(TableGateway $tableGateway) {
			$this->tableGateway = $tableGateway;
		}
		
		public function getData($condition){
			  $sqlSelect = $this->tableGateway->getSql()->select();
			  $sqlSelect->where($condition);
			  $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
			  $resultSet = $statement->execute();	
			  return  $resultSet;
		}
		
		public function deleteData($condition){
			  $this->tableGateway->delete($condition);
		}
           
		public function truncateTable() { 
			$query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
			$query->execute();
		}
		
		public function fetchData($dataArr){
			$this->tableGateway->select($dataArr);
		}
			
		public function insertTable($updateArr){
			$this->tableGateway->insert($updateArr);
		}
                
               
 }


