<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblNtpServerTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	   
       public function fetchAll(){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->order('ntp_name');
            $resultSet =$this->tableGateway->selectWith($sqlSelect);
            return $resultSet;
       }
		public function checkNTP($whereArr){
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->where($whereArr);
			$resultSet =$this->tableGateway->selectWith($sqlSelect);
			$rowCount = $resultSet->count();
			return $rowCount;
		}
	
	
        public function getNtp(){
            $sqlQry = $this->tableGateway->getSql()->select();
            $sqlQry->where(array("status IN ('0','1','2')"));
            $resultSet =$this->tableGateway->selectWith($sqlQry);
            $rows = $resultSet->count();
            if($rows>0){
                foreach($resultSet as $key => $ntp){
                    $result[$key]['id'] = $ntp->id;
                    $result[$key]['ntp_name'] = $ntp->ntp_name;
                    $result[$key]['status'] = $ntp->status;
                    $result[$key]['ntp_uuid'] = $ntp->ntp_uuid;
                }
            }
            return $result;           
        }
        
        public function getNtpByName($ntpServer){
            $sqlQry = $this->tableGateway->getSql()->select();
            $sqlQry->where(array("ntp_name"=>$ntpServer));
            $resultSet = $this->tableGateway->selectWith($sqlQry);
            return $resultSet->count();
        }
	
        public function getSelectedNtp($ntpId){
            $sqlQry = $this->tableGateway->getSql()->select();
            $sqlQry->where(array("id"=>$ntpId));
            $resultSet =$this->tableGateway->selectWith($sqlQry);
            $ntpArr = $resultSet->current();
            return $ntpArr;
        }
        
        /*public function checkNtp($ntpId, $ntpServer){
            $sqlQry = $this->tableGateway->getSql()->select();
            $sqlQry->where(array("ntp_name"=>$ntpServer));
            $sqlQry->where(array("id NOT IN ($ntpId)"));
            $resultSet =$this->tableGateway->selectWith($sqlQry);
            return $resultSet->count();
        }*/
        
        public function updateNtp($updateArr, $where){
            $this->tableGateway->update($updateArr, $where);
        }
        
         public function insertNtp($insertArr){
            $this->tableGateway->insert($insertArr);
            /*$insertId = $this->tableGateway->lastInsertValue; 
            return $insertId;*/
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('ntp_server_id_seq');
        }
 }