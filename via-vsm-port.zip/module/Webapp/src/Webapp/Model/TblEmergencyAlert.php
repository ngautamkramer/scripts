<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblEmergencyAlert
 {
    public $id;
    public $emergency_alert_name;
    public $status;
    public $userid_fk;
 
 public function exchangeArray($data)
 {
      $this->id= (isset($data['id']))? $data['id']: null;
      $this->emergency_alert_name= (isset($data['emergency_alert_name']))? $data['emergency_alert_name']: null;
      $this->status= (isset($data['status']))? $data['status']: null;
      $this->userid_fk= (isset($data['userid_fk']))? $data['userid_fk']: null;
    
 }
 
 public function getArrayCopy()
 {
 return get_object_vars($this);
 }
 }