<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblDeviceInventoryTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
        
        public function getData($condition){
            $select = $this->tableGateway->getSql()->select();
            $select->where($condition);
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
			$resultSet = $statement->execute();	
            return $resultSet;
        }
        
        public function insertAndGetId($insertArr){
            $this->tableGateway->insert($insertArr);
            /*$insertId = $this->tableGateway->lastInsertValue; 
            return $insertId;*/
			// for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('deviceinventory_did_seq');
        }
        
        public function updateDeviceInventory($updateArr){
            $sqlupdate = $this->tableGateway->update($updateArr);
            return $sqlupdate;
        }

        public function updateWhere($updateArr, $whereArr){
            $sqlupdate = $this->tableGateway->update($updateArr, $whereArr);
        }
        
         public function deleteDeviceInventory($where){            
            $this->tableGateway->delete($where);			
        }

		public function getGatewayList($user_id, $definput, $export){
            $sqlSelect = $this->tableGateway->getSql()->select();
            if($user_id==1){
                $sqlSelect->columns(array('*'));
            }else{
                $sqlSelect->columns(array('*'));
				$sqlSelect->quantifier('DISTINCT');
            }
            
            $sqlSelect->join('devicegroup', 'devicegroup.DeviceGroupID = DeviceInventory.DeviceGroupID', array('DeviceGroup'=>'DeviceGroup'), 'INNER');
            if($user_id!=1){
				$sqlSelect->join('tbl_user_access', 'tbl_user_access.group_id_fk = devicegroup.DeviceGroupID', array(), 'INNER');
			}
			$sqlSelect->join('tbl_sys_report', 'tbl_sys_report.did_fk = DeviceInventory.DID', array(), 'INNER');
			$sqlSelect->join('tbl_advance_sys_report', 'tbl_advance_sys_report.did_fk = DeviceInventory.DID', array('extraField3'=>'extraField3'), 'INNER');
            $sqlSelect->join('tbl_device_extra_info', 'tbl_device_extra_info.deviceID_Fk = DeviceInventory.DID', array('airplay_name'=>'airplay_name','airplay_max_no'=>'airplay_max_no','model_value'=>'model_value'), 'INNER');
            $sqlSelect->join('tbl_device_live_status', 'tbl_device_live_status.did_fk = DeviceInventory.DID', array('Network_status'=>'Network_status','last_updated_time'=>'last_updated_time'), 'INNER');
            $sqlSelect->join('tbl_device_dnsname', 'tbl_device_dnsname.DID_Fk = DeviceInventory.DID', array('field1'=>'field1','dns_name'=>'dns_name'), 'LEFT'); 
            if($user_id!=1){
				$sqlSelect->where(array('tbl_user_access.user_id_fk'=>$user_id));
			}
            if(!empty($definput)){
                $sqlSelect->where->like(new \Zend\Db\Sql\Expression('Concat(DeviceInventory.DeviceID,DeviceInventory.DeviceName, DeviceInventory.DeviceIP , DeviceInventory.remarks, devicegroup.DeviceGroup)'),'%'.$definput.'%');
            }
            $sqlSelect->order('DeviceInventory.DeviceName');
			//$sqlSelect->limit(50);
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
			$result['data'] = $resultSet;
            $result['count'] = $resultSet->count();
			if($export==null){
				//$paginatorAdapter = new DbSelect($sqlSelect,$this->tableGateway->getAdapter());
				//$result['data'] = new Paginator($paginatorAdapter); 	
			}
            return $result;
        }

		public function getGatewayDetails($gatewayID){
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('*'));
            $sqlSelect->join('tbl_sys_report', 'tbl_sys_report.did_fk = DeviceInventory.DID', array('*'), 'INNER');
            $sqlSelect->join('tbl_advance_sys_report', 'tbl_advance_sys_report.did_fk = tbl_sys_report.did_fk', array('*'), 'INNER');
            $sqlSelect->join('tbl_device_live_status', 'tbl_device_live_status.did_fk = DeviceInventory.DID', array('*'), 'INNER'); 
            $sqlSelect->where(array('DeviceInventory.DID'=>$gatewayID));
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
			return $resultSet;
		}

        public function fetchAll(){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $resultSet =$this->tableGateway->selectWith($sqlSelect);
            return $resultSet;
        }

        public function getDIDFromGroupId($grpIdStr){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('DID'));
            $sqlSelect->where(array("DeviceGroupID IN ($grpIdStr)"));
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
            $resultSet = $statement->execute();
            return $resultSet;
        }

        public function fetchMACAddress() { 
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('macaddress'));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            if($resultSet->count() > 0) {
                foreach($resultSet as $feature){
                    $result =  $feature->macaddress;
                 }
            }
            return $result;
 
        }

        public function fetchMACAddressForDssLicence() { 
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('macaddress'));
			$sqlSelect->where->notEqualTo('macaddress', "");
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            if($resultSet->count() > 0) {
                foreach($resultSet as $feature){
                    $result =  $feature->macaddress;
                 }
            }
            return $result; 
        }
		
		public function searchGateway($user_id, $searchArr){
            $sqlSelect = $this->tableGateway->getSql()->select();
			$predicate = new  \Zend\Db\Sql\Where();
            if($user_id==1){
                $sqlSelect->columns(array('*'));
            }else{
                $sqlSelect->columns(array('*'));
				$sqlSelect->quantifier('DISTINCT');
            }
            
            $sqlSelect->join('devicegroup', 'devicegroup.DeviceGroupID = DeviceInventory.DeviceGroupID', array('DeviceGroup'=>'DeviceGroup'), 'INNER');
            if($user_id!=1){
				$sqlSelect->join('tbl_user_access', 'tbl_user_access.group_id_fk = devicegroup.DeviceGroupID', array(), 'INNER');
			}
			$sqlSelect->join('tbl_sys_report', 'tbl_sys_report.did_fk = DeviceInventory.DID', array(), 'INNER');
			$sqlSelect->join('tbl_advance_sys_report', 'tbl_advance_sys_report.did_fk = DeviceInventory.DID', array('extraField3'=>'extraField3'), 'INNER');
            $sqlSelect->join('tbl_device_extra_info', 'tbl_device_extra_info.deviceID_Fk = DeviceInventory.DID', array('airplay_name'=>'airplay_name','airplay_max_no'=>'airplay_max_no','model_value'=>'model_value'), 'INNER');
            $sqlSelect->join('tbl_device_live_status', 'tbl_device_live_status.did_fk = DeviceInventory.DID', array('Network_status'=>'Network_status','last_updated_time'=>'last_updated_time'), 'INNER');
            $sqlSelect->join('tbl_device_dnsname', 'tbl_device_dnsname.DID_Fk = DeviceInventory.DID', array('field1'=>'field1','dns_name'=>'dns_name'), 'LEFT'); 
            if($user_id!=1){
				$sqlSelect->where(array('tbl_user_access.user_id_fk'=>$user_id));
			}
            if(!empty($searchArr)){
				foreach($searchArr as $val){
					if($val['field'] == 'DeviceName'){
						$deviceName = str_replace('"','',$val['value']);
						$totalCount=explode(',', $val['value']);
						$total=count($totalCount);
                        if ($total==1) {
                            $sqlSelect->where->like('DeviceInventory.DeviceName', '%'.$deviceName.'%');
                        }else if($total==2){
							$sqlSelect->where->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[0]).'%')->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[1]).'%');
						}
						else if($total==3){
						 $sqlSelect->where->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[0]).'%')->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[1]).'%')->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[2]).'%');
						}else if($total==4){
							$sqlSelect->where->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[0]).'%')->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[1]).'%')
							->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[2]).'%')
						   ->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[3]).'%');
						}else if($total==5){
						$sqlSelect->where->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[0]).'%')->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[1]).'%')
						->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[2]).'%')
						->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[3]).'%')
						->OR->like('DeviceInventory.DeviceName', '%'.str_replace('"','',$totalCount[4]).'%');
						}
						//echo $sqlSelect->getSqlString();
					}
					
					if($val['field'] == 'DeviceGroup'){
						$grpID = $val['id'];
						if($grpID !=0 && $grpID !=""){
							$sqlSelect->where(array('DeviceInventory.DeviceGroupID IN ('.$grpID.')'));
						}
					}
					if($val['field'] == 'Version'){
						$versionStr = str_replace(array('(',')','"',' '),"",$val['value']);
						$version = "'" . implode("','", explode(",", $versionStr)) ."'";
						$sqlSelect->where(array("DeviceInventory.Version IN (".$version.")"));
					}
					if($val['field'] == 'DeviceIP'){
						$deviceIp = str_replace('"','',$val['value']);
						$sqlSelect->where->like('DeviceInventory.DeviceIP','%'.$deviceIp.'%');
					}
					if($val['field'] == 'DeviceID'){
						$boxId = str_replace('"','',$val['value']);
						$sqlSelect->where->like('DeviceInventory.DeviceID','%'.$boxId.'%');
					}
					if($val['field'] == 'os_type'){
						$model_value = $val['id'];
						if (strstr($model_value, '6')) {
							$model_value = str_replace('6','5,6',$model_value);
						  }
						$sqlSelect->where(array('tbl_device_extra_info.model_value IN ('.$model_value.')'));
					}
					if($val['field'] == 'Network_status'){
						$status = str_replace('"','',$val['value']);
						if($status=='ON'){
							$qry.=" AND L.Network_status IN (1,2)";
							$sqlSelect->where(array('tbl_device_live_status.Network_status IN (1,2)'));
						}
						if($status=='OFF'){
							$sqlSelect->where(array('tbl_device_live_status.Network_status'=> 0));
						}
					}
					if($val['field'] == 'CPU_Status'){
						$cpuStatus = str_replace('"','',$val['id']);
						if($cpuStatus==1){
							$sqlSelect->where($predicate->greaterThan("tbl_device_live_status.CPU_Status", -1), 'AND');
							$sqlSelect->where($predicate->lessThan("tbl_device_live_status.CPU_Status", 51), 'AND');
						}else if($cpuStatus==2){
							$sqlSelect->where($predicate->greaterThanOrEqualTo("tbl_device_live_status.CPU_Status", 51), 'AND');
							$sqlSelect->where($predicate->lessThanOrEqualTo("tbl_device_live_status.CPU_Status", 80), 'AND');
						}else if($cpuStatus==3){
							$sqlSelect->where($predicate->greaterThan("tbl_device_live_status.CPU_Status", 80), 'AND');
						}
					}
					if($val['field'] == 'HD_Status'){
						$hdStatus = str_replace('"','',$val['id']);
						if($hdStatus==1){
							$sqlSelect->where($predicate->greaterThan("tbl_device_live_status.HD_Status", -1), 'AND');
							$sqlSelect->where($predicate->lessThan("tbl_device_live_status.HD_Status", 51), 'AND');
						}else if($hdStatus==2){
							$sqlSelect->where($predicate->greaterThanOrEqualTo("tbl_device_live_status.HD_Status", 51), 'AND');
							$sqlSelect->where($predicate->lessThanOrEqualTo("tbl_device_live_status.HD_Status", 70), 'AND');
						}else if($hdStatus==3){
							$sqlSelect->where($predicate->greaterThan("tbl_device_live_status.HD_Status", 70), 'AND');
						}
					}
				}
                
            }
            $sqlSelect->order('DeviceInventory.DeviceName');
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
			$result['data'] = $resultSet;
            $result['count'] = $resultSet->count();
			$paginatorAdapter = new DbSelect($sqlSelect,$this->tableGateway->getAdapter());
			$result['data'] = new Paginator($paginatorAdapter);
            return $result;
        }
		
		public function getIndexList($definput){
			$sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('*'));
            $sqlSelect->join('devicegroup', 'devicegroup.DeviceGroupID = DeviceInventory.DeviceGroupID', array('DeviceGroup'=>'DeviceGroup'), 'INNER');
			$sqlSelect->join('tbl_device_dnsname', 'tbl_device_dnsname.DID_Fk = DeviceInventory.DID', array('dns_name'=>'dns_name'), 'LEFT'); 
			if(!empty($definput)){
                $sqlSelect->where->like(new \Zend\Db\Sql\Expression('Concat(DeviceInventory.DeviceName, devicegroup.DeviceGroup)'),'%'.$definput.'%');
            }
			$sqlSelect->order('DeviceInventory.DeviceName');
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
			$paginatorAdapter = new DbSelect($sqlSelect,$this->tableGateway->getAdapter());
			$result = new Paginator($paginatorAdapter);
            return $result;
		}
		public function getGatewayNamebyid($did){
			 $did  = (int) $did;
			 $rowset = $this->tableGateway->select(array('DID' => $did));			 
			 $row = $rowset->current();
			 return $row;
		}
		
	
 }