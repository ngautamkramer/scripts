<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

 class TblAppUserGroups implements InputFilterAwareInterface
 {
     public $AppUserGroupID;
	 public $appuserid;
     public $appgroupid;
     public $modifydate;
	 public $UserName;
	 public $hostname; 
     protected $inputFilter;                       // <-- Add this variable

     public function exchangeArray($data)
     {
	 	 $this->AppUserGroupID= (isset($data['AppUserGroupID']))? $data['AppUserGroupID']: null;
         $this->appuserid= (isset($data['appuserid']))? $data['appuserid']: null;
         $this->appgroupid = (isset($data['appgroupid'])) ? $data['appgroupid'] : null;
         $this->modifydate  = (isset($data['status']))  ? $data['status']  : null;
		 $this->UserName  = (isset($data['UserName']))  ? $data['UserName']  : null;
		 $this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null;
		 
		 
		 
     }
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();
             $inputFilter->add(array(
                 'name'     => 'login_name',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'login_password',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }
	 
	 
	 
	 

	 
 }
