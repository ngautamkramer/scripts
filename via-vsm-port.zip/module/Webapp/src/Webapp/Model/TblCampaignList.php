<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblCampaignList
{
    public $cid;
    public $createDate;
    public $modifydate;
    public $fileName;
    public $cName;    

    public function exchangeArray($data){
        $this->cid = (isset($data['cid']))? $data['cid']: null;
        $this->createDate = (isset($data['createDate']))? $data['createDate']: null;
        $this->modifydate = (isset($data['modifydate'])) ? $data['modifydate'] : null;
        $this->fileName  = (isset($data['fileName']))  ? $data['fileName']  : null;
	    $this->cName  = (isset($data['cName']))  ? $data['cName']  : null;	    
    }
       

	 
}
