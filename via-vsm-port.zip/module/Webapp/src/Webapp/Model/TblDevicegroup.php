<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblDevicegroup implements InputFilterAwareInterface
 {
	  public $DeviceGroupID;
	  public $DeviceMasterID;
	  public $DeviceGroup; 
      public $Comments; 
 
   public function exchangeArray($data)
	{
		 $this->DeviceGroupID = (isset($data['DeviceGroupID']))? $data['DeviceGroupID']: null;
		 $this->DeviceMasterID = (isset($data['DeviceMasterID']))? $data['DeviceMasterID']: null;
		 $this->DeviceGroup = (isset($data['DeviceGroup']))? $data['DeviceGroup']: null;
		 $this->Comments = (isset($data['Comments']))? $data['Comments']: null;
	}
	
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}
	public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }

     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();
             $inputFilter->add(array(
                 'name'     => 'grpName',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 25,
                         ),
                     ),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'grpRemarks',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 200,
                         ),
                     ),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }
	
 }