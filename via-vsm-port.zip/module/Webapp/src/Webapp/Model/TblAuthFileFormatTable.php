<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblAuthFileFormatTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

        public function fetchAllData(){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            foreach($resultSet as $key => $fileFormat){
               $result[$key]['fileformat'] = $fileFormat->fileformat;
               $result[$key]['formatstatus'] = $fileFormat->formatstatus;
            }
            return $result;
        }
	
        public function fetchFileFormat($FormatStatus,$FileFormat) { 
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where(array('fileformat' => $FileFormat, 'formatstatus' => $FormatStatus));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            foreach($resultSet as $fileFormat){
               $result = $fileFormat->formatstatus;
            }
            return $result;
        }
        
        public function fetchSelectedFileFormat() { 
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where(array("fileformat NOT IN ('All')"));
            $sqlSelect->where(array("formatstatus" => 1));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            foreach($resultSet as $fileFormat){
               $result[] = $fileFormat->fileformat;
            }
            return $result;
        }
        
        public function fetchAllFileFormat() { 
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where(array("fileformat NOT IN ('All','jpeg','pdf','png','jpg')"));
            $sqlSelect->order('fileformat ASC');
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            foreach($resultSet as $key => $file){
               $result[$key]['fileformat'] = $file->fileformat;
               $result[$key]['formatstatus'] = $file->formatstatus;
            }
            
            return $result;
        }
        
        public function fetchFileStatus($FileFormat) { 
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where(array('fileformat' => $FileFormat));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            foreach($resultSet as $fileFormat){
               $result = $fileFormat->formatstatus;
            }
            return $result;
        }
        
        public function fetchAll(){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where(array("fileformat NOT IN ('All')"));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            foreach($resultSet as $fileFormat){
               $result[] = $fileFormat->fileformat;
            }
            return $result;
        }
        
        public function fetchFileFormatWithoutStatus($customFileString){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where(array("fileformat IN ($customFileString)"));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            if($resultSet->count()>0){
                foreach($resultSet as $fileFormat){
                    $result[] = $fileFormat->fileformat;
                }
            }else{
                $result=0;
            }
            return $result;
        }
        
        public function updateStatus($status){
            $sqlUpdate = $this->tableGateway->update(array('formatstatus'=>$status),array("fileformat NOT IN ('jpeg','pdf','png','jpg')"));
        }
        
        public function updateSelectedFileStatus($status,$format){
            $sqlUpdate = $this->tableGateway->update(array('formatstatus'=>$status),array("fileformat IN ($format)"));
        }
        
        public function addNewFileFormat($newFormatArr){
            $sqlUpdate = $this->tableGateway->insert($newFormatArr);
        }
        
        public function deleteFileFormat($fileArr){
            $sqlUpdate = $this->tableGateway->delete($fileArr);
        }
	
 }