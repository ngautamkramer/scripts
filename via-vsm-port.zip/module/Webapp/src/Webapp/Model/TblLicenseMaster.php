<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblLicenseMaster
{
  	public $licmsterid;
    public $uniqueid;
    public $orderid;
    public $no_of_devices;
    public $purchase_date;
    public $license_validity;    
    public $license_expiry_date;    
    public $number_of_lic_used;    

    public function exchangeArray($data){
        $this->licmsterid = (isset($data['licmsterid']))? $data['licmsterid']: null;
        $this->uniqueid = (isset($data['uniqueid']))? $data['uniqueid']: null;
        $this->orderid = (isset($data['orderid'])) ? $data['orderid'] : null;
        $this->no_of_devices  = (isset($data['no_of_devices']))  ? $data['no_of_devices']  : null;
	    $this->purchase_date  = (isset($data['purchase_date']))  ? $data['purchase_date']  : null;	    
        $this->license_validity  = (isset($data['license_validity']))  ? $data['license_validity']  : null;
        $this->license_expiry_date  = (isset($data['license_expiry_date']))  ? $data['license_expiry_date']  : null;
        $this->number_of_lic_used  = (isset($data['number_of_lic_used']))  ? $data['number_of_lic_used']  : null;
    }
       

	 
}
