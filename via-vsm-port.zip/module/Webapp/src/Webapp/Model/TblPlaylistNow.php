<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblPlaylistNow
{
    public $ID;
    public $OID;
    public $DID;
    public $fileName;
    public $sync_status;    


    public $StartTime;
    public $EndTime;
    public $StartDate;
    public $EndDate;
    public $ModifyDateTime;    
    public $UserName;    


    public function exchangeArray($data){
        $this->ID = (isset($data['ID']))? $data['ID']: null;
        $this->OID = (isset($data['OID']))? $data['OID']: null;
        $this->DID = (isset($data['DID'])) ? $data['DID'] : null;
        $this->fileName  = (isset($data['fileName']))  ? $data['fileName']  : null;
	    $this->sync_status  = (isset($data['sync_status']))  ? $data['sync_status']  : null;	

        $this->StartTime = (isset($data['StartTime']))? $data['StartTime']: null;
        $this->EndTime = (isset($data['EndTime']))? $data['EndTime']: null;
        $this->StartDate = (isset($data['StartDate'])) ? $data['StartDate'] : null;
        $this->EndDate  = (isset($data['EndDate']))  ? $data['EndDate']  : null;
        $this->ModifyDateTime  = (isset($data['ModifyDateTime']))  ? $data['ModifyDateTime']  : null;    
        $this->UserName  = (isset($data['UserName']))  ? $data['ModifyDateTime']  : null;    
    }
       

	 
}
