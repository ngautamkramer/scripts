<?php
namespace Webapp\Model;
// Add these import statements
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class TblRecordingChild {
	public $rchild;
	public $rmaster;
	public $starttime;
	public $endtime;
	public $filename;
	public $duration;
	public $screen;
	public $user;
	public $status;
	public $reserved1;
	public $reserved2;

	public function exchangeArray($data) {
		$this->rchild =(isset($data['rchild']))? $data['rchild'] : null;
		$this->rmaster =(isset($data['rmaster']))? $data['rmaster'] : null;
		$this->endtime =(isset($data['endtime']))? $data['endtime'] : null;
		$this->filename =(isset($data['filename']))? $data['filename'] : null;
		$this->duration =(isset($data['duration']))? $data['duration'] : null;
		$this->screen =(isset($data['screen']))? $data['screen'] : null;
		$this->user =(isset($data['user']))? $data['user'] : null;
		$this->status =(isset($data['status']))? $data['status'] : null;
		$this->reserved1 =(isset($data['reserved1']))? $data['reserved1'] : null;
		$this->reserved2 =(isset($data['reserved2']))? $data['reserved2'] : null;
	}
}
