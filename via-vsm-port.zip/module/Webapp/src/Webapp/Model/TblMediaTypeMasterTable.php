<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;

 class TblMediaTypeMasterTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

        public function getMediaType() {
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT MediaTypeID, MediaType, MediaComponentID
                FROM mediatypemaster";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }

        public function getMediaTypeIdByName($mediaType) {
            $appObj = new ApplicationController();            
            $sqlQuery = "SELECT MediaTypeID
                FROM mediatypemaster 
            WHERE MediaType = '".$mediaType."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }
  
 }