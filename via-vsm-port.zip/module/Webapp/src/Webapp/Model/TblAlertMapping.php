<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblAlertMapping
 {
    public $id;
    public $alert_id_fk;
    public $user_id_fk;
    public $group_id_fk;
    public $device_id_fk;
    public $created_on;
    public $status;
   

    public function exchangeArray($data)
	{
		$this->id= (isset($data['id']))? $data['id']: null;
		$this->alert_id_fk= (isset($data['alert_id_fk']))? $data['alert_id_fk']: null;
		$this->user_id_fk= (isset($data['user_id_fk']))? $data['user_id_fk']: null;
		$this->group_id_fk= (isset($data['group_id_fk']))? $data['group_id_fk']: null;
        $this->device_id_fk= (isset($data['device_id_fk']))? $data['device_id_fk']: null;
        $this->created_on= (isset($data['created_on']))? $data['created_on']: null;
        $this->status= (isset($data['status']))? $data['status']: null;
    }
    public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }