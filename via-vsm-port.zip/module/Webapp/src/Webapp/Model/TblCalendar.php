<?php

namespace Webapp\Model; // define namespace for current file

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

/*********
 * @Name   : TblCalendar
 * @Table  : tbl_calender
 * @Author : Dileep Kumar
 * @Date   : 25 JAN 2020
 * ******/
 
class TblCalendar implements InputFilterAwareInterface
{
	public $id;
	public $color;
	public $name;
	public $account_id;
	public $calender_id;
	public $timezone;
	public $created_at;
	protected $inputFilter;
	
	// this function is automatically called
	public function exchangeArray($data)
	{
	 $this->id     = (isset($data['id']))     ? $data['id']     : null;
	 $this->color     = (isset($data['color']))     ? $data['color']     : null;
	 $this->name = (isset($data['name'])) ? $data['name'] : null;
	 $this->account_id = (isset($data['account_id'])) ? $data['account_id'] : null;
	 $this->calender_id = (isset($data['calender_id'])) ? $data['calender_id'] : null;
	 $this->timezone = (isset($data['timezone'])) ? $data['timezone'] : null;
	 $this->created_at = (isset($data['created_at'])) ? $data['created_at'] : null;
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

	// function of InputFilterAwareInterface interface needed to implement
	public function setInputFilter(InputFilterInterface $inputFilter)
	{
		throw new \Exception("Not used");
	}
	// function of InputFilterAwareInterface interface needed to implement
	// validation for form
	public function getInputFilter()
    {
		
	}
}
?>
