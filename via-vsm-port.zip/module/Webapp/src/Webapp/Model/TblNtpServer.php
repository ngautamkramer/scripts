<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblNtpServer implements InputFilterAwareInterface
{
    public $id;
    public $ntp_name;
    public $status;
    public $ntp_uuid;
    public $modifydate;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id = (isset($data['id']))? $data['id']: null;
        $this->ntp_name = (isset($data['ntp_name']))? $data['ntp_name']: null;
        $this->status = (isset($data['status'])) ? $data['status'] : null;
        $this->ntp_uuid = (isset($data['ntp_uuid'])) ? $data['ntp_uuid'] : null;
        $this->modifydate = (isset($data['modifydate'])) ? $data['modifydate'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
