<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
 class TblPlaylistScheduleMasterTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }      

        public function insertPlaylistMaster($data) {
            $this->tableGateway->insert($data);
            //$lastInsertId = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    $lastInsertId = $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('playlist_schedule_master_oid_seq');
            $appObj = new ApplicationController();
            $session = new Container('userinfo');
            $user = $session->offsetGet('LoginName');
            if(PRODUCT == 'via') {
                $appObj->ActivityLog('Create', 'Schedule: '. $data['schedulename']);
            } else {
                $appObj->ActivityLogVSM(3, 'Schedule: '.$data['schedulename'], 21);
            }
            return $lastInsertId;
        } 

        public function deletePlaylistScheduleMaster($whereCondition) {
            $appObj = new ApplicationController();
            $session = new Container('userinfo');
            $user = $session->offsetGet('LoginName');
            if(PRODUCT == 'via') {
                $appObj->ActivityLog('Delete','Schedule deleted by '. $user);
            } else {
                $appObj->ActivityLogVSM(5,'Schedule deleted by '. $user,21);
            } 
            $this->tableGateway->delete($whereCondition); 
        }

        public function getAllPlaylistScheduleMaster() {    

            $appObj = new ApplicationController();  
            $sqlQuery = "SELECT * FROM playlist_schedule_master psm 
                INNER JOIN campaignlist as cl
                     ON psm.cid = cl.cid 
                ORDER BY psm.oid DESC";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;

        }

        public function getSelectedScheduleMaster($userData) {
            $appObj = new ApplicationController();  
            $sqlQuery = "SELECT * FROM playlist_schedule_master psm 
                INNER JOIN campaignlist as cl
                     ON psm.cid = cl.cid WHERE psm.oid = '".$userData["scheduleCampaignId"]."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

        public function fetchDataForDuplicateSchedule($userData) {
            $appObj = new ApplicationController();  
            $sqlQuery = "SELECT psm.*, pn.* FROM playlist_schedule_master psm 
                INNER JOIN  playlist_now as pn
                     ON psm.OID = pn.OID WHERE psm.OID = '".$userData["scheduleCampaignId"]."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

        public function updatePlaylistMaster($whereCondition, $userData) {
            $appObj = new ApplicationController(); 
            $session = new Container('userinfo');
            $user = $session->offsetGet('LoginName');
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Update','Schedule: '. $userData['schedulename']);
            }else{
                $appObj->ActivityLogVSM(4,'Schedule: '. $userData['schedulename'],21);
            }
            $result = $this->tableGateway->update($userData, $whereCondition);
            return $result;
        }

        public function canCampaignDelete($userData) {
            $appObj = new ApplicationController();  
            $sqlQuery = "SELECT * FROM playlist_schedule_master 
                Where CID = '".$userData["campaignId"]."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }
		//Modified by ashu on 17Aug2022 to change this function according to zend
        public function checkScheduleUniqueName($data) {
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('oid'));
			if($data["oid"]){
				//$sqlSelect->where(array("schedulename" => $data["scheduleName"], "oid!= ".$data["oid"].""  ));
                $sqlSelect->where(array("oid!= ".$data["oid"]."" ));
                $sqlSelect->where->expression("schedulename ILIKE ?",  $data["scheduleName"]);
			}else{
				//$sqlSelect->where(array("schedulename" => $data["scheduleName"]));
                $sqlSelect->where->expression("schedulename ILIKE ?",  $data["scheduleName"]);

			}		
			//echo $sql->getSqlstringForSqlObject($sqlSelect); die ;
			$sql->getSqlstringForSqlObject($sqlSelect); 	
			$resultSet = $this->tableGateway->selectWith($sqlSelect);		
            return $resultSet; 
        }

        public function getServerDateTime(){
            $appObj = new ApplicationController();   
            $sqlQuery = "SELECT CURRENT_TIMESTAMP::TIMESTAMP AS current_date_time";       
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }


        public function getLoginUserAllGroups() {
            $session = new Container('userinfo');
            $loginUserId = $session->offsetGet('usrid');
            $appObj = new ApplicationController();   
            $sqlQuery = "SELECT DISTINCT(group_id_fk) FROM tbl_user_access WHERE user_id_fk = ".$loginUserId."";            
            $selectResultSet = $appObj->returnQueryData($sqlQuery);  
            $groupIds = array();
            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
                $groupIds[] = $resultSet["group_id_fk"];
            }
            return $groupIds;
        }
        
        public function getAllDeviceGroupAndInventory() {
            $session = new Container('userinfo');
            $loginUserId = $session->offsetGet('usrid');
            $appObj = new ApplicationController();   
            // $sqlQuery = "SELECT dg.DeviceGroup as deviceGroup, dg.DeviceGroupID as deviceGroupId, dg.DeviceMasterID as deviceMasterId, di.DID as deviceInventryId, di.DeviceName as deviceName, di.DeviceGroupID as deviceGroupInventroyID
            //     FROM DeviceGroup dg 
            //         LEFT JOIN DeviceInventory di ON dg.DeviceGroupID = di.DeviceGroupID 
            //         INNER JOIN tbl_user_access AS tua ON tua.group_id_fk = dg.DeviceGroupID
            //     WHERE tua.user_id_fk = ".$loginUserId.""; 
            $sqlQuery = "SELECT dg.DeviceGroup as deviceGroup, dg.DeviceGroupID as deviceGroupId, dg.DeviceMasterID as deviceMasterId, di.active as deviceActive, di.DID as deviceInventryId, di.DeviceName as deviceName, di.DeviceGroupID as deviceGroupInventroyID
                FROM DeviceGroup dg 
                    LEFT JOIN DeviceInventory di ON dg.DeviceGroupID = di.DeviceGroupID";       
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet; 
        }
        
        function isGatewayModelTypeViaGoTwo($did) {
            $appObj = new ApplicationController();   
            $sqlQuery = "SELECT model_value FROM tbl_device_extra_info WHERE deviceID_Fk = ".$did." AND model_value = 12";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

        public function getAllDeviceIdsOfSchedule($userData) {
            $appObj = new ApplicationController();   
            $sqlQuery = "SELECT di.DeviceName, pln.DID FROM playlist_schedule_master as psm
                    INNER JOIN playlist_now pln ON psm.OID = pln.OID 
                    INNER JOIN DeviceInventory as di on di.DID = pln.DID 
                WHERE psm.OID = '".$userData["scheduleCampaignId"]."'";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

 }