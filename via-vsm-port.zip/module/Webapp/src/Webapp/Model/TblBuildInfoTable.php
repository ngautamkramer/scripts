<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class TblBuildInfoTable {
	protected $tableGateway;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}

	public function fetchAll() {
		$select = $this->tableGateway->getSql()->select();
		$select->order('id DESC');
		if(PRODUCT=='via'){
			$select->limit(1);
		}
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}
	public function fetchOne() {
		$select = $this->tableGateway->getSql()->select();
		$select->order('id DESC');
		$select->limit(1);
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}

	public function getAllData($data) {
		$select = $this->tableGateway->getSql()->select();
		$select->columns(array('client_version_no'));
		$select->where->like('client_version_no',$data.'%');
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}

	public function getAppList($data) {
		$select = $this->tableGateway->getSql()->select();
		$select->columns(array('client_version_no'));
		$resultSet = $this->tableGateway->selectWith($select);
		return $resultSet;
	}

	public function getClientId($data) {
		$rowset = $this->tableGateway->select(array('client_version_no' => $data));
		$row = $rowset->current();
		if(!$row) {
			throw new \Exception("Could not find row");
			
		}
		return $row;
	}

	public function readVersionFile($readMyversionFileTxt) {
		$rowset = $this->tableGateway->select(array('client_version_no' => $readMyversionFileTxt));
		//$row = $rowset->current();
		if(!$row) {
			throw new \Exception("Could not find row ");
		}
		return $rowset ;
	}

	public function insertClientVersion($readMyversionFileTxt) {
		$this->tableGateway->insert(array('client_version_no' =>$readMyversionFileTxt));
		//return $lastInsertid = $this->tableGateway->lastInsertValue;
		// for return last inserted id from pgsql
		return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('tbl_buildinfo_id_seq');
             
	}
	
	
}
