<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblAutoDiscoverVsm implements InputFilterAwareInterface
{
    public $autoid;
    public $HQ_WallpaperSetting;
    public $HQ_AuthSetting;
    public $HQ_ConfigSetting;
    public $HQ_GwayFeatureSetting;
    public $HQ_ClientFeatureSetting;
    public $HQ_MobileFeatureSetting;
    public $featureStatus1;
    public $featureStatus2;
    public $featureStatus3;
    public $featureStatus4;
    public $featureStatus5;
    public $featureStatus6;
    public $featureStatus7;
    public $featureStatus8;
	public $featureStatus9;
	public $featureStatus10;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->autoid = (isset($data['autoid']))? $data['autoid']: null;
        $this->HQ_WallpaperSetting = (isset($data['HQ_WallpaperSetting']))? $data['HQ_WallpaperSetting']: null;
        $this->HQ_AuthSetting = (isset($data['HQ_AuthSetting'])) ? $data['HQ_AuthSetting'] : null;
        $this->HQ_ConfigSetting  = (isset($data['HQ_ConfigSetting']))  ? $data['HQ_ConfigSetting']  : null;
        $this->HQ_GwayFeatureSetting  = (isset($data['HQ_GwayFeatureSetting']))  ? $data['HQ_GwayFeatureSetting']  : null; 
        $this->HQ_ClientFeatureSetting  = (isset($data['HQ_ClientFeatureSetting']))  ? $data['HQ_ClientFeatureSetting']  : null; 
        $this->HQ_MobileFeatureSetting  = (isset($data['HQ_MobileFeatureSetting']))  ? $data['HQ_MobileFeatureSetting']  : null; 
        $this->featureStatus1  = (isset($data['featureStatus1']))  ? $data['featureStatus1']  : null; 
        $this->featureStatus2  = (isset($data['featureStatus2']))  ? $data['featureStatus2']  : null; 
        $this->featureStatus3  = (isset($data['featureStatus3']))  ? $data['featureStatus3']  : null; 
        $this->featureStatus4  = (isset($data['featureStatus4']))  ? $data['featureStatus4']  : null; 
        $this->featureStatus5  = (isset($data['featureStatus5']))  ? $data['featureStatus5']  : null;
		$this->featureStatus6  = (isset($data['featureStatus6']))  ? $data['featureStatus6']  : null;  
        $this->featureStatus7  = (isset($data['featureStatus7']))  ? $data['featureStatus7']  : null;
		$this->featureStatus8  = (isset($data['featureStatus8']))  ? $data['featureStatus8']  : null; 
		$this->featureStatus9  = (isset($data['featureStatus9']))  ? $data['featureStatus9']  : null;
		$this->featureStatus10  = (isset($data['featureStatus10']))  ? $data['featureStatus10']  : null; 
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
