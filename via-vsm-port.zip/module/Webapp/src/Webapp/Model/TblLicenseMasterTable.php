<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;
//for pagination
use Zend\Paginator\Paginator;

 class TblLicenseMasterTable
 {
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }      

    public function inserDataForDssFont($userData) {     
        $appObj = new ApplicationController();
        $appObj->ActivityLog('Insert Font','Font Name: ' . $userData["fontName"] );     

        $this->tableGateway->insert($userData);
        //return $lastInsertid = $this->tableGateway->lastInsertValue;
        // for return last inserted id from pgsql
		return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('license_master_licmsterid_seq');
    }

	public function getOrderCount($orderid){
		 $rowset = $this->tableGateway->select(array('orderid' => $orderid));
		 return $rowset->count();
	}
	public function checkUniqueId($uniqueId){
		 $rowset = $this->tableGateway->select(array('uniqueid' => $uniqueId));
		 return $rowset;
	}
	
	
	
        public function fetchAll() { 
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('*'));
            $select->order('orderid DESC');			
            $resultSet = $this->tableGateway->selectWith($select);
             // create a new pagination adapter object
            $paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
            $resultSet = new Paginator($paginatorAdapter); 			       
            return $resultSet;				
        }
	
				
 }