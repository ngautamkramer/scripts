<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblAutoDiscoverVsmTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
        public function getData($condition){
            $select = $this->tableGateway->getSql()->select();
            $select->where($condition);
            $resultSet =$this->tableGateway->selectWith($select);
            return $resultSet;
        }
		
		public function insert($insertArr){
            $this->tableGateway->insert($insertArr);
        }
 }