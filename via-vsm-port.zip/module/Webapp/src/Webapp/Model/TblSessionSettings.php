<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblSessionSettings implements InputFilterAwareInterface
{
    public $id;
    public $sessionTimeOut;
    public $captcha;
    public $created_by;
    public $created_on;
    public $field1; //broadcast setting
    public $field2; 
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->sessionTimeOut= (isset($data['sessionTimeOut']))? $data['sessionTimeOut']: null;
        $this->captcha = (isset($data['captcha'])) ? $data['captcha'] : null;
        $this->created_by  = (isset($data['created_by']))  ? $data['created_by']  : null;
	$this->created_on  = (isset($data['created_on']))  ? $data['created_on']  : null;
	$this->field1  = (isset($data['field1']))  ? $data['field1']  : null;  
        $this->field2  = (isset($data['field2']))  ? $data['field2']  : null;  
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
