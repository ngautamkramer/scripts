<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblStreamingSettings implements InputFilterAwareInterface
{
    public $id;
    public $status;
    public $display_url_1;
    public $display_url_2;
    public $reserve1;
    public $reserve2; 
    public $reserve3; 
    public $reserve4; 
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->status= (isset($data['status']))? $data['status']: null;
        $this->display_url_1 = (isset($data['display_url_1'])) ? $data['display_url_1'] : null;
        $this->display_url_2  = (isset($data['display_url_2']))  ? $data['display_url_2']  : null;
	$this->reserve1  = (isset($data['reserve1']))  ? $data['reserve1']  : null;
	$this->reserve2  = (isset($data['reserve2']))  ? $data['reserve2']  : null;  
        $this->reserve3  = (isset($data['reserve3']))  ? $data['reserve3']  : null;   
        $this->reserve4  = (isset($data['reserve4']))  ? $data['reserve4']  : null;   
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
