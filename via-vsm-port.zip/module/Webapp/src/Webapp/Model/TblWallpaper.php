<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblWallpaper implements InputFilterAwareInterface
{
    public $id;
    public $wallp_name;
    public $wallp_created_by;
    public $wallp_is_active;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->wallp_name= (isset($data['wallp_name']))? $data['wallp_name']: null;
        $this->wallp_created_by = (isset($data['wallp_created_by'])) ? $data['wallp_created_by'] : null;
        $this->wallp_is_active = (isset($data['wallp_is_active'])) ? $data['wallp_is_active'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
