<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblComplexPassword implements InputFilterAwareInterface
 {
	  public $id;
	  public $alphanumeric;
	  public $specialchar; 
      public $capitalltr; 
	  public $checkoldpass; 
	  public $minimumchar; 
	  public $passvalidity; 
	  public $applyin_basicmode; 
	  public $modifydatetime; 
 
 
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->alphanumeric= (isset($data['alphanumeric']))? $data['alphanumeric']: null;
		 $this->specialchar= (isset($data['specialchar']))? $data['specialchar']: null;
		 $this->capitalltr= (isset($data['capitalltr']))? $data['capitalltr']: null;
		 $this->checkoldpass= (isset($data['checkoldpass']))? $data['checkoldpass']: null;
		 $this->minimumchar= (isset($data['minimumchar']))? $data['minimumchar']: null;
		 $this->passvalidity= (isset($data['passvalidity']))? $data['passvalidity']: null;
		 $this->applyin_basicmode= (isset($data['applyin_basicmode']))? $data['applyin_basicmode']: null;
		 $this->modifydatetime= (isset($data['modifydatetime']))? $data['modifydatetime']: null;
	}
	
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}
	public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }

     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();
             $inputFilter->add(array(
                 'name'     => 'login_name',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'login_password',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }
	
 }