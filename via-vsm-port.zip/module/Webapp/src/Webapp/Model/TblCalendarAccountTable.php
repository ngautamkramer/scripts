<?php

namespace Webapp\Model;  // define namespace for current file

use Zend\Db\TableGateway\TableGateway;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Select;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
use Zend\Session\Container; //for session
/*********
 * @Name   : TblCalendarAcocuntTable
 * @Desc   : It is for custom functions related to TblCalendarAcocuntTable model
 * @Author : Dileep Kumar
 * @Date   : 24 APR 2018
 * ******/
 
class TblCalendarAccountTable
{
     protected $tableGateway;
	// object of tablegateway is flushed to constructor
     public function __construct(TableGateway $tableGateway)
     {
         $this->tableGateway = $tableGateway;
     }
	 
	 /*****
	 *	@Function Name		: fetchAll
	 *  @description	    : get calendar accounts
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-Jan-2020
	 *****/
	 public function fetchAll()
     { 
		$resultSet = $this->tableGateway->select();
         return $resultSet;
     }
	 
	 /*****
	 *	@Function Name		: deleteCalAccount
	 *  @description	    : delete the calendar account
     *	@Author			    : Dileep Yadav
	 *  @Date               : 12-Dec-2018
	 *****/
	 
	public function deleteCalAccount($accountId,$compId)
	{ 
		$result=$this->tableGateway->delete(array('account_id' =>"$accountId","compId_fk IN ($compId)"));
		if($result==1){
			return 1;die;
		}
	}
		
}