<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;
//for pagination
use Zend\Paginator\Paginator;

 class TblDssLicenseMasterTable
 {
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }     

    public function updateLicenseUsed($whereCondition, $userData) {
        // $appObj = new ApplicationController();  
        // if($userData['cName']) {
        //   $appObj->ActivityLog('Update Campaign','Campaign Name: '. $userData['cName']);
        // }
        $result = $this->tableGateway->update($userData, $whereCondition);
        return $result;
    } 

    public function insertDataDssLicenseMaster($data) {
        // $appObj = new ApplicationController();  
        // $appObj->ActivityLog('Create Campaign','Campaign Name: '. $data['cName']);
        
        $encryptionKey = POLL_ENCRPTION_KEY;
        $appObj = new ApplicationController();  
        $uniqueId = $data["unique_id"];
        $orderId = $data["order_id"];
        $numOfDevices = $data["num_of_devices"];
        $purchaseDate =  $data["purchase_date"];
        $validityMonths = $data["validity_months"];
        $expiryDate = $data["expiry_date"];
        $numOfLicUsed = $data["num_of_lic_used"];
        $sqlQuery = "INSERT INTO dss_license_master (unique_id, order_id, num_of_devices, purchase_date, validity_months, expiry_date, num_of_lic_used) values ('$uniqueId', AES_ENCRYPT('$orderId', '$encryptionKey'), '$numOfDevices', '$purchaseDate', '$validityMonths', '$expiryDate', 0)";    
        
        $appObj->returnQueryData("START TRANSACTION");//begin transtion
        $execute = $appObj->returnQueryData($sqlQuery);

        $lastInsertId = isset($execute->getResource()->insert_id)? $execute->getResource()->insert_id : $execute->getGeneratedValue();
        // $lastInsertId = $execute->getResource()->insert_id;
        // if(empty($lastInsertId)){
        //     $lastInsertId = $execute->getGeneratedValue();
        // }
        return $lastInsertId;
    }

    public function checkDuplicateOrder($condition) {        
        $encryptionKey = POLL_ENCRPTION_KEY;        
        $orderId = $condition["orderId"];
        $orderId = "AES_ENCRYPT('$orderId', '$encryptionKey')";
        $appObj = new ApplicationController();     
        
        $sqlQuery = "SELECT COUNT(*) as cnt FROM dss_license_master WHERE order_id = ".$orderId."";
        $resultSet = $appObj->returnQueryData($sqlQuery); 
        return $resultSet; 
        // $selectQry = $this->tableGateway->getSql()->select();
        // $selectQry->where($condition);
        // $resultSet = $this->tableGateway->selectWith($selectQry);
        // return $resultSet->count();
    }

    public function fetchAllDssLicenseMaster() { 
        $appObj = new ApplicationController();
        $encryptionKey = POLL_ENCRPTION_KEY;
        $sqlQuery = "SELECT dss_master_id, unique_id, AES_DECRYPT(order_id, '$encryptionKey') as order_id, num_of_devices, purchase_date, validity_months, expiry_date, num_of_lic_used FROM dss_license_master ORDER BY dss_master_id DESC";
        // $sqlQuery = "SELECT * FROM dss_license_master ORDER BY dss_master_id DESC limit 1";
        $resultSet = $appObj->returnQueryData($sqlQuery); 
        return $resultSet;
    }

    public function getNumLicenseUsed($searchFilter) {
        $appObj = new ApplicationController();       
        $sqlQuery = "SELECT num_of_lic_used, num_of_devices FROM dss_license_master WHERE unique_id = '".$searchFilter["uniqueId"]."'";
        // $sqlQuery = "SELECT * FROM dss_license_master ORDER BY dss_master_id DESC limit 1";
        $resultSet = $appObj->returnQueryData($sqlQuery); 
        return $resultSet;
    }	

    public function updateNumLicenseUsed($updateData) {
        $appObj = new ApplicationController();       
        $sqlQuery = "UPDATE dss_license_master SET num_of_lic_used = ".$updateData["numLicenseUsed"]." WHERE unique_id = '".$updateData["uniqueId"]."'";
        // $sqlQuery = "SELECT * FROM dss_license_master ORDER BY dss_master_id DESC limit 1";
        $resultSet = $appObj->returnQueryData($sqlQuery); 
        return $resultSet;
    }
				
 }