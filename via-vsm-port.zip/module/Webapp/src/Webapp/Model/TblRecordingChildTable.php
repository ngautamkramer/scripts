<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

class TblRecordingChildTable {
	protected $tableGateway;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}

	public function deleteRecordingChild($recordingId) {
		$recordingId = (int) $recordingId;
		$result = $this->tableGateway->delete(array('rmaster' => $recordingId));
		return $result;
	}

	public function fetchRecordingChild($recordingId) {
		$recordingId = (int) $recordingId;
		$rowset = $this->tableGateway->select(array('rmaster' =>$recordingId));
		$row = $rowset->current();
		if(!$row) {
			throw new \Exception("Could not find row");
		}
		return $row;
	}
}
