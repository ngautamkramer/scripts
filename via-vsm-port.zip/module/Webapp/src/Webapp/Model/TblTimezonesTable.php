<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblTimezonesTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

		public function fetchAll($type){			
			$select = $this->tableGateway->getSql()->select();
			$select->columns(array('*'));
			if(PRODUCT=="vsm"){
				$select->where(array('osType' =>$type));
			}	
			$select->order('tz_id ASC');
			$selectAll = $this->tableGateway->selectWith($select);
				foreach($selectAll as $timezoneKey => $timezone){
				   $result[$timezoneKey]['tz_id'] =  $timezone->tz_id;
				   $result[$timezoneKey]['tz_name'] =  $timezone->tz_name;
				   $result[$timezoneKey]['tz_active_status'] =  $timezone->tz_active_status;
				}					
			return $result;	
		}

	
       public function getActiveTimeZone($type) { 
            $select = $this->tableGateway->select();
            if(PRODUCT=="vsm"){
				$select->where(array('osType' => $type, 'tz_active_status' => 1));
			}else{
				$select->where(array('tz_active_status' => 1));
			}
			$resultSet = $this->tableGateway->selectWith($select);
            foreach($resultSet as $timezoneKey => $timezone){
               $result[$timezoneKey]['tz_id'] = $timezone->tz_id;
               $result[$timezoneKey]['tz_name'] = $timezone->tz_name;
               $result[$timezoneKey]['tz_active_status'] = $timezone->tz_active_status;
            }
            return $result;
        }
	
 }