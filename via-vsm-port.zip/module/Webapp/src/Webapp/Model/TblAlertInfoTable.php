<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblAlertInfoTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

        public function fetchAll()
        {
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('id', 'min_threshold_value', 'max_threshold_value', 'description', 'start_date','end_date','alertid_fk','userid_fk'));
            $select->join('tbl_alert_parameter', 'tbl_alert_parameter.id = tbl_alert_info.alertid_fk', array('alert_name'), 'inner')
            ->join('appuserlist','appuserlist.appuserid=tbl_alert_info.userid_fk',array('apploginname'),'left');
            $select->where(array('tbl_alert_parameter.id NOT IN(1)'));
            $select->order('id');
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
            $resultSet = $statement->execute();
		    return $resultSet;

        }

        public function delete($id)
        {
            $this->tableGateway->delete(array('id' => (int) $id));
        }
        public function insertAlert($getLoggedInUserId,$alert_ids,$minthresholdValue,$descValue,$startDateValue,$endDateValue)
        {
            $data = array(
                'userid_fk' => $getLoggedInUserId,
                'entrytype'  =>1,
                'alertid_fk'  => $alert_ids,
                'min_threshold_value'=>$minthresholdValue,
                'description'=>$descValue,
                'start_date'=>$startDateValue,
                'end_date'=>$endDateValue,
                'max_threshold_value'=>100
                
            );		 
            $this->tableGateway->insert($data);

        }

        public function updateAlert($minthresholdValue,$descValue,$startDateValue,$endDateValue,$aID)
        {
            $data = array(
                'min_threshold_value' => $minthresholdValue,
                'description'=>$descValue,
                'start_date'=>$startDateValue,
                'end_date'=>$endDateValue,
                'max_threshold_value'=>100
            );

            $this->tableGateway->update($data,array('id' => $aID));
        }

        public function getAlertById($id)
        {
            $alertId  = (int) $id;			
            $resultSet = $this->tableGateway->select(array('id' => $alertId));
            $row = $resultSet->current();
		    return $row;
        }
    }