<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
 class TblCampaignListTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }      

        public function insertCampaign($data) {
            $appObj = new ApplicationController();  
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Create Campaign','Campaign Name: '. $data['cname']);
            }else{
                $appObj->ActivityLogVSM(3,'Campaign Name: '. $data['cname'],20);
            }
            $this->tableGateway->insert($data);
            //return $lastInsertid = $this->tableGateway->lastInsertValue;
            // for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('campaignlist_cid_seq');
        } 

        public function updateCampaign($whereCondition, $userData) {
            $appObj = new ApplicationController();  
            if($userData['cname']) {
                if (PRODUCT=='via') {
                    $appObj->ActivityLog('Update Campaign', 'Campaign Name: '. $userData['cname']);
                }else{
                    $appObj->ActivityLogVSM(4, 'Campaign Name: '. $userData['cname'],20);
                }
            }
            $result = $this->tableGateway->update($userData, $whereCondition);
            return $result;
        }

        public function getAllCampaign() {
            $appObj = new ApplicationController();  
            //$sqlQuery = "SELECT * FROM campaignlist ORDER BY createdate DESC";
            $sqlQuery = "SELECT * FROM campaignlist cl 
                LEFT JOIN playlist_schedule_master psm 
                    ON psm.cid = cl.cid 
                ORDER BY cl.cid DESC";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }

        public function getCampaigns() {
            $appObj = new ApplicationController();  
            $sqlQuery = "SELECT cl.*, psm.cid as pcid FROM campaignlist cl 
                LEFT JOIN (SELECT DISTINCT(p1.cid) FROM playlist_schedule_master p1) psm 
                    ON (psm.cid = cl.cid) ORDER BY cl.cid DESC";            
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;
        }
		//Modified by ashu on 18Aug2022 to change this function according to zend
        public function getCampaignDetail($userData) {
            $campaignId = $userData["campaignId"];
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('cid as ccid', 'filename', 'cname'));
			$sqlSelect->join('playlist_schedule_master', 'playlist_schedule_master.cid = campaignlist.cid', array('*'), 'LEFT');
			$sqlSelect->where(array("campaignlist.cid" => $campaignId));
			$sqlSelect->limit(1);
			// echo $sql->getSqlstringForSqlObject($sqlSelect); die ;			
			$statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
		    $resultSet = $statement->execute();
            return $resultSet; 
        }

        public function campaignDelete($userData) {
            $campaignId = $userData["campaignId"];
            $appObj = new ApplicationController();
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');  
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Delete','Delete Campaign by'.' '.$name);
            }else{
                $appObj->ActivityLogVSM(5,'Delete Campaign by'.' '.$name,20);
            }
            $sqlQuery = "DELETE FROM campaignlist WHERE cid = '". $campaignId ."'";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
        }

		//Modified by ashu on 18Aug2022 to change this function according to zend
        public function checkCampaignUniqueName($data) {
			$sql = $this->tableGateway->getSql();
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('cid'));
			if($data["cid"]){
				//$sqlSelect->where(array("cname" => $data["cname"],"cid!= ".$data["cid"].""  ));
                $sqlSelect->where(array("cid!= ".$data["cid"].""));
                $sqlSelect->where->expression("cname ILIKE ?",  $data["cname"]);
			}else{
				//$sqlSelect->where(array("cname" => $data["cname"]));
                $sqlSelect->where->expression("cname ILIKE ?",  $data["cname"]);
			}
			//echo $sql->getSqlstringForSqlObject($sqlSelect); die ;
			$sql->getSqlstringForSqlObject($sqlSelect); 	
			$resultSet = $this->tableGateway->selectWith($sqlSelect);		
            return $resultSet; 
        }

        public function campaignStatus($userData) {
            $campaignId = $userData["campaignId"];
            $appObj = new ApplicationController();             
            $sqlQuery = "SELECT COUNT(*) as cnt FROM playlist_schedule_master WHERE CID = '".$campaignId."'";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
            return $resultSet; 
        }
 }