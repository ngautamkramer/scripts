<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblEmergencyAlertExecute
 {
    public $id;
    public $emergency_alert_id_fk;
    public $user_id_fk;
    public $group_id_fk;
    public $device_id_fk;
    public $start_datetime;
    public $end_datetime;
    public $status;
 
 public function exchangeArray($data)
 {
      $this->id= (isset($data['id']))? $data['id']: null;
      $this->emergency_alert_id_fk= (isset($data['emergency_alert_id_fk']))? $data['emergency_alert_id_fk']: null;
      $this->user_id_fk= (isset($data['user_id_fk']))? $data['user_id_fk']: null;
      $this->group_id_fk= (isset($data['group_id_fk']))? $data['group_id_fk']: null;
      $this->device_id_fk= (isset($data['device_id_fk']))? $data['device_id_fk']: null;
      $this->start_datetime= (isset($data['start_datetime']))? $data['start_datetime']: null;
      $this->end_datetime= (isset($data['end_datetime']))? $data['end_datetime']: null;
      $this->status= (isset($data['status']))? $data['status']: null;
 }
 
 public function getArrayCopy()
 {
 return get_object_vars($this);
 }
 }