<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblAlertMappingTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }

        public function delete($id)
        {
            $this->tableGateway->delete(array('alert_id_fk' => (int) $id));
        }

        public function countAlert($id)
        {
           $select = $this->tableGateway->getSql()->select();
           $select->columns(array('num' => new \Zend\Db\Sql\Expression('COUNT(*)')));
           $value=$select->where(array('alert_id_fk'=> (int)$id));
           $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
           $resultSet = $statement->execute();
           return  $resultSet;

        }

        public function showAlertById($alertId,$getRow){
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('apploginname' => new \Zend\Db\Sql\Expression('DISTINCT appuserlist.apploginname')));
            $select->join('appuserlist', 'appuserlist.appuserid = tbl_alert_mapping.user_id_fk', array('appuserid','email'), 'left')
            ->join('DeviceInventory','DeviceInventory.DID=tbl_alert_mapping.device_id_fk',array('*'),'inner');
            $select->where(array('tbl_alert_mapping.alert_id_fk'=>$alertId,"DeviceInventory.DeviceGroupID IN ($getRow)"));
            //echo $select->getSqlString();
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
            $resultSet = $statement->execute();
            return  $resultSet;
        }

        public function showAlert($alertId,$getRow){
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('DeviceName' => new \Zend\Db\Sql\Expression('DISTINCT DeviceInventory.DeviceName')));
            $select->join('DeviceInventory', 'DeviceInventory.DID = tbl_alert_mapping.device_id_fk', array('DID','DeviceIP','DeviceGroupID'), 'left');
            $select->where(array('tbl_alert_mapping.alert_id_fk'=>$alertId,"DeviceInventory.DeviceGroupID IN ($getRow)"));
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
            $resultSet = $statement->execute();
            return  $resultSet;

        }

        public function showUserListByAlertId($alertId){
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('apploginname' => new \Zend\Db\Sql\Expression('DISTINCT appuserlist.apploginname')));
            $select->join('appuserlist', 'appuserlist.appuserid = tbl_alert_mapping.user_id_fk', array('appuserid','email'), 'left');
            $select->where(array('tbl_alert_mapping.alert_id_fk'=>$alertId));
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
            $resultSet = $statement->execute();
            return  $resultSet;

        }

        public function showGatewayAlertId($alertId){
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('DeviceName' => new \Zend\Db\Sql\Expression('DISTINCT DeviceInventory.DeviceName')));
            $select->join('DeviceInventory', 'DeviceInventory.DID = tbl_alert_mapping.device_id_fk', array('DID','DeviceIP','DeviceGroupID'), 'left');
            $select->where(array('tbl_alert_mapping.alert_id_fk'=>$alertId));
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
            $resultSet = $statement->execute();
            return  $resultSet;
        }
    }