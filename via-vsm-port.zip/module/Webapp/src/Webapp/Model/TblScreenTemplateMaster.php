<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblScreenTemplateMaster implements InputFilterAwareInterface
{
    public $screentemplateid;
    public $screentemplatename;
    public $audioframeid;
    public $active;
    public $aspectratio;
    public $framecount; 
    public $backgroundcolor; 
    public $defaultimage; 
    public $originalimage;
    public $appname;
    public $username;
    public $hostname;
    public $modifydate;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->screentemplateid = (isset($data['screentemplateid']))? $data['screentemplateid']: null;
        $this->screentemplatename = (isset($data['screentemplatename']))? $data['screentemplatename']: null;
        $this->audioframeid = (isset($data['audioframeid'])) ? $data['audioframeid'] : null;
        $this->active  = (isset($data['active']))  ? $data['active']  : null;
        $this->aspectratio  = (isset($data['aspectratio']))  ? $data['aspectratio']  : null;
        $this->framecount  = (isset($data['framecount']))  ? $data['framecount']  : null;  
        $this->backgroundcolor  = (isset($data['backgroundcolor']))  ? $data['backgroundcolor']  : null;   
        $this->defaultimage  = (isset($data['defaultimage']))  ? $data['defaultimage']  : null; 
        $this->originalimage  = (isset($data['originalimage']))  ? $data['originalimage']  : null; 
        $this->appname  = (isset($data['appname']))  ? $data['appname']  : null;  
        $this->username  = (isset($data['username']))  ? $data['username']  : null;  
        $this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null;  
        $this->modifydate  = (isset($data['modifydate']))  ? $data['modifydate']  : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
