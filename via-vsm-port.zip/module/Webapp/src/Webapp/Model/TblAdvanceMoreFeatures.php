<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblAdvanceMoreFeatures 
 {
	  public $id;
	  public $property_name;
      public $ivalue;
      public $strvalue;
	  public $modifydatetime;
 
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		$this->property_name= (isset($data['property_name']))? $data['property_name']: null;
		$this->ivalue= (isset($data['ivalue']))? $data['ivalue']: null;
		$this->strvalue= (isset($data['strvalue']))? $data['strvalue']: null;
		$this->modifydatetime= (isset($data['modifydatetime']))? $data['modifydatetime']: null;
	}
	
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}
 }