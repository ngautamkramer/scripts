<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblRecordingTransferTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function fetchTransferOption(){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->columns(array('transfer_option'));
            $resultSet = $this->tableGateway->selectWith($sqlSelect);
            if($resultSet->count()>0){
                foreach($resultSet as $feature){
                    $result =  $feature->transfer_option;
                 }
            }
            return $result;
        }
        public function updateRecording($data){
            $this->tableGateway->update($data);  
        }
	
 }