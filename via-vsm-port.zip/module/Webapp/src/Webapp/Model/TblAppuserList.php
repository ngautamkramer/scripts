<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

 class TblAppuserList implements InputFilterAwareInterface
 {
     public $appuserid;
	 public $apploginname;
	 public $email;
     public $password;
     public $changepassword;
	 public $active;
	 public $modifydate; 
	 public $hostname;	 
	 public $name;	
	 public $remarks;	
     protected $inputFilter;                       // <-- Add this variable

     public function exchangeArray($data)
     {
	 	 $this->appuserid= (isset($data['appuserid']))? $data['appuserid']: null;
         $this->apploginname= (isset($data['apploginname']))? $data['apploginname']: null;
         $this->email= (isset($data['email']))? $data['email']: null;
         $this->password = (isset($data['password'])) ? $data['password'] : null;
         $this->changepassword  = (isset($data['changepassword']))  ? $data['changepassword']  : null;
		 $this->active  = (isset($data['active']))  ? $data['active']  : null;
		 $this->modifydate  = (isset($data['modifydate']))  ? $data['modifydate']  : null;
		 $this->hostname  = (isset($data['hostname']))  ? $data['hostname']  : null;
		 $this->name  = (isset($data['name']))  ? $data['name']  : null;
		 $this->remarks  = (isset($data['remarks']))  ? $data['remarks']  : null;
		 
		 
		 
     }
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }

     public function getInputFilter()
     {
         if (!$this->inputFilter) {
             $inputFilter = new InputFilter();
             $inputFilter->add(array(
                 'name'     => 'login_name',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $inputFilter->add(array(
                 'name'     => 'login_password',
                 'required' => false,
                 'filters'  => array(
                     array('name' => 'StripTags'),
                     array('name' => 'StringTrim'),
                 ),
                 'validators' => array(
                     array(
                         'name'    => 'StringLength',
                         'options' => array(
                             'encoding' => 'UTF-8',
                             'min'      => 4,
                             'max'      => 100,
                         ),
                     ),
                 ),
             ));

             $this->inputFilter = $inputFilter;
         }

         return $this->inputFilter;
     }
	 
 }
