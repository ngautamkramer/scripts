<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblViaSettingsTemplatesMappingTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function fetchAll() { 
            $resultSet = $this->tableGateway->select();
            foreach($resultSet as $fetchConfigData){
                $result['activateRoomOverlay']=$fetchConfigData->activateRoomOverlay;
                $result['RoomOverlayValue']=$fetchConfigData->RoomOverlayValue;
                $result['twentyfourHoursFormat']=$fetchConfigData->twentyfourHoursFormat;
            }
            return $result;
        }
        
        
	
 }