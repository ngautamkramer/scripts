<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblFeatureConfigSetting implements InputFilterAwareInterface
{
    public $id;
    public $feature_name;
    public $feature_data;
    public $feature_dateTime;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->feature_name= (isset($data['feature_name']))? $data['feature_name']: null;
        $this->feature_data = (isset($data['feature_data'])) ? $data['feature_data'] : null;
        $this->feature_dateTime = (isset($data['feature_dateTime'])) ? $data['feature_dateTime'] : null;
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
