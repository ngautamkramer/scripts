<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

 class TblUserAccess implements InputFilterAwareInterface
 {
     public $id;
	 public $module_id_fk;
     public $menu_id_fk;
     public $access_id_fk;
	 public $user_id_fk;
	 public $group_id_fk; 	
     protected $inputFilter;

     public function exchangeArray($data)
     {
	 	 $this->id= (isset($data['id']))? $data['id']: null;
         $this->module_id_fk= (isset($data['module_id_fk']))? $data['module_id_fk']: null;
         $this->menu_id_fk = (isset($data['menu_id_fk'])) ? $data['menu_id_fk'] : null;
         $this->access_id_fk  = (isset($data['access_id_fk']))  ? $data['access_id_fk']  : null;
		 $this->user_id_fk  = (isset($data['user_id_fk']))  ? $data['user_id_fk']  : null;
		 $this->group_id_fk  = (isset($data['group_id_fk']))  ? $data['group_id_fk']  : null; 
     }
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }
	   public function getInputFilter()
     {
         return $this->inputFilter;
     }

	 
 }
