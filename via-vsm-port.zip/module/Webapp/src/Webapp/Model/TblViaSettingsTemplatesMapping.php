<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblViaSettingsTemplatesMapping implements InputFilterAwareInterface
{
    public $id;
    public $template_id;
    //public $status;
    public $isGrpIdOrDeviceId;
    public $entryType;   
	public $modifydatetime;   
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->id= (isset($data['id']))? $data['id']: null;
        $this->template_id= (isset($data['template_id']))? $data['template_id']: null;
        //$this->status = (isset($data['status'])) ? $data['status'] : null;
        $this->isGrpIdOrDeviceId  = (isset($data['isGrpIdOrDeviceId']))  ? $data['isGrpIdOrDeviceId']  : null;
		$this->entryType  = (isset($data['entryType']))  ? $data['entryType']  : null;		
		$this->modifydatetime  = (isset($data['modifydatetime']))  ? $data['modifydatetime']  : null;
        
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
