<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblGatewayCustomizeHomepageTable
 {
	   protected $tableGateway;
	   public function __construct(TableGateway $tableGateway) {
                $this->tableGateway = $tableGateway;
           }
           
            public function truncateTable() { 
                $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
                $query->execute();
            }
                
            public function insertTable($updateArr){
                $this->tableGateway->insert($updateArr);
            }
                
               
 }


