<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Webapp\Controller\ApplicationController;
use Zend\Session\Container;
 class TblDssInfoTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }      

        public function inserDataForDssLicense($userData) {  
            $dssLicensFileName = $userData['licenseFileName'];
            $dateTimeStamp = $userData['dateTimeStamp'];   
            $pollEncryptionKey = POLL_ENCRPTION_KEY;
            $appObj = new ApplicationController();
            $sqlTruncate = "TRUNCATE TABLE dss_info RESTART IDENTITY";
            $appObj->executeQueries($sqlTruncate);
            //$sqlQuery = "INSERT INTO dss_info SET filename = '$dssLicensFileName', datetime = AES_ENCRYPT('$dateTimeStamp', '$pollEncryptionKey')";
            $sqlQuery = "INSERT INTO dss_info(filename, datetime) VALUES('$dssLicensFileName', encrypt('$dateTimeStamp','$pollEncryptionKey','aes'))";
            $appObj->executeQueries($sqlQuery);
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Upload','Dss License'); 
            }else{
                $appObj->ActivityLogVSM(6,'Dss License',22); 
            }        
                         
        }

        public function getDataForDssLicense() {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRPTION_KEY;
            $sqlQuery = "SELECT id, filename, convert_from(decrypt(datetime,'$pollEncryptionKey','aes'),'utf-8') as licenseDate FROM dss_info ORDER BY id DESC limit 1";
            $resultSet = $appObj->returnQueryData($sqlQuery);  
            return $resultSet;                      
        }

        public function updateDataForDssLicense($userData) {
            $dssLicensFileName = $userData['licenseFileName'];
            $dateTimeStamp = $userData['dateTimeStamp'];   
            $pollEncryptionKey = POLL_ENCRPTION_KEY;
            $appObj = new ApplicationController();                        
            $sqlQuery = "UPDATE dss_info SET filename = '$dssLicensFileName', datetime = AES_ENCRYPT('$dateTimeStamp', '$pollEncryptionKey') WHERE id = 1";
            $appObj->executeQueries($sqlQuery);
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');
            if(PRODUCT=='via'){
                $appObj->ActivityLog('Update','Dss License');
            }else{
                $appObj->ActivityLogVSM(4,'Dss License',22);
            }
                    
        }

        public function checkDssLicenseValidity() {
            $licenedStatus = 'notfound';
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRPTION_KEY;
            $sqlQuery = "SELECT id, filename, convert_from(decrypt(datetime,'$pollEncryptionKey','aes'),'utf-8') as licenseDate FROM dss_info ORDER BY id DESC limit 1";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
            foreach($resultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);    
                $licenseDate = $resultSet['licensedate'];
                if($licenseDate != 'FULL') {
                    if($licenseDate < time()) {
                        $licenedStatus = 'expired'; 
                    } else {
                        $licenedStatus = 'FULL';
                    }
                } else {
                    $licenedStatus = 'FULL';
                }
            } 
            return  $licenedStatus;
        }

        function getDataForDssLicenseVsmList() {
            $licenedStatus = 'notfound';
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $sqlQuery = "SELECT di.DeviceName, expiry_date as licenseDate 
                    FROM dss_file_auth as dfa 
                INNER JOIN DeviceInventory as di ON dfa.DID = di.DID";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
            return $resultSet;
        }


        function getDataForDssLicenseVsm() {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            // $sqlQuery = "SELECT AES_DECRYPT(datetime, '$pollEncryptionKey') as licenseDate FROM dss_file_auth WHERE (AES_DECRYPT(datetime,'$pollEncryptionKey') > extract(epoch FROM NOW()) || AES_DECRYPT(datetime, '$pollEncryptionKey') = 'FULL')";
            // This first check for any free gateway is attached to the VSM if yes the send full status if no the check same as early.
            $response = "Expired";
            if(count($this->getAllFreeLicenceDeveiceId()) > 0) {
                $response = "FULL";
            } else {
                $sqlQuery = "SELECT expiry_date as licenseDate FROM dss_file_auth WHERE expiry_date > CURDATE()";
                $selectResultSet = $appObj->returnQueryData($sqlQuery);
                $result = array();
                foreach($selectResultSet as $row) {
                    $resultSetJson = json_encode($row); 
                    $resultSet = json_decode($resultSetJson, true); 
                    if($resultSet["licenseDate"] == "FULL") {
                        $result[] = $resultSet;
                    } else {
                        if($resultSet["licenseDate"] > date("Y-m-d")) {
                           $result[] = $resultSet;
                        } 
                    }
                }
                if(count($result) > 0) {
                    $response = "FULL";
                }
            }
            return $response; 
            
            // $sqlQuery = "SELECT di.DeviceName, AES_DECRYPT(datetime, '$pollEncryptionKey') as licenseDate 
            //         FROM dss_file_auth as dfa 
            //     INNER JOIN deviceinventory as di ON dfa.DID = di.DeviceID";
            // $resultSetValue = $appObj->returnQueryData($sqlQuery); 

            // foreach( $resultSetValue as $row) {
            //     $resultSetJson = json_encode($row); 
            //     $resultSet = json_decode($resultSetJson, true);   
            //     if($resultSet["licenseDate"] == "FULL") {
            //         $result[] = $resultSet;
            //     } else {
            //         if($resultSet["licenseDate"] > time()) {
            //            $result[] = $resultSet;
            //         } 
            //     }
            // }
            // return $result;
        }

        function getMacAddressForLicense() {
            $appObj = new ApplicationController();
            $sqlQuery = "SELECT DID_FK, field1, DeviceName FROM tbl_device_dnsname as tdd 
                    INNER JOIN DeviceInventory ON DID = DID_FK
                WHERE field1 != ''";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);

            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
                $macAddress[] = array("macAddress"=> $resultSet["field1"] ,"gatewayName" => $resultSet["DeviceName"], "deviceId" => $resultSet["DID_FK"]);
            } 
            return $macAddress;
        }


        function getMacAddressForLicenseAtUplaod() {
            $appObj = new ApplicationController();
            $sqlQuery = "SELECT DID_FK, field1, DeviceName FROM tbl_device_dnsname as tdd 
                    INNER JOIN DeviceInventory ON DID = DID_FK
                WHERE field1 != ''";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);

            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
                $macAddress[] = array("macAddress"=> $resultSet["field1"] ,"gatewayName" => $resultSet["DeviceName"], "deviceId" => $resultSet["DID_FK"]);
            } 
            return $macAddress;
        }

        public function getDeviceNameById($did) {
            $appObj = new ApplicationController();
            $sqlQuery = "SELECT DeviceName FROM DeviceInventory WHERE DID = ".$did."";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
                $gatewayName = $resultSet["DeviceName"];
            } 
            return $gatewayName;
        }

        public function isInitialLicenseUpload() {
            $appObj = new ApplicationController();
            $sqlQuery = "SELECT count(*) AS licenseCount FROM dss_file_auth";           
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
            } 
            $response = $resultSet["licenseCount"] == 0 ? "true" : "false"; 
            return $response;
        }

        public function getAllActiveLicensedDevices() {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $sqlQuery = "SELECT * FROM dss_file_auth WHERE expiry_date > CURDATE()";           
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        public function getDssActiveLicenseCount($searchFilter) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $uniqueId = is_array($searchFilter) ? $searchFilter["uniqueId"] : "";
            $searchWhere = "";
            if($uniqueId) {
                $searchWhere = " AND unique_id = '".$uniqueId."'";
            }
            $sqlQuery = "SELECT count(*) AS licenseCount FROM dss_file_auth WHERE expiry_date > CURDATE()". $searchWhere;
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        public function getDssActiveLicenseData($searchFilter) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $uniqueId = is_array($searchFilter) ? $searchFilter["uniqueId"] : "";
            $searchWhere = "";
            if($uniqueId) {
                $searchWhere = " WHERE dfa.unique_id = '".$uniqueId."'";
            }
            $sqlQuery = "SELECT dfa.id, dfa.did, dfa.gateway_name, dfa.expiry_date as licenseDate, dlm.purchase_date 
                FROM dss_file_auth as dfa                 
                    INNER JOIN dss_license_master as dlm ON dfa.unique_id = dlm.unique_id  $searchWhere";
                    // WHERE (dfa.expiry_date >= CURDATE() || dfa.expiry_date = 'FULL') $searchWhere"; 
                
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }


        function checkDataVsmLicenseUploaded($did) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $sqlQuery = "SELECT dfa.id, dfa.did, dlm.unique_id, dfa.expiry_date, DATEDIFF(dfa.expiry_date, CURDATE()) AS exipryDaysLeft FROM dss_file_auth as dfa 
                    INNER JOIN dss_license_master as dlm ON dfa.unique_id = dlm.unique_id
                WHERE DID = $did AND dfa.expiry_date >= CURDATE()";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        function checkDataVsmLicense($did) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $sqlQuery = "SELECT dfa.id, dlm.unique_id, DATEDIFF(CURDATE(), dfa.expiry_date) AS exipryDaysLeft FROM dss_file_auth as dfa 
                    INNER JOIN dss_license_master as dlm ON dfa.unique_id = dlm.unique_id
                WHERE DID = $did AND dfa.expiry_date <= CURDATE()";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        function insertDataDssFileAuth($userData) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $sqlQuery =  "INSERT INTO dss_file_auth SET DID = '".$userData["did"]."', issued_date = '".$userData["purchaseDate"]."', gateway_name = '".$userData["gatewayName"]."', unique_id = '".$userData["uniqueId"]."', expiry_date = '".$userData["dateTimeStamp"]."'";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        function updateDataDssFileAuth($userData) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            echo $sqlQuery = "UPDATE dss_file_auth SET expiry_date = '".$userData["dateTimeStamp"]."' WHERE DID =  '".$userData["did"]."'";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

         function updateDataDssFileAuthById($userData) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            echo $sqlQuery = "UPDATE dss_file_auth SET expiry_date = '".$userData["dateTimeStamp"]."' WHERE id =  '".$userData["id"]."'";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        public function updateDssMasterExpiryDate($data) {
            $appObj = new ApplicationController();
            foreach($data as $key => $value ) {
                $sqlQuery = "UPDATE dss_license_master SET expiry_date = '".$value."' WHERE unique_id =  '".$key."'";
                $selectResultSet = $appObj->returnQueryData($sqlQuery);    
            }   
        }

        function insertDssFileInfo($userData) {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            $sqlQuery = "INSERT INTO dss_file_info SET filename = '".$userData["fileName"]."', datetime = AES_ENCRYPT('".$userData["dateTimeStamp"]."', '$pollEncryptionKey')";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        public function getAllDssFileAuthDeviceId() {
            $appObj = new ApplicationController();
            $sqlQuery = "SELECT DID FROM dss_file_auth";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
            $allDeviceId = array();
            foreach($resultSet as $row) {
                $resultSetJson = json_encode($row); 
                $result = json_decode($resultSetJson, true);
                $allDeviceId[] = $result["DID"];
            }
            return $allDeviceId;
        }

        function getAllDataDssFileAuth($deviceIds) {
            $appObj = new ApplicationController();;
            $sqlQuery = "SELECT * FROM dss_file_auth WHERE DID IN ($deviceIds) AND expiry_date > CURRENT_DATE()";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            return $selectResultSet;
        }

        function deleteDeviceRecordForLicense($deviceIds) {
            $appObj = new ApplicationController();
            $sqlQuery = "DELETE FROM dss_file_auth WHERE DID IN ($deviceIds)";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
        }

        function getDeviceModelValue($did) { 
            $appObj = new ApplicationController();   
            $sqlQuery = "SELECT model_value FROM tbl_device_extra_info WHERE deviceID_Fk = ".$did."";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
            } 
            $response = $resultSet["model_value"]; 
            return $response;
        }

        function checkFreeLicenseDevice($did) { 
            $appObj = new ApplicationController();   
            $sqlQuery = "SELECT  count(*) AS freeLicense FROM tbl_device_extra_info WHERE deviceID_Fk = ".$did." AND (model_value = 12 || model_value = 11)";
            $selectResultSet = $appObj->returnQueryData($sqlQuery);
            foreach($selectResultSet as $resultSetValue) {
                $resultSetJson = json_encode($resultSetValue); 
                $resultSet = json_decode($resultSetJson, true);
            } 
            $response = $resultSet["freeLicense"] == 1 ? true : false; 
            return $response;
        }   

        public function getAllFreeLicenceDeveiceId() {
            $appObj = new ApplicationController();
            $allDeviceId = $this->getAllDssFileAuthDeviceId();             
            $sqlQuery = "SELECT di.DID, tdei.model_value, di.DeviceName
                FROM DeviceInventory as di 
                    INNER JOIN tbl_device_extra_info as tdei ON tdei.deviceID_Fk = di.DID 
                WHERE (tdei.model_value = 12 || tdei.model_value = 11)";
            $resultSet = $appObj->returnQueryData($sqlQuery); 
            $deviceInfo = array();            
            foreach($resultSet as $row) {                
                $resultSetJson = json_encode($row); 
                $result = json_decode($resultSetJson, true);                                
                if(!in_array($result["DID"], $allDeviceId)) {   
                    $deviceInfo[] = array("deviceId" => $result["DID"], "deviceName" => $result["DeviceName"]);    
                }
            }
            return $deviceInfo;
        }

        public function insertDataInDssAuthForViaGoTwo() {
            $appObj = new ApplicationController();
            $encryptionKey = POLL_ENCRPTION_KEY;
            $allFreeDeviceIdsNotAdded =  $this->getAllFreeLicenceDeveiceId();
            $numOfDevices = count($allFreeDeviceIdsNotAdded);
            if($numOfDevices > 0) { 
                $validityMonths = 36;
                $orderId = date('ymdhis');
                $issueDate = date('Y-m-d');
                $expiryDate = date('Y-m-d', strtotime('+'. $validityMonths .'months'));
                $uniqueId = $appObj->getUniqueRandomNumber(5);                
                $sqlQueryMaster = "INSERT INTO dss_license_master (unique_id, order_id, num_of_devices, purchase_date, validity_months, expiry_date, num_of_lic_used) VALUES ('$uniqueId', AES_ENCRYPT('$orderId', '$encryptionKey'), '$numOfDevices', '$issueDate', '$validityMonths', '$expiryDate', '$numOfDevices')";
                $appObj->returnQueryData($sqlQueryMaster);    
                foreach($allFreeDeviceIdsNotAdded as $key => $value) {                
                    $sqlQuery = "INSERT INTO dss_file_auth SET DID = '".$value["deviceId"]."', expiry_date = '".$expiryDate."', unique_id = '".$uniqueId."', issued_date = '".$issueDate."', gateway_name = '".$value["deviceName"]."'";                    
                    $selectResultSet = $appObj->returnQueryData($sqlQuery);                
                }
            }
        }

        public function getDeviceIdByIdDssFileAuth($id) {
            $appObj = new ApplicationController();
            $sql = "SELECT DID from dss_file_auth WHERE id = ".$id."";
            $result = $appObj->returnQueryData($sql); 
            foreach($result as $row) {
                $resultSetJson = json_encode($row); 
                $response = json_decode($resultSetJson, true);
            }
            return $response["DID"];
        }

        public function deleteDssActiveLicenseData($whereCondition) {  
            $appObj = new ApplicationController();
            $sqlOne = "SELECT DID from dss_file_auth WHERE id = ".$whereCondition["id"]."";
            $resultDataOne = $appObj->returnQueryData($sqlOne); 
            foreach($resultDataOne as $row) {
                $resultSetJson = json_encode($row); 
                $resultOne = json_decode($resultSetJson, true);
            }
            $sqlTwo = "SELECT id, unique_id from dss_file_auth WHERE DID = ".$resultOne["DID"]." AND expiry_date >= CURDATE()";
            $resultDataTwo = $appObj->returnQueryData($sqlTwo); 
            foreach($resultDataTwo as $row) {
                $resultSetJson = json_encode($row); 
                $resultTwo = json_decode($resultSetJson, true);   
                $dataDeleted[$resultTwo["id"]] =  $resultTwo["unique_id"];
            }

            foreach($dataDeleted as $key => $value) {
               $sqlQuery = "DELETE FROM dss_file_auth WHERE id = ".$key."";
               $resultSet = $appObj->returnQueryData($sqlQuery); 
            }
            return $dataDeleted;
        }

        public function getProxyServerSettings() {
            $appObj = new ApplicationController();
            $pollEncryptionKey = POLL_ENCRYPTION_KEY;
            // $sqlQuery = "UPDATE tbl_proxy_setting SET password = AES_ENCRYPT('123456', '$pollEncryptionKey') WHERE id = 3";
                    // $selectResultSet = $appObj->returnQueryData($sqlQuery);exit;
            $sqlOne = "SELECT *, convert_from(decrypt(password,'".POLL_ENCRYPTION_KEY."','aes'),'utf-8') as password from tbl_proxy_setting";
            $resultDataOne = $appObj->returnQueryData($sqlOne); 
            foreach($resultDataOne as $row) {
                $resultSetJson = json_encode($row); 
                $resultOne = json_decode($resultSetJson, true);
            }
            return $resultOne;
        }
    
 }