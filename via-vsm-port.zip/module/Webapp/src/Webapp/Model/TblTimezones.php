<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblTimezones implements InputFilterAwareInterface
{
    public $tz_id;
    public $tz_name;
    public $tz_active_status;
    
    protected $inputFilter;    // Add this variable

    public function exchangeArray($data){
        $this->tz_id= (isset($data['tz_id']))? $data['tz_id']: null;
        $this->tz_name= (isset($data['tz_name']))? $data['tz_name']: null;
        $this->tz_active_status = (isset($data['tz_active_status'])) ? $data['tz_active_status'] : null;  
    }
    
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
	 
}
