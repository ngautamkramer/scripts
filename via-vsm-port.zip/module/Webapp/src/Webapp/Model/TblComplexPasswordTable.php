<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblComplexPasswordTable
 {
	    protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		public function fetchComplexPassword(){
			  $select = $this->tableGateway->getSql()->select();
			  $select->columns(array('*'));	
			  $select->order('id DESC');
			  $select->limit(1);
			  $resultSet = $this->tableGateway->selectWith($select);
			  return  $resultSet ;
		}
                
        public function updatePasswordPolicy($updateArr){
            $this->tableGateway->update($updateArr);
        }
 }