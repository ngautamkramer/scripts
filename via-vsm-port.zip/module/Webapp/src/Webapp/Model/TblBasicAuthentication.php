<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblBasicAuthentication 
 {
	  public $SrNo;
	  public $password;
	  protected $inputFilter;   
 
   public function exchangeArray($data)
	{
		 $this->SrNo= (isset($data['SrNo']))? $data['SrNo']: null;
		 $this->password= (isset($data['password']))? $data['password']: null;
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }