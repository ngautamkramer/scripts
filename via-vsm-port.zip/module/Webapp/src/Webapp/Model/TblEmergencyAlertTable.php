<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblEmergencyAlertTable
 {
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }

    public function fetchInstantList()
    {
        $select = $this->tableGateway->getSql()->select();
        $select->columns(array('id', 'emergency_alert_name'));
        $select->join('appuserlist', 'appuserlist.appuserid = tbl_emergency_alert.userid_fk', array('appuserid'), 'inner');
        $select->order('id');
        $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($select);
        $resultSet = $statement->execute();
        return $resultSet;

    }
     public function insertInstantAlert($name,$lastpicid)
     {
        $data = array(
            'emergency_alert_name' => $name,
            'status'=>1,
            'userid_fk'=>$lastpicid, 
            );		 
        $this->tableGateway->insert($data);

    }

    public function getInstantAlertById($id){
        $id  = (int) $id;			
        $resultSet = $this->tableGateway->select(array('id' => $id));
        $row = $resultSet->current();
        return $row;

    }

    public function deleteInstantAlert($id)
    {
        $this->tableGateway->delete(array('id' => (int) $id));
    }

    public function updateEmergencyAlert($id,$alertName){
        $data=array(
            'emergency_alert_name'=>$alertName
        );
        $this->tableGateway->update($data,array('id'=>$id));
    }
 }