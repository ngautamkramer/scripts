<?php

namespace Webapp\Model; // define namespace for current file

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

/*********
 * @Name   : TblCalendarAccount
 * @Table  : tbl_company_calender_account
 * @Author : Dileep Kumar
 * @Date   : 24 APR 2018
 * ******/
 
class TblCalendarAccount implements InputFilterAwareInterface
{
	public $id;
	public $account_id;
	public $email;
	public $display_name;
	public $account_type;
	public $created_on;
	public $permission_type;
	protected $inputFilter;
	
	// this function is automatically called
	public function exchangeArray($data)
	{
	 $this->id     = (isset($data['id']))     ? $data['id']     : null;
	 $this->account_id = (isset($data['account_id'])) ? $data['account_id'] : null;
	 $this->email = (isset($data['email'])) ? $data['email'] : null;
	 $this->display_name = (isset($data['display_name'])) ? $data['display_name'] : null;
	 $this->account_type = (isset($data['account_type'])) ? $data['account_type'] : null;
	 $this->permission_type = (isset($data['permission_type'])) ? $data['permission_type'] : null;
	 $this->created_on = (isset($data['created_on'])) ? $data['created_on'] : null;
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

	// function of InputFilterAwareInterface interface needed to implement
	public function setInputFilter(InputFilterInterface $inputFilter)
	{
		throw new \Exception("Not used");
	}
	// function of InputFilterAwareInterface interface needed to implement
	// validation for form
	public function getInputFilter()
    {
		
	}
}
?>
