<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblViaSettingsTemplatesTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function fetchAll() { 
            $select = $this->tableGateway->getSql()->select();
            $select->columns(array('*'));
			$select->where(array('model_type'=>PRODUCT_MODEL_TYPE));
            $select->order('id');			
            $resultSet = $this->tableGateway->selectWith($select);
             // create a new pagination adapter object
            $paginatorAdapter = new DbSelect($select,$this->tableGateway->getAdapter());
            $resultSet = new Paginator($paginatorAdapter); 			       
            return $resultSet;		
		
        }
		
        public function insertData($data){
            $this->tableGateway->insert($data);
            /*$insertId = $this->tableGateway->lastInsertValue; 
            return $insertId;*/	
            // for return last inserted id from pgsql
			return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('tbl_via_settings_templates_id_seq');
            
        }
        
		public function checkTemplate($whereArr){
			 $rowset = $this->tableGateway->select($whereArr);
			 return $rowset->count();
		}
			
        public function updateTableData($data,$last_insert_id){ 
		  	//$this->tableGateway->update($data,$whrArray); 
			$this->tableGateway->update($data, array('id' => $last_insert_id));
        }
				
        public function updateData($data,$templateName){ 
		  	$this->tableGateway->update($data, array('template_name' => $templateName)); 
        }
		
        public function deleteData($data){ 
		  	$this->tableGateway->delete($data); 				
        }

        public function getTemplate($whereArr){
             $rowset = $this->tableGateway->select($whereArr);
             return $rowset;
        }

        public function truncateTable(){
            $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable().' RESTART IDENTITY');
            $query->execute();
        }
		// get table data by condition
        public function getData($condition){
            $sqlSelect = $this->tableGateway->getSql()->select();
            $sqlSelect->where($condition);
            $statement = $this->tableGateway->getSql()->prepareStatementForSqlObject($sqlSelect);
            $resultSet = $statement->execute(); 
            return $resultSet;
        }
		
	
 }