<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblCampaignTemplate
{
    public $id;
    public $campaign_id;
    public $modifydate;

    public function exchangeArray($data){
        $this->id = (isset($data['id']))? $data['id']: null;
        $this->campaign_id = (isset($data['campaign_id']))? $data['campaign_id']: null;
        $this->template_id = (isset($data['template_id'])) ? $data['template_id'] : null;
    }
	 
}
