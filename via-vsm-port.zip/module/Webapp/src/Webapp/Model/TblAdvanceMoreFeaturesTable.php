<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblAdvanceMoreFeaturesTable
 {
	   protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		public function updateMoreFeatures( $ivalue,$property_name)
		{
			$result=$this->tableGateway->update(array('ivalue' => $ivalue),array('property_name'=>$property_name)); 
			return $result;
		}
		
		public function getAdavnceMoreFeatures()
		{
			$select = $this->tableGateway->getSql()->select();
			$select->columns(array('property_name','ivalue'));	
			$select->where(array('property_name'=>'ModFeatEnable'));
			$resultSet =$this->tableGateway->selectWith($select);	
			return  $resultSet ;
		
		}
                
                public function fetchProperty($propertyName) { 
                    $sqlSelect = $this->tableGateway->getSql()->select();
                    $sqlSelect->where(array('property_name' => $propertyName));
                    $resultSet = $this->tableGateway->selectWith($sqlSelect);
                    foreach($resultSet as $feature){
                       $result =  $feature->ivalue;
                    }
                    return $result;
                }

                public function updateFeatures($data, $where){
                    $this->tableGateway->update($data, $where);  
                }
 }