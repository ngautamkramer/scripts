<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Db\Sql\Expression;
use Zend\Paginator\Paginator;
use Webapp\Controller\ApplicationController;
class TblProjectorLogTable {
	protected $tableGateway;

	public function __construct(TableGateway $tableGateway) {
		$this->tableGateway = $tableGateway;
	}
	
	/*****
	 *	@Function Name:  getProjectorList
	 *  @description  : get gateway log list
	 *	@Author		  : Vineet
	 *  @Date         : 27-jan-2020
	 *****/
	public function getProjectorList($user_id) {
		$startDateTime = date("Y-m-d"). ' 00:00:00';
		$endDateTime = date("Y-m-d"). ' 23:59:00';
		$select = $this->tableGateway->getSql()->select();
		if(PRODUCT=='vsm'){
		/*for admin***/
		if($user_id==1){
			$select->columns(array('UserName', 'ActivityDate', 'StartTime', 'EndTime', 'DeviceID','PlayedType','Comments'));
			$select->join('DeviceInventory', 'DeviceInventory.DID = ProjectorLog.DeviceID', array('DeviceName'), 'inner');
			$select->where->between('ProjectorLog.ActivityDate', $startDateTime, $endDateTime);
		}
		// for other users
		else{
			$select->columns(array('ProjectorLogID' => new \Zend\Db\Sql\Expression('DISTINCT ProjectorLogID'),'UserName', 'ActivityDate', 'StartTime', 'EndTime', 'DeviceID','PlayedType','Comments'));
			$select->join('DeviceInventory', 'DeviceInventory.DID=ProjectorLog.DeviceID', array('DeviceName'), 'inner')
			->join('tbl_user_access','tbl_user_access.group_id_fk = DeviceInventory.DeviceGroupID', array('field1'), 'inner')
			->where(array('tbl_user_access.user_id_fk'=>$user_id));
			$select->where->between('ProjectorLog.ActivityDate', $startDateTime, $endDateTime);
			
		}
		$select->order(array('ProjectorLog.ActivityDate DESC' ,'ProjectorLog.StartTime DESC'));
		
	}else{
		$select->columns(array('*'));
		$select->where->between('activitydate', $startDateTime, $endDateTime);
		$select->order(array('activitydate DESC', 'starttime DESC'));
	}
		$resultSet = $this->tableGateway->selectWith($select);
		$result['count'] = $resultSet->count();
		$paginatorAdapter = new DbSelect($select, $this->tableGateway->getAdapter());
		$resultSet = new Paginator($paginatorAdapter);
		$result['data']=$resultSet;	
		return $result;

	}
	
	
	
	/*****
	 *	@Function Name:  getProjectorLogSerachList
	 *  @description  : get gateway log by name,startdate,edndate
	 *	@Author		  : Vineet
	 *  @Date         : 27-jan-2020
	 *****/
	public function getGatewayLogSerachList($name, $startDate, $endDate, $export,$user_id) {
		
		$startDateTime = $startDate. ' 00:00:00';
		$endDateTime = $endDate. ' 23:59:00';
		$select = $this->tableGateway->getSql()->select();
		/*for admin***/
		if($user_id==1){
			$select->columns(array('UserName', 'ActivityDate', 'StartTime', 'EndTime', 'DeviceID','PlayedType','Comments'));
			$select->join('DeviceInventory', 'DeviceInventory.DID = ProjectorLog.DeviceID', array('DeviceName'), 'inner');
			$select->where->between('ProjectorLog.ActivityDate', $startDateTime, $endDateTime);
		}
		// for other users
		else{
			$select->columns(array('ProjectorLogID' => new \Zend\Db\Sql\Expression('DISTINCT ProjectorLogID'),'UserName', 'ActivityDate', 'StartTime', 'EndTime', 'DeviceID','PlayedType','Comments'));
			$select->join('DeviceInventory', 'DeviceInventory.DID=ProjectorLog.DeviceID', array('DeviceName'), 'inner')
			->join('tbl_user_access','tbl_user_access.group_id_fk = DeviceInventory.DeviceGroupID', array('field1'), 'inner')
			->where(array('tbl_user_access.user_id_fk'=>$user_id))
			 ->where->between('ProjectorLog.ActivityDate', $startDateTime, $endDateTime);
		
		}
		
		if($name == "" && $startDate == "" && $endDate == "") {
			$startDateTime = date("Y-m-d"). ' 00:00:00';
			$endDateTime = date("Y-m-d"). ' 23:59:00';
			$select->where->between('ProjectorLog.ActivityDate', $startDateTime, $endDateTime);
		}
		else if($name == "" && $startDate != "" && $endDate != "") {
			$startDate = $startDate . '00:00:00';
			$endDate = $endDate . '23:59:00';
			$startDate = date('Y-m-d H:i:s', strtotime($startDate));
			$endDate = date('Y-m-d H:i:s', strtotime($endDate));
			$select->where->between('ActivityDate', $startDate, $endDate);

		}else if($name != "" && $startDate == "" && $endDate == "") {
			$select->where->expression("CONCAT(ProjectorLog.UserName,DeviceInventory.DeviceName,ProjectorLog.Comments) ILIKE ?",  '%'.$name.'%');		
		}
		else{
			$startDate = $startDate . '00:00:00';
			$endDate = $endDate . '23:59:00';
			$startDate = date('Y-m-d H:i:s', strtotime($startDate));
			$endDate = date('Y-m-d H:i:s', strtotime($endDate));
			$select->where->between('ActivityDate', $startDate, $endDate);
			$select->where->expression("CONCAT(ProjectorLog.UserName,DeviceInventory.DeviceName,ProjectorLog.Comments) ILIKE ?",  '%'.$name.'%');
		}
		//echo $select->getSqlString();
		//$select->order(array('ProjectorLog.ActivityDate DESC'));
		$select->order(array('ProjectorLog.ActivityDate DESC' ,'ProjectorLog.StartTime DESC'));
		$resultSet = $this->tableGateway->selectWith($select);
		$result['count'] = $resultSet->count();
		$result['data']=$resultSet;	
		if($export == null) {
			$paginatorAdapter = new DbSelect($select, $this->tableGateway->getAdapter());
			$resultSet = new Paginator($paginatorAdapter);
			$result['data']=$resultSet;	
		}
		return $result;
	}
	/*****
	 *	@Function Name:  getProjectorLogSerachList
	 *  @description  : get gateway log by name,startdate,edndate
	 *	@Author		  : Vineet
	 *  @Date         : 8-sep-2020
	 *****/
	public function getProjectorLogSerachList($name, $startDate, $endDate, $export) {
		$select = $this->tableGateway->getSql()->select();
		if($name == "" && $startDate == "" && $endDate == "") {
			$select->columns(array('*'));
			$select->order(array('activitydate DESC', 'starttime DESC'));
		} else if($name == "" && $startDate != "" && $endDate != "") {
			$startDate = $startDate . '00:00:00';
			$endDate = $endDate . '23:59:00';
			$startDate = date('Y-m-d H:i:s', strtotime($startDate));
			$endDate = date('Y-m-d H:i:s', strtotime($endDate));
			$select->columns(array('*'));
			$select->where->between('activitydate', $startDate, $endDate);
			$select->order(array('activitydate DESC', 'starttime DESC'));
		} else if($name != "" && $startDate == "" && $endDate == "") {
			$select = $this->tableGateway->getSql()->select();
			$select->columns(array('*'));
			//$select->where->like('username', '%'.$name.'%');
			$select->where->expression("username ILIKE ?",  '%'.$name.'%');
			$select->order(array('activitydate DESC', 'starttime DESC'));
		} else {
			$startDate = $startDate . '00:00:00';
			$endDate = $endDate . '23:59:00';
			$startDate = date('Y-m-d H:i:s', strtotime($startDate));
			$endDate = date('Y-m-d H:i:s', strtotime($endDate));
			$select->columns(array('*'));
			//$select->Where->between('activitydate', $startDate, $endDate)->andwhere->like('username', '%'.$name.'%')->andWhere->isNotNull('username');
			$select->Where->between('activitydate',  $startDate, $endDate)->andwhere->expression("username ILIKE ?",  '%'.$name.'%')->andWhere->isNotNull('username');
			$select->order(array('activitydate DESC', 'starttime DESC'));
		}
		$resultSet = $this->tableGateway->selectWith($select);
		$result['count']=$resultSet->count();
		$result['data']=$resultSet;
		if($export == null) {
			$paginatorAdapter = new DbSelect($select, $this->tableGateway->getAdapter());
			$resultSet = new Paginator($paginatorAdapter);
			$result['data']=$resultSet;
		}
		return $result;
	}
}
