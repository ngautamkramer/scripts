<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblAdvanceConfiguration 
 {
	  public $id;
	  public $feature1;
      public $feature2;
      public $feature3;
	  public $feature4;
	  public $feature5; 
	  public $feature6;	 
	  public $feature7;	
	  public $feature8;	
	  public $feature9;	
	  public $feature10;	
	  public $last_updated;
	  public $os_type;
	  public $timezone_name; 	
 
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		$this->feature1= (isset($data['feature1']))? $data['feature1']: null;
		$this->feature2= (isset($data['feature2']))? $data['feature2']: null;
		$this->feature3= (isset($data['feature3']))? $data['feature3']: null;
		$this->feature4= (isset($data['feature4']))? $data['feature4']: null;
		$this->feature5= (isset($data['feature5']))? $data['feature5']: null;
		$this->feature6= (isset($data['feature6']))? $data['feature6']: null;
		$this->feature7= (isset($data['feature7']))? $data['feature7']: null;
		$this->feature8= (isset($data['feature8']))? $data['feature8']: null;
		$this->feature9= (isset($data['feature9']))? $data['feature9']: null;
		$this->feature10= (isset($data['feature10']))? $data['feature10']: null;
		$this->last_updated= (isset($data['last_updated']))? $data['last_updated']: null;
		$this->os_type= (isset($data['os_type']))? $data['os_type']: null;
		$this->timezone_name= (isset($data['timezone_name']))? $data['timezone_name']: null;
	}
	
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}
	
 }