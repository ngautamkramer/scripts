<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblGatewayFeaturesPositionTable
 {
        protected $tableGateway;
	public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	public function getGwayFeaturesPositionCount()
        {
            $select = $this->tableGateway->select();
            $count = $select->count();
            return  $count ;
        }
        
        public function insertFeaturesPosition($gateway_feature){
            $select = $this->tableGateway->insert(array('gateway_feature_fk'=>$gateway_feature));
        }
        
        public function truncateTable(){
            $query = $this->tableGateway->getAdapter()->query('TRUNCATE TABLE '.$this->tableGateway->getTable());
            $query->execute();
        }
 }


