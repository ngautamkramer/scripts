<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

 class TblThirdpartyapps implements InputFilterAwareInterface
 {
     public $tpsn;
	 public $tpname;
	 public $tpimage;
     public $tppath;
     public $param1;
	 public $param2;
	 public $param3; 
	 public $param4;	 
	 public $name;	
	 public $remarks;	
     protected $inputFilter;                       // <-- Add this variable

     public function exchangeArray($data)
     {
	 	 $this->tpsn= (isset($data['tpsn']))? $data['tpsn']: null;
         $this->tpname= (isset($data['tpname']))? $data['tpname']: null;
         $this->tpimage= (isset($data['tpimage']))? $data['tpimage']: null;
         $this->tppath = (isset($data['tppath'])) ? $data['tppath'] : null;
         $this->param1  = (isset($data['param1']))  ? $data['param1']  : null;
		 $this->param2  = (isset($data['param2']))  ? $data['param2']  : null;
		 $this->param3  = (isset($data['param3']))  ? $data['param3']  : null;
		 $this->param4  = (isset($data['param4']))  ? $data['param4']  : null;
     }
	 
    public function getArrayCopy(){
        return get_object_vars($this);
    }

     // Add content to these methods:
    public function setInputFilter(InputFilterInterface $inputFilter){
        throw new \Exception("Not used");
    }

    public function getInputFilter(){
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $this->inputFilter = $inputFilter;
        }

        return $this->inputFilter;
    }
 }
