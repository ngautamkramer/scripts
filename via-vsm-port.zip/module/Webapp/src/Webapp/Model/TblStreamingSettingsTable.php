<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblStreamingSettingsTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function fetchAll() { 
            $resultSet = $this->tableGateway->select();
            $resultCount = $resultSet->count();
            if($resultCount>0){
                foreach($resultSet as $streamkey => $stream){
                    $streamArr[$streamkey]=$stream;
                }
            }else{
                $streamArr=array();
            }
            return $streamArr;
        }
        
        public function countRows() { 
            $resultSet = $this->tableGateway->select();
            $resultCount = $resultSet->count();
            return $resultCount;
        }
        
        public function updateStreaming($data){
            $this->tableGateway->update($data);  
        }
        
        public function insertStreaming($data){
            $this->tableGateway->insert($data);  
        }
	
 }