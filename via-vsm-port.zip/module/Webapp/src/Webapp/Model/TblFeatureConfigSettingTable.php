<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblFeatureConfigSettingTable
 {
        protected $tableGateway;

        public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
	
        public function fetchFeatures($feature_name){
            $sqlQry = $this->tableGateway->getSql()->select();
            $sqlQry->where(array('feature_name'=>$feature_name));
            $resultSet =$this->tableGateway->selectWith($sqlQry);
            $result = $resultSet->count();
            return $result;           
        }
	
        public function insertFeatureConfigSetting($feature_name, $feature_data){
            $this->tableGateway->insert(array('feature_name' => $feature_name, 'feature_data' => $feature_data, 'feature_dateTime' => date("Y-m-d h:i:s")));
        }
        
        public function updateFeatureConfigSetting($feature_name, $feature_data){
            $select = $this->tableGateway->update(array('feature_data' => $feature_data,'feature_dateTime' => date("Y-m-d h:i:s")),array('feature_name'=>$feature_name));
        }
 }