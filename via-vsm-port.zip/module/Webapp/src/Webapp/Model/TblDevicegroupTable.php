<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;
class TblDevicegroupTable
 {
		protected $tableGateway;
	    public function __construct(TableGateway $tableGateway)
        {
            $this->tableGateway = $tableGateway;
        }
		
		public function fetchAll(){
			$sqlSelect = $this->tableGateway->select();
			return $sqlSelect;
		}
		
		public function fetchGroupList($user_id, $group){
			$sqlSelect = $this->tableGateway->getSql()->select();
			if($user_id==1){
				$sqlSelect->columns(array('*'));
				if($group!=''){
					$sqlSelect->where->like('DeviceGroup', '%'.$group.'%');
				}
			}else{
				$sqlSelect->columns(array('DeviceGroupID'=>'DeviceGroupID','DeviceMasterID'=>'DeviceMasterID','DeviceGroup'=>'DeviceGroup','Comments'=>'Comments'));
				$sqlSelect->quantifier('DISTINCT');    // For distinct value
				$sqlSelect->join('tbl_user_access', 'tbl_user_access.group_id_fk = devicegroup.DeviceGroupID',array('tbl_user_access.menu_id_fk' => new \Zend\Db\Sql\Expression("GROUP_CONCAT(tbl_user_access.menu_id_fk)")),'left');
				$sqlSelect->where(array('tbl_user_access.user_id_fk'=>$user_id));
				if($group!=''){
					$sqlSelect->where->like('DeviceGroup', '%'.$group.'%');
				}
				$sqlSelect->group(array('tbl_user_access.group_id_fk'));
			}				
			$resultSet = $this->tableGateway->selectWith($sqlSelect);
			$result['count'] = $resultSet->count();
            $paginatorAdapter = new DbSelect($sqlSelect,$this->tableGateway->getAdapter());
            $result['data'] = new Paginator($paginatorAdapter);
            return $result;
		}
		
		public function getGroup($condition){
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->where($condition);
			$resultSet = $this->tableGateway->selectWith($sqlSelect);
			return $resultSet->buffer();
		}
		
		public function getGroupWithPermission($user_id){
			$sqlSelect = $this->tableGateway->getSql()->select();
			$sqlSelect->columns(array('DeviceGroup'=>'DeviceGroup'));
			$sqlSelect->quantifier('DISTINCT');    // For distinct value
			$sqlSelect->join('tbl_user_access', 'tbl_user_access.group_id_fk = devicegroup.DeviceGroupID',array(),'LEFT');
			$sqlSelect->where(array('tbl_user_access.user_id_fk'=>$user_id));				
			$resultSet = $this->tableGateway->selectWith($sqlSelect);
            return $resultSet->buffer();
		}
		
		public function insertGroup($insertArr){
			$this->tableGateway->insert($insertArr);
            /*$insertId = $this->tableGateway->lastInsertValue; 
            return $insertId;*/
			// for return last inserted id from pgsql
		    return $this->tableGateway->getAdapter()->getDriver()->getLastGeneratedValue('devicegroup_devicegroupid_seq');
		}
		
		public function deleteGroup($condition){
			$this->tableGateway->delete($condition);
		}
                
		public function updateGroup($updateArr){
			$this->tableGateway->update($updateArr);
		}
 }