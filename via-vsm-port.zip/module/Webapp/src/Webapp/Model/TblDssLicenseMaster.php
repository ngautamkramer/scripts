<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

class TblDssLicenseMaster
{
  	public $dss_master_id;
    public $unique_id;
    public $order_id;
    public $num_of_devices;
    public $purchase_date;
    public $validity_months;    
    public $expiry_date;    
    public $num_of_lic_used;    

    public function exchangeArray($data){
        $this->dss_master_id = (isset($data['dss_master_id']))? $data['dss_master_id']: null;
        $this->unique_id = (isset($data['unique_id']))? $data['unique_id']: null;
        $this->order_id = (isset($data['order_id'])) ? $data['order_id'] : null;
        $this->num_of_devices  = (isset($data['num_of_devices']))  ? $data['num_of_devices']  : null;
	    $this->purchase_date  = (isset($data['purchase_date']))  ? $data['purchase_date']  : null;	    
        $this->validity_months  = (isset($data['validity_months']))  ? $data['validity_months']  : null;
        $this->num_of_lic_used  = (isset($data['expiry_date']))  ? $data['expiry_date']  : null;
        $this->number_of_lic_used  = (isset($data['num_of_lic_used']))  ? $data['num_of_lic_used']  : null;
    }
       

	 
}
