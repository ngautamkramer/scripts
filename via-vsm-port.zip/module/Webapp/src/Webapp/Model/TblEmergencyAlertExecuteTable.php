<?php
namespace Webapp\Model;
use Zend\Db\TableGateway\TableGateway;
//for pagination
use Zend\Paginator\Adapter\DbSelect;
use Zend\Paginator\Paginator;

 class TblEmergencyAlertExecuteTable
 {
    protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }
    public function deleteInstantAlert($id)
    {
        $this->tableGateway->delete(array('emergency_alert_id_fk' => (int) $id));
    }
   
 }