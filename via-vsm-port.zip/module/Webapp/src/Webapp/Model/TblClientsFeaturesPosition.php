<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblClientsFeaturesPosition
 {
	  public $id;
	  public $client_feature_fk;
  
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->client_feature_fk= (isset($data['client_feature_fk']))? $data['client_feature_fk']: null;
		 
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }