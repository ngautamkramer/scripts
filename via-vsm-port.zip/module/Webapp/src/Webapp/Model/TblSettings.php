<?php

namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;

 class TblSettings implements InputFilterAwareInterface
 {
     public $id;
	 public $logoutTIme;
     public $pageSize;
     public $field1;
	 public $field2;
	 public $field3; 
	 public $field4;	
	 public $field5; 
	 public $field6;	
	 public $startTime;
	 public $endTime;
	 public $field9;
	 public $field10;		 	
     protected $inputFilter;                       // <-- Add this variable

     public function exchangeArray($data)
     {
		$this->id= (isset($data['id']))? $data['id']: null;
		$this->logoutTIme= (isset($data['logoutTIme']))? $data['logoutTIme']: null;
		$this->pageSize = (isset($data['pageSize'])) ? $data['pageSize'] : null;
		$this->field1  = (isset($data['field1']))  ? $data['field1']  : null;
		$this->field2  = (isset($data['field2']))  ? $data['field2']  : null;
		$this->field3  = (isset($data['field3']))  ? $data['field3']  : null;
		$this->field4  = (isset($data['field4']))  ? $data['field4']  : null;
		$this->field5  = (isset($data['field5']))  ? $data['field5']  : null;
		$this->field6  = (isset($data['field6']))  ? $data['field6']  : null;
		$this->startTime  = (isset($data['startTime']))  ? $data['startTime']  : null;
		$this->endTime  = (isset($data['endTime']))  ? $data['endTime']  : null;
		$this->field9  = (isset($data['field9']))  ? $data['field9']  : null;
		$this->field10  = (isset($data['field10']))  ? $data['field10']  : null;
		 
		 
     }
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

     // Add content to these methods:
     public function setInputFilter(InputFilterInterface $inputFilter)
     {
         throw new \Exception("Not used");
     }

     public function getInputFilter()
     {         

         return $this->inputFilter;
     }
	 
 }
