<?php
namespace Webapp\Model;
use Zend\Db\Table\AbstractTable;


 // Add these import statements
 use Zend\InputFilter\InputFilter;
 use Zend\InputFilter\InputFilterAwareInterface;
 use Zend\InputFilter\InputFilterInterface;
 
 class TblBuildInfo
 {
	  public $id;
	  public $client_version_no;
 
   public function exchangeArray($data)
	{
		 $this->id= (isset($data['id']))? $data['id']: null;
		 $this->client_version_no= (isset($data['client_version_no']))? $data['client_version_no']: null;
	}
	public function getArrayCopy()
	{
	return get_object_vars($this);
	}

 }