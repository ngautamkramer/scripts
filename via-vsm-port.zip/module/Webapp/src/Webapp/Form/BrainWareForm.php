<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class BrainWareForm extends Form
{	
 public function __construct()
  {
       parent::__construct('brainWare');
            $this->addInputFilter();
       
             
            
            $this->add(array(
                'name' => 'serial_number',
                'type' => 'text',
                'attributes' => array(
                   'id' => 'serial_number',
                   'class' => 'form-control styl makeDisabled',
                   'autocomplete'=>'off',
                   'value' => '',
                ), 
            ));
            
            
            
	}
    
            
	
	function addInputFilter() {
                $inputFilter = new InputFilter();        
                $this->setInputFilter($inputFilter);
                $inputFilter->add(array(
                    'name' => 'logoutTime',
                    'required' => true,
                    'filters' => array(
                        array('name' => StripTags::class),
                        array('name' => StringTrim::class),
                    ),
                    'validators' =>array(
                        array(
                            'name' => 'NotEmpty',
                            'options' => array(
                                'break_chain_on_failure' => true,
                            ),
                        ),
                    ),
                ));
                
                $inputFilter->add(array(
                    'name' => 'netServer',
                    'required' => true,
                    'filters' => array(
                        array('name' => StripTags::class),
                        array('name' => StringTrim::class),

                    ),
                    'validators' =>array(
                        array(
                            'name' => 'NotEmpty',
                            'options' => array(
                                'break_chain_on_failure' => true,
                            ),
                       ),
                       array(
                           'name' => 'Regex', 
                           'options' =>  array('pattern' =>'/^[^\s]+$/',
                           ),
                       ),
                    ),
                ));
	 	 
	}
}