<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class ViapadForm extends Form
{	
        public function __construct($guestTag,$roomcode,$roomname,$autoconnect,$ssid,$authMode,$encryptArr)
        {
           parent::__construct('wifisecurityFrm');
                $this->addInputFilter();
                
                $guestChecked = $guestTag==1?'checked':'';
                $roomCodeChecked = $roomcode==0?'checked':'';
                $roomcodeval=($roomcode==0)?1:0;
                $autoconnectChecked = $autoconnect==1?'checked':'';
                
                $this->add(array(
                    'type' => 'Zend\Form\Element\Checkbox',
                    'name' => 'txtGuest',		
                    'options' => array( 
                        'value_options' => $guestTag,
                        'use_hidden_element' => false,
                    ),
                    'attributes' => array(
                        'class'=>'chkbox',
                        'id'=>'txtGuest',
                        'checked'=>$guestChecked,
                    )
                ));
                
                $this->add(array(
                    'type' => 'Zend\Form\Element\Checkbox',
                    'name' => 'roomcodeDD',		
                    'options' => array(
                        'value_options' => $roomcodeval,
                        'use_hidden_element' => false,
                    ),
                    'attributes' => array(
                        'class'=>'chkbox makeDisabled',
                        'id'=>'roomcodeDD',
                        'checked'=>$roomCodeChecked,
                    )
                ));
                
                $this->add(array(
                    'name' => 'txtRoomname',
                    'type' => 'text',
                    'attributes' => array(
                       'id' => 'txtRoomname',
                       'class' => 'form-control m-b styl',
                       'autocomplete'=>'off',
                        'disabled'=>'disabled',
                       'value' => $roomname,
                    ), 
                ));
                
                $this->add(array(
                    'type' => 'Zend\Form\Element\Checkbox',
                    'name' => 'txtAutoconnect',		
                    'options' => array( 
                        'value_options' => $autoconnect,
                        'use_hidden_element' => false,
                    ),
                    'attributes' => array(
                        'class'=>'chkbox',
                        'id'=>'txtAutoconnect',
                        'checked'=>$autoconnectChecked,
                    )
                ));
                
                $this->add(array(
                    'name' => 'txtSSID',
                    'type' => 'text',
                    'attributes' => array(
                       'id' => 'txtSSID',
                       'class' => 'form-control m-b styl',
                       'autocomplete'=>'off',
                        'maxlength'=>35,
                       'value' => $ssid,
                    ), 
                ));
                
                $this->add(array(
                    'name' => 'txtKey',
                    'type' => 'password',
                    'attributes' => array(
                       'id' => 'txtKey',
                       'class' => 'form-control m-b styl',
                       'autocomplete'=>'off',
                        'maxlength'=>50,
                       'value' => '',
                    ), 
                ));
                
                $this->add(array(
                    'name' => 'authentiationMode',
                    'type' => 'Select',
                    'attributes' => array(
                        'id'   => 'authentiationMode',
                        'class' => 'form-control m-b styl',
                        'value'=> $authMode['sel'],	
                        'disabled'=>'',
                    ),
                    'options' => array(
                             'empty_option' => 'Select',
                             'options' => $authMode['options'],
                    ),
                ));
                
                 $this->add(array(
                    'name' => 'encryptionDDBox',
                    'type' => 'Select',
                    'attributes' => array(
                        'id'   => 'encryptionDDBox',
                        'class' => 'form-control m-b styl',
                        'value'=> $encryptArr['sel'],	
                        'disabled'=>'',
                    ),
                    'options' => array(
                             'empty_option' => 'Select',
                             'options' => $encryptArr['options'],
                    ),
                ));
                
        }

        
	function addInputFilter() {
                $inputFilter = new InputFilter();        
                $this->setInputFilter($inputFilter);
                
	}
}