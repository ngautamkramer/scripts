<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Session\Container;

class GatewaysForm extends Form
{	
	public function __construct($airMirrorMax=null)
	{
       parent::__construct('exportLogFrm');
	   $this->addFromElement($page);
	   $this->addInputFilter();
    }
	
	public function addFromElement()
	{		 
			$session = new Container('userinfo');
		    $page = $session->offsetGet('rowsPerPage');
			for($i=1;$i<13;$i++){
				$airMirrorMax[$i] = $i;
			}
			$perpage = array(50=>50,100=>100,200=>200,500=>500,2000=>2000);
			
             $this->add(array(
                'name' => 'gatewaySearchBox',
                'type' => 'text',
                'attributes'=>array(
                    'id'=>'gatewaySearchBox',
                    'class'=>'form-control search titillium',
                    'placeholder'=>STR_FILTER_GATEWAY_IP_REMARKS,
                ),
            ));
		
            $this->add(array(
                'name' => 'exportpdf',
                'type' => 'submit',
                'attributes'=>array(
                    'id'=>'exportpdf',
                    'value' => EXPORT_TO_PDF_BTN,
                ),
            ));
		
            $this->add(array(
                'name' => 'exportcsv',
                'type' => 'submit',
                'attributes'=>array(
                    'id'=>'exportcsv',
                    'value' => EXPORT_TO_CSV_BTN,
                ),
            ));
		
		
            $this->add(array(
                'name' => 'searchBtn',
                'type' => 'submit',
                'attributes' => array(
                    'value' => SEARCH_BTN,
                    'id'    => 'serverBtn',
                ),
            ));
            
	    $this->add(array(
                'name' => 'gwayID',
                'type' => 'text',
                'attributes'=>array(
                    'id'=>'gwayID',
                    'class'=>'form-control styl',
                    'maxlength' => '10',
                    'autocomplete'=>  'off',
                    'value'=>$gwayDeviceID,
                ),
            ));
            
            $this->add(array(
                'name' => 'gatewayName',
                'type' => 'text',
                'attributes'=>array(
                    'id'=>'gatewayName',
                    'class'=>'form-control styl',
                    'autocomplete'=>  'off',
					'maxlength' => '45',
                ),
            ));
            
            $this->add(array(
                'name' => 'mcAddress',
                'type' => 'text',
                'attributes'=>array(
                    'id'=>'mcAddress',
                    'class'=>'form-control styl',
                    'maxlength' => '30',
                    'autocomplete'=>  'off',
                ),
            ));
            
            $this->add(array(
                'name' => 'ddGrpName',
				'type' => 'Select',
                'attributes' => array(
                    'id'   => 'ddGrpName',
                    'class' => 'form-control m-b styl',
                    'value'=> '1',	
                    'disabled'=>'',
                ),
                'options' => array(
                         'options' => array(1,2,3),
                ),
            ));
            
            $this->add(array(
                'name' => 'dnsName',
                'type' => 'text',
                'attributes'=>array(
                    'id'=>'dnsName',
                    'class'=>'form-control styl',
                    'autocomplete'=>  'off',
					'maxlength' => '50',
                ),
            ));
            
            $this->add(array(
                'name' => 'airMirrorName',
                'type' => 'text',
                'attributes'=>array(
                    'id'=>'airMirrorName',
                    'class'=>'form-control styl',
                    'autocomplete'=>  'off',
                    'maxlength' => '100',
                ),
            ));
            
            $this->add(array(
                'name' => 'airMirrorMaxNo',
				'type' => 'Select',
                'attributes' => array(
                    'id'   => 'airMirrorMaxNo',
                    'class' => 'form-control m-b styl',
                    //'value'=> '1',
                ),
                'options' => array(
                         'options' => $airMirrorMax,
                ),
            ));
            
            $this->add(array(
                'name' => 'gatewayRemarks',
                'type' => 'textarea',
                'attributes'=>array(
                    'id'=>'gatewayRemarks',
                    'class'=>'form-control styl',
                    'autocomplete'=>  'off',
                    'maxlength' => '200',
                ),
            ));
			
			$this->add(array(
                'name' => 'rowsPerPage',
				'type' => 'Select',
                'attributes' => array(
                    'id'   => 'rowsPerPage',
                    'class' => 'form-control m-b styl',
                    'value'=> $page,
                ),
                'options' => array(
                    'options' => $perpage,
                ),
            ));
            	
	}
        
        function addInputFilter(){
            $inputFilter = new InputFilter();        
            $this->setInputFilter($inputFilter);
            $inputFilter->add(array(
                'name' => 'search',
                'required' => false,
            ));
        }
}