<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;

class RecordingController extends AbstractActionController {
	
	public function recordingListAction(){
		
	   $viewmodel = new ViewModel(array());
		return $viewmodel;
	}
	
		public function getAdvanceConfigurationTable() {
		if(!$this->TblAdvanceConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationTable = $sm->get('Webapp\Model\TblAdvanceConfigurationTable');
		}
		return $this->TblAdvanceConfigurationTable;
	}
	
	
}