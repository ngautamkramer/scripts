<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;


class ThirdpartyappForm extends Form
 {//$name = null
     public function __construct()
     {
	 
	 parent::__construct('addtpaform');
		//CSRF token code(Added date 23-Aug-2022)
		$this->add(array(
			'type' => 'Zend\Form\Element\Csrf',
			'name' => 'secret',
			'options' => array(
				'csrf_options' => array(
					'timeout' => 600
				)
			)
		));
         	$this->add(array(
			'name' => 'tpaname',
			'attributes' => array(
			'type' => 'text',
			'id'   => 'tpaname',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
             
         ));
         	$this->add(array(
			'name' => 'tpaurl',
			'attributes' => array(
			'type' => 'text',
			'id'   => 'tpaurl',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
             
         ));
	 
	 	 
/*         	$this->add(array(
			'name' => 'tpaiconurl',
			'attributes' => array(
			'type' => 'text',
			'id'   => 'tpaiconurl',
			'class' => 'form-control styl',
			'autocomplete'=>'off',
			'maxlength' => 25
			),			 
             
         ));
*/		 
         $this->add(array(
             'name' => 'submit',
             'type' => 'button',
             'attributes' => array(
                 'value' => 'Save',
                 'id' => 'submitbutton',
				 'class'=>'newBtnClass',
             ),
         ));
     }
 }