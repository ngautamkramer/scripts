<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class GroupsForm extends Form
{	
	public function __construct($airMirrorMax=null)
	{
       parent::__construct('groupFrm');
	   $this->addFromElement();
	   $this->addInputFilter();
    }
	
	public function addFromElement()
	{		 
		 $this->add(array(
			'name' => 'grpSearchBox',
			'type' => 'text',
			'attributes'=>array(
				'id'=>'grpSearchBox',
				'class'=>'form-control search titillium',
				'placeholder'=>STR_FILTER_BY_LOCATION_NAME,
			),
		));
	
		$this->add(array(
			'name' => 'searchBtn',
			'type' => 'submit',
			'attributes' => array(
				'value' => 'Search',
				'id'    => 'serverBtn',
			),
		));
            
		$this->add(array(
			'name' => 'grpName',
			'type' => 'text',
			'attributes'=>array(
				'id'=>'grpName',
				'class'=>'form-control styl',
				'autocomplete'=>  'off',
				'maxlength' => '25',
			),
		));
            
		$this->add(array(
			'name' => 'grpRemarks',
			'type' => 'textarea',
			'attributes'=>array(
				'id'=>'grpRemarks',
				'class'=>'form-control styl',
				'autocomplete'=>  'off',
				'maxlength' => '30',
			),
		));
            	
	}
        
	function addInputFilter(){
		$inputFilter = new InputFilter();        
		$this->setInputFilter($inputFilter);
		$inputFilter->add(array(
			'name' => 'search',
			'required' => false,
		));
	}
}