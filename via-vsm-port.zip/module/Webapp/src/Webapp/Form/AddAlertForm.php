<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class AddAlertForm extends Form
{	
 public function __construct($alertThresholdArray=null)
  {
       parent::__construct('alertform');
		$this->addFromElement();
		$this->addInputFilter();
    }
    function addFromElement()
	{

		$this->add(array(
			'name' => 'alertmode',
			'attributes' => array(
			'type' => 'hidden',
			'id'   => 'alertmode',		
			),			 
             
		 ));
		 
		 $this->add(array(
			'name' => 'idAlert',
			'attributes' => array(
			'type' => 'hidden',
			'id'   => 'idAlert',		
			),			 
             
         ));

		
			
        
        
        $this->add(array(
            'name' => 'minvalue',
            'type' => 'Select',
            'attributes' => array(
               'id' => 'minvalue',
               'class' => 'form-control m-b makeDisabled minthresholdValue styl',
              
            ),
            'options' => array(

               'value_options' => array('20'=>20,
               '40'=>40,
               '50'=>50,
               '80'=>80,
               '100'=>100
            ),
            'empty_option' => 'Select Min.Value(%)',
            ),
        ));

        $this->add(array(
            'name' => 'startdate',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'startdate',
			'autocomplete'=>  'off',
			'class' => 'form-control styl',
			),
          
        ));
		
		$this->add(array(
            'name' => 'enddate',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'enddate',
			'autocomplete'=>  'off',
			'class' => 'form-control styl',
			),
        ));

        $this->add(array(
            'name' => 'description',
            'type' => 'textarea',
			'attributes'=>array(
			'id'=>'description',
			'autocomplete'=>  'off',
			'class' => 'form-control styl',
			),
          
		));
		
		$this->add(array(
            'name' => 'exportcsv',
            'type' => 'submit',
			'attributes'=>array(
			'id'=>'exportcsv',
             'value' => EXPORT_TO_CSV_BTN,
			),
        ));

	}
	function addInputFilter()
		{
		   $inputFilter = new InputFilter();        
		   $this->setInputFilter($inputFilter);
		   	 $inputFilter->add(array(
            'name' => 'startdate',
            'required' => false,
			));
			$inputFilter->add(array(
            'name' => 'enddate',
            'required' => false,
			));
		
			$inputFilter->add(array(
				'name' => 'minvalue',
				'required' => false,
				));

				$inputFilter->add(array(
					'name' => 'description',
					'required' => false,
					));

				
		}

}