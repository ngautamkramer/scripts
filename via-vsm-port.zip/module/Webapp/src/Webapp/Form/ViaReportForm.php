<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class ViaReportForm extends Form
 {
    public function __construct($name=null)
    {
         parent::__construct('viausageform');
         $this->addFromElement();
         $this->addInputFilter();
      }
      public function addFromElement()
      {
          $this->add(array(
              'name' => 'startdate',
              'type' => 'text',
              'attributes'=>array(
              'id'=>'startdate',
              'autocomplete'=>  'off',
              ),
              'options' => array(
                  'label' => 'Start Date',
              ),
          ));
          
          $this->add(array(
              'name' => 'enddate',
              'type' => 'text',
              'attributes'=>array(
              'id'=>'enddate',
              'autocomplete'=>  'off',
              ),
              'options' => array(
                  'label' => 'Start Date',
              ),
          ));
          $this->add(array(
            'name' => 'submitBtn',
            'type' => 'submit',
            'attributes' => array(
                'value' => 'Search',
                'id'    => 'submitBtn',
            ),
        ));

        }
        function addInputFilter()
		{
		   $inputFilter = new InputFilter();        
		   $this->setInputFilter($inputFilter);
		   	 $inputFilter->add(array(
            'name' => 'startdate',
            'required' => false,
			));
			$inputFilter->add(array(
            'name' => 'enddate',
            'required' => false,
			));
		}
 }