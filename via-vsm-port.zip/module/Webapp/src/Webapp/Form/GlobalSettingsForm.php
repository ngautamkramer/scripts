<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class GlobalSettingsForm extends Form
{	
 public function __construct($sessionTimeOutArray = null,$sessionVal = null,$cmplxSettings = null)
  {
       parent::__construct('globalSettings');
            $this->addInputFilter();
       
            $this->add(array(
                'name' => 'logoutTime',
                'type' => 'Select',
                'attributes' => array(
                   'id' => 'logoutTime',
                   'class' => 'form-control m-b makeDisabled',
                   'value' => $sessionVal['sessionTimeOut'],
                ),
                'options' => array(
                   'value_options' => $sessionTimeOutArray,
                ),
            ));  
            
            $this->add(array(
                'name' => 'netServer',
                'type' => 'text',
                'attributes' => array(
                   'id' => 'netServer',
                   'class' => 'form-control m-b makeDisabled',
                   'autocomplete'=>'off',
                   'value' => '',
                ), 
            ));
            
            $this->add(array(
                'name' => 'ntpmode',
                'attributes' => array(
                    'type' => 'hidden',
                    'id'   => 'ntpmode',
                    'class' => 'form-control',			
                ),
            ));
            
            $this->add(array(
                'name' => 'ntpid',
                'attributes' => array(
                    'type' => 'hidden',
                    'id'   => 'ntpid',
                    'class' => 'form-control',			
                ),
            ));
            
            $this->add(array(
                'name' => 'minimumChar',
                'type' => 'text',
                'attributes' => array(
                   'id' => 'minimumChar',
                   'class' => 'form-control m-b styl makeDisabled',
                   'autocomplete'=>'off',
                   'value' => $cmplxSettings['minimumchar'],
                ), 
            ));
	}
    
            
	
	function addInputFilter() {
                $inputFilter = new InputFilter();        
                $this->setInputFilter($inputFilter);
                $inputFilter->add(array(
                    'name' => 'logoutTime',
                    'required' => true,
                    'filters' => array(
                        array('name' => StripTags::class),
                        array('name' => StringTrim::class),
                    ),
                    'validators' =>array(
                        array(
                            'name' => 'NotEmpty',
                            'options' => array(
                                'break_chain_on_failure' => true,
                            ),
                        ),
                    ),
                ));
                
                $inputFilter->add(array(
                    'name' => 'netServer',
                    'required' => true,
                    'filters' => array(
                        array('name' => StripTags::class),
                        array('name' => StringTrim::class),

                    ),
                    'validators' =>array(
                        array(
                            'name' => 'NotEmpty',
                            'options' => array(
                                'break_chain_on_failure' => true,
                            ),
                       ),
                       array(
                           'name' => 'Regex', 
                           'options' =>  array('pattern' =>'/^[^\s]+$/',
                           ),
                       ),
                    ),
                ));
	 	 
	}
}