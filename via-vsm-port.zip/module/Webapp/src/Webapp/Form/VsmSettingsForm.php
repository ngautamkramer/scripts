<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class VsmSettingsForm extends Form
{	
        public function __construct($definedServerIP = null,$boxID = null)
        {
           parent::__construct('vsmSettingForm');
                $this->addInputFilter();

                $this->add(array(
                    'name' => 'definedLinServerIP',
                    'type' => 'text',
                    'attributes' => array(
                       'id' => 'definedLinServerIP',
                       'class' => 'form-control m-b styl makeDisabled',
                       'autocomplete'=>'off',
                       'value' => $definedServerIP,
					   'maxlength' => '50',
                    ), 
                ));
                
                $this->add(array(
                    'name' => 'definedBoxID',
                    'type' => 'text',
                    'attributes' => array(
                       'id' => 'definedBoxID',
                       'class' => 'form-control m-b styl makeDisabled',
                       'autocomplete'=>'off',
                       'value' => $boxID,
					   'maxlength' => '10',
                    ), 
                ));
                
                $this->add(array(
                    'type' => 'Zend\Form\Element\Checkbox',
                    'name' => 'selAllHQ',		
                    'options' => array(
                        'use_hidden_element' => false,
                    ),
                    'attributes' => array(
                        'class'=>'chkbox chkAllHQmaster',
                        'id'=>'selAllHQ',
                        'checked'=>'',
                    )
                ));
                
                $this->add(array(
                    'type' => 'Zend\Form\Element\Checkbox',
                    'name' => 'selAllLocal',		
                    'options' => array(
                        'use_hidden_element' => false,
                    ),
                    'attributes' => array(
                        'class'=>'chkbox chkAllHQmaster',
                        'id'=>'selAllLocal',
                        'checked'=>'',
                    )
                ));
                
                $this->add(array(
                    'name' => 'radioBtn',
                    'type' => 'radio',
                    'attributes'=>array(
                        'id'=>'radioBtn',
                        'class'=>'radioBtnChk',
                    ),
                    'options' => array(
                    'label_attributes' => array(
                         'class' => 'control-label col-md-2 prevent-default',
                    ),
                        'value_options' => array(
                            array(
                                'value' => '1',
                                'label' => STR_FROM_VIA_SITEMGMT,
                                'label_attributes' => array('class' => 'radio-inline radioBtnChk prevent-default',),
                            ),

                            array(
                                'value' => '2',
                                'label' => STR_FROM_GATEWAY,
                                'label_attributes' => array('class' => 'radio-inline adBased radioBtnChk prevent-default',),
                            ),
                        ),
                    ),
                    'attributes' =>array(
                        'value' => '1' 
                    )
            ));

        }

        
	function addInputFilter() {
                $inputFilter = new InputFilter();        
                $this->setInputFilter($inputFilter);
                
                $inputFilter->add(array(
                    'name' => 'definedLinServerIP',
                    'required' => true,
                    'filters' => array(
                        array('name' => StripTags::class),
                        array('name' => StringTrim::class),

                    ),
                    'validators' =>array(
                        array(
                            'name' => 'NotEmpty',
                            'options' => array(
                                'break_chain_on_failure' => true,
                            ),
                       ),
                       array(
                           'name' => 'Regex', 
                           'options' =>  array('pattern' =>'/^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/',
                           ),
                       ),
                    ),
                ));
                
                $inputFilter->add(array(
                    'name' => 'definedBoxID',
                    'required' => true,
                    'filters' => array(
                        array('name' => StripTags::class),
                        array('name' => StringTrim::class),

                    ),
                    'validators' =>array(
                        array(
                            'name' => 'NotEmpty',
                            'options' => array(
                                'break_chain_on_failure' => true,
                            ),
                       ),
                       array(
                           'name' => 'Regex', 
                           'options' =>  array('pattern' =>'/^[0-9]+$/',
                           ),
                       ),
                    ),
                ));
	 	 
	}
}