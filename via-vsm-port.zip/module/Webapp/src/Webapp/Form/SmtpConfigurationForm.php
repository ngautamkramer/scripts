<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class SmtpConfigurationForm extends Form
{
    public function __construct($name=null)
    {
         parent::__construct('smtpConfigForm');
          $this->addFromElement();
      }

      	
	function addFromElement()
	{
        $this->add(array(
            'name' => 'mailerName',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'mailerName',
            'autocomplete'=>  'off',
            'maxlength'=>50,
			),
           
        ));

        $this->add(array(
            'name' => 'mailerHost',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'mailerHost',
            'autocomplete'=>  'off',
            'maxlength'=>45,
			),
           
        ));

        $this->add(array(
            'name' => 'mailerPort',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'mailerPort',
            'autocomplete'=>  'off',
            'maxlength'=>10,
			),
           
        ));

        $this->add(array(
            'type' => Element\Checkbox::class,
            'name' => 'mailerAuth',
                     'attributes' => array(
               'id'    => 'mailerAuth',
               'class'=>'mailerAuth',
           ),
       ));

       $this->add(array(
        'name' => 'mailerUserName',
        'type' => 'text',
        'attributes'=>array(
        'id'=>'mailerUserName',
        'autocomplete'=>  'off',
        ),
       
    ));

        $this->add(array(
            'name' => 'mailerUsername',
            'type' => 'text',
            'attributes'=>array(
            'id'=>'mailerUsername',
             'autocomplete'=>  'off',
             'maxlength'=>50,
         ),
       
        ));

        $this->add(array(
            'name' => 'mailerPassword',
            'type' => 'password',
            'attributes'=>array(
            'id'=>'mailerPassword',
             'autocomplete'=>  'off',
             'maxlength'=>20,
         ),
       
        ));

        $this->add(array(
            'type' => Element\Checkbox::class,
            'name' => 'mailerSSL',
                     'attributes' => array(
               'id'    => 'mailerSSL',
               'class'=>'mailerSSL',
           ),
       ));

       $this->add(array(
        'name' => 'mailerFromMail',
        'type' => 'text',
        'attributes'=>array(
        'id'=>'mailerFromMail',
         'autocomplete'=>  'off',
         'maxlength'=>100,
     ),
   
    ));

    }

}