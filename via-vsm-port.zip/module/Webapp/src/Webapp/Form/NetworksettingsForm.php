<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;


class NetworksettingsForm extends Form
 {//$name = null
     public function __construct()
     {
	 parent::__construct('networksettings');
         	$this->add(array(
			'name' => 'radioBtnOption',
			'attributes' => array(
			'type' => 'text',
			'id'   => 'radioBtnOption',
			'class' => 'form-control styl',
			'autocomplete'=>'off',				
			),			 
             
         ));
         
		 
         		 
		 
		
		
		


         
     }
 }