<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class IndexForm extends Form
{	
    public function __construct($name=null){
       parent::__construct('searchForm');
	   $this->addFromElement();
	   $this->addInputFilter();
    }
	
    public function addFromElement(){

        $this->add(array(
            'name' => 'search',
            'type' => 'text',
            'attributes'=>array(
                'id'=>'search_data',
                'autocomplete'=>  'off',
                'placeholder'=>STR_GATEWAY_OR_GROUP_NAME,
            ),
        ));


        $this->add(array(
            'name' => 'searchBtn',
            'type' => 'submit',
            'attributes' => array(
                'value' => 'Search',
                'id'    => 'serverBtn',
            ),
        ));

    }
    
    function addInputFilter(){
        $inputFilter = new InputFilter();	   
        $inputFilter->add(array(
            'name' => 'search',
            'required' => false,
        ));
    }
    
}