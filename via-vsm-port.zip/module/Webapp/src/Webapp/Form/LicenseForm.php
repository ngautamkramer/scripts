<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;


class LicenseForm extends Form
 {
	  public function __construct()
     {
		parent::__construct('licenseFileForm');
         $this->add(array(
             'name' => 'licensefile',
			'attributes' => array(
			'type' => 'file',
			'id'   => 'licensefile',
			'class' => 'pointer',
			),			 
           ));
		   
		   //for submit
         $this->add(array(
             'name' => 'updateGatewayBtn',
             'type' => 'submit',
             'attributes' => array(
                 'value' => 'Upload',
                 'id' => 'updateGatewayBtn',
				 'class'=>'btn btn-viablue makeDisabled',
				 'style'=>'float: right',
             ),
         ));
	 }
 }