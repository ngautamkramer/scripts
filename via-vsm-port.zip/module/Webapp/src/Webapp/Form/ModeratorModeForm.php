<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class ModeratorModeForm extends Form
{	
 public function __construct($name=null)
  {
       parent::__construct('moderatormodeform');
		$this->addFromElement();
    }
	
	function addFromElement()
	{
		 $this->add(array(
            'name' => 'checkPmode',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'checkPmode',
            ),
           ));
	
			 $this->add(array(
            'name' => 'file_strOUGroup',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'file_strOUGroup',
            ),
           ));
		
		 $this->add(array(
            'name' => 'file_strADSettings',
            'type' => 'hidden',
			 'attributes' =>array(
                'id'    => 'file_strADSettings',
            ),
           ));
		   
		    $this->add(array(
            'name' => 'pollTabVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'pollTabVal',
            ),
           ));

	 $this->add(array(
            'name' => 'pmodeFileData',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'pmodeFileData',
            ),
           ));


		$this->add(array(
            'name' => 'check_viagoFile',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'check_viagoFile',
            ),
           ));

			$this->add(array(
            'name' => 'chatStatus',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'chatStatus',
            ),
           ));
      $this->add(array(
            'name' => 'mobileChatStatus',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'mobilechatStatus',
            ),
           ));
		   
		   
		   $this->add(array(
            'name' => 'gatewayChatStatus',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'gatewayChatStatus',
            ),
           ));
		   
		   $this->add(array(
            'name' => 'chatFileVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'chatFileVal',
            ),
           ));
		   
		   
		    $this->add(array(
            'name' => 'hq_AuthSetting',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'selAuthSettingOption',
            ),
           ));

			$this->add(array(
            'name' => 'alphanumericVal',
            'type' => 'hidden',
			 'attributes' =>array(
                'id'    => 'alphanumericVal',
            ),
           ));

		$this->add(array(
            'name' => 'specialCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'specialCharVal',
            ),
           ));

			$this->add(array(
            'name' => 'capitalLtrVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'capitalLtrVal',
            ),
           ));


		$this->add(array(
            'name' => 'minCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'minCharVal',
            ),
           ));
		   
		   	 $this->add(array(
            'name' => 'basicModeVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'basicModeVal',
            ),
           ));
		   
			   	 $this->add(array(
            'name' => 'presentationMode',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'presentationMode',
            ),
           ));
		
		
	$this->add(array(
             'type' => 'Zend\Form\Element\Checkbox',
             'name' => 'presentationMode',
		 	     'attributes' =>array(
                'id'    => 'presentationMode',
				'class'=>'chkboxAuthentiCation ',
            ),
             'options' => array(
             'label' => STR_ACTIVE_DIRECTORY_MODE,
			  'label_attributes' => array(
            'class'  => 'prevent-default',
        ),
            ),
           
        ));


		
			$this->add(array(
             'type' => Element\Checkbox::class,
             'name' => 'activateChatChkbox',
			 	     'attributes' =>array(
                'id'    => 'activateChatChkbox',
				'class'=>'activateClass1',
            ),
             'options' => array(
             'label' => STR_MODERATOR_CHAT_ENABLE_DISABLE,
			 			  'label_attributes' => array(
            'class'  => 'prevent-default',
        ),
            ),
           
        ));
		
		
		
		
		 $this->add(array(
        'name' => 'radioBtn',
        'type' => 'radio',
				'attributes'=>array(
			'id'=>'radioBtn',
			'class'=>'radioBtnChk',
			
			
			),
        'options' => array(
        'label_attributes' => array(
             'class' => 'control-label col-md-2 prevent-default',
        ),
        'value_options' => array(
        array(
        'value' => '1',
        'label' => BTN_DATABASE_BASSED,
        'label_attributes' => array('class' => 'radio-inline radioBtnChk prevent-default',),
        ),
		
		array(
        'value' => '2',
        'label' => BTN_ACTIVE_DIRECTORY,
        'label_attributes' => array('class' => 'radio-inline adBased radioBtnChk prevent-default',),
        ),
		
			
		array(
        'value' => '3',
        'label' => STR_SIMPLE_PMODE_BTN,
        'label_attributes' => array('class' => 'radio-inline radioBtnChk' ,),
        ),
		
        ),
        ),
        'attributes' =>array(
        'value' => '1' 
        )
        ));
		
		$this->add(array(
             'type' => Element\Checkbox::class,
             'name' => 'participantConfChkbox',
			 	     'attributes' => array(
                'id'    => 'participantConfChkbox',
				'class'=>'activateClass1',
            ),
             'options' => array(
             'label' => STR_PARTICIPANT_CONF,
			 			  'label_attributes' => array(
            'class'  => 'prevent-default',
        ),
            ),
           
        ));
		
		$this->add(array(
             'type' => Element\Checkbox::class,
             'name' => 'disableAllFeaturesChkbox',
			 	     'attributes' => array(
                'id'    => 'disableAllFeaturesChkbox',
				'class'=>'activateClass1',
            ),
             'options' => array(
             'label' => STR_DISABLE_MODERATOR_FEATURE,
            ),
           
        ));
		
		        $this->add(array(
         'name' => 'activatepolling',
        'type' => 'radio',
       'attributes' =>array(
                'id'    => 'activatepolling',
        ),
       'options' => array(
            'label' => STR_ACTIVATE_EPOLLING,
             'label_attributes' => array(
               
                ),
            'value_options' => array(
            array(
                        'value' => '1',
                        'label' => 'ON',
                        'label_attributes' => array('class' => 'btn btn-default btn-on pollingcss ','id'=>'labelYes','data-toggle'=>'on'),
			),
                array(
                        'value' => '0',
                        'label' => 'OFF',
                          'label_attributes' => array('class' => 'btn btn-default btn-off active pollingcss','id'=>'labelNo','data-toggle'=>'off'),
                    ),
                    ),
        ),
         'attributes' => array(
                'value' => '0' //set selected to '0'
            )
    ));
	
		$this->add(array(
            'name' => 'adDomain',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'adDomain',
			'autocomplete'=>  'off',
			),
            'options' => array(
                'label' => STR_ACTIVE_DIRECTORY_DOMAIN,
            ),
        ));
	
	
	
	
	 $this->add(array(
        'name' => 'accRadioBtn',
        'type' => 'radio',
				'attributes'=>array(
			'id'=>'accRadioBtn',
			
			),
        'options' => array(
        'label_attributes' => array(
             'class' => 'control-label col-md-2',
        ),
        'value_options' => array(
        array(
        'value' => '1',
        'label' => STR_USER_PRINCIPAL_NAME,
        'label_attributes' => array('class' => 'radio-inline accRadioBtncss ',),
        ),
		
		array(
        'value' => '0',
        'label' => STR_SAM_ACCOUNT_NAME,
        'label_attributes' => array('class' => 'radio-inline accRadioBtncss',),
        ),
		
        ),
        ),
        'attributes' =>array(
        'value' => '0' 
        )
        ));
	
	
	$this->add(array(
        'name' => 'adRadioBtn',
        'type' => 'radio',
				'attributes'=>array(
			'id'=>'adRadioBtn',
			
			),
        'options' => array(
        'label_attributes' => array(
             'class' => 'control-label col-md-2',
        ),
        'value_options' => array(
        array(
        'value' => '1',
        'label' => BTN_GROUP_BASSED,
        'label_attributes' => array('class' => 'radio-inline  prevent-default',),
        ),
		
		array(
        'value' => '2',
        'label' => BTN_OU_BASSED,
        'label_attributes' => array('class' => 'radio-inline prevent-default',),
        ),
		
        ),
        ),
       
        ));

			$this->add(array(
            'name' => 'adModerator',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'adModerator',
			'autocomplete'=>  'off',
			),
            'options' => array(
                'label' =>STR_MODERATOR,
            ),
        ));
		
		$this->add(array(
            'name' => 'adParticipant',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'adParticipant',
			'autocomplete'=>  'off',
			),
            'options' => array(
			'label' => STR_PARTICIPANT,
            ),
        ));
		
		
			$this->add(array(
            'name' => 'password',
            'type' => 'password',
			'attributes'=>array(
			'id'=>'password',
			'autocomplete'=>  'off',
			),
            'options' => array(
			'label' => STR_PASSWORD,
            ),
        ));
		
		
		
		
			 $this->add(array(
            'name' => 'serverActionResetBtn',
            'type' => 'submit',
            'attributes' => array(
                'value' => 'Reset VIA Session',
                'id'    => 'serverActionResetBtn',
            ),
        ));
	
	}
}