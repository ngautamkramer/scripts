<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class CertificateForm extends Form
{	
 public function __construct()
  {
       parent::__construct('uploadCertificateFrm');
            $this->addInputFilter();
       
            $this->add(array(
                'name' => 'certificateCertFile',
                'attributes' => array(
                    'type'  => 'file',
                    'id' => 'certificateCertFile',
                    'class'=>'pointer',
                    'accept' => ".crt"
                ),
            )); 
            
            $this->add(array(
                'name' => 'certificateKeyFile',
                'attributes' => array(
                    'type'  => 'file',
                    'id' => 'certificateKeyFile',
                    'class'=>'pointer',
                    'accept' => ".key"
                ),
            ));
            
	}
    
            
	
	function addInputFilter() {
                $inputFilter = new InputFilter();        
                $this->setInputFilter($inputFilter); 
	}
}