<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class RecordingForm extends Form {

	public function __construct($name = null) {
		parent::__construct('recordingform');
		$this->addFromElement();
	}

	function addFromElement() {
		$this->add(array(
            'name' => 'sessionname',
            'type' => 'text',
			     'attributes' => array(
                'id'    => 'sessionname',
				'autocomplete'=>  'off',
			
            ),
         
        ));
		
			$this->add(array(
            'name' => 'description',
            'type' => 'textarea',
			     'attributes' => array(
                'id'    => 'description',
				'autocomplete'=>  'off',
				'cols'=>"35",
				'rows'=>"4",
            ),
         
        ));
		
				$this->add(array(
            'name' => 'search',
            'type' => 'text',
			     'attributes' => array(
                'id'    => 'search',
				'autocomplete'=>  'off',
            ),
         
        ));
		
	}
}
