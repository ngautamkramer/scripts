<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class RegisterUnitForm extends Form {

    public function __construct($name = null) {
		parent::__construct('registerunitform');
		$this->addFromElement();
    }
    function addFromElement() {
		$this->add(array(
            'name' => 'txtRegEmail',
            'type' => 'text',
			     'attributes' => array(
                'id'    => 'txtRegEmail',
				'autocomplete'=>  'off',
            ),
         
        ));

        $this->add(array(
            'name' => 'txtRegPassword',
            'type' => 'password',
			     'attributes' => array(
                'id'    => 'txtRegPassword',
				'autocomplete'=>  'off',
            ),
        ));
    }

}