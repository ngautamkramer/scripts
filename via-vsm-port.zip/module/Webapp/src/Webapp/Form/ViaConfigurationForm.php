<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
/**
 * Description of AlbumForm
 *
 * @author suleymanmelikoglu
 */
class ViaConfigurationForm extends Form
 {//$timezoneArray = null,$mirrorFile_data = null,$mirrorArr = null,$layoutArr = null,$wpglanguage = null,$dpiFileValue = null,$autoPowerOffData = null,$autoRebootData = null,$show_date_format = null,$clearCloud = null,$audioConfigArr = null,$defaultAudioVal,$streamFormData,$proxyDataArr
     public function __construct($formData)
     {
	 parent::__construct('viaConfiguration');
         $uiScaling = array(96=>'Normal',120=>'Large');
         $dateTimeFormat = array('Y-m-d H:i:s'=>'Y-m-d HH:MM:SS','Y-m-d h:i A'=>'Y-m-d HH:MM AM/PM','d-m-Y H:i:s'=>'d-m-Y HH:MM:SS','d-m-Y h:i A'=>'d-m-Y HH:MM AM/PM');         
         for($hours=0; $hours <24;  $hours++){ 
            if($hours <10 ){
                    $hours = "0{$hours}";
            }
            $hoursArray[$hours] = $hours;
         }
         
         for($minutes=0; $minutes < 60; $minutes++){
            if($minutes <10 ){
                    $minutes = "0{$minutes}";
            }
            $minutesArray[$minutes] = $minutes;
         }
        // list($hh,$mm)=explode(':',$formData['autoPowerOffData']);
       //  list($autoRebootHours,$autoRebootMints)=explode(':',$formData['autoRebootData']);
         $defaultAudioArr=array('10'=>10,'20'=>20,'30'=>30,'40'=>40,'50'=>50,'60'=>60,'70'=>70,'80'=>80,'90'=>90,'100'=>100);
         $hdmiInputNotStart='checked';	
         $uiScaling = array(96=>'Normal',120=>'Large');
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'sysLog',
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'chkbox makeDisabled',
                    'id'=>'sysLog',
                    'rel'=>'sysLog',
                    'rev'=>'sysLog',
                    //'checked' => $sysLog,
                )
         ));
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'activateEnergySaver',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'chkbox makeDisabled',
                    'id'=>'activateEnergySaver',
                    'rel'=>'activateEnergySaver',
                    'rev'=>'activateEnergySaver',
                    //'checked' => $activateEnergySaver,
                )
         ));
		 
        $this->add(array(
             'name' => 'sleepTime',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'sleepTime',
                    'class' => 'form-control m-b makeDisabled styl',
                    'value' => $formData['sleepArr']['sel'],
             ),
             'options' => array(
                 'options' => $formData['sleepArr']['option'],
             ),
         ));
		 
		 
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'quickClientAccess',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'chkbox makeDisabled',
                    'id'=>'quickClientAccess',
                    'rel'=>'quickClientAccess',
                    'rev'=>'quickClientAccess',
                    //'checked' => $quickClientAccess,
                )
         ));
		 
        $this->add(array(
             'name' => 'setLang',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'setLang',
                    'class' => 'form-control m-b makeDisabled styl',
                    'value' => $formData['langArr']['sel'],
             ),
             'options' => array(
                 'options' => $formData['langArr']['option'],
             ),
         ));
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'hdmiInputNotStart',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                ),
                'attributes' => array(
                    'class'=>'chkbox makeDisabled',
                    'id'=>'hdmiInputNotStart',
                    'rel'=>'hdmiInputNotStart',
                    'rev'=>'hdmiInputNotStart',
                    //'checked'=>$hdmiInputNotStart,
                )
         ));
		 
		$this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'pipMode',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                ),
                'attributes' => array(
                    'class'=>'chkbox makeDisabled',
                    'id'=>'pipMode',
                    'rel'=>'pipMode',
                    'rev'=>'pipMode',
                   // 'checked'=>$pipMode,
                )
         ));		 
 
          $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'activateHDMIChkbox',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'activateHDMIChkbox makeDisabled',
                    'id'=>'activateHDMIChkbox',
                    'rel'=>'activateHDMIChkbox',
                    'rev'=>'activateHDMIChkbox',
                    //'checked' => $activateHDMIChkbox,
                )
         ));
 
          $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'activateDNDChkbox',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'chkbox makeDisabled',
                    'id'=>'activateDNDChkbox',
                    'rel'=>'activateDNDChkbox',
                    'rev'=>'activateDNDChkbox',
                    //'checked' => $activateDNDChkbox,
                )
         ));
 
         //datetime
        $this->add(array(
             'name' => 'selhoursdd',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selhoursdd',
                    'class' => 'form-control m-b autopoweroffCss makeDisabled styl',
                    'value' => $formData['power_off_Hours'],
             ),
             'options' => array(
                 'options' => $hoursArray,
             ),
         ));
        
        $this->add(array(
             'name' => 'selminsdd',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selminsdd',
                    'class' => 'form-control m-b autopoweroffCss makeDisabled styl',
                    'value' => $formData['power_off_Mints'],
             ),
             'options' => array(
                 'options' => $minutesArray,
             ),
         ));
        
        $this->add(array(
             'name' => 'selAutoRebootHoursList',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selAutoRebootHoursList',
                    'class' => 'form-control m-b autoRebootOffCss makeDisabled styl',
                    'value' => $formData['power_Reboot_Hours'],
             ),
             'options' => array(
                 'options' => $hoursArray,
             ),
         ));
        
        $this->add(array(
             'name' => 'selAutoRebootMinsList',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selAutoRebootMinsList',
                    'class' => 'form-control m-b autoRebootOffCss makeDisabled styl',
                    'value' => $formData['power_Reboot_Mints'],
             ),
             'options' => array(
                 'options' => $minutesArray,
             ),
         ));

        $this->add(array(
             'name' => 'selDateFormatDD',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selDateFormatDD',
                    'class' => 'form-control m-b makeDisabled styl',
                    'value' => $formData['date_time_format'],
             ),
             'options' => array(
                 'options' => $dateTimeFormat,
             ),
         ));
        
        $this->add(array(
             'name' => 'timezoneConfigBox',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'timezoneConfigBox',
                    'class' => 'form-control m-b advConfigBox makeDisabled styl',
                    'value' => $formData['linuxTimezoneData']['sel'],
             ),
             'options' => array(
                 'options' => $formData['linuxTimezoneData']['option'],
             ),
         ));
		 
        $this->add(array(
             'name' => 'winTimezoneConfigBox',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'winTimezoneConfigBox',
                    'class' => 'form-control m-b advConfigBox makeDisabled styl',
                    'value' => $formData['windowsTimezoneData']['sel'],
             ),
             'options' => array(
                 'options' => $formData['windowsTimezoneData']['option'],
             ),
         ));
		 
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'clearCloud',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'advChkbox advMakeDisabled makeDisabled',
                    'id'=>'clearCloud',
                   // 'checked' => $clearCloudChk,
                )
         ));
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'activateChatChkbox',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'activateClass1',
                    'id'=>'activateChatChkbox',
                   // 'checked' => $clearCloudChk,
                )
         ));
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'participantConfChkbox',		
                'options' => array(            
                    'value_options' => 1,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'activateClass1',
                    'id'=>'participantConfChkbox',
                   // 'checked' => $clearCloudChk,
                )
         ));
		 
			
        $this->add(array(
             'name' => 'setDynamicLayout',
             'type' => 'Select',
             'attributes' => array(
                'id' => 'setDynamicLayout',
                'class' => 'form-control m-b makeDisabled styl',
                'value' => $formData['displayLayoutArr']['sel'],
             ),
             'options' => array(
                'value_options' => $formData['displayLayoutArr']['option'],
				
             ),
         ));
		 
         $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'dynamicLayoutChkbox',		
                'options' => array(            
                    'value_options' => 1,//CHECK_FILE_DYNAMICLAYOUT,
                    'use_hidden_element' => false,
                    'checked_value' => '0',
                    'unchecked_value' => '1',
                ),
                'attributes' => array(
                    'class'=>'activateClass makeDisabled',
                    'id'=>'dynamicLayoutChkbox',
                    'rel'=>'dynamicLayoutChkbox',
                    'rev'=>'dynamicLayoutChkbox',
                    //'checked' => $dynamicLayoutChkbox,
                )
         ));
 
         $this->add(array(
             'name' => 'dpiConfigBox',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'dpiConfigBox',
                    'class' => 'form-control m-b advConfigBox makeDisabled styl',
                    'value' => $formData['dpiFileValue'],
             ),
             'options' => array(
                 'options' => $uiScaling,
             ),
         ));
        
		 $this->add(array(
             'name' => 'logoutTime',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'logoutTime',
                    'class' => 'form-control m-b advConfigBox makeDisabled styl',
                    'value' => $formData['logout_time'],
             ),
             'options' => array(
                 'options' =>$formData['sessionTimeOutArray']['option'],
             ),
         ));

            $this->add(array(
                'name' => 'minimumChar',
                'type' => 'text',
                'attributes' => array(
                   'id' => 'minimumChar',
                   'class' => 'form-control styl makeDisabled',
                   'autocomplete'=>'off',
                   'value' =>$formData['password_length'],// $cmplxSettings['minimumchar'],
				   'maxlength' => '2',
                ), 
            ));


        $this->add(array(
             'name' => 'selAutoPowerOnHoursList',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selAutoPowerOnHoursList',
                    'class' => 'form-control m-b autoViaPowerOffCss makeDisabled styl',
                    'value' => $formData['power_on_Hours'],
             ),
             'options' => array(
                 'options' => $hoursArray,
             ),
         ));
        
        $this->add(array(
             'name' => 'selAutoPowerOnMinsList',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'selAutoPowerOnMinsList',
                    'class' => 'form-control m-b autoViaPowerOffCss makeDisabled styl',
                    'value' => $formData['power_on_Mints'],
             ),
             'options' => array(
                 'options' => $minutesArray,
             ),
         ));

		 //Audio Input Device
        $this->add(array(
             'name' => 'audioOutputConfigBox',
             'type' => 'Select',
             'attributes' => array(
                'id' => 'audioOutputConfigBox',
                'class' => 'form-control m-b makeDisabled styl',
                'value' => $formData['audioOutputArr']['sel'],
             ),
             'options' => array(
                'value_options' => $formData['audioOutputArr']['option'],
				
             ),
         ));
		 
         $this->add(array(
             'name' => 'setDefaultAudioLevel',
             'type' => 'Select',
             'attributes' => array(
                    'id' => 'setDefaultAudioLevel',
                    'class' => 'form-control m-b makeDisabled styl',
                    'value' => $formData['audiolevelArr']['sel'],
             ),
             'options' => array(
                 'value_options' => $formData['audiolevelArr']['option'],
             ),
         ));

     }
     
     function addInputFilter()
     {
        $inputFilter = new InputFilter();        
        $this->setInputFilter($inputFilter);
       /* $inputFilter->add(array(
            'name' => 'mirrorName',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),  
            ),
            'validators' =>array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'break_chain_on_failure' => true,
                    ),
                   
                ),
             array(
                'name' => 'Regex', 
                'options' =>  array('pattern' =>'/^[a-zA-Z0-9._(), {}\-\/\r\n]+$/'),
             ),
            ),
        ));*/
		
        	 
        /*$inputFilter->add(array(
            'name' => 'maxNoOfMirrors',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class), 
            ),
            'validators' => array(
             array(
                    'name' => 'NotEmpty',
                   
                ),
            ),
        ));
        */
       /* $inputFilter->add(array(
            'name' => 'proxyServerName',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),  
            ),
            'validators' =>array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'break_chain_on_failure' => true,
                    ),
                   
                ),
             array(
                'name' => 'Regex', 
                'options' =>  array('pattern' =>'/^[^\s]+$/'),
             ),
            ),
        ));*/
        
        /*$inputFilter->add(array(
            'name' => 'proxyPort',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),  
            ),
            'validators' =>array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'break_chain_on_failure' => true,
                    ),
                   
                ),
             array(
                'name' => 'Regex', 
                'options' =>  array('pattern' =>'/^([0-9]{1,4}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$/'),
             ),
            ),
        ));
        */
        
     }
 }