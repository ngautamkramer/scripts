<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class SettingsForm extends Form
{

    public function __construct($sessionTimeOutArray = null,$sessionVal = null,$cmplxSettings=null)
    {
         parent::__construct('setting');
             
         
              $this->add(array(
                  'name' => 'logoutTime',
                  'type' => 'Select',
                  'attributes' => array(
                     'id' => 'logoutTime',
                     'class' => 'form-control m-b makeDisabled',
                     'value' => $sessionVal['logoutTime'],
                  ),
                  'options' => array(
                     'value_options' => $sessionTimeOutArray,
                  ),
              ));
				$this->add(array(
                'name' => 'minimumChar',
                'type' => 'text',
                'attributes' => array(
                   'id' => 'minimumChar',
                   'class' => 'form-control m-b styl makeDisabled',
                   'autocomplete'=>'off',
                   'value' => $cmplxSettings['minimumchar'],
                ), 
            ));	
            
            // $this->add(array(
            //     'name' => 'frequencyalert',
            //     'type' => 'Select',
            //     'attributes' => array(
            //        'id' => 'frequencyalert',
            //        'class' => 'form-control m-b makeDisabled',
            //        'value' => $sessionVal['frequencyAlert'],
                   
            //     ),
            //     'options' => array(
            //        'value_options' => $fequencyAlertArray,
            //     ),
            // ));

            $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'selAllHQ',   
                'options' => array(
                    'use_hidden_element' => false,
                ),
                'attributes' => array(
                    'class'=>'chkAllHQmaster',
                    'id'=>'selAllHQ',
                    'checked'=>'checked',
                )
            ));
            
            $this->add(array(
                'type' => 'Zend\Form\Element\Checkbox',
                'name' => 'selAllLocal',    
                'options' => array(
                    'use_hidden_element' => false,
                ),
                'attributes' => array(
                    'class'=>'chkAllHQmaster',
                    'id'=>'selAllLocal',
                    'checked'=>'',
                )
            ));
    }
}