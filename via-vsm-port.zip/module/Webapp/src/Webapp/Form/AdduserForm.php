<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;


class AdduserForm extends Form
 {//$name = null
     public function __construct()
     {
	 
	 parent::__construct('adduser');
		//CSRF token code(Added date 20-july-2020)
		$this->add(array(
			'type' => 'Zend\Form\Element\Csrf',
			'name' => 'secret',
			'options' => array(
				'csrf_options' => array(
					'timeout' => 600
				)
			)
		));
         	$this->add(array(
			'name' => 'usermode',
			'attributes' => array(
			'type' => 'hidden',
			'id'   => 'usermode',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
             
         ));
         	$this->add(array(
			'name' => 'userid',
			'attributes' => array(
			'type' => 'hidden',
			'id'   => 'userid',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
             
         ));
	 
	 	 
         	$this->add(array(
			'name' => 'txtUserId',
			'attributes' => array(
			'type' => 'text',
			'id'   => 'txtUserId',
			'class' => 'form-control styl',
			'autocomplete'=>'off',
			'maxlength' => 25
			),			 
             
         ));
		 
		 $this->add(array(
			'name' => 'txtEmail',
			'attributes' => array(
			'type' => 'text',
			'id'   => 'txtEmail',
			'class' => 'form-control styl',
			'autocomplete'=>'off',				
			),			 
             
         ));
		 
         $this->add(array(
             'name' => 'txtPassword',
			'attributes' => array(
			'type' => 'password',
			'id'   => 'txtPassword',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
         ));
		 
         $this->add(array(
             'name' => 'txtConfirmPassword',
			'attributes' => array(
			'type' => 'password',
			'id'   => 'txtConfirmPassword',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
         ));		 
		 
		$this->add(array(
			'type' => 'Zend\Form\Element\Checkbox',
			'name' => 'chkAdministrator',			
			'options' => array(
				//'label' => 'Web Administrator',
				//'use_hidden_element' => true,
				'checked_value' => 1,
				'unchecked_value' => 0
			),
			'attributes' => array(
				'id' => 'chkAdministrator',
				//'checked'=>$isAdmin,
				'class'=>'chkAdministratorClass',
				
			)

		));
		
		$this->add(array(
			'type' => 'Zend\Form\Element\Checkbox',
			'name' => 'audianceResponse',			
			'options' => array(
				//'label' => 'Web Administrator',
				//'use_hidden_element' => true,
				'checked_value' => 40,
				'unchecked_value' => 0
			),
			'attributes' => array(
				'id' => 'audianceResponse',
				'checked'=>$isPoll,
				'class'=>'makedisabled',
			)
		));
		
		$this->add(array(
			'type' => 'Zend\Form\Element\Checkbox',
			'name' => 'dss',			
			'options' => array(
				//'label' => 'Web Administrator',
				//'use_hidden_element' => true,				
				'checked_value' => 41,
				'unchecked_value' => 0
			)	,		
			'attributes' => array(
				'id' => 'dss',
				//'checked'=>$isDSS,
				'class'=>'makedisabled',
			)

		));
		
		$this->add(array(
            'name' => 'alphanumericVal',
            'type' => 'hidden',
			 'attributes' =>array(
                'id'    => 'alphanumericVal',
            ),
           ));

		$this->add(array(
            'name' => 'specialCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'specialCharVal',
            ),
           ));

			$this->add(array(
            'name' => 'capitalLtrVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'capitalLtrVal',
            ),
           ));


		$this->add(array(
            'name' => 'minCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'minCharVal',
            ),
           ));
		   
		   	 $this->add(array(
            'name' => 'basicModeVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'basicModeVal',
            ),
           ));



         $this->add(array(
             'name' => 'submit',
             'type' => 'button',
             'attributes' => array(
                 'value' => 'Save',
                 'id' => 'submitbutton',
				 'class'=>'newBtnClass',
             ),
         ));
     }
 }