<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class ResetPasswordForm extends Form {

    public function __construct($name = null) {
		parent::__construct('resetpassform');
		$this->addFromElement();
    }

    function addFromElement() {
		$this->add(array(
            'name' => 'txtNewPassword',
            'type' => 'password',
			     'attributes' => array(
                'id'    => 'txtNewPassword',
				'autocomplete'=>  'off',
            ),
         
        ));

        $this->add(array(
            'name' => 'txtConNewPassword',
            'type' => 'password',
			     'attributes' => array(
                'id'    => 'txtConNewPassword',
				'autocomplete'=>  'off',
            ),
        ));
        $this->add(array(
            'name' => 'alphanumericVal',
            'type' => 'hidden',
			 'attributes' =>array(
                'id'    => 'alphanumericVal',
            ),
           ));

		$this->add(array(
            'name' => 'specialCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'specialCharVal',
            ),
           ));

			$this->add(array(
            'name' => 'capitalLtrVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'capitalLtrVal',
            ),
           ));


		$this->add(array(
            'name' => 'minCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'minCharVal',
            ),
           ));
		   
           $this->add(array(
            'name' => 'checkOldPassVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'checkOldPassVal',
            ),
           ));



        $this->add(array(
            'name' => 'btnReset',
            'type' => 'Submit',
            'attributes' => array(
                'value' => 'Reset',
                'class' => 'btnReset btn btn-viablue btn-s-xs',
                'id'    => 'btnReset'
            ),
        ));
    }



}