<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class UserActivityLogForm extends Form
{	
 public function __construct($name=null)
  {
       parent::__construct('useractivitylogform');
	   $this->addFromElement();
	   $this->addInputFilter();
    }
	
	public function addFromElement()
	{
		$this->add(array(
            'name' => 'startdate',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'startdate',
			'autocomplete'=>  'off',
			),
            'options' => array(
                'label' => 'Start Date',
            ),
        ));
		
		$this->add(array(
            'name' => 'enddate',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'enddate',
			'autocomplete'=>  'off',
			),
            'options' => array(
                'label' => 'Start Date',
            ),
        ));
		
	    $this->add(array(
            'name' => 'search',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'search_data',
			'autocomplete'=>  'off',
			),
        ));
		
		   $this->add(array(
            'name' => 'exportpdf',
            'type' => 'submit',
			'attributes'=>array(
			'id'=>'exportpdf',
             'value' => EXPORT_TO_PDF_BTN,
			),
        ));
		
		$this->add(array(
            'name' => 'exportcsv',
            'type' => 'submit',
			'attributes'=>array(
			'id'=>'exportcsv',
             'value' => EXPORT_TO_CSV_BTN,
			),
        ));
		
		
			$this->add(array(
            'name' => 'searchBtn',
            'type' => 'submit',
            'attributes' => array(
                'value' => 'Search',
                'id'    => 'serverBtn',
            ),
        ));
		
	}
		function addInputFilter()
		{
		   $inputFilter = new InputFilter();        
		   $this->setInputFilter($inputFilter);
		   	 $inputFilter->add(array(
            'name' => 'startdate',
            'required' => false,
			));
			$inputFilter->add(array(
            'name' => 'enddate',
            'required' => false,
			));
			$inputFilter->add(array(
            'name' => 'search',
            'required' => false,
			));
		}
}