<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class AppVersionForm extends Form {

	public function __construct($name = null) {
		parent::__construct('appversionform');
		$this->addFromElement();
	}

	function addFromElement() {
		    if(PRODUCT=='via'){
				$id='versionsearchVia';
			}else{
				$id='versionsearch';
			}
			$this->add(array(
            'name' => $id,
            'type' => 'text',
					     'attributes' => array(
                'id'    => $id,
				'autocomplete'=>  'off',
            ),
      
        ));
		
		 $this->add(array(
            'name' => 'exportpdf',
            'type' => 'submit',
			'attributes'=>array(
			'id'=>'exportpdf',
             'value' => 'Export to PDF',
			),
        ));
	}
}
