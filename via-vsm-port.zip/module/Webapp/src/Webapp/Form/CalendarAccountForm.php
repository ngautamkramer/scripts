<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class CalendarAccountForm extends Form
{	
 public function __construct($getExchageVersionArr=null)
  {
       parent::__construct('calendarAccount');
		$this->addFromElement($getExchageVersionArr);
		$this->addInputFilter();
    }
	function addFromElement($getExchageVersionArr)
	{
		$calTypeArr = array("msexchange"=>STR_MS_EXCHANGE,"google"=>STR_GOOGLE,"office365auth2"=>STR_OFFICE365);
		$permissionTypeArr = array(0=>STR_ATD_NONE,1=>STR_IMPERSONATION,2=>STR_DELEGATE);
	    $this->add(array(
			 'name' => 'calType',
			 'attributes' => array(			
			 'id'   => 'calType',
			 'class' => 'form-control m-b styl',									
				'options' =>$calTypeArr,
			 ),	
			 'type' => 'select',		 
			 'options' => array(
				 'label' => STR_CALENDAR_TYPE,
				 'class' => 'ddlabelCss',
			 ),
		 ));
		 
		$this->add(array(
            'name' => 'caluserid',
            'type' => 'text',
			     'attributes' => array(
                'id'    => 'caluserid',
				'autocomplete'=>  'off',
				'maxlength' => '50',
				'class' => "form-control styl"
            ),
            'options' => array(
                //'label' => STR_WEBADMIN_USERNAME,
            ),
        ));
		
		$this->add(array(
            'name' => 'caluserpass',
            'type' => 'password',
			'attributes' => array(
                'id'    => 'caluserpass',
				'autocomplete'=>  'off',
				'maxlength' => '50',
				'class' => "form-control styl"
            ),
            'options' => array(
                //'label' => STR_PASWORD,
            ),
        ));
		
		 $this->add(array(
			 'name' => 'access_type',
			 'attributes' => array(			
			 'id'   => 'access_type',
			'class' => "form-control m-b styl",								
				'options' =>$permissionTypeArr,
			 ),	
			 'type' => 'select',		 
			 'options' => array(
				 'label' => STR_PERMISSION_TYPE,
			 ),
		 ));
		 
		 $this->add(array(
            'name' => 'calname1',
            'type' => 'text',
			'attributes' => array(
                'id'    => 'calname1',
				'autocomplete'=>  'off',
				'class' => "form-control styl",
				'disabled' => true
            ),
            'options' => array(
                //'label' => STR_RESOURCE_CALENDAR,
            ),
        ));
		
		 $this->add(array(
            'name' => 'hosturl',
            'type' => 'text',
			'attributes' => array(
                'id'    => 'hosturl',
				'autocomplete'=>  'off',
				'class' => "form-control styl"
            ),
            'options' => array(
                //'label' => STR_EXCHANGE_SERVER_URL,
            ),
        ));
		
		 $this->add(array(
			 'name' => 'exchangeVer',
			 'attributes' => array(			
			 'id'   => 'exchangeVer',
			 'class' => 'form-control m-b styl',									
				'options' =>$getExchageVersionArr,
			 ),	
			 'type' => 'select',		 
			 'options' => array(
				 'label' => STR_MS_EXCHANGE_VERSION,
			 ),
		 ));
		 
		 $this->add(array(
            'name' => 'code',
            'type' => 'text',
			'attributes' => array(
                'id'    => 'code',
				'autocomplete'=>  'off',
				'class' => "form-control styl",
            ),
            'options' => array(
                //'label' => STR_STEP2,
				//'placeholder' =>MSG_ENTER_CODE
            ),
        ));
		
		$this->add(array(
			 'name' => 'selCal',
			 'attributes' => array(			
			 'id'   => 'selCal',
			 'class' => 'form-control m-b stepthree',									
				'options' =>array("Select the calendar"),
			 ),	
			 'type' => 'select',		 
			 'options' => array(
				 'label' => STR_STEP3,
			 ),
		 ));
//added by ashu for office365 auth2
		 $this->add(array(
            'name' => 'office365code',
            'type' => 'textarea',
			'attributes' => array(
                'id'    => 'office365code',
				'autocomplete'=>  'off',
				'class' => "form-control styl",
				'cols'	=> 150,
				'rows'	=> 6,
            ),
            'options' => array(
                //'label' => STR_STEP2,
				//'placeholder' =>MSG_ENTER_CODE
            ),
        ));

		$this->add(array(
			 'name' => 'selOffice365Cal',
			 'attributes' => array(			
			 'id'   => 'selOffice365Cal',
			 'class' => 'form-control m-b stepthree',									
				'options' =>array("Select the calendar"),
			 ),	
			 'type' => 'select',		 
			 'options' => array(
				 'label' => STR_STEP3,
			 ),
		 ));
		 
		 
		$this->add(array(
            'name' => 'officeSubmit',
            'type' => 'submit',
            'attributes' => array(
                'value' => STR_BTN_TEST_SAVE,
              	'id'=>'btnOk',
            ),
        ));
		
	   $this->add(array(
            'name' => 'exchangeSubmit',
            'type' => 'submit',
            'attributes' => array(
                'value' => STR_BTN_TEST_SAVE,
              	'id'=>'btnexchangeOk',
            ),
        ));
	}
	
	function addInputFilter()
	{
		 $inputFilter = new InputFilter();        
		 $this->setInputFilter($inputFilter);
	}
}