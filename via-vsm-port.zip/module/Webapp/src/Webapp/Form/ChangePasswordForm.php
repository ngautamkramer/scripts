<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;


class ChangePasswordForm extends Form
 {//$name = null
     public function __construct()
     {
	 
	 parent::__construct('chnagepassform');
	     	
		 //old password
         $this->add(array(
             'name' => 'txtOldPassword',
			'attributes' => array(
			'type' => 'password',
			'id'   => 'txtOldPassword',
			'class' => 'form-control styl',
			'autocomplete'=>'off',			
			),			 
           ));
		 
		 //new password
         $this->add(array(
             'name' => 'txtNewPassword',
			'attributes' => array(
			'type' => 'password',
			'id'   => 'txtNewPassword',
			'class' => 'form-control styl',
			'autocomplete'=>'off',	
			'data-required'=>'true',
			),			 
           ));
		   
		   //confirm password
         $this->add(array(
             'name' => 'txtConNewPassword',
			'attributes' => array(
			'type' => 'password',
			'id'   => 'txtConNewPassword',
			'class' => 'form-control styl',
			'autocomplete'=>'off',	
			'data-required'=>'true',
			),			 
		   ));
		   
		   $this->add(array(
            'name' => 'alphanumericVal',
            'type' => 'hidden',
			 'attributes' =>array(
                'id'    => 'alphanumericVal',
            ),
           ));

		$this->add(array(
            'name' => 'specialCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'specialCharVal',
            ),
           ));

			$this->add(array(
            'name' => 'capitalLtrVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'capitalLtrVal',
            ),
           ));


		$this->add(array(
            'name' => 'minCharVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'minCharVal',
            ),
           ));
		   
		   	$this->add(array(
            'name' => 'checkOldPassVal',
            'type' => 'hidden',
			 'attributes' => array(
                'id'    => 'checkOldPassVal',
            ),
           ));
		   


		   
		//for submit
         $this->add(array(
             'name' => 'btnOk',
             'type' => 'submit',
             'attributes' => array(
                 'value' => BTN_UPDATE,
                 'id' => 'btnOk',
				 'class'=>'btn btn-viablue btn-s-xs',
             ),
         ));
		 
		 //for reset
		 $this->add(array(
             'name' => 'btnReset',
			'attributes' => array(
			'type' => 'reset',
			'id'   => 'btnReset',
			'class' => 'btn btn-viablue btn-s-xs makeDisabled',
			'value' => 'update',
			'align' => 'right',
			),			 
           ));
     }
 }