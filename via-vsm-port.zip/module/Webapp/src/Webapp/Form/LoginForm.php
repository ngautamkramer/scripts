<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\Form\Element\Captcha;
use Zend\Captcha\Image as CaptchaImage;
/**
 * Description of AlbumForm
 *
 * @author suleymanmelikoglu
 */
class LoginForm extends Form
 {//$name = null
     public function __construct($urlcaptcha = null,$captchaVal='')
     { 
	 parent::__construct('loginfrm');
	    //$dirdata = './data';
		$dirdata = getcwd()."/data";
	     //pass captcha image options
		 if($captchaVal=="" || $captchaVal==1){
			$captchaImage = new CaptchaImage(  array(
					'font' => $dirdata . '/fonts/recaptchaFont.ttf',
					'font' =>getcwd()."/data/fonts/recaptchaFont.ttf",    // TODO path for PHP 7+
					'width' => 140,
					'height' => 55,
					'fontSize'  => 18,
					'dotNoiseLevel' => 7,
					'lineNoiseLevel' => 3)
			);
			$captchaImage->setImgDir($dirdata.'/captcha');
			$captchaImage->setImgUrl($urlcaptcha);
		  }
	  
         	$this->add(array(
			'name' => 'login_name',
			'attributes' => array(
				'type' => 'text',
				'id'   => 'login_name',
				'class' => 'styl inputFldCss',
                //'required' => true,
				'autocomplete'=>  'off',
                'maxlength' => '25',				
			),			 
             
         ));
         $this->add(array(
            'name' => 'login_password',
			'attributes' => array(
					'type' => 'password',
                    'maxlength' => '50',
                    'id'          => 'login_password',
					'class' => 'styl inputFldCss',
                    'autocomplete'=>  'off',
                    //'required' => true					
                  	),			 
         ));
		 if($captchaVal=="" || $captchaVal==1){ 
			  //add captcha element...
			$this->add(array(
				'type' => 'Zend\Form\Element\Captcha',
				'name' => 'captcha',
				'options' => array(
					'captcha' => $captchaImage,
				),
				'attributes' => array(
					'id' => 'captchInput',
					'class' => 'styl inputFldCss',
					'required' => true	,
					'autocomplete'=>  'off',
				)
			));

		}
        $this->add(array(
             'name' => 'submit',
             'type' => 'Submit',
             'attributes' => array(
                 'value' => STR_LOGIN,
                 'class' => 'btnClass purplebtn',
                 'id'    => 'btnLogin'
             ),
         ));
     }
 }