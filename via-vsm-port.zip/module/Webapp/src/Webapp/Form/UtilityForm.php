<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;


class UtilityForm extends Form
 {//$name = null
     public function __construct()
     {
	 
	 parent::__construct('updateFirmwareFrm');
	     	
		 // add file
         $this->add(array(
             'name' => 'userfile',
			'attributes' => array(
			'type' => 'file',
			'id'   => 'userfile',
			'class' => 'pointer',
			),			 
           ));
		 
		 
		   
		//for submit
         $this->add(array(
             'name' => 'updateGatewayBtn',
             'type' => 'submit',
             'attributes' => array(
                 'value' => 'Upload',
                 'id' => 'updateGatewayBtn',
				 'class'=>'btn btn-viablue makeDisabled',
				 'style'=>'float: right',
             ),
         ));
		 
		
     }
 }