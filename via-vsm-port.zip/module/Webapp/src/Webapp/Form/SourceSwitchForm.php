<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;
use Zend\Filter\StringTrim;
use Zend\Filter\StripTags;
use Zend\Filter\ToInt;
class SourceSwitchForm extends Form
{	
 public function __construct($name=null)
  {
       parent::__construct('sourceswitchform');
		$this->addFromElement();
		$this->addInputFilter();
    }
	function addFromElement()
	{
			 $this->add(array(
            'name' => 'tooltip1',
            'type' => 'hidden',
           ));
		   
		     $this->add(array(
            'name' => 'tooltip2',
            'type' => 'hidden',
           ));
		   
			$this->add(array(
            'name' => '  lgsourcefile',
            'type' => 'hidden',
           ));
		   
			$this->add(array(
			'type' => 'Zend\Form\Element\Checkbox',
			'name' => 'lgActivateControl',
			'options' => array(            
			'label' => STR_ACTIVATE_CONTROLLER,
               
			),
			'attributes' => array(
			'id'=>'lgActivateControl',
           
			)
         ));
		
		$this->add(array(
            'name' => 'lgIP',
            'type' => 'text',
			     'attributes' => array(
                'id'    => 'lgIP',
				'autocomplete'=>  'off',
				'maxlength' => '100',
            ),
            'options' => array(
                'label' => STR_DISPLAY_IP,
            ),
        ));
		
		
			$this->add(array(
            'name' => 'lgPort',
            'type' => 'text',
					     'attributes' => array(
                'id'    => 'lgPort',
				'autocomplete'=>  'off',
				'maxlength' => '10',
            ),
            'options' =>array(
                'label' => STR_DISPLAY_CONTROL_PORT,
            ),
        ));
		
		$this->add(array(
            'name' => 'lgSS1',
            'type' => 'text',
			'attributes'=>array(
			'id'=>'lgSS1',
			'autocomplete'=>  'off',
			'maxlength' => '100',
			),
            'options' => array(
                'label' => 'Command 1 (VIA)',
            ),
        ));
		
		$this->add(array(
            'name' => 'lgSS2',
            'type' => 'text',
				'attributes'=>array(
			'id'=>'lgSS2',
			'autocomplete'=>  'off',
			'maxlength' => '100',
			),
            'options' => array(
                'label' => 'Command 2',
            ),
        ));
		
		
		     $this->add(array(
        'name' => 'enctype',
        'type' => 'radio',
			'id'=>'enctype1',
				'attributes'=>array(
			'class'=>'enctype boxEnabled',
			
			),
        'options' => array(
        'label_attributes' => array(
             'class' => 'control-label col-md-2',
        ),
        'value_options' => array(
        array(
        'value' => '0',
        'label' => 'ASCII',
        'label_attributes' => array('class' => 'radio-inline  boxEnabled',
		),
        ),
		
		array(
        'value' => '1',
        'label' => 'Hex',
        'label_attributes' => array('class' => 'radio-inline boxEnabled ',
		),
        ),
		
        ),
        ),
        'attributes' =>array(
        'value' => '0' 
        )
        ));
		
		    $this->add(array(
            'name' => 'lgSubmit',
            'type' => 'submit',
            'attributes' => array(
                'value' => APPLY_BTN,
              	'id'=>'lgSubmit',
            ),
        ));
		
		 $this->add(array(
            'name' => 'serverActionBtn',
            'type' => 'submit',
            'attributes' => array(
                'value' => STR_REBOOT_GATEWAY,
                'id'    => 'serverActionBtn',
            ),
        ));
	}
	
	function addInputFilter()
	{
		 $inputFilter = new InputFilter();        
		 $this->setInputFilter($inputFilter);
		 $inputFilter->add(array(
            'name' => 'lgIP',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),
               
            ),
            'validators' =>array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'messages' => array(
                        'isEmpty' => MSG_IP_REQUIRED,
                    ),
					  'break_chain_on_failure' => true,
                    ),
                   
                ),
								       array(
        'name' => 'Regex', 
        'options' =>  array('pattern' =>'/^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/',
        'messages' => array(
        'regexNotMatch' => MSG_INVALID_IP, 
        ),

        ),
        ),
            ),
        ));
		
		 $inputFilter->add(array(
            'name' => 'lgPort',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),
               
            ),
            'validators' => array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'messages' =>array(
                        'isEmpty' =>MSG_PORT_REQUIRED,
                    ),
					       'break_chain_on_failure' => true,
                    ),
                   
                ),
				     array(
        'name' => 'Regex', 
        'options' =>  array('pattern' =>'/^\+?[0-9(),.-]+$/',
        'messages' => array(
        'regexNotMatch' => MSG_ENTER_NUMERIC_VALUE, 
        ),

        ),
        ),
				
				
            ),
        ));
		 
		  $inputFilter->add(array(
            'name' => 'lgSS1',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),
               
            ),
            'validators' => array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'messages' => array(
                        'isEmpty' => MSG_COMMAND1_REQUIRED,
                    ),
                    ),
                   
                ),
            ),
        ));
		 
		 $inputFilter->add(array(
            'name' => 'lgSS2',
            'required' => true,
            'filters' => array(
                array('name' => StripTags::class),
                array('name' => StringTrim::class),
               
            ),
            'validators' => array(
             array(
                    'name' => 'NotEmpty',
                    'options' => array(
                        'messages' => array(
                        'isEmpty' =>MSG_COMMAND2_REQUIRED,
                    ),
                    ),
                   
                ),
            ),
        ));
		 
	}
}