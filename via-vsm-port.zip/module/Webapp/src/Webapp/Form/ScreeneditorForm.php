<?php
namespace Webapp\Form;
use Zend\Form\Form;
use Zend\Form\Element;
use Zend\InputFilter\InputFilter;
use Zend\InputFilter\ArrayInput;

class ScreeneditorForm extends Form
{	
 public function __construct($name=null)
  {
       parent::__construct('searchFrm');
	   $this->addFromElement();
	   $this->addInputFilter();
    }
	
	public function addFromElement()
	{
	
	    $this->add(array(
            'name' => 'wallpaperSearchBox',
            'type' => 'text',
            'attributes'=>array(
                'id'=>'wallpaperSearchBox',
                'class'=>'form-control search titillium',
                'placeholder'=>(PRODUCT_MODEL_TYPE==0)?SCREEN_EDITOR_SEARCH_TXT:SCREEN_EDITOR_SEARCH_WALLPAPER_TXT,
            ),
        ));
		
            
	}
        
    function addInputFilter(){
        $inputFilter = new InputFilter();        
        $this->setInputFilter($inputFilter);
        $inputFilter->add(array(
            'name' => 'search',
            'required' => false,
        ));
    }
}