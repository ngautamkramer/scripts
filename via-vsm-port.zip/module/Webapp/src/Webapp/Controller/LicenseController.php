<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\LicenseForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\PDF\fpdf;
use Webapp\Controller\WebProducerController;

class LicenseController extends AbstractActionController
{
    public function onDispatch(MvcEvent $e)
    {
        $session = new Container('userinfo');
        $user = $session->offsetGet('LoginName');
        //check session code
        $appObj = new ApplicationController();
        //getting sessionTimeOut value. bydefault value is 10
        $tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
        foreach ($tblSessionTimeOutDataArr as $sessiondata) {
            $getSettingData=$sessiondata['logoutTime'];
        }
        $getSettingData=($getSettingData>0)?$getSettingData:10;
        //now getting session time out based on query and compare
        $qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
        $tblSessionCheckdataArr=$appObj->returnQueryData($qry2);
        if (count($tblSessionCheckdataArr)>0) {
            $updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
            $appObj->executeQueries($updSession);
        } else {
            return $this->redirect()->toRoute('index', array('action' => 'logout'));
        }
        //end check session code
            
        if (empty($user)) {
            // redirect if not
            return $this->redirect()->toRoute('index', array('action' => 'index'));
        }
        return parent::onDispatch($e);
    }

    /*****
     *	@function Name		: licenseDetailsAction
     *  @description	    : Getting details and upload license file for linux
     *	@Author			    : Vineet
     *  @Date               : 30-march-2020
     	@modify				: 23-Dec-2020
    	@modify by			: Ashu
     *****/

    public function licenseDetailsAction()
    {
        if (PRODUCT=='kds') {
            die('Access denied.');
        }
        $request = $this->getRequest();
        $appObj = new ApplicationController();
        $form = new LicenseForm();
        
        /*get total table*/
        $totalTable=$appObj->countTables();
        $tableCount=$totalTable['total'];
        
        if (GET_OS=="LIN" &&  PRODUCT_TYPE=='vsm') {
            $cloudLicenseDataArr=$appObj->returnQueryData("SELECT licmsterid,uniqueid,AES_DECRYPT(orderid,'".POLL_ENCRYPTION_KEY."') AS orderid, no_of_devices, purchase_date, license_validity, license_expiry_date,number_of_lic_used FROM license_master");
        
        //     /*$cloudLicenseDataArr=$this->getLicenseMasterTable()->fetchAll();
        //     //pagination code
        //     $cloudLicenseDataArr->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        //     $cloudLicenseDataArr->setItemCountPerPage(50);
        //     */
         }
        
        $licenseInfo='NA';
        $licenseSr='NA';
        if (CHECK_TOTAL_GATEWAYS==1) {
            $gWayVal=$appObj->file_read(COUNT_GWAY_FILE);
            $allowTotalGateways=$appObj->desDecrypt($gWayVal, KEY_SEED_NEW);
        }
        if (CHECK_FILE_LICENSE_DETAILS==1) {
            $file_licenseDetails=$appObj->file_read(FILE_LICENSE_DETAILS);
            $file_contents=$appObj->desDecrypt($file_licenseDetails, KEY_SEED_NEW);
            $arr=explode("|", $file_contents);
            $licenseInfo=$arr[0];
            $licenseSr=$arr[1];
        }

        $resultData=$this->getBuildInfoTable()->fetchAll();
        $countTotalRows=$resultData->count();
    
    
        /* ******************************************************* */
        //added by ashu on 14/12/2020 for uploading cloud license
        $wifiSecurityFilekey = "1324587099345678";
        //$appObj = new ApplicationController();
        if ($this->getRequest()->isPost()) {
            $postData = $this->getRequest()->getPost()->toArray();
            $licenseFile = $this->params()->fromFiles('licenseFile');
            $licenseFileName = $licenseFile['name'];
            //die(UPLOAD_DIR_ZEND.$licenseFileName);
            $upload = move_uploaded_file($licenseFile['tmp_name'], UPLOAD_DIR_ZEND.$licenseFileName);
            $uploadedFileContent=file_get_contents(UPLOAD_DIR_ZEND.$licenseFileName);
            //decrypt file
            $decrypted = $appObj->desDecrypt($uploadedFileContent, $wifiSecurityFilekey);
            
            //Get Domain
            $url = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];
            $parse = parse_url($url);
            $host = $parse['host'];
            $url_domain = str_ireplace('www.', '', $host);
            
            //explode uploaded file data
            $explode_decrypted_arr=explode("|", $decrypted);
            $file_domain=trim($explode_decrypted_arr[0]);
            $orderId=trim($explode_decrypted_arr[1]);
            $no_of_devices=trim($explode_decrypted_arr[2]);
            $purchase_date=trim($explode_decrypted_arr[3]);
            $license_validity=trim($explode_decrypted_arr[4]);
            $license_file_type=strtolower(trim($explode_decrypted_arr[5]));
            $license_expiry_date_timestamp = strtotime("+$license_validity months", strtotime($purchase_date)); // returns timestamp
            $license_expiry_date =date('Y-m-d', $license_expiry_date_timestamp); // formatted version
            //die($file_domain.' and '.$orderId);
            
            //check order id in database
            //$checkOrderCount =$this->getLicenseMasterTable()->getOrderCount($orderId);
            
            //validate file first param.it may be domain or mac address
            $validate_file_first_param=(filter_var($file_domain, FILTER_VALIDATE_MAC))?'macaddress':'domain';
            if (GET_OS=='WIN') {
                $vsm_macAddress=trim(file_get_contents(DEST_PATH."/macaddress.txt"));
            } else {
                $vsm_macAddress=trim(file_get_contents($_SERVER["DOCUMENT_ROOT"]."/../bin/config/macaddress.txt"));
            }
            
            $checkOrderCount=$appObj->checkTableCount("license_master WHERE AES_DECRYPT(orderid,'".POLL_ENCRYPTION_KEY."')=$orderId");
            $error='';
            if ($validate_file_first_param=='macaddress' && $file_domain!=$vsm_macAddress) {
                //die('domain_error');
                $error='macaddr_error';
                unlink(UPLOAD_DIR_ZEND.$licenseFileName);
            } elseif ($validate_file_first_param=='domain' && $file_domain!=$url_domain) {
                //die('domain_error');
                $error='domain_error';
                unlink(UPLOAD_DIR_ZEND.$licenseFileName);
            } elseif ($checkOrderCount>0) {
                //die('order_error');
                $error='order_error';
            } elseif ($license_file_type=='ds') {
                $error='file_error';
                unlink(UPLOAD_DSS_LICENSE.$licenseFileName);
            } else {
                $uniqueId=substr(md5(microtime()), 0, 5);
                $checkUniqueIdData=$this->getLicenseMasterTable()->checkUniqueId($uniqueId);
                $checkUniqueId = $checkUniqueIdData->count();
            
                //$licenseDataArr = array('uniqueid'=>substr(md5(microtime()), 0, 5), 'orderid'=>$orderId,'no_of_devices'=>$no_of_devices,'purchase_date'=>$purchase_date,'license_validity'=>$license_validity,'license_expiry_date'=>$license_expiry_date,'number_of_lic_used'=>0);
                //$certificateflag = $this->getLicenseMasterTable()->inserDataForDssFont($licenseDataArr);
                $appObj->executeQueries("INSERT INTO license_master SET uniqueid='".substr(md5(microtime()), 0, 5)."',orderid=AES_ENCRYPT($orderId, '".POLL_ENCRYPTION_KEY."'),no_of_devices=$no_of_devices,purchase_date='$purchase_date',license_validity=$license_validity,license_expiry_date='$license_expiry_date',number_of_lic_used=0,model_type=0");
                
                //manage log
                $appObj->ActivityLogVSM(6, $licenseFileName, 10);

                //Rabbit MQ Code
                $cmdArr=array("cmd"=>"check_licence","sender"=>"web-vsm");
                $cmdJson=json_encode($cmdArr);
                $producerObject=new WebProducerController();
                $producerObject->rabbitWebProducerAction($cmdJson);
                $error='success';
            }
        }//end of post
        /* ******************************************************* */
    
        return new ViewModel(array('form'=>$form ,'licenseInfo'=>$licenseInfo,'licenseSr'=>$licenseSr,'allowTotalGateways'=>$allowTotalGateways,'countTotalRows'=>$countTotalRows,'tableCount'=>$tableCount,'error_flag'=>$error,'cloudLicenseDataArr'=>$cloudLicenseDataArr));
    }

    /*****
 *	@function Name		: getlicenseDetailsAction
 *  @description	    : Get license details when click on license row
 *	@Author			    : Ashu
 *  @Date               : 08/Jan/2021
 *****/
    public function getlicenseDetailsAction()
    {
        $postData=trim($_POST['licUniqueId']);
        $postDataArr=explode("##", $postData);
        $uniqueid=trim($postDataArr[0]);
        $orderId=trim($postDataArr[1]);
        $usedLicenseData=$this->getLicenseUsedTable()->fetchAll($uniqueid);
        $str.='<div class="row"><div class="col-md-6"><strong>'.STR_GRAPH_GATEWAY_NAME.'</strong></div><div class="col-md-6"><strong>Expiry Date</strong></div></div>';
        if ($usedLicenseData->count()>0) {
            foreach ($usedLicenseData as $usedLicenseArr) {
                $deviceDetailsArr=(array)$this->getDeviceInventoryTable()->getGatewayNamebyid($usedLicenseArr->did);
                //$showDeviceName=($deviceDetailsArr['DeviceName']=="")?htmlspecialchars('<Gateway Deleted>'):$deviceDetailsArr['DeviceName'];
                $showDeviceName=trim($usedLicenseArr->gateway_name);
                $str.='<div class="row">';
                $str.='<div class="col-md-6"  style="word-break: break-word">'.$showDeviceName.'</div>';
                $str.='<div class="col-md-6"> <span>'.$usedLicenseArr->expiry_date.'</span> </div></div>';
            }
        } else {
            $str.='<div class="row">';
            $str.='<div class="col-md-12" align="center">'.MSG_NO_RECORD_FOUND.'</div>';
            $str.='</div>';
        }
        echo $str;
        die;
    }
    

    /*****
     *	@function Name		: uploadlicenseDetailFileAction
     *  @description	    : upload license file for linux
     *	@Author			    : Vineet
     *  @Date               : 30-march-2020
     *****/
    public function uploadlicenseDetailFileAction()
    {
        $appObj = new ApplicationController();
        $licensefile = $this->params()->fromFiles('licensefile');
        $request = $this->getRequest();
        $postData = $this->getRequest()->getPost()->toArray();
        $status= move_uploaded_file($_FILES['licensefile']['tmp_name'], LICENSE_FILE_PATH.$_FILES['licensefile']['name']);
        copy(LICENSE_FILE_PATH.$_FILES['licensefile']['name'], LICENSE_FILE_PATH."licdetails.txt");
        unlink(LICENSE_FILE_PATH.$_FILES['licensefile']['name']);
        
        if (CHECK_FILE_LICENSE_DETAILS==1) {
            $file_licenseDetails=$appObj->file_read(FILE_LICENSE_DETAILS);
            $file_contents=$appObj->desDecrypt($file_licenseDetails, KEY_SEED_NEW);
        
            $arr=explode("|", $file_contents);
            $domainFromFile=$arr[0];
            //$licenseSr=$arr[1];
            $unitsAllocated=$arr[2];
            $unitsAllocated=$appObj->desEncrypt($unitsAllocated, KEY_SEED_NEW);
            if (file_exists($_SERVER["DOCUMENT_ROOT"]."/../bin/config/serverconfig.xml")) {
                $domainename=trim($appObj->file_read($_SERVER["DOCUMENT_ROOT"]."/../bin/config/".FILE_DOMAIN));
                if ($domainename==$domainFromFile) {
                    $flag=1;
                    $openfile = fopen(BASE_PATH.'/configs/loglc.txt', 'w');
                    $confWrite= fwrite($openfile, $unitsAllocated);
                    fclose(openfile);
                } else {
                    $flag=0;
                    unlink(LICENSE_FILE_PATH."licdetails.txt");
                }
            }
        }
        if ($flag==1) {
            echo "success";
            exit;
        }
        if ($flag==0) {
            echo"Error in file uploading";
            exit;
        }
    }
    
    /*****
 *	@function Name		: searchClientVersionAction
 *  @description	    : get client version
 *	@Author			    : Vineet
 *  @Date               : 30-march-2020
 *****/
    public function searchClientVersionAction()
    {
        $request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
            $data = $request->getPost('data');
            $allData = $this->getBuildInfoTable()->getAllData($data[0]);
            foreach ($allData as $allResult) {
                $data1[] = $allResult->client_version_no;
            }
            $dataValue = json_encode($data1);
            $view = new JsonModel(array('success' =>$dataValue));
            $view->setTerminal(true);
            return $view;
        }
    }
    
    
    /*****
     *	@function Name		: buildInfoAction
     *  @description	    : get version data
     *	@Author			    : Vineet
     *  @Date               : 30-march-2020
     *****/
    public function buildInfoAction()
    {
        $request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
            $appversionmappingArray=array('Cloud File server'=>'File Server','CollabAppLauncher'=>'AppLauncher','WindowsFTP Serve'=>'Streaming Server','WOWApi Server'=>'Api Server','WOW Mouse Server'=>'Collobration Server','WOWCollab8(Admin mode)'=>'VIA/Collab8','WOW Player'=>'Video Player','WPG_Client_Linux(Windows)'=>'ScreenShare','WOW Viewer17'=>'Viewer','AirMirror_Linux'=>'Airplay Mirroring','Vinagre (Linux)'=>'Viewer','Tinyftp'=>'Streaming Server','RTP Audio win_lin_player'=>'Audio Player','Collab8Seeting'=>'AppSetting','x11vnc'=>'WOWCapture','vinagre'=>'WOWViewer');
    
            $result = $this->getBuildInfoTable()->fetchOne();
            foreach ($result as $results) {
                $temp = array('id' =>$results->id,
                              'client_version' =>$results->client_version_no,
                             );
            }
            $clientVersionID = $temp['id'];
            $client_version = $temp['client_version'];
            $versionData = $this->getVersionInfoTable()->fetchAll($clientVersionID);
            $idx = 0;
            foreach ($versionData as $versionDataFile) {
                $temp = array('version_id' =>$versionDataFile->version_id,
                              'client_version_fk' =>$versionDataFile->client_version_fk,
                              'clientVersion' =>$client_version,
                              'AppsFilePath' =>($versionDataFile->appMappingName == WebSite_AppName)?$versionDataFile->appMappingName . '/' : VERSION_PATH .$versionDataFile->appMappingName . '/',
                              // 'AppName' =>$versionDataFile->AppName,
                            'AppName' => array_key_exists(
                                $versionDataFile->AppName,
                                $appversionmappingArray
                            )?$appversionmappingArray[$versionDataFile->AppName]:$versionDataFile->AppName,
                              'version_no' =>$versionDataFile->version_no,
                              'modifydate' =>$versionDataFile->modifydate,
                             );
                //$fileList=fileList($temp['AppsFilePath']);
                $jsonData[$idx ++] = $temp;
            }
            $val = json_encode($jsonData);
            $view = new JsonModel(array('success' => $val));
            $view->setTerminal(true);
            return $view;
        }
    }
    
    
    /*****
     *	@function Name	: fileList
     *  @description	    : mapping file
     *	@Author			    : Vineet
     *  @Date               : 30-march-2020
     *****/
    public function fileList($dir)
    {
        if (is_dir($dir)) {
            $fileListArray = array();
            if ($dh = opendir($dir)) {
                while (($file = readdir($dh))!== false) {
                    //echo "filename:" . $file . "<br>";
                    if (strlen($file)> 3) {
                        array_push($fileListArray, $file);
                    }
                }
                return $fileListArray;
                closedir($dh);
            }
        } else {
            return 0;
        }
    }
    /*****
     *	@function Name	: versioninfoDataAction
     *  @description	    : get versoninfo table data
     *	@Author			    : Vineet
     *  @Date               : 20-feb-2020
     *****/
    public function versioninfoDataAction()
    {
        $request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
            $data = $request->getPost('data');
            $appversionmappingArray=array('Cloud File server'=>'File Server','CollabAppLauncher'=>'AppLauncher','WindowsFTP Serve'=>'Streaming Server','WOWApi Server'=>'Api Server','WOW Mouse Server'=>'Collobration Server','WOWCollab8(Admin mode)'=>'VIA/Collab8','WOW Player'=>'Video Player','WPG_Client_Linux(Windows)'=>'ScreenShare','WOW Viewer17'=>'Viewer','AirMirror_Linux'=>'Airplay Mirroring','Vinagre (Linux)'=>'Viewer','Tinyftp'=>'Streaming Server','RTP Audio win_lin_player'=>'Audio Player','Collab8Seeting'=>'AppSetting','x11vnc'=>'WOWCapture','vinagre'=>'WOWViewer');
            $result=$this->getVersionInfoTable()->getDataByAppName($data[0]);
            foreach ($result as $allDatas) {
                $temp = array(
                             'clientVersion' =>$client_version,
                             'AppsFilePath' =>($allDatas->appMappingName == WebSite_AppName)?$allDatas->appMappingName . '/' : VERSION_PATH .$allDatas->appMappingName . '/',
                              // 'AppName' =>$versionDataFile->AppName,
                            'AppName' => array_key_exists(
                                $allDatas->AppName,
                                $appversionmappingArray
                            )?$appversionmappingArray[$allDatas->AppName]:$allDatas->AppName,
                             'version_no' =>$allDatas->version_no,
                             'modifydate' =>$allDatas->modifydate,
                             );
                $jsonData[$idx ++] = $temp;
            }
            $val = json_encode($jsonData);
            $view = new JsonModel(array('success' =>$val));
            $view->setTerminal(true);
            return $view;
        }
    }
    /*****
     *	@function Name	: exportPDFAction
     *  @description	    : export pdf
     *	@Author			    : Vineet
     *  @Date               : 30-march-2020
     *****/
    public function exportPDFAction()
    {
        $request = $this->getRequest();
        //$val=$request->getPost();
        $value=$_GET["link"];
        if ($value=="") {
            $resultData=$this->getBuildInfoTable()->fetchAll();
            //echo $resultData;
            foreach ($resultData as $results) {
                $temp = array('id' =>$results->id,
                      'client_version' =>$results->client_version_no,
                     );
            }
            $clientId = $temp['id'];
            $client_version = $temp['client_version'];
        } else {
            $result = $this->getBuildInfoTable()->getClientId($value);
            $clientId=$result->id;
            $client_version=$value;
        }

        $allData=$this->getVersionInfoTable()->fetchAll($clientId);
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->AliasNbPages();
        $pdf->SetFont('Arial', 'B', 11);
        //ob_start();
        $header=array('AppName','Build Number','Version No','ModifyDate');
        $width=array(54,30,64,40);
        $i=0;
        foreach ($header as $heading) {
            $pdf->Cell($width[$i], 11, $heading, 1);
            $i++;
        }
        foreach ($allData as $row) {
            $temp = array($row->AppName,
                     $client_version,
                     $row->version_no,
                      $row->modifydate,
                     );
            $jsonData[$idx ++] = $temp;
        }
        foreach ($jsonData as $row) {
            $pdf->SetFont('Arial', '', 11);
            $pdf->Ln();
            $j=0;
            foreach ($row  as $column) {
                $pdf->Cell($width[$j], 11, $column, 1);
                $j++;
            }
        }
        $pdf->Output('AppVersion.pdf', "D");
        exit();
    
        //}
    }

    /*****
    *	@function Name	: appVersionListAction
    *  @description	    :
    *	@Author			    : Vineet
    *  @Date               : 30-march-2020
    *****/

    public function appVersionListAction()
    {
        $request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
            $data = $request->getPost('data');
            $appversionmappingArray=array('Cloud File server'=>'File Server','CollabAppLauncher'=>'AppLauncher','WindowsFTP Serve'=>'Streaming Server','WOWApi Server'=>'Api Server','WOW Mouse Server'=>'Collobration Server','WOWCollab8(Admin mode)'=>'VIA/Collab8','WOW Player'=>'Video Player','WPG_Client_Linux(Windows)'=>'ScreenShare','WOW Viewer17'=>'Viewer','AirMirror_Linux'=>'Airplay Mirroring','Vinagre (Linux)'=>'Viewer','Tinyftp'=>'Streaming Server','RTP Audio win_lin_player'=>'Audio Player','Collab8Seeting'=>'AppSetting','x11vnc'=>'WOWCapture','vinagre'=>'WOWViewer');

            if ($data[0]=="") {
                $resultData=$this->getBuildInfoTable()->fetchOne();
                foreach ($resultData as $results) {
                    $temp = array('id' =>$results->id,
                      'client_version' =>$results->client_version_no,
                     );
                }
                $clientId = $temp['id'];
                $client_version = $temp['client_version'];
            } else {
                $result = $this->getBuildInfoTable()->getClientId($data);
                $clientId=$result->id;
                $client_version =$result->client_version_no;
            }

            $allData=$this->getVersionInfoTable()->fetchAll($clientId);
            foreach ($allData as $allDatas) {
                $temp = array('version_id' =>$allDatas->version_id,
                      'client_version_fk' =>$allDatas->client_version_fk,
                      'clientVersion' =>$client_version,
                      'AppsFilePath' =>($allDatas->appMappingName == WebSite_AppName)?$allDatas->appMappingName . '/' : VERSION_PATH .$allDatas->appMappingName . '/',
                      // 'AppName' =>$versionDataFile->AppName,
                    'AppName' => array_key_exists(
                        $allDatas->AppName,
                        $appversionmappingArray
                    )?$appversionmappingArray[$allDatas->AppName]:$allDatas->AppName,
                      'version_no' =>$allDatas->version_no,
                      'modifydate' =>$allDatas->modifydate,
                     );
                $jsonData[$idx ++] = $temp;
            }
            $val = json_encode($jsonData);
            $view = new JsonModel(array('success' =>$val));
            $view->setTerminal(true);
            return $view;
        }
    }

    // Cloud License re-balancing
    public function licenseReBalancingAction()
    {
        $appObj = new ApplicationController();
        $tblLicenseMasterDataArr=$appObj->returnQueryData("select datediff(license_expiry_date, CURRENT_DATE()) AS remaining_days,no_of_devices, license_expiry_date FROM license_master WHERE license_expiry_date >CURRENT_DATE()");
        $sum_no_of_devices=0;
        $sum_remainingDays=0;
        foreach ($tblLicenseMasterDataArr as $data) {
            $totalRecords++;
            $remaining_days=$data['remaining_days'];
            $sum_remainingDays=$sum_remainingDays+($remaining_days*$data['no_of_devices']);
            $sum_no_of_devices=$sum_no_of_devices+$data['no_of_devices'];
        }
        $avg_remaingDays=round($sum_remainingDays/$sum_no_of_devices);
        
        $appObj->executeQueries("UPDATE license_master SET license_expiry_date=DATE_ADD(CURRENT_DATE(), INTERVAL $avg_remaingDays DAY) WHERE license_expiry_date >CURRENT_DATE()");
        $appObj->executeQueries("UPDATE license_used SET expiry_date=DATE_ADD(CURRENT_DATE(), INTERVAL $avg_remaingDays DAY) WHERE expiry_date >CURRENT_DATE()");
        die;
    }


	/*****
	*	@function Name	: getLicenseDetailAjax
	*  @description	    : get license detail
	*	@Author			: Vineet
	*  @Date            : 22-march-2021
	*****/
	public function getLicenseDetailAjaxAction(){
		$request = $this->getRequest();
		$appObj = new ApplicationController();
        if ($request->isXmlHttpRequest()) {
            if (GET_OS=="LIN" &&  PRODUCT_TYPE=='vsm') {
                $cloudLicenseDataArr=$appObj->returnQueryData("SELECT licmsterid,uniqueid,AES_DECRYPT(orderid,'".POLL_ENCRYPTION_KEY."') AS orderid, no_of_devices, purchase_date, license_validity, license_expiry_date,number_of_lic_used FROM license_master");
            }
            // insert clientVersion entry
            $readMyversionFileTxt=$appObj->file_read(SECOND_DEST_PATH.'hq_version.txt');
            $checkClientVersion=$appObj->returnQueryData("SELECT * FROM tbl_buildinfo WHERE client_version_no='$readMyversionFileTxt'");
            if ($checkClientVersion->count()==0) {
                $last_insert_id =$this->getBuildInfoTable()->insertClientVersion($readMyversionFileTxt);
            } elseif ($checkClientVersion->count()==1) {
                $versionData=$checkClientVersion->current();
                $last_insert_id=$versionData['id'];
                $this->getVersionInfoTable()->deleteRecord($last_insert_id);
            }
            $versionPath=DEST_PATH."Version/";
            $listDirArr = scandir($versionPath);
            $sql="INSERT INTO tbl_versioninfo (client_version_fk,AppName,version_no,modifydate,appMappingName) VALUES";
            foreach ($listDirArr as $dirname) {
                if (!strstr($dirname, '.')) {
                    if (!strstr($dirname, 'QRWidget')) {
                        //$dirname."<br>";
                        $appName=trim($dirname);
                        $dirname=$versionPath.trim($dirname).'/';
                        $fileList=$this->fileList($dirname);
                        foreach ($fileList as $val) {
                            $filename=$val;
                            $fileData=$appObj->file_read($dirname.$filename);
                            if (trim(strtolower($filename))=='info.txt') {
                                $xml=simplexml_load_string($fileData);
                                $xmlAppName=trim($xml->AppName);
                                $versionnumber=trim($xml->Version);
                                $modifydate=trim($xml->ModifiedDate);
                                $sql.="($last_insert_id,'$xmlAppName','$versionnumber','$modifydate','$appName'),";
                            }
                        }
                    }
                }
            }//end of foreach
            $sql=rtrim($sql, ',');
            $conn = $appObj->getConnection();
            $qryResponse = $conn->execute($sql);
            $webVersion=WEB_VERSION;
            $query="INSERT INTO tbl_versioninfo SET client_version_fk=$last_insert_id,AppName='Website',version_no='$webVersion',modifydate='$modifydate', appMappingName='Website'";
            $qryResponse = $conn->execute($query);
			$resultData=$this->getBuildInfoTable()->fetchAll();
        	$countTotalRows=$resultData->count();
			echo $countTotalRows;
			die;
        }
	}

    /*****
    *	@function Name	: getBuildInfoTableAction
    *  @description	    : get table
    *	@Author			    : Vineet
    *  @Date               : 30-march-2020
    *****/
    public function getBuildInfoTable()
    {
        if (!$this->TblBuildInfoTable) {
            $sm = $this->getServiceLocator();
            $this->TblBuildInfoTable = $sm->get('Webapp\Model\TblBuildInfoTable');
        }
        return $this->TblBuildInfoTable;
    }

    /*****
    *	@function Name	: getVersionInfoTableAction
    *  @description	    : get table
    *	@Author			    : Vineet
    *  @Date               : 30-march-2020
    *****/
    public function getVersionInfoTable()
    {
        if (!$this->TblVersionInfoTable) {
            $sm = $this->getServiceLocator();
            $this->TblVersionInfoTable = $sm->get('Webapp\Model\TblVersionInfoTable');
        }
        return $this->TblVersionInfoTable;
    }

    public function getLicenseMasterTable()
    {
        if (!$this->TblLicenseMasterTable) {
            $sm = $this->getServiceLocator();
            $this->TblLicenseMasterTable = $sm->get('Webapp\Model\TblLicenseMasterTable');
        }
        return $this->TblLicenseMasterTable;
    }

    public function getSessionCheckTable()
    {
        if (!$this->TblSessionCheckTable) {
            $sm = $this->getServiceLocator();
            $this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
        }
        return $this->TblSessionCheckTable;
    }
    public function getLicenseUsedTable()
    {
        if (!$this->TblLicenseUsedTable) {
            $sm = $this->getServiceLocator();
            $this->TblLicenseUsedTable = $sm->get('Webapp\Model\TblLicenseUsedTable');
        }
        return $this->TblLicenseUsedTable;
    }

    public function getDeviceInventoryTable()
    {
        if (!$this->TblDeviceInventoryTable) {
            $sm = $this->getServiceLocator();
            $this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
        }
        return $this->TblDeviceInventoryTable;
    }
}
