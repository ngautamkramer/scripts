<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\TtfInfo\TtfInfo;

class DssCampaignController extends AbstractActionController {	
	protected $fileExtension = "json";
	protected $fileNamePrefix = "vsm_camp_";
	public function getScreenTemplateMasterTable() {
		if(!$this->TblScreenTemplateMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblScreenTemplateMasterTable = $sm->get('Webapp\Model\TblScreenTemplateMasterTable');
		}
		return $this->TblScreenTemplateMasterTable;
	}

	public function getMediaInventryTable() {
		if(!$this->TblMediaInventryTable) {
			$sm = $this->getServiceLocator();
			$this->TblMediaInventryTable = $sm->get('Webapp\Model\TblMediaInventryTable');
		}
		return $this->TblMediaInventryTable;
	}
	
	public function getMediaComponentMasterTable() {
		if(!$this->TblMediaComponentMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblMediaComponentMasterTable = $sm->get('Webapp\Model\TblMediaComponentMasterTable');
		}
		return $this->TblMediaComponentMasterTable;
	}

	public function getCampaignListTable() {
		if(!$this->TblCampaignListTable) {
			$sm = $this->getServiceLocator();
			$this->TblCampaignListTable = $sm->get('Webapp\Model\TblCampaignListTable');
		}
		return $this->TblCampaignListTable;
	}


	public function getPlaylistScheduleMasterTable() {
		if(!$this->TblPlaylistScheduleMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblPlaylistScheduleMasterTable = $sm->get('Webapp\Model\TblPlaylistScheduleMasterTable');
		}
		return $this->TblPlaylistScheduleMasterTable;
	}

	public function getCampaignTemplateTable() {
		if(!$this->TblCampaignTemplateTable) {
			$sm = $this->getServiceLocator();
			$this->TblCampaignTemplateTable = $sm->get('Webapp\Model\TblCampaignTemplateTable');
		}
		return $this->TblCampaignTemplateTable;
	}

	public function getCampaignMediaTable() {
		if(!$this->TblCampaignMediaTable) {
			$sm = $this->getServiceLocator();
			$this->TblCampaignMediaTable = $sm->get('Webapp\Model\TblCampaignMediaTable');
		}
		return $this->TblCampaignMediaTable;
	}

	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}

	public function getSettingTable() {
		if(!$this->TblSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}
	
	public function deleteCampaignAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');	
		$postData = $this->getRequest()->getPost()->toArray();
		$sendData["campaignId"] = $postData["campaignId"];
		$crsf_tokenval=trim($postData["crsf_tokenval"]);
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$scheduledMasterData = $playlistMasterTable->canCampaignDelete($sendData);
		$canDelete = false;
		$fileNamePrefix="";
		if(PRODUCT=='via'){
			$fileNamePrefix='camp_';
		}
		else{
			$fileNamePrefix='vsm_camp_';
		}
		if(count($scheduledMasterData) == 0) {
			$canDelete = true;
			$campaignListTable = $this->getCampaignListTable();
			$campaignListTable->campaignDelete($sendData);
			
			$deleteTemplateAssociation["campaign_id"] = $postData["campaignId"];
			$deleteMediaAssociation["campaign_id"] = $postData["campaignId"];
			
			$campaignMediaTable = $this->getCampaignMediaTable();
			$campaignMediaTable->deleteMediaAssociationInCampaign($deleteMediaAssociation);
			$campaignTemplateTable = $this->getCampaignTemplateTable();
			$campaignTemplateTable->deleteTemplateAssociationInCampaign($deleteTemplateAssociation);
			unlink(UPLOAD_DSS_CAMPAIGN.$fileNamePrefix . $postData["campaignId"] . "." . $this->fileExtension);
		}
		echo $canDelete;
		die();
	}


	public function fetchMediaIdFromArray($frameArrayData) {
		$mediaIds = [];	
		foreach($frameArrayData as $frameKey => $frameValue) {
			if($frameValue["media"]) {
				foreach($frameValue["media"] as $mediaKey => $mediaArray) {
					foreach($mediaArray as $mediaArrayKey => $mediaArrayValue) {
						if($mediaArrayKey == "mediaId") {
							array_push($mediaIds, $mediaArrayValue);
						}
					}
				}	
			}
		}
		return $mediaIds;
	}

	public function saveUpdateCampaign($saveData, $jsonCampaignData ,$actionType, $updateCondition) {
		$campaignListTable = $this->getCampaignListTable();
		$campaignMediaTable = $this->getCampaignMediaTable();
		$campaignTemplateTable = $this->getCampaignTemplateTable();
		


		$fileNamePrefix="";
		if(PRODUCT=='via' || PRODUCT== 'kds' ){
			$fileNamePrefix='camp_';
		}
	    else{
			$fileNamePrefix='vsm_camp_';
		}
		$uniqueNameSearch = array();
		$uniqueNameSearch["cname"] = $saveData['cname'];		
		$responseReturn = "";
		
		if($saveData['cname'] == "") {
			$responseReturn = 4;  
		} else {
			if(strlen($saveData['cname']) > 100) {
				$responseReturn = 7;  
			} else {
				if($actionType == "add") {
					$uniqueNameData = $campaignListTable->checkCampaignUniqueName($uniqueNameSearch);
					$responseReturn = count($uniqueNameData) == 0 ? "" : 1;
				} else if ($actionType == "update") {
					$uniqueNameSearch["cid"] = $updateCondition["cid"];
					$uniqueNameData = $campaignListTable->checkCampaignUniqueName($uniqueNameSearch);
					$responseReturn = count($uniqueNameData) == 0 ? "" : 1;
				}
			}
			
		}
		if($responseReturn == "") {
			if($actionType == "add"  || $actionType == "duplicate") {
				$lastInsertedId = $campaignListTable->insertCampaign($saveData);
				if($lastInsertedId) { 
					if(PRODUCT=='via' ){
						$jsonData = json_encode($jsonCampaignData["campaignJsonData"]);
					}else{
						$jsonData = json_encode($jsonCampaignData["campaignJsonData"], JSON_NUMERIC_CHECK);
			
					}
					$mediaIds = $this->fetchMediaIdFromArray($jsonCampaignData["campaignJsonData"]["frame"]);
					foreach($mediaIds as $key => $value) {
						$saveCampaignMedia = [];
						$saveCampaignMedia["campaign_id"] = $lastInsertedId;
						$saveCampaignMedia["media_id"] = $value;
						$campaignMediaTable->insertMediaAssociationInCampaign($saveCampaignMedia);
					}
					$templateId = $jsonCampaignData["campaignJsonData"]["templateId"];
					$saveCampaignTemplate["campaign_id"] = $lastInsertedId;
					$saveCampaignTemplate["template_id"] = $templateId;
					$campaignTemplateTable->insertTemplateAssociationInCampaign($saveCampaignTemplate);
					$jsonFileName = $fileNamePrefix . $lastInsertedId . "." . $this->fileExtension;
					file_put_contents(UPLOAD_DSS_CAMPAIGN.$jsonFileName, $jsonData);
					$updateCampaign["filename"] = $jsonFileName;
					$updateCampaignWhere["cid"] = $lastInsertedId;
					$campaignListTable->updateCampaign($updateCampaignWhere, $updateCampaign);
					$responseReturn = 2;
				}		
			} else if ($actionType == "update") {
				// check for update camapign for in use status
				$getAllCampaignStatus = $campaignListTable->campaignStatus(array("campaignId" => $updateCondition["cid"])); 
				foreach($getAllCampaignStatus as $statusData){
					$resultJson = json_encode($statusData); 
					$resultArray = json_decode($resultJson, true);				
				}		
				$campaignScheduled = $resultArray['cnt'];
				if($campaignScheduled == 0) {
					$updated = $campaignListTable->updateCampaign($updateCondition, $saveData);
					if(PRODUCT=='via'){
						$jsonData = json_encode($jsonCampaignData["campaignJsonData"]);
					}else{
						$jsonData = json_encode($jsonCampaignData["campaignJsonData"],JSON_NUMERIC_CHECK);
					}
					
					$jsonFileName = $fileNamePrefix . $updateCondition["cid"] . "." . $this->fileExtension;
					//unlink(UPLOAD_DSS_CAMPAIGN.$jsonFileName);
					file_put_contents(UPLOAD_DSS_CAMPAIGN.$jsonFileName, $jsonData);	
					$mediaIds = $this->fetchMediaIdFromArray($jsonCampaignData["campaignJsonData"]["frame"]);
					$deleteMediaAssociation["campaign_id"] = $updateCondition["cid"];
					$campaignMediaTable->deleteMediaAssociationInCampaign($deleteMediaAssociation);
					foreach($mediaIds as $key => $value) {
						$saveCampaignMedia = [];
						$saveCampaignMedia["campaign_id"] = $updateCondition["cid"];
						$saveCampaignMedia["media_id"] = $value;
						$campaignMediaTable->insertMediaAssociationInCampaign($saveCampaignMedia);
					}
					$responseReturn = 3;
				} else {
					$responseReturn = 8;
				}
				
			}
		} 
		echo $responseReturn; exit;
	}

	public function createDuplicateCampaignAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$postData = $this->getRequest()->getPost()->toArray();
		//$campaignId = $postData["campaignId"];
		$encryptedCampaignId = $postData["campaignId"];
		$crsf_tokenval = trim($postData["crsf_tokenval"]);
		//Validate CSRF attack
		if($session_crsf_token != $crsf_tokenval){
			die('Invalid request');
		}		
		
		//Security changes added by ashu on 25/03/22. Passing template id encrypted
		$appObj = new ApplicationController();
		$input=str_replace(' ','+',trim($encryptedCampaignId));
		$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
		$campaignId=$appObj->desDecrypt($input, KEY_SEED);
	    if(!is_numeric($campaignId) && $campaignId<= 0 ){
			echo "Id is not valid";die;
		}	
		
		
		$campaignListTable = $this->getCampaignListTable();
		$sendCampaignDetail = array("campaignId" => $campaignId);
		$campaignDetail = $campaignListTable->getCampaignDetail($sendCampaignDetail);
		foreach($campaignDetail as $allCampaignDetail){
			$resultSetJson = json_encode($allCampaignDetail); 
			$resultSet = json_decode($resultSetJson, true);
		}
		$saveCampaign["cname"] = "Duplicate_". date("y-m-d-H-i-s");
		$saveCampaign["createdate"] = date("Y-m-d H:i:s");
		$jsonCampaignData["campaignJsonData"] = $this->readCampaignJsonFile($resultSet["filename"]);
		$this->saveUpdateCampaign($saveCampaign, $jsonCampaignData, "duplicate", "");
		// echo true;
		// die;
	}

	public function checkMediaAdded($frameArrayData) {
		$respose = false;
		foreach($frameArrayData as $key => $value) {
			//echo $key;
			if(count($value["media"]) > 0) {
				$respose = true;
				break;
			}
		}
		return $respose; 
	}

	public function addEditSaveCampaignAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$crsf_tokenval=$postData["crsf_tokenval"];
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		// echo "<pre>";
		// print_r($postData);
		// echo "</pre>";
		// exit;
		$mediaAdded = $this->checkMediaAdded($postData["postCampaignData"]["frame"]);
		$responseReturn = "";
		
		if(count($postData["postCampaignData"]["frame"]) == 0) {
			$responseReturn = 5;  
		} else {
			if($mediaAdded == false) {
				$responseReturn = 6;  
			} 
		}

		if($responseReturn == "") {
			$saveCampaign["cname"] = htmlspecialchars($postData["campaignName"]);
			if($postData["actionType"] == "add") {
				$saveCampaign["createdate"] = date("Y-m-d H:i:s");
			} else if ($postData["actionType"] == "update") {
				$saveCampaign["modifydate"] = date("Y-m-d H:i:s");
				$updateCampaignWhere["cid"] = $postData["campaignId"];
			}
			$jsonCampaignData["campaignJsonData"] = $postData["postCampaignData"];
			$this->saveUpdateCampaign($saveCampaign, $jsonCampaignData, $postData["actionType"], $updateCampaignWhere);
		} else {
			echo $responseReturn;
		}
		exit;
	}

	public function campaignEditAction() {
		$campaignDetail = array();
		$editViewType = htmlspecialchars($_GET["type"]);
		
		if(isset($_GET['id']) && !empty($_GET['id'])) {
			$campaignId = $_GET["id"];

			//for security changes
			if(!is_numeric($campaignId) || $campaignId <= 0){
				echo "Id is not valid";die;
			}
			//end for security changes

			$campaignListTable = $this->getCampaignListTable();	
			$sendCampaignDetail = array("campaignId" => $campaignId);
			$campaignDetailData = $campaignListTable->getCampaignDetail($sendCampaignDetail);

			foreach($campaignDetailData as $allCampaignDetail){
				$resultSetJson = json_encode($allCampaignDetail); 
				$resultSet = json_decode($resultSetJson, true);
			}
			$campaignDetail["campaignName"] = $resultSet["cname"];
			$campaignDetail["campaignId"] = $resultSet["ccid"];
			$campaignDetail["campaignJsonData"] = $this->readCampaignJsonFile($resultSet["filename"]);
		}
		// echo "<pre>";
		// print_r($resultSet);
		// echo "</pre>";		
		
		$this->layout('layout/campaigneditor');
		$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
		$predfinedTemplateResultSet = $tableScreenTemplateMasterTable->getPredefinedDssTempaltes();
		$customTemplateResultSet = $tableScreenTemplateMasterTable->getCustomDssTempaltes();

		$mediaComponentMasterTable = $this->getMediaComponentMasterTable();		
		$mediaComponentResultSet = $mediaComponentMasterTable->getActiveMediaComponents();

		$mediaInventoryTable = $this->getMediaInventryTable();
		$getAllMediaInventory =  $mediaInventoryTable->getAllMediaInventory("");

		$viewmodel = new ViewModel(array("predinedTemplateList" => $predfinedTemplateResultSet, 
			"customTemplateList" => $customTemplateResultSet, "mediaComponentResultSet" => $mediaComponentResultSet, "getAllMediaInventory" => $getAllMediaInventory, "campaignDetail" => $campaignDetail, "campaignStatus" => $campaignStatus, "editViewType" => $editViewType));
		return $viewmodel;
	}

	public function readCampaignJsonFile($fileName) {
		if(file_exists(UPLOAD_DSS_CAMPAIGN.$fileName)) {
			$appObj = new ApplicationController();
			$fileContent = $appObj->file_read(UPLOAD_DSS_CAMPAIGN.$fileName);
			$fileContentArray = json_decode($fileContent, true);
			return $fileContentArray;
		}
	}

	public function campaignListAction() {
		$campaignListTable = $this->getCampaignListTable();
		$getAllCampaign = $campaignListTable->getCampaigns();
		$allCampaignData = array();
		foreach($getAllCampaign as $allMediaResultSet) {
			$resultSetJson = json_encode($allMediaResultSet); 
			$resultSet = json_decode($resultSetJson, true);
			// print_r($resultSet);
			//$arrayForGetStatus = array("StartDate" => $resultSet["StartDate"], "EndDate" => $resultSet["EndDate"]);
			// $resultSet["campaignStatus"] = $this->getCampaignStatus($arrayForGetStatus);
			$resultSet["campaignStatus"] = "Ready to use";
			if($resultSet["pcid"]) {
				$resultSet["campaignStatus"] = "In Use";
			}
			$fileContentArray = $this->readCampaignJsonFile($resultSet["filename"]);
			$templateId = $fileContentArray["templateId"];
			$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
			$templateDetailsData = $tableScreenTemplateMasterTable->getTemplateDetails($templateId);	
			$templateDetails = [];
			foreach($templateDetailsData as $detailsResultSet) {
				$hasAudio = $detailsResultSet['frameid'] ==	$fileContentArray["audioinframe"] ? "yes" : "no";
				$templateDetails["templateId"] = $detailsResultSet['screentemplateid'];
				$templateDetails["templateName"] = $detailsResultSet['screentemplatename'];
				$templateDetails['frameProperties'][$detailsResultSet['zorder']] = array (
					'frameHeight' => round($detailsResultSet['frameheight']), 
					'frameWidth' =>round($detailsResultSet['framewidth']),
					'frameLeft' => round($detailsResultSet['frameleft']), 
					'frameTop' => round($detailsResultSet['frametop']),	
					'frameName' => $detailsResultSet['framename'], 
					'frameId' => $detailsResultSet['frameid'],
					'hasAudio' => $hasAudio
				);
			}
			$fileContentArray = is_array($fileContentArray) ? $fileContentArray : [];		
			array_push($allCampaignData, array_merge($resultSet, $templateDetails, $fileContentArray));
		}
		// echo "<pre>";
		// print_r($allCampaignData);
		// echo "</pre>";exit;
		$viewmodel = new ViewModel(array("getAllCampaign" => $allCampaignData));
		return $viewmodel;
	}	

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		$appObj = new ApplicationController();
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		} else {
			if(PRODUCT=='via' || PRODUCT=='kds'){
				$getSettingObj = $appObj->getComplexPasswordSettings();
				$getSettingData = $getSettingObj->webadmin_session_timeout;
			}else{
				$settingTable = $this->getSettingTable();
				$dataSessionSetting = $settingTable->getSessionCheckData();
				foreach($dataSessionSetting as $contentDetailResultSet) {
					$resultSetJson = json_encode($contentDetailResultSet); 
					$resultSet = json_decode($resultSetJson, true);
					$getSettingData = $resultSet['logoutTIme'];
				}
			}
			$sessionTimeOut = ($getSettingData > 0) ? $getSettingData : 10;
			$dataSendSessionCheck = array("sessionTimeOut" => $sessionTimeOut, "sessionLoginName" => $session->offsetGet('LoginName'));
			$sessionCheckTable = $this->getSessionCheckTable();
			$dataSessionCheck = $sessionCheckTable->getSessionCheckData($dataSendSessionCheck);
			
			if(count($dataSessionCheck) > 0) {
				$dataSendUpdateSessionCheck = array("sessionLoginName" => $session->offsetGet('LoginName'));
				$sessionCheckTable->updateSessionCheckData($dataSendUpdateSessionCheck);
			} else {
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		return parent::onDispatch($e);
	}

}