<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Model\UserTable;
use Webapp\Model\adduser;
use Webapp\Controller\ApplicationController;
use Webapp\Form\UserActivityLogForm;
use Zend\View\Model\JsonModel;
use Webapp\PDF\fpdf;
require(ROOT_BASE_PATH.'/module/Webapp/src/Webapp/PDF/mc_table.php');
class ReportsController extends AbstractActionController {


	public $session;
    public $user_id;
    public $appObj;
    public function __construct() {
        $session = new Container('userinfo');
		$this->user_id = $session->offsetGet('usrid');
        $this->appObj = new ApplicationController();
        
	}

	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		if(PRODUCT=='via'){
			$getSettingObj = $appObj->getComplexPasswordSettings();
			$getSettingData = $getSettingObj->webadmin_session_timeout;
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
			foreach($tblSessionTimeOutDataArr as $sessiondata){
				$getSettingData=$sessiondata['logoutTime'];
			}
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

			/*****
	 *	@Function Name: vsmActivityAction
	 *  @description  : get vsm activity log
	 *	@Author		  : Vineet
	 *  @Date         : 15-april-2020
	 *****/
	public function viaActivityAction() {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$form = new UserActivityLogForm();
		$request = $this->getRequest();
		$appObj = new ApplicationController();	
		if(PRODUCT=='via'){
			//$show_date_format = $appObj->file_read(DEST_PATH . FILE_DATEFORMAT);
			$settingsUrl = DEST_PATH.'via_settings.json';
			$response = file_get_contents($settingsUrl);
			$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
			$templateSettings = json_decode($decryptResponse);
			$show_date_format=$templateSettings->VIA_CONFIG_TEMPLATE->via_settings->date_time->date_time_format;
		}else{
			$show_date_format=$date_format='Y-m-d H:i:s';
		}
		if(!$request->isPost()) {
			$startDate = "";
			$endDate = "";
			$data = $this->getProjectorLogTable()->getProjectorList($this->user_id);
			$startDate = date("Y-m-d");
			$endDate = date("Y-m-d");
			if( $_GET["search"] || $_GET["startdate"] || $_GET["enddate"]){
			$strUserName = htmlspecialchars($_GET["search"]);
			$startDate = htmlspecialchars($_GET["startdate"]);
			$endDate = htmlspecialchars($_GET["enddate"]);
		    if(PRODUCT=='vsm'){
			$data = $this->getProjectorLogTable()->getGatewayLogSerachList($strUserName, $startDate, $endDate, null,$this->user_id);
			}else{
				$data = $this->getProjectorLogTable()->getProjectorLogSerachList($strUserName, $startDate, $endDate, null,$this->user_id);
			}
			$search=$strUserName;
		}
		} else {
			
			$form->setData($request->getPost());
			if(!$form->isValid()) {
			
				return new ViewModel(array('form' => $form, 'data' => $data, 'dateformat' => $show_date_format));
			}
			$dataPost = $form->getData();
			$startDate = htmlspecialchars(trim($dataPost['startdate']));
			$endDate = htmlspecialchars(trim($dataPost['enddate']));
			$strUserName = htmlspecialchars(trim($dataPost['search']));
			$data = $this->getProjectorLogTable()->getProjectorLogSerachList($strUserName, $startDate, $endDate, null,$this->user_id);
		
			
			if(isset($_POST['exportcsv'])) {
				$result = $this->getProjectorLogTable()->getProjectorLogSerachList($strUserName, $startDate, $endDate, "export",$this->user_id);
				$this->exportToCsv($result['data'], 'client');
			}
			if(isset($_POST['exportpdf'])) {
				$result = $this->getProjectorLogTable()->getProjectorLogSerachList($strUserName, $startDate, $endDate, "export",$this->user_id);
				$this->exportToPDF($result['data'], 'client');
			}
		}
	
		$form->setData(array('startdate' => $startDate, 'enddate' => $endDate,'search' => $search));
		$viewmodel = new ViewModel(array('form' => $form, 'data' => $data['data'], 'dateformat' => $show_date_format,'count'=>$data['count']));
		//added by niraj for load menus data into tab
		if(PRODUCT=='via'){
			$viewmodel->setTemplate('webapp/reports/list');
		}
		$data['data']->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
		$data['data']->setItemCountPerPage(50);
		return $viewmodel;
	}

		/*****
	 *	@Function Name: vsmActivityAction
	 *  @description  : get vsm activity log
	 *	@Author		  : Vineet
	 *  @Date         : 16-april-2020
	 *****/
	public function vsmActivityAction() {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		//$this->layout('layout/login');	
		$form = new UserActivityLogForm();
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		if(PRODUCT=='via'){
		$settingsUrl = DEST_PATH.'via_settings.json';
		$response = file_get_contents($settingsUrl);
		//decrypt json
		$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
		$templateSettings = json_decode($decryptResponse);
		$show_date_format=$templateSettings->VIA_CONFIG_TEMPLATE->via_settings->date_time->date_time_format;
		}else{
			$show_date_format=$date_format='Y-m-d H:i:s';
		}
		
		if(!$request->isPost()) {
			$startDate = "";
			$endDate = "";
			$strUserName = "";
			$data = $this->getActivityLogMasterTable()->getUserLogList();
			$startDate = date("Y-m-d");
			$endDate = date("Y-m-d");
			if(isset($_GET['search'])||isset($_GET['startdate'])||isset($_GET['enddate'])) {
			if($_GET["search"] || $_GET["startdate"] || $_GET["enddate"]){
				$strUserName = htmlspecialchars(trim($_GET["search"]));
				$startDate = htmlspecialchars(trim($_GET["startdate"]));
				$endDate = htmlspecialchars(trim($_GET["enddate"]));
				$data = $this->getActivityLogMasterTable()->getUserLogListSearch($strUserName, $startDate, $endDate, null);
				$search = $strUserName;
			}
			else{
				$startDate = "";
				$endDate = "";
				$strUserName = "";
				$data = $this->getActivityLogMasterTable()->getUserLogListSearch($strUserName, $startDate, $endDate, null);
		
			}
		}
		} else {
		
			$form->setData($request->getPost());
			if(!$form->isValid()) {
				return new ViewModel(array('form' => $form, 'data' => $data, 'dateformat' => $show_date_format));
			}
			$dataPost = $form->getData();
			$startDate = trim($dataPost['startdate']);
			$endDate = trim($dataPost['enddate']);
			$strUserName = trim($dataPost['search']);
			 if(strstr($strUserName,"'") || strstr($strUserName,"\"") || strstr($strUserName,",") || strstr($strUserName,">") || strstr($strUserName,htmlentities("<")) ){
				die("Error in data");
			}

			$data = $this->getActivityLogMasterTable()->getUserLogListSearch($strUserName, $startDate, $endDate, null);
			
			if(isset($_POST['exportcsv'])) {
				$result = $this->getActivityLogMasterTable()->getUserLogListSearch($strUserName, $startDate, $endDate, "export");
				$this->exportToCsv($result['data'], 'web');
			}
			if(isset($_POST['exportpdf'])) {
				$result = $this->getActivityLogMasterTable()->getUserLogListSearch($strUserName, $startDate, $endDate, "export");
				$this->exportToPDF($result['data'], 'web');
			}
		}
		$form->setData(array('startdate' => $startDate, 'enddate' => $endDate, 'search' => $search,));
		$data['data']->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
		$data['data']->setItemCountPerPage(50);
		$viewmodel = new ViewModel(array('form' => $form, 'data' => $data['data'], 'dateformat' => $show_date_format,'count'=>$data['count']));
		//added by niraj for load menus data into tab
		if(PRODUCT=='via'){
			$viewmodel->setTemplate('webapp/reports/list');
		}
		return $viewmodel;
	}
	
	
	/*****
	 *	@Function Name: exportToCsv
	 *  @description  : export web and client data in csv
	 *	@Author		  : Vineet
	 *  @Date         : 16-april-2020
	 *****/
	public function exportToCsv($data, $gatewayName) {
		$idx = 0;
		$appObj = new ApplicationController();
		if(PRODUCT=='via'){
			$fileName='GatewayActivityLog.csv';
		}else{
			$fileName='viaActivityLog.csv';
			
		}
		$session = new Container('userinfo');	
		$lang=$session->offsetGet('lang');
		if($gatewayName == 'client') {
			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename='.$fileName);
			$output = fopen('php://output', 'w');
			if(PRODUCT=='via'){
				fputcsv($output, array(STR_WEBADMIN_USERNAME, STR_ACTIVITY_DATE, STR_REMARKS));
			}else{
				fputcsv($output, array('UserName', 'Gateway Name','Activity Date', 'remarks'));
			}
			foreach($data as $row) {
				if(PRODUCT=='vsm'){
				$gatewayName=$appObj->getGatewayName($row->DeviceID);
				$gatewayName=($gatewayName!="")?$gatewayName:'-';
				$temp = array($row->UserName,
							 $gatewayName,
							 $row->ActivityDate.' '.$row->StartTime,
							 $row->Comments,
							 );
				$jsonData[$idx ++] = $temp;
				}else{
				$temp = array($row->username,
							$row->activitydate.' '.$row->starttime,
							$row->comments,
							 );
				$jsonData[$idx ++] = $temp;
			}
			
			}
				foreach($jsonData as $column)
				{
					fputcsv($output, $column);
				}
			exit();
		} else {
			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename=adminActivityLog.csv');
			// if($lang=='jap'){
			// 	echo "\xEF\xBB\xBF";
			// }
			$output = fopen('php://output', 'w');
			//fputcsv($output, array(STR_GATEWAY_LOG_USER, STR_ACTION_TAKEN, STR_ACTIVITY_DATE, STR_REMARKS, STR_HOSTNAME));
			fputcsv($output, array('User', 'ActionTaken', 'Activity Date', 'Remarks', 'Hostname'));
			foreach($data as $row) {
				$temp = array($row->userid,
							 $row->actiontaken,
							 $row->activitydate,
							 $row->remarks,
							 $row->hostname,
							 );
				$jsonData[$idx ++] = $temp;

			
			}
				foreach($jsonData as $column)
				{
					fputcsv($output, $column);
				}
			exit();
			

		}
	}

	/*****
	 *	@Function Name: exportToPDF
	 *  @description  : export data to pdf
	 *	@Author		  : Vineet
	 *  @Date         : 15-april-2020
	 *****/
	public function exportToPDF($data,$gatewayName) {
		$appObj = new ApplicationController();
				$idx = 0;
				ob_clean();
				if(PRODUCT=='via'){
					$fileName='GatewayActivityLog.pdf';
				}else{
					$fileName='viaActivityLog.pdf';
					
				}
				$pdf = new \PDF_MC_Table();
				$pdf->AddPage();
				$pdf->AliasNbPages();
				$pdf->SetFont('Arial', 'B', 11);
			    if($gatewayName == 'client') {
				//ob_start();
			    if(PRODUCT=='via'){
					$header = array(STR_WEBADMIN_USERNAME,
					STR_ACTIVITY_DATE,
					STR_REMARKS);
				}else{
					$header=array('UserName','Gateway Name','ActivityDate','remarks');
				}
				
				foreach($header as $heading) {
					//foreach($heading as $column_heading)
					$pdf->Cell(38, 11, $heading, 1);
				}

				foreach($data as $row) {
				if(PRODUCT=='vsm'){
				$gatewayName=$appObj->getGatewayName($row->deviceid);
				$gatewayName=($gatewayName!="")?$gatewayName:'-';
				$temp = array($row->username,
							 $gatewayName,
							 $row->activitydate.' '.$row->starttime,
							 $row->comments,
							 );
				$jsonData[$idx ++] = $temp;
				}else{
					$temp = array($row->username,
							 $row->activitydate.' '.$row->starttime,
							 $row->comments,
							 );
				$jsonData[$idx ++] = $temp;
				}

			}
				
				$pdf->SetWidths(array(38, 38, 38, 38, 38));
				$pdf->Ln();
				foreach($jsonData as $row) {
					$pdf->SetFont('Arial', '', 11);
					$pdf->Row($row);
				}
				$pdf->Output($fileName, "D");
		}
			else
			{
				$header=array('UserName','ActionTaken','ActivityDate','Remarks','Hostname');
				foreach($header as $heading) {
					//foreach($heading as $column_heading)
		
					$pdf->Cell(38, 11, $heading, 1);
				}
				
				foreach($data as $row) {
				$activity_date = !empty($row->activitydate) ? date('Y-m-d H:i:s', strtotime($row->activitydate)) : $row->activitydate;
				$temp = array($row->userid,
							 $row->actiontaken,
							 $activity_date,
							 $row->remarks,
							 $row->hostname,
							 );
				$jsonData[$idx ++] = $temp;

			
			}
				
				
				$pdf->SetWidths(array(38, 38, 38, 38, 38));
				$pdf->Ln();
				foreach($jsonData as $row) {
					$pdf->SetFont('Arial', '', 11);
					$pdf->Row($row);
				}
				$pdf->Output('adminActivityLog.pdf', "D");
			}
				//ob_end_flush(); 
		
	}
	/*****
	 *	@Function Name: getActivityLogMasterTable
	 *  @description  : get table
	 *	@Author		  : Vineet
	 *  @Date         : 15-april-2020
	 *****/
	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}
	
	public function getProjectorLogTable() {
		if(!$this->TblProjectorLogTable) {
			$sm = $this->getServiceLocator();
			$this->TblProjectorLogTable = $sm->get('Webapp\Model\TblProjectorLogTable');
		}
		return $this->TblProjectorLogTable;
	}
	
	public function export1(){
		
	}	
	
	
}
