<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\SettingsForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\WebProducerController;

class VsmSettingsController extends AbstractActionController {

    public function onDispatch(MvcEvent $e) {
        $session = new Container('userinfo');
        $user = $session->offsetGet('LoginName');   
        //check session code
        $appObj = new ApplicationController();
        //getting sessionTimeOut value. bydefault value is 10
        $tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
        foreach($tblSessionTimeOutDataArr as $sessiondata){
            $getSettingData=$sessiondata['logoutTime'];
        }
        $getSettingData=($getSettingData>0)?$getSettingData:10; 
        //now getting session time out based on query and compare   
        $qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
        $tblSessionCheckdataArr=$appObj->returnQueryData($qry2);        
        if($tblSessionCheckdataArr->count() > 0){
            $updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
            $appObj->executeQueries($updSession);
        }else{                  
            return $this->redirect()->toRoute('index', array('action' => 'logout'));
        }
        //end check session code        
            
        if(empty($user)) {
            // redirect if not
            return $this->redirect()->toRoute('index',array('action' => 'index'));
        }
        return parent::onDispatch($e);
    }

    public function settingsAction() {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $session = new Container('userinfo');
        $loginName = $session->offsetGet('LoginName');
    	$AppObj = new ApplicationController();
        $sessionTimeOutArray=array('10'=>'10 Minute','20'=>'20 Minute','30'=>'30 Minute','60'=>'1 Hour','120'=>'2 Hours','360'=>'6 Hours','1440'=>'24 Hours');   
        //$fequencyAlertArray=array('5'=>'5 Minute','10'=>'10 Minute','30'=>'30 Minute','60'=>'1 Hour','1440'=>'24 Hours');  
        $cmplxSettings = $AppObj->getVsmComplexPasswordSettings();
    	//via discovery
        $statusQry=$AppObj->returnQueryData("SELECT * FROM tbl_auto_discover_status");
        if($statusQry->count()>0){
            foreach($statusQry as $statusdata){
                $autoServerStatus=$statusdata['isactive'];
                $dns_name=$statusdata['dns_name'];
            }
        }else{
            $autoServerStatus=0;
            $dns_name=$_SERVER['SERVER_ADDR'];
        }
		$sessionVal = $this->getSettingsTable()->fetchAllRows();
		$captchaTxt = $sessionVal['field3'];
		$disabled = '';
		if(file_exists($_SERVER["DOCUMENT_ROOT"]."/../bin/config/serverconfig.xml")){
			if($autoServerStatus == 0){
				$AppObj->executeQueries("UPDATE tbl_auto_discover_status SET isactive=1");
			}
			if($captchaTxt == 0){
				$AppObj->executeQueries("UPDATE settings SET field3=1");
			}
			$autoServerStatus = 1;
			$captchaTxt = 1;
			$disabled = 'disabled';
		}// end autoboarding 
          //Get or insert session value
          

        $syncResult= $AppObj->returnQueryData("SELECT DeviceName,mac_address FROM DeviceInventory d left join tbl_mac_address_sync syn on d.MacAddress=syn.mac_address");
        $firebaseStatus=file_exists(DEST_PATH.FILE_FIREBASE)?1:0;     
    	$form = new SettingsForm($sessionTimeOutArray,$sessionVal,$cmplxSettings);
        $viewmodel = new ViewModel(array('form' => $form, 'logoutTime' => $sessionVal['logoutTime'],
        'captchaTxt' => $captchaTxt,
        'gwayIdVal'=>$sessionVal['field4'],
    	'alphanumericSetting' => $cmplxSettings['alphanumeric'], 
        'specialCharSetting' => $cmplxSettings['specialchar'], 
        'capitalLtrSetting' => $cmplxSettings['capitalltr'], 
        'oldPassSetting' => $cmplxSettings['checkoldpass'],
        'minCharSetting' => $cmplxSettings['minimumchar'],
        'passValiditySetting' => $cmplxSettings['passvalidity'],
        'autoServerStatus' => $autoServerStatus,
        'dns_name' => $dns_name,
        'disabled' => $disabled,
        'starttime'=>$sessionVal['startTime'],
        'endtime'=>$sessionVal['endTime'],
        'syncResult'=>$syncResult,
        'firebaseStatus'=>$firebaseStatus
    	));
        return $viewmodel;

    }
	/*****
	 *	@function Name		: sessionSettingAction
	 *  @description	    : set session value 
	 *	@Author			    : Vineet
	 *  @Date               : 25-march-2020
	 *****/
    public function sessionSettingAction(){
        $session = new Container('userinfo');
        $loginName = $session->offsetGet('LoginName');
		$user_id = $session->offsetGet('usrid');
        $hostname = DEFAULT_SERVER_IP;
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $timeVal = trim($request->getPost('timeVal'));
            $gwayIdVal = trim($request->getPost('gwayValue'));
            $val=$this->getSettingsTable()->insertSessionTime($timeVal,$gwayIdVal,$user_id);
			 echo $val;die();
           
        }
    }
    /*****
	 *	@function Name		: securitySettingsAction
	 *  @description	    : set security value 
	 *	@Author			    : Vineet
	 *  @Date               : 25-march-2020
	 *****/
	public function securitySettingsAction(){
        $session = new Container('userinfo');
        $loginName = $session->offsetGet('LoginName');
        $obj = new ApplicationController();
        $hostname = DEFAULT_SERVER_IP;
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $captchaVal = trim($request->getPost('captchaVal'));
            $alphanumericValue = trim($request->getPost('alphanumericVal'));
            $specialCharValue = trim($request->getPost('specialCharVal'));
            $capitalLtrValue = trim($request->getPost('capitalLtrVal'));
             $minimumChar = trim($request->getPost('minimumCharVal'));
        }
		
        $captchaArr = array('field3'=>$captchaVal);
        $this->getSettingsTable()->updateCaptcha($captchaArr);
        $policyArr = array('alphanumeric'=>$alphanumericValue, 'specialchar'=>$specialCharValue, 'capitalltr'=>$capitalLtrValue, 'minimumchar'=> $minimumChar );
        $this->getComplexPasswordTable()->updatePasswordPolicy($policyArr);
        //$this->getActivityLogMasterTable()->setActivity($loginName, UPDATE_BTN, MSG_PASSWORD_POLICY_UPDATED, $hostname);
        $obj->ActivityLogVSM(4,MSG_PASSWORD_POLICY_UPDATED,11);
        echo "success"; die;
    }


    /*****
     *  @Function Name: checkDomainAction
     *  @description  : check VIA discovery server connectivity status
     *  @Author       : Ranjan
     *  @Date         : 19-may-2020
     *****/
    public function checkDomainAction(){
        $appObj = new ApplicationController();
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $pingDomain = trim($request->getPost('pingDomain'));
            $pingDomainPort = trim($request->getPost('pingDomainPort'));
            $tB = microtime(true); 
            $fP = fSockOpen($pingDomain, $pingDomainPort, $errno, $errstr, 10); 
            if (!$fP) { $respTime = "down"; } 
            $tA = microtime(true); 
            $respTime = round((($tA - $tB) * 1000), 0)." ms"; 
            echo ($respTime!="down")?'Success':'Failed';die;
        }
    }
    
    /*****
     *  @Function Name: applyAutoVsmSettingAction
     *  @description  : set via discovery on-off
     *  @Author       : Ranjan
     *  @Date         : 19-may-2020
     *****/
    public function applyAutoVsmSettingAction(){
        $session = new Container('userinfo');
        $username = $session->offsetGet('LoginName'); //get the user
        $appObj = new ApplicationController();
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $autoStatus=trim($request->getPost('autoStatus'));
            $sql=$appObj->returnQueryData("SELECT * FROM tbl_auto_discover_status");
            if($sql->count()>0){
                $appObj->executeQueries("UPDATE tbl_auto_discover_status SET isactive=$autoStatus,dns_name='".HOSTNAME."',modifydate='".date('Y-m-d H:i:s')."'");    
            }else{
                $appObj->executeQueries("INSERT INTO tbl_auto_discover_status(isactive,dns_name,modifydate) values($autoStatus,'".HOSTNAME."','".date('Y-m-d H:i:s')."')");
            }
            echo 'success'; die;   
        }
    }
			
        
    
    /*****
	     *	@function Name		: frequencyAlertSetting
	     *  @description	    : set security value 
	     *	@Author			    : Vineet
	     *  @Date               : 15-may-2020
	*****/
    public function frequencyAlertSettingAction(){
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $alertVal = trim($request->getPost('alertVal'));
            $this->getSettingsTable()->insertFrequencyAlert($alertVal);
            echo "success";die();
        }
    }

    public function viaSettingsAction(){
        $session = new Container('userinfo');
        $username = $session->offsetGet('LoginName');
        $user_id = $session->offsetGet('usrid');
        $appObj = new ApplicationController();
        //remove the deviceid from tbl_group_store in case of basic mode(3-July-2017)
        $appObj->executeQueries("UPDATE tbl_group_store SET deviceID='' WHERE userid_fk=".$user_id);
        /* ***************  For processing Groups *************** */
        $result = $appObj->returnQueryData("SELECT * FROM devicegroup");
        $groupCount = $result->count();
        $arrayCategories = array();
        foreach ($result as $key => $row) {
            $arrayCategories[$row['DeviceGroupID']] = array("parent_id" => $row['DeviceMasterID'], "name" => $row['DeviceGroup'],"grp_ID" =>$row['DeviceGroupID']);
        }
        
        $form = new SettingsForm();
        $viewModel = new ViewModel(array(
            'form' => $form,
            'groupCount' => $groupCount,
            'arrayCategories' => $arrayCategories,
            'user_id' => $user_id, 
        ));
        //$viewModel->setTerminal(true);
        return $viewModel;
    }

    public function applyHQMasterSettingAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $selectedItems = trim($request->getPost('selectedItems'));
                $selectedGroups = trim($request->getPost('selectedGroups'));
                $groupName=implode("','",explode(',',$selectedGroups));
                $appObj = new ApplicationController();
                $dataQry1=$appObj->returnQueryData("SELECT DeviceGroupID FROM devicegroup WHERE DeviceGroup IN ('".$groupName."')"); 
                foreach ($dataQry1 as $key => $datarow) {
                    $DeviceGroupId[] = $datarow['DeviceGroupID'];
                }
                
				list($wallpaperArrSet,$configArrSet,$authArrSet,$gwayArrSet,$clintArrSet,$mobileArrSet,$globalArrSet,$dssArrSet,$calendarArrSet)=explode(',',$selectedItems);
                list($wallpOpt,$wallpVal)=explode('#',$wallpaperArrSet);
                list($configOpt,$configVal)=explode('#',$configArrSet);
                list($authOpt,$authVal)=explode('#',$authArrSet);
                list($gwayOpt,$gwayVal)=explode('#',$gwayArrSet);
                list($clintOpt,$clintVal)=explode('#',$clintArrSet);
                list($mobileOpt,$mobileVal)=explode('#',$mobileArrSet);
                list($dssOpt,$dssVal)=explode('#',$dssArrSet); 
                list($globalOpt,$globalVal)=explode('#',$globalArrSet);
                list($calendarOpt,$calendarVal)=explode('#',$calendarArrSet);

                foreach ($DeviceGroupId as $key => $group) {
                     $chkQuery = $appObj->returnQueryData("SELECT * FROM tbl_auto_discover_vsm_mapping WHERE isGrpIdOrDeviceId=$group AND entryType=0");
                     if($chkQuery->count() > 0){
                        $appObj->executeQueries("UPDATE tbl_auto_discover_vsm_mapping SET HQ_WallpaperSetting=$wallpVal,HQ_AuthSetting=$authVal,HQ_ConfigSetting=$configVal,HQ_GwayFeatureSetting=$gwayVal, HQ_ClientFeatureSetting=$clintVal, HQ_MobileFeatureSetting=$mobileVal,featureStatus1=$configVal,featureStatus2=$dssVal,featureStatus4=$globalVal,featureStatus5=$calendarVal WHERE isGrpIdOrDeviceId=$group AND entryType=0");
                     }else{
                        $appObj->executeQueries("INSERT INTO tbl_auto_discover_vsm_mapping (HQ_WallpaperSetting,HQ_AuthSetting,HQ_ConfigSetting,HQ_GwayFeatureSetting,HQ_ClientFeatureSetting,HQ_MobileFeatureSetting,featureStatus1,featureStatus2,featureStatus4,featureStatus5,isGrpIdOrDeviceId,entryType) VALUES ($wallpVal,$authVal,$configVal,$gwayVal,$clintVal,$mobileVal,$configVal,$dssVal,$globalVal,$calendarVal,$group,0)");
                     }
                }
                $deviceGroupIdStr = implode(',',$DeviceGroupId);
                $didQuery = $appObj->returnQueryData("SELECT DID FROM DeviceInventory WHERE DeviceGroupID IN ($deviceGroupIdStr)");
                if($didQuery->count() > 0){
                    $via_did = array();
                    foreach ($didQuery as $key => $did) {
                        $didStr .= $did['DID'].',';
                        $via_did[]['device_id'] = $did['DID'];
                    }
                    $didStr = rtrim($didStr,',');
                    $appObj->executeQueries("UPDATE tbl_sys_report SET Last_Updated_Time=now(), wallpaper_status=0, configSettingStatus=0 WHERE did_fk IN($didStr)");
                    $appObj->executeQueries("UPDATE tbl_advance_sys_report SET Last_Updated_Time=now(), extraField1=0, extraField4=0 WHERE did_fk IN($didStr)");
                    $appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($didStr)");
                    //RabbitMQ Command for reset
                    $cmdArr=array("cmd"=>"reset","sender"=>"web-vsm","request_id"=>"","via_did"=>$via_did);
                    $cmdJson=json_encode($cmdArr);
                    $producerObject=new WebProducerController();
                    $producerObject->rabbitWebProducerAction($cmdJson);
                }
                
                echo "success";die;
           }     
                
    }

    public function getCurrentGrpAction(){
        $session = new Container('userinfo');
        $loginName = $session->offsetGet('LoginName');
        $hostname = DEFAULT_SERVER_IP;
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $appObj = new ApplicationController();
            $grpName = trim($request->getPost('grpName'));
            $groupNameStr = implode("','",explode(',',$grpName));
            $grpIdSql = $appObj->returnQueryData("SELECT DeviceGroupID FROM devicegroup WHERE DeviceGroup IN ('".$groupNameStr."')");
            foreach($grpIdSql as $key => $value) {
                $grpIdArr[]=$value['DeviceGroupID'];
            }
            $grpId=implode(',',$grpIdArr);
            $checkSettings_mapping = $appObj->returnQueryData("SELECT HQ_WallpaperSetting,HQ_ConfigSetting,featureStatus2,featureStatus5 FROM tbl_auto_discover_vsm_mapping WHERE isGrpIdOrDeviceId IN ($grpId)");
            if($checkSettings_mapping->count() == 0){
                $checkSettings = $appObj->returnQueryData("SELECT HQ_WallpaperSetting,HQ_ConfigSetting,featureStatus2,featureStatus5 FROM tbl_auto_discover_vsm LIMIT 1");
                if($checkSettings->count() > 0){
                    $settingsArray = $checkSettings->current();
                }
            }else{
                $settingsArray = $checkSettings_mapping->current();
            }
            echo json_encode($settingsArray);die;
        }
    }

     /*****
	     *	@function Name		: startTime
	     *  @description	    : set business working hour start time
	     *	@Author			    : Vineet
	     *  @Date               : 24-dec-2020
	*****/
    public function startTimeAction(){
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $timeVal = trim($request->getPost('starttime'));
            $startTime  = date("H:i", strtotime($timeVal));
            $this->getSettingsTable()->insertStartEndTime($startTime,'starttime');
            echo "success" ;die();
        }
    }

        /*****
	     *	@function Name		: endTime
	     *  @description	    : set business working hour end time
	     *	@Author			    : Vineet
	     *  @Date               : 24-dec-2020
	*****/
    public function endTimeAction(){
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
            $timeVal = trim($request->getPost('endtime'));
            $endTime  = date("H:i", strtotime($timeVal));
            $this->getSettingsTable()->insertStartEndTime($endTime,'endtime');
            echo "success" ;die();
        }
    }

   /*****
	     *	@function Name		: resyncGatewayAction
	     *  @description	    : resync gateway 
	     *	@Author			    : Vineet
	     *  @Date               : 20-jan-2021
	*****/
    public function resyncGatewayAction(){
        $request = $this->getRequest();
        $appObj = new ApplicationController();
        if($request->isXmlHttpRequest()) {
            $chkBoxMacAdrress=explode(",",trim($_POST['chkBoxMacAdrress']));
            foreach($chkBoxMacAdrress as $macAdress){
                $chkBoxVal=explode("&&",$macAdress);
                $appObj->executeQueries("DELETE FROM tbl_mac_address_sync WHERE mac_address='$chkBoxVal[0]'");
            }
            echo "success";
            die();
        }
    }

    /*****
	 *	@Function Name		: firebaseSettingAction
	 *  @description	    : for firebase  setting on/off
     *	@Author			    : Vineet 
	 *  @Date               : 1-march-2021
	 *****/
	public function firebaseSettingAction(){
		$request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
		$firebaseStatus=trim($request->getPost('firebaseStatus'));
		$myfileName=DEST_PATH.FILE_FIREBASE;
        if ($firebaseStatus==1) {
            fopen($myfileName, "w") or die("can't open file");;
        }else{
			unlink($myfileName);
		}
		echo "success";
		die;
        }
	}

	/*****
	 *	@Function Name: getSettingsTable
	 *  @description  : get setting table
	 *	@Author		  : Vineet
	 *  @Date         : 27-march-2020
	 *****/
	public function getSettingsTable() {
        if(!$this->TblSettingsTable) {
                $sm = $this->getServiceLocator();
                $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}
	      
	/*****
	 *	@Function Name: getComplexPasswordTable
	 *  @description  : get table
	 *	@Author		  : Vineet
	 *  @Date         : 27-march-2020
	 *****/
	public function getComplexPasswordTable() {
        if(!$this->TblComplexPasswordTable) {
                $sm = $this->getServiceLocator();
                $this->TblComplexPasswordTable = $sm->get('Webapp\Model\TblComplexPasswordTable');
        }
        return $this->TblComplexPasswordTable;
	}
	
    /*****
	 *	@Function Name: getActivityLogMasterTable()
	 *  @description  : get table
	 *	@Author		  : Vineet
	 *  @Date         : 27-march-2020
	 *****/
    public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}
}