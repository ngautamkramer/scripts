<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\TtfInfo\TtfInfo;
use Zend\Validator\File\MimeType;

class DssContentController extends AbstractActionController {	

	public function getMediaComponentMasterTable() {
		if(!$this->TblMediaComponentMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblMediaComponentMasterTable = $sm->get('Webapp\Model\TblMediaComponentMasterTable');
		}
		return $this->TblMediaComponentMasterTable;
	}
	
	public function getMediaTypeMasterTable() {
		if(!$this->TblMediaTypeMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblMediaTypeMasterTable = $sm->get('Webapp\Model\TblMediaTypeMasterTable');
		}
		return $this->TblMediaTypeMasterTable;
	}

	public function getMediaInventryTable() {
		if(!$this->TblMediaInventryTable) {
			$sm = $this->getServiceLocator();
			$this->TblMediaInventryTable = $sm->get('Webapp\Model\TblMediaInventryTable');
		}
		return $this->TblMediaInventryTable;
	}

	public function getDssFontInfoTable() {
		if(!$this->TblDssFontInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblDssFontInfoTable = $sm->get('Webapp\Model\TblDssFontInfoTable');
		}
		return $this->TblDssFontInfoTable;
	}

	public function getCampaignMediaTable() {
		if(!$this->TblCampaignMediaTable) {
			$sm = $this->getServiceLocator();
			$this->TblCampaignMediaTable = $sm->get('Webapp\Model\TblCampaignMediaTable');
		}
		return $this->TblCampaignMediaTable;
	}

	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}

	public function getSettingTable() {
		if(!$this->TblSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}
	public function checkMediaTypeAllowed() {
		$mediaTypes = [];
		$mediaTypeMasterTable = $this->getMediaTypeMasterTable();		
		$mediaTypeResultSet = $mediaTypeMasterTable->getMediaType();
		foreach($mediaTypeResultSet as $mediaTypeResultSetValue) {
			$resultSetJson = json_encode($mediaTypeResultSetValue); 
			$resultSet = json_decode($resultSetJson, true);
			$mediaTypes[$resultSet['mediatypeid']] = $resultSet['mediatype'];
		}
		return $mediaTypes;
	}

	public function getPlayLength($mediaType){
        $mediaType = strtolower($mediaType);
        switch($mediaType)
        {
           case "jpeg":              
           case "png":    
           case "jpg":              
           case "bmp": 
           case "gif":  
           case "tiff":  
             return 60;
           break;
           default:
              return 0;
           break;
        }
    }

	public function updateMediaAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
			
		$postData = $this->getRequest()->getPost()->toArray();		
		$mediaFile = $this->params()->fromFiles('mediaFile');
		$crsf_tokenval = trim($postData['crsf_tokenval']);		
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}

		$validator = new \Zend\Validator\File\MimeType(
			array('image/gif', 'image/jpg', 'image/jpeg', 'text/plain', 'image/bmp', 'image/png', 'video/mp4',
			'video/x-msvideo', 'video/mpeg', 'video/x-ms-wmv', 'video/quicktime', 'video/x-m4v', 'video/mkv',
			'video/x-ms-vob', 'video/x-matroska', 'video/x-ms-asf', 'image/x-ms-bmp')
		);

		// echo "<pre>";
		// print_r($mediaFile);
		// echo "</pre>";		
		// exit;
		$uploadedMediaType = strtolower(substr($mediaFile['name'], strrpos($mediaFile['name'], '.') +1));
		$mediaTypes = $this->checkMediaTypeAllowed();
		if ($validator->isValid($mediaFile['tmp_name'])) {
			if($postData['fileFlag'] == 'newMediaFile') {
				if($mediaFile['error'] == 0) {
					$mediaFileName = $mediaFile['name'];
					$upload = move_uploaded_file($mediaFile['tmp_name'], UPLOAD_CONTENT_MEDIA.$mediaFileName);
					if($upload) {
						$mediaTypeMasterTable = $this->getMediaTypeMasterTable();		
						$mediaTypeResultSet = $mediaTypeMasterTable->getMediaTypeIdByName($uploadedMediaType);
						foreach($mediaTypeResultSet as $mediaTypeResultSetValue) {
							$resultSetJson = json_encode($mediaTypeResultSetValue); 
							$resultSet = json_decode($resultSetJson, true);
							$mediaTypeID = $resultSet["mediatypeid"];
						}
						$playLengthValue = $this->getPlayLength($uploadedMediaType);
						$postMedia = array();
						$postMedia["medianame"] = $mediaFileName;
						$postMedia["mediatypeid"] = $mediaTypeID;
						$postMedia["mediaoriginalname"] = "";
						$postMedia["mediapath"] = "";
						$postMedia["playlength"] = $playLengthValue;
						$postMedia["autotype"] = "Y";
						$postMedia["isfiller"] = "Y";
						$postMedia["clientid"] = 1;
						$postMedia["appname"] = "VistaWeb";
						$postMedia["username"] = $session->offsetGet('LoginName');
						$postMedia["hostname"] = HOSTNAME;
						$postMedia["isdeleted"] = 'N';
						$postMedia["modifydate"] = date("Y-m-d H:i:s");
						$postMedia["mediasize"] = filesize(UPLOAD_CONTENT_MEDIA.$mediaFileName);
						$mediaInventoryTable = $this->getMediaInventryTable();
						$lastInsertedId = $mediaInventoryTable->insertMediaInventory($postMedia);
						if(PRODUCT=='vsm'){
							$mediaOrignalName = 'VSM_F_'.$lastInsertedId.'.'.$uploadedMediaType;
						}else{
							$mediaOrignalName = 'F_'.$lastInsertedId.'.'.$uploadedMediaType;
						}
						
						rename(UPLOAD_CONTENT_MEDIA.stripslashes($mediaFileName), UPLOAD_CONTENT_MEDIA.$mediaOrignalName);
						$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$mediaOrignalName);
						$updateMedia = array();
						$updateMedia['mediaoriginalname'] = $mediaOrignalName;
						$updateMedia["mediachecksum"] = $md5Hash;
						$updateMediaWhere = array();
						$updateMediaWhere['mediaid'] = $lastInsertedId;
						$mediaInventoryTable->updateMediaInventory($updateMediaWhere, $updateMedia);
						echo "media added";
					}	
				}
			}
		} else {
			echo "media not supported";
		}
		exit;
	}

	public function updateWebUrlAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
			
		$postData = $this->getRequest()->getPost()->toArray();
		$crsf_tokenval=trim($postData['crsf_tokenval']);
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}
		
		$mediaInventoryTable = $this->getMediaInventryTable();
		// echo "<pre>";
		// print_r($postData);
		// echo "</pre>";
		// exit;
		$webAutoRefresh = $postData["webAutoRefresh"];
		$webUrl = $postData["webUrl"];
		$fileName = htmlspecialchars($postData["fileName"]);
 		$responseReturn = "";
 		$fileExtensionChk = "vurl";
		if($webUrl == "") {
 			$responseReturn = "blank weburl";
		} else if($webUrl != "") {			
			if (!filter_var($webUrl, FILTER_VALIDATE_URL)) {
				$responseReturn = "invalid weburl";
			}	
		} if($fileName == "") {
			$responseReturn = "blank filename";
		} else if($fileName != "") {
			$uniqueNameSearch = array();
			$uniqueNameSearch["MediaName"] = $fileName . "." . $fileExtensionChk;
			if($postData["postAction"] == "add") {
				$uniqueNameData = $mediaInventoryTable->checkMediaUniqueName($uniqueNameSearch);
			} else if($postData["postAction"] == "edit" && $postData["postMediaId"] != "") {
				$uniqueNameSearch["mediaid"] = $postData["postMediaId"];
				$uniqueNameData = $mediaInventoryTable->checkMediaUniqueName($uniqueNameSearch);
			}
			$responseReturn = count($uniqueNameData) == 0 ? "" : "filename name exits";
		}

		if($responseReturn == "") {
			$fileWriteArray = array($webUrl, $webAutoRefresh);
	        $strFileWrite = implode("~@~", $fileWriteArray);
	        // this is the only code that run in case of edit web url content
	      
			$txtFileName = trim($fileName). "." .$fileExtensionChk;
			$mediaTypeMasterTable = $this->getMediaTypeMasterTable();		
			$mediaTypeResultSet = $mediaTypeMasterTable->getMediaTypeIdByName($fileExtensionChk);
			foreach($mediaTypeResultSet as $mediaTypeResultSetValue) {
				$resultSetJson = json_encode($mediaTypeResultSetValue); 
				$resultSet = json_decode($resultSetJson, true);
				$mediaTypeID = $resultSet["mediatypeid"];
			}
			$postWebUrl = array();
			$postWebUrl["medianame"] = $txtFileName;
			$postWebUrl["mediatypeid"] = $mediaTypeID;
			$postWebUrl["mediaoriginalname"] = "";
			$postWebUrl["mediapath"] = "";
			$postWebUrl["playlength"] = 60;
			$postWebUrl["autotype"] = "Y";
			$postWebUrl["isfiller"] = "Y";
			$postWebUrl["clientid"] = 1;
			$postWebUrl["appname"] = "VistaWeb";
			$postWebUrl["username"] = $session->offsetGet('LoginName');
			$postWebUrl["hostname"] = HOSTNAME;
			$postWebUrl["isdeleted"] = 'N';
			$postWebUrl["modifydate"] = date("Y-m-d H:i:s");
			if($postData["postAction"] == "add") {
				$fh = fopen(UPLOAD_CONTENT_MEDIA.$txtFileName,'w');
				fwrite($fh, $strFileWrite);
				fclose($fh);
				$responseReturn = "url added";
				$postWebUrl["mediasize"] = filesize(UPLOAD_CONTENT_MEDIA.$txtFileName);
				$lastInsertedId = $mediaInventoryTable->insertMediaInventory($postWebUrl);
				if(PRODUCT=='vsm'){
					$mediaOrignalName = 'VSM_F_'.$lastInsertedId. '.' .$fileExtensionChk;
				}else{
					$mediaOrignalName = 'F_'.$lastInsertedId. '.' .$fileExtensionChk;
				}
				
				rename(UPLOAD_CONTENT_MEDIA.stripslashes($txtFileName), UPLOAD_CONTENT_MEDIA.$mediaOrignalName);
				$updateWebUrl = array();
				$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$mediaOrignalName);
				$updateWebUrl["mediachecksum"] = $md5Hash;
				$updateWebUrl['mediaoriginalname'] = $mediaOrignalName;
				$updateWebUrlWhere = array();
				$updateWebUrlWhere['mediaid'] = $lastInsertedId;
				$mediaInventoryTable->updateMediaInventory($updateWebUrlWhere, $updateWebUrl);
			} else if($postData["postAction"] == "edit" && $postData["postMediaId"] != "") {
				$fh = fopen(UPLOAD_CONTENT_MEDIA.trim($postData["postMediaName"]),'w');
				fwrite($fh, $strFileWrite);
				fclose($fh);				
				$updateWebUrl = array();
				$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.trim($postData["postMediaName"]));
				$updateWebUrl["mediachecksum"] = $md5Hash;
				$updateWebUrl['medianame'] = $txtFileName;
				$updateWebUrl["mediasize"] = filesize(UPLOAD_CONTENT_MEDIA.trim($postData["postMediaName"]));
				$updateWebUrlWhere = array();
				$updateWebUrlWhere['mediaid'] = $postData["postMediaId"];	
				$mediaInventoryTable->updateMediaInventory($updateWebUrlWhere, $updateWebUrl);
				$responseReturn = "url updated";
			}
		}
		echo $responseReturn;
		exit;
	}

	public function updateRssScrollerAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
		
		$postData = $this->getRequest()->getPost()->toArray();
		$crsf_tokenval=trim($postData['crsf_tokenval']);		
		$session_crsf_token." and ".$crsf_tokenval;
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		// echo "<pre>";
		// print_r($postData);
		// echo "</pre>";exit;
		$mediaInventoryTable = $this->getMediaInventryTable();
		
		$contentType = $postData["contentType"];
		$responseReturn = "";
		if($contentType == "rss") {
			$fileExtensionChk = "rss";
			if($postData["rssName"] == "") {
				$responseReturn = "rss name blank";
			} else if ($postData["rssName"] != "") {
				if(strlen($postData["rssName"]) > 255) {
					$responseReturn = "media length exceeds";
				} else {
					$uniqueNameSearch = array();
					$uniqueNameSearch["MediaName"] = $postData["rssName"] . "." . $fileExtensionChk;
					if($postData["postAction"] == "add") {
						$uniqueNameData = $mediaInventoryTable->checkMediaUniqueName($uniqueNameSearch);
					} else if($postData["postAction"] == "edit" && $postData["postMediaId"] != "") {
						$uniqueNameSearch["mediaid"] = $postData["postMediaId"];
						$uniqueNameData = $mediaInventoryTable->checkMediaUniqueName($uniqueNameSearch);
					}				
					$responseReturn = count($uniqueNameData) == 0 ? "" : "rss name exits";
				}
			}
			if($postData["rssUrl"] == "") {
				$responseReturn = "rss url blank";
			} 
			if($postData["rssTag"] == "") {
				$responseReturn = "rss tag blank";
			}
		} else if($contentType == "scroller") {
			$fileExtensionChk = "vsf";
			if($postData["scrollName"] == "") {
				$responseReturn = "scroll name blank";
			} else if($postData["scrollName"] != "") {
				if(strlen($postData["scrollName"]) > 255) {
					$responseReturn = "media length exceeds";
				} else { 
					$uniqueNameSearch = array();
					$uniqueNameSearch["MediaName"] = $postData["scrollName"] . "." .$fileExtensionChk;
					if($postData["postAction"] == "add") {
						$uniqueNameData = $mediaInventoryTable->checkMediaUniqueName($uniqueNameSearch);	
					} else if($postData["postAction"] == "edit" && $postData["postMediaId"] != "") { 
						$uniqueNameSearch["mediaid"] = $postData["postMediaId"];
						$uniqueNameData = $mediaInventoryTable->checkMediaUniqueName($uniqueNameSearch);
					}
					$responseReturn = count($uniqueNameData) == 0 ? "" : "scroll name exits";
				}
			}
			if($postData["scrollText"] == "") {
				$responseReturn = "scroll text blank";
			}
		}

		if($postData["fontFamily"] == "") {
			$responseReturn = "font family blank";
		}
		
		if($responseReturn == "") {
			$fontFamily = $postData["fontFamily"];
			$fontStyle = $postData["fontStyle"];
			$fontWeight = $postData["fontWeight"];
			$textColor = $postData["textColor"];
			$bgColor = $postData["bgColor"];
	 		$ddlRightLeft = "left";
	 		$txtFileName = "";

			if($contentType == "rss") {
				$rssName = htmlspecialchars($postData["rssName"]);
				$rssUrl = $postData["rssUrl"];
				$rssTag = $postData["rssTag"];
				$rssDisplayStyle = $postData["rssDisplayStyle"];
				$textSpeed = $postData["rssSpeed"];
				$fileWriteArray = array($rssUrl, $textColor, $bgColor, $fontFamily, $fontWeight, $textSpeed, $fontStyle, $ddlRightLeft, $rssTag, $rssDisplayStyle);
				$strFileWrite =  implode("~@~", $fileWriteArray);
				$txtFileName = trim($rssName). "." .$fileExtensionChk;
				// this is the only code that run in case of edit rss content
				if($postData["postAction"] == "edit" && (trim($rssName) == trim($postData["postFileName"]))) {
					$responseReturn = "rss updated";
					$fh = fopen(UPLOAD_CONTENT_MEDIA.trim($postData["postMediaName"]),'w');
					//$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$postData["postMediaName"]);
				} else {
					$responseReturn = "rss added";
					$fh = fopen(UPLOAD_CONTENT_MEDIA.$txtFileName,'w');
					//$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$txtFileName);
				}
			} else if($contentType == "scroller") {
				$scrollText = $postData["scrollText"];
				$scrollText = str_replace("\xC2\xA0", ' ', $scrollText);
				$scrollName = htmlspecialchars($postData["scrollName"]);
				$textSpeed = $postData["scrollSpeed"];
				
				$fileWriteArray = array(trim($scrollText), $textColor, $bgColor, $fontFamily, $fontWeight, $textSpeed, $fontStyle, $ddlRightLeft);
				$strFileWrite =  implode("~@~", $fileWriteArray);
				$txtFileName = trim($scrollName). "." .$fileExtensionChk;
				// this is the only code that run in case of edit scroller content
				if($postData["postAction"] == "edit") {
					$responseReturn = "scroller updated";
					$fh = fopen(UPLOAD_CONTENT_MEDIA.trim($postData["postMediaName"]),'w');
					// $md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$postData["postMediaName"]);
				} else {
					$responseReturn = "scroller added";
					$fh = fopen(UPLOAD_CONTENT_MEDIA.$txtFileName,'w');
					// $md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$txtFileName);
				}
			}
			
			//$txtFileName1 = $postData["postMediaName"] == "" ? $txtFileName : $postData["postMediaName"];
			fwrite($fh , $strFileWrite);
			fclose($fh);
			
			
			$mediaTypeMasterTable = $this->getMediaTypeMasterTable();		
			$mediaTypeResultSet = $mediaTypeMasterTable->getMediaTypeIdByName($fileExtensionChk);
			foreach($mediaTypeResultSet as $mediaTypeResultSetValue) {
				$resultSetJson = json_encode($mediaTypeResultSetValue); 
				$resultSet = json_decode($resultSetJson, true);
				$mediaTypeID = $resultSet["mediatypeid"];
			}
			
			$postScrollerRss = array();
			$postScrollerRss["medianame"] = $txtFileName;
			$postScrollerRss["mediatypeid"] = $mediaTypeID;
			$postScrollerRss["mediaoriginalname"] = "";
			$postScrollerRss["mediapath"] = "";
			$postScrollerRss["playlength"] = 60;
			$postScrollerRss["autotype"] = "Y";
			$postScrollerRss["isfiller"] = "Y";
			$postScrollerRss["clientid"] = 1;
			$postScrollerRss["appname"] = "VistaWeb";
			$postScrollerRss["username"] = $session->offsetGet('LoginName');
			$postScrollerRss["hostname"] = HOSTNAME;
			$postScrollerRss["isdeleted"] = 'N';
			$postScrollerRss["modifydate"] = date("Y-m-d H:i:s");
			$mediaInventoryTable = $this->getMediaInventryTable();
			$fontMatchResultSet = $this->getDssFontInfoTable()->getDssFontIdByFontName($fontFamily);
			foreach($fontMatchResultSet as $matchFontInfo) {
                $fontId =  $matchFontInfo->fontid;
            }
			if($postData["postMediaId"] == "" && $postData["postAction"] == "add") {
				$postScrollerRss["mediasize"] = filesize(UPLOAD_CONTENT_MEDIA.$txtFileName);
				$lastInsertedId = $mediaInventoryTable->insertMediaInventory($postScrollerRss);
				if(PRODUCT=='vsm'){
					$mediaOrignalName = 'VSM_F_'.$lastInsertedId. '.' .$fileExtensionChk;
				}else{
					$mediaOrignalName = 'F_'.$lastInsertedId. '.' .$fileExtensionChk;
				}
				
				rename(UPLOAD_CONTENT_MEDIA.stripslashes($txtFileName), UPLOAD_CONTENT_MEDIA.$mediaOrignalName);
				$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$mediaOrignalName);
				$updateScrollerRss = array();
				$updateScrollerRss["mediachecksum"] = $md5Hash;
				$updateScrollerRss['mediaoriginalname'] = $mediaOrignalName;
				$updateScrollerRssWhere = array();
				$updateScrollerRssWhere['mediaid'] = $lastInsertedId;
				$mediaInventoryTable->updateMediaInventory($updateScrollerRssWhere, $updateScrollerRss);
				$fontMatchResultSet = $this->getDssFontInfoTable()->getDssFontIdByFontName($fontFamily);
			} else if($postData["postMediaId"] != "" && $postData["postAction"] == "edit") {
				$updateScrollerRss = array();
				$md5Hash = md5_file(UPLOAD_CONTENT_MEDIA.$postData["postMediaName"]);
				$updateScrollerRss['medianame'] = $txtFileName;
				$updateScrollerRss["mediachecksum"] = $md5Hash;			
				$updateScrollerRss["mediasize"] = filesize(UPLOAD_CONTENT_MEDIA.$postData["postMediaName"]);

				$updateScrollerRssWhere = array();
				$updateScrollerRssWhere['mediaid'] = $postData["postMediaId"];	
				$mediaInventoryTable->updateMediaInventory($updateScrollerRssWhere, $updateScrollerRss);
				if(PRODUCT=='vsm'){
					$mediaOrignalName = 'VSM_F_'.$postData["postMediaId"]. '.' .$fileExtensionChk;
				}else{
					$mediaOrignalName = 'F_'.$postData["postMediaId"]. '.' .$fileExtensionChk;
				}
				
			} 
			
			$postDssScrollerInfo = array();
			$postDssScrollerInfo['fontId_fk'] = $fontId;
			$postDssScrollerInfo['scrollfileName'] = $mediaOrignalName;
			$isMediaFont = $mediaInventoryTable->checkFontWithMedia($postDssScrollerInfo);
			if(count($isMediaFont) == 0) {
				$postDssScrollerInfo['modifydatetime'] = date("Y-m-d H:i:s");
				$mediaInventoryTable->updateDssScrollerInfo($postDssScrollerInfo);	
			}
		}
		echo $responseReturn;
		exit;
	}

	public function deleteContentAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$postData = $this->getRequest()->getPost()->toArray();
		$contentId = $postData["contentId"];
		$crsf_tokenval = $postData["crsf_tokenval"];
		//Security changes added by ashu on 28/03/22. Allow only numeric value 
		if(!is_numeric($contentId) || $contentId <= 0 ){
			echo "Id is not valid";die;
		}		
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		$mediaInventoryTable = $this->getMediaInventryTable();
		$tableCampaignMediaTable = $this->getCampaignMediaTable();
		$campaignMediaRecord = $tableCampaignMediaTable->getMediaAssociationInCampaign($contentId);
		$checkMediaAssociation = false;
		if(count($campaignMediaRecord) > 0) {
			$checkMediaAssociation = true;
		} else {
			$deleteContentWhere = array();
			$deleteContentWhere['mediaId'] = $contentId;

			$searchMediaWhere = array();
			$searchMediaWhere['mediaId'] = $contentId;
			$mediaTypeResultSet = $mediaInventoryTable->getMediaFilenameFromId($searchMediaWhere);

			foreach($mediaTypeResultSet as $mediaTypeResultSetValue) {
				$resultSetJson = json_encode($mediaTypeResultSetValue); 
				$resultSet = json_decode($resultSetJson, true);
				$fileName = $resultSet["mediaoriginalname"];
			}
			unlink(UPLOAD_CONTENT_MEDIA.$fileName);
			$mediaId = $mediaInventoryTable->deleteMediaInventory($deleteContentWhere);

			$deleteScrolleInfo = array();
			$deleteScrolleInfo["scrollFileName"] = $fileName;
			$mediaInventoryTable->deleteDssScrollerInfo($deleteScrolleInfo);
		}
		echo $checkMediaAssociation; exit;
	}

	public function getMediaComponentsAction() {
		$postData = $this->getRequest()->getPost()->toArray();
		$mediaComponentId = $postData["mediaComponentId"];
		if($mediaComponentId != "" && (!is_numeric($mediaComponentId) || $mediaComponentId <= 0)){
			echo "Id is not valid";die;
		}
		$mediaInventoryTable = $this->getMediaInventryTable();
		$getAllMediaInventory = $mediaInventoryTable->getAllMediaInventory($mediaComponentId);
		$contentListing = array();
		foreach($getAllMediaInventory as $allMediaResultSet) {
			$resultSetJson = json_encode($allMediaResultSet); 
			$resultSet = json_decode($resultSetJson, true);
			$contentListing[$resultSet["mediaid"]] = $resultSet; 
		}
		$response = array("totalLength" => count($contentListing), "contentListing" => $contentListing);
		echo json_encode($response); exit;
	}

	public function getContentDetailAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	 
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$contentId = $postData["contentId"];
		$crsf_tokenval=trim($postData["crsf_tokenval"]);
		//Security changes added by ashu on 28/03/22. Allow only numeric value 
		if(!is_numeric($contentId) || $contentId <= 0 ){
			echo "Id is not valid";die;
		}		
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		$type = $postData["type"];
		$tableCampaignMediaTable = $this->getCampaignMediaTable();
		$campaignMediaRecord = $tableCampaignMediaTable->getMediaAssociationInCampaign($contentId);		
		if(count($campaignMediaRecord) > 0 && $type == "edit") {
			$responseData["checkMediaAssociation"] = true;
		} else {
			$data = array("contentId" => $contentId);
			$mediaInventoryTable = $this->getMediaInventryTable();
			$contentDetail = $mediaInventoryTable->getContentDetail($data);
			foreach($contentDetail as $contentDetailResultSet) {
				$resultSetJson = json_encode($contentDetailResultSet); 
				$resultSet = json_decode($resultSetJson, true);
			}
			
			$resultSet["checkMediaAssociation"] = false;
			$fileName = $resultSet["mediaoriginalname"];
			$mediaComponentName = $resultSet["mediacomponentname"];
			if(file_exists(UPLOAD_CONTENT_MEDIA.$fileName)) {
				$appObj = new ApplicationController();
				$fileContent = $appObj->file_read(UPLOAD_CONTENT_MEDIA.$fileName);
				$fileData = explode('~@~', $fileContent);
				if($mediaComponentName != "Media") {
					if($mediaComponentName == "Web URL") {
						$fileDataArray = array("contentUrl" => $fileData[0], "weburlAutoRefresh" => $fileData[1]);
					} else if($mediaComponentName == "RSS") {
						$data = array("rssFeedUrl" => $fileData[0], "searchTag" => $fileData[8]);
		    			$selectedTagData = $this->rssFeedsData($data);
						$fileDataArray = array("rssUrl" => $fileData[0], "rssSpeedRadio" => $fileData[5], 
							"activeFontFamily" => $fileData[3], "activeFontStyle" => $fileData[6], 
							"activeFontWeight" => $fileData[4], "textColor" => $fileData[1], 
							"bgColor" => $fileData[2], "ddRightLeft" => $fileData[7], 'selectedTagData' => $selectedTagData, 
							"rssTag" => $fileData[8], "rssDisplayStyleRadio" => $fileData[9]
						);
					} else if ($mediaComponentName == "Scroller") {
						$fileDataArray = array("scrollText" => $fileData[0], "scrollSpeedRadio" => $fileData[5], 
							"activeFontFamily" => $fileData[3], "activeFontStyle" => $fileData[6], 
							"activeFontWeight" => $fileData[4], "textColor" => $fileData[1], 
							"bgColor" => $fileData[2], "ddRightLeft" => $fileData[7]
						);
					}
					$responseData = array_merge($resultSet, $fileDataArray);
				} else {
					$responseData = $resultSet;
				}
			}
		}
		echo json_encode($responseData);
		exit;
	}
	public function getdataCurl($url) {
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,false);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_HEADER,false);
		$data = curl_exec($ch);
		curl_close($ch);
		$content = simplexml_load_string($data);
		return $content;
    }

    public function rssFeedsData($data) {
    	$rssFeedUrl = $data["rssFeedUrl"];
    	$searchTag = $data["searchTag"]; 
    	$response = "";
		$url = str_replace("http:", "https:", $rssFeedUrl);
		if($url) {
	    	$content = $this->getdataCurl($url);
		    if($content) {
		        $tagsDetails = array();
		        foreach($content->channel->item as $entry ) {
		            foreach($entry as $key => $val){
		                if(isset($entry->{$key}) && $entry->{$key}!='') {
		                	$tagsDetails[$key][] = strip_tags($entry->{$key});
		                	//$tagsDetails[$key][] = strip_tags($entry->{$key},'<img>');
		                }
		            }
		        }
		        return $selectedTagData = $tagsDetails[$searchTag];
		    } 
		}
    }

    public function getRssFeedsAction() { 
    	$postData = $this->getRequest()->getPost()->toArray();
    	$rssFeedUrl = $postData["rssFeedUrl"];
    	$searchTag = $postData["searchTag"]; 
    	$data = array("rssFeedUrl" => $rssFeedUrl, "searchTag" => $searchTag); 
    	$selectedTagData = $this->rssFeedsData($data);
    	echo json_encode($selectedTagData);exit;
    }

	public function getRssFeedTagsAction() {
		$postData = $this->getRequest()->getPost()->toArray();
		$rssFeedUrl = $postData["rssFeedUrl"];
		$response = "";
		$url = str_replace("http:", "https:", $rssFeedUrl);
		if($url) {
	    	$content = $this->getdataCurl($url);
	    	$myArray = json_decode(json_encode($content->channel->item), true);
	    	$rssFeedTags = is_array($myArray) ? array_keys($myArray) : []; 
	    	if(count($rssFeedTags) > 0) {	
	    		$response = $rssFeedTags;
			} else {
				$response= "invalid";
			}
			echo json_encode($response);exit;
		}
	}

	public function contentListAction() {
		$mediaComponentMasterTable = $this->getMediaComponentMasterTable();		
		$mediaComponentResultSet = $mediaComponentMasterTable->getActiveMediaComponents();
		$mediaInventoryTable = $this->getMediaInventryTable();
		$getAllMediaInventory =  $mediaInventoryTable->getAllMediaInventory("");
		$mediaTypes = $this->checkMediaTypeAllowed();
		$dssFontInfoData = $this->getDssFontInfoTable();
		$dssUploadedFonts = $dssFontInfoData->getUploadedDssFonts();	
		$dssFontNameWithStyles = $dssFontInfoData->getFontNameWithStyles();
		$viewmodel = new ViewModel(array("mediaComponentResultSet" => $mediaComponentResultSet, 
			'mediaTypes' => $mediaTypes, "getAllMediaInventory" => $getAllMediaInventory, 
			"dssUploadedFonts" => $dssUploadedFonts, "dssFontNameWithStyles" => $dssFontNameWithStyles));
		return $viewmodel;
	}	

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		$appObj = new ApplicationController();
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		} else {
			if(PRODUCT=='via' || PRODUCT=='kds'){
				$getSettingObj = $appObj->getComplexPasswordSettings();
				$getSettingData = $getSettingObj->webadmin_session_timeout;
			}else{
				$settingTable = $this->getSettingTable();
				$dataSessionSetting = $settingTable->getSessionCheckData();
				foreach($dataSessionSetting as $contentDetailResultSet) {
					$resultSetJson = json_encode($contentDetailResultSet); 
					$resultSet = json_decode($resultSetJson, true);
					$getSettingData = $resultSet['logoutTIme'];
				}
			}
			$sessionTimeOut = ($getSettingData > 0) ? $getSettingData : 10;
			$dataSendSessionCheck = array("sessionTimeOut" => $sessionTimeOut, "sessionLoginName" => $session->offsetGet('LoginName'));
			$sessionCheckTable = $this->getSessionCheckTable();
			$dataSessionCheck = $sessionCheckTable->getSessionCheckData($dataSendSessionCheck);
			
			if(count($dataSessionCheck) > 0) {
				$dataSendUpdateSessionCheck = array("sessionLoginName" => $session->offsetGet('LoginName'));
				$sessionCheckTable->updateSessionCheckData($dataSendUpdateSessionCheck);
			} else {
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		return parent::onDispatch($e);
	}

	/*****
	 *	@Function Name: downloadMediaAction
	 *  @description  : download media file
	 *	@Author		  : Vineet
	 *  @Date         : 16-jul-2020
	 *****/
	public function downloadMediaAction(){
		$appObj = new ApplicationController();
		$medId= $_GET['id'];
		set_time_limit(0);
		$qry="SELECT mediaoriginalname as media FROM mediainventry WHERE mediaid=$medId";
		$returnData=$appObj->returnQueryData($qry);
		$data=$returnData->current();
		$FileName=$data['media'];
		
		//path to the file
		$file_path = UPLOAD_CONTENT_MEDIA.$FileName;
		$this->output_file($file_path, ''.$FileName.'', 'application/octet-stream');
	}

	/*****
	 *	@Function Name: output_file
	 *  @description  : check file to download file
	 *	@Author		  : Vineet
	 *  @Date         : 16-jul-2020
	 *****/
	public function output_file($file, $name, $mime_type=''){ 
		//Check the file premission
		if(!is_readable($file)) die('File not found or inaccessible!');
		
		$size = filesize($file);
		$name = rawurldecode($name);
		
		/* Figure out the MIME type | Check in array */
		$known_mime_types=array(
			"pdf" => "application/pdf",
			"txt" => "text/plain",
			"html" => "text/html",
			"htm" => "text/html",
		   "exe" => "application/octet-stream",
		   "dmg" => "application/octet-stream",
			"zip" => "application/zip",
		   "doc" => "application/msword",
		   "xls" => "application/vnd.ms-excel",
		   "ppt" => "application/vnd.ms-powerpoint",
		   "gif" => "image/gif",
		   "png" => "image/png",
		   "jpeg"=> "image/jpg",
		   "jpg" =>  "image/jpg",
		   "php" => "text/plain",
		   "avi" => "application/octet-stream",
		);
		
		if($mime_type==''){
			$file_extension = strtolower(substr(strrchr($file,"."),1));
			if(array_key_exists($file_extension, $known_mime_types)){
			   $mime_type=$known_mime_types[$file_extension];
			} else {
			   $mime_type="application/force-download";
			};
		};
		
		//turn off output buffering to decrease cpu usage
		@ob_end_clean(); 
		
		// required for IE, otherwise Content-Disposition may be ignored
		if(ini_get('zlib.output_compression'))
		 ini_set('zlib.output_compression', 'Off');
		
		header('Content-Type: ' . $mime_type);
		header('Content-Disposition: attachment; filename="'.$name.'"');
		header("Content-Transfer-Encoding: binary");
		header('Accept-Ranges: bytes');
		
		/* The three lines below basically make the 
		   download non-cacheable */
		header("Cache-control: private");
		header('Pragma: private');
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		
		// multipart-download and download resuming support
		if(isset($_SERVER['HTTP_RANGE']))
		{
		   list($a, $range) = explode("=",$_SERVER['HTTP_RANGE'],2);
		   list($range) = explode(",",$range,2);
		   list($range, $range_end) = explode("-", $range);
		   $range=intval($range);
		   if(!$range_end) {
			   $range_end=$size-1;
		   } else {
			   $range_end=intval($range_end);
		   }
		   /*
		   ------------------------------------------------------------------------------------------------------
		   //This application is developed by www.webinfopedia.com
		   //visit www.webinfopedia.com for PHP,Mysql,html5 and Designing tutorials for FREE!!!
		   ------------------------------------------------------------------------------------------------------
			*/
		   $new_length = $range_end-$range+1;
		   header("HTTP/1.1 206 Partial Content");
		   header("Content-Length: $new_length");
		   header("Content-Range: bytes $range-$range_end/$size");
		} else {
		   $new_length=$size;
		   header("Content-Length: ".$size);
		}
		
		/* Will output the file itself */
		$chunksize = 1*(1024*1024); //you may want to change this
		$bytes_send = 0;
		if ($file = fopen($file, 'r'))
		{
		   if(isset($_SERVER['HTTP_RANGE']))
		   fseek($file, $range);
		
		   while(!feof($file) && 
			   (!connection_aborted()) && 
			   ($bytes_send<$new_length)
				 )
		   {
			   $buffer = fread($file, $chunksize);
			   print($buffer); //echo($buffer); // can also possible
			   flush();
			   $bytes_send += strlen($buffer);
		   }
		fclose($file);
		} else
		//If no permissiion
		die('Error - can not open file.');
		//die
	   die();
	   }
}