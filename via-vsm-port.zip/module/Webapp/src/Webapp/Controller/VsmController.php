<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Webapp\Form\VsmSettingsForm;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\ServicesController;

class VsmController extends AbstractActionController {
	//checking session
        protected $TblDeviceInventoryTable;
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}


	//using for vsm
	public function vsmSettingsAction() {
            $validateHQandIDFlag=0;
            $AppObj = new ApplicationController();
			//get device model and ostype
			$model=$AppObj->getModelNameByParam('model');
			$modelOSType=$AppObj->getModelNameByParam('ostype');
			
            $deviceInventoryData = $AppObj->getTableAllData('deviceinventory')->current();
            $boxID = $deviceInventoryData['deviceid'];
           	$getDefinedServerIP = $deviceInventoryData['deviceip'];
			//for KDS we are getting name before cloudvsm.com
			if(PRODUCT=='kds'){
				$getDefinedServerIP=substr($getDefinedServerIP,0,(strlen($getDefinedServerIP)-strlen('.cloudvsm.com')) );
			}
			
            if($boxID!="" && $getDefinedServerIP!="") $validateHQandIDFlag=1;
            
            $hqConfigData = $AppObj->getTableAllData('tbl_hq_configuration')->current();
            $wallpaperSettingVal=$hqConfigData['hq_wallpapersetting'];
            $authSettingVal=$hqConfigData['hq_authsetting'];
            $configSettingVal=$hqConfigData['hq_configsetting'];
            $gwaySettingVal=$hqConfigData['hq_gwayfeaturesetting'];
            $clientSettingVal=$hqConfigData['hq_clientfeaturesetting'];
            $mobileSettingVal=$hqConfigData['hq_mobilefeaturesetting'];
            
            $hqMoreConfigData = $AppObj->getTableAllData('tbl_hq_more_configuration')->current();
            $advanceConfigurationSettingVal=$hqMoreConfigData['featurestatus1'];
            $dssSettingVal=$hqMoreConfigData['featurestatus2'];
            $pollSettingVal=$hqMoreConfigData['featurestatus3'];
            $globalSettingsVal=$hqMoreConfigData['featurestatus4'];
            $calendarSettingsVal=$hqMoreConfigData['featurestatus5'];
            
            $form = new VsmSettingsForm($getDefinedServerIP,$boxID);
            $viewmodel =  new ViewModel(array(
                'form' => $form,
                'getDefinedServerIP' => $getDefinedServerIP,
                'boxID' => $boxID,
                'validateHQandIDFlag' => $validateHQandIDFlag,
                'wallpaperSettingVal' => $wallpaperSettingVal,
                'authSettingVal' => $authSettingVal,
                'configSettingVal' => $configSettingVal,
                'gwaySettingVal' => $gwaySettingVal,
                'clientSettingVal' => $clientSettingVal,
                'mobileSettingVal' => $mobileSettingVal,
                'dssSettingVal' => $dssSettingVal,
                'pollSettingVal' => $pollSettingVal,
                'globalSettingsVal' => $globalSettingsVal,
                'calendarSettingsVal' => $calendarSettingsVal,
				'model'=>$model,
				'modelOSType'=>$modelOSType,
                )
            );

            $viewmodel->setTemplate("webapp/utility/system-settings");
            return $viewmodel;
	}
        
        public function validateGwayIPandIDCurlAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $HQserverIP = htmlspecialchars(trim($request->getPost('HQserverIP')));
                $invalidRequest = true;
                // preventing it to send the request to loopback url
                if($HQserverIP != "0.0.0.0" &&  $HQserverIP != "127.0.0.1" && $HQserverIP != "localhost") {
                    // checing if the IP is valid and does not contains the port or anything vunerable
                    if (filter_var($HQserverIP, FILTER_VALIDATE_IP)) {
                        $invalidRequest = false;
                    } else {
                        // checking it the doamin name for cloud vsm then it must be of kramer URL only
                        if(strstr($HQserverIP, "cloudvsm.com")) {
                            $invalidRequest = false;
                        }  
                    }
                }
                // proceed only when the request is valid with proper valid server IP else throw an error
                if($invalidRequest == false) {
                    $gwayBoxID = htmlspecialchars(trim($request->getPost('gwayBoxID')));
                    $clientIP = HOSTNAME;
                    //added on 4Dec2017 for delete UpdatesAvailable.txt
                    if(file_exists(DEST_PATH.FILE_UPDATES_AVAILABLE) ){
                            unlink(DEST_PATH.FILE_UPDATES_AVAILABLE);
                    }
                    $chkUrl=$this->http_get_contents("https://$HQserverIP");
                    if($chkUrl=='error'){
                            echo 'urlError';die;
                    }else{
                            $url="https://$HQserverIP/webservice/webserviceResponse";   
                            $ch = curl_init($url);
                            $certificate_location = BASE_PATH.'/config/cacertupdates.crt';
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
                            curl_setopt($ch, CURLOPT_HEADER, true);    // we want headers
                            curl_setopt($ch, CURLOPT_NOBODY, true);    // we don't need body
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                            curl_setopt($ch, CURLOPT_TIMEOUT,10);
                            $output = curl_exec($ch);
                            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                            curl_close($ch);
                            if($httpcode==404){
                                    echo 'urlError';die;
                            }
                    }
                    
                    $macAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
                    $appObj = new ApplicationController();
                    //get the firmware version (Added on 13-Sept-2017)
                    $firmwareVersion = $appObj->getModelNameByParam('firmversion');
                    if($macAddr!=""){
                            $url="https://$HQserverIP/webservice/webserviceResponse?gwayBoxId=$gwayBoxID&macAddr=$macAddr&fVersion=$firmwareVersion";
                            // create a new cURL resource
                            $ch = curl_init();
                            $certificate_location = BASE_PATH.'/config/cacertupdates.crt';
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
                            // set URL and other appropriate options
                            curl_setopt($ch, CURLOPT_URL, $url);
                            // grab URL and pass it to the browser
                            $output=curl_exec($ch);
                            // close cURL resource, and free up system resources
                            curl_close($ch);
                    }else{
                        echo "NoMacAddr";die;
                    }
                    die;
                } else {
					//modified by ashu on 8Jan25 for fixing bug id VG-8197
                    echo "urlError";die;
                }
            }
        }
        
        public function overwriteBoxIDCurlAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $HQserverIP = htmlspecialchars(trim($request->getPost('HQserverIP')));
                $gwayBoxID = htmlspecialchars(trim($request->getPost('gwayBoxID')));
                $takeAction = trim($request->getPost('takeAction'));
                $clientIP=DEFAULT_SERVER_IP;
                $macAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
                $url="https://$HQserverIP/webservice/updBoxIDWebserviceResp?gwayBoxId=$gwayBoxID&macAddr=".$macAddr.'&takeAction='.$takeAction;
                // create a new cURL resource
                $ch = curl_init();
				$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
                // set URL and other appropriate options
                curl_setopt($ch, CURLOPT_URL, $url);
                // grab URL and pass it to the browser
                $output=curl_exec($ch);
                // close cURL resource, and free up system resources
                curl_close($ch);
                die;
            }
        }
        
        public function resetBoxIDCurlAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $HQserverIP = htmlspecialchars(trim($request->getPost('HQserverIP')));
                $gwayBoxID = htmlspecialchars(trim($request->getPost('gwayBoxID')));
                $clientIP=DEFAULT_SERVER_IP;
                
                $macAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
                $url="https://$HQserverIP/webservice/resetBoxIDWebserviceResp?gwayBoxId=$gwayBoxID&macAddr=".$macAddr.'&takeAction='.$takeAction;
                $chkUrl=$this->http_get_contents($url);
                if($chkUrl=='error'){
                    $updateArr = array('deviceid'=>'', 'deviceip'=>'');
                    $qry = $this->getDeviceInventoryTable()->updateDeviceInventory($updateArr);
                    echo 'success'; die();
                }else{
                    // Added By ashu to check IP is valid on 30May16		
                    $ch = curl_init($url);
					$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
                    curl_setopt($ch, CURLOPT_HEADER, true);    // we want headers
                    curl_setopt($ch, CURLOPT_NOBODY, true);    // we don't need body
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                    curl_setopt($ch, CURLOPT_TIMEOUT,10);
                    $output = curl_exec($ch);
                    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    curl_close($ch);
                    if($httpcode==404){
                        echo 'success'; die();
                    }
                    // End By ashu to check IP on 30May16
                }
                // create a new cURL resource
                $ch = curl_init();
                // set URL and other appropriate options
                curl_setopt($ch, CURLOPT_URL, $url);
                // grab URL and pass it to the browser
                $output=curl_exec($ch);
                // close cURL resource, and free up system resources
                curl_close($ch);die;
            }die;
        }
        
        public function saveHQinfoAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            $appObj = new ApplicationController();
            if($request->isXmlHttpRequest()) {
                $HQserverIP = htmlspecialchars(trim($request->getPost('HQserverIP')));
                $gwayBoxID = htmlspecialchars(trim($request->getPost('gwayBoxID')));
                $updateArr = array('deviceid'=>$gwayBoxID, 'deviceip'=>$HQserverIP);
                $qry = $this->getDeviceInventoryTable()->updateDeviceInventory($updateArr);
                $appObj->ActivityLog(APPLY_BTN,'Server Settings'.' '.MSG_USER_UPDATED); 
                echo 'success';die;
            }     
        }
        
        public function resetBoxIDFromLocalAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            $appObj = new ApplicationController();
            if($request->isXmlHttpRequest()) {
                $HQserverIP = htmlspecialchars(trim($request->getPost('HQserverIP')));
                $gwayBoxID = htmlspecialchars(trim($request->getPost('gwayBoxID')));
                $updateArr = array('deviceid'=>'', 'deviceip'=>'', 'remarks'=>'');
                $resetQry = $this->getDeviceInventoryTable()->updateDeviceInventory($updateArr);
                $updateConfigArr = array('hq_wallpapersetting'=>2,'hq_authsetting'=>2,'hq_configsetting'=>2,'hq_gwayfeaturesetting'=>2,'hq_clientfeaturesetting'=>2,'hq_mobilefeaturesetting'=>2);
                $resetQry = $this->getHqConfigurationTable()->updateConfiguration($updateConfigArr);
                
                $updateMoreConfigArr = array('featurestatus1'=>2,'featurestatus2'=>2,'featurestatus3'=>2,'featurestatus4'=>2,'featurestatus5'=>2);
                $this->getHqMoreConfigurationTable()->updateHqMoreConfiguration($updateMoreConfigArr);
                $recSql = $appObj->returnQueryData("SELECT * FROM tbl_recording_transfer");
                if($recSql->count()>0){
                    $recRow = $recSql->current();
                    if($recRow['transfer_option'] == 'vsm'){
                        $appObj->executeQueries("UPDATE tbl_recording_transfer SET transfer_option='system_default'");
                    }
                }else{
                    $appObj->executeQueries("INSERT INTO tbl_recording_transfer (transfer_option) VALUES ('system_default')");
                }
                $appObj->ActivityLog(RESET_BTN,'Server Settings'.' '.RESET_BTN); 
                //added on 6Dec16 to delete UpdatesAvailable.txt
                if(CHECK_FILE_UPDATES_AVAILABLE==1){
                        unlink(DEST_PATH.FILE_UPDATES_AVAILABLE);
                }	
                if(file_exists(DEST_PATH.'manageLocally.txt')){
                        unlink(DEST_PATH.'manageLocally.txt');
                }

                //remove lic_status.txt file 
                if(file_exists(DEST_PATH.FILE_LIC_STATUS)){
                    unlink(DEST_PATH.FILE_LIC_STATUS);
                }

				//reset tbl_auth_fileformat
				$appObj->executeQueries("DELETE FROM tbl_auth_fileformat WHERE id>44");
				$appObj->executeQueries("UPDATE tbl_auth_fileformat SET formatstatus = 1");
								
				//added on 29July2021 to delete dss data when reset. it will fix bug id 14442 
				$appObj->truncateTable('scheduledisplaydetails');
				$appObj->truncateTable('playerschedule');
				$appObj->truncateTable('playerplaylist');
				$appObj->truncateTable('schedulemaster');
				$appObj->truncateTable('schedulemediadetails');
				$appObj->truncateTable('mediainventry');
				$appObj->truncateTable('campaign_media');
				$appObj->truncateTable('campaignlist');
				$appObj->truncateTable('campaign_template');
				$appObj->truncateTable('dss_scrollerInfo');
				$appObj->truncateTable('playlist_now');
				$appObj->truncateTable('playlist_schedule_master');				
				$appObj->executeQueries("DELETE FROM screentemplatemaster WHERE screentemplateid>6");
				$appObj->executeQueries("DELETE FROM screentemplatedetails WHERE screentemplateid>6");
				$appObj->truncateTable('tbl_media_avail');					
				//deleting all media files
				$files = glob(dirname(BASE_PATH).'/public/media/*');
				foreach($files as $file){
				  if(is_file($file))
						unlink($file);
				}
				$campaignFiles = glob(dirname(BASE_PATH).'/public/campaign/*');
				foreach($campaignFiles as $cfile){
				  if(is_file($cfile))
						unlink($cfile);
				}
				
				//Update by ashu for handling via_admin_pass tag in default.json . We have upgraded it blank in setting_default.json and default.json. We are updating it bcoz from vsm when push then we get a value. 
				$sourceFile = DEST_PATH."settings_default.json";
				$defaultFile = UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'default.json';
				copy($sourceFile, $defaultFile);

                echo 'success';die;
            }
        }
        
        public function applyHQMasterSettingAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $selectedItems = trim($request->getPost('selectedItems'));
                $appObj = new ApplicationController();
                if(GET_OS=='LIN'){
                    if(PRODUCT_TYPE == 'via'){                                
                        list($wallpaperArrSet,$configArrSet,$authArrSet,$gwayArrSet,$clintArrSet,$mobileArrSet,$globalArrSet,$dssArrSet,$calendarArrSet)=explode(',',$selectedItems);
					    //list($wallpaperArrSet,$configArrSet,$dssArrSet,$calendarArrSet)=explode(',',$selectedItems);
                            //$pollArrSet="POLL#2";
                    }	
                    if(PRODUCT_TYPE == 'collab8'){   
                        list($wallpaperArrSet,$configArrSet,$authArrSet,$gwayArrSet,$clintArrSet,$mobileArrSet,$globalArrSet,$dssArrSet,$calendarArrSet)=explode(',',$selectedItems);
					   //list($wallpaperArrSet,$configArrSet,$dssArrSet,$calendarArrSet)=explode(',',$selectedItems);
							//$pollArrSet="POLL#2";
                    }
                }

                if(GET_OS=='WIN'){
                    list($wallpaperArrSet,$configArrSet,$authArrSet,$gwayArrSet,$clintArrSet,$mobileArrSet,$globalArrSet,$dssArrSet,$calendarArrSet)=explode(',',$selectedItems);
                }
               
                list($wallpOpt,$wallpVal)=explode('#',$wallpaperArrSet);
                list($configOpt,$configVal)=explode('#',$configArrSet);
                list($authOpt,$authVal)=explode('#',$authArrSet);
                list($gwayOpt,$gwayVal)=explode('#',$gwayArrSet);
                list($clintOpt,$clintVal)=explode('#',$clintArrSet);
                list($mobileOpt,$mobileVal)=explode('#',$mobileArrSet);
                list($dssOpt,$dssVal)=explode('#',$dssArrSet);	
                /*list($pollOpt,$pollVal)=explode('#',$pollArrSet);*/
                list($globalOpt,$globalVal)=explode('#',$globalArrSet);
				
                list($calendarOpt,$calendarVal)=explode('#',$calendarArrSet); 
                $advaceVal=$configVal;
                $connection=$appObj->getConnection();
                $hqConfigData = $appObj->getTableAllData('tbl_hq_more_configuration')->current();
                $dssSettingVal=$hqConfigData['featurestatus2'];
                $pollSettingVal=$hqConfigData['featurestatus3'];
                $calSettingVal=$hqConfigData['featurestatus5'];
                $hqConfigData1 = $appObj->getTableAllData('tbl_hq_configuration')->current();
                $wallSettingVal = $hqConfigData1['hq_wallpapersetting'];
				$intConfigSettingVal = $hqConfigData1['hq_configsetting'];
                if($wallpOpt=="WALP" && ($wallpVal!=$wallSettingVal)){
                    if(GET_OS=='WIN'){
                            $imgExt='.jpg';
                            $defImgName='default.jpg';
                            $defImg = 'default.jpg';
                            $source_json = DEST_PATH.'windowDefault.json';
                            $source_img = DEST_PATH.'windowDefault.jpg';
                    }
                    if(GET_OS=='LIN'){
                            $imgExt='.png';
                            $defImgName='Default.png';
                            $defImg = 'default.png';
                            $source_json = DEST_PATH.'linuxDefault.json';
                            $source_img = DEST_PATH.'linuxDefault.png';
                    }		
					
                    //truncate wallpaper table
                    $this->getWallpaperTable()->truncateTable();
                    copy(DEST_PATH.SYSTEM_DEFAULT_IMG,DEST_PATH.$defImgName) or die('Default image not found');

                    //added on 7 Dec2018. for Reset template designer
                    $this->getTemplatesTable()->truncateTable();
                    //deleting all template files
                    
                    $files = glob(dirname(BASE_PATH).'/templatedesigner/templates/*');
                    foreach($files as $file){
                      if(is_file($file))
                            unlink($file);
                    }
                    //remove all wallpapers
                    $wallpfiles = glob(dirname(BASE_PATH).'/uploads/large/*');
                    foreach($wallpfiles as $wallfile){ 
                      if(is_file($wallfile))
                            unlink($wallfile);
                    }	

					//deleting all template files                   
					$files1 = glob(TEMPLATE_DIR_ZEND.'*');
                    foreach($files1 as $file){
                      if(is_file($file))
                            unlink($file);
                    }
					//remove all wallpapers                    
					$wallpfiles1 = glob(HTML_PUBLIC_DIR.'/uploads/large/*');
                    foreach($wallpfiles1 as $wallfile){ 
                      if(is_file($wallfile))
                            unlink($wallfile);
                    }


                    if(FILE_ROOMNAME==1) unlink(DEST_PATH.READFILE_ROOMNAME);
                    if(FILE_ROOMCODE==1) unlink(DEST_PATH.READFILE_ROOMCODE);
                    if(FILE_ROOMCODESHOW==1) unlink(DEST_PATH.READFILE_ROOMCODESHOW);
                    // Undefined constant FILE_REFRESHTIME gives a warning so commented
                    //if(FILE_REFRESHTIME==1) unlink(DEST_PATH.READFILE_REFRESHTIME);		
                    
                    // Undefined constant FILE_STRDATETIME and FILE_SECOND_DISPLAY gives a warning so commented
                    //if(FILE_STRDATETIME==1) unlink(DEST_PATH.READFILE_STRDATETIME);
                    //if(FILE_SECOND_DISPLAY==1) unlink(DEST_PATH.READFILE_SECOND_DISPLAY);
                    if(CHECK_FILE_STR24HOUR_FORMAT==1) unlink(DEST_PATH.FILE_STR24HOUR_FORMAT);
                    /*,'24hoursformat'=>1*/
					
                    $connection->execute("UPDATE tbl_display_settings SET activate_roomname=1,show_roomname_color='255,255,255', activate_roomcode=1, show_roomcode_color='255,255,255', activate_showonwallpaper=1,activate_refreshtime=30,activate_datetime=1,show_datetime_wallp_color='0,0,0', activate_roomname_seconddisplay=0,\"24hoursformat\"=1,activateroomoverlay=0,roomoverlayvalue=0,field1='1', field2='255,255,255',field3=''");
                    //For reset dynamic wallpaer settings
                    
					//$serviceObj=new ServicesController();
					//$serviceObj->createDefaultTemplateAction();
                    $dest_img = BASE_PATH.'/public/uploads/large/'.$defImg;
                    $dest_json = BASE_PATH.'/public/uploads/templates/default.json';
                    copy($source_img,$dest_img);
                    copy($source_json,$dest_json);	
                    
					//copy on dynamic path
					$dest_img1 = HTML_PUBLIC_DIR.'/uploads/large/'.$defImg;
					$dest_json1 = HTML_PUBLIC_DIR.'/uploads/templates/default.json';
                    copy($source_img,$dest_img1);
                    copy($source_json,$dest_json1);	

					
                    $finalImg='uploads/large/'.$defImg;
					$appObj->executeQueries("INSERT INTO tbl_templates (template_name, status, wallpaper_name,model_type,modifydatetime)VALUES ('default', 1, '$finalImg',".PRODUCT_MODEL_TYPE.",NOW()); "); 
                }
				
				if(strtolower($configOpt)=="cnfg" && ($configVal!=$intConfigSettingVal)){
					$sourceFile = DEST_PATH."settings_default.json";//$appObj->getViaSettingTemplate();
					$settingsFile = DEST_PATH.'via_settings.json';
					
					if(file_exists($settingsFile)){
						unlink($settingsFile);
					}
					copy($sourceFile, $settingsFile);
									
					$settingPath = glob(UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'*');
					foreach($settingPath as $file){
					  if(is_file($file) && $file != $sourceFile){
							unlink($file);
					  }
					}
					$defaultFile = UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'default.json';
					copy($sourceFile, $defaultFile);				
				
                	$this->getViaSettingsTemplatesTable()->truncateTable();
					$insertArr = array('template_name' => 'default', 'status' => 1, 'created_at' => date("Y-m-d H:i:s"),'model_type'=>PRODUCT_MODEL_TYPE, 'template_path' => 'uploads/config_templates/default.json' , 'modifydatetime' => date("Y-m-d H:i:s"));
					$this->getViaSettingsTemplatesTable()->insertData($insertArr);
					//reset tbl_auth_fileformat
					$appObj->executeQueries("DELETE FROM tbl_auth_fileformat WHERE id>44");
					$appObj->executeQueries("UPDATE tbl_auth_fileformat SET formatstatus = 1");
                    
                    // host name put in roomnamevalueshow.txt file.
                    $roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
                    $sessionNetworkData=$session->offsetGet('networkData');
                    if($sessionNetworkData['Lan1_Host']!=''){
                        $get_roomname = $sessionNetworkData['Lan1_Host'];
                    }else{
                        $get_roomname = $sessionNetworkData['wifi1_Host'];
                    }
                    file_put_contents($roomnameTxtFile, $get_roomname);	
				}				



                // ading chnage on 15may2017 for truncate DSS tables when connect hq
                if($dssOpt=="DSS"){
                        if($dssVal !=$dssSettingVal){
                            $appObj->truncateTable('scheduledisplaydetails');
                            $appObj->truncateTable('playerschedule');
                            $appObj->truncateTable('playerplaylist');
                            $appObj->truncateTable('schedulemaster');
                            $appObj->truncateTable('schedulemediadetails');
                            $appObj->truncateTable('mediainventry');
							$appObj->truncateTable('campaign_media');
							$appObj->truncateTable('campaignlist');
							$appObj->truncateTable('campaign_template');
							$appObj->truncateTable('dss_scrollerInfo');
							$appObj->truncateTable('playlist_now');
							$appObj->truncateTable('playlist_schedule_master');
							
                            $connection->execute("DELETE FROM screentemplatemaster WHERE screentemplateid>6");
                            $connection->execute("DELETE FROM screentemplatedetails WHERE screentemplateid>6");
                            $appObj->truncateTable('tbl_media_avail');					
                            //deleting all media files
                            $files = glob(dirname(BASE_PATH).'/public/media/*');
                            foreach($files as $file){
                              if(is_file($file))
                                    unlink($file);
                            }
							$campaignFiles = glob(dirname(BASE_PATH).'/public/campaign/*');
                            foreach($campaignFiles as $cfile){
                              if(is_file($cfile))
                                    unlink($cfile);
                            }
                        }
                }	
                // end DSS Changes
                //Added for Calendar(21-Sept-2018)
                if($calendarOpt=="calendar"){
                    if($calendarVal !=$calSettingVal){
                        $appObj->truncateTable('tbl_access_token');
                        $appObj->truncateTable('tbl_calendars');
                        $appObj->truncateTable('tbl_calender_account');
                    }
                    
                }
                $updateHqConfigArr = array('hq_wallpapersetting'=>$wallpVal,'hq_configsetting'=>$configVal,'hq_authsetting'=>$authVal, 'hq_gwayfeaturesetting'=>$gwayVal, 'hq_clientfeaturesetting'=>$clintVal, 'hq_mobilefeaturesetting'=>$mobileVal);
                $this->getHqConfigurationTable()->updateConfiguration($updateHqConfigArr);
                $updateHqMoreConfigArr = array('featurestatus1'=>$configVal,'featurestatus2'=>$dssVal,'featurestatus4'=>$globalVal,'featurestatus5'=>$calendarVal);
                $this->getHqMoreConfigurationTable()->updateHqMoreConfiguration($updateHqMoreConfigArr);
                echo 'success';die;
            }
        }
        
        public function http_get_contents($url){
            $ch = curl_init();
			$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
            curl_setopt($ch, CURLOPT_TIMEOUT, 10);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            if(FALSE === ($retval = curl_exec($ch))) {
              //echo curl_error($ch);			 
                   return 'error';
            } else {
                   return 'ok';
            }
        }
		
		// check port status on vsm page
		public function checkportAction(){
			$appObj = new ApplicationController();
			$connection = $appObj->getConnection();
			$host = trim($_POST['definedLinServerIP']);					
			if(PRODUCT=='kds'){
				//$host ='rabbitmq.cloudvsm.com';
				$host = trim($_POST['definedLinServerIP']).'.cloudvsm.com';
			}	
			$chkUrl=$this->http_get_contents("https://$host");
			if($chkUrl=='error'){
				echo 'Site server url is wrong';die;
			}else{
				$url="https://$host/Getportlist.php";
				$portListData=$appObj->curl_get_contents($url);
				$explodePortListData=explode("|",$portListData);
				$fileserver_port=trim($explodePortListData[4]);				
				//$getPorts=$connection->execute("SELECT fileserver_port FROM tbl_port_mapping")->current();
				//$fileserver_port=$getPorts['fileserver_port'];
				$ports = array("SSL"=>443,"Rabbitmq"=>5671,"File Server"=>$fileserver_port);	
				$portDeatils='<div class="row m-l-sm" style="height:30px"><div class="col-md-12"><strong>'.STR_VSM_URL.':&nbsp;'.$host.'</strong></div></div>';		
				$portDeatils.='<div class="row m-l-sm"><div class="col-md-6"><strong>'.STR_PORT.'</strong></div><div class="col-md-6"><strong>'.STR_STATUS.'</strong></div></div>';				
				foreach ($ports as $portname=>$port){
					$connection = @fsockopen($host, $port);			
					if (is_resource($connection)){
						$portDeatils.='<div class="row m-l-sm">';
						$portDeatils.='<div class="col-md-6">'.$port.'&nbsp;('.$portname.')'.'</div>';
						$portDeatils.='<div class="col-md-6"> <span>Open</span> </div></div>';
						//return true;
					}else{
						$portDeatils.='<div class="row m-l-sm">';
						$portDeatils.='<div class="col-md-6">'.$port.'&nbsp;('.$portname.')'.'</div>';
						$portDeatils.='<div class="col-md-6"> <span>Close</span> </div></div>';
						//return true;
					}
				}	
				echo $portDeatils;		
				die;
			}
		}
       
        public function getDeviceInventoryTable() {
            if(!$this->TblDeviceInventoryTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
            }
            return $this->TblDeviceInventoryTable;
	}
        
        public function getHqConfigurationTable() {
            if(!$this->TblHqConfigurationTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblHqConfigurationTable = $sm->get('Webapp\Model\TblHqConfigurationTable');
            }
            return $this->TblHqConfigurationTable;
	}
        
        public function getHqMoreConfigurationTable() {
            if(!$this->TblHqMoreConfigurationTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblHqMoreConfigurationTable = $sm->get('Webapp\Model\TblHqMoreConfigurationTable');
            }
            return $this->TblHqMoreConfigurationTable;
	}
        
        public function getWallpaperTable() {
            if(!$this->TblWallpaperTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblWallpaperTable = $sm->get('Webapp\Model\TblWallpaperTable');
            }
            return $this->TblWallpaperTable;
	}
        
        public function getTemplatesTable() {
            if(!$this->TblTemplatesTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblTemplatesTable = $sm->get('Webapp\Model\TblTemplatesTable');
            }
            return $this->TblTemplatesTable;
	}
        
        public function getGatewayCustomizeHomepageTable() {
            if(!$this->TblGatewayCustomizeHomepageTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblGatewayCustomizeHomepageTable = $sm->get('Webapp\Model\TblGatewayCustomizeHomepageTable');
            }
            return $this->TblGatewayCustomizeHomepageTable;
	}
        
     public function getDisplaySettingsTable() {
            if(!$this->TblDisplaySettingsTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblDisplaySettingsTable = $sm->get('Webapp\Model\TblDisplaySettingsTable');
            }
            return $this->TblDisplaySettingsTable;
	}
	public function getViaSettingsTemplatesTable() {
		if (!$this->TblViaSettingsTemplatesTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblViaSettingsTemplatesTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesTable');
		}
		return $this->TblViaSettingsTemplatesTable;
	}
	
	
	

}
