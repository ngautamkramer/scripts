<?php
namespace Webapp\Controller;

use Exception;
use Zend\Db\ResultSet\ResultSet;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Db\Adapter\Adapter;

ini_set("memory_limit", '10G');

class MigrationController extends AbstractActionController{

    /*protected $tableGateway;

    public function __construct(TableGateway $tableGateway)
    {
        $this->tableGateway = $tableGateway;
    }*/

    protected $showMessage = false;
    

    //return MySQL connection
    public function getMySQLConnection(){
        $dbAdapterConfig = array(
            'driver'   => 'Mysqli',
            'database' => 'wpg',
            'username' => 'viadbuser',
            'password' => 'w0wAdm1n8',
            'charset'  => 'utf8'
        );
        $dbAdapter = new Adapter($dbAdapterConfig); 
        $driver = $dbAdapter->getDriver();
        $connection = $driver->getConnection();
        return $connection;
    }

    

    //return PostgreSQL connection
    public function getPostgresConnection(){
        $dbAdapterConfig = array(
            'driver'   => 'Pgsql',
            'database' => DB_NAME,
            'username' => "postgres",
            'password' => DB_PASSWORD,
            'hostname' => HOST_NAME,
            'port' => DB_PORT,
            'charset'  => 'utf8'
        );
        $dbAdapter = new Adapter($dbAdapterConfig); 
        $driver = $dbAdapter->getDriver();
        $connection = $driver->getConnection();
        return $connection;
    }

    //view array data in format
    public function pre($data){
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }



    //view query result in array
    public function viewInArray($data){
        $resultSet = new ResultSet();
        $resultSet->initialize($data);
        return $resultSet->toArray();
    }


    //insert data into table
    public function insertIntoPostgreSQL($tableName, $key, $values){
        $pgsqlObj = $this->getPostgresConnection();
        $tblQry = "INSERT INTO $tableName $key VALUES $values";
        $pgsqlObj->execute($tblQry);
    }


    public function insertIntoPostByTablegreSQL($query){
        $pgsqlObj = $this->getPostgresConnection();
        $pgsqlObj->execute($query);
    }

    public function restartSequenceIdentity(){
        $pgsqlObj = $this->getPostgresConnection();
        $query = "DO $$
        DECLARE
        i TEXT;
        BEGIN
          FOR i IN (
            SELECT 'SELECT SETVAL('
                || quote_literal(quote_ident(PGT.schemaname) || '.' || quote_ident(S.relname))
                || ', COALESCE(MAX(' ||quote_ident(C.attname)|| '), 1) ) FROM '
                || quote_ident(PGT.schemaname)|| '.'||quote_ident(T.relname)|| ';'
              FROM pg_class AS S,
                   pg_depend AS D,
                   pg_class AS T,
                   pg_attribute AS C,
                   pg_tables AS PGT
             WHERE S.relkind = 'S'
               AND S.oid = D.objid
               AND D.refobjid = T.oid
               AND D.refobjid = C.attrelid
               AND D.refobjsubid = C.attnum
               AND T.relname = PGT.tablename
          ) LOOP
              EXECUTE i;
          END LOOP;
        END $$";
        return $pgsqlObj->execute($query);
    }

    public function skipTable($tableName){
        $tableLists = ["alertsconfiguration","alertsupport","alerttype","autoupdate","canceledorder","clientlocation","commandqueue","commandsupport","commandtype","dailyschedule","disucssionlogs","globalcash","globalcmaster","mailalert","mediadetails","mediainventory","mediaplay","noticetypemaster","playerlog","projectorcommand","projectors","projectorstatus","reporttable","scheduledetail","scheduledisplay","scheduledisplayhistory","scheduleofftimer","schedulestatus","sessionrecord","smsoutbox","tbl_autoupdate_selected","tbl_device_mapping","tbl_polls_result","tbl_poll_groups","tbl_poll_group_relation","tbl_poll_group_sync","tbl_poll_options","tbl_poll_questions","tbl_poll_schedule","tbl_poll_session_check","tbl_poll_sync","tbl_poll_users","tbl_poll_users_sync","tbl_wifisecurity","wpglanguageprefer","tbl_feature_temp","tbl_feature_client_temp","tbl_mobile_feature_temp"];
        return in_array(strtolower($tableName), $tableLists);
    }

    public function string_filter_in_array(&$array) {
        array_walk_recursive($array, function(&$array){
            $array = str_replace("'", "`", $array);
        });
        return $array;
    }

    public function checkValidDateAndTime($datetime){
        return (bool)strtotime($datetime) && $datetime != "0000-00-00 00:00:00" ? $datetime : date("Y-m-d h:i:s");
    }

    public function checkValidDate($date){
        return (bool)strtotime($date) && $date != "0000-00-00" ? $date : date("Y-m-d");
    }

    public function updateDataAfterMigration(){
        $pgsqlObj = $this->getPostgresConnection();
        $tmpData = $pgsqlObj->execute("SELECT count(*) as count from tbl_via_settings_templates WHERE status=1 AND template_name='default'")->current();
        $advData = $pgsqlObj->execute("SELECT count(*) as count from tbl_advance_more_features WHERE property_name='ModFeatEnable' AND ivalue=1")->current();
        if($tmpData['count'] > 0 && $advData['count'] > 0){      
            $pgsqlObj->execute("UPDATE tbl_advance_more_features SET ivalue = '0' WHERE property_name = 'ModFeatEnable'");
        }

        //check recording value
        $recData = $pgsqlObj->execute("SELECT count(*) as rec_count from tbl_advance_configuration WHERE feature4=1")->current();
        if($tmpData['count'] > 0 && $recData['rec_count'] > 0){      
            $pgsqlObj->execute("UPDATE tbl_advance_configuration SET feature4 = 0");
        }
    }

    public function startAction(){

        $mysqlObj = $this->getMySQLConnection();
        
        $pollEncryptionKey =  POLL_ENCRPTION_KEY;

        //get all tables;
        $resData = $mysqlObj->execute("show tables");
        
        foreach($resData as $tableName){

            //get acurrent table data
            $tableName = $tableName['Tables_in_wpg'];

            //skip table from the import
            if($this->skipTable($tableName)){
                continue;
            }

            $tableData = $mysqlObj->execute("SELECT * from ".$tableName);
            $tableName = strtolower($tableName);
            $tableData = $this->viewInArray($tableData);
            $insertVar = ''; $tableKeys = '';

            if(count($tableData) > 0){

                foreach($tableData as $key => $singleData){
                    
                    //convert all keys into lowercase
                    $singleData = array_change_key_case($singleData, CASE_LOWER);
                    $singleData = $this->string_filter_in_array($singleData);

                    //finalize insert table column keys
                    if($key == 0){
                        $tableKeys = '("'.implode('","', array_keys($singleData)).'")';
                    }
                    
                    //issue with datetime field
                    if($tableName == "appgroups" || $tableName == "appusergroups" || $tableName == 'tbl_versioninfo'){
                        $singleData['modifydate'] = $this->checkValidDateAndTime($singleData['modifydate']);
                        /*if($singleData['modifydate'] == '0000-00-00 00:00:00' || empty($singleData['modifydate'])){
                            $singleData['modifydate'] =  date("Y-m-d h:i:s");
                        }*/
                    }

                    if($tableName == "tbl_mobile_features_position"){
                        $singleData['date_time'] = $this->checkValidDateAndTime($singleData['date_time']);
                        /*if($singleData['date_time'] == '0000-00-00 00:00:00'){
                            $singleData['date_time'] =  date("Y-m-d h:i:s");
                        }*/
                    }

                    if($tableName == "playlist_schedule_master"){
                        $singleData['modifydatetime'] = $this->checkValidDateAndTime($singleData['modifydatetime']);
                        /*if(empty($singleData['modifydatetime'])){
                            $singleData['modifydatetime'] =  date("Y-m-d h:i:s");
                        }*/
                    }

                    //issue with date field
                    if($tableName == "campaignlist"){
                        $singleData['modifydate'] = $this->checkValidDate($singleData['modifydate']);
                        /*if(empty($singleData['modifydate'])){
                            $singleData['modifydate'] =  date("Y-m-d");
                        }*/
                    }

                    //update table count
                    if($tableName == "tbl_table_count"){
                        $singleData['table_count'] = 82;
                    }
                                    
                    //converted mysql aes encryption into pgsql
                    if($tableName == "dss_info" || $tableName == "tbl_firmware_auth"){
                        $rowData = $mysqlObj->execute("SELECT AES_DECRYPT(dateTime, '$pollEncryptionKey') as datetime FROM $tableName WHERE id=".$singleData['id']);
                        $rowData = $this->viewInArray($rowData);
                        $dvalue = $rowData[0]['datetime'];
                        $singleData['datetime'] = "encrypt('$dvalue','$pollEncryptionKey','aes')";
                    }

                    if($tableName == "tbl_calender_account"){
                        $rowData = $mysqlObj->execute("SELECT AES_DECRYPT(email, '$pollEncryptionKey') as email FROM $tableName WHERE id=".$singleData['id']);
                        $rowData = $this->viewInArray($rowData);
                        $dvalue = $rowData[0]['email'];
                        $singleData['email'] = "encrypt('$dvalue','$pollEncryptionKey', 'aes')";
                    }
                                    
                    //not required it's data
                    if($tableName == "tbl_web_error_log" || $tableName == "tbl_hq_settings"){
                        continue;                  
                    }


                    //assigning 0 value instead of '' blank
                    if($tableName == "tbl_display_settings"){
                        $singleData['field6'] =  $singleData['field6'] != NULL ? $singleData['field6'] : 0;
                        $singleData['field7'] =  $singleData['field7'] != NULL ? $singleData['field7'] : 0;
                        $singleData['field8'] =  $singleData['field8'] != NULL ? $singleData['field8'] : 0;
                        $singleData['field9'] =  $singleData['field9'] != NULL ? $singleData['field9'] : 0;
                    }


                    //assigning 0 value instead of '' blank
                    if($tableName == "tbl_auth_fileformat"){
                        $singleData['param1'] =  $singleData['param1'] != NULL ? $singleData['param1'] : 0;
                        $singleData['param2'] =  $singleData['param2'] != NULL ? $singleData['param2'] : 0;
                    }

                    if($tableName == "tbl_menus"){
                        $singleData['parent_menu_id'] =  $singleData['parent_menu_id'] != NULL ? $singleData['parent_menu_id'] : 0;
                    }

                    if($tableName == "tbl_modules"){
                        $singleData['datetime'] =  $singleData['datetime'] != NULL ? $singleData['datetime'] : 0;
                        $singleData['field1'] =  $singleData['field1'] != NULL ? $singleData['field1'] : 0;
                    }

                    if($tableName == "tbl_recording_transfer"){
                        $singleData['field1'] =  $singleData['field1'] != NULL ? $singleData['field1'] : 0;
                    }

                    if($tableName == "recordingmaster" || $tableName == "recordingchild"){
                        if($singleData['reserved1'] == NULL){
                            $singleData['reserved1'] =  0;
                        }
                    }

                    if($tableName == "tbl_access_token"){
                        if($singleData['user_id'] == NULL){
                            $singleData['user_id'] =  0;
                        }
                    }

                    if($tableName == "thirdpartyapps"){
                        $singleData['param3'] =  $singleData['param3'] != NULL ? $singleData['param3'] : 0;
                        $singleData['param4'] =  $singleData['param4'] != NULL ? $singleData['param4'] : 0;
                    }

                    if($tableName == "tbl_streaming_settings"){
                        $singleData['reserve1'] =  $singleData['reserve1'] != NULL ? $singleData['reserve1'] : 0;
                        $singleData['reserve2'] =  $singleData['reserve2'] != NULL ? $singleData['reserve2'] : 0;
                    }
                    
                    //finalize insert value statement
                    $insertVar .= "('" . implode("','", array_values($singleData)) ."'),";

                    //remove 'quotes from postgres function
                    $insertVar = str_replace(["'encrypt(", "'aes')'"], ["encrypt(", "'aes')"], $insertVar);                    
                }


                //insert many statement for table entry
                if(!empty($insertVar) && !empty($tableKeys)){
                    $insertVar = rtrim($insertVar, ',');
                    
                    try{
                        $this->insertIntoPostgreSQL($tableName, $tableKeys, $insertVar);
                        //$this->showSuccessMessage($tableName);
                    }catch(Exception $e){
                        if(str_contains($e->getMessage(), "duplicate key value violates unique constraint")){
                            //$this->showSuccessMessage($tableName);
                            continue;
                        }else{
                            echo $tableName.": ".$e->getMessage()."\n";
                        }
                    }
                }
            }else{
                //$this->showCustomAvailabeMessage($tableName);
            }
        }

        //restart identity
        $this->restartSequenceIdentity();

        //to fix if ModFeatEnable = 1 in default template
        $this->updateDataAfterMigration();
        echo "Migrated successfully from MySQL to PostgreSQL \n"; die;    
    }

    /*public function showSuccessMessage($tableName){
        if($this->showMessage){
            echo('<p style="font-size:18px;">✅ <b>'.$tableName.'</b> table migrated successfully from MySQL to PostgreSQL</p>');
        }
    }

    public function showCustomAvailabeMessage($tableName){
        if($this->showMessage){
            echo('<p style="font-size:18px;">✅ <b>'.$tableName.'</b> Migration started...., No data available</p>');
        }
    }*/

}