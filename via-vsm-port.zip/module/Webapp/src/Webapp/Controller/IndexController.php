<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\LoginForm;
use Webapp\Form\IndexForm;
use Zend\Session\Container;
use Webapp\Controller\ApplicationController;
use Webapp\Form\ResetPasswordForm;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;
use Zend\Mime\Part as MimePart;
use Zend\Mime\Message as MimeMessage;

class IndexController extends AbstractActionController {

	public function generateAction() {
		$response = $this->getResponse();
		$response->getHeaders()->addHeaderLine('Content-Type', "image/png");
		$id = $this->params('id', false);
		if($id) {
			$image = './data/captcha/' . $id;
			if(file_exists($image)!== false) {
				$imagegetcontent = @ file_get_contents($image);
				$response->setStatusCode(200);
				$response->setContent($imagegetcontent);
				if(file_exists($image)== true) {
					unlink($image);
				}
			}
		}
		return $response;
	}

	public function indexAction() {
		if(PRODUCT=="via" || PRODUCT=="kds"){
	  		return $this->redirect()->toRoute('viaIndex', ['action'=>'index']);
	 	}
	 	
		//code for showing set default language
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('lang');
		if(!isset($sessionLoginName)) {
			//echo 'set default';
			$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
			if($lang == "zh") {
				if(strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 5))== "zh-tw")
					$lang = "zh-TW";
				if(strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 10))== "zh-hant-tw")
					$lang = "zh-TW";
			}
			if($lang == "en")
				$lang = "eng";
			if($lang == "ja")
				$lang = "jap";
			if($lang == "zh")
				$lang = "chi";
			if($lang == "es")
				$lang = "spa";
			if($lang == "de")
				$lang = "ger";
			if($lang == "ru")
				$lang = "rus";
			if($lang == "pl")
				$lang = "pol";
			if($lang == "fr")
				$lang = "fre";
			if($lang == "pt")
				$lang = "por";
			//if($lang=="zh-TW")  $lang="trchi";
			if($lang == "zh-TW")
				$lang = "trchi";
			$session->offsetSet('lang', $lang);
		}
		$this->layout('layout/landing');
        $appObj = new ApplicationController();
        // DNS setting
		$dnsQry = $appObj->returnQueryData("SELECT * FROM tbl_hq_settings");
		if($dnsQry->count()==0){		
			$appObj->executeQueries("INSERT INTO tbl_hq_settings(dns_settings) VALUES(0)");
		}

		//settings default entry
		$settingsQry = $appObj->returnQueryData("SELECT * FROM settings");
		if($settingsQry->count()==0){
			$insertArr = array('logoutTIme' => 1440, 'pageSize' => 50, 'field1' => 1);
			$this->getSettingsTable()->insertSessionValue($insertArr);	
		}
        $form = new IndexForm();
        //$qry1="SELECT DI.*, DG.DeviceGroup, DD.`dns_name` FROM devicegroup AS DG INNER JOIN DeviceInventory AS DI ON DG.DeviceGroupID=DI.DeviceGroupID LEFT JOIN tbl_device_dnsname DD ON DI.DID=DD.DID_Fk";
                
        $request = $this->getRequest();
        if(!$request->isPost()) {
			$strGwayGrpName = "";
			if(isset($_GET["search"])){
                $strGwayGrpName = $_GET["search"];
                //$qry1.=" WHERE Concat(DI.DeviceName, DG.DeviceGroup) like '%$strGwayGrpName%'";
                $search = $strGwayGrpName;
			}
		} else {
			$form->setData($request->getPost());
			if(!$form->isValid()) {
                return new ViewModel(array('form' => $form));
			}
			$dataPost = $form->getData();
			$strGwayGrpName = trim($dataPost['search']);
		}
		
		$getClientOS=strtoupper(substr($appObj->getClientOS(), 0, 3));

		$getGwayIP=$_SERVER['HTTP_HOST'];			
		if($getClientOS=="WIN" || $getClientOS=="LIN"){
			$url='https://'.$getGwayIP."/download.php?filename=VIASetup.exe";
			$setupImg=PUBLIC_URL.'img/windows-mac.png';	
		}
		if($getClientOS=="MAC"){
			$url='https://'.$getGwayIP."/download.php?filename=VIASetup.dmg";	
			$setupImg=PUBLIC_URL.'img/windows-mac.png';
		}			
		if($getClientOS=="AND"){
			$url='https://play.google.com/store/apps/details?id=com.Activities.VIA&hl=en';
			$setupImg=PUBLIC_URL.'img/android.png';
		}
		if($getClientOS=="IPA" || $getClientOS=="IPH"){
			$url='https://itunes.apple.com/us/app/via-app/id883509803';
			$setupImg=PUBLIC_URL.'img/apple.png';	
		}
		if($getClientOS=="MOB"){
			$url="https://www.microsoft.com/en-in/store/apps/via/9wzdncrd2qlr";
			$setupImg=PUBLIC_URL.'img/winmobile.png';	
		}
		if($getClientOS=="CHR"){				
			$url="https://play.google.com/store/apps/details?id=com.Activities.VIA&hl=en";
			$setupImg=PUBLIC_URL.'img/winmobile.png';	
		}

        //$qry1 .= " ORDER BY DI.DeviceName";
        //$gatewayListData = $appObj->returnQueryData($qry1);
		$gatewayListData = $this->getDeviceInventoryTable()->getIndexList($strGwayGrpName);
		$gatewayListData->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        $gatewayListData->setItemCountPerPage(50);
        $hqSettingRow=$appObj->returnQueryData("SELECT dns_settings FROM tbl_hq_settings")->current();
        //get the logo
		$uploaddir =UPLOAD_DIR_ZEND.'img/Logo/';	
		$images = glob($uploaddir . "*.*");
		foreach($images as $image)
		{ 
			$imageName = basename($image);
		}
		$timestmp = rand(10000,100000);//time();
        if(PRODUCT_TYPE=='via' || PRODUCT_TYPE=='vsm'){
        	$logoImg=(file_exists($image))?PUBLIC_URL.'/img/Logo/'.$imageName.'?time='.$timestmp:PUBLIC_URL.'/img/via-kramer-logo-grey.svg?time='.$timestmp; 
        }else{
        	$logoImg=(file_exists(UPLOAD_DIR_ZEND.'img/Logo/logo.jpg'))?PUBLIC_URL.'/img/Logo/logo.jpg?time='.$timestmp:PUBLIC_URL.'/img/collab8/logo.jpg?time='.$timestmp; 
        }
        
        //get the logo url
		$logosql=$appObj->returnQueryData("SELECT field2 FROM settings limit 1")->current();
		$logoUrl=$logosql['field2'];
		if($logoUrl !=""){
			if (strpos($logoUrl, 'http') !== false || strpos($logo, 'https') !== false ) {
				$logoUrlFinal=$logoUrl;
			}else{
				$logoUrlFinal="https://".$logoUrl;
			}  
		}else{
			$logoUrlFinal="https://www.kramerav.com";
		}
		$wpglanguage=array('chi'=>'Chinese','eng'=>'English','ger'=>'German','jap'=>'Japanese','pol'=>'Polish','por'=>'Portuguese','rus'=>'Russian','spa'=>'Spanish','fre'=>'French', 'trchi'=>'Traditional chinese');
		//implement homecolortheme.json on index page.
		$filepath = DEST_PATH.'homecolortheme.json';
		$jsonFileDataArray=$appObj->getDecryptJsonFileData($filepath);

		$form->setData(array('search' => $search,));
		return new ViewModel(array('form' => $form, 'gatewayListData' => $gatewayListData, 'dns_setting' => $hqSettingRow['dns_settings'], 'url' => $url, 'setupImg' => $setupImg, 'logoUrlFinal' => $logoUrlFinal, 'logoImg' => $logoImg, 'wpglanguage' => $wpglanguage,'getClientOS'=>$getClientOS,'jsonFileDataArray'=>$jsonFileDataArray));
	}

	public function loginAction() {
		$appObj = new ApplicationController();
		//getting captcha value from table 
		$captchaVal='';
		$settingsTblDataArr=$this->getSettingsTable()->fetchAll();
		foreach($settingsTblDataArr as $settingsTblData){
			$captchaVal=$settingsTblData['field3'];
		}
		$session = new Container('userinfo');
		$user = $session->offsetGet('usrid');
		
		if(!empty($user)) {			
			return $this->redirect()->toRoute('vsmdashboard', array('action' => 'report'));
		}
		$this->layout('layout/login');
		$form = new LoginForm($this->getRequest()->getBaseUrl().'/data/captcha/',$captchaVal);
		
		if($this->getRequest()->isPost()) {
			// regenerate session
			session_regenerate_id(true);

			$postData = $this->getRequest()->getPost()->toArray();
			unset($postData['submit']);
			//$postData = array_map('trim', $postData);
			$strusrName=$postData['login_name'];
			$strPassword=$postData['login_password'];			
			
			//convert ' \ characters #added by niraj
			$strusrName = str_replace(["'", '\\'], '&', $strusrName);
			$postData['login_name'] = $strusrName;

			$request = $this->getRequest();
			$form->setData($request->getPost());
			//form submit code
			if($form->isValid()) {
				$postData['status'] = 'Y';
				//Start...Check the md5 password and update with new algorithem.
				if(isset($postData['login_name'])){
					$getPassLength=$appObj->updatePassAlgo($postData['login_name']);
				}
				//checking user
				$result = $this->getAppuserListTable()->checkLoginUser($postData);							
				if($result->count()> 0) {
					//get crsf token and store in session
					$crsf_token=$appObj->create_crsftoken();				
					$user_detail = $result->current();
					$userid=$user_detail['appuserid'];
					
					$session = new Container('userinfo');
					//store values in session
					$session->offsetSet('LoginName', $user_detail['apploginname']);
					$session->offsetSet('usrid', $user_detail['appuserid']);
					$session->offsetSet('utype', $user_detail['appgroupid']);
					$session->offsetSet('read_only', 1);
					$session->offsetSet('modelContent', PRODUCT_TYPE);
					$session->offsetSet('sessionId', session_id());
					//store crsf_token into session
					$session->offsetSet('crsf_token', $crsf_token);					
					
					//die("SELECT * FROM tbl_user_access WHERE module_id_fk=1 AND menu_id_fk=1 AND user_id_fk=".$user_detail['appuserid']);
					
					//New Check for Super admin 19-2-2019
					$qreyResArr=$appObj->returnQueryData("SELECT * FROM tbl_user_access WHERE module_id_fk=1 AND menu_id_fk=1 AND user_id_fk=".$user_detail['appuserid']);							
					if(count($qreyResArr) > 0){	
						 $session->offsetSet('usrid',1);
						 //over write userid						 
						 $userid=1;			 
					}
					// End New change
					
					//getting menus from session					
					$menuarr=$appObj->getmenusbyrole($userid);					
					if ($strusrName != "" && $strPassword != ""){
						$sql_queryArr = $appObj->returnQueryData("select count(*) as cntUser from appuserlist where apploginname='".$strusrName."' and password='".$appObj->securePassword($strPassword)."'");
						if(count($sql_queryArr) > 0){
						 	$session->offsetSet('username', $strusrName);
							$session->offsetSet('sessionId', session_id());	
							//getting route and action name based on user role 												
							$redirectActionArr=explode('#',$appObj->getLandingpage($session->offsetGet('usrid')));							
						}else{
							echo "Invalid username and password";
						}
                	}
					
					//getting user roles and store in array
					// code commented by niraj this is unused code
				 /*$sqlQueryRollsArr=$appObj->returnQueryData("SELECT Distinct A.appgroupid as GID from appusergroups A, appuserlist B where A.AppuserID=B.appuserid and B.apploginname = '" . $strusrName . "' and B.password='" . $appObj->securePassword($strPassword) . "' and B.active = 'Y' and A.appgroupid <=40 UNION SELECT ParentGroupID from UserDefinedGroup where appgroupid in (SELECT Distinct A.appgroupid from appusergroups A, appuserlist B,appgroups C where A.AppuserID=B.appuserid and C.appgroupid=A.appgroupid and B.apploginname = '" . $strusrName . "' and B.password='" . $appObj->securePassword($strPassword) . "' and B.active = 'Y' and A.appgroupid > 40 and C.active='Y') order by GID");			
					$usrRollsArray=array();
					foreach($sqlQueryRollsArr as $sqlQueryRollsData){
						$usrRollsArray[]=$sqlQueryRollsData['GID'];
					}*/
															
					//manage tbl_session_check 
					$appObj->manage_Tbl_Session_Check();	
					//manage log			
					$appObj->ActivityLogVSM(1, MSG_SUCCESS, 'Login');	
					if(GET_OS=='WIN'){
						//Entry for license (14-Apr-2021)
						$licenseMaster = $appObj->returnQueryData("SELECT count(*) as cnt FROM license_master");
						$licenseMasterArr = $licenseMaster->current();
						if($licenseMasterArr['cnt'] ==0){
							$purchase_date=date("Y-m-d");
							$license_validity=36;
							$license_expiry_date_timestamp = strtotime("+$license_validity months", strtotime($purchase_date));
							$license_expiry_date =date('Y-m-d',$license_expiry_date_timestamp);								
							$appObj->returnQueryData("INSERT INTO license_master SET uniqueid='".substr(md5(microtime()), 0, 5)."',orderid=AES_ENCRYPT(1011, '".POLL_ENCRYPTION_KEY."'),no_of_devices=2000,purchase_date=now(),license_validity=36,license_expiry_date='$license_expiry_date',number_of_lic_used=0,model_type=0");
						} //end
					}	
					
				return $this->redirect()->toRoute($redirectActionArr[0], array('action' =>$redirectActionArr[1]));
				} else {
					$form->setMessages(array('login_name' => array('Invalid username or password')));					
				}
			
			}
		}//end form post check
		//getting smtp info
		$smtpTblCount=$appObj->checkTableCount("tbl_smtp_configuration");
		//unused query commented by niraj
		//$getSqlData=$appObj->returnQueryData("SELECT (AES_DECRYPT(email,'$poll_encryption_key')) as email,(AES_DECRYPT(password,'$poll_encryption_key')) as password from tbl_registration_info");
		$registerCount = 1;//$getSqlData->count();
		return array('form' =>$form,'captchaVal'=>$captchaVal,'smtpTblCount'=>$smtpTblCount,'registerCount'=>$registerCount);
	}
	

	public function logoutAction() {
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		//delete data from tbl_session_check 
		$appObj->delete_Tbl_Session_CheckData();
		if(PRODUCT=='vsm'){
			$appObj->ActivityLogVSM(2,MSG_SUCCESS,'Logout');
		}else{
			$appObj->ActivityLog('Logout',MSG_SUCCESS);
		}
		$session->getManager()->destroy();
		$session->offsetSet('login_email', '');
		$session->offsetSet('user_cmpid', '');	
		$session->offsetSet('crsf_token', '');		
		return $this->redirect()->toRoute('index');
	}
	//Support page
	public function supportAction() {
	}
	
	
	/*****
	 *	@Class Name			: changeLangAction
	 *  @description	    : Using for change lang from drop down                     
	 *	@Author			    : Ashu
	 *  @Date               : 17-Jan-2020
	 *****/ 		
	public function changeLangAction(){
		$postData = $this->getRequest()->getPost()->toArray();
		$selectedLang=$postData['selectedLang'];
		if($selectedLang=='Chinese'){
			$lang='chi';
		}
		else if($selectedLang=='Polish'){
			$lang='pol';
		}
		else if($selectedLang=='German'){
			$lang='ger';
		}
		else if($selectedLang=='Japanese'){
			$lang='jap';
		}
		else if($selectedLang=='Russian'){
			$lang='rus';
		}
		else if($selectedLang=='Spanish'){
			$lang='spa';
		}
		else if($selectedLang=='French'){
			$lang='fre';
		}else if($selectedLang=='Portuguese'){
			$lang='por';
		}else if($selectedLang=='Traditional chinese'){
			$lang='trchi';
		}else{
			$lang='eng';
		} 
		$session = new Container('userinfo');	
		$session->offsetSet('lang', $lang);	
		//$this->layout('layout/login');		
		die;			
	}
	
	public function bridgeAction(){
		$key = $this->params()->fromQuery('key');
		$appObj = new ApplicationController();
		$encryptedkey = trim($key);
		$decryptedKey = $appObj->desDecrypt($encryptedkey, WIFISECURITY_KEYWORD);
		return new ViewModel(array(
			'encryptedkey' => $encryptedkey,
			'decryptedKey' => $decryptedKey,
		));
	}
	
	public function loginbridgeAction(){
		$request = $this->getRequest();
		$session = new Container('userinfo');
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$keyword = trim($request->getPost('keyword'));
			$session->getManager()->getStorage()->clear('usrid');
			$session->getManager()->getStorage()->clear('LoginName');
			$session->getManager()->getStorage()->clear('utype');
			$session->getManager()->getStorage()->clear('bridge');
			$query = "SELECT A.appuserid, A.apploginname, A.active, B.appgroupid FROM appusergroups AS B INNER JOIN appuserlist AS A ON A.appuserid=B.appuserid WHERE A.active='Y' AND B.appgroupid=1 ORDER BY A.apploginname limit 1" ;
			$result = $appObj->returnQueryData($query);
			if($result->count()>0){
				$data = $result->current();
				$session->offsetSet('LoginName', $data['apploginname']);
				$session->offsetSet('usrid', $data['appuserid']);
				$session->offsetSet('utype', $data['appgroupid']);
				$session->offsetSet('bridge', 1);
				echo'success';die;			
			}else{
				echo'error';die;	
			}
		}		
	}

	public function getAppuserListTable() {
		if(!$this->TblAppuserListTable) {
			$sm = $this->getServiceLocator();
			$this->TblAppuserListTable = $sm->get('Webapp\Model\TblAppuserListTable');
		}
		return $this->TblAppuserListTable;
	}
	public function getTblMobileFeaturesTable() {
		if(!$this->TblMobileFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblMobileFeaturesTable = $sm->get('Webapp\Model\TblMobileFeaturesTable');
		}
		return $this->TblMobileFeaturesTable;
	}
	
	public function getSettingsTable() {
		if(!$this->TblSettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
		}
		return $this->TblSettingsTable;
	}

	
	/*****
	 *	@Class Name			: forgotPasswordAction
	 *  @description	    : Using for forget pass                     
	 *	@Author			    : Vineet
	 *  @Date               : 28-Jul-2020
	 *****/ 
	public function forgotPasswordAction(){
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		$poll_encryption_key=POLL_ENCRYPTION_KEY;
		if($request->isXmlHttpRequest()) {
		$emailId= trim($request->getPost('emailId'));
		
		$qry=$appObj->returnQueryData("SELECT * FROM appuserlist WHERE email='$emailId'");
		$SmtpUser="";
		$SmtpPass="";
		if($qry->count()>0){
			$smtpQry=$appObj->returnQueryData("SELECT mailer_host,mailer_port,mailer_username,AES_DECRYPT(mailer_password,'$poll_encryption_key') as mailer_password,from_mail_id,mailer_auth,mailer_ssl FROM tbl_smtp_configuration");
			if($smtpQry->count()>0){
				$rowData=$smtpQry->current();
				$SmtpServer=$rowData['mailer_host'];
				$SmtpPort=$rowData['mailer_port'];
				$from = $rowData['from_mail_id'];
				$mailerAuth = $rowData['mailer_auth'];
				$mailerSsl = $rowData['mailer_ssl'];
				$SmtpUser=$rowData['mailer_username'];
				$SmtpPass=$rowData['mailer_password'];
			
				if($mailerAuth=="on"){
					$mailerAuth="login";
				}else{
					$mailerAuth="smtp";
				}
				if($mailerSsl=="on"){
					$SSL="ssl";
				}else{
					$SSL="tls"; // TODO
				}
			}
			
			foreach($qry as $rowData){
				$custname=$rowData['apploginname'];
				$custID=$rowData['appuserid'];
				$to = $emailId;			
			}
			
			$currentTimestamp = $this->getCurrentTimestamp();
			$encryptUsrId = $appObj->desEncrypt($custID."#$#".$currentTimestamp,KEY_SEED_NEW);
			$url='https://'.$_SERVER['HTTP_HOST'].'/index/resetpassword?tokenId='.urlencode($encryptUsrId);
			$htmlMarkup="<html><body><p>Dear ".ucfirst($custname).",<br>We received a request to reset your password.If this request was not made by you, or if you do not wish to reset your password at this time, please ignore this email.<br>Click the following link to reset your VSM password:</p><a href=".$url.">".$url."</a><br>Thanks,<br>The VSM Team</body></html>";
			
			$message = new \Zend\Mail\Message();
			$message->setFrom($from);
			$message->addTo($to);
			$message->setSubject("Password Reset");
			$html = new MimePart($htmlMarkup);
			$html->type = "text/html";
			$body = new MimeMessage();
			$body->setParts(array($html));
			$message->setBody($body);

			$transport = new SmtpTransport();
			$options   = new SmtpOptions(array(
				'name'              => $SmtpServer,
				'host'              => $SmtpServer,
				'port'              => $SmtpPort,
				'connection_class'  => $mailerAuth,
				'connection_config' => array(
					'username' => $SmtpUser,
					'password' => $SmtpPass,
					'ssl'      => $SSL,
				),
			));
			$transport->setOptions($options);
			$transport->send($message);
			if($transport){
				echo 1;die;
			}else{
				echo 0;die;
			}
		}else{
			//wrong email id
			echo 2;die;
		}
	  }
	}
	
	/*****
	 *	@Class Name			: resetpasswordAction
	 *  @description	    : using for reset passwd     
	 *	@Author			    : vineet
	 *  @Date               : 29-jul-2020
	 *****/
	public function resetpasswordAction(){
		$session = new Container('userinfo');
		$appObj = new ApplicationController();
		$form=new ResetPasswordForm();
	    $request = $this->getRequest();
	    if($request->getQuery("tokenId")){
			 $result = $this->getComplexPasswordTable()->fetchComplexPassword();
			 foreach($result as $val) {
				 $specialCharVal = $val->specialchar;
				 $alphanumericVal = $val->alphanumeric;
				 $capitalLtrVal = $val->capitalltr;
				 $minCharVal = $val->minimumchar;
				 $checkOldPassVal = $val->checkoldpass;
			 }
			 $form->setData(array('specialCharVal' => $specialCharVal, 'alphanumericVal' => $alphanumericVal, 'capitalLtrVal' => $capitalLtrVal, 'minCharVal' => $minCharVal, 'basicModeVal' => $basicModeVal));
			 $tokenId = trim($request->getQuery("tokenId"));
			 $dataArr = explode("#$#",$appObj->desDecrypt($tokenId, KEY_SEED_NEW));
			 $usrId = $dataArr[0];
			 $getTimestamp = $dataArr[1];
			  //calculate time
			 $currentTimestamp = $this->getCurrentTimestamp();
			 $timeDiffMintue = round(abs($getTimestamp - $currentTimestamp) / 60,0);
			 if($timeDiffMintue <= 30){
				if($usrId){
					$session->offsetSet('reset_token', $usrId);
					return new ViewModel(array('form'=> $form));
			    }
			  }else{
				   echo "Link has been expired. <a href=".BASE_URL."/index/login >Click here</a> to generate new link.";die;
			  }
	    }
	    //$decryptTokenId=$appObj->desDecrypt($input, KEY_SEED_NEW);
	    if($request->isPost()) { 
			$usrId = $session->offsetGet('reset_token');
		    $txtNewPassword=trim($_POST['txtNewPassword']);
		    $txtConNewPassword=trim($_POST['txtConNewPassword']);
			$txtConNewPassword=$appObj->securePassword($txtNewPassword);
			$appObj->executeQueries("UPDATE appuserlist SET password='$txtConNewPassword' WHERE appuserid='$usrId'");
			$session->offsetSet('reset_token', '');
			$this->flashMessenger()->addMessage("Password reset successfully.");
			return $this->redirect()->toRoute('index', array('action' => 'resetpassword'));
		}
		return new ViewModel(array('form'=> $form));
	   
	}

	public function saveRegisterUnitAction(){
        $appObj = new ApplicationController();
        $emailId = urlencode(trim($_POST['email']));
        $password = urlencode(trim($_POST['password']));
        $emailIdDec = trim($_POST['email']);
        $passwordDec = trim($_POST['password']);
        $poll_encryption_key=POLL_ENCRYPTION_KEY;
            
        if(!empty($emailId)){
            $url = 'https://www.kramerav.com/api/ViaApi/?email='.$emailId.'&password='.$password.'&OemSN=WOWV1484FB8411A3&AspxAutoDetectCookieSupport=1';
            $inserttext = 'Email or Password incorrect.';
            $response = json_decode(file_get_contents($url));
            if($response!=''){
                if(strcmp($response->value,$inserttext)){
                   $sql_check = $appObj->returnQueryData("SELECT * FROM tbl_registration_info");
                   $rowCount=$sql_check->count();	
               
                   if($rowCount==0){
                       $sql_query="INSERT INTO tbl_registration_info (email,password) VALUES (AES_ENCRYPT('$emailIdDec','$poll_encryption_key'),AES_ENCRYPT('$passwordDec','$poll_encryption_key'))";
                   }else{                 
                       $sql_query="UPDATE tbl_registration_info SET email=AES_ENCRYPT('$emailIdDec','$poll_encryption_key'),password=AES_ENCRYPT('$passwordDec','$poll_encryption_key')";
                   }
				  
					$getMacInfo = $appObj->returnQueryData("SELECT A.DID_Fk,A.field1 from tbl_device_dnsname A 
                         WHERE (A.DID_Fk NOT IN (select B.DID from tbl_registration_status B) OR A.DID_Fk=-1)");
                        
					if($getMacInfo->count() > 0){
					   $sql_query_status="INSERT INTO tbl_registration_status(DID,status)values ";
					   $value_array=array();
                          foreach($getMacInfo as $row){
						   $getDID=$row['DID_Fk'];
						   $value_array[] = "($getDID, 0)"; 
					   }
						$sql_query_status .= implode(',', $value_array);
						$appObj->executeQueries($sql_query_status);
					}  
                    $appObj->executeQueries($sql_query);
                   echo 'success';die;
                }else{
                    echo '';die;
                }   
            }else{
                echo 'empty';die;
            }   
        }
    }
	
	
	 /*****
	 *	@Class Name			: getCurrentTimestamp
	 *  @description	    : get current time                   
	 *	@Author			    : Dileep
	 *  @Date               : 30-April-2020
	 *****/ 
	 public function getCurrentTimestamp()
     { 
		 $ConnObject=new ServicesController();
		 $connection=$ConnObject->getConnection();
		 $queryResult = $connection->execute("SELECT now() as c_time;");
		 $response=$queryResult->current();
		 $currentTimestamp = strtotime($response['c_time']);
		 return $currentTimestamp; 
 	 }
	 
	/*****
	 *	@Class Name			: getComplexPasswordTable
	 *  @description	    : get complexpass table      
	 *	@Author			    : vineet
	 *  @Date               : 28-jul-2020
	 *****/ 	 
	 
	public function getComplexPasswordTable() {
		if(!$this->TblComplexPasswordTable) {
			$sm = $this->getServiceLocator();
			$this->TblComplexPasswordTable = $sm->get('Webapp\Model\TblComplexPasswordTable');
		}
		return $this->TblComplexPasswordTable;
	}
	
	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}
	
}
