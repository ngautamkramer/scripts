<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Form\RecordingForm;
use Webapp\Controller\ApplicationController;
class RecordingController extends AbstractActionController {

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		if(PRODUCT=='via'){
			$getSettingObj = $appObj->getComplexPasswordSettings();
			$getSettingData = $getSettingObj->webadmin_session_timeout;
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
			foreach($tblSessionTimeOutDataArr as $sessiondata){
				$getSettingData=$sessiondata['logoutTime'];
			}
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
	public function recordingListAction() {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		if(PRODUCT=='via'){
			$result = $this->getAdvanceConfigurationTable()->getAdvanceConfigData();
			$feature4 = $result->feature4;
			//$feature4=0;
			$configData=$this->getHqConfigurationTable()->getAllHqConfig();
			$row = $configData->current();
			$configSettingVal= $row->hq_configsetting;
		}else{
			$feature4=1;
		}
		$form = new RecordingForm();
			if(!$request->isPost()) {
			if($user_id != 1) {
				if(PRODUCT_TYPE=='vsm'){
					$data = $appObj->returnQueryData("SELECT GROUP_CONCAT(DISTINCT(group_id_fk)) as group_id FROM tbl_user_access WHERE user_id_fk=$user_id AND menu_id_fk IN (51,52)");
					
					foreach($data as $querdata) {
						$dataId = $querdata['group_id'];
						//$dataId = json_encode($querydata);
					}
					$user_id = 0;
					$tableData = $this->getRecordingMasterTable()->fetchAll($user_id, $dataId);
				}else{
					$tableData = $this->getRecordingMasterTable()->fetchAll($user_id, null);
				}	
			} else {
				$tableData = $this->getRecordingMasterTable()->fetchAll($user_id, null);
			}
			if($_GET["search"] != "") {
				$value = $_GET["search"];
				$searchValue=preg_replace('/[^A-Za-z0-9\-]/', '', trim($value));
				$tableData = $this->getRecordingMasterTable()->getRecording($user_id, $dataId, $searchValue);
				$form->setData(['search' => $value]);
			}
		}

		$tableData['data']->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
		$tableData['data']->setItemCountPerPage(10);
		$viewmodel = new ViewModel(array('form' => $form, 'data' => $tableData['data'], 'user_id' => $user_id,'count'=> $tableData['count'],'feature4' => $feature4,'configSettingVal'=>$configSettingVal));
		if(PRODUCT == "via"){
			$viewmodel->setTemplate("webapp/utility/system-settings");
		}
		return $viewmodel;
	}
	
	/*****
	 *	@Function Name: downloadRecordingAction
	 *  @description  : download recording file
	 *	@Author		  : Vineet
	 *  @Date         : 17-march-2020
	 *****/
	public function downloadRecordingAction() {
	
		if(PRODUCT=='via'){
			$file_url = $_GET['file'];
		}else{
			$file_url = RECORDING_PATH.'/'.$_GET['file'];
		}
		header('Content-Type: application/octet-stream');
		header("Content-Transfer-Encoding: Binary"); 
		header("Content-disposition: attachment; filename=\"" . basename($file_url) . "\""); 
		readfile($file_url);
		exit();
	}
	
	/*****
	 *	@Function Name: deleteRecordingAction
	 *  @description  : delete recording file
	 *	@Author		  : Vineet
	 *  @Date         : 17-march-2020
	 *****/
	public function deleteRecordingAction() {
		$recordingId = $this->params()->fromRoute('id');
		$result = $this->getRecordingChildTable()->fetchRecordingChild($recordingId);
		$fileName = $result->filename;
		if(PRODUCT=='via'){
			$path = $result->reserved2;
		}else{
			$path = RECORDING_PATH;
		}
		$file_url = $path . $fileName;
		if(substr($path, - 1)!= '/' || substr($path, - 1)!= '\\') {
			$path = $path . '/';
		}

		if(file_exists($file_url)) {
			unlink($file_url);
		}
		$deldata = $this->getRecordingMasterTable()->deleteRecording($recordingId);
		$deldata = $this->getRecordingChildTable()->deleteRecordingChild($recordingId);
		return $this->redirect()->toRoute('getrecording');
	}
	
	/*****
	 *	@Function Name: editRecordingAction
	 *  @description  : edit recording file
	 *	@Author		  : Vineet
	 *  @Date         : 17-march-2020
	 *****/
	public function editRecordingAction() {
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$result = $this->getRecordingMasterTable()->getRecordingDataById($data[0]);
		
			if($result != null) {
				$temp = array('sessionname' =>$result->sessionname,
							  'description' =>($result->description == null)? '' :$result->description,
							 );
			}
			$view = new JsonModel(array('success' => $temp));
			$view->setTerminal(true);
			return $view;
		}
	}
	
	/*****
	 *	@Function Name: updateRecordingAction
	 *  @description  : update recording file
	 *	@Author		  : Vineet
	 *  @Date         : 20-march-2020
	 *****/
	public function updateRecordingAction() {
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$result = $this->getRecordingMasterTable()->updateRecording($data[0], $data[1], $data[2]);
		
			if($result==0||$result==1)
				$msg = true;
			$view = new JsonModel(array('success' => $msg));
			$view->setTerminal(true);
			return $view;
		}
	}
	/*****
	 *	@Function Name: setRecordingConfigurationAction
	 *  @description  : enable recording
	 *	@Author		  : Vineet
	 *  @Date         : 8-sep-2020
	 *****/
	public function setRecordingConfigurationAction() {
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('checkVal');
			$this->getAdvanceConfigurationTable()->updateConfiguration($data);
			if($data == 1) {
				if(PRODUCT=='via'){
					$this->getActivityLogMasterTable()->setActivity($loginName, STR_ACTIVATE, MSG_SET_RECORDINGBY, $hostname);
				}else{
					$appObj->ActivityLogVSM(7,MSG_SET_RECORDINGBY,17);
				}
				
			}
			$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ForceStopRecord</Cmd><P1>$loginName</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$appObj->sendMsgToAPIserver($logincmd,$actionCmd);						
			echo 'successAndReboot';
			die();
		}
	}
	
	/*****
	 *  @description  : get table
	 *	@Author		  : Vineet
	 *  @Date         : 17-march-2020
	 *****/
	public function getRecordingMasterTable() {
		if(!$this->TblRecordingMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblRecordingMasterTable = $sm->get('Webapp\Model\TblRecordingMasterTable');
		}
		return $this->TblRecordingMasterTable;
	}

	public function getRecordingChildTable() {
		if(!$this->TblRecordingChildTable) {
			$sm = $this->getServiceLocator();
			$this->TblRecordingChildTable = $sm->get('Webapp\Model\TblRecordingChildTable');
		}
		return $this->TblRecordingChildTable;
	}
	public function getHqConfigurationTable() {
		if(!$this->TblHqConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblHqConfigurationTable = $sm->get('Webapp\Model\TblHqConfigurationTable');
		}
		return $this->TblHqConfigurationTable;
	}
	public function getAdvanceConfigurationTable() {
		if(!$this->TblAdvanceConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationTable = $sm->get('Webapp\Model\TblAdvanceConfigurationTable');
		}
		return $this->TblAdvanceConfigurationTable;
	}
	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}
}
