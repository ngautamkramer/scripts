<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\ViewModel;
use Webapp\Form\GatewaysForm;
use Zend\Validator\File\Size;
use Zend\Validator\File\Extension;
use Zend\Validator\File\Rename;
use Zend\File\Transfer\Adapter\Http;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\WebProducerController;
//for email
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;
use Zend\Mime\Part as MimePart;
use Zend\Mime\Message as MimeMessage;

class GatewaysController extends AbstractActionController
{
        public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
        
        public function listAction(){
			//added by ashu on 13May2021 for showing the menu accordingly when we select option from dashboard
			$noDevicePopupRequest=0;
			if($this->params()->fromQuery('flag')!=''){
				$noDevicePopupRequest = $this->params()->fromQuery('flag');
			}
			//end
			if(PRODUCT=='kds'){
				die('Access denied.');
			}
            $session = new Container('userinfo');
            $user_id = $session->offsetGet('usrid');
            $form = new GatewaysForm();
            $request = $this->getRequest();
            $appObj = new ApplicationController();
			if($request->getPost('rowsPerPage')!='') $session->offsetSet('rowsPerPage', $request->getPost('rowsPerPage'));
			$rowsPerPage = ($session->offsetGet('rowsPerPage')!='')?$session->offsetGet('rowsPerPage'):'50';
			
            if(!$request->isPost()) {
                if( $_GET["gatewaySearchBox"]){
                    $definput=htmlspecialchars(trim($_GET['gatewaySearchBox']));
                }
            }else {
                $definput=htmlspecialchars(trim($_POST['gatewaySearchBox']));
               
                $form->setData($request->getPost());
				if($form->isValid()){
				   //$dataPost = $form->getData();
				}
				$dataPost = $form->getData();
                $definput = htmlspecialchars(trim($dataPost['gatewaySearchBox']));
                if(isset($_POST['csv'])) {
                        $csvdata = $this->getDeviceInventoryTable()->getGatewayList($user_id, $definput, 'csv');
                        $this->exportToCsv($csvdata['data']);
                }
            }
            if($request->getPost('downloadFileTxtbox')!=''){
                    $file=BASE_PATH.'/public/uploads/'.$request->getPost('downloadFileTxtbox');
                    if (!file_exists($file)) {
                        return false;
                    }
                    header('Content-Description: File Transfer');
                    header('Content-type: application/csv');  
                    header("Content-Disposition: attachment; filename=".basename($file));   
                    readfile($file); 
                    exit;	
            }
            $encryptKey=$appObj->desEncrypt(BRIDGE_KEYWORD, WIFISECURITY_KEYWORD);

			$qry = $this->getAutoDiscoverVsmTable()->getData(array('os_type'=>0));
            if($qry->count()==0){
				$insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>1,'HQ_ClientFeatureSetting'=>1,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>1,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>0);
				$this->getAutoDiscoverVsmTable()->insert($insertArr);
            }	
            $qry1 = $this->getAutoDiscoverVsmTable()->getData(array('os_type'=>1));
            if($qry1->count()==0){	
                if(PRODUCT_TYPE=='via'){	
                    $insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>1,'HQ_ClientFeatureSetting'=>1,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>2,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>1);
					$this->getAutoDiscoverVsmTable()->insert($insertArr);
                }else{
                    $insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>1,'HQ_ClientFeatureSetting'=>1,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>1,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>1);
					$this->getAutoDiscoverVsmTable()->insert($insertArr);
                }
            }	
            $qry2 = $this->getAutoDiscoverVsmTable()->getData(array('os_type'=>2));
            if($qry2->count()==0){
					$insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>1,'HQ_ClientFeatureSetting'=>1,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>1,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>2);
					$this->getAutoDiscoverVsmTable()->insert($insertArr);
            }	
            $qry3 = $this->getAutoDiscoverVsmTable()->getData(array('os_type'=>3));
            if($qry3->count()==0){
				$insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>2,'HQ_ClientFeatureSetting'=>2,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>2,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>3);
				$this->getAutoDiscoverVsmTable()->insert($insertArr);
            }	

            $qry4 = $this->getAutoDiscoverVsmTable()->getData(array('os_type'=>4));
            if($qry4->count()==0){
                if(PRODUCT_TYPE=='via'){
					$insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>1,'HQ_ClientFeatureSetting'=>1,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>2,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>4);
					$this->getAutoDiscoverVsmTable()->insert($insertArr);
                }else{
                    $insertArr = array('HQ_WallpaperSetting'=>1,'HQ_AuthSetting'=>1,'HQ_ConfigSetting'=>1,'HQ_GwayFeatureSetting'=>1,'HQ_ClientFeatureSetting'=>1,'HQ_MobileFeatureSetting'=>1,'featureStatus1'=>1,'featureStatus2'=>1,'featureStatus3'=>1,'featureStatus4'=>1,'featureStatus5'=>1,'featureStatus6'=>2,'featureStatus7'=>2,'featureStatus8'=>2,'featureStatus9'=>2,'featureStatus10'=>2,'os_type'=>4);
					$this->getAutoDiscoverVsmTable()->insert($insertArr);
                }		
            }
			
            $statusQry=$appObj->returnQueryData("SELECT * FROM tbl_auto_discover_status");
            if($statusQry->count()>0){
                foreach($statusQry as $statusdata){
                    $autoServerStatus=$statusdata['isactive'];
                    $dns_name=$statusdata['dns_name'];
                }
            }else{
                $autoServerStatus=0;
                $dns_name=$_SERVER['SERVER_ADDR'];
            }// end autoboarding
			$res = $appObj->returnQueryData("SELECT * from devicegroup order by DeviceGroup");
			$i=0;
			foreach($res as $group){
				$groupArr[$i]['id'] = $group['DeviceGroupID'];
				$groupArr[$i]['label'] = $group['DeviceGroup'];
				$i++;
			}
			$groupJson = json_encode($groupArr);
			$firmwareVersion = $appObj->returnQueryData("SELECT DISTINCT Version FROM DeviceInventory WHERE Version<>-1 AND Version<>'' ORDER BY Version DESC");
			$i=0;
			foreach($firmwareVersion as $version){
				$versionArr[$i]['id'] = $i;
				$versionArr[$i]['label'] = $version['Version'];
				$i++;
			}		
			$versionJson = json_encode($versionArr);
			if(file_exists(DEST_PATH."model.json")){
				$jsonStr = file_get_contents(DEST_PATH."model.json");
				$json_arr = json_decode($jsonStr,true);
				$i=0;
				foreach($json_arr as $k =>$val){
					if($val['modelvalue']!=1 && $val['modelvalue']!=5 && $val['modelvalue']!=13){
						$modelArr[$i]['id'] = $val['modelvalue'];
						$modelArr[$i]['label'] = $val['modelshow'];
						$i++;
					}	
				}		
			}
			
			$modelJson = json_encode($modelArr);
            $form->setData(array('search' => $search));
			
			$screenEditordata=$this->getTemplatesTable()->fetchAll($template);
			$settingsTemplatedata=$this->getViaSettingsTemplatesTable()->fetchAll();
            return new ViewModel(array(
                    'form' => $form,
                    'encryptKey' => $encryptKey,
                    'autoServerStatus' => $autoServerStatus,
					'versionJson'=>$versionJson,
					'groupJson'=>$groupJson,
					'modelJson'=>$modelJson,
					'rowsPerPage'=>$rowsPerPage,
					'screenEditordata'=>$screenEditordata,
					'settingsTemplatedata'=>$settingsTemplatedata,
					'noDevicePopupRequest'=>$noDevicePopupRequest,
            ));
        }
		
		public function searchGatewayAction(){
			$request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
				$appObj = new ApplicationController();
                $searchJson = json_decode($request->getPost('json'));
				$session = new Container('userinfo');
				$user_id = $session->offsetGet('usrid');
				$new_array = [];
				if($request->getPost('json')!=''){
					foreach($searchJson as $key => $val){
						$new_array[$key]['id'] = $val->value->value;
						$new_array[$key]['field'] = $val->field->value;
						$new_array[$key]['value'] = $val->value->label;
					}
				}
				$searchArr = [];
				foreach($new_array as $arr) {
					$field = $arr['field'];
					$id = $arr['id'];
					$value = $arr['value'];
					//if($field == 'DeviceGroup'){
						if(!array_key_exists($field, $searchArr)) {
							//key doesn't exist in new array, so create it
							$searchArr[$field] = $arr;
						} else {
							//key exists in new array, append new values
							$searchArr[$field]['id'] .= ",{$id}";
							$searchArr[$field]['value'] .= ",{$value}";
						}
					//}
				}
				
				$searchArr = array_values($searchArr);
				$resultArr = $this->getDeviceInventoryTable()->searchGateway($user_id, $searchArr);
				$result = $resultArr['data'];
				$count = $resultArr['count'];
				$result->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
				$result->setItemCountPerPage($rowsPerPage);
				echo STR_TOTAL_NUMBER_OFF_RECORD_FOUND.' '.$count.'~';
				if($count>0){ ?>
					<?php foreach ($result as $gateway) {
						$DevIP=($gateway['Active']=='Y' && $gateway['DeviceIP']=="DHCP")?'DHCP':$gateway['DeviceIP'];
						$showStar=($gateway['DeviceIP']!="DHCP" && $gateway['Active']=='Y')?' *':'';
						$nw_status=($gateway['Network_status']==1 || $gateway['Network_status']==2)?'ON':'OFF';
						//For showing network status image in place of text
						if($gateway['Network_status']==1){ $nwImage=PUBLIC_URL.'/img/via/icon/Button-Power-green-48.png'; $nwTitle="ON";}
						if($gateway['Network_status']==0 || $gateway['Network_status']==-1){ $nwImage=PUBLIC_URL.'/img/via/icon/Button-Power-red-48.png'; $nwTitle="OFF";}
						if($gateway['Network_status']==2){ $nwImage=PUBLIC_URL.'/img/via/icon/Button-Power-green-48.png'; $nwTitle=$titleDisplay;}
						
						$nwCss=($nw_status=='ON')?'green':'red';
						if($gateway['os_type']==0) {$osType='Windows';}
						if($gateway['os_type']==1) {$osType='Linux';}
						//TO Match Gateway IP with Old IP Address in case of Static
						$misMatchNote='';
						if($DevIP!='DHCP'){					  	
							$misMatchNote=($gateway['oldIPAddess']!="" && $gateway['DeviceIP']!=$gateway['oldIPAddess'])?'#':'';
							if($gateway['oldIPAddess']!="" && $gateway['DeviceIP']!=$gateway['oldIPAddess']){
								$DevIP=$gateway['oldIPAddess'];
							}				
						}
						$gatewayVersion='';
						if(strstr($gateway['Version'],'.')){						
							$versionExlode=explode('.',$gateway['Version']);
							$versionbuild=trim($versionExlode[3]);
							//Added on 28Oct22 for getting Gateway Version
							$gatewayVersion=trim($versionExlode[0]).'.'.trim($versionExlode[1]);
							
						}
						$gateway['versionbuild'] = $versionbuild;
						
						if($gateway['Active']=='N'){
							$gloablsettingStatusImg=PUBLIC_URL.'/img/via/icon/locked.svg'; $gbImgMouseOverTxt='VIA Manager license expired';$pushClassGlobal="";
						}else if($gateway['global_sync_status'] == 0){
							$gloablsettingStatusImg=PUBLIC_URL.'/img/via/icon/hq32x32-red-refresh.png'; $gbImgMouseOverTxt=STR_VIA_PENDING_FOR_UPDATE;$pushClassGlobal="push_config";
						}else if($gateway['global_sync_status'] == 1){
							$gloablsettingStatusImg=PUBLIC_URL.'/img/via/icon/VSM_Status_Green_icon_64x64px.png'; $gbImgMouseOverTxt=STR_VIA_UPDATES_COMPLETE;$pushClassGlobal="push_config";
						}
						
						$modelObj = $appObj->getModelFromJson($gateway['model_value']);
						//if(file_exists($_SERVER["DOCUMENT_ROOT"]."/../bin/config/serverconfig.xml")){
							/*$sqlData=$appObj->returnQueryData("SELECT count(OS) as count,OS FROM tbl_GatewayCurrentInfo WHERE DeviceID=".$gateway['DeviceID']." GROUP BY OS");
							if($sqlData->count()>0){			
								foreach($sqlData as $data){
									$userCount.=$data['OS'].'&nbsp;&nbsp;:&nbsp;&nbsp;'.$data['count'].' Users';
								}   
							}else{
								$userCount='0 User';
							}*/
						//}
					
							
							// get user/dss count
							$sqlData=$appObj->returnQueryData("SELECT count(OS) AS count,OS FROM tbl_GatewayCurrentInfo WHERE DeviceID=".$gateway['DID']." GROUP BY OS");
							$userCountArray=array();
							$dssUserCountArray=array();
							//echo "<br>".$sqlData->count().' and '.	$gateway['DeviceID'];
							$dssFlag=0;						
							if($sqlData->count()>0){
								//$dssFlag=1;
								$userCount='';			
								foreach($sqlData as $data){									
									if(trim($data['OS'])=='DSS'){
										$dssFlag=1;
										$dssUserCountArray[]=$data['count'];
										$userText=($data['count']>1)?'Users':'User';										
										//$dssUserCount=$data['OS'].'&nbsp;&nbsp;:&nbsp;&nbsp;'.$data['count'].' '.$userText;
										$dssUserCount="DSS Running";
									}else{
									
									$userCountArray[]=$data['count'];
									$userText=($data['count']>1)?'Users':'User';
									$userCount.=$data['OS'].'&nbsp;:&nbsp;'.$data['count'].' '.$userText.', ';
										//$userCount1=$userCount1+$data['count'];
									}
									
								}   
							}else{
								$userCount='0 User';
								$dssUserCount='0 User';								
							}							
							$getUserCount=array_sum($userCountArray);
							$getDSSUserCount=array_sum($dssUserCountArray);							
							$rowColorCss='';								
							if($dssFlag==1){
								//$userImg='dssActiveUser.png';
								$userImg='dss_activeUser.png';
							}elseif($getUserCount>0){
								$userImg='activeUser.png';
							}else{
								$userImg='Participants.png';
								
							}
							
							$showUserCount=strstr($userCount,',')?substr(trim($userCount),0,-1):$userCount;
					?>
					
					  <tr class="<?php echo ($gateway['Active']=='N')?'css_expired_license':'gwayDetailCss editItemCss'?>" id="<?php echo $gateway['DID'].'#'.$gateway['DeviceID'];?>">
						<span class="hide"><?php echo $gateway['field1'];?></span>
						<td><?php echo $gateway['DeviceID'] ?></td>
						<td><?php echo $gateway['DeviceName'] ?>
						<?php //if(file_exists($_SERVER["DOCUMENT_ROOT"]."/../bin/config/serverconfig.xml")) { ?>
						<?php if($dssFlag==1 || $getUserCount>=0) { ?>
						&nbsp;<span data-toggle="tooltip" data-placement="bottom" title="<?php echo ($dssFlag==1)?$dssUserCount:$showUserCount;?>" data-original-title="<?php echo ($dssFlag==1)?$dssUserCount:$showUserCount;?>">
						<img src="<?php echo PUBLIC_URL.'/img/via/icon/'.$userImg?>" style="height:25px;width:25px;" /></span><?php //}
						} ?>
						</td>
						<td><?php echo $modelObj->modelshow;?></td>
						<td><?php echo $gateway['Version']==-1?"":$gateway['Version'];?></td>
						<td><span>&nbsp;<?php echo $DevIP;?></span><br/>
						<span>&nbsp;<?php echo ($gateway['MacAddress']!="")?'('. $gateway['MacAddress'].')':'';?></span></td>
						<td><?php echo $gateway['DeviceGroup'] ?></td>
						<td class="<?php echo $nwCss;?> text-center"><img src="<?php echo $nwImage;?>" title="<?php echo $nwTitle;?>" width="20px" height="20px"/></td>
						<td class="text-center noclick-td">
						<img src="<?php echo $gloablsettingStatusImg;?>" title="<?php echo $gbImgMouseOverTxt;?>" width="20px" height="20px" class="<?php echo $pushClassGlobal; ?>" rev="<?php echo $gateway['DID']; ?>" via_version="<?php echo $gatewayVersion; ?>"/>
						</td>
						<td><?php echo ($gateway['last_updated_time']!='0000-00-00 00:00:00')?$appObj->get_time_ago($gateway['last_updated_time']):'-';?></td>
						<td class="text-right noclick-td"><input type="checkbox" name="delchk" id="delchk_<?php echo $gateway['DID'];?>" class="chkbox" value="<?php echo $gateway['DID'];?>" rev="<?php echo $gateway['DeviceID'];?>" /><label for="delchk_<?php echo $gateway['DID'];?>"><span></span></label></td>
					  </tr>
					  
					<?php
					}
				}else{
					echo '<tr><td colspan="10" align="center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
				}
			}
			die;
		}
		
		public function setPageSizeAction(){
			$request = $this->getRequest();
            if($request->isXmlHttpRequest()){
				$session = new Container('userinfo');
				$appObj = new ApplicationController();
                $pagesize = trim($request->getPost('pagesize'));
				($pagesize!='')? $session->offsetSet('rowsPerPage', $pagesize):$session->offsetSet('rowsPerPage', '50');
				echo $session->offsetGet('rowsPerPage');die;
			}
		}
		
		public function gatewaysDetailAction(){
			$request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $gatewayID = trim($request->getPost('did'));
                $sqlData=$appObj->returnQueryData("SELECT count(OS) as count,OS FROM tbl_GatewayCurrentInfo WHERE DeviceID=".$gatewayID." GROUP BY OS");
				$gatewayData = array();
                if($sqlData->count()>0){			
                    foreach($sqlData as $value){
						$gatewayData['userCount'][] = $value['OS'].'&nbsp;&nbsp;:&nbsp;&nbsp;'.$value['count'].' Users';
					}   
                }else{
					$gatewayData['userCount'][]='0 User';
				}
				$dnsSql=$this->getDeviceDnsnameTable()->getData(array('DID_Fk'=>$gatewayID));
				if($dnsSql->count()>0){
					$dnsRow=$dnsSql->current();
					$serial= $dnsRow['field1'];						
				}else{
					$serial=""; 
				}
				$gatewayData['serial'] = $serial;
				$sqlConfig = $this->getDeviceInventoryTable()->getGatewayDetails($gatewayID);
                if($sqlConfig->count()>0){
                    $dataConfig = $sqlConfig->current();
                    $pushClassWall="";
					$pushClassConfig="";
					$pushClassGlobal="";
					$DevIP = $dataConfig['DeviceIP'];
					$encryptKey=$appObj->desEncrypt(BRIDGE_KEYWORD, WIFISECURITY_KEYWORD);	
					$nw_status=($dataConfig['Network_status']==1 || $dataConfig['Network_status']==2)?'ON':'OFF';
					$gatewayVersion='';
					if($dataConfig['Version']==-1){
						  $dVersion="";
					  }else{
						$dVersion=$dataConfig['Version'];
						//Added on 28Oct22 for getting Gateway Version
						$versionExlode=explode('.',$dataConfig['Version']);	
						$gatewayVersion=trim($versionExlode[0]).'.'.trim($versionExlode[1]);
					  }
					  //Show network Info based on network_code
					  $extraInfoSql = $appObj->returnQueryData("SELECT * FROM tbl_device_extra_info WHERE deviceID_Fk=".$gatewayID)->current();
					  $network_code = $extraInfoSql['network_code'];
					  if($network_code == 9){
						 $network = 'LAN'; 
					  }
					  if($network_code == 1){
						 $network = 'AP Mode'; 
					  }
					  if($network_code == 2){
						 $network = 'Guest Mode'; 
					  }
					  if($network_code == 4){
						 $network = 'AP Mode Stand Alone'; 
					  }
					  if($network_code == 5){
						 $network = 'Client Mode'; 
					  }
					  if($network_code == 6){
						 $network = 'Dual Network Mode'; 
					  }
					  if($network_code == 7){
						 $network = 'Guest Mode Available'; 
					  }
					  if($network_code == 8){
						 $network = 'Guest Mode not Available'; 
					  }
					//For getting build no. build no is using when we auto logged in to gateway. now we restrict auto login below build no 1058
					if(strstr($dVersion,'.')){						
						$versionExlode=explode('.',$dVersion);
						$versionbuild=trim($versionExlode[3]);
						$version=trim($versionExlode[0].'.'.$versionExlode[1]);
					}
					$gatewayData['redirectRev'] = $nw_status.'#'.$DevIP.'#'.$encryptKey.'#'.$versionbuild.'#'.$version;
					if($dataConfig['HD_Status']<=50){ $HDImage=PUBLIC_URL.'/img/via/icon/Dashboard-green-48.png'; $HDTitle="Normal";}
					if($dataConfig['HD_Status']>50 && $dataConfig['HD_Status']<=70){ $HDImage=PUBLIC_URL.'/img/via/icon/Dashboard-yellow-48.png'; $HDTitle="Moderate";}
					if($dataConfig['HD_Status']>70){ $HDImage=PUBLIC_URL.'/img/via/icon/Dashboard-red-48.png'; $HDTitle="High";}
						
					if($dataConfig['wallpaper_status']==0){ 
						$wallPStatusImg=PUBLIC_URL.'/img/via/icon/hq32x32-red-refresh.png'; 
						$wallpImgMouseOverTxt=STR_VIA_PENDING_FOR_UPDATE;$pushClassWall="push_config";
					}
					if($dataConfig['wallpaper_status']==1){ 
						$wallPStatusImg=PUBLIC_URL.'/img/via/icon/VSM_Status_Green_icon_64x64px.png'; 
						$wallpImgMouseOverTxt=STR_VIA_UPDATES_COMPLETE;$pushClassWall="push_config";
					}
					if($dataConfig['wallpaper_status']==2){ 
						$wallPStatusImg=PUBLIC_URL.'/img/via/icon/VIA_Unit_Status_icon_64x64px.png'; 
						$wallpImgMouseOverTxt=STR_GATEWAY;
					}
														
					if($dataConfig['configSettingStatus']==0){ 
						$configStatusImg=PUBLIC_URL.'/img/via/icon/hq32x32-red-refresh.png'; 
						$configImgMouseOverTxt=STR_VIA_PENDING_FOR_UPDATE;$pushClassConfig="push_config";
					}
					if($dataConfig['configSettingStatus']==1){
						$configStatusImg=PUBLIC_URL.'/img/via/icon/VSM_Status_Green_icon_64x64px.png'; 
						$configImgMouseOverTxt=STR_VIA_UPDATES_COMPLETE;
						$pushClassConfig="push_config";
					}
					if($dataConfig['configSettingStatus']==2){
						$configStatusImg=PUBLIC_URL.'/img/via/icon/VIA_Unit_Status_icon_64x64px.png'; 
						$configImgMouseOverTxt=STR_GATEWAY;
					}
					
					//dss
					if($dataConfig['extraField1']==0 || $dataConfig['extraField1']==""){ 
						$dssStatusImg=PUBLIC_URL.'/img/via/icon/hq32x32-red-refresh.png'; 
						$dssImgMouseOverTxt=STR_VIA_PENDING_FOR_UPDATE;
					}
					if($dataConfig['extraField1']==1){ 
						$dssStatusImg=PUBLIC_URL.'/img/via/icon/VSM_Status_Green_icon_64x64px.png'; 
						$dssImgMouseOverTxt=STR_VIA_UPDATES_COMPLETE;}
					if($dataConfig['extraField1']==2){ 
						$dssStatusImg=PUBLIC_URL.'/img/via/icon/VIA_Unit_Status_icon_64x64px.png'; 
						$dssImgMouseOverTxt=STR_GATEWAY;
					}	
					$deviceIp = $dataConfig['DeviceIP'];
					$deviceGrpId = $dataConfig['DeviceGroupID'];
					
					//advance mode implementation. First priority is advance mode then basic
					$screenEditorTempCount=$appObj->returnQueryData("SELECT b.id, b.template_name FROM tbl_templates_mapping a INNER JOIN tbl_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$gatewayID AND a.entryType=1");					
					if($screenEditorTempCount->count() > 0){
						$templateSql=$appObj->returnQueryData("SELECT b.id, b.template_name FROM tbl_templates_mapping a INNER JOIN tbl_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$gatewayID  AND a.entryType=1")->current();
						$templateName = $templateSql['template_name'];
						$templateId = $templateSql['id'];					
					}else{					
						$templateSql = $appObj->returnQueryData("SELECT b.id, b.template_name FROM tbl_templates_mapping a INNER JOIN tbl_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$deviceGrpId")->current();
						$templateName = $templateSql['template_name'];
						$templateId = $templateSql['id'];
					}
					
					$settingsTempCount=$appObj->returnQueryData("SELECT b.template_name FROM tbl_via_settings_templates_mapping a INNER JOIN tbl_via_settings_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$gatewayID AND a.entryType=1");					
					
					if($settingsTempCount->count() > 0){
						$settingSql=$appObj->returnQueryData("SELECT b.id,b.template_name FROM tbl_via_settings_templates_mapping a INNER JOIN tbl_via_settings_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$gatewayID AND a.entryType=1")->current();
						$settingName = $settingSql['template_name'];
						$settingTemplateId = $settingSql['id'];
					}else{				
						$settingSql = $appObj->returnQueryData("SELECT b.id,b.template_name FROM tbl_via_settings_templates_mapping a INNER JOIN tbl_via_settings_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$deviceGrpId")->current();
						$settingName = $settingSql['template_name'];
						$settingTemplateId = $settingSql['id'];
					
					}
                }
                //calendar
				$calendarStatus = $appObj->returnQueryData("SELECT sync_status FROM tbl_gway_cal_relation WHERE device_id = $gatewayID");
				if($calendarStatus->count() > 0){
					$calendarStatusArr = $calendarStatus->current();
					if($calendarStatusArr['sync_status']==0 || $calendarStatusArr['sync_status']==""){ 
						$calStatusImg=PUBLIC_URL.'/img/via/icon/hq32x32-red-refresh.png'; 
						$calImgMouseOverTxt=STR_VIA_PENDING_FOR_UPDATE;
					}
					if($calendarStatusArr['sync_status']==1){ 
						$calStatusImg=PUBLIC_URL.'/img/via/icon/VSM_Status_Green_icon_64x64px.png'; 
						$calImgMouseOverTxt=STR_VIA_UPDATES_COMPLETE;
					}
					if($calendarStatusArr['sync_status']==2){ 
						$calStatusImg=PUBLIC_URL.'/img/via/icon/VIA_Unit_Status_icon_64x64px.png'; 
						$calImgMouseOverTxt=STR_GATEWAY;
					}
				}
					
				$deviceIp = $dataConfig['DeviceIP'];				
                $gatewayData['wallpaper']['img'] = $wallPStatusImg;
				$gatewayData['wallpaper']['status'] = $wallpImgMouseOverTxt;
				$gatewayData['config']['img'] = $configStatusImg;
				$gatewayData['config']['status'] = $configImgMouseOverTxt;  
				$gatewayData['dss']['img'] = $dssStatusImg;
				$gatewayData['dss']['status'] = $dssImgMouseOverTxt;
				if($calendarStatus->count() > 0){
					$gatewayData['cal']['img'] = $calStatusImg;
					$gatewayData['cal']['status'] = $calImgMouseOverTxt;
				}
				$gatewayData['storage']['img'] = $HDImage;
				$gatewayData['storage']['status'] = $HDTitle;
				$gatewayData['DeviceIP'] = $deviceIp;
				$gatewayData['networkInfo'] = $network;
				$gatewayData['templateName'] = $templateName;
				$gatewayData['templateId'] = $templateId;
				$gatewayData['settingName'] = $settingName;
				/* added on 24/06/2021 for edit template name so storing setting and screen template ids and passing to view */
				$gatewayData['settingTemplateId'] = $appObj->desEncrypt($settingTemplateId, KEY_SEED);
				$gatewayData['screenEditorTemplateId'] = $appObj->desEncrypt($templateId, KEY_SEED);
				//added on 28/10/2022 by ashu for adding via version in array
				$gatewayData['gatewayVersion'] = $gatewayVersion;				
				echo json_encode($gatewayData);die; 
            }
		}
		
		public function getPreviewAction(){
			$request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $templateId = trim($request->getPost('templateId'));
				$previewUrl = BASE_URL.'/screeneditor/templatePreview?imgID='.urlencode($appObj->desEncrypt($templateId, KEY_SEED));
				echo $previewUrl;die;
			}
		}
        
        public function exportToCsv($data) {
			$idx = 0;
			$downloadfnameCsv=(PRODUCT_TYPE=='collab8')?'collab8gatewaylist.csv':'viagatewaylist.csv';
			$appObj = new ApplicationController();
			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename='.$downloadfnameCsv);
			$output = fopen('php://output', 'w');
			fputcsv($output, array("Device Id","Device Name","Group Name","Device IP","DHCP","DNS Name","Air Mirror Name","Max No. Of Mirrored IOS Devices","hostname","Mac Address","Model","OEM S/N","Version"));

			foreach($data as $row) {
					$modelObj = $appObj->getModelFromJson($row['model_value']);
					$model = $modelObj->modelshow;
					$temp = array($row['DeviceID'],
						$row['DeviceName'],
						$row['DeviceGroup'],
						$row['DeviceIP'],
						$row['Active'],
						($row['dns_name']=="")?"-":$row['dns_name'],
						$row['airplay_name'],
						$row['airplay_max_no'],
						$row['hostname'],
						$row['MacAddress'],
						($model=="")?"":$model,
						$row['field1'],
						($row['Version']==-1)?"":$row['Version'],
					);
					$jsonData[$idx ++] = $temp;
			}

			foreach($jsonData as $column) {
					fputcsv($output, $column);
			}
			exit();
		}
        
        public function getGwayIdSettingAction(){
			$appObj = new ApplicationController();
			$sql=$appObj->returnQueryData("SELECT field4 FROM settings ORDER BY id DESC LIMIT 1");
			if($sql->count()>0){ 
				 $data = $sql->current();
				 $gwayIdVal=$data['field4'];
			 }
			 $gwayIdVal=($gwayIdVal=='')?0:$gwayIdVal;
			 echo $gwayIdVal;die;
		}
		
		public function autoGenerateGwayIdAction(){
			$appObj = new ApplicationController();
			$did_query="SELECT MAX(CONVERT(DeviceID, SIGNED)) AS DeviceID FROM DeviceInventory";
			$result = $appObj->returnQueryData($did_query);
			$rowCount = $result->current();
			$newGatewayId = $rowCount['DeviceID']+1;
			echo $newGatewayId;die;
		}
        
        public function importGatewayAction(){
            $request = $this->getRequest();
            $appObj = new ApplicationController();
            if($request->getPost('importPollsBtn')!='') {
                $fileArray = $this->params()->fromFiles('csvfile');
                if(is_uploaded_file($fileArray['tmp_name'])){
                    $ext=strrchr($fileArray['name'], '.');
                    if(strtolower($ext) != '.csv'){
                        die("File type unsupported. Please upload csv file.");
                    }
                    $target = BASE_PATH."/public/uploads/";
                    $adapter = new Http();
                    $adapter->setDestination($target);
                    $adapter->addFilter('File\Rename',array('target' => $adapter->getDestination().'/'.basename($fileArray['name']),'overwrite' => true));

                    if ($adapter->receive($fileArray['name'])) {
                            $return_array['success'] = $fileArray['name'];
                    }else{
                        die('could not copy file');
                    }
                    		
                    $fp=fopen($target.'/'.basename($fileArray['name']), "r");
                    if(!$fp){
                        die('Error in opening file.');
                    }
                    // read the first line and check header format
                    $header=fgetcsv($fp);
                    if(count($header)!=8){
                        $invalidCsv='true';
                    }
                    if(!empty($invalidCsv)){ 
                        echo"<script language='javascript'>alert('CSV file format is not correct. Please try with correct file.');window.location.href='../gateways';</script>";  die;    
                    }
                    $i=0;
                    $session = new Container('userinfo');
                    $name = $session->offsetGet('LoginName');
                    $hostname=$_SERVER['REMOTE_ADDR'];
                    if(GET_OS=="WIN"){
						$check_gwayCounterFile=file_exists(BASE_PATH.'/configs/loglc.txt')?$appObj->desDecrypt($appObj->file_read(BASE_PATH.'/configs/loglc.txt'), KEY_SEED):0;	 
						$allocated_devices=$check_gwayCounterFile;//$numberOfUnits;
						//$allocated_devices=$appObj->getActivateDevicesLicenseData();
					}else{
						//change code for allocated units. now we are using databse
						$allocated_devices=$appObj->getActivateDevicesLicenseData();
						//end					
					}
                    //$allocated_devices=200;    
                }
				$allocated_devices =($allocated_devices == '')?0:$allocated_devices;
				//check the license of gateway
				$numSql=$this->getDeviceInventoryTable()->fetchAll();	
				$getTotal= $numSql->count();
				
				/* Added by ashu on 25Aug2021 for vsm 3.2 to restrict import gateways more than the allocated  */				
				$countCSV_Records=count(file($target.'/'.basename($fileArray['name'])))-1;	
				$csv_and_db_count=(int)($countCSV_Records+$getTotal);
				$remaining_devices_balance=$allocated_devices-$getTotal;
				//die("allocated=".$allocated_devices." and db=".$getTotal." and Balance=".$remaining_devices_balance." and csvanddb=".$csv_and_db_count);
				/* End restrict import gateways more than then the allocated  */			
				
                if($allocated_devices>0  && $remaining_devices_balance>=$countCSV_Records){
					$connection = $appObj->getConnection();
                    while(($data = fgetcsv($fp, 1000, ",")) !== false)
                    {
                        if($getTotal>=$allocated_devices){
                            $deviceExceed="DeviceExceed";
                        }else{	
                            if(!empty($data[0]) && !empty($data[1]) && !empty($data[2]) && $data[5]!=''){
                                if(is_numeric($data[0]) && strlen($data[0])< 11 && $data[0][0] != 0 ){
                                    $aValid = array('-'); 
                                        if(ctype_alnum(str_replace($aValid, '', $data[1])) &&  !preg_match('/\s/',$data[1])) {
                                            if(!preg_match("/[^[:alnum:]\-_\s]/",$data[2]) && ltrim($data[2]) == $data[2]){	 
                                                if((empty($data[5]) || $data[5]==0) || (is_numeric($data[5]) && $data[5]>=0 && $data[5]<=12)){
                                                    $dnsValid=array('-'," ","."); 
                                                    if(ctype_alnum(str_replace($dnsValid, '', $data[3])) || $data[3]=="" ){
                                                        $deviceNameCond = array('DeviceName'=>$data[1]);
                                                        $qry12 = $this->getDeviceInventoryTable()->getData($deviceNameCond);
                                                        if($qry12->count()==0){
                                                            $deviceIdCond = array('DeviceID'=>$data[0]);
                                                            $qry14 = $this->getDeviceInventoryTable()->getData($deviceIdCond);
                                                            if($qry14->count()==0){
																$selGroupData=$this->getDevicegroupTable()->getGroup(array('DeviceGroup'=>$data[2]));
                                                                $selGroupDataCount=$selGroupData->count();
                                                                if($selGroupDataCount==0){
                                                                	$grpNameArr = array('DeviceMasterID'=>0,'DeviceGroup'=>$data[2],'Comments'=>'VIA');
																	$lastpicid = $this->getDevicegroupTable()->insertGroup($grpNameArr);
                                                                    $connection->execute("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType)values (1,$lastpicid,0)");
                                                                    $connection->execute("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type,modifydatetime)values (1,$lastpicid,0,0,'".date('Y-m-d H:i:s')."')");
                                                                }
                                                                $selGroupData=$this->getDevicegroupTable()->getGroup(array('DeviceGroup'=>$data[2]));
                                                                $selGroupDataCount=$selGroupData->count();
                                                                    if($selGroupDataCount>0){
                                                                        $rowdata=$selGroupData->current();
                                                                        $groupId=$rowdata->DeviceGroupID;
                                                                        $gatewayIP='DHCP';
                                                                        $dhcp="Y";
                                                                        //valid and duplicate mac Address Check	 
                                                                        if($data[7]=='' || !filter_var($data[7], FILTER_VALIDATE_MAC) === false || strlen(preg_replace('/[^A-Fa-f0-9]/', '', $data[7])) == 12){
                                                                             //die('mac addres is ok');
                                                                            $checkMacAddrData=0;
                                                                            if($data[7]!=''){
                                                                                $macAddr=preg_replace('/[^A-Fa-f0-9]/', '', $data[7]);
                                                                                $chunks = str_split($macAddr, 2);
                                                                                $validMacAddr = implode(':', $chunks);
                                                                                $MACAddrCond = array('MacAddress'=>$validMacAddr);
                                                                                $checkMacAddrData = $this->getDeviceInventoryTable()->getData($MACAddrCond);
                                                                            }													
                                                                            if($checkMacAddrData==0 || count($checkMacAddrData)==0){
                                                                                if(empty($data[7])){
                                                                                    $data[7]="";
                                                                                    $validMacAddr="";
                                                                                }

                                                                                //insert into DeviceInventory														 
                                                                                $insertArr = array(
                                                                                    'DeviceName' => $data[1],
                                                                                    'DeviceIP' => $gatewayIP,
                                                                                    'hostname' => $data[6],
                                                                                    'UserName' => $name,
                                                                                    'hostname' => $hostname,
                                                                                    'modifydate' => date('Y-m-d H:i:s'),
                                                                                    'DeviceGroupID' => $groupId,
                                                                                    'Active' => $dhcp,
                                                                                    'DeviceID' => $data[0],
                                                                                    'MacAddress' => $validMacAddr,
                                                                                    'global_sync_status' => 0
                                                                                );
                                                                                $last_insert_id = $this->getDeviceInventoryTable()->insertAndGetId($insertArr);
                                                                                 // insert into tbl_device_extra_info
                                                                                if(empty($data[4])){
                                                                                        $data[4]="";
                                                                                }
                                                                                if(empty($data[5]) || $data[5]==0){
                                                                                        $data[5]=1;
                                                                                }
																				$str2=$connection->execute("INSERT INTO tbl_device_extra_info SET deviceID_Fk=$last_insert_id ,airplay_name='".$data[4]."' ,airplay_max_no='".$data[5]."'");
																				if($data[3]!=''){
																					$this->getDeviceDnsnameTable()->insert(array('DID_Fk'=>$last_insert_id,'dns_name'=>$data[3]));
                                                                                }
                                                                                //insert into tbl_sys_report
                                                                                $qry3=$connection->execute("insert into  tbl_sys_report(did_fk,wallpaper_status,clientFeaturesStatus,configSettingStatus,dateTimeSettingStatus,authSettingStatus,mobileFeaturesStatus,Last_Updated_Time) values($last_insert_id,0,0,0,0,0,0,'".date('Y-m-d H:i:s')."')");
                                                                                //insert into tbl_advance_sys_report										 
                                                                                $qry4=$connection->execute("insert into tbl_advance_sys_report(did_fk,advanceConfigStatus,Last_Updated_Time) values($last_insert_id,0,NOW())");
                                                                                //insert into tbl_device_live_status
                                                                                $qry44=$connection->execute("insert into tbl_device_live_status(did_fk,last_updated_time) values($last_insert_id,NOW())");

                                                                                //insert into ActivityLogMaster
                                                                                $appObj->ActivityLog('Create',"");
                                                                                 
                                                                                $success ="Success";

                                                                            }else{
                                                                                $getMacAddrErr1 .=$data[1].",";
                                                                            }//end macaddress duplicate value
                                                                        }else{
                                                                            $getMacAddrErr2 .=$data[1].",";
                                                                        } //end valid macaddress
                                                                    }else{
                                                                        $grpNameErr .=$data[2].",";
                                                                    }
                                                            }else{
                                                                $gwayDeviceidExistArr .=$data[0].",";
                                                            }
                                                        }else{
                                                            $gwayExistArr .=$data[1].",";
                                                        }                 
                                                    }else{
                                                        $dnsNameErr .=$data[3].",";
                                                    }
                                                }else{
                                                    $mirrorErr .=$data[5].",";
                                                }		 
                                            } else{
                                                $grpErr .=$data[2].",";
                                            }
                                        }else{
                                            $gwayNameErr .=$data[1].",";
                                        } 
                                    }else{
                                        $gwayIdFormatErr =$data[1].",";
                                    }
                                }else{
                                    $emptyErr .=$data[0]."/".$data[1]."/".$data[2]."/".$data[5].",";
                                }
                        }
                    }
					$connection->disconnect();
				}else{
					$insufficientDevicesErr="insufficientDevices";	
				}
        		        
                return new ViewModel(array(
                    'invalidCsv'=>$invalidCsv,
                    'getTotal' => $getTotal,
                    'allocated_devices' => $allocated_devices,
                    'invalidCsvError' => $invalidCsvError,
                    'emptyErr' => $emptyErr,
                    'importErr1'=>$importErr1,
                    'gwayIdFormatErr'=>$gwayIdFormatErr,
                    'importErr2'=>$importErr2,
                    'gwayNameErr'=>$gwayNameErr,
                    'importErr3'=>$importErr3,
                    'gwayIpErr'=>$gwayIpErr,
                    'importErr4'=>$importErr4,
                    'dnsNameErr'=>$dnsNameErr,
                    'importErr5'=>$importErr5,
                    'grpNameErr'=>$grpNameErr,
                    'importErr6'=>$importErr6,
                    'gwayExistArr'=>$gwayExistArr,
                    'importErr7'=>$importErr7,
                    'grpErr'=>$grpErr,
                    'importErr8'=>$importErr8,
                    'gwayDeviceidExistArr'=>$gwayDeviceidExistArr,
                    'importErr9'=>$importErr9,
                    'mirrorErr'=>$mirrorErr,
                    'getMacAddrErr1'=>$getMacAddrErr1,
                    'getMacAddrErr2'=>$getMacAddrErr2,
                    'success'=>$success,
                    'deviceExceed'=>$deviceExceed,
					'insufficientDevicesErr'=>$insufficientDevicesErr,
					'remaining_devices_balance'=>$remaining_devices_balance,
                ));
            }
        }

		public function getDssInfoTable() {
			if(!$this->TblDssInfoTable) {
				$sm = $this->getServiceLocator();
				$this->TblDssInfoTable = $sm->get('Webapp\Model\TblDssInfoTable');
			}
			return $this->TblDssInfoTable;
		}

		public function getDssLicenseMasterTable() {
			if(!$this->TblDssLicenseMasterTable) {
	            $sm = $this->getServiceLocator();
	            $this->TblDssLicenseMasterTable = $sm->get('Webapp\Model\TblDssLicenseMasterTable');
	        }
       		return $this->TblDssLicenseMasterTable;
		}

        
        public function deleteGatewaysAction(){
            $session = new Container('userinfo');
            $user = $session->offsetGet('LoginName');	
            $hostname=$_SERVER['REMOTE_ADDR'];
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $chkedbox = trim($request->getPost('checkedBox'));
                $arr=explode(",",$chkedbox);
                $searchVal=json_encode(unserialize(base64_decode(trim($request->getPost('search')))));
				//added by ashu on 12Feb22 for 3.3 to delete entry when gateway is deleted
				$macAddressList='';
				$getMacAddressSql = $appObj->returnQueryData("SELECT MacAddress from deviceinventory WHERE DID IN ($chkedbox)");
				foreach($getMacAddressSql as $macAddrValue){
					$macAddressList.='"'.$macAddrValue['MacAddress'].'"'.',';
				}
				$macAddressList=substr($macAddressList,0,-1);								
				$appObj->executeQueries("DELETE FROM tbl_mac_address_sync WHERE mac_address IN($macAddressList)");
				//End tbl_mac_address_sync delete
				
                foreach($arr as $key=>$val){
                    // query for log table
                    $whereArr = array('DID' => $val);
                    $gateway_arr = $this->getDeviceInventoryTable()->getData($whereArr)->current();
                    $getDel_gateway=$gateway_arr->DeviceName;
                    $this->getDeviceInventoryTable()->deleteDeviceInventory($whereArr);  
                    if($getDel_gateway!=""){
                        $appObj->ActivityLogVSM(5,"Device $getDel_gateway deleted",3);
                    }	
                } 
                //added on 5 Oct16 for deleting advance settings from tbl_advance_sys_report
                $appObj->executeQueries("DELETE FROM tbl_advance_sys_report WHERE did_fk IN($chkedbox)");	
                $appObj->executeQueries("DELETE FROM tbl_device_extra_info WHERE deviceID_Fk IN($chkedbox)");
                $appObj->executeQueries("DELETE FROM tbl_sys_report WHERE did_fk IN($chkedbox)");
                $appObj->executeQueries("DELETE FROM tbl_device_dnsname WHERE DID_Fk IN($chkedbox)");	
                /* code for update existing group setting on new delete a gateway*********** */
				/* Now below tables are not using  due to settings template. so commenting **************** */              
				/*$checkQry1=$appObj->returnQueryData("SELECT * FROM tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry1->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }	
                $checkQry2=$appObj->returnQueryData("SELECT * FROM tbl_clients_features_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry2->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_clients_features_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }	
                $checkQry3=$appObj->returnQueryData("SELECT * FROM tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry3->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry4=$appObj->returnQueryData("SELECT * FROM tbl_configuration_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry4->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_configuration_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry5=$appObj->returnQueryData("SELECT * FROM tbl_adsettings_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry5->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_adsettings_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry6=$appObj->returnQueryData("SELECT * FROM tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry6->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                //Added on 20-July-2017
                $checkQry8=$appObj->returnQueryData("SELECT * FROM tbl_display_settings_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry8->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_display_settings_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry9=$appObj->returnQueryData("SELECT * FROM tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry9->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry10=$appObj->returnQueryData("SELECT * FROM tbl_auth_fileformat_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry10->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_auth_fileformat_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry11=$appObj->returnQueryData("SELECT * FROM tbl_advance_configuration_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry11->count()>0){
					$appObj->executeQueries("DELETE FROM tbl_advance_configuration_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $checkQry12=$appObj->returnQueryData("SELECT * FROM gateway_customize_homepage_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry12->count()>0){
					$appObj->executeQueries("DELETE FROM gateway_customize_homepage_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }
				*/
				/* ***************** End ***************************** */
				
                $checkQry13=$appObj->returnQueryData("SELECT * FROM AutoUpdateDone WHERE deviceID_Fk IN($chkedbox)");
                if($checkQry13->count()>0){
					$appObj->executeQueries("DELETE FROM AutoUpdateDone WHERE deviceID_Fk IN($chkedbox)");
                }

                $checkQry14=$appObj->returnQueryData("SELECT event_id FROM events_detail WHERE deviceId_fk IN($chkedbox)");
                if($checkQry14->count()>0){
					$appObj->executeQueries("DELETE FROM events_detail WHERE deviceId_fk IN($chkedbox)");
					$eventId=$checkQry14->current()->event_id;
					$appObj->executeQueries("DELETE FROM events WHERE event_id=$eventId");
                }
                
                //delete from tbl_registration_status
                 $appObj->executeQueries("DELETE FROM tbl_registration_status WHERE DID IN($chkedbox)");
                //delete from calendar relation table
                 $appObj->executeQueries("DELETE FROM tbl_gway_cal_relation WHERE device_id IN($chkedbox)");
                //2.6 changes
                $checkQry15=$appObj->returnQueryData("SELECT * FROM tbl_proxy_setting_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry15->count()>0){
                        $appObj->executeQueries("DELETE FROM tbl_proxy_setting_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }
                $checkQry16=$appObj->returnQueryData("SELECT * FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                if($checkQry16->count()>0){
                        $appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId IN($chkedbox) AND entryType=1");
                }

                $appObj->executeQueries("DELETE FROM tbl_device_live_status WHERE did_fk IN($chkedbox)");
				//Delete recording files
				$recordingFilesSql = $appObj->returnQueryData("SELECT filename FROM recordingchild WHERE reserved1 IN ($chkedbox)");				
				foreach($recordingFilesSql as $recordingFilesValue){
					$recording_file_url=RECORDING_PATH.'/'.$recordingFilesValue['filename'];
					if(file_exists($recording_file_url)){
						unlink($recording_file_url);
					}
					
				}		
				//Delete recording entries		
				$appObj->executeQueries("DELETE FROM recordingchild WHERE reserved1 IN($chkedbox)");
				$appObj->executeQueries("DELETE FROM recordingmaster WHERE reserved1 IN($chkedbox)");
                /* *************** End ************** */

				/* *************************************Delete cloud license. execute on cloud vsm****************** */
				//getting active gateways uniqueIds
				if(GET_OS=="LIN" && PRODUCT_TYPE=='vsm'){
					$licenseQryData=$appObj->returnQueryData("SELECT * FROM license_used WHERE did IN($chkedbox) AND expiry_date >CURRENT_DATE()");	
					$deletedDevices = count($licenseQryData);
					if($licenseQryData->count()>0){
						$lic_uniqueIds='(';
						foreach($licenseQryData as $licenseQryDataArr){
							$lic_uniqueIds.='"'.$licenseQryDataArr['uniqueid'].'"'.',';
						}
						$lic_uniqueIds=substr($lic_uniqueIds,0,-1).')';	
						$appObj->executeQueries("DELETE FROM license_used WHERE did IN($chkedbox) AND expiry_date >CURRENT_DATE()");
						//decreament license used counter in license_master						
						$appObj->executeQueries("UPDATE license_master set number_of_lic_used=(number_of_lic_used-$deletedDevices) WHERE uniqueid IN $lic_uniqueIds");				
					}
				}
				//End cloud license delete system
				
				/* *************************************Delete dss license. ****************** */

				$tableDssInfoData = $this->getDssInfoTable();
				$tableDssLicenseMaster = $this->getDssLicenseMasterTable();
				// fetch all the gateways that is going to delete from dss_file_Auth table
				$allDssFileAuth = $tableDssInfoData->getAllDataDssFileAuth($chkedbox);
				$uniqueKeyWithDid = [];

				foreach($allDssFileAuth as $resultSetValue) {
					$resultSetJson = json_encode($resultSetValue);
					$resultSet = json_decode($resultSetJson, true);
					// make an array as per the unique key to get the total number of devices licese issued for that unique key
					$uniqueKeyWithDid[$resultSet["unique_id"]][] = $resultSet["DID"];
				}

				foreach($uniqueKeyWithDid as $key => $value) {
					$searchFilter = array("uniqueId" => $key);
					// fetch total number of license issued for the unique key
					$licenseUsedData = $tableDssLicenseMaster->getNumLicenseUsed($searchFilter);
					foreach($licenseUsedData as $row) {
						$resultSetJson = json_encode($row);
						$resultSet = json_decode($resultSetJson, true);
					}
					$numLicenseUsedUpdate = $resultSet["num_of_lic_used"] - count($value);
					// delete the number of license of the device deleting from the total number of license used.
					$dataUpdate = array("numLicenseUsed" => $numLicenseUsedUpdate, "uniqueId" => $key);
					$tableDssLicenseMaster->updateNumLicenseUsed($dataUpdate);
				}
				// deleting the entry of devices from the dss_file_auth table.
				$tableDssInfoData->deleteDeviceRecordForLicense($chkedbox);

				// $dsslicenseQryData=$appObj->returnQueryData("SELECT * FROM dss_file_auth WHERE DID IN($chkedbox) AND expiry_date >CURRENT_DATE()");	
				// if($dsslicenseQryData->count()>0){
				// 	$dsslic_uniqueIds='(';
				// 	foreach($dsslicenseQryData as $dsslicenseQryDataArr){
				// 		$dsslic_uniqueIds.='"'.$dsslicenseQryDataArr['unique_id'].'"'.',';
				// 	}
				// 	$dsslic_uniqueIds=substr($dsslic_uniqueIds,0,-1).')';	
				// 	$appObj->executeQueries("DELETE FROM dss_file_auth WHERE DID IN($chkedbox) AND expiry_date >CURRENT_DATE()");
				// 	//decreament license used counter in dss_license_master						
				// 	$appObj->executeQueries("UPDATE dss_license_master set num_of_lic_used=(num_of_lic_used-1) WHERE unique_id IN $dsslic_uniqueIds");				
				// }



				//End dss license delete system

               	$qryResult = $appObj->returnQueryData("SELECT * FROM DeviceInventory");	
                $total = $qryResult->count();
                //echo $msg."#".$total."#"."DeviceInventoryList.php";
                echo $searchVal;die;
            }
        }
        
        public function addGatewayAction(){
            $session = new Container('userinfo');
            $user = $session->offsetGet('LoginName');
            $userid = $session->offsetGet('usrid');
            $hostname=$_SERVER['REMOTE_ADDR'];
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $dhcp='Y';
                $gwayID = htmlspecialchars(trim($request->getPost('gwayID')));
                $gatewayName = htmlspecialchars(trim($request->getPost('gatewayName')));
                $ddGrpID = htmlspecialchars(trim($request->getPost('ddGrpName')));
                $gatewayIP = htmlspecialchars(trim($request->getPost('gatewayIP')));
                $dnsName=htmlspecialchars(trim($request->getPost('dnsName')));
                $airMirrorName=htmlspecialchars(trim($request->getPost('airMirrorName')));
                $airMirrorMaxNo=(trim($request->getPost('airMirrorMaxNo'))!='')?trim($request->getPost('airMirrorMaxNo')):0;
                $mcAddress = htmlspecialchars(trim($request->getPost('mcAddress')));
                if($userid !=1){
                    $getMenusResponse=$appObj->returnQueryData("SELECT * FROM tbl_user_access WHERE group_id_fk=$ddGrpID AND user_id_fk = $userid");
                    if($getMenusResponse->count() == 0){
                        echo "You are not allowed to add VIA to this group. Please contact administrator to give you permission to manage this group.";die;
                    }
                }
                //for alert setting
                if(trim($request->getPost('alertType')) !="" ){
                    $alert=1;
                }else{
                    $alert=0;
                }
                $gatewayRemarks=$appObj->strip_xss(trim($request->getPost('gatewayRemarks')));
				$remarks=$appObj->strip_xss(trim($request->getPost('remarks')));
                $isChecked=(trim($request->getPost('setForAll'))==1)?trim($request->getPost('setForAll')):0;
                $file_exist_check=(file_exists(DEST_PATH.FILE_GWAY_AUTHENTICATION))?1:0;
                if(GET_OS=="WIN"){
					$check_gwayCounterFile=file_exists(BASE_PATH.'/configs/loglc.txt')?$appObj->desDecrypt($appObj->file_read(BASE_PATH.'/configs/loglc.txt'), KEY_SEED):0;	
					$allocated_devices=$check_gwayCounterFile;//$numberOfUnits;	
					//$allocated_devices=$appObj->getActivateDevicesLicenseData();
				}else{
					//change code for allocated units. now we are using databse
					$allocated_devices=$appObj->getActivateDevicesLicenseData();
					//end				
				}
                //$allocated_devices=200;
				
                if($allocated_devices>0){
                    $numSql=$appObj->returnQueryData("SELECT * from DeviceInventory");	
                    $getTotal= $numSql->count();
                    if($getTotal>=$allocated_devices){
                            echo"DeviceExceed";
                            exit;
                    }else{
                        $flag=0;
                     
                        /* *************** End Time compare check **************** */
                        $qry1=$appObj->returnQueryData("SELECT * from DeviceInventory  where DeviceName ='$gatewayName'");
                        if($qry1->count()>0){
                            $flag=1; //gatewayExists

                        }
                        
                        $gwayIDExistQry=$appObj->returnQueryData("SELECT * from DeviceInventory  where DeviceID='$gwayID'");
                        if($gwayIDExistQry->count()>0){
                            $flag=3; //IPExists
                        }

                        if($flag==1){
                            echo "gatewayExists";
                            exit;
                        }
                        if($flag==2){
                            echo "IPExists";
                            exit;
                        }
                        if($flag==3){
                            echo "gwayIDExists";
                            exit;
                        }
                        // check for duplicate DNS	
                        if($dnsName!=''){
							$getDnsSql=$this->getDeviceDnsnameTable()->getData(array('dns_name'=>$dnsName));
                            if($getDnsSql->count()>0){
                                echo 'dnsexist';
                                exit;
                            }	
                        }

                        // check for duplicate Mac Address	
                        if($mcAddress!=''){
                            $getmacAddrSql=$appObj->returnQueryData("SELECT * FROM DeviceInventory WHERE MacAddress='$mcAddress'");
                            if($getmacAddrSql->count()>0){
                                echo 'macAddrExist';
                                exit;
                            }	
                        }			

                        // check mirrorname	
                        if($airMirrorName!=''){
                                $getMirroringSql=$appObj->returnQueryData("SELECT * FROM tbl_device_extra_info WHERE airplay_name='$airMirrorName'");
                                if($getMirroringSql->count()>0){
                                    echo 'mirroringexist';
                                    exit;
                                }	
                        }			

                        if($flag==0){
                        /* ********* check value from AD Setting Table ********** */
                                $adSettingSql=$appObj->returnQueryData('SELECT activate_presentation_mode, authentication_mode FROM tbl_ADSettings');
                                $countRecord = $adSettingSql->count();	
                                if($countRecord==0){
                                    $presentation_mode=0;
                                    $authentication_mode=0;
                                }else{
                                    foreach($adSettingSql as $rowData){
                                        $presentation_mode=$rowData['activate_presentation_mode'];
                                        $authentication_mode=$rowData['authentication_mode'];
                                    }
                                }

                                /* ********* nd AD setting check *************** */	
                                $insertArr = array(
                                    'DeviceName' => $gatewayName,
                                    'DeviceIP' => 'DHCP',
                                    //'remarks' => $gatewayRemarks,
									'remarks' => $remarks,
                                    'UserName' => $user,
                                    'hostname' => $hostname,
                                    'modifydate' => date('Y-m-d H:i:s'),
                                    'DeviceGroupID' => $ddGrpID,
                                    'Active' => $dhcp,
                                    'DeviceID' => $gwayID,
                                    'MacAddress' => $mcAddress,
                                    'global_sync_status' => 0
                                );
                                $last_insert_id = $this->getDeviceInventoryTable()->insertAndGetId($insertArr);
                                
                                // added on 5Oct16 for entry in tbl_device_extra_info	
                                $appObj->executeQueries("INSERT INTO tbl_device_extra_info SET deviceID_Fk=$last_insert_id ,airplay_name='$airMirrorName' ,airplay_max_no='$airMirrorMaxNo'");

                                // added on 2Jun16 for dns entry
                                if($dnsName!=''){
									$this->getDeviceDnsnameTable()->insert(array('DID_Fk'=>$last_insert_id, 'dns_name'=>$dnsName));
                                } else if($dnsName == '') { // added by anuj 24-2-23
                                	$this->getDeviceDnsnameTable()->insert(array('DID_Fk' => $last_insert_id, 'dns_name' => $gatewayName));
                                }

                                // update above table DeviceID field 
                                if($dhcp=='Y'){
                                    $updIP=$appObj->executeQueries("update DeviceInventory set DeviceIP='DHCP' WHERE DID=$last_insert_id");
                                }
                                $appObj->ActivityLogVSM(3,"Add Device $gatewayName",3);
                                
                                $qry7=$appObj->executeQueries("insert into  tbl_sys_report(did_Fk,wallpaper_status,clientFeaturesStatus,configSettingStatus,dateTimeSettingStatus,authSettingStatus,mobileFeaturesStatus,Last_Updated_Time) values($last_insert_id,0,0,0,0,0,0,'".date('Y-m-d H:i:s')."')");			
                                $qry8=$appObj->executeQueries("insert into tbl_advance_sys_report(did_Fk,advanceConfigStatus,Last_Updated_Time) values($last_insert_id,0,NOW())");	
                                $qry11=$appObj->executeQueries("insert into tbl_device_live_status(did_Fk,last_updated_time) values($last_insert_id,NOW())");

                                // for alert setting start
                                if($alert==1){
                                    $resultData = $appObj->returnQueryData("SELECT DISTINCT(alert_id_fk) FROM tbl_alert_mapping WHERE group_id_fk=$ddGrpID");
                                    if($resultData->count()>0){
                                           $sql_query="INSERT INTO tbl_alert_mapping(alert_id_fk,user_id_fk,group_id_fk,device_id_fk)values ";
                                           $value_array=array();
                                           foreach($resultData as $alertData){
                                                $alert_id=$alertData['alert_id_fk'];
                                                $value_array[] = "('$alert_id', '$userid','$ddGrpID','$last_insert_id')";
                                            }
                                            $sql_query .= implode(',', $value_array);
                                             $appObj->executeQueries($sql_query);
                                    }
                                }
                                echo 'success';die;
                        } 

                        /* *************** End Gateway/IP exist check**************************************** */
                    }
                }else{
                    echo"noDeviceAllocatedNumber";
                    exit;
                }
            }
            
        }
        
        public function getDataAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $gatewayID = trim($request->getPost('did'));
                $sql=$appObj->returnQueryData("SELECT * FROM DeviceInventory WHERE DID=$gatewayID");
                if($sql->count()>0){
                        $data = $sql->current();
                        $gwayDeviceID=$data['DeviceID'];			
                        $gatewayName=$data['DeviceName'];
                        $gatewayIP=($data['DeviceIP']!='DHCP'?$data['DeviceIP']:'');
                        $gatewayStartTime=$data['StartTime'];
                        $gatewayEndTime=$data['EndTime'];			
                        $gatewayRemarks=$data['remarks'];
                        $gateWayGrpID=$data['DeviceGroupID'];
                        $isDHCP=$data['Active'];
                        list($startHours,$startMins,$startSec)=explode(":",$gatewayStartTime);
                        list($endHours,$endMins,$endSec)=explode(":",$gatewayEndTime);
                        $startAMPM=($startHours<=12)?'AM':'PM';
                        $endAMPM=($endHours<=12)?'AM':'PM';
                        $startHours=($startHours>12)?$startHours-12:$startHours;
                        $endHours=($endHours>12)?$endHours-12:$endHours;
                        $DeviceMasterID=$data['DeviceGroupID'];
                        $getMcAddress=$data['MacAddress'];    
                }
                //added on 30Jan2018 to make sure all  default entries for a gateway exists on default tables.
                $this->checkDefaultDbGway($gatewayID,$data['os_type']);

                $sqlExtraInfo=$appObj->returnQueryData("SELECT * FROM tbl_device_extra_info WHERE deviceID_Fk=$gatewayID");	
                if($sqlExtraInfo->count()>0){
                    $dataExtra = $sqlExtraInfo->current();
                    $airplay_name=$dataExtra['airplay_name'];			
                    $airplay_max_no=$dataExtra['airplay_max_no'];
                    $data['airplay_name'] = $airplay_name;
                    $data['airplay_max_no'] = $airplay_max_no;
					//Adding by Ashu on 16Feb23 for enable/disable DNS Name inpput filed based on Network Code
					$data['via_network_code'] = $dataExtra['network_code'];
                }
                
				$dnsQry=$this->getDeviceDnsnameTable()->getData(array('DID_Fk'=>$gatewayID));
                if($dnsQry->count()>0){
					$dnsRow=$dnsQry->current();
					$dnsName=$dnsRow['dns_name'];
					$data['dns_name'] = $dnsName;
                }
                
                //check autoboarding
                $autoBoardingQry = $appObj->returnQueryData("SELECT * FROM tbl_auto_discover_status");
                if($autoBoardingQry->count()>0){
					$autoBoardingRow=$autoBoardingQry->current();
					$autoBoarding = $autoBoardingRow['isactive'];
					$data['isactive'] = $autoBoarding;
                }
                echo json_encode($data);die;
                
            }
        }
        
        public function checkDefaultDbGway($gatewayID,$os_type){
            $appObj = new ApplicationController();
            $chkqry1=$appObj->returnQueryData("SELECT * FROM tbl_device_extra_info WHERE deviceID_Fk=$gatewayID");
            if($chkqry1->count()==0){
                    //updated on 9March2018 for updating max connection(based on model type)
                    $getMirrorNameStr=$appObj->getDnsNameById($gatewayID);	
                    if($getMirrorNameStr==''){
						$checkDnsQry11=$appObj->returnQueryData("SELECT DeviceName FROM DeviceInventory WHERE DID=$gatewayID");
						$getMirrorNameArr=$checkDnsQry11->current();
						$getMirrorNameStr=$getMirrorNameArr['DeviceName'];
                    }
					$modelObj = $appObj->getModelFromJson($os_type);
					$modelType = $modelObj->modellike;
                    if($modelType==0 || $modelType==2){
                            $maxCon=4;
                    }
                    if($modelType==1 || $modelType==4){
                            $maxCon=2;
                    }
                    if($modelType==3){
                            $maxCon=1;
                    }
                    //end
                    $appObj->executeQueries("INSERT INTO tbl_device_extra_info(deviceID_Fk,airplay_name,airplay_max_no) values ($gatewayID,'$getMirrorNameStr',$maxCon)");	
            }

            //checking tbl_sys_report
            $chkqry2=$appObj->returnQueryData("SELECT * FROM tbl_sys_report WHERE did_fk=$gatewayID");
            if($chkqry2->count()==0){
                    $appObj->executeQueries("insert into  tbl_sys_report(did_fk,wallpaper_status,clientFeaturesStatus,configSettingStatus,dateTimeSettingStatus,authSettingStatus,mobileFeaturesStatus,Last_Updated_Time) values($gatewayID,0,0,0,0,0,0,now())");			
            }

            //checking tbl_advance_sys_report
            $chkqry3=$appObj->returnQueryData("SELECT * FROM tbl_advance_sys_report WHERE did_fk=$gatewayID");
            if($chkqry3->count()==0){
                    $appObj->executeQueries("insert into tbl_advance_sys_report(did_fk,advanceConfigStatus,Last_Updated_Time) values($gatewayID,0,NOW())");
            }

            //checking if dss license exist for the gateway.
            $licenceCheckQry=$appObj->returnQueryData("SELECT * FROM dss_file_auth WHERE DID=$gatewayID");
            $get_dss_file_auth_count=$licenceCheckQry->count();
        }
        
        public function updateGatewayAction(){
            $session = new Container('userinfo');
            $name = $session->offsetGet('LoginName');
            $userid = $session->offsetGet('usrid');
            $hostname=$_SERVER['REMOTE_ADDR'];
            
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $dhcp='Y';
                $gwayDeviceID=htmlspecialchars(trim($request->getPost('gwayID')));
                $gatewayID = htmlspecialchars(trim($request->getPost('gatewayID')));
                $gatewayName = htmlspecialchars(trim($request->getPost('gatewayName')));
                $ddGrpID = htmlspecialchars(trim($request->getPost('ddGrpName')));
                $gatewayRemarks=$appObj->strip_xss(trim($request->getPost('gatewayRemarks')));
                $dnsName = htmlspecialchars(trim($request->getPost('dnsName')));
                $isChecked=(trim($request->getPost('setForAll'))==1)?trim($request->getPost('setForAll')):0;
                $airMirrorName=htmlspecialchars(trim($request->getPost('airMirrorName')));
                $airMirrorMaxNo=(trim($request->getPost('airMirrorMaxNo'))!='')?trim($request->getPost('airMirrorMaxNo')):0;
                $getMcAddress = trim($request->getPost('mcAddress'));
				$remarks = trim($request->getPost('remarks'));
                //check the user group permission(4-Apr-2019 By Dileep)
                if($userid !=1){
                    $getMenusResponse=$appObj->returnQueryData("SELECT * FROM tbl_user_access WHERE group_id_fk=$ddGrpID AND user_id_fk = $userid");
                    if($getMenusResponse->count() == 0){
                        echo "You are not allowed to add VIA to this group. Please contact administrator to give you permission to manage this group.";die;
                    }
                }
                $flag1=0;
                $flag2=0;
                $flag3=0;
                $myselQry1 = $appObj->returnQueryData("SELECT * FROM DeviceInventory WHERE DeviceName ='$gatewayName' AND DID!=$gatewayID");		
                $recount=$myselQry1->count();
                if($recount>0){
                    $flag1=1;
                }

                if($dhcp=="N"){
                    if($gatewayIP!=""){		
                        $myselQry2 = $appObj->returnQueryData("SELECT * FROM DeviceInventory WHERE DeviceIP ='$gatewayIP' AND DID!=$gatewayID");		
                        $recountIP=$myselQry2->count();
                        if($recountIP>0){
                            $flag2=1;
                        }
                    }		
                }
                $gwayIDExistQry = $appObj->returnQueryData("SELECT * FROM DeviceInventory WHERE DeviceID='$gwayDeviceID' AND DID!=$gatewayID");		
                $recountID=$gwayIDExistQry->count();
                if($recountID>0){
                    $flag3=1;
                }

                // Check for duplicate DNS		
                if($dnsName!=''){		
                    $checkDnsSql=$appObj->returnQueryData("SELECT * FROM tbl_device_dnsname WHERE DID_Fk!=$gatewayID AND dns_name='$dnsName'");	
                    if($checkDnsSql->count()>0){
                        echo 'dnsexist';
                        exit;
                    }
                } else if($dnsName == '') { // added by anuj 29-3-23
                	$appObj->executeQueries("UPDATE tbl_device_dnsname SET dns_name = '$gatewayName' WHERE DID_Fk = $gatewayID");
                }	

                // Check for duplicate Mirroring name		
                if($airMirrorName!=''){		
                    $checkMirroringSql=$appObj->returnQueryData("SELECT * FROM tbl_device_extra_info WHERE deviceID_Fk!=$gatewayID AND airplay_name='$airMirrorName'");	
                    if($checkMirroringSql->count()>0){
                        echo 'mirroringexist';
                        exit;
                    }
                }

                // check for duplicate Mac Address
                if($getMcAddress!=''){		
                    $checkMacAddrSql=$appObj->returnQueryData("SELECT * FROM DeviceInventory WHERE MacAddress='$getMcAddress' AND DID!=$gatewayID");	
                    if($checkMacAddrSql->count()>0){
                        echo 'macAddrExist';
                        exit;
                    }
                }	

                if($flag1==1 && $flag2==1 && $flag3==1){
                    echo "AllExists";
                }elseif($flag1==1 && $flag2==1 && $flag3==0){
                    echo "NameIPExists";
                }elseif($flag1==1 && $flag2==0 && $flag3==1){
                    echo "NameIDExists";
                }elseif($flag1==1 && $flag2==0 && $flag3==0){
                    echo "gatewayExists";
                }elseif($flag1==0 && $flag2==1 && $flag3==0){
                    echo "IPExists";
                }elseif($flag1==0 && $flag2==0 && $flag3==1){
                    echo "IDExists";
                }elseif($flag1==0 && $flag2==1 && $flag3==1){
                    echo "IPIDExists";
                }else{		
                    //update the tbl_sys_report table when change the gateway group.(Added on 13-Sept-2017)
                    $checkGrpExist=$this->getDeviceInventoryTable()->getData(array('DID'=>$gatewayID,'DeviceID'=>$gwayDeviceID,'DeviceGroupID'=>$ddGrpID));
                    if($checkGrpExist->count() == 0){
                        $appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0,clientFeaturesStatus=0, configSettingStatus=0,dateTimeSettingStatus=0,authSettingStatus=0,mobileFeaturesStatus=0 WHERE did_fk=$gatewayID");
                        $appObj->executeQueries("UPDATE tbl_advance_sys_report SET advanceConfigStatus=0,Last_Updated_Time=NOW() WHERE did_fk=$gatewayID");
                        $appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID=$gatewayID");
                    }		
                    //Now we have removed StartTime and EndTime form table
                    $checkDidSql=$this->getDeviceInventoryTable()->getData(array('DID'=>$gatewayID));
                    if($checkDidSql->count() > 0){
                        $deviceArr = $checkDidSql->current();
                        $deviceGrpId = $deviceArr['DeviceGroupID'];
                        $os_type = $deviceArr['os_type'];
                    }
                    // if old grp and new grp are mismatched then delete gateway entry from template_mapping
                    if($deviceGrpId!=$ddGrpID){						
                        $appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId=$gatewayID AND entryType=1");
                    }
                    
                    $str=$appObj->executeQueries("UPDATE DeviceInventory  SET DeviceName='$gatewayName' ,DeviceIP='$gatewayIP' ,remarks='$gatewayRemarks' ,UserName='$name' , hostname='$hostname', modifydate=now(), DeviceGroupID='$ddGrpID', Active='$dhcp',DeviceID='$gwayDeviceID', MacAddress='$getMcAddress',global_sync_status=0 WHERE DID=$gatewayID");
	
                    $strExtraInfo=$appObj->executeQueries("UPDATE tbl_device_extra_info  SET airplay_name='$airMirrorName' ,airplay_max_no='$airMirrorMaxNo' WHERE deviceID_Fk=$gatewayID");

					$getDnsSql=$this->getDeviceDnsnameTable()->getData(array('DID_Fk'=>$gatewayID));
                    if($getDnsSql->count()==0){
                        $this->getDeviceDnsnameTable()->insert(array('dns_name'=>$dnsName,'DID_Fk'=>$gatewayID));
                    }else if($dnsName == '') { // added by naveen 29/06/2023
                	$appObj->executeQueries("UPDATE tbl_device_dnsname SET dns_name = '$gatewayName' WHERE DID_Fk = $gatewayID");
                	}else{
                        $appObj->executeQueries("UPDATE tbl_device_dnsname SET dns_name='$dnsName' WHERE DID_Fk=$gatewayID");
                    }
                    // Update DEvice IP Table
                    //if($dhcp=='Y' && $gatewayIP==''){
                        $updIP = $appObj->executeQueries("update DeviceInventory set DeviceIP='DHCP' WHERE DID=$gatewayID");
                    //}			
					if($remarks!=''){
						$appObj->executeQueries("update DeviceInventory SET remarks='".$remarks."' where DID=$gatewayID");
					}
                    //update the the status (Added Date 4-jan-2018)
                    $appObj->executeQueries("update tbl_sys_report SET configSettingStatus=0,dateTimeSettingStatus=0,Last_Updated_Time=now() where did_fk=$gatewayID");			
                    $appObj->executeQueries("update tbl_advance_sys_report SET advanceConfigStatus=0,Last_Updated_Time=NOW() where did_fk=$gatewayID");
                    $appObj->executeQueries("update DeviceInventory SET global_sync_status=0 where DID=$gatewayID");
                    
                    $producerObject = new WebProducerController();
                    //RabbitMQ Command for wallpaper
                    $cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
					$cmdJson=json_encode($cmdArr);
					$producerObject->rabbitWebProducerAction($cmdJson);	
					//RabbitMQ Command for settings
					$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
					$cmdJson=json_encode($cmdArr);
					$producerObject->rabbitWebProducerAction($cmdJson);	
					
					//update gateway name in license_used and dss_file_auth table
					$appObj->executeQueries("UPDATE license_used SET gateway_name='$gatewayName' WHERE did='$gatewayID'");
					$appObj->executeQueries("UPDATE dss_file_auth SET gateway_name='$gatewayName' WHERE DID='$gatewayID'");
                   
                    $appObj->executeQueries("insert into ActivityLogMaster(UserID,ActionTaken,ActivityDate,remarks,hostname,moduleName) values('$name','Update', now(), '$logMsgUpdateDevice: $gatewayName', '$hostname','Devices')");	
                    echo"success";die;
                }
            }  
        }
        
        public function rebootGatewayAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $gwayIdArr=trim($request->getPost('gwayIds'));
				$deviceIdArr=trim($request->getPost('deviceIds'));
                if($gwayIdArr){
                    $gwayIdArr=explode(",",$gwayIdArr);
                    $sql_query="INSERT INTO tbl_gways_reboot(deviceID_Fk,status)values ";
                    $value_array=array();
                    $via_did = array();
                    foreach($gwayIdArr as $val){
                            $did=$val;
                            $status=1;
                            $value_array[] = "('$did', '$status')";
                            $via_did[]['device_id']=$val;
                    }
                    $sql_query .= implode(',', $value_array);
                    $appObj->executeQueries($sql_query);
					$deviceIdArr = explode(",",$deviceIdArr);
					//Rabbit MQ Code
					$cmdArr=array("cmd"=>"reboot","sender"=>"web-vsm","request_id"=>"","via_did"=>$via_did);
					$cmdJson=json_encode($cmdArr);
					$producerObject=new WebProducerController();
					$producerObject->rabbitWebProducerAction($cmdJson);
                    echo "success";die;
                }
            }    
        }
        
        public function resetGatewaySessionAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $appObj = new ApplicationController();
                $gwayIdArr=trim($request->getPost('gwayIds'));
				$deviceIdArr=trim($request->getPost('deviceIds'));
                if($gwayIdArr){
                    $gwayIdArr=explode(",",$gwayIdArr);
                    $sql_query="INSERT INTO tbl_gways_reset(deviceID_Fk,status)values ";
                    $value_array=array();
                    $via_did = array();
                    foreach($gwayIdArr as $val){
						$did=$val;
						$status=1;
						$value_array[] = "('$did', '$status')";
						$via_did[]['device_id']=$val;
                    }
                    $sql_query .= implode(',', $value_array);
					$appObj->executeQueries($sql_query);
					$deviceIdArr = explode(",",$deviceIdArr);
					
					$cmdArr=array("cmd"=>"reset","sender"=>"web-vsm","request_id"=>"","via_did"=>$via_did);
					$cmdJson=json_encode($cmdArr);
					$producerObject=new WebProducerController();
					$producerObject->rabbitWebProducerAction($cmdJson);
                    echo "success";die;
                }
            }
        }
		
		public function pushConfigOnGatewayAction(){
			$request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $gwayId = trim($request->getPost('did'));
				$serviceName=trim($request->getPost('serviceName'));
				if($gwayId != ''){
					$appObj = new ApplicationController();
					$producerObject=new WebProducerController();
					//Insert the gway id into tbl_gways_reboot
					$appObj->executeQueries("INSERT INTO tbl_gways_reboot(deviceID_Fk,status)values ('$gwayId',1)");
					if($serviceName!=''){
						switch($serviceName){
							case "wallpaper" : 
								$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0 WHERE wallpaper_status=1 AND did_fk=$gwayId");
									
								$cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
								$cmdJson=json_encode($cmdArr);
								$producerObject->rabbitWebProducerAction($cmdJson);
								break;
							case "configuration" :
								$appObj->executeQueries("UPDATE tbl_sys_report SET configSettingStatus=0 WHERE configSettingStatus=1 AND did_fk=$gwayId");
								
								$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
								$cmdJson=json_encode($cmdArr);
								$producerObject->rabbitWebProducerAction($cmdJson);
								break;						
						}
					}else{
						$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0 WHERE wallpaper_status=1 AND did_fk=$gwayId");
						$appObj->executeQueries("UPDATE tbl_sys_report SET configSettingStatus=0 WHERE configSettingStatus=1 AND did_fk=$gwayId");
                        $appObj->executeQueries("UPDATE  tbl_gway_cal_relation SET sync_status=0 WHERE sync_status=1 AND device_id = $gwayId"); 
						//push settings
						$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
						$cmdJson=json_encode($cmdArr);
						$producerObject->rabbitWebProducerAction($cmdJson);
					}
					$sysStatus = $appObj->returnQueryData("SELECT configSettingStatus,wallpaper_status FROM tbl_sys_report WHERE did_fk = $gwayId");
					$statusArr = $sysStatus->current();
					$calStatus = $appObj->returnQueryData("SELECT sync_status FROM tbl_gway_cal_relation WHERE device_id = $gwayId");
					$calStatusArr = $calStatus->current();
					
					if(($sysStatus->count() > 0 && $statusArr['configSettingStatus'] == 0 || $statusArr['wallpaper_status'] == 0) || ($calStatus->count() > 0 && $calStatusArr['sync_status'] ==0) ){
						$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID=$gwayId");
					}
					echo 1;die;
				}
			}
		}
		
		//Get Screen Editor Template list by model_type
		public function getTemplateDetailsAction(){
			$did=trim($_POST['did']);
			$appObj = new ApplicationController();
			
			//getting screen editor template which is set on group
			$getGroupsSql = $this->getDeviceInventoryTable()->getData(array('DID'=>$did));
			if($getGroupsSql->count()>0){
				$deviceDataArr = $getGroupsSql->current();
				$deviceGrpId = $deviceDataArr['DeviceGroupID'];
				
				$screenEditor_templateSql = $appObj->returnQueryData("SELECT b.id, b.template_name FROM tbl_templates_mapping a INNER JOIN tbl_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$deviceGrpId")->current();
				$screenEditor_grp_templateName = $screenEditor_templateSql['template_name'];
				$basicModeScreenTemplateId=$screenEditor_templateSql['id'];
			}
			
			//get model_type based on did
			/*$sysReportQry=$appObj->returnQueryData("SELECT model_type FROM tbl_sys_report WHERE did_fk=$did");
			if($sysReportQry->count()>0){
				$syeReportRow=$sysReportQry->current();
				$model_type = $syeReportRow['model_type'];
			}*/
			$model_type=PRODUCT_MODEL_TYPE;			
			$condition=array('model_type'=>$model_type);
			$screenEditordata=$this->getTemplatesTable()->getData($condition);
			//get selected template
			$templateSql = $appObj->returnQueryData("SELECT b.id, b.template_name FROM tbl_templates_mapping a INNER JOIN tbl_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$did AND entryType=1")->current();			
			$screen_templateId = $templateSql['id'];
			$screen_template_name = $templateSql['template_name'];
			
			//getting templateid. Advanced mode template id is priority than basic mode
			$getScreenTemplayteId=($templateSql['id']!='')?$templateSql['id']:$basicModeScreenTemplateId;
			
			$str='<section class="">';
			$str.='<div class="panel-body">';
			
			$str.='<div class="row" style="padding-left:20px;">'.STR_ADVANCED_MODE_Screen_Txt1.'</div>';
			$str.='<div class="row" style="height:20px">&nbsp;</div>';
			$str.='<div class="row" style="padding-left:20px;">'.STR_ADVANCED_MODE_Screen_Txt2.'</div>';
			$str.='<div class="row" style="height:20px">&nbsp;</div>';
			
			$str.='<div id="advancedMode_roundborder">';
			if($screen_templateId!=''){
				$str.='<p><strong>'.STR_ADVANCED_MODE_Screen_Txt3.'</strong>:&nbsp;&nbsp;'.$screen_template_name.'</p>';
			}
			$str.='<p><strong>'.STR_ADVANCED_MODE_Screen_Txt4.':&nbsp;&nbsp;</strong>'.$screenEditor_grp_templateName.'</p>';
			if($screen_templateId!=''){
				$str.='<p><span id="revert_screen_editor_template" style="padding-left:50%; cursor:pointer; color: #35ACF8;" rev='.$screen_templateId.'#'.$did.'><strong>'.STR_ADVANCED_MODE_5.'<strong></span></p>';
			}			
			$str.='</div>';		
			
			$str.='<div class="row">';
			$str.='<div class="col-md-12">';
			$str.='<div class="listAlign">';
			$str.='<table class="table table-responsive">';
			$str.='<thead>';
			$str.='<tr>';
			$str.='<th style="padding-left: 10px">Template</th>';
			$str.='<th style="padding-left: 30px"></th>';
			$str.='</tr>';
			$str.='</thead>';
			$str.='<tbody id="setWallpaper">';
			foreach ($screenEditordata as $templateArr){
				$checkedScreenTemplate=($getScreenTemplayteId==$templateArr['id'])?'checked':'';
				$str.='<tr>';
				$str.='<td align="center"><span class="pointer pull-left editScreenEditorTemplateCss" id='.$appObj->desEncrypt($templateArr['id'], KEY_SEED).'> <img src="'.WEB_DATA_PATH.'/'.$templateArr['wallpaper_name'].'?param='.time().'" width="30px" height="30px"><span class="m-l">'.$templateArr['template_name'].'</span> </td>';
				$str.='<td>';
				$str.='<div class="col-md-6">';
				$str.='<div class="radio">';
				$str.='<input type="radio" name="template_name[]" id="tempchk_'.$templateArr['id'].'" value="'.$templateArr['id'].'" rev="'.$templateArr['id'].'" class="radio3 pointer makeDisabled" '.$checkedScreenTemplate.'><label for="tempchk_'.$templateArr['id'].'"></label>';
				
				$str.='</div>';
				$str.='</div>';
				$str.='</td>';
				$str.='</tr>';
			}
			$str.='</tbody>';
			$str.='<tbody>';
			$str.='<td></td>';
			$str.='<td></td>';
			$str.='</tr>';
			$str.='</tbody>';
			$str.='</table>';
			$str.='</div>';
			$str.='</div>';
			$str.='</div>';
 	 		$str.='</div>';
	  		$str.='</section>';
			echo $str.='<section><div class="col-md-12" style="position: fixed;bottom:1px;right: 20px;"><div class="form-group m-b-xs pull-right">
			<button type="button" id="closebtn" class="btn btn-via" data-dismiss="modal"><span aria-hidden="true">Cancel</span></button>
			&nbsp;<button type="button" id="applytemplateBtn" class="btn btn-via applytemplatecss">Apply</button></div></div></section>';

	  		die;			
		}		

		//Get Settings Template list by model_type
		public function getSettingsTemplateListAction(){
			$did=trim($_POST['did']);
			$appObj = new ApplicationController();
			//getting screen editor template which is set on group
			$getGroupsSql = $this->getDeviceInventoryTable()->getData(array('DID'=>$did));
			if($getGroupsSql->count()>0){
				$deviceDataArr = $getGroupsSql->current();
				$deviceGrpId = $deviceDataArr['DeviceGroupID'];				
				$setting_templateSql = $appObj->returnQueryData("SELECT b.id,b.template_name FROM tbl_via_settings_templates_mapping a INNER JOIN tbl_via_settings_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$deviceGrpId")->current();
				$setting_grp_templateName = $setting_templateSql['template_name'];
				$basicModeSettingsTemplateId=$setting_templateSql['id'];
			}
			
			
			
			//get model_type based on did
			/*$sysReportQry=$appObj->returnQueryData("SELECT model_type FROM tbl_sys_report WHERE did_fk=$did");
			if($sysReportQry->count()>0){
				$syeReportRow=$sysReportQry->current();
				$model_type = $syeReportRow['model_type'];
			}*/	
			$model_type=PRODUCT_MODEL_TYPE;		
			$condition=array('model_type'=>$model_type);
			$settingsTemplatedata=$this->getViaSettingsTemplatesTable()->getData($condition);			
			//get selected template
			$templateSql = $appObj->returnQueryData("SELECT b.id, b.template_name FROM tbl_via_settings_templates_mapping a INNER JOIN tbl_via_settings_templates b ON a.template_id=b.id WHERE a.isGrpIdOrDeviceId=$did AND entryType=1")->current();			
			$settings_templateId = $templateSql['id'];
			$settings_selected_templateId = $templateSql['template_name'];
			
			//getting templateid. Advanced mode template id is priority than basic mode
			$getSettingsTemplayteId=($templateSql['id']!='')?$templateSql['id']:$basicModeSettingsTemplateId;
			
			
			$str='<section class="">';
			$str.='<div class="panel-body">';
			$str.='<div class="row" style="padding-left:20px;">'.STR_ADVANCED_MODE_1.'</div>';
			$str.='<div class="row" style="height:20px">&nbsp;</div>';
			$str.='<div class="row" style="padding-left:20px;">'.STR_ADVANCED_MODE_2.'</div>';
			$str.='<div class="row" style="height:20px">&nbsp;</div>';
			
			$str.='<div id="advancedMode_roundborder">';
			if($settings_templateId!=''){
				$str.='<p><strong>'.STR_ADVANCED_MODE_3.':&nbsp;&nbsp;'.$settings_selected_templateId.'</strong></p>';
			}
			$str.='<p><strong>'.STR_ADVANCED_MODE_4.':&nbsp;&nbsp;'.$setting_grp_templateName.'<strong></p>';
			if($settings_templateId!=''){
				$str.='<p><span id="revert_template" style="padding-left:50%; cursor:pointer; color: #35ACF8;" rev='.$settings_templateId.'#'.$did.'><strong>'.STR_ADVANCED_MODE_5.'<strong></span></p>';
			}			
			$str.='</div>';	
				
			$str.='<div class="row">';
			$str.='<div class="col-md-12">';
			$str.='<div class="listAlign">';
			$str.='<table class="table table-responsive">';
			$str.='<thead>';
			$str.='<tr>';
			$str.='<th style="padding-left: 10px">Template</th>';
			$str.='<th style="padding-left: 30px"></th>';
			$str.='</tr>';
			$str.='</thead>';
			$str.='<tbody id="setWallpaper">';
			foreach ($settingsTemplatedata as $templateArr){
				$checkedSettingsTemplate=($getSettingsTemplayteId==$templateArr['id'])?'checked':'';
				$str.='<tr>';
				$str.='<td align="center"><span class="pointer pull-left editSettingsTemplateCss" rev='.$appObj->desEncrypt($templateArr['id'], KEY_SEED).' id='.$appObj->desEncrypt($templateArr['template_name'], KEY_SEED).'>'.$templateArr['template_name'].'</span> </td>';
				$str.='<td>';
				$str.='<div class="col-md-6">';
				$str.='<div class="radio">';
				$str.='<input type="radio" name="template_name[]" id="tempchk_'.$templateArr['id'].'" value="'.$templateArr['id'].'" rev="'.$templateArr['id'].'" class="radio3 pointer makeDisabled" '.$checkedSettingsTemplate.'><label for="tempchk_'.$templateArr['id'].'"></label>';
				
				$str.='</div>';
				$str.='</div>';
				$str.='</td>';
				$str.='</tr>';
			}
				$str.='</tbody>';
				$str.='<tbody>';
				$str.='<td></td>';
				$str.='<td></td>';
				$str.='</tr>';
				$str.='</tbody>';
				$str.='</table>';
				$str.='</div>';
				$str.='</div>';
				$str.='</div>';
		  		$str.='<section><div class="col-md-12" style="position: fixed;bottom:1px;right: 20px;"><div class="form-group m-b-xs pull-right"><button type="button" id="closebtn" class="btn btn-via" data-dismiss="modal"><span aria-hidden="true">Cancel</span></button>&nbsp;<button type="button" id="applySettingsTemplateBtn" class="btn btn-via applytemplatecss">Apply</button></div></div></section>';
		  		$str.='</div>';
		  		echo $str.='</section>';
	  			die;			
		}		

		
		//apply screen editor advanced mode
		public function applyScreenEditorTemplateAction(){
			$appObj = new ApplicationController();
			$tmpId=trim($_POST['tmpId']);
			$did=trim($_POST['did']);
			//get model_type based on did
			/*$sysReportQry=$appObj->returnQueryData("SELECT model_type FROM tbl_sys_report WHERE did_fk=$did");
			if($sysReportQry->count()>0){
				$syeReportRow=$sysReportQry->current();
				$model_type = $syeReportRow['model_type'];
			}*/			
			$model_type=PRODUCT_MODEL_TYPE;
			
			$templateStatus = $appObj->returnQueryData("SELECT * FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			//$templateStatusArr = $templateStatus->current();			
			if($templateStatus->count()==0){		
				$appObj->executeQueries("INSERT INTO tbl_templates_mapping SET isGrpIdOrDeviceId=$did,entryType=1,template_id=$tmpId,model_type=$model_type,modifydatetime=now()");
			}else{
				$appObj->executeQueries("UPDATE tbl_templates_mapping SET isGrpIdOrDeviceId=$did,entryType=1,template_id=$tmpId,model_type=$model_type,modifydatetime=now() WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			}
			$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0 WHERE did_fk IN ($did) AND wallpaper_status=1");
			$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($did)");
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);
			die('success');
		}

		//apply settings template advanced mode
		public function applySettingsTemplateAction(){
			$appObj = new ApplicationController();
			$tmpId=trim($_POST['tmpId']);
			$did=trim($_POST['did']);
			//get model_type based on did
			/*$sysReportQry=$appObj->returnQueryData("SELECT model_type FROM tbl_sys_report WHERE did_fk=$did");
			if($sysReportQry->count()>0){
				$syeReportRow=$sysReportQry->current();
				$model_type = $syeReportRow['model_type'];
			}*/
			$model_type=PRODUCT_MODEL_TYPE;
			//die("SELECT * FROM tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			$templateStatus = $appObj->returnQueryData("SELECT * FROM tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			//$templateStatusArr = $templateStatus->current();			
			if($templateStatus->count()==0){		
				$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping SET isGrpIdOrDeviceId=$did, entryType=1,template_id=$tmpId, model_type=$model_type, modifydatetime=now()");
			}else{
				$appObj->executeQueries("UPDATE tbl_via_settings_templates_mapping SET isGrpIdOrDeviceId=$did,entryType=1,template_id=$tmpId,model_type=$model_type, modifydatetime=now() WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			}
			$appObj->executeQueries("UPDATE tbl_sys_report SET configSettingStatus=0 WHERE did_fk IN ($did) AND configSettingStatus=1");
			$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($did)");
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);			
			die('success');
		}
		

		//revert settings template advanced mode
		public function revertTempleteAction(){
			$appObj = new ApplicationController();
			$tmpId=trim($_POST['tmpId']);
			$did=trim($_POST['did']);
			$model_type=PRODUCT_MODEL_TYPE;
			$appObj->returnQueryData("DELETE FROM tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			
			$appObj->executeQueries("UPDATE tbl_sys_report SET configSettingStatus=0 WHERE did_fk=$did AND configSettingStatus=1");
			$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID=$did");	
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);	
			die('success');
		}
		
		//revert screen template advanced mode
		public function revertScreenEditorTempleteAction(){
			$appObj = new ApplicationController();
			$tmpId=trim($_POST['tmpId']);
			$did=trim($_POST['did']);
			$model_type=PRODUCT_MODEL_TYPE;
			$appObj->returnQueryData("DELETE FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId=$did AND entryType=1 AND model_type=$model_type");
			$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0 WHERE did_fk=$did AND wallpaper_status=1");
			$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID=$did");
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);			
			die('success');
		}
		
		//revert screen template advanced mode
		public function sentVSMCloudUpgradeEmailAction(){
			$request = $this->getRequest();
			$appObj = new ApplicationController();
			$poll_encryption_key=POLL_ENCRYPTION_KEY;
			if($request->isXmlHttpRequest()) {
				$emailId= trim($request->getPost('email'));	
				$SmtpUser="";
				$SmtpPass="";
				$smtpQry=$appObj->returnQueryData("SELECT mailer_host,mailer_port,mailer_username,AES_DECRYPT(mailer_password,'$poll_encryption_key') as mailer_password,from_mail_id,mailer_auth,mailer_ssl FROM tbl_smtp_configuration");
				if($smtpQry->count()>0){
					$rowData=$smtpQry->current();
					$SmtpServer=$rowData['mailer_host'];
					$SmtpPort=$rowData['mailer_port'];
					$from = $emailId;//$rowData['from_mail_id'];
					$mailerAuth = $rowData['mailer_auth'];
					$mailerSsl = $rowData['mailer_ssl'];
					$SmtpUser=$rowData['mailer_username'];
					$SmtpPass=$rowData['mailer_password'];
				
					if($mailerAuth=="on"){
						$mailerAuth="login";
					}else{
						$mailerAuth="smtp";
					}
					if($mailerSsl=="on"){
						$SSL="ssl";
					}else{
						$SSL="tls"; // TODO
					}
				}
				$to = 'achauhan@kramerav.com';	
				$htmlMarkup="<html><body><p>Dear Support,<br>We have placed a request to upgrade VSM. Please upgrade VSM.<br>Thanks,</body></html>";
				
				$message = new \Zend\Mail\Message();
				$message->setFrom($from);
				$message->addTo($to);
				$message->setSubject("VSM update request");
				$html = new MimePart($htmlMarkup);
				$html->type = "text/html";
				$body = new MimeMessage();
				$body->setParts(array($html));
				$message->setBody($body);
				$transport = new SmtpTransport();
				$options   = new SmtpOptions(array(
					'name'              => $SmtpServer,
					'host'              => $SmtpServer,
					'port'              => $SmtpPort,
					'connection_class'  => $mailerAuth,
					'connection_config' => array(
						'username' => $SmtpUser,
						'password' => $SmtpPass,
						'ssl'      => $SSL,
					),
				));
				
				$transport->setOptions($options);				
				$transport->send($message);				
				if($transport){
					echo 1;die;
				}else{
					echo 0;die;
				}
							
				
			  }
		}		
		
		
        public function getDeviceInventoryTable() {
			if(!$this->TblDeviceInventoryTable) {
				$sm = $this->getServiceLocator();
				$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
			}
			return $this->TblDeviceInventoryTable;
		}
		
		public function getAutoDiscoverVsmTable() {
			if(!$this->TblAutoDiscoverVsmTable) {
				$sm = $this->getServiceLocator();
				$this->TblAutoDiscoverVsmTable = $sm->get('Webapp\Model\TblAutoDiscoverVsmTable');
			}
			return $this->TblAutoDiscoverVsmTable;
		}

		public function getDeviceDnsnameTable() {
			if(!$this->TblDeviceDnsnameTable) {
				$sm = $this->getServiceLocator();
				$this->TblDeviceDnsnameTable = $sm->get('Webapp\Model\TblDeviceDnsnameTable');
			}
			return $this->TblDeviceDnsnameTable;
		}

		public function getDevicegroupTable() {
			if(!$this->TblDevicegroupTable) {
				$sm = $this->getServiceLocator();
				$this->TblDevicegroupTable = $sm->get('Webapp\Model\TblDevicegroupTable');
			}
			return $this->TblDevicegroupTable;
		}
		public function getTemplatesTable() {
			if (!$this->TblTemplatesTable) {	
				$sm = $this->getServiceLocator();		
				$this->TblTemplatesTable = $sm->get('Webapp\Model\TblTemplatesTable');	
			}
			return $this->TblTemplatesTable;
		}
		 /*****
		 *	@Function Name: getViaSettingsTemplatesTable
		 *  @description  : get viasetting table
		 *	@Author		  : Ashu
		 *  @Date         : 22-april-2020
		 *****/
		public function getViaSettingsTemplatesTable() {
			if (!$this->TblViaSettingsTemplatesTable) {	
				$sm = $this->getServiceLocator();		
				$this->TblViaSettingsTemplatesTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesTable');
			}
			return $this->TblViaSettingsTemplatesTable;
		}
				
		
}
