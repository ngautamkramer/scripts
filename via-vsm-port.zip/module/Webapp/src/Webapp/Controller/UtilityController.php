<?php

namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\ServicesController;

use Webapp\Form\UtilityForm;
//using for zip
use ZipArchive;
class UtilityController extends AbstractActionController
{
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

     /*****
	 *	@Function Name		: resetUnitAction
	 *  @description	    : main function for reset unit.
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 03-Feb-2020
	 *****/
	public function resetUnitAction(){
		$appObj=new ApplicationController();
		$hqMasterData = $appObj->getTableAllData('tbl_hq_configuration');
		foreach($hqMasterData as $hqMasterDataVal) {
			$wallpaperSettingVal = $hqMasterDataVal['hq_wallpapersetting'];
			$authSettingVal = $hqMasterDataVal['hq_authsetting'];
			$configSettingVal = $hqMasterDataVal['hq_configsetting'];
			$gwaySettingVal = $hqMasterDataVal['hq_gwayfeaturesetting'];
			$clientSettingVal = $hqMasterDataVal['hq_clientfeaturesetting'];
			$mobileSettingVal = $hqMasterDataVal['hq_mobilefeaturesetting'];
		}
		
		$hqMasterMoreData = $appObj->getTableAllData('tbl_hq_more_configuration');
		foreach($hqMasterMoreData as $hqMasterMoreDataVal) {
			$advanceConfigurationSettingVal=$hqMasterMoreDataVal['featurestatus1'];
			$dssSettingVal=$hqMasterMoreDataVal['featurestatus2'];
			$pollSettingVal=$hqMasterMoreDataVal['featurestatus3'];
			$globalSettingsVal=$hqMasterMoreDataVal['featurestatus4'];
			$calendarSettingsVal=$hqMasterMoreDataVal['featurestatus5'];
		
		}
		
		$deviceInventoryData = $appObj->getTableAllData('deviceinventory');
		foreach($deviceInventoryData as $deviceInventoryVal) {			
			$viaServerIP = $deviceInventoryVal['deviceip'];
		}
		$modelOsType=strtolower($appObj->getModelNameByParam('ostype'));
		$firebaseStatus=file_exists(DEST_PATH.FILE_FIREBASE)?1:0;
		//adding modellike
		$modellike=$appObj->getModelNameByParam('modellike');		
		$viewmodel = new ViewModel(array('viaServerIP' => $viaServerIP,'wallpaperSettingVal'=>$wallpaperSettingVal,'authSettingVal'=>$authSettingVal,'configSettingVal'=>$configSettingVal,'gwaySettingVal'=>$gwaySettingVal,'clientSettingVal'=>$clientSettingVal,'mobileSettingVal'=>$mobileSettingVal,'advanceConfigurationSettingVal'=>$advanceConfigurationSettingVal,'dssSettingVal'=>$dssSettingVal,'pollSettingVal'=>$pollSettingVal,'globalSettingsVal'=>$globalSettingsVal,'calendarSettingsVal'=>$calendarSettingsVal,'modelOsType'=>$modelOsType,'firebaseStatus'=>$firebaseStatus,'modellike'=>$modellike));
		if(PRODUCT == "via"){
			$viewmodel->setTemplate("webapp/utility/system-settings");
		}
		return $viewmodel;
						
	}
     /*****
	 *	@Function Name		: resetLogs
	 *  @description	    : ajax call to reset gateway logs
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 04-Feb-2020
	 *****/
	
 	public function resetLogsAction(){
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('LoginName');
		$appObj=new ApplicationController();
	
		$radiobtn = trim($_POST['selectedItems']);
		if($radiobtn=='resetLogs'){
			// added by ashu on 9Dec15 to delete logs from tables also
			//$appObj->truncateTable('ActivityLogMaster');
			//updated by ashu on 19Jan22. Deleting all logs except VIA-Activated
			$appObj->executeQueries("DELETE FROM ActivityLogMaster WHERE ActionTaken!='VIA-Activated'");
			$appObj->truncateTable('ProjectorLog');
			//end
			
			if(GET_OS=='LIN'){
				$clientSysLogDir=CLIENT_SYSLOG_DIR;
				if($getOS=='LIN'){
					$logsDir = glob($clientSysLogDir.'/*');
					foreach($logsDir as $fileL) {
						unlink($fileL);
					}			
				}
			}
			$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>DeleteLog</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$appObj->sendMsgToAPIserver($logincmd,$actionCmd);
			echo 'success';		
		}
		die;
	}


     /*****
	 *	@Function Name		: resetConfigurationAction
	 *  @description	    : ajax call to reset files and table from maintenance
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 03-Feb-2020
	 *****/
	
 	public function resetConfigurationAction(){
			$session = new Container('userinfo');
			$sessionLoginName = $session->offsetGet('LoginName');
			$appObj=new ApplicationController();
			$model=trim($appObj->getModelNameByParam('model'));
			$modellike=trim($appObj->getModelNameByParam('modellike'));
			//modified condition by ashu on 11July24. now using modellike in place of model
			$check_viago=($modellike==3)?1:0;
	
			$configChkBoxArr=trim($_POST['configChkBoxArr']);
			$finalArr=explode(",",$configChkBoxArr);
			//print_r($finalArr);
			for($i=0;$i<count($finalArr);$i++){		
				if($finalArr[$i]=='resetConfigs'){ 
					$resetConfiguration='yes';
					/*$resetAdvConfig='yes';
					$resetAuthentication='yes';
					$resetGwayFeatures='yes';
					$resetClientFeatures='yes';
					$resetMobileFeatures='yes';
					$resetGlobal='yes';*/
				}
				if($finalArr[$i]=='resetWallp'){ $resetWallpaper='yes';}
				if($finalArr[$i]=='resetUsers'){ $resetUsers='yes';}
				if($finalArr[$i]=='resetViaPad'){ $resetViaPad='yes';}
				//if($finalArr[$i]=='resetAdvConfig'){ $resetAdvConfig='yes';}
				//if($finalArr[$i]=='resetAudienceConfig'){ $resetAudienceConfig='yes';}
				if($finalArr[$i]=='resetDss'){ $resetDss='yes';}
				if($finalArr[$i]=='resetWizard') $resetWizard='yes';
				if($finalArr[$i]=='resetCalendar'){ $resetCalendar='yes';}
				if($finalArr[$i]=='resetLogs'){ $resetLogs='yes';}
			}
			
			//getting hostname or wifi1_Host for dns name
			$get_roomname='';					
			$sessionNetworkData=$session->offsetGet('networkData');	
			if($sessionNetworkData['Lan1_Host']!=''){
				$get_roomname = $sessionNetworkData['Lan1_Host'];
			}else{
				$get_roomname = $sessionNetworkData['wifi1_Host'];
			}
			if($resetWallpaper=='yes' || $resetConfiguration=='yes'){
					//put ssid or host or wifi1_Host value in roomnamevalueshow.txt
					$roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
					file_put_contents($roomnameTxtFile, $get_roomname);	
			}
			
			if($resetWallpaper=='yes'){			
                   if(GET_OS=='WIN'){
                            $imgExt='.jpg';
                            $defImgName='default.jpg';
                            $source_img = DEST_PATH.'windowDefault.jpg';
                			$defImg = 'default.jpg';
                    }
                    if(GET_OS=='LIN'){
                            $imgExt='.png';
                            $defImgName='Default.png';
                            $source_img = DEST_PATH.'linuxDefault.png';
                			$defImg = 'default.png';
                    }		
					$defTemplateName='default.json';
					
					$appObj->truncateTable('tbl_wallpaper');
					copy(DEST_PATH.SYSTEM_DEFAULT_IMG,DEST_PATH.$defImgName);// or die('Default image not found');
					copy(DEST_PATH.$defImgName,HTML_PUBLIC_DIR.'/uploads/large/'.$defImgName);// or die('Default image not found');
					
					//added on 7 Dec2018. for Reset template designer
					$appObj->truncateTable('tbl_templates');
					//deleting all template files                   
					$files = glob(TEMPLATE_DIR_ZEND.'*');
                    foreach($files as $file){
                      if(is_file($file))
                            unlink($file);
                    }
					//remove all wallpapers                    
					$wallpfiles = glob(HTML_PUBLIC_DIR.'/uploads/large/*');
                    foreach($wallpfiles as $wallfile){ 
                      if(is_file($wallfile))
                            unlink($wallfile);
                    }
					
				if(FILE_ROOMNAME==1) unlink(DEST_PATH.READFILE_ROOMNAME);
				if(FILE_ROOMCODE==1) unlink(DEST_PATH.READFILE_ROOMCODE);
				if(FILE_ROOMCODESHOW==1) unlink(DEST_PATH.READFILE_ROOMCODESHOW);
				if(FILE_REFRESHTIME==1) unlink(DEST_PATH.READFILE_REFRESHTIME);		
				if(FILE_STRDATETIME==1) unlink(DEST_PATH.READFILE_STRDATETIME);
				if(FILE_SECOND_DISPLAY==1) unlink(DEST_PATH.READFILE_SECOND_DISPLAY);
				if(CHECK_FILE_STR24HOUR_FORMAT==1) unlink(DEST_PATH.FILE_STR24HOUR_FORMAT);
				
				//create default template
				
				if(GET_OS=='WIN'){
					$source_json = DEST_PATH.'windowDefault.json';
				}else{
					$source_json = DEST_PATH.'linuxDefault.json';
				}
               
                $dest_img = HTML_PUBLIC_DIR.'/uploads/large/'.$defImg;
                $dest_json = HTML_PUBLIC_DIR.'/uploads/templates/default.json';
                copy($source_img,$dest_img);
                copy($source_json,$dest_json);

                $finalImg='uploads/large/'.$defImg;
				$appObj->executeQueries("INSERT INTO tbl_templates (template_name, status, created_at, wallpaper_name,modifydatetime, model_type) VALUES ('default',1,now(),'$finalImg',now(),".PRODUCT_MODEL_TYPE.");");		
				$appObj->ActivityLog('Reset',MSG_WALLPAPER_BY.' '.$sessionLoginName);
			}
			
			if($resetConfiguration=='yes'){
				if(file_exists(DEST_PATH."model.json")){
					$sourceFile = DEST_PATH."settings_default.json";//$appObj->getViaSettingTemplate();
					$settingsFile = DEST_PATH.'via_settings.json';
					
					if(file_exists($settingsFile)){
						unlink($settingsFile);
					}
					copy($sourceFile, $settingsFile);
					//update dns in via_settings.json
						$settingFile_content=file_get_contents($settingsFile);	
						//decrypt json					
						$decryptSettingFile = $appObj->desDecrypt($settingFile_content,POLL_ENCRPTION_KEY);
						$jsonArray=json_decode($decryptSettingFile, true);
						//update thirdparty Array. now zoom and teams will be off 
						$via_details_arr = $jsonArray['VIA_CONFIG_TEMPLATE']['via_details'];
						$via_details_arr['dnsname'] =$get_roomname;							
						$jsonArray['VIA_CONFIG_TEMPLATE']['via_details'] = $via_details_arr;
						//add room name type 2 for host radio button
						$jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = 2;
						//Encrypt to json				
						$encodedData = json_encode($jsonArray,true);	
						$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);				
						file_put_contents($settingsFile, $encryptedJson);
					//end
					
					
					$settingPath = glob(UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'*');
					foreach($settingPath as $file){
					  if(is_file($file) && $file != $sourceFile){
							unlink($file);
					  }
					}
					$defaultFile = UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'default.json';
					//modified byu ashu. Now copying updated via_settings.json to default.json coz it contans dns name
					copy($settingsFile, $defaultFile);
				}
				
                $this->getViaSettingsTemplatesTable()->truncateTable();
				$insertArr = array('template_name' => 'default', 'status' => 1, 'created_at' => date("Y-m-d H:i:s"),'model_type'=>PRODUCT_MODEL_TYPE, 'template_path' => 'uploads/config_templates/default.json' , 'modifydatetime' => date("Y-m-d H:i:s"));
				$this->getViaSettingsTemplatesTable()->insertData($insertArr);
				
				if(FILE_PIP==1) unlink(DEST_PATH.READFILE_PIP);
				if(CHECKFILE_ENABLELOG==1) unlink(DEST_PATH.READFILE_ENABLELOG);
				if(FILE_MEDIA==1) unlink(DEST_PATH.READFILE_MEDIA);
				if(FILE_QUICK==1) unlink(DEST_PATH.READFILE_QUICK);
				if(CHECK_FILE_CHAT==1) unlink(DEST_PATH.FILE_CHAT);
				//create nohidewindow.txt for autohide
				$myfileAutoHide = fopen(DEST_PATH.FILE_DYNAMICLAYOUT, 'w');// or die("can't open file");
				fwrite($myfileAutoHide, '');			
				fclose($myfileAutoHide);			
				
				// create default file for layout.txt
				$myfileDynamicLayot = fopen(DEST_PATH.FILE_LAYOUT, 'w');// or die("can't open file");
				fwrite($myfileDynamicLayot, 0);			
				fclose($myfileDynamicLayot);	
					
				if(CHECK_FILE_ENERGYSAVER_MODE==1) unlink(DEST_PATH.FILE_ENERGYSAVER_MODE);				
				
				/* ********* Reset Power Off Block Files ************* */
				if(CHECK_FILE_AUTO_POWEROFF==1) unlink(DEST_PATH.FILE_AUTO_POWEROFF);
				/* ********** Reset Lang Block File ******************* */
				if(CHECK_FILE_LANGTXT==1) unlink(DEST_PATH.READFILE_LANGTXT);
				/* *********** Reset DateTime Block File ************************** */
				if(CHECK_FILE_DATEFORMAT==1) unlink(DEST_PATH.FILE_DATEFORMAT);		
				/* ********************** Reset QR Files ************************** */
				if(CHECK_FILE_QRTOP==1) unlink(DEST_PATH.FILE_QRTOP);
				if(CHECK_FILE_QRBYPASS==1) unlink(DEST_PATH.FILE_QRBYPASS);
				if(CHECK_FILE_QRCODE==1) unlink(DEST_PATH.FILE_QRCODE);
				if(CHECK_FILE_AUTO_REBOOT==1) unlink(DEST_PATH.FILE_AUTO_REBOOT);
				//added on 14Feb2017 to reset third party shortcut
				if(CHECK_FILE_THIRDPARTYSHORTCUT==1) unlink(DEST_PATH.FILE_THIRDPARTYSHORTCUT);
				//added on 14Feb2019 for reset miracast frequency
				if(file_exists(LIN_WIFI_PATH.FILE_MIRACAST_FREQUENCY)){ 
					unlink(LIN_WIFI_PATH.FILE_MIRACAST_FREQUENCY);
					$miracastFrequencyFile = fopen(DEST_PATH.'wifi/'.FILE_MIRACAST_FREQUENCY, 'w');
					fwrite($miracastFrequencyFile, 24);			
					fclose($miracastFrequencyFile);				
				}

				//create lang file
				if(!file_exists(DEST_PATH.READFILE_LANGTXT)){
					$fileName = DEST_PATH.READFILE_LANGTXT;
					$myfile = fopen($fileName, 'w');			
					$confWrite = fwrite($myfile, 'en');	
				}
				
				//Create date format file
				if(!file_exists(DEST_PATH.FILE_DATEFORMAT)){
					$dateFormatfileName = DEST_PATH.FILE_DATEFORMAT;
					$dateFormatFile = fopen($dateFormatfileName, 'w');			
					$dateFormatFilefWrite = fwrite($dateFormatFile, 'Y-m-d H:i:s');	
				}
				
				// reset $disableontopFile (Via Minimized icon feature file disableontop.txt)
				if(CHECK_FILE_DISABLE_ONTOP==1) unlink(DEST_PATH.FILE_DISABLE_ONTOP);
                //reset session
				$appObj->executeQueries("UPDATE tbl_advance_more_features SET ivalue = '1', modifydatetime='".date("Y-m-d H:i:s")."' WHERE property_name = 'ResetSession'");
				$appObj->executeQueries("UPDATE tbl_advance_more_features SET ivalue = '1', modifydatetime='".date("Y-m-d H:i:s")."' WHERE property_name = 'DspEncodeValue'");
				$appObj->executeQueries("UPDATE tbl_advance_more_features SET ivalue = '0', modifydatetime='".date("Y-m-d H:i:s")."' WHERE property_name = 'ModFeatEnable'");
				
				//added this on 5 Nov, 2024 by niraj as discuss with prateek sir
				$appObj->executeQueries("UPDATE tbl_advance_configuration SET feature4 = 0");

				//reset tbl_auth_fileformat
				
				$appObj->executeQueries("TRUNCATE TABLE tbl_auth_fileformat RESTART IDENTITY");
				//$appObj->executeQueries("DELETE FROM tbl_auth_fileformat WHERE id>44");
				//insert default data				
				$appObj->executeQueries("INSERT INTO tbl_auth_fileformat (id, fileformat, formatstatus, param1, param2, param3, param4) VALUES (1,'All',1,NULL,NULL,NULL,NULL),(2,'M4v',1,NULL,NULL,NULL,NULL),(3,'avi',1,NULL,NULL,NULL,NULL),(4,'bmp',1,NULL,NULL,NULL,NULL),(5,'dbt',1,NULL,NULL,NULL,NULL),(6,'divx',1,NULL,NULL,NULL,NULL),(7,'doc',1,NULL,NULL,NULL,NULL),(8,'docx',1,NULL,NULL,NULL,NULL),(9,'dot',1,NULL,NULL,NULL,NULL),(10,'ett',1,NULL,NULL,NULL,NULL),(11,'flv',1,NULL,NULL,NULL,NULL),(12,'gif',1,NULL,NULL,NULL,NULL),(13,'html',1,NULL,NULL,NULL,NULL),(14,'jpeg',1,NULL,NULL,NULL,NULL),(15,'jpg',1,NULL,NULL,NULL,NULL),(16,'m4a',1,NULL,NULL,NULL,NULL),(17,'mht',1,NULL,NULL,NULL,NULL),(18,'mkv',1,NULL,NULL,NULL,NULL),(19,'mov',1,NULL,NULL,NULL,NULL),(20,'mp3',1,NULL,NULL,NULL,NULL),(21,'mp4',1,NULL,NULL,NULL,NULL),(22,'mpeg',1,NULL,NULL,NULL,NULL),(23,'mpg',1,NULL,NULL,NULL,NULL),(24,'pdf',1,NULL,NULL,NULL,NULL),(25,'png',1,NULL,NULL,NULL,NULL),(26,'ppt',1,NULL,NULL,NULL,NULL),(27,'pptx',1,NULL,NULL,NULL,NULL),(28,'prs',1,NULL,NULL,NULL,NULL),(29,'rm',1,NULL,NULL,NULL,NULL),(30,'rmv',1,NULL,NULL,NULL,NULL),(31,'rmvb',1,NULL,NULL,NULL,NULL),(32,'rtf',1,NULL,NULL,NULL,NULL),(33,'svg',1,NULL,NULL,NULL,NULL),(34,'tiff',1,NULL,NULL,NULL,NULL),(35,'txt',1,NULL,NULL,NULL,NULL),(36,'vob',1,NULL,NULL,NULL,NULL),(37,'wav',1,NULL,NULL,NULL,NULL),(38,'wma',1,NULL,NULL,NULL,NULL),(39,'wmv',1,NULL,NULL,NULL,NULL),(40,'wps',1,NULL,NULL,NULL,NULL),(41,'wpt',1,NULL,NULL,NULL,NULL),(42,'xls',1,NULL,NULL,NULL,NULL),(43,'xlt',1,NULL,NULL,NULL,NULL),(44,'xml',1,NULL,NULL,NULL,NULL)");
				//$appObj->executeQueries("UPDATE tbl_auth_fileformat SET FormatStatus = 1");
     			
				//create NOPIP.txt for showing "Do not start HDMI input on startup "
				if(!file_exists(DEST_PATH.FILE_NOPIP)){
					$appObj->createFile(DEST_PATH.FILE_NOPIP,1);				
				}	
			
				//create dndbutton.txt for showing "Do Not Disturb"	
				if(!file_exists(DEST_PATH.FILE_DND)){
					$appObj->createFile(DEST_PATH.FILE_DND,'');				
				}
				if(CHECK_FILE_HDMIMODE==1) unlink(DEST_PATH.FILE_HDMIMODE);
				
				//mirroring
				$fileName1 = DEST_PATH . FILE_MIRRORNAME;
				$fileName2 = DEST_PATH . FILE_MIRROR_MAXCON;
				if(GET_OS == 'WIN') {
					$last4digit =(CHECK_SERIALNO_FILE == 1)? '_' . substr($appObj->file_read(DEST_PATH . SERIALNO_FILE), - 4): '';
				}
				$gwayMacAddr = "";
				if(GET_OS == 'LIN') {
					$gwayMacAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
					$last4digit =($gwayMacAddr != "")? '_' . substr(str_replace(':', '', $gwayMacAddr), - 4): '';
				}
				
				$myfile1 = fopen($fileName1, 'w')or die("can't open file");
				$confWrite1 = fwrite($myfile1, FILE_MIRRORNAME_TEXT .$last4digit);
				$myfile2 = fopen($fileName2, 'w')or die("can't open file");
				$confWrite1 = fwrite($myfile2, FILE_MIRROR_MAX_CONN);
				

				//update airmirrorname in default.json
				$settingsFile = DEST_PATH.'via_settings.json';
				$defaultFile = UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'default.json';
				$settingsFile_content=file_get_contents($settingsFile);	
				$decryptSettingsFile = $appObj->desDecrypt($settingsFile_content,POLL_ENCRPTION_KEY);
				$jsonArraySettings=json_decode($decryptSettingsFile, true);
				$jsonArraySettings['VIA_CONFIG_TEMPLATE']['via_details']['airplayname'] = FILE_MIRRORNAME_TEXT.$last4digit;
				$jsonArraySettings['VIA_CONFIG_TEMPLATE']['via_details']['airplay_number'] = FILE_MIRROR_MAX_CONN;
				$encodedDataSettings = json_encode($jsonArraySettings,true);	
				$encryptedJsonSettings = $appObj->desEncrypt($encodedDataSettings,POLL_ENCRPTION_KEY);				
				file_put_contents($settingsFile, $encryptedJsonSettings);
				copy($settingsFile, $defaultFile);
				//end update airmirrorname in default.json


				//create default files
				if(!file_exists(DEST_PATH.READFILE_PIP)){	
					$FileName=DEST_PATH.READFILE_PIP;
					$appObj->createFile($FileName,1);
					
				}
				if(!file_exists(DEST_PATH.READFILE_QUICK)){
					$FileName=DEST_PATH.READFILE_QUICK;					
					$appObj->createFile($FileName,1);
				}	
				if(!file_exists(DEST_PATH.READFILE_REFRESHTIME)){
					$FileName=DEST_PATH.READFILE_REFRESHTIME;					
					$appObj->createFile($FileName,$get_refreshTime);
				}
				if(!file_exists(DEST_PATH.READFILE_ROOMNAME)){
					$FileName=DEST_PATH.READFILE_ROOMNAME;					
					$appObj->createFile($FileName,'255,255,255');
				}
				if(!file_exists(DEST_PATH.READFILE_ROOMCODE)){
					$FileName=DEST_PATH.READFILE_ROOMCODE;	
					$appObj->createFile($FileName,'255,255,255');
				}
				if(!file_exists(DEST_PATH.READFILE_STRDATETIME)){
					$FileName=DEST_PATH.READFILE_STRDATETIME;
					$appObj->createFile($FileName,'255,255,255');
				}
				if(!file_exists(DEST_PATH.READFILE_ROOMCODESHOW)){
					$FileName=DEST_PATH.READFILE_ROOMCODESHOW;
					$appObj->createFile($FileName,1);		
				}
				if(!file_exists(DEST_PATH.FILE_STR24HOUR_FORMAT)){
					$FileName=DEST_PATH.FILE_STR24HOUR_FORMAT;
					$appObj->createFile($FileName,1);
				}
				//Reset moderator mode files
				if(FILE_CHKPRESENTATION_MODE==1) unlink(DEST_PATH.READFILE_CHKPRESENTATION_MODE);		
				if(FILE_STROUGROUP==1) unlink(DEST_PATH.READFILE_STROUGROUP);		
				if(FILE_STRADSETTINGS==1) unlink(DEST_PATH.READFILE_STRADSETTINGS);
				if(CHECK_FILE_CHAT==1) unlink(DEST_PATH.FILE_CHAT);

				//Reset gateway features files
				$file=DEST_PATH.FILE_GATEWAY_FEATURES;					
				if(file_exists($file)){
					unlink($file);
				}
				if(file_exists(DEST_PATH.FILE_ASSOCIATE_FILE)){
					unlink(DEST_PATH.FILE_ASSOCIATE_FILE);
				}
				if(file_exists(DEST_PATH.FILE_BROWSE_ASSOCIATE)){
					unlink(DEST_PATH.FILE_BROWSE_ASSOCIATE);
				}

				//Reset client features files
				$file=DEST_PATH.FILE_CLIENT_FEATURES;					
				if(file_exists($file)){
					unlink($file);
				}

				//Reset Display controller
				if(file_exists(DEST_PATH . FILE_LG)){
					unlink(DEST_PATH . FILE_LG);
				}

				//reset miracast file
				//Modifying by ashu on 11March25 for reset/create miracast file. Now for connect3 miracast is always ON so not deleteing this file				
				if(file_exists(DEST_PATH.FILE_MIRACAST)){
					if($modellike!=4){	
						unlink(DEST_PATH.FILE_MIRACAST);
					}					
				}else{
					if($modellike==4){
						$appObj->createFile(DEST_PATH.FILE_MIRACAST,'');
					}	
				}
				//creating infra.txt
				if(GET_OS=='LIN'){
					if(!file_exists(LIN_WIFI_PATH.'infra.txt')){
						$appObj->createFile(LIN_WIFI_PATH.'infra.txt','1');
					}
				}
				

				//reset DPI
				if(GET_OS=='WIN'){			
					$file=DEST_PATH.FILE_DPI;
					if(file_exists($file)){
						unlink($file);
					}					
				}

				//reset streaming
				$appObj->truncateTable('tbl_streaming_settings');
				//reset language	
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>ChangeLang</Cmd><P1>en</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$appObj->sendMsgToAPIserver($logincmd, $actionCmd);
				
				//Reset global settings
				//commented by ashu for updating pass
				//$tbldataArr=array('Password'=>'ff0774aae5cbca63fc70296f1b201a9f2ed9cf3a');
				//$appObj->updateTableData('AppUserList',$tbldataArr,$whrCondition='WHERE AppLoginName="su"');
				$tbldataArr1=array('sessionTimeOut'=>1440,'captcha'=>1,'field1'=>1);
				$appObj->updateTableData('tbl_session_settings',$tbldataArr1);
				$appObj->createFile(DEST_PATH.FILE_BROADCAST_IP,'');
				
				//reset certificate	
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Certificate</Cmd><P1>0</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";	
				$returnResult=$appObj->returnSocketData($logincmd,$actionCmd);

				$explodeReturnResult=explode('|',$returnResult);	
				$getResponse=trim($explodeReturnResult[2]);
					
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>NTPInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$appObj->sendMsgToAPIserver($logincmd,$actionCmd);


				//reset timezone
				$defailtTimezone = GET_OS == "WIN" ? '(UTC) Coordinated Universal Time' : 'UTC';
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetTimeZone</Cmd><P1>$defailtTimezone</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$appObj->sendMsgToAPIserver($logincmd,$actionCmd);

				//create history
				$appObj->ActivityLog('Reset',MSG_CONFIG_BY.' '.$sessionLoginName);				
				//create chromerun.txt	
				if(!file_exists(DEST_PATH.FILE_CHROMERUN)){									
					$appObj->createFile(DEST_PATH.FILE_CHROMERUN,1);				
				}					
				
			}


			
			$su = $appObj->securePassword('supass');
			$si = $appObj->securePassword('admin');
			$user = $appObj->securePassword('userpass');
			if($resetUsers=='yes'){
				$appObj->executeQueries("DELETE FROM appuserlist WHERE appuserid>1");
				$appObj->executeQueries("DELETE FROM appusergroups WHERE appuserid not in (1)");
				$appObj->executeQueries("UPDATE appuserlist SET password='".$su."' WHERE apploginname='su'");
				//$appObj->executeQueries("UPDATE appuserlist SET password='".$si."' WHERE apploginname='si'");
				//$appObj->executeQueries("UPDATE appuserlist SET password='".$user."' WHERE apploginname='user'");
				$appObj->ActivityLog('Reset',MSG_USERS_BY.' '.$sessionLoginName);
			}
			
			if($resetViaPad=='yes'){
				$file=DEST_PATH.FILE_WIFISECURITY_FILE;					
				if(file_exists($file)){
					unlink($file);
				}
				// create default via pad file
				$file_roomnamevalueshow=file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?$appObj->file_read(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):$appObj->file_read(DEST_PATH.READFILE_IPADD);
				
				$xml='';					
				if(GET_OS=='WIN'){
					$xml .= '<?xml version="1.0" encoding="utf-8"?>';
				}
				$xml .= '<viapad>';
				$xml .= '<authentication></authentication>';
				$xml .= '<encryption></encryption>';
				$xml .= '<autoconnect>0</autoconnect>';
				$xml .= '<ssid></ssid>';
				$xml .= '<key></key>';		
				$xml .= '<guest>0</guest>';
				$xml .= '<roomname>'.trim(str_replace("\n","",$file_roomnamevalueshow)).'</roomname>';
				$xml .= '<roomcode>0</roomcode>';
				$xml .= '<doubleclick>250</doubleclick>';
				$xml .= '</viapad>';
				
				list($wifiSecurityFilekey,$wifiSecurityFileIV)=explode('#',$appObj->getWifiSecurityKey());				
				if(strlen($wifiSecurityFilekey)==0 || strlen($wifiSecurityFileIV)==0){
					echo 'resetViaPadKeyError';
					exit;			
				}				
				$encryptedStr=$appObj->desEncrypt($xml,$wifiSecurityFilekey);
				$fileName=DEST_PATH.$wifiSecurityFile;
				$myfile = fopen($file, 'w');// or die("can't open file");
				$confWrite= fwrite($myfile, $encryptedStr);			
				fclose($myfile);
				$appObj->ActivityLog('Reset',MSG_VIAPAD_CONFIGBY.' '.$sessionLoginName);
			}
			
			if($resetDss=='yes'){
				$appObj->truncateTable('campaignlist');
				$appObj->truncateTable('campaign_media');
				$appObj->truncateTable('campaign_template');
				$appObj->truncateTable('dss_scrollerInfo');
				$appObj->truncateTable('MediaInventry');
				$appObj->truncateTable('playlist_now');
				$appObj->truncateTable('playlist_schedule_master');
				$appObj->deleteTableData('screentemplatemaster','WHERE ScreenTemplateID>6');
				$appObj->executeQueries('TRUNCATE TABLE dss_font RESTART IDENTITY');	
							
				//deleting all media files				
				$files = glob(UPLOAD_CONTENT_MEDIA.'*');				
				foreach($files as $file){ // iterate files
				  if(is_file($file))
					unlink($file); // delete file
				}				
				$campainFiles = glob(UPLOAD_DSS_CAMPAIGN.'*');
				foreach($campainFiles as $file){ // iterate files
				  if(is_file($file))
					unlink($file); // delete file
				}
				
				//deleting all font files	
				
				$dssFontQry="INSERT INTO dss_font (fontname, fontitalic, fontbolditalic, fontbold, fontnormal, fontblack, fontblackitalic, fontlight, fontlightitalic, fontfilename, 
				fontstatus, modifydate, fontuuid, fontchecksum) VALUES
				('Arial', 1, 1, 1, 1, 1, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Calibri', 1, 1, 1, 1, 0, 0, 1, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Cambria', 1, 1, 1, 0, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Century', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Comic Sans MS', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Courier New', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Impact', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Sylfaen', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Tahoma', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Times New Roman', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Trebuchet MS', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','',''),
				('Verdana', 1, 1, 1, 1, 0, 0, 0, 0, '', 1, '2017-10-06 00:00:00','','')";	
				$appObj->executeQueries($dssFontQry);					
				
				$files = glob(FONT_UPLOAD_PATH.'*');
				$leave_files=array('fontawesome-webfont.woff');
				foreach($files as $file){ // iterate files
					if( !in_array(basename($file), $leave_files) ){
						  if(is_file($file))
							unlink($file); // delete file					
					}
				}	
				$appObj->ActivityLog('Reset',MSG_DSS_BY.' '.$sessionLoginName);
			}
			//delete reset wizard file
			/*if($resetWizard=='yes'){
				unlink(DEST_PATH.FILE_SYSWIZARD);
				$appObj->ActivityLog('Reset',MSG_SETUP_WIZARD_BY.' '.$sessionLoginName);
			}*/
			if($resetWizard=='yes'){
				if(file_exists(DEST_PATH.FILE_WIZARD)){
					unlink(DEST_PATH.FILE_WIZARD);
				}				
				$appObj->ActivityLog('Reset',MSG_SETUP_WIZARD_BY.' '.$sessionLoginName);	
			}
			
			if($resetCalendar=='yes'){				
				$appObj->truncateTable('tbl_calendars');
				$appObj->truncateTable('tbl_access_token');
				$appObj->truncateTable('tbl_calender_account');
				$appObj->truncateTable('tbl_calendar_properties');				
				$appObj->ActivityLog('Reset',MSG_CALENDER_BY.' '.$sessionLoginName);
			}


			if($resetLogs=='yes'){
				$appObj->executeQueries("DELETE FROM ActivityLogMaster WHERE ActionTaken!='VIA-Activated'");
				$appObj->truncateTable('ProjectorLog');			
				if(GET_OS=='LIN'){
					$clientSysLogDir=CLIENT_SYSLOG_DIR;
					if($getOS=='LIN'){
						$logsDir = glob($clientSysLogDir.'/*');
						foreach($logsDir as $fileL) {
							unlink($fileL);
						}			
					}
				}
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>DeleteLog</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$appObj->sendMsgToAPIserver($logincmd,$actionCmd);			
			}
			
			die;
	}
	
	public function uploadWpglicenseAction(){
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$userfile = $this->params()->fromFiles('userfile');		
		$request = $this->getRequest();
		$postData = $this->getRequest()->getPost()->toArray();
		if($postData['fileFlag']=='newfile'){
			if($userfile['error']== '0'){
				//check for differentiate dss file and  system license file	
				if(strstr($_FILES['userfile']['name'],'_dss.lic') ){
					unlink(DEST_PATH.$userfile['name']);
					echo "<script>alert('Invalid License File'); window.location.href='uploadWpglicense';</script>";
					die;
				}
				$up = move_uploaded_file($_FILES['userfile']['tmp_name'], DEST_PATH.$_FILES['userfile']['name']);
				
				if($up){
				
					$wifiSecurityFilekey="1324587099345678";
					$wifiSecurityFileIV ="9131557057664220";	
					$wifiSecurityFile=DEST_PATH.$_FILES['userfile']['name'];	
					
				
					$filepath="";
					$filename=$_FILES['userfile']['name'];
					if(file_exists(DEST_PATH.$filename)){
						copy(DEST_PATH.$filename,DEST_PATH."activation.lic");
						unlink(DEST_PATH.$filename);
						system("sync");
						system("sync");
						$myfileName=DEST_PATH.'newfile.txt';
						$myfile = fopen($myfileName, 'w') or die("can't open file");
						$content = "Last updated on ".date("Y-m-d H:i:s");	
						$confWrite= fwrite($myfile, $content);		
						fclose($myfile);					
						sleep(1);
						$appObj = new ApplicationController();
						$retVal=$appObj->reboot_powerOff_Server('reboot');	
						echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";
                                                die;
					}else{
						echo"<script language='javascript'>alert('File Not Found!')</script>";
					}								
				}else{
						echo"<script language='javascript'>alert('Error: File not supported!')</script>";
				}
			}
		}
		
		if(file_exists(DEST_PATH.'licdetails.txt')){
			$licfile=DEST_PATH.'licdetails.txt';	
			$fp = fopen($licfile, "r");		
			if($fp){			
				$str="";			
				while(!feof($fp)){
						$fcontent = fgets($fp);//, filesize($file));					
						if($fcontent != ""){
							if(!strstr($fcontent,'Serial no')){								
								$str.=str_replace("|"," - ",$fcontent)."</p>";
							}	
						}	
				}
				if(strstr($str,'Locked')){
                                $str=str_replace("Locked","Locked&nbsp;<div style='display: inline-block;'><form name='activateLicenseFrm' id='activateLicenseFrm' method='post' action='uploadWpglicense'><input type='submit' name='activateLicensebtn' id='activateLicensebtn' value='Activate License' class='btn btn-viablue makeDisabled'></form></div>",$str);
                        }
                        else if(strstr($str,'DEMO')){
                                $str=str_replace("DEMO","DEMO&nbsp;<div style='display: inline-block;'><form name='activateLicenseFrm' id='activateLicenseFrm' method='post' action='uploadWpglicense'><input type='submit' name='activateLicensebtn' id='activateLicensebtn' value='Activate License' class='btn btn-viablue makeDisabled'></form></div>",$str);
                        } 
			}
		}
		
		if($request->getPost('activateLicensebtn')) {
			$gwayMacAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
			$macAddr=str_replace(':','-',$gwayMacAddr);
			$path="https://license.wowvision.com/";		
			$filename ='KRAMER_'.$macAddr.'.lic';	
			$save_to=realpath(DEST_PATH) . '/'.$filename;	
			$serverurl=$path.$filename;
			$curl = curl_init();
			//die(getcwd().'/config/cacertupdates.crt');
			curl_setopt_array($curl, array(
				CURLOPT_POST => 0,
				CURLOPT_URL => $serverurl,
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_SSL_VERIFYHOST=>0,		
				CURLOPT_CAINFO=>BASE_PATH.'/config/cacertupdates.crt',
				//by pass certificate		
				CURLOPT_SSL_VERIFYPEER=>false,
				CURLOPT_VERBOSE=>1
			));
			
			   $actFlag=1;
			  $file_content = curl_exec($curl);
			 // print_r($file_content);die;
			   if(strstr($file_content,'Not Found')){
					$actFlag=0;
			   }
		 //  die($actFlag);
				curl_close($curl);
				if($actFlag==1)	{ 
					$downloaded_file = fopen($save_to, 'w');
					fwrite($downloaded_file, $file_content);
					fclose($downloaded_file);			
						if(file_exists(DEST_PATH.$filename)){
							copy(DEST_PATH.$filename,DEST_PATH."activation.lic");
							unlink(DEST_PATH.$filename);
							system("sync");
							system("sync");	
							$myfileName=DEST_PATH."newfile.txt";
							$myfile = fopen($myfileName, 'w') or die("can't open file");
							$content = "Last updated on ".date("Y-m-d H:i:s");	
							$confWrite= fwrite($myfile, $content);		
							fclose($myfile);
							sleep(5);	
							$appObj=new ApplicationController();
							$appObj->ActivityLog('Activate','Activated License');
							$appObj = new ApplicationController();
							$retVal=$appObj->reboot_powerOff_Server('reboot');	
							echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";
                                                        die;
						}else{
							echo"<script language='javascript'>alert('License file is not available. Please contact Kramer Support.')</script>";			
						}		
				}else{
					echo"<script language='javascript'>alert('License file is not available. Please contact Kramer Support.')</script>";
				}

		}
		
		
		//echo $str;//die;
		$form = new UtilityForm();
		$viewmodel =  new ViewModel(array(
			'form' => $form,
			'str' => $str,
		));
		if(PRODUCT == "via"){
			$viewmodel->setTemplate("webapp/utility/system-settings");
		}
		return $viewmodel;
					
	}
	
	public function uploadLicenseFileAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$userfile = trim($request->getPost('userfile'));	
			if(strstr($userfile,'\\')){	
				$url_arr = explode ("\\", $userfile);
				$ct = count($url_arr);
				$userfile = $url_arr[$ct-1];

			}else{
				$userfile=$userfile;
			}
			$FileExt=strtolower(trim((substr($userfile,strlen($userfile)-4,4))));
			if($FileExt=='.lic'){
				echo'Ok';
				exit;
			
			}else{ 
				echo'invalidformat';
				exit;
			}
		}
						
	}

     /*****
	 *	@Function Name		: downloadLogsAction
	 *  @description	    : for download logs on maintenance page
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 16-March-2020
	 *****/
	
	public function downloadLogsAction(){
		$filesArr=$_POST['selChkBox'];		
		if(count($filesArr)==1){
			for($i=0;$i<count($filesArr);$i++){								
				header('Content-Description: File Transfer');
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename='.basename($filesArr[$i]));
				header('Content-Transfer-Encoding: binary');
				header('Expires: 0');
				header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
				header('Pragma: public');
				header('Content-Length: ' . filesize($filesArr[$i]));
				ob_clean();
				flush();
				readfile($filesArr[$i]);		
				exit;
			}

		}else{
			if(extension_loaded('zip')){	// Checking ZIP extension is available			
					$zip = new ZipArchive();			// Load zip library	
					$zip_name = 'GatewayLog_'.date('Y-M-d').".zip";			// Zip name
					if($zip->open($zip_name, ZIPARCHIVE::CREATE)!==TRUE){		// Opening zip file to load files
						$error .=  "* Sorry ZIP creation failed at this time<br/>";
					}
					foreach($filesArr as $file){								
						//$zip->addFile($file);
						$zip->addFile($file,basename($file));
					}
					$zip->close();
					if(file_exists($zip_name)){
						// push to download the zip
						header('Content-type: application/zip');
						header('Content-Disposition: attachment; filename="'.$zip_name.'"');
						readfile($zip_name);
						// remove zip file is exists in temp path
						unlink($zip_name);
					}
					
			}else
					//$error .= "* You dont have ZIP extension<br/>";
					die('You dont have ZIP extension<br/>');
			}
		die;
	}

	 /*****
	 *	@Function Name		: firebaseSettingAction
	 *  @description	    : for firebase  setting on/off
     *	@Author			    : Vineet 
	 *  @Date               : 27-feb-2021
	 *****/
	public function firebaseSettingAction(){
		$request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
		$firebaseStatus=trim($request->getPost('firebaseStatus'));
		$myfileName=DEST_PATH.FILE_FIREBASE;
        if ($firebaseStatus==1) {
            fopen($myfileName, "w") or die("can't open file");;
        }else{
			unlink($myfileName);
		}
		echo "success";
		die;
        }
	}
	
	/*****
	 *	@Function Name		: uploading BIOS Settings. We are not checking any extension. any file you can upload.
	 *  @description	    : It will upload bios image using jquery
	 *****/	
	public function uploadAction(){
		$appObj=new ApplicationController();
		$postData = $this->getRequest()->getPost()->toArray();
		$biosfileInfo = $this->params()->fromFiles('file');
		$biosfileArr = explode(".", $biosfileInfo['name']);
		//print_r($biosfileInfo);
		$imgTypeArr=strtolower($biosfileInfo['type']);		
		$imgTypeExplode=explode("/",$imgTypeArr);
		$imgType=trim($imgTypeExplode[1]);			
		$iconExt = strtolower(end($biosfileArr));		
		$upload_dir='/var/www/html/public/uploads';		
		$filepath = $upload_dir.'/'.$biosfileInfo['name'];		
		$up = move_uploaded_file($biosfileInfo['tmp_name'], $filepath);
		if($up){
			rename($filepath, $upload_dir.'/ami_bios_fw.bin');
			//sending command to api server
			$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$bioscmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>BiosUpdate</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$appObj->sendMsgToAPIserver($logincmd,$bioscmd);				
			die('success');
		}else{
			die('error');
		}
	}
	
	
	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}

	public function getViaSettingsTemplatesTable() {
		if (!$this->TblViaSettingsTemplatesTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblViaSettingsTemplatesTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesTable');
		}
		return $this->TblViaSettingsTemplatesTable;
	}
	
	 
}