<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\NetworksettingsForm;
use Webapp\Form\ViaConfigurationForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
//use Webapp\Model\UserTable;
//use Webapp\Model\adduser;
use Webapp\Form\SourceSwitchForm;
use Webapp\Form\ModeratorModeForm;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;

class DisplaycontrolController extends AbstractActionController {
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
	//uisg for display control
	public function sourceSwitchAction() {
		
		//$this->layout('layout/login');	
		$session = new Container('userinfo');
		$usrid = $session->offsetGet('usrid');
		//$utype = $session->offsetGet('utype');
		if(empty($usrid)) {
			return $this->redirect()->toRoute('index');
		}
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		$form = new SourceSwitchForm();
		if(!$request->isPost()) {
			if(file_exists(DEST_PATH . FILE_LG)) {
				$chkbox = 1;
				$handle = fopen(DEST_PATH . 
								FILE_LG, "r");
				if($handle) {
					$arr = array();

					while(($line = fgets($handle))!== false) {
						array_push($arr, $line);
					}
				} else {
				}
				fclose($handle);
				for($i = 0;
				$i < count ($arr );
				$i ++ ) {
					if($i == 0) {
						$line1 = $arr[$i];
						$line1Arr = explode("|", $line1);
						$lgIPTxt = $line1Arr[0];
						$lgIP = $line1Arr[1];
					}
					if($i == 1) {
						$line2 = $arr[$i];
						$line2Arr = explode("|", $line2);
						$lgPortTxt = $line2Arr[0];
						$lgPort = $line2Arr[1];
					}
					if($i == 2) {
						$line3 = $arr[$i];
						$line3Arr = explode("|", $line3);
						$lgSS1Txt = $line3Arr[0];
						$lgSS1 = $line3Arr[1];
					}
					if($i == 3) {
						$line4 = $arr[$i];
						$line4Arr = explode("|", $line4);
						$lgSS2Txt = $line4Arr[0];
						$lgSS2 = $line4Arr[1];
					}
					if($i == 4) {
						$line5 = $arr[$i];
						$line5Arr = explode("|", $line5);
						$lgEncTxt = $line5Arr[0];
						$lgEnc = $line5Arr[1];
					}
					$tooltipSS1Txt = "Ex: ".STR_SSS1_COMMAND . "=" . $lgSS1;
					$tooltipSS2Txt = "Ex: ".STR_SSS2_COMMAND . "=" . $lgSS2;
				}
			} else {
				$chkbox = 0;
				$lgIP = "";
				$lgPort = "";
				$lgSS1 = "";
				$lgSS2 = "";
				$lgEnc = 0;
				$tooltipSS1Txt = "Ex: ".STR_SSS1_COMMAND . "=" . STR_SS1_DEF_COMMAND;
				$tooltipSS2Txt = "Ex: ".STR_SSS2_COMMAND . "=" . STR_SS2_DEF_COMMAND;
			}
			if(CHECK_FILE_LGOPTIONS == 1) {
				$lgSouceFile_val = $appObj->file_read(DEST_PATH.FILE_LG_OPTIONS);
				
			} else {
				$lgSouceFile_val = '-1';
			}
			$form->setData(['lgActivateControl' => $chkbox, 'lgIP' => $lgIP, 'lgPort' => $lgPort, 'lgSS1' => $lgSS1, 'lgSS2' => $lgSS2, 'enctype' => $lgEnc, 'tooltip1' => $tooltipSS1Txt, 'tooltip2' => $tooltipSS2Txt,]);
			$viewmodel = new ViewModel(array('form' => $form, 'chkval' => $chkbox,'lgSourceFile'=>trim($lgSouceFile_val)));

			//added by niraj for load menus data into tab
            $viewmodel->setTemplate('webapp/manage-configurations/room-settings');
            return $viewmodel;
		}
		$form->setData($request->getPost());
		if(!$form->isValid()) {
			$viewmodel = new ViewModel(array('form' => $form));

			//added by niraj for load menus data into tab
            $viewmodel->setTemplate('webapp/manage-configurations/room-settings');
            return $viewmodel;
		}
		$data = $form->getData();
		$lgIP = trim($data['lgIP']);
		$lgPort = trim($data['lgPort']);
		$lgSS1 = trim($data['lgSS1']);
		$lgSS2 = trim($data['lgSS2']);
		$encType = trim($data['enctype']);
		$fileName = DEST_PATH . FILE_LG;
		$myfile = fopen($fileName, 'w')or die("can't open file");
		$content = "LGIP|$lgIP\r\nLGPort|$lgPort\r\nLGSS1|$lgSS1\r\nLGSS2|$lgSS2\r\nEncType|$encType";
		$confWrite = fwrite($myfile, $content);
		fclose($myfile);
		$this->flashMessenger()->addMessage('Activated successfully!');
		return $this->redirect()->toRoute('displaycontrol', array('action' => 'sourceSwitch'));
	}
	
	/*****
	 *	@function Name			: disabledConfigurationAction
	 *  @description	    : Using for remove configuration setting
	 *	@Author			    : Vineet
	 *  @Date               : 10-JAN-2020
	 *****/
	public function disabledConfigurationAction() {
		$session = new Container('userinfo');		
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$crsf_tokenval=trim($data[1]);
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}	
			
			if(file_exists(DEST_PATH . FILE_LG))
				unlink(DEST_PATH . 
					   FILE_LG);
			$view = new JsonModel(array('status' => true));
			$view->setTerminal(true);
			return $view;
		}
	}
	/*****
	 *	@function Name			: saveDisplaySetting
	 *  @description	    : save display controller data
	 *	@Author			    : Vineet
	 *  @Date               : 11-feb-2020
	 *****/
	public function saveDisplaySettingAction() {
		$session = new Container('userinfo');		
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$lgIP = htmlspecialchars($data[0]);
			$lgPort = htmlspecialchars($data[1]);
			$lgSS1 = htmlspecialchars($data[2]);
			$lgSS2 = htmlspecialchars($data[3]);
			$encType = $data[4];
			$crsf_tokenval=trim($data[5]);
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			
			if($lgIP == "" || $lgPort == "" || $lgSS1 == "" || $lgSS2 == "") {
				if($lgIP == "") {
					$msg = "ipnull";
				} else if($lgPort == "") {
					$msg = "portnull";
				} else if($lgSS1 == "") {
					$msg = "command1null";
				} else if($lgSS2 == "") {
					$msg = "command2null";
				}
				$view = new JsonModel(array('status' => $msg));
				$view->setTerminal(true);
				return $view;
			} else {
				$fileName = DEST_PATH . FILE_LG;
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$content = "LGIP|$lgIP\r\nLGPort|$lgPort\r\nLGSS1|$lgSS1\r\nLGSS2|$lgSS2\r\nEncType|$encType";
				$confWrite = fwrite($myfile, $content);
				fclose($myfile);
				$view = new JsonModel(array('status' => true));
				$view->setTerminal(true);
				return $view;
			}
		}
	}

	/*****
	 *	@function Name		: largeOptionAction
	 *  @description	    : save large otpion data
	 *	@Author			    : Vineet
	 *  @Date               : 28-aug-2020
	 *****/
	public function largeOptionAction(){
		
		$optionName=trim($_POST['optionName']);
		$getOptionVal=trim($_POST['getOption']);
		if($optionName=='setLGOptions'){
		$fileName=DEST_PATH.FILE_LG_OPTIONS;
			$myfile = fopen($fileName, 'w') or die("can't open file");
			$content = "";	
			$confWrite= fwrite($myfile, $getOptionVal);
			echo 'File Created';
			die;
		}
	}

	public function getHqConfigurationTable() {
		if(!$this->TblHqConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblHqConfigurationTable = $sm->get('Webapp\Model\TblHqConfigurationTable');
		}
		return $this->TblHqConfigurationTable;
	}

	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}

	public function getClientsFeaturesTable() {
		if(!$this->TblClientsFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
		}
		return $this->TblClientsFeaturesTable;
	}

	public function getDisplaySettingsTable() {
		if(!$this->TblDisplaySettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblDisplaySettingsTable = $sm->get('Webapp\Model\TblDisplaySettingsTable');
		}
		return $this->TblDisplaySettingsTable;
	}

	public function getTimezonesTable() {
		if(!$this->TblTimezonesTable) {
			$sm = $this->getServiceLocator();
			$this->TblTimezonesTable = $sm->get('Webapp\Model\TblTimezonesTable');
		}
		return $this->TblTimezonesTable;
	}

	public function getAdvanceConfigurationTable() {
		if(!$this->TblAdvanceConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationTable = $sm->get('Webapp\Model\TblAdvanceConfigurationTable');
		}
		return $this->TblAdvanceConfigurationTable;
	}

	public function getAdvanceMoreFeaturesTable() {
		if(!$this->TblAdvanceMoreFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceMoreFeaturesTable = $sm->get('Webapp\Model\TblAdvanceMoreFeaturesTable');
		}
		return $this->TblAdvanceMoreFeaturesTable;
	}

	public function getAuthFileFormatTable() {
		if(!$this->TblAuthFileFormatTable) {
			$sm = $this->getServiceLocator();
			$this->TblAuthFileFormatTable = $sm->get('Webapp\Model\TblAuthFileFormatTable');
		}
		return $this->TblAuthFileFormatTable;
	}

	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}

	public function getStreamingSettingsTable() {
		if(!$this->TblStreamingSettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblStreamingSettingsTable = $sm->get('Webapp\Model\TblStreamingSettingsTable');
		}
		return $this->TblStreamingSettingsTable;
	}

	public function getRecordingTransferTable() {
		if(!$this->TblRecordingTransferTable) {
			$sm = $this->getServiceLocator();
			$this->TblRecordingTransferTable = $sm->get('Webapp\Model\TblRecordingTransferTable');
		}
		return $this->TblRecordingTransferTable;
	}

	public function getProxySettingTable() {
		if(!$this->TblProxySettingTable) {
			$sm = $this->getServiceLocator();
			$this->TblProxySettingTable = $sm->get('Webapp\Model\TblProxySettingTable');
		}
		return $this->TblProxySettingTable;
	}

	public function getTemplatesTable() {
		if(!$this->TblTemplatesTable) {
			$sm = $this->getServiceLocator();
			$this->TblTemplatesTable = $sm->get('Webapp\Model\TblTemplatesTable');
		}
		return $this->TblTemplatesTable;
	}

	public function getFeatureTempTable() {
		if(!$this->TblFeatureTempTable) {
			$sm = $this->getServiceLocator();
			$this->TblFeatureTempTable = $sm->get('Webapp\Model\TblFeatureTempTable');
		}
		return $this->TblFeatureTempTable;
	}

	public function getTblGatewayFeaturesTable() {
		if(!$this->TblGatewayFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblGatewayFeaturesTable = $sm->get('Webapp\Model\TblGatewayFeaturesTable');
		}
		return $this->TblGatewayFeaturesTable;
	}

	public function getTblGatewayFeaturesPositionTable() {
		if(!$this->TblGatewayFeaturesPositionTable) {
			$sm = $this->getServiceLocator();
			$this->TblGatewayFeaturesPositionTable = $sm->get('Webapp\Model\TblGatewayFeaturesPositionTable');
		}
		return $this->TblGatewayFeaturesPositionTable;
	}
}
