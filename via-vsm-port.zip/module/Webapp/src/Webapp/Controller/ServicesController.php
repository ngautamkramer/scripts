<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Http\Request;
use Zend\Http\Response;
use Zend\Http\Headers;
use Zend\View\Model\JsonModel;
use Zend\Log\Writer\Stream;
use Zend\Log\Logger;
use Zend\Db\Sql\Sql;
use Zend\Db\Adapter\Adapter;
//add the package for license 7-Aug-2019
use Webapp\Controller\LicenseController;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use ZipArchive;
use StdClass;

    
class ServicesController extends AbstractActionController
{
	/*****
	 *	@Function Name		: croncreatetemplateAction
	 *  @description	    : calling  from qt side for Creating default template
     *	@Author			    : Ashu
	 *  @Date               : 27/March/2020
	 *****/	
	public function croncreatetemplateAction(){
			$appObj = new ApplicationController();			
			  if(GET_OS=='WIN'){
						$imgExt='.jpg';
						$defImgName='default.jpg';
						$source_img = DEST_PATH.'windowDefault.jpg';
						$defImg = 'default.jpg';
				}
				if(GET_OS=='LIN'){
						$imgExt='.png';
						$defImgName='Default.png';
						$source_img = DEST_PATH.'linuxDefault.png';
						$defImg = 'default.png';
				}		
			$finalImg='uploads/large/'.$defImg;			
			$qryArr=$appObj->getTableAllData("tbl_templates WHERE template_name='default'");
			if(count($qryArr)==0){
				//$appObj->executeQueries("INSERT INTO tbl_templates SET template_name='default',status=1,wallpaper_name='$finalImg', modifydatetime=now(),model_type=".PRODUCT_MODEL_TYPE."");
				$appObj->executeQueries("INSERT INTO tbl_templates (id, template_name, status, created_at, wallpaper_name,modifydatetime, model_type) VALUES (1, 'default',1,now(),'$finalImg',now(),".PRODUCT_MODEL_TYPE.");");
				if(GET_OS=='WIN'){
					$source_json = DEST_PATH.'windowDefault.json';
				}else{
					$source_json = DEST_PATH.'linuxDefault.json';
				}
               
                $dest_img = HTML_PUBLIC_DIR.'/uploads/large/'.$defImg;
                $dest_json = HTML_PUBLIC_DIR.'/uploads/templates/default.json';
                copy($source_img,$dest_img);
                copy($source_json,$dest_json);
				echo 'Template created successfully';
			
			}else{
				echo 'Template already exists'; 
			}
		die;
	}

	/*****
	 *	@Function Name		: moveTemplatesAction
	 *  @description	    : Templates data moved
     *	@Author			    : Ashu
	 *  @Date               : 27/March/2020
	 *****/		
	public function movetemplatesAction(){
		$appObj = new ApplicationController();
		$tbl_templatesData=$appObj->getTableAllData('tbl_templates');
		foreach($tbl_templatesData as $templatesValue){		
			//move and encryption code		
			$templateName=trim($templatesValue['template_name'].'.json');
			$encryptionfile=UPLOAD_PATH_VIA_SAVEAS.TEMPLATE_DIR.$templateName;
			$encryptionPath=TEMPLATE_DIR_ZEND.$templateName;			
			$appObj->encryptFile($encryptionfile,$encryptionPath);			
			//Image copy code
			$templateImgSourcePath=UPLOAD_PATH_VIA_SAVEAS.trim($templatesValue['wallpaper_name']);
			$templateImgDestPath=UPLOAD_DIR_ZEND.trim($templatesValue['wallpaper_name']);
			$appObj->copyFiles($templateImgSourcePath,$templateImgDestPath);
			
			//delete old data
			unlink($encryptionfile);
			unlink($templateImgSourcePath);
			
		}
		die('Template moved successfully');
	}

	/*****
	 *	@Function Name		: createDefaultTemplateAction
	 *  @description	    : createDefaultTemplate
     *	@Author			    : Ashu
	 *  @Date               : 8/April/2020
	 *****/		

	public function createDefaultTemplateAction(){
		$appObj = new ApplicationController();
		$lang=(CHECK_FILE_LANGTXT==1)?$appObj->file_read(DEST_PATH.READFILE_LANGTXT):'en';
		$extrawidth=($lang=='en')?20:20;
		$dateFormat='DD/MM/YYYY';
		$cwd=BASE_PATH;//dirname(__FILE__);
				
		$roomnameIP=trim($appObj->file_read(DEST_PATH.READFILE_IPADD));
		$check_readfile_ipadd1=file_exists(DEST_PATH.READFILE_IPADD1)?$appObj->file_read(DEST_PATH.READFILE_IPADD1):'';
		$displaySettingsData=$appObj->getTableAllData('tbl_display_settings');
		foreach($displaySettingsData as $displaySettingsArr){
			$check24HourFormat=trim($displaySettingsArr['24HoursFormat']);
			//Getting Roomname 1 Properties
			$activate_RoomName=trim($displaySettingsArr['activate_RoomName']);
			$roomname1hexCode=trim($appObj->gethexacodeFromRGb($displaySettingsArr['show_RoomName_Color']));
			$activate_RoomName_SecondDisplay=trim($displaySettingsArr['activate_RoomName_SecondDisplay']);
			$activateRoomOverlay=trim($displaySettingsArr['activateRoomOverlay']);
			$RoomOverlayValue=trim($displaySettingsArr['RoomOverlayValue']);
			$activate_RoomName2=trim($displaySettingsArr['field1']);
			$roomname2hexCode=trim($appObj->gethexacodeFromRGb($displaySettingsArr['field2']));
			//$show_RoomName2_customIP=trim($displaySettingsArr['field3']);
			$show_RoomName2_customIP=($displaySettingsArr['field3']!='')?$displaySettingsArr['field3']:$check_readfile_ipadd1;
			
			//roomcode values
			$activate_RoomCode=trim($displaySettingsArr['activate_RoomCode']);
			$alwaysShowOnWallp=trim($displaySettingsArr['activate_ShowOnWallpaper']);
			$roomCodeHexaColor=trim($appObj->gethexacodeFromRGb($displaySettingsArr['show_RoomCode_Color']));		
			$activate_RefreshTime=trim($displaySettingsArr['activate_RefreshTime']);
			
			$activate_DateTime=trim($displaySettingsArr['activate_DateTime']);
			$dateTime_HexaColor=trim($appObj->gethexacodeFromRGb($displaySettingsArr['show_DateTime_Wallp_Color']));
			$dateTimeColor=trim($displaySettingsArr['show_DateTime_Wallp_Color']);			
			$qrcode=$displaySettingsArr['qrcode'];
			
			
		}
		
		
		 $timeformat=($check24HourFormat==1)?'24hours':'AM/PM';
		//getting mysql details
		$mySqlCurrentTime=$appObj->getMysqlDateTime();
		list($currentMysqlDate,$currentMysqlTime)=explode(' ',$mySqlCurrentTime);
		list($mysqlHour,$mysqlMins,$mysqlSeconds)=explode(':',$currentMysqlTime);
		$datetimeformat=($timeformat=='24hours')?$mysqlHour.':'.$mysqlMins:date('h:i a', strtotime($mySqlCurrentTime));

	//Geting aspect ratio of image
		$defImg=(GET_OS=='WIN')?'default.jpg':'default.png';
		//getting active wallpaper from tbl_wallpaper
		$activeWallpaperArr=$appObj->getTableAllData("tbl_wallpaper WHERE wallp_is_active=1");
		foreach($activeWallpaperArr as $activeWallpaperValue){
			$activeWallpaper=$activeWallpaperValue['wallp_name'];
		}
		
		
		$activeImagName=($activeWallpaper!='')?$activeWallpaper:$defImg;	
		//if active wallpaper not found then copy default image from default path			
		if(!file_exists(UPLOAD_DIR_ZEND.IMG_DIR.'/large/'.$activeImagName)){									
			if(!file_exists(UPLOAD_DIR_ZEND.IMG_DIR.'large/'.SYSTEM_DEFAULT_IMG)){
				copy(DEST_PATH.SYSTEM_DEFAULT_IMG,UPLOAD_DIR_ZEND.IMG_DIR."large/".$activeImagName);
			}
		}
		
		//getting image info
		$arrImgInfo = getimagesize(UPLOAD_DIR_ZEND.IMG_DIR.'/large/'.$activeImagName);
		$getImageWidth=$arrImgInfo[0];
		$getImageHeight=$arrImgInfo[1];
		$gethcf=$appObj->gethcf($getImageWidth , $getImageHeight);
		$getAspectRaio=($getImageHeight/$gethcf)/($getImageWidth/$gethcf);
		
		
		//now set width and height fix to 1920 and 1080
		$screenWidth=1920;
		$screenHeight=1080;	
		/*if(file_exists($destPath.'resolution.txt')){
			$resolutiondata=trim(file_read($destPath.'resolution.txt'));
			$explodeResolutiondata=explode('*',$resolutiondata);
			$screenWidth=$explodeResolutiondata[0];
			$screenHeight=$explodeResolutiondata[1];	
		}*/
		//getting container width and height
		$contentScreenWidth=$screenWidth-650;		
		$contentScreenHeight=$contentScreenWidth*$getAspectRaio;
		$destWidth=1270;
		$destHeight=714;	
		$fittoscreenHeight=number_format($destHeight/$screenHeight,4);
		$fittoscreenWidth=number_format($destWidth/$screenWidth,4);
		
		//added for getting code popup X and Y
		//$roomcodePopupWidth=305;
		$roomcodePopupHeight=50;
		//$roomcodePopupLeft=intval($contentScreenWidth-$roomcodePopupWidth);
		//$roomcodePopupTop=intval($contentScreenHeight-$roomcodePopupHeight);
		$codepopUptxt='Code : XXXX';
		list($left,, $right)  =  imagettfbbox(48, 0, $cwd.'/verdana.ttf', $codepopUptxt);
		$roomcodepopframewidth = intval(($right - $left)*(3/4))+50;
		$roomcodePopupLeft=intval($contentScreenWidth-(20+$roomcodepopframewidth));
		$roomcodePopupTop=intval(($contentScreenHeight+20)-($contentScreenHeight*.2));
		
		
		$roomnameData=$appObj->getTableAllData("gateway_customize_homepage WHERE FrameID=1");
		$datTimeData=$appObj->getTableAllData("gateway_customize_homepage WHERE FrameID=2");
		$roomcodeData=$appObj->getTableAllData("gateway_customize_homepage WHERE FrameID=3");
		$roomname2Data=$appObj->getTableAllData("gateway_customize_homepage WHERE FrameID=4");
		
		foreach($roomnameData as $roomnameArrayData){
			$roomnameTxt=(($roomnameArrayData['FrameName']!='')?$roomnameArrayData['FrameName']:'Room Name').' : '.trim($appObj->file_read(DEST_PATH.READFILE_IPADD));
			$roomname1TxtStr=(($roomnameArrayData['FrameName']!='')?$roomnameArrayData['FrameName']:'Room Name').' : #roomname#';					
			
			//getting roomname 1 position
			//$roomname1framewidth = ($contentScreenWidth*$roomnameArrayData['FrameWidth']/100);
			$roomname1frameheight = 38;//($contentScreenHeight*$roomnameArrayData['FrameHeight']/100);
			$roomname1frameleft =  intval($contentScreenWidth*$roomnameArrayData['FrameLeft']/100);
			$roomname1frametop =  intval($contentScreenHeight*$roomnameArrayData['FrameTop']/100);	
			list($left,, $right)  =  imagettfbbox(35, 0, $cwd.'/verdana.ttf', $roomnameTxt);
			//converting pt to pixels
			$roomname1framewidth = intval(($right - $left)*(3/4))+25;
			//added on 17Jan2019 for getting roomnanme1 x position when width>xpositon+boxwidth	
			$roomname1Total=intval($roomname1frameleft+$roomname1framewidth);
			if($roomname1Total>$contentScreenWidth){
				$roomname1pos=intval($roomname1frameleft+$roomname1framewidth-$contentScreenWidth+5);
				$roomname1frameleft=intval($roomname1frameleft-$roomname1pos);
			}
			
		}		
	//end
	//Getting Roomname 2 Properties
	foreach($roomname2Data as $roomname2ArrayData){			
		$roomname2Txt=(($roomname2ArrayData['FrameName']!='')?trim($roomname2ArrayData['FrameName']):'Room Name 2').' : '.trim($show_RoomName2_customIP);
		$roomname2TxtStr=(($roomname2ArrayData['FrameName']!='')?trim($roomname2ArrayData['FrameName']):'Room Name 2').' : #roomname#';
		//getting roomname 2 position
		//$roomname2framewidth = ($contentScreenWidth*$roomname2ArrayData['FrameWidth']/100);
		$roomname2frameheight = 38;//($contentScreenHeight*$roomname2ArrayData['FrameHeight']/100);
		$roomname2frameleft =  intval($contentScreenWidth*$roomname2ArrayData['FrameLeft']/100);
		$roomname2frametop =  intval($contentScreenHeight*$roomname2ArrayData['FrameTop']/100);	
		list($left,, $right)  =  imagettfbbox(35, 0, $cwd.'/verdana.ttf', $roomname2Txt);	
		//converting pt to pixels
		$roomname2framewidth = intval(($right - $left)*(3/4))+20;
		//added on 17Jan2019 for getting roomnanme2 x position when width>xpositon+boxwidth	
		$roomname2Total=intval($roomname2frameleft+$roomname2framewidth);
		if($roomname2Total>$contentScreenWidth){
			$roomname2pos=$roomname2frameleft+$roomname2framewidth-$contentScreenWidth+5;
			$roomname2frameleft=intval($roomname2frameleft-$roomname2pos);
		}
		
	}//roomname 2 loop end
	
	//Getting Roomcode Properties	
	foreach($roomcodeData as $roomcodeArrayData){
		$roomcodetxt=trim($roomcodeArrayData['FrameName']).' : #roomcode#';
		//Getting Roomcode Position
		//$roomcodeframewidth = ($contentScreenWidth*$roomcodeArrayData['FrameWidth']/100);
		$roomcodeframeheight = 38;//($contentScreenHeight*$roomcodeArrayData['FrameHeight']/100);
		$roomcodeframeleft =  intval($contentScreenWidth*$roomcodeArrayData['FrameLeft']/100);
		$roomcodeframetop =  intval($contentScreenHeight*$roomcodeArrayData['FrameTop']/100)+5;
		//getting text length
		list($left,, $right)  =  imagettfbbox(35, 0, $cwd.'/verdana.ttf', $roomcodetxt);
		//converting pt to pixels
		$roomcodeframewidth = intval(($right - $left)*(3/4))+50;
		//added on 17Jan2019 for getting roomcode x position when width>xpositon+boxwidth	
		$roomcodeTotal=intval($roomcodeframeleft+$roomcodeframewidth);
		if($roomcodeTotal>$contentScreenWidth){
			$roomcode1pos=intval($roomcodeframeleft+$roomcodeframewidth-$contentScreenWidth+5);
			$roomcodeframeleft=intval($roomcodeframeleft-$roomcode1pos);
		}
		
	}//end roomcode loop
	
	//getting DateTime Properties			
	foreach($datTimeData as $datTimeArrayData){
		//Getting Date Position
		//$dateframewidth = ($contentScreenWidth*$datTimeArrayData['FrameWidth']/100)/2;
		$dateframeheight = 25;//($contentScreenHeight*$datTimeArrayData['FrameHeight']/100);
		$dateframeleft =  intval($contentScreenWidth*$datTimeArrayData['FrameLeft']/100);
		$dateframetop =  intval($contentScreenHeight*$datTimeArrayData['FrameTop']/100);
		//getting date box length
		list($left,, $right)  =  imagettfbbox(20, 0, $cwd.'/verdana.ttf', $datetimeformat.' | '.$appObj->getDefaultDateByLang($lang));
		//converting pt to pixels
		$dateframewidth = intval(($right - $left)*(3/4))+20;
		//added on 17Jan2019 for getting combineddate x position when width>xpositon+boxwidth	
		$datetimeTotal=intval($dateframeleft+$dateframewidth);
		if($datetimeTotal>$contentScreenWidth){
			$datetimepos=intval($dateframeleft+$dateframewidth-$contentScreenWidth+5);
			$dateframeleft=intval($dateframeleft-$datetimepos);
		}
	
	}//end date time foreach loop

//Getting qrcode Properties
$checkQrcodeActive=CHECK_FILE_QRCODE;		
$qrbypass=CHECK_FILE_QRBYPASS;
$qrtop=CHECK_FILE_QRTOP;
//getting calendar settings
$calIsActive=0;
$calQryDataArr=$appObj->getTableAllData('tbl_calendar_properties');		
if(count($calQryDataArr)>0){
	$meetingX1=$fittoscreenWidth*110;
	$meetingX=intval(1270-$meetingX1-286);
	$meetingY1=$fittoscreenHeight*8;
	$meetingY=intval(714/$meetingY1-61);
	foreach($calQryDataArr as $calData){
		$calIsActive=$calData['show_on_via'];
		$inuse_color=($calData['inuse_color']!='')?$calData['inuse_color']:'#ff0000';
		$available_color=($calData['available_color']!='')?$calData['available_color']:'#32cd32';
		$upcoming_color=($calData['upcoming_color']!='')?$calData['upcoming_color']:'#c0c0c0';		
		$inuse_font_color=($calData['inuse_font_color']!='')?$calData['inuse_font_color']:'#ffffff';
		$available_font_color=($calData['available_font_color']!='')?$calData['available_font_color']:'#ffffff';
		$upcoming_font_color=($calData['upcoming_font_color']!='')?$calData['upcoming_font_color']:'#ffffff';
		//$upcoming_font_color=$calData['upcoming_font_color'];
		$show_title=$calData['show_title'];
		$show_orgnizer=$calData['show_orgnizer'];
		$show_on_via=$calData['show_on_via'];
		$show_no_of_record=$calData['show_no_of_record'];
		$meetingBackgroundColor='#000000';
		$titleFontColor='#ffffff';
		$meetingBoxHeight=($show_no_of_record>3)?'400':'324';
	
	}

}	//cal end condition end

$datetimefont='20px';
$othersfont='35px';
$wallpapername='uploads/large/'.$defImg;	
//json code	
$wallpaperJson=array('imagePath'=>$wallpapername,'width'=>intval(trim($contentScreenWidth)),'height'=>intval(trim($contentScreenHeight)));
$jsonValue->wallpaper=(object)$wallpaperJson;
if($activate_RoomName==1){
	$jsonValue->roomname1->posLeft=intval(trim($roomname1frameleft));
	$jsonValue->roomname1->posTop=intval(trim($roomname1frametop));
	$jsonValue->roomname1->width=intval(trim($roomname1framewidth));
	$jsonValue->roomname1->height=intval(trim($roomname1frameheight));
	$jsonValue->roomname1->roomname1Text=$roomname1TxtStr;
	$jsonValue->roomname1->activateRoomName=trim($activate_RoomName);
	$jsonValue->roomname1->showSecondDisplay=trim($activate_RoomName_SecondDisplay);
	$jsonValue->roomname1->activateRoomOverlay=trim($activateRoomOverlay);
	$jsonValue->roomname1->RoomOverlayValue=$RoomOverlayValue;
	$jsonValue->roomname1->backgroundColor='transparent';
	$jsonValue->roomname1->borderColor='';
	$jsonValue->roomname1->fontColor=trim($roomname1hexCode);
	$jsonValue->roomname1->fontSize=$othersfont;
	$jsonValue->roomname1->textAlign='Left';
	$jsonValue->roomname1->opacity='1';
	$jsonValue->roomname1->borderNoneChkbox='0';
	$jsonValue->roomname1->text=$roomname1TxtStr;
	$jsonValue->roomname1->customNameText='';
	$jsonValue->roomname1->autoResize='1';
}

if($check_dualNetworkFile==1 && $activate_RoomName2==1){
	$jsonValue->roomname2->posLeft=intval(trim($roomname2frameleft));
	$jsonValue->roomname2->posTop=intval(trim($roomname2frametop));
	$jsonValue->roomname2->width=intval(trim($roomname2framewidth));
	$jsonValue->roomname2->height=intval(trim($roomname2frameheight));
	$jsonValue->roomname2->roomname2Text=$roomname2TxtStr;
	$jsonValue->roomname2->activateRoomName=trim($activate_RoomName2);
	$jsonValue->roomname2->backgroundColor='transparent';
	$jsonValue->roomname2->borderColor='';
	$jsonValue->roomname2->fontColor=trim($roomname2hexCode);
	$jsonValue->roomname2->fontSize=$othersfont;
	$jsonValue->roomname2->textAlign='Left';
	$jsonValue->roomname2->opacity='1';
	$jsonValue->roomname2->borderNoneChkbox='0';
	$jsonValue->roomname2->text=$roomname2TxtStr;
	$jsonValue->roomname2->autoResize='1';
}	
if($activate_RoomCode==1){
	$jsonValue->roomcode->posLeft=intval(trim($roomcodeframeleft));
	$jsonValue->roomcode->posTop=intval(trim($roomcodeframetop));
	$jsonValue->roomcode->width=intval(trim($roomcodeframewidth));
	$jsonValue->roomcode->height=intval(trim($roomcodeframeheight));
	$jsonValue->roomcode->text=trim($roomcodetxt);
	$jsonValue->roomcode->activateRoomCode=trim($activate_RoomCode);
	$jsonValue->roomcode->activateShowOnWallpaper=trim($alwaysShowOnWallp);
	$jsonValue->roomcode->refreshTime=trim($activate_RefreshTime);
	$jsonValue->roomcode->backgroundColor='transparent';
	$jsonValue->roomcode->borderColor='';
	$jsonValue->roomcode->fontColor=trim($roomCodeHexaColor);
	$jsonValue->roomcode->fontSize=$othersfont;
	$jsonValue->roomcode->textAlign='Left';
	$jsonValue->roomcode->opacity='1';
	$jsonValue->roomcode->showSecondDisplay=trim($activate_RoomName_SecondDisplay);
	$jsonValue->roomcode->borderNoneChkbox='0';
	$jsonValue->roomcode->autoResize='1';
	
	$jsonValue->codepopup->posLeft=intval(trim($roomcodePopupLeft));
	$jsonValue->codepopup->posTop=intval(trim($roomcodePopupTop));
	$jsonValue->codepopup->width=intval(trim($roomcodepopframewidth));
	$jsonValue->codepopup->height=intval(trim($roomcodePopupHeight));
	$jsonValue->codepopup->backgroundColor='#ffffff';
	$jsonValue->codepopup->borderColor='';
	$jsonValue->codepopup->fontColor='#000000';
	$jsonValue->codepopup->fontSize='48px';
	$jsonValue->codepopup->textAlign='Vertical';
	$jsonValue->codepopup->opacity='1';
	$jsonValue->codepopup->borderNoneChkbox='0';
	$jsonValue->codepopup->showSecondDisplay=trim($activate_RoomName_SecondDisplay);
}
if($activate_DateTime==1){
	$jsonValue->datetimecombined->posLeft=intval(trim($dateframeleft));
	$jsonValue->datetimecombined->posTop=intval(trim($dateframetop));
	$jsonValue->datetimecombined->width=intval(trim($dateframewidth));
	$jsonValue->datetimecombined->height=intval(trim($dateframeheight));
	$jsonValue->datetimecombined->activateDatetimecombined=trim($activate_DateTime);
	$jsonValue->datetimecombined->dateTimeFormat=trim($timeformat);
	$jsonValue->datetimecombined->backgroundColor='transparent';
	$jsonValue->datetimecombined->borderColor='';
	$jsonValue->datetimecombined->fontColor=trim($dateTime_HexaColor);
	$jsonValue->datetimecombined->fontSize=$datetimefont;
	$jsonValue->datetimecombined->textAlign='Right';
	$jsonValue->datetimecombined->opacity='1';
	$jsonValue->datetimecombined->borderNoneChkbox='0';
	$jsonValue->datetimecombined->autoResize='1';
	$jsonValue->datetimecombined->showSecondDisplay='0';
}
if($checkQrcodeActive==1){
	$qrpointFileData=file_get_contents(DEST_PATH.FILE_QRPOINT);
	$explodeQRPointFile=explode(',',$qrpointFileData);
	$qrcodeX=intval(trim($explodeQRPointFile[0])*$fittoscreenWidth);
	$qrcodeY=intval(trim($explodeQRPointFile[1])*$fittoscreenHeight);
	$qrcodeW=intval(trim($explodeQRPointFile[2])*$fittoscreenWidth);
	$qrcodeH=intval(trim($explodeQRPointFile[3])*$fittoscreenHeight);
	
	$jsonValue->qrcode->posLeft=intval($qrcodeX);
	$jsonValue->qrcode->posTop=intval($qrcodeY);
	$jsonValue->qrcode->width=intval($qrcodeW);
	$jsonValue->qrcode->height=intval($qrcodeH);
	$jsonValue->qrcode->checkQrcodeFile='1';
	$jsonValue->qrcode->checkQrbypassFile=$qrbypass;
	$jsonValue->qrcode->checkQrtopFile=$qrtop;
	$jsonValue->qrcode->showSecondDisplay='0';
}
if($calIsActive==1){
	$jsonValue->upcomingmeetings->posLeft=intval(trim($meetingX));
	$jsonValue->upcomingmeetings->posTop=intval(trim($meetingY));
	$jsonValue->upcomingmeetings->width=284;
	$jsonValue->upcomingmeetings->height=intval($meetingBoxHeight);
	$jsonValue->upcomingmeetings->showTitle=trim($show_title);
	$jsonValue->upcomingmeetings->showOrganisor=trim($show_orgnizer);
	$jsonValue->upcomingmeetings->meetingRecords=trim($show_no_of_record);
	$jsonValue->upcomingmeetings->meetingupcomingEventsColor=trim($upcoming_color);
	$jsonValue->upcomingmeetings->meetinginuseEventsColor=trim($inuse_color);
	$jsonValue->upcomingmeetings->meetingavailableEventsColor=trim($available_color);
	$jsonValue->upcomingmeetings->meetingupcomingfontColor=trim($upcoming_font_color);
	$jsonValue->upcomingmeetings->meetinginusefontcolor=trim($inuse_font_color);
	$jsonValue->upcomingmeetings->meetingavailablefontcolor=trim($available_font_color);
	$jsonValue->upcomingmeetings->backgroundColor=trim($meetingBackgroundColor);
	$jsonValue->upcomingmeetings->meetingTitleBackgroundColor=trim($meetingBackgroundColor);
	$jsonValue->upcomingmeetings->meetingTitleFontColor=trim($titleFontColor);
	$jsonValue->upcomingmeetings->meetingTitleFontsize='18px';
	$jsonValue->upcomingmeetings->meetingfontsize=$jsonValue->upcomingmeetings->meetingTitleFontsize;
	$jsonValue->upcomingmeetings->opacity='.4';
	$jsonValue->upcomingmeetings->timeFormat='24';
	$jsonValue->upcomingmeetings->showSecondDisplay='0';
}
if($calIsActive==1){
	$meetingNotifyX=intval(234*$fittoscreenWidth);
	$meetingNotifyY=intval(714-($fittoscreenHeight*480));				
	$jsonValue->meetingnotify->posLeft=intval(trim($meetingNotifyX));
	$jsonValue->meetingnotify->posTop=intval(trim($meetingNotifyY));
	$jsonValue->meetingnotify->width=410;
	$jsonValue->meetingnotify->height=104;
	$jsonValue->meetingnotify->backgroundColor='#000000';
	$jsonValue->meetingnotify->borderColor='#35acf8';
	$jsonValue->meetingnotify->fontColor='#ffffff';
	$jsonValue->meetingnotify->topTextFontSize='18px';
	$jsonValue->meetingnotify->middleTextFontSize='36px';
	$jsonValue->meetingnotify->bottomTextFontSize='18px';
	$jsonValue->meetingnotify->lineProperty='multiple';
	$jsonValue->meetingnotify->opacity='.4';
	$jsonValue->meetingnotify->displayAlert='3';
	$jsonValue->meetingnotify->borderNoneChkbox='0';
	$jsonValue->meetingnotify->availability='0';
	$jsonValue->meetingnotify->showSecondDisplay='0';
}

$jsonContent = json_encode($jsonValue, JSON_PRETTY_PRINT);
$qryArr=$appObj->getTableAllData("tbl_templates WHERE template_name='default'");		
		if(count($qryArr)==0){
			$finalImg='uploads/large/'.$defImg;
			//$appObj->executeQueries("INSERT INTO tbl_templates SET template_name='default',status=1,wallpaper_name='$finalImg', modifydatetime=now()");	
			$appObj->executeQueries("INSERT INTO tbl_templates (id, template_name, status, created_at, wallpaper_name,modifydatetime, model_type) VALUES (1, 'default',1,now(),'$finalImg',now(),".PRODUCT_MODEL_TYPE.");");

			/* ********************* making data encrypted ************************ */
			/*list($wifiSecurityFilekey,$wifiSecurityFileIV)=explode('#',$appObj->getWifiSecurityKey());
			if(strlen($wifiSecurityFilekey)==0 || strlen($wifiSecurityFileIV)==0){
				echo 'nokey';
				exit;
			}*/
			$encryptedStr=$appObj->desEncrypt($jsonContent,POLL_ENCRPTION_KEY);
			/* end */
			
					
			$fileName=TEMPLATE_DIR_ZEND.'default.json';	
			$myfile = fopen($fileName, 'w') or die("can't open file");
			$confWrite= fwrite($myfile, $encryptedStr);
			fclose($myfile);
		}
		//die('created successfuly');
 }

    //set the http status code
    public function SetReponseCode($result_data) { 	
            $this->getResponse()->setStatusCode(RESPONSE_SUCCESS);
            return $result_data;
    }
	
    /***************
     * Name    : make_safe
     * Desc    : decode the data in base64
     * *************/

    public function make_safe($string){
            $string = trim($string);
            /*if($this->decode == 1) {
                    $string = base64_decode($string);
            } */
            return $string;
    }

    /****************
     * Name    : base64encode
     * Desc    : encode the data in base64
     * *************/

    public function base64encode($string){
           $string = trim($string);
           /*if($this->decode == 1) {
                   $string = base64_encode($string);
           }*/
           return $string;
    }


   /*****
    *	Function Name		: getConnection
    *  description			: Create the db_adapter connection
*	Author			    : Dileep Kumar
    *****/

    public function getConnection(){ 
	    $dbAdapterConfig = array(
           'driver'   => 'Mysqli',
           'database' => DB_NAME,
           'username' => DB_USER,
           'password' => DB_PASSWORD
	    );
	    $dbAdapter = new Adapter($dbAdapterConfig); 
	    $driver = $dbAdapter->getDriver();
	    $connection = $driver->getConnection();
	    return $connection;
   }

   public function createViaSettingsTemplateOnUpgradeAction(){
   		$appObj = new ApplicationController();
		$viaModel=$appObj->getModelNameByParam('model');
		$modellike=$appObj->getModelNameByParam('modellike');
		$sysLog = file_exists(DEST_PATH . READFILE_ENABLELOG)?1:0;
		if(file_exists(DEST_PATH.FILE_ENERGYSAVER_MODE)){
			$energysaver = 1;
			$sleep_time = file_get_contents(DEST_PATH.FILE_ENERGYSAVER_MODE);
			$sleepTime = ($sleep_time=='')?10:$sleep_time;
		}else{
			$energysaver = 0;
			$sleepTime = 10;
		}
		$quickClientAccess=(file_exists(DEST_PATH.READFILE_QUICK))?1:0;
		$advanceConfig = $appObj->getTableAllData('tbl_advance_configuration')->current();
		$apiCmd = $advanceConfig['feature5'];
		$setLang = $appObj->file_read(DEST_PATH.READFILE_LANGTXT);
		$mirroring = $appObj->file_read(DEST_PATH.FILE_MIRRORNAME);
		$chrome = $advanceConfig['feature9'];
		$miracast = file_exists(DEST_PATH.FILE_MIRACAST)?1:0;
		$frequency = file_exists(LIN_WIFI_PATH.FILE_MIRACAST_FREQUENCY)?$appObj->file_read(LIN_WIFI_PATH.FILE_MIRACAST_FREQUENCY):0;
		$activateDNDChkbox = file_exists(DEST_PATH.FILE_DND)?1:0;
		$resetSession = $this->getAdvanceMoreFeaturesTable()->fetchProperty('ResetSession');
		$dspEncodeValueStatus = $this->getAdvanceMoreFeaturesTable()->fetchProperty('DspEncodeValue');
		$encoding = ($dspEncodeValueStatus==1)?'h264':'jpeg';
		if(DEST_PATH.FILE_AUTO_POWEROFF == 1) {
			$autoPowerOff = 1;
			$autoPowerOffData = $appObj->file_read(DEST_PATH.FILE_AUTO_POWEROFF);
			list($selhoursdd, $selminsdd)= explode(':', $autoPowerOffData);
		}else{
			$autoPowerOff = 0;
			$selhoursdd = '00';
			$selminsdd = '00';
		}
		$autoPowerOffTime=($autoPowerOff==1)?$selhoursdd.':'.$selminsdd:'00:00';
		if(DEST_PATH . FILE_AUTO_REBOOT == 1) {
			$autoReboot = 1;
			$autoRebootData = $appObj->file_read(DEST_PATH . FILE_AUTO_REBOOT);
			list($autoRebootHours, $autoRebootMints)= explode(':', $autoRebootData);
		}else{
			$autoReboot = 0;
			$autoRebootHours = '00';
			$autoRebootMints = '00';
		}
		$autoRebootTime = ($autoReboot==1)?$autoRebootHours.':'.$autoRebootMints:'00:00';
		$autoPowerOn = 0;
		$autoPowerOnTime = '00:00';
		$selDateFormatDD = file_exists(DEST_PATH.FILE_DATEFORMAT)?$appObj->file_read(DEST_PATH.FILE_DATEFORMAT):'Y-m-d H:i:s';
		$timezoneArray = $appObj->returnQueryData("SELECT * FROM tbl_timezones WHERE tz_active_status=1 AND osType=0");
		if($timezoneArray->count() > 0){
			$timezone = $timezoneArray->current();
			$timezoneConfigBox = $timezone['tz_name'];
			$winTimezoneConfigBox = $timezone['tz_name'];
		}else{
			$timezoneConfigBox = 'Asia/Kolkata';
			$winTimezoneConfigBox = '(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi';
		}
		
		$hdmiInputNotStart = file_exists(DEST_PATH.FILE_NOPIP)?1:0;
		$pipMode = file_exists(DEST_PATH.READFILE_PIP)?1:0;
		$activateHDMIChkbox = $this->getAdvanceMoreFeaturesTable()->fetchProperty('DefHDMIMod');
		$manualOnOff = 0;
		$clearCloud = $advanceConfig['feature1'];
		$closeWhiteBoardBtn = $advanceConfig['feature3'];
		$setDynamicLayout = file_exists(DEST_PATH.FILE_LAYOUT)?1:0;
		$dynamicLayoutChkbox = file_exists(DEST_PATH.FILE_LAYOUT)?$appObj->file_read(DEST_PATH.FILE_LAYOUT):0;
		$dpiConfigBox = $advanceConfig['feature2'];
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut,captcha,field1 FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData = $sessiondata['sessionTimeOut'];
			$captchaVal = $sessiondata['captcha'];
			$broadcastVal = $sessiondata['field1'];
		}
		$logoutTime = ($getSettingData>0)?$getSettingData:10;
		$getCaptcha = ($captchaVal!='')?$captchaVal:1;
		$broadcast = ($broadcastVal!='')?$broadcastVal:1;
		$securitySetting = $appObj->returnQueryData("SELECT * FROM complexpassword ORDER BY id DESC LIMIT 1")->current();
		
		$getAlplhanumric = $securitySetting['alphanumeric'];
		$getSpecialChar = $securitySetting['specialchar'];
		$getCaptLetter = $securitySetting['capitalltr'];
		$minimumChar = $securitySetting['minimumchar'];
		$getBasicModeFlag = $securitySetting['applyin_basicmode'];
		$getRecording = $advanceConfig['feature4'];
		$transferRecordingPath = $appObj->returnQueryData("SELECT * FROM tbl_recording_transfer")->current();
		$transferRecording = $transferRecordingPath['transfer_option'];
		$proxyQry = $appObj->returnQueryData("SELECT servername,port,username,AES_DECRYPT(password,'" . POLL_ENCRYPTION_KEY . "') as password FROM tbl_proxy_setting")->current();
		$proxyServerName = $proxyQry['servername'];
		$proxyPort = $proxyQry['port'];
		$proxyUserName = $proxyQry['username'];
		$proxyPassword = $proxyQry['password'];
		$host_config = '';
		$certificateData = $this->getCertificatesTable()->getCertificateCount();
		$certFile = CERTIFICATE_UPLOAD_PATH."/".$certificateData['cert_file_name'];
		$keyFile = CERTIFICATE_UPLOAD_PATH."/".$certificateData['key_file_name'];
		if(file_exists($certFile)){
			$via_certificate = file_get_contents($certFile);
		}else{
			$via_certificate = '';
		}
		if(file_exists($keyFile)){
			$certificateKey = file_get_contents($keyFile);
		}else{
			$certificateKey = '';
		}
		
		$audioOutput = '';
		$audioLevel = $this->getAdvanceMoreFeaturesTable()->fetchProperty('DefAudioSetting');
		$zoomVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('Zoom');
		$bluejeansVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('BlueJeans');
		$msTeamVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('MSTeams');
		$TPCollabAppCloseVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('TPCollabAppClose');
		$thirdpartyapp = file_exists(DEST_PATH.FILE_THIRDPARTYSHORTCUT)?1:0;
		$mediamode = file_exists(DEST_PATH.READFILE_MEDIA)?1:0;

		$rcount = $this->getTblGatewayFeaturesPositionTable()->getGwayFeaturesPositionCount();
		if($rcount==0){
			$this->getTblGatewayFeaturesTable()->updateFeatureStatus('1');
			$gway_sql = $this->getTblGatewayFeaturesTable()->fetchAll('');
		}else{
			$gway_sql = $this->getTblGatewayFeaturesTable()->fetchAllWithPosition();
		}
		foreach ($gway_sql as $value) {
			$gway_str .= $value['feature_btn_name'].'$'.$value['feature_status'].'#';
		}
		
		$rcount = $this->getTblClientFeaturesPositionTable()->getClientsFeaturesPositionCount();
        if($rcount==0){
            $this->getTblClientFeaturesTable()->updateFeatureStatus('1');
            $client_sql = $this->getTblClientFeaturesTable()->fetchAll('');
        }else{
            $client_sql = $this->getTblClientFeaturesTable()->fetchAllWithPosition();
        }
        foreach ($client_sql as $value) {
			$client_str .= $value['feature_btn_name'].'$'.$value['feature_status'].'#';
		}
		$rcount = $this->getTblMobileFeaturesPositionTable()->getMobileFeaturesPositionCount();
        if($rcount==0){
            $this->getTblMobileFeaturesTable()->updateFeatureStatus('1');
            $mobile_sql = $this->getTblMobileFeaturesTable()->fetchAll('');
        }else{
            $mobile_sql = $this->getTblMobileFeaturesTable()->fetchAllWithPosition();
        }
        foreach ($mobile_sql as $value) {
			$mobile_str .= $value['feature_btn_name'].'$'.$value['feature_status'].'#';
		}

		$presentationMode = file_exists(DEST_PATH.READFILE_CHKPRESENTATION_MODE)?1:0;
		$moderator_type = file_get_contents(DEST_PATH.READFILE_CHKPRESENTATION_MODE);
		$participantConfChkboxSql = $this->getAdvanceConfigurationTable()->getParticipantCheckboxVal()->current();
		$participantConfChkbox = $participantConfChkboxSql->feature6;
		$wait_moderatorSql = $this->getAdvanceMoreFeaturesTable()->getAdavnceMoreFeatures()->current();
		$wait_moderator = $wait_moderatorSql->ivalue;
		$activateChatChkbox = file_exists(DEST_PATH.FILE_CHAT)?1:0;
		if(CHECKFILE_ADSETTINGS == 1) {
			$myfile = DEST_PATH.READFILE_STRADSETTINGS;
			$fp = fopen($myfile, "r");
			if($fp) {
				$myarr = array();

				while(!feof($fp)) {
					$fcontent = fgets($fp, filesize($myfile));
					if($fcontent != "") {
						array_push($myarr, $fcontent);
					}
				}
			}
			$adDomain = $myarr[0];
			$moderatorValue = $myarr[1];
			$participantValue = $myarr[2];
			if($myarr[3] == '')
				$accountName = 0;
			else 
				$accountName = trim($myarr[3]);
		}else{
			$adDomain = '';
			$accountName = 0;
			$moderatorValue = '';
			$participantValue = '';
		}
		if(FILE_STROUGROUP == 1) {
			$file = DEST_PATH . READFILE_STROUGROUP;
			$arr = file_get_contents($file);
			$group_ou = $arr[0];
		}else{
			$group_ou = 1;
		}
		$viaAdminpassSql = $appObj->returnQueryData("SELECT * FROM appuserlist WHERE apploginname='su'")->current();
		$viaAdminPassword = ($viaAdminpassSql['password']!='')?$viaAdminpassSql['password']:'';
		$basicpassSql = $appObj->returnQueryData("SELECT * FROM tbl_basicauthentication")->current();	
		$viaBasicPassword = ($basicpassSql['password']!='')?$basicpassSql['password']:'';
		//changes for single code
		if(CHECK_FILE_MIRRORNAME == 1) {
			$mirrorName = $appObj->file_read(DEST_PATH.FILE_MIRRORNAME);
		}else{
			$mirrorName = '';
		}
		if(CHECK_FILE_MIRROR_MAXCON == 1) {
			$maxNoOfMirrors = $appObj->file_read(DEST_PATH.FILE_MIRROR_MAXCON);
		}else{
			$maxNoOfMirrors = '';
		}
		$fileFormatData = $this->getAuthFileFormatTable()->fetchAllData();
		$new_formatArr = array();
		foreach ($fileFormatData as $key => $value) {
			$new_formatArr[$key]['ext_name'] = $value['fileformat'];
			$new_formatArr[$key]['status'] = $value['formatstatus'];
		}
		$authFileArray = $new_formatArr;	
		
		$ntpArray = array();
		$getNTPData = $this->getNtpServerTable()->getNtp(); 
		foreach ($getNTPData as $ntp_key=>$ntp_value){ 
			$ntpArray[]=array("ntp_name"=>$ntp_value['ntp_name'],"ntp_uuid"=>$ntp_value['ntp_uuid']);
		}

		if($modellike==0){
			$collageGwayfeaturesStr = trim(substr($gway_str,0,-1));
			$collageClientfeaturesStr = trim(substr($client_str,0,-1));
			$collageMobfeaturesStr = trim(substr($mobile_str,0,-1));
			$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>$broadcast,"thirdparty_app"=>$thirdpartyapp),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"gway_features"=>array('0'=>$collageGwayfeaturesStr),
				"client_features"=>array('0'=>$collageClientfeaturesStr),
				"mobile_features"=>array('0'=>$collageMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
				)
			);
		}elseif($modellike==1){
				$connectGwayfeaturesStr = trim(substr($gway_str,0,-1));
				$connectClientfeaturesStr = trim(substr($client_str,0,-1));
				$connectMobfeaturesStr = trim(substr($mobile_str,0,-1));
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>$broadcast,"thirdparty_app"=>$thirdpartyapp),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"gway_features"=>array('1'=>$connectGwayfeaturesStrr),
				"client_features"=>array('1'=>$connectClientfeaturesStr),
				"mobile_features"=>array('1'=>$connectMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName),				
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
				)
				);				
			}elseif($modellike==2){
				$campusGwayfeaturesStr = trim(substr($gway_str,0,-1));
				$campusClientfeaturesStr = trim(substr($client_str,0,-1));
				$campusMobfeaturesStr = trim(substr($mobile_str,0,-1));
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>$broadcast,"thirdparty_app"=>$thirdpartyapp),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"gway_features"=>array('2'=>$campusGwayfeaturesStr),
				"client_features"=>array('2'=>$campusClientfeaturesStr),
				"mobile_features"=>array('2'=>$campusMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
				)
				);				
			}elseif($modellike==3){
				$viagoClientfeaturesStr = trim(substr($client_str,0,-1));
				$viagoMobfeaturesStr = trim(substr($mobile_str,0,-1));
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>$broadcast,"thirdparty_app"=>$thirdpartyapp),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"client_features"=>array('3'=>$viagoClientfeaturesStr),
				"mobile_features"=>array('3'=>$viagoMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
				)
				);				
			}elseif($modellike==4){
				$connectplusGwayfeaturesStr = trim(substr($gway_str,0,-1));
				$connectplusClientfeaturesStr = trim(substr($client_str,0,-1));
				$connectplusMobfeaturesStr = trim(substr($mobile_str,0,-1));
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>$broadcast,"thirdparty_app"=>$thirdpartyapp),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"gway_features"=>array('4'=>$connectplusGwayfeaturesStr),
				"client_features"=>array('4'=>$connectplusClintfeaturesStr),
				"mobile_features"=>array('4'=>$connectplusMobfeaturesStr),	
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName),							
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
				)
			);
		}
		$encodedData = json_encode($arr,true);
		$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRYPTION_KEY);
		$myFile = UPLOAD_DIR_ZEND."uploads/".TEMPLATE_DIR_CONFIG.'settings_1.json';
		file_put_contents($myFile, $encryptedJson);
		$templateName = 'template1';
		$whereArr=array('template_name'=>$templateName);
		$dataArr=array('template_name'=>$templateName,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>'uploads/'.TEMPLATE_DIR_CONFIG.'settings_1.json','modifydatetime'=>date('Y-m-d H:i:s'));
		$checkCount=$this->getViaSettingsTemplatesTable()->checkTemplate($whereArr);
		if($checkCount==0){
			$last_insert_id = $this->getViaSettingsTemplatesTable()->insertData($dataArr);	
		}
		echo 'upgrade setting template created successfully';die;
		//echo '<pre>';print_r(json_decode($encodedData));die;
    }
	
	/*	Created by ashu to upgrade mirroring name and  max connection */
	/*	upgarde default settings json */
	/*	Execute from cron *************/
	public function upgradeSettingsDefaultTemplateAction(){	
		$appObj = new ApplicationController();
		$settingFile=DEST_PATH.VIA_SETTINGS_DEFAULT_JSON_FILE;
		$mirroringName=file_get_contents(DEST_PATH . FILE_MIRRORNAME);
		$mirrorMaxConn=file_get_contents(DEST_PATH . FILE_MIRROR_MAXCON);	
		if(file_exists($settingFile)){
			$response=file_get_contents($settingFile);
			//decrypt json					
				$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRPTION_KEY);
				if($decryptResponse!=''){
					$jsonArray=json_decode($decryptResponse, true);
					//system Array
					$jsonArray['VIA_CONFIG_TEMPLATE']['via_details']['airplayname']=$mirroringName;
					$jsonArray['VIA_CONFIG_TEMPLATE']['via_details']['airplay_number']=$mirrorMaxConn;
					//Encrypt to json
					$encodedData = json_encode($jsonArray,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);
					file_put_contents($settingFile, $encryptedJson);
					die('Template updated successfully');
				}
			
		}else{
			die('Default file doesn\'t exist');
		}
		
	}
	
	/* Web Service Created by ashu on 19Aug2021 for User Authentication */	
	public function authenticateUserAction(){
		$appObj = new ApplicationController();
		if(isset($_POST['username'])) $username=trim($_POST['username']);
		if(isset($_POST['userpass'])) $userpass=trim($_POST['userpass']);				
		if($username==''){
			die('user_error');
		}elseif($userpass==''){
			die('pass_error');
		}
		$userpass=$appObj->securePassword($userpass);		
		$userDataArray = $appObj->returnQueryData("SELECT * FROM appuserlist WHERE apploginname='".$username."' AND password='".$userpass."'");
		if($userDataArray->count() > 0){
			die('valid');
		}else{
			die('invalid');
		}
	}
	
	/*	Created by ashu on 20/12/2022 */
	/*	upgrade dnsname tag in active template */
	/*	Execute from cron *************/
	public function modifyRoomnameAction(){
			if(isset($_REQUEST['ssid'])){
				$ssid="VIA_".trim($_REQUEST['ssid']);
			}			
			$appObj = new ApplicationController();
			//modified code by ashu on 30Dec22 for getting model like
			$modellike=$appObj->getModelNameByParam('modellike');
					
			$getActiveTemplateSql = $appObj->returnQueryData("SELECT status,template_path FROM tbl_via_settings_templates WHERE status=1");
			$templateStatus=0;
			foreach($getActiveTemplateSql as $activeTemplateData){						
				$templateStatus = $activeTemplateData['status'];
				$templatepath = $activeTemplateData['template_path'];				
			}			
			$sourceSettingFile = UPLOAD_DIR_ZEND.$templatepath;
			$settingsFile = DEST_PATH.'via_settings.json';
		
		//modified by ashu on 20DEc22 for Updating dns name/roomname in active tyemplate
			$sourceFile_content=file_get_contents($sourceSettingFile);		
			//decrypt json					
			$decryptSourceFile = $appObj->desDecrypt($sourceFile_content,POLL_ENCRPTION_KEY);
			$jsonArrayy=json_decode($decryptSourceFile, true);			
			$via_details_arr = $jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'];	            
			$via_details_arr['dnsname']=$ssid;					
			$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'] = $via_details_arr;	
			$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = 3;
			
			//fix file extension issue.
			if($modellike==0){
				$get_gwayFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features'];								
				$gwayFeaturesKeyArr=array_keys($get_gwayFeatures);
				$gwayFeaturesValArr=$get_gwayFeatures[0];
				$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features']=(object)[0=>$gwayFeaturesValArr];
				
				$get_clientFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features'];							
				$clientFeaturesKeyArr=array_keys($get_clientFeatures);
				$clientFeatureskey=$clientFeaturesKeyArr[0];
				$clientFeaturesValArr=$get_clientFeatures[0];						
				$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=(object)[0=>$clientFeaturesValArr];

				$get_mobFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features'];								
				$mobFeaturesKeyArr=array_keys($get_mobFeatures);
				$mobFeaturesValArr=$mobFeaturesKeyArr[0];
				$mobFeaturesValArr=$get_mobFeatures[0];
				$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=(object)[0=>$mobFeaturesValArr];					
			}						
			
			
			//Encrypt to json				
			$encodedData = json_encode($jsonArrayy,JSON_FORCE_OBJECT);	
			$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);										
			file_put_contents($sourceSettingFile, $encryptedJson);			
		//end Updating dns name/roomname in active tyemplate
			//put ssid value in roomnamevalueshow.txt
			$roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
			file_put_contents($roomnameTxtFile, $ssid);			
		
			copy($sourceSettingFile, $settingsFile);
				
	}	
	
	/*	Created by ashu on 22/12/2022. modifyRoomnameQTAction is calling from QT */
	/*	upgrade dnsname tag in active template */
	/*	Execute from cron *************/
	public function modifyRoomnameQTAction(){
			// takes json data from the request 
			$jsonArrData = json_decode(file_get_contents('php://input'), true);
			$ssid=$jsonArrData['ssidname'];
			$roomType = $jsonArrData['roomtype'];

			$appObj = new ApplicationController();
			//modified code by ashu on 30Dec22 for getting model like
			$modellike=$appObj->getModelNameByParam('modellike');					
			$getActiveTemplateSql = $appObj->returnQueryData("SELECT status,template_path FROM tbl_via_settings_templates WHERE status=1");
			$templateStatus=0;
			foreach($getActiveTemplateSql as $activeTemplateData){						
				$templateStatus = $activeTemplateData['status'];
				$templatepath = $activeTemplateData['template_path'];				
			}			
			$sourceSettingFile = UPLOAD_DIR_ZEND.$templatepath;
			$settingsFile = DEST_PATH.'via_settings.json';
		
		//modified by ashu on 20DEc22 for Updating dns name/roomname in active tyemplate
			$sourceFile_content=file_get_contents($sourceSettingFile);		
			//decrypt json					
			$decryptSourceFile = $appObj->desDecrypt($sourceFile_content,POLL_ENCRPTION_KEY);
			$jsonArrayy=json_decode($decryptSourceFile, true);			
			$via_details_arr = $jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'];	            
			$via_details_arr['dnsname']=$ssid;					
			$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'] = $via_details_arr;	
			$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = $roomType;
			//fix file extension issue.
			if($modellike==0){
				$get_gwayFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features'];								
				$gwayFeaturesKeyArr=array_keys($get_gwayFeatures);
				$gwayFeaturesValArr=$get_gwayFeatures[0];
				$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features']=(object)[0=>$gwayFeaturesValArr];
				
				$get_clientFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features'];							
				$clientFeaturesKeyArr=array_keys($get_clientFeatures);
				$clientFeatureskey=$clientFeaturesKeyArr[0];
				$clientFeaturesValArr=$get_clientFeatures[0];						
				$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=(object)[0=>$clientFeaturesValArr];

				$get_mobFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features'];								
				$mobFeaturesKeyArr=array_keys($get_mobFeatures);
				$mobFeaturesValArr=$mobFeaturesKeyArr[0];
				$mobFeaturesValArr=$get_mobFeatures[0];
				$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=(object)[0=>$mobFeaturesValArr];					
			}						
			
			
							
			//Encrypt to json				
			$encodedData = json_encode($jsonArrayy,JSON_FORCE_OBJECT);	
			$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);										
			file_put_contents($sourceSettingFile, $encryptedJson);
			//put ssid value in roomnamevalueshow.txt
			$roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
			file_put_contents($roomnameTxtFile, $ssid);			
		//end Updating dns name/roomname in active tyemplate
			copy($sourceSettingFile, $settingsFile);
			die('success');				
	}
	

    public function getTblGatewayFeaturesTable(){
        if (!$this->TblGatewayFeaturesTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblGatewayFeaturesTable = $sm->get('Webapp\Model\TblGatewayFeaturesTable');
        }
        return $this->TblGatewayFeaturesTable;
    }
    
    public function getTblGatewayFeaturesPositionTable(){
        if (!$this->TblGatewayFeaturesPositionTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblGatewayFeaturesPositionTable = $sm->get('Webapp\Model\TblGatewayFeaturesPositionTable');
        }
        return $this->TblGatewayFeaturesPositionTable;
    }
        
    public function getTblGatewayFeatureTempTable(){
        if (!$this->TblFeatureTempTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblFeatureTempTable = $sm->get('Webapp\Model\TblFeatureTempTable');
        }
        return $this->TblFeatureTempTable;
    }
        
	public function getTblClientFeaturesTable() {
		if(!$this->TblClientsFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
		}
		return $this->TblClientsFeaturesTable;
	}
        
    public function getTblClientFeaturesPositionTable(){
        if (!$this->TblClientsFeaturesPositionTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblClientsFeaturesPositionTable = $sm->get('Webapp\Model\TblClientsFeaturesPositionTable');
        }
        return $this->TblClientsFeaturesPositionTable;
    }
    
    public function getTblClientFeatureTempTable(){
        if (!$this->TblClientsFeatureTempTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblClientsFeatureTempTable = $sm->get('Webapp\Model\TblClientsFeatureTempTable');
        }
        return $this->TblClientsFeatureTempTable;
    }
        
	public function getTblMobileFeaturesTable() {
		if(!$this->TblMobileFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblMobileFeaturesTable = $sm->get('Webapp\Model\TblMobileFeaturesTable');
		}
		return $this->TblMobileFeaturesTable;
	}
        
    public function getTblMobileFeaturesPositionTable(){
        if (!$this->TblMobileFeaturesPositionTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblMobileFeaturesPositionTable = $sm->get('Webapp\Model\TblMobileFeaturesPositionTable');
        }
        return $this->TblMobileFeaturesPositionTable;
    }

    public function getTblMobileFeatureTempTable(){
        if (!$this->TblMobileFeatureTempTable) {	
            $sm = $this->getServiceLocator();		
            $this->TblMobileFeatureTempTable = $sm->get('Webapp\Model\TblMobileFeatureTempTable');
        }
        return $this->TblMobileFeatureTempTable;
    }
    
    public function getAdvanceConfigurationTable() {
		if(!$this->TblAdvanceConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationTable = $sm->get('Webapp\Model\TblAdvanceConfigurationTable');
		}
		return $this->TblAdvanceConfigurationTable;
	}

    public function getAdvanceMoreFeaturesTable() {
		if(!$this->TblAdvanceMoreFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceMoreFeaturesTable = $sm->get('Webapp\Model\TblAdvanceMoreFeaturesTable');
		}
		return $this->TblAdvanceMoreFeaturesTable;
	}

	public function getAuthFileFormatTable() {
		if(!$this->TblAuthFileFormatTable) {
			$sm = $this->getServiceLocator();
			$this->TblAuthFileFormatTable = $sm->get('Webapp\Model\TblAuthFileFormatTable');
		}
		return $this->TblAuthFileFormatTable;
	}

	public function getNtpServerTable() {
        if(!$this->TblNtpServerTable) {
            $sm = $this->getServiceLocator();
            $this->TblNtpServerTable = $sm->get('Webapp\Model\TblNtpServerTable');
        }
        return $this->TblNtpServerTable;
	}

	public function getCertificatesTable() {
        if(!$this->TblCertificatesTable) {
            $sm = $this->getServiceLocator();
            $this->TblCertificatesTable = $sm->get('Webapp\Model\TblCertificatesTable');
        }
        return $this->TblCertificatesTable;
	}

	public function getViaSettingsTemplatesTable() {
		if (!$this->TblViaSettingsTemplatesTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblViaSettingsTemplatesTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesTable');
			
		}
		return $this->TblViaSettingsTemplatesTable;
	}

	public function getAppuserListTable() {
		if(!$this->TblAppuserListTable) {
			$sm = $this->getServiceLocator();
			$this->TblAppuserListTable = $sm->get('Webapp\Model\TblAppuserListTable');
		}
		return $this->TblAppuserListTable;
	}
	

}
