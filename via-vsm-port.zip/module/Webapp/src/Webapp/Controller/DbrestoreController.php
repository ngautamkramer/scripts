<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Controller\ApplicationController;

class DbrestoreController extends AbstractActionController {
        
        public function indexAction(){
            $appObj = new ApplicationController();
            $con = $appObj->getConnection();
            $DBName = DB_NAME;
            $getOS = GET_OS;
			//Based on this dbrestoreflag flag we are showing dbstore UI or redirecting to index page. When truncate the table then this flag is using to restrict redirect to index page
			if(isset($_GET['dbrestoreflag'])){
				$dbrestoreflag=trim($appObj->desDecrypt(trim($_GET['dbrestoreflag']), KEY_SEED));								
			}else{
				$dbrestoreflag=1;
			}
					
            $this->layout('layout/default-db-restore');            
            $wpgTableCount = $appObj->tableCount();            
            $chkTblCnt=$con->execute("SELECT COUNT(*) AS tablecount FROM information_schema.tables WHERE table_schema = 'public'")->current();            
            $getHostIP=$_SERVER['SERVER_ADDR'];
			//Based on this dbrestoreflag flag we are showing dbstore UI or redirecting to index page. When truncate the table then this flag is using to restrict redirect to index page.bcoz in that case table count is equals to db count 
           if($getHostIP!="127.0.0.1" && ($chkTblCnt['tablecount'] == $wpgTableCount && $dbrestoreflag==1)){
                return $this->redirect()->toRoute('index',array('action' => 'index'));
                exit;
           }
        }

	//for restore default tables
	/*public function defaultDbRestoreAction() {
        $dbpass = DB_PASSWORD;
        $DBName = DB_NAME;
        //backup file path
        $db_backup_path = (GET_OS == "LIN") ? "/home/Collab8/config/wpg_backup.sql" : "C:/tc/config/wpg_backup.sql";
        if(file_exists($db_backup_path)){
            $importCommand = '';
            if(GET_OS == "LIN"){
                // for linux Gateway
                $importCommand = "mysql --user=root --password=$dbpass  $DBName < $db_backup_path";
            }else{
                // for windows Gateway
                $importCommand = "C:\MySQL\MySQL8\bin\mysql.exe --user=root --password=$dbpass $DBName < $db_backup_path";
            }
            exec($importCommand, $output, $retval);
            if($retval == 0) {
                echo "success";die;
            }else{
                echo "failure";die;
            }
        }else{
            echo "failure"; die;
        }

	}*/

    //for restore default tables
    public function defaultDbRestoreAction() {
            $appObj = new ApplicationController();
            $con = $appObj->getConnection();
            if($con){
                $DBName = DB_NAME;
                $dbpass = DB_PASSWORD;
				$dbhost = HOST_NAME;
                $getHostIP=$_SERVER['SERVER_ADDR'];                
        /******************************Importing databse ******************************************************************** */
                $db_backup_path = (GET_OS == "LIN") ? "/home/Collab8/config/wpg_pgsql_backup.sql" : (file_exists(DEST_PATH.FILE_SESSION_MANAGER) ? "C:/ProgramData/KRAMER/tc/config/wpg_pgsql_backup.sql" : "C:/tc/config/wpg_pgsql_backup.sql");
				if(file_exists($db_backup_path)){
					$importCommand = '';
					if(GET_OS == "LIN"){
						// for linux Gateway
						//$importCommand = "mysql --user=root --password=$dbpass  $DBName < $db_backup_path";
						putenv("PGPASSWORD=$dbpass");
						$importCommand = "/usr/local/pgsql/bin/psql -h $dbhost -U postgres -d $DBName < $db_backup_path";
					
					}else{
						// for windows Gateway
						if(file_exists(DEST_PATH.FILE_SESSION_MANAGER)){
							putenv("PGPASSWORD=$dbpass");
							$importCommand = "\"C:\Program Files\KRAMER\pgsql\bin\psql.exe\" -U postgres -d $DBName < $db_backup_path";
						}else{
							putenv("PGPASSWORD=$dbpass");
							$importCommand = "\"C:\pgsql\bin\psql.exe\" -U postgres -d $DBName < $db_backup_path";
						}
					}
					exec($importCommand, $output, $retval);
					if($retval == 1 || $retval == 0){

			/****************** Create default wallpaper ********************** */ 
						if(GET_OS=='WIN'){
								$imgExt='.jpg';
								$defImgName='default.jpg';
								$source_img = DEST_PATH.'windowDefault.jpg';
								$defImg = 'default.jpg';
						}
						if(GET_OS=='LIN'){
								$imgExt='.png';
								$defImgName='Default.png';
								$source_img = DEST_PATH.'linuxDefault.png';
								$defImg = 'default.png';
						}                                   
						copy(DEST_PATH.SYSTEM_DEFAULT_IMG,DEST_PATH.$defImgName);// or die('Default image not found');
						copy(DEST_PATH.$defImgName,HTML_PUBLIC_DIR.'/uploads/large/'.$defImgName);// or die('Default image not found');
						
						//deleting all template files                   
						$files = glob(TEMPLATE_DIR_ZEND.'*');
						foreach($files as $file){
						  if(is_file($file))
								unlink($file);
						}
						//remove all wallpapers                    
						$wallpfiles = glob(HTML_PUBLIC_DIR.'/uploads/large/*');
						foreach($wallpfiles as $wallfile){ 
						  if(is_file($wallfile))
								unlink($wallfile);
						}
						
						//create default template               
						if(GET_OS=='WIN'){
							$source_json = DEST_PATH.'windowDefault.json';
						}else{
							$source_json = DEST_PATH.'linuxDefault.json';
						}
				   
						$dest_img = HTML_PUBLIC_DIR.'/uploads/large/'.$defImg;
						$dest_json = HTML_PUBLIC_DIR.'/uploads/templates/default.json';
						copy($source_img,$dest_img);
						copy($source_json,$dest_json);
			/*************** end create default wallpaper ********************* */ 
			

			/*************** Mirroring proccess ********************* */
						if(GET_OS == 'WIN') {
							$last4digit =(CHECK_SERIALNO_FILE == 1)? '_' . substr($appObj->file_read(DEST_PATH . SERIALNO_FILE), - 4): '';
						}
						$gwayMacAddr = "";
						if(GET_OS == 'LIN') {
							$gwayMacAddr = $appObj->file_read(DEST_PATH.FILE_MAC_ADDRESS);
							$last4digit =($gwayMacAddr != "")? '_' . substr(str_replace(':', '', $gwayMacAddr), 0, -2): '';
						}
						$myfile1 = fopen(DEST_PATH.FILE_MIRRORNAME, 'w');
						fwrite($myfile1, FILE_MIRRORNAME_TEXT .$last4digit);
						$myfile2 = fopen(DEST_PATH.FILE_MIRROR_MAXCON, 'w');
						fwrite($myfile2, FILE_MIRROR_MAX_CONN);
			/*************** end Mirroring proccess ********************* */



			/*************** Create settings template*************************** */
						$networkArr = $appObj->getNetworkBasicInfoAction();
						if($networkArr['Lan1_Host']!=''){
							$get_roomname = $networkArr['Lan1_Host'];
						}else{
							$get_roomname = $networkArr['wifi1_Host'];
						}
						$roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
						file_put_contents($roomnameTxtFile, $get_roomname);
						if(file_exists(DEST_PATH."model.json")){
							$sourceFile = DEST_PATH."settings_default.json";
							$settingsFile = DEST_PATH.'via_settings.json';
							
							if(file_exists($settingsFile)){
								unlink($settingsFile);
							}
							copy($sourceFile, $settingsFile);
							//update dns in via_settings.json
							$settingFile_content=file_get_contents($settingsFile);  
							//decrypt json                  
							$decryptSettingFile = $appObj->desDecrypt($settingFile_content,POLL_ENCRPTION_KEY);
							$jsonArray=json_decode($decryptSettingFile, true);
							//update thirdparty Array. now zoom and teams will be off 
							$via_details_arr = $jsonArray['VIA_CONFIG_TEMPLATE']['via_details'];
							$via_details_arr['dnsname'] =$get_roomname;                         
							$jsonArray['VIA_CONFIG_TEMPLATE']['via_details'] = $via_details_arr;
							//add room name type 2 for host radio button
							$jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = 2;
							//Encrypt to json               
							$encodedData = json_encode($jsonArray,true);    
							$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);              
							file_put_contents($settingsFile, $encryptedJson);
							//end
							
							
							$settingPath = glob(UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'*');
							foreach($settingPath as $file){
							  if(is_file($file) && $file != $sourceFile){
									unlink($file);
							  }
							}
							$defaultFile = UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'default.json';
							//modified by ashu. Now copying updated via_settings.json to default.json coz it contans dns name
							copy($settingsFile, $defaultFile);
						}
			/*************** end settings template ********************* */ 
						
			/*******************  reset dss  *************************/
						//deleting all media files              
						$files = glob(UPLOAD_CONTENT_MEDIA.'*');                
						foreach($files as $file){ // iterate files
						  if(is_file($file))
							unlink($file); // delete file
						}               
						$campainFiles = glob(UPLOAD_DSS_CAMPAIGN.'*');
						foreach($campainFiles as $file){ // iterate files
						  if(is_file($file))
							unlink($file); // delete file
						}

						$files = glob(FONT_UPLOAD_PATH.'*');
						$leave_files=array('fontawesome-webfont.woff');
						foreach($files as $file){ // iterate files
							if( !in_array(basename($file), $leave_files) ){
								  if(is_file($file))
									unlink($file); // delete file                   
							}
						}   
			/*******************  end reset dss  *************************/	

						///reset timezone
						$defailtTimezone = GET_OS == "WIN" ? '(UTC) Coordinated Universal Time' : 'UTC';
						$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
						$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetTimeZone</Cmd><P1>$defailtTimezone</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
						$appObj->sendMsgToAPIserver($logincmd,$actionCmd);


						//rebooting gateways
						$usrInput="reboot";
						$res=$appObj->reboot_powerOff_Server($usrInput);    
						if($res==1){
							if($usrInput=='reboot'){
								echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";                                       
							}       
						}       
						
					}else{
						echo "failure";die;
					}
				}else{
                        echo "failure"; die;
                    }

               
            }else{
                    echo "failure";die;
            }
            die;
    }
        
}