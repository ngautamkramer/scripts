<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\TtfInfo\TtfInfo;

class CloudLicenseController extends AbstractActionController {	
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		if(PRODUCT=='via'){
			$getSettingObj = $appObj->getComplexPasswordSettings();
			$getSettingData = $getSettingObj->webadmin_session_timeout;
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
			foreach($tblSessionTimeOutDataArr as $sessiondata){
				$getSettingData=$sessiondata['logoutTime'];
			}
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if($tblSessionCheckdataArr->count()>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
	
	public function licenceAction() {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$wifiSecurityFilekey = "1324587099345678";
		$appObj = new ApplicationController();
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$licenseFile = $this->params()->fromFiles('licenseFile');
				$licenseFileName = $licenseFile['name'];
				$upload = move_uploaded_file($licenseFile['tmp_name'], UPLOAD_DIR_ZEND.$licenseFileName);
				$uploadedFileContent=file_get_contents(UPLOAD_DIR_ZEND.$licenseFileName);
				//decrypt file
				$decrypted = $appObj->desDecrypt($uploadedFileContent,$wifiSecurityFilekey);
				
				//Get Domain
				$url = 'https://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF'];				
				$parse = parse_url($url);
				$host = $parse['host'];
				$url_domain = str_ireplace('www.', '', $host);
				
				//explode uploaded file data
				$explode_decrypted_arr=explode("|",$decrypted);
				$file_domain=trim($explode_decrypted_arr[0]);
				$orderId=trim($explode_decrypted_arr[1]);
				$no_of_devices=trim($explode_decrypted_arr[2]);
				$purchase_date=trim($explode_decrypted_arr[3]);
				$license_validity=trim($explode_decrypted_arr[4]);
				$license_expiry_date_timestamp = strtotime("+$license_validity months", strtotime($purchase_date)); // returns timestamp
				$license_expiry_date =date('Y-m-d',$license_expiry_date_timestamp); // formatted version
				//die($file_domain.' and '.$orderId);
				
				//check order id in database				
				$checkOrderCount =$this->getLicenseMasterTable()->getOrderCount($orderId);
				$error='';
				if($file_domain!=$url_domain){
					//die('domain_error');
					$error='domain_error';
				}elseif($checkOrderCount>0){
					//die('order_error');
					$error='order_error';
				}else{
					$licenseDataArr = array('uniqueid'=>substr(md5(microtime()), 0, 5), 'orderid'=>$orderId,'no_of_devices'=>$no_of_devices,'purchase_date'=>$purchase_date,'license_validity'=>$license_validity,'license_expiry_date'=>$license_expiry_date,'number_of_lic_used'=>0);
					$certificateflag = $this->getLicenseMasterTable()->inserDataForDssFont($licenseDataArr);
					$error='success';
				}

              return new ViewModel(array(                 
				'error_flag'=>$error,   
                )
            );   
								
				
						
		}
	}


	public function getLicenseMasterTable() {
		if(!$this->TblLicenseMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblLicenseMasterTable = $sm->get('Webapp\Model\TblLicenseMasterTable');
		}
		return $this->TblLicenseMasterTable;
	}


	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}


}