<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Form\AddAlertForm;;

class AlertController extends AbstractActionController {


    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}


    public function alertListAction()
    {
        if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $appObj = new ApplicationController();
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $request = $this->getRequest();
        $alertThresholdArray=array(20,40,50,80,100);
        $query="SELECT * FROM tbl_alert_parameter WHERE alert_status=1 AND id NOT IN (3,4,1)";
        $queryResult = $appObj->returnQueryData($query);
        $rowsCount=$queryResult->count();
        $form=new AddAlertForm($alertThresholdArray);
        $startDate = date("Y-m-d");
        $enddate='';
        $form->setData(array('startdate' => $startDate,'enddate'=>$enddate));
        $data=$this->getAlertInfoTable()->fetchAll();
        return new ViewModel(array('data'=>$data,'userId'=>$user_id,'form'=>$form,'queryResult'=>$queryResult,'rowsCount'=>$rowsCount));
    }

      /*****
	 *	@Function Name: addAlertAction
	 *  @description  : add alert
	 *	@Author		  : Vineet
	 *  @Date         : 23-april-2020
	 *****/
    public function addEditAlertAction()
    {
        $appObj = new ApplicationController();
        $alert_ids=htmlspecialchars($_POST['alert_ids']);
        $lastpicid=htmlspecialchars($_POST['lastUserId']);
        $minthresholdValue=htmlspecialchars($_POST['minthresholdValue']);
        $descValue=htmlspecialchars($_POST['descValue']);
        $startDateValue=htmlspecialchars($_POST['startDateValue']);
        $endDateValue=($_POST['endDateValue'] !="" ? $_POST['endDateValue'] : "0000-00-00");
        $userLoggedNameStr=strtolower(trim($_POST['userLoggedNameStr']));
        $qrery="SELECT appuserid FROM appuserlist WHERE apploginname='$userLoggedNameStr'";
        $queryResult = $appObj->returnQueryData($qrery);
        $result=$queryResult->current();
        $getLoggedInUserId=$result['appuserid'];

        if(isset($_POST['alert_id']) && !empty($_POST['alert_id'])){
			$aID= htmlspecialchars($_POST['alert_id']);
         }
      
        if($lastpicid!="" && $startDateValue!=""){
            if(!empty($aID)){ 
                $this->getAlertInfoTable()->updateAlert($minthresholdValue,$descValue,$startDateValue,$endDateValue,$aID);
            }else{
              $this->getAlertInfoTable()->insertAlert($getLoggedInUserId,$alert_ids,$minthresholdValue,$descValue,$startDateValue,$endDateValue);
            }
            echo 'success';die;
        }
        else{
			echo "Enter the value";die; 
		 }
    }

      /*****
	 *	@Function Name: getAlertdataAction
	 *  @description  : get alert data
	 *	@Author		  : Vineet
	 *  @Date         : 24-april-2020
	 *****/
    public function getAlertdataAction(){
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
		$data = $request->getPost('data');
        $alert_id=$_POST['id'];
        $result=$this->getAlertInfoTable()->getAlertById($alert_id);
        $temp = array('id' =>$result->id,
        'minVal' =>$result->min_threshold_value,
        'description'=>$result->description,
        'start_date'=>$result->start_date,
	    'end_date'=>$result->end_date,
        );
        $view = new JsonModel(array('success' => $temp));
		$view->setTerminal(true);
		return $view;
         
        }
    }


    /*****
	 *	@Function Name: deleteAlertAction
	 *  @description  : delete alert by id
	 *	@Author		  : Vineet
	 *  @Date         : 24-april-2020
	 *****/
    public function deleteAlertAction()
    {
        $session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
        $alertId = $this->params()->fromRoute('id');
        //return $this->redirect()->toRoute('alert');
        if($user_id==1)
        {
            $this->getAlertInfoTable()->delete($alertId);
            $this->getAlertMappingTable()->delete($alertId);
            echo "success";die;
        }
        else{
            $result= $this->getAlertMappingTable()->countAlert($alertId);
            $data=$result->current();
            if($data['num']==0){
                $this->getAlertInfoTable()->delete($alertId);
                $this->getAlertMappingTable()->delete($alertId);
                echo "success";die;
            }
            else{
                echo "This alert is in use by other users of system, it can’t be deleted at this point.";die;
            }
        }
    }

      /*****
	 *	@Function Name: showAlertAction
	 *  @description  : view alert by id
	 *	@Author		  : Vineet
	 *  @Date         : 27-april-2020
	 *****/
    public function showAlertAction()
    {
        $layout = $this->layout();
        $appObj = new ApplicationController();
        //$layout->setTemplate('layout/default');
        $session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
        $alertId=$_POST['id'];
          if($user_id!=1){
              $query= "SELECT GROUP_CONCAT(DISTINCT(group_id_fk)) as group_id FROM tbl_user_access WHERE user_id_fk=$user_id";
              $queryResult = $appObj->returnQueryData($query);
              $row= $queryResult->current();
              $getRow=$row['group_id'];

               // Userlist 
               $queryResult=$this->getAlertMappingTable()->showAlertById($alertId,$getRow);
              // $result2=$this->getAlertMappingTable()->showAlert($alert_id,$getRow);
           
             $qry2="SELECT DISTINCT(B.DeviceName),B.DID,B.DeviceIP,B.DeviceGroupID FROM tbl_alert_mapping A
              LEFT JOIN DeviceInventory B ON B.DID=A.device_id_fk WHERE A.alert_id_fk=$alertId AND B.DeviceGroupID IN ($getRow)";

          }
          else{
              // Userlist 
              $queryResult=$this->getAlertMappingTable()->showUserListByAlertId($alertId);
              //$result2=$this->getAlertMappingTable()->showGatewayAlertId($alertId);
     
          // Gateway 
          $qry2="SELECT DISTINCT(B.DeviceName),B.DID,B.DeviceIP,B.DeviceGroupID FROM tbl_alert_mapping A
              LEFT JOIN DeviceInventory B ON B.DID=A.device_id_fk WHERE A.alert_id_fk=$alertId";	
          }
          $count=$queryResult->count();
          if($count>0){
          $str.='<button class="delAlrt btn btn-viablue btn-s-xs" style="float:right;margin-bottom: 5px;">Delete</button>';
          $str.='</br>';
          $str.='</br>';
          }
           $str.= '<table class="table tbl1" id="printTbl" style="max-width:700 !important">';
           if($count>0){
           
            $i=0;
            $j=0;
           foreach($queryResult as $row){
             if($row['appuserid']){
              $gatewayData= $qry2." AND A.user_id_fk=".$row['appuserid']." ";        
              $viaArr = $appObj->returnQueryData($gatewayData);
             }
            if($viaArr->count() >0){ 
                
                $str.='<tr>';
                $str.='<th style="border-right: 0px;"><span style="float:left;">Alert Going To :'.$row['apploginname'].'</span></th>';
                $str.='<th style="border-left: 0px;"><span style="float:left;">Email :'.$row['email'].'</span></th>';
                $str.='<th width="10%" ><input type="checkbox" name="checkAll" id="checkAll-'.$i.'" class="checkAll makeCboxEnabled"><label for="checkAll-'.$i.'"><span></span></label></th>';
                $str.='</tr>';

                foreach($viaArr as $row2){
                    $gatewayIp=$row2['DeviceIP']!=''?" ( IP: ".$row2['DeviceIP']." )":"";
                    
                    $str.='<tr>';
                    $str.= '<td width="80%" colspan="2">'.$row2['DeviceName'].$gatewayIp.'</td>';
                    $str.= '<td width="10%">';
                    $str.= '<input type="checkbox" id="note-'.$j.'" class="note-'.$i.' pointer makeCboxEnabled" value='.$row['appuserid']."&&".$row2['DID']."&&".$alertId.'><label for="note-'.$j.'"><span></span></label>';
                    $str.= '</td>';
                    $str.= '</tr>';
                    $j++;
                }
                $i++;
            }
           }
        }
        else{
            $str.= '<tr>';
            $str.='<td colspan="3" align="center">'.MSG_NO_RECORD_FOUND.'</td>';
            $str.='</tr>';
        }
        $str.= '<tr>';
        $str.='<td colspan="9"></td>';
        $str.='</tr>';
        $str.='</table>';
		 
        echo $str ;
        die;
     }

    /*****
	 *	@Function Name: deleteAlertGatewayAction
	 *  @description  : delete view alert by id
	 *	@Author		  : Vineet
	 *  @Date         : 27-april-2020
	 *****/
     public function deleteAlertGatewayAction(){
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        
        $getGwayIdArr=explode(",",trim($_POST['chkBoxId']));
        $appObj = new ApplicationController();
        foreach($getGwayIdArr as $val){
           $chkBoxVal=explode("&&",$val);
           $qrs="DELETE FROM tbl_alert_mapping WHERE user_id_fk='".$chkBoxVal[0]."' AND device_id_fk='".$chkBoxVal[1]."' AND alert_id_fk='".$chkBoxVal[2]."' ";
           $rs= $appObj->executeQueries($qrs); 
            $alertId=$chkBoxVal[2];
            try{
                if($user_id !=1){
                    
                     $getData=$appObj->returnQueryData("SELECT GROUP_CONCAT(DISTINCT(group_id_fk)) as group_id FROM tbl_user_access WHERE user_id_fk=$userId");
                     $getRow=$getData->current();
                     $getRow=$getRow['group_id'];	
                     
                     // Userlist 
                     $queryResult=$this->getAlertMappingTable()->showAlertById($alert_id,$getRow);
                     
                     $qry2="SELECT DISTINCT(B.DeviceName),B.DID,B.DeviceIP,B.DeviceGroupID FROM tbl_alert_mapping A
                        LEFT JOIN DeviceInventory B ON B.DID=A.device_id_fk WHERE A.alert_id_fk=$alertId AND B.DeviceGroupID IN ($getRow)";
                }else{
                     //Userlist 
                     $queryResult=$this->getAlertMappingTable()->showUserListByAlertId($alertId);
                
                     // Gateway 
                     $qry2="SELECT DISTINCT(B.DeviceName),B.DID,B.DeviceIP,B.DeviceGroupID FROM tbl_alert_mapping A
                         LEFT JOIN DeviceInventory B ON B.DID=A.device_id_fk WHERE A.alert_id_fk=$alertId";	
                }
            
            }catch(\Exception $e){
                echo "Something went wrong.";die;
            }
            
            $count=$queryResult->count();
        }
            if($count>0){
                $str.='<button class="delAlrt btn btn-viablue btn-s-xs" style="float:right;margin-bottom: 5px;">Delete</button>';
                $str.='</br>';
                $str.='</br>';
                }
                $str.= '<table class="table tbl1" id="printTbl" style="max-width:700 !important">';
                if($count>0){
                 $i=0;
                 $j=0;
                foreach($queryResult as $row){
                   $gatewayData= $qry2." AND A.user_id_fk='".$row['appuserid']."'";              
                   $viaArr = $appObj->returnQueryData($gatewayData);
                 if($viaArr->count() >0){ 
                     
                     $str.='<tr>';
                     $str.='<th style="border-right: 0px;"><span style="float:left;">Alert Going To :'.$row['apploginname'].'</span></th>';
                     $str.='<th style="border-left: 0px;"><span style="float:left;">Email :'.$row['email'].'</span></th>';
                     $str.='<th align="center"><div><input type="checkbox" name="checkAll" id="checkAll-'.$i.'" class="checkAll makeCboxEnabled"><label for="checkAll-'.$i.'"><span></span></label></div></th>';
                     $str.='</tr>';
     
                     foreach($viaArr as $row2){
                         $gatewayIp=$row2['DeviceIP']!=''?" ( IP: ".$row2['DeviceIP']." )":"";
                         $str.='<tr>';
                         $str.= '<td colspan="2">'.$row2['DeviceName'].$gatewayIp.'</td>';
                         $str.= '<td>';
                         $str.= '<input type="checkbox" id="note-'.$j.'" class="note-'.$i.' pointer makeCboxEnabled" value='.$row['appuserid']."&&".$row2['DID']."&&".$alertId.'><label for="note-'.$j.'"><span></span></label>';
                         $str.= '</td>';
                         $str.= '</tr>';
                         $j++;
                     }
                     $i++;
                 }
                }

            }
            else{
                $str.= '<tr>';
                $str.='<td colspan="3" align="center">'.MSG_NO_RECORD_FOUND.'</td>';
                $str.='</tr>';
            }
            $str.= '<tr>';
            $str.='<td colspan="3"></td>';
            $str.='</tr>';
            $str.='</table>';
            echo $str ;
            die;
        }

      /*****
	 *	@Function Name: setAlertAction
	 *  @description  : set view alert
	 *	@Author		  : Vineet
	 *  @Date         : 27-april-2020
	 *****/
    public function setViewAlertAction(){
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $appObj = new ApplicationController();
        $alertId=$_POST['id'];
        $alertType=$_POST['atype'];
        $poll_encryption_key= POLL_ENCRYPTION_KEY;
        /* **************************** Gateway Stauts Report *************** */
        if($grpIdsData!=''){
            if($user_id==1){
                  $checkSql=$appObj->returnQueryData("SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                         INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                                         INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                         WHERE 1 AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1");
              }else{
                  $checkSql=$appObj->returnQueryData("SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                         INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                                         INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                         INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                                         WHERE TUA.user_id_fk=$user_id AND B.os_type!=-1");
             }
           if($checkSql->count()>0){
                if($user_id==1){
                    $qry="SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                          INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                          INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                          WHERE 1 AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1";
                }else{
                     $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                           INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                           INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                           INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                           WHERE TUA.user_id_fk=$user_id AND  B.os_type!=-1";
                }
           }else{
                if($user_id==1){
                    $qry="SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                          INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                          INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                          WHERE 1 AND B.os_type!=-1";
                }else{
                     $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                           INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                           INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                           INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                           WHERE TUA.user_id_fk=$user_id AND B.os_type!=-1"; 
               }
           }
            
        }
        else{
            
            if($user_id==1){
               
                $qry="SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                      INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                      INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                      WHERE 1 AND B.os_type!=-1";
            }else{
               $grpData=$appObj->returnQueryData("select DISTINCT(group_id_fk) from tbl_user_access where user_id_fk=$user_id");
                if($grpData->count() > 0 ){
                   // while($grpRow=mysql_fetch_array($grpData)){
                       foreach($grpData as $grpRow ){
                        $grpIds .=$grpRow['group_id_fk'].",";
                    }
                    $grpIds=rtrim($grpIds,",");
                }
                
               $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                     INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                     INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                     WHERE B.DeviceGroupID IN ($grpIds) AND B.os_type!=-1";
           }
        }
        $sql2   = $qry;

            /* ***************  For processing Groups *************** */
            
            $qry1="SELECT * FROM devicegroup";
            $result=$appObj->returnQueryData($qry1);
            $arrayCategories = array();
            foreach($result as $row ){
 	        $arrayCategories[$row['DeviceGroupID']] = array("parent_id" => $row['DeviceMasterID'], "name" =>$row['DeviceGroup'],"grp_ID" =>$row['DeviceGroupID']);   
            }

         
              if($result->count()!=0){
                $str.=$this->createTreeView2($arrayCategories,0);
                 }
        
              $results = $appObj->returnQueryData("SELECT * FROM appuserlist WHERE appuserid<>1");
              $str1.='<input type="hidden" id="aid" value='.$alertId.'>';

              $str1.='<input type="hidden" name="checLastClickSide" id="checLastClickSide" value='.$this->getLastClickValue().'>';
       
              $str1.='<table class="table"> 
			  <tr> 
			  <td class="font-bold border-Top">'.STR_USERNAME.'</td>
			  <td class="font-bold border-Top">'.STR_EMAIL.'</td>
              <td  style="text-align:right" class="border-Top"><input type="checkbox" id="selUserChkBox" class="makeCboxEnabled"><label for="selUserChkBox"><span></span></label>
              </td>
              </tr>';
            
              
              if($results->count()>0){
                $count=0; 
                
                    foreach($results as $row){
                        $str1.='<tr>';
                        $str1.='<td style="word-break:break-all;width:20%">'.$row['apploginname'].'</td>';
                        $str1.='<td style="word-break:break-all;width:50%">'.$row['email'].'</td>';
                        $str1.='<td align="right">';
                        $str1.='<input type="checkbox" class="alertId makeCboxEnabled" id="alertId'.$row['appuserid'].'" name="alertId" value='.$row['appuserid'].'><label for="alertId'.$row['appuserid'].'"><span></span></label>';
                        $str1.='</td>';
                        $str1.='</tr>';

              }}else{
                $str1.='<tr><td colspan="3" align="center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
              }

              $str1.= '<tr>
              <td colspan="3"></td>
              </tr>';
              $str1.='</table>';
             
        $finalQry="$qry ORDER BY B.DeviceGroupID ASC";
        $sql=$appObj->returnQueryData($finalQry);
        if($sql->count()>0){
                foreach($sql as $fetch){
                    $counter++;	

						if($fetch['Network_status']==1){ $nwImage=$iconNWGreen; $nwTitle="ON";}
						if($fetch['Network_status']==0 || $fetch['Network_status']==-1){ $nwImage=$iconNWRed; $nwTitle="OFF";}
                        if($fetch['Network_status']==2){ $nwImage=$iconNWGreen; $nwTitle=$titleDisplay;}
						if($fetch['CPU_Status']<=50){ $cpuImage=$iconCPUGreen; $cpuTitle="Normal";}
						if($fetch['CPU_Status']>50 && $fetch['CPU_Status']<=80){ $cpuImage=$iconCPUYello; $cpuTitle="Moderate";}
						if($fetch['CPU_Status']>80){ $cpuImage=$iconCPURed; $cpuTitle="High";}
						
						if($fetch['HD_Status']<=50){ $HDImage=$iconHDnormal; $HDTitle="Normal";}
						if($fetch['HD_Status']>50 && $fetch['HD_Status']<=70){ $HDImage=$iconHDModerate; $HDTitle="Moderate";}
						if($fetch['HD_Status']>70){ $HDImage=$iconHDhigh; $HDTitle="High";}		
						
						if($fetch['wallpaper_status']==0){ $wallPStatusImg=$iconHQRed_notdownloaded; $wallpImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['wallpaper_status']==1){ $wallPStatusImg=$iconHQGreen_downloaded; $wallpImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['wallpaper_status']==2){ $wallPStatusImg=$icon_via_Set; $wallpImgMouseOverTxt=$vsmTitleGray;}
						//if($fetch['gatewayFeaturesStatus']==0){ $gwayFeatureStatusImg=$iconHQRed_notdownloaded; $gwayImgMouseOverTxt=$vsmTitleRed;}
						//if($fetch['gatewayFeaturesStatus']==1){ $gwayFeatureStatusImg=$iconHQGreen_downloaded; $gwayImgMouseOverTxt=$vsmTitleGreen;}
						//if($fetch['gatewayFeaturesStatus']==2){ $gwayFeatureStatusImg=$icon_via_Set; $gwayImgMouseOverTxt=$vsmTitleGray;}									
						if($fetch['clientFeaturesStatus']==0){ $clintFeatureStatusImg=$iconHQRed_notdownloaded; $clientImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['clientFeaturesStatus']==1){ $clintFeatureStatusImg=$iconHQGreen_downloaded; $clientImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['clientFeaturesStatus']==2){ $clintFeatureStatusImg=$icon_via_Set; $clientImgMouseOverTxt=$vsmTitleGray;}	
						// Condition added by ashu to show if dateTimesetting field has value 0 then always configSetting will show as RED i.e. (Status 0)
						if( ($fetch['dateTimeSettingStatus']==0 && ($fetch['configSettingStatus']==0 || $fetch['configSettingStatus']==1 || $fetch['configSettingStatus']==2)) || ($fetch['dateTimeSettingStatus']==1 && $fetch['configSettingStatus']==0)  ){
							 $configStatusImg=$iconHQRed_notdownloaded;
							 $configImgMouseOverTxt=$vsmTitleRed;
						}else{									
							if($fetch['configSettingStatus']==0){ $configStatusImg=$iconHQRed_notdownloaded; $configImgMouseOverTxt=$vsmTitleRed;}
							if($fetch['configSettingStatus']==1){ $configStatusImg=$iconHQGreen_downloaded; $configImgMouseOverTxt=$vsmTitleGreen;}
							if($fetch['configSettingStatus']==2){ $configStatusImg=$icon_via_Set; $configImgMouseOverTxt=$vsmTitleGray;}
						}	
						
						if($fetch['dateTimeSettingStatus']==0){ $dateTimeStatusImg=$iconHQRed_notdownloaded;}
						if($fetch['dateTimeSettingStatus']==1){ $dateTimeStatusImg=$iconHQGreen_downloaded;}
						if($fetch['dateTimeSettingStatus']==2){ $dateTimeStatusImg=$icon_via_Set;}			
			
						if($fetch['authSettingStatus']==0){ $authStatusImg=$iconHQRed_notdownloaded; $authImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['authSettingStatus']==1){ $authStatusImg=$iconHQGreen_downloaded; $authImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['authSettingStatus']==2){ $authStatusImg=$icon_via_Set; $authImgMouseOverTxt=$vsmTitleGray;}
						
						if($fetch['mobileFeaturesStatus']==0){ $mobileStatusImg=$iconHQRed_notdownloaded; $mobImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['mobileFeaturesStatus']==1){ $mobileStatusImg=$iconHQGreen_downloaded; $mobImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['mobileFeaturesStatus']==2){ $mobileStatusImg=$icon_via_Set; $mobImgMouseOverTxt=$vsmTitleGray;}
									
						$imgMouseOverTxt="Gateway Status Report"; 
					  	$sqlGatewayInfo=$appObj->returnQueryData("SELECT DeviceName,DeviceIP,Active,oldIPAddess FROM DeviceInventory WHERE DID=".$fetch['DID']);	

                          if($sqlGatewayInfo){
                            $gatewayInfoArr=$sqlGatewayInfo->current();
                            $myGatewayName=$gatewayInfoArr['DeviceName'];
                            $misMatchNote='';
                            if($gatewayInfoArr[2]!='Y'){					  	
                                $misMatchNote=($gatewayInfoArr[3]!="" && $gatewayInfoArr[1]!=$gatewayInfoArr[3])?'#':'';				
                            }
                                
                        }
                        $grpID=$fetch['DeviceGroupID'];
						$newGrp=$appObj->getGroupName($grpID);
						if(strstr($newGrp,' ')){
							$newGrp=str_replace(' ','',$newGrp);
						}
								
						//$immediateParenGrpName=getImmediateParent($grpID);
						$hdStatus=($fetch['HD_Status']!=-1)?"<img src=$HDImage title=".$fetch['HD_Status'].'%'." width=32 height=32>":$sysReportPgBlank;
						$cpuStatus=($fetch['CPU_Status']!=-1)?"<img src=$cpuImage title=".$fetch['CPU_Status'].'%'." width=32 height=32>":$sysReportPgBlank;
						$version=($fetch['Version']!=-1)?$fetch['Version']:'';
						$lastActivity=($fetch['Last_Updated_Time']!='0000-00-00 00:00:00')?date($date_format,strtotime($fetch['Last_Updated_Time'])) :$sysReportPgDateNull;
						
						$selChkBox='';
                        //Warning: $gwayIdStrArr array is not defined or gets value in project.
						// if(in_array($fetch['DID'],$gwayIdStrArr)){
						// 	$selChkBox='checked';
						// }
						if($fetch['field2'] !=""){ 
							$validity=date('Y-m-d', $fetch['field2']);
							$validity1=strtotime($validity);
						}else{
							$validity="";
						}
							$strRow.="<tr id='row_".$fetch['DID']."' class='abc grpCss_".$newGrp."'><td>$myGatewayName&nbsp;<span class='noteHeading'>$misMatchNote</span></td><td>".$appObj->getGroupName($fetch['DeviceGroupID'])."</td><td align='center'><input type='checkbox' name='gwayCheckBox' id='gwayCheckBox_".$fetch['DID']."' value=".$fetch['DID']." class='chkbox makeCboxEnabled".$newGrp."' rev=".$fetch['DID']." ".$selChkBox."><label for='gwayCheckBox_".$fetch['DID']."' class='text-dark pointer'><span></span></label></td></tr>";
			
            }



                }else{
					$strRow.="<tr><td colspan=3 align='center'><strong>There is no validated gateway available in the group(s) you selected. Please validate the same and try again.</strong></td></tr>";
                }
                

                   $selAllDisabled='';					
					if($appObj->returnQueryData($sql2)->count()==0){
						$selAllDisabled='disabled';
                    }
                    $str2.='<table class="table" id="punchHtml">';
                    $str2.='<tr>
                    <td class="font-bold border-Top">'.STR_GATEWAY_NAME.'</td>
                    <td class="font-bold border-Top">'.STR_GROUP_NAME.'</td>
                    <td align="center" class="border-Top">
                    <input type="checkbox" name="selAllChkBox" id="selAllChkBox"  class="makeCboxEnabled" '.$selAllDisabled.'><label for="selAllChkBox" class="text-dark pointer"><span></span></label>
                    </td></tr>';
                    $str2.=$strRow;

                    $str2.= '<tr>
                    <td colspan="3"></td>
                    </tr>';
					$str2.='</table>';
                    echo $str.'?'.$str1.'?'.$str2;
                    die;

    }



    public function createTreeView2($array, $currentParent, $currLevel = 0, $prevLevel = -1){

        $user_grp_arr=array();
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $appObj = new ApplicationController();
    
    
    
        if($user_id!=1){
            $newQuery2=$appObj->returnQueryData("SELECT DISTINCT(DG.DeviceGroup) FROM tbl_user_access TUA
                                                            LEFT JOIN devicegroup DG ON DG.DeviceGroupID=TUA.group_id_fk
                                                            WHERE TUA.user_id_fk=".$user_id);
           
              foreach($newQuery2 as $newresult2){
                    $user_grp_arr[]=$newresult2['DeviceGroup'];
            }
        }
    
        foreach ($array as $key => $val) {
            if ($currentParent == $val['parent_id']) {             
               // if ($currLevel > $prevLevel) echo " <ul> "; 
                if ($currLevel == $prevLevel) echo " </ul> ";
                $grpName=$val['name'];
                $grp_id=$val['grp_ID'];
                if(strstr($val['name'],' ')){
                    $grpName=str_replace(' ','',$val['name']);
            }
            $grpNameCss=$grpName.'_TreeCss';
            if($user_id ==1){
                    $disa="";
            }else{
                if(in_array($val['name'],$user_grp_arr)){
                    $disa="";
                }else{
                    $disa='dis22';
                }
            }
            if($val['parent_id']==0){
                $result=$this->getUserPermission($grp_id);
            }else{
                $result=$this->getUserPermission($val['parent_id']);
            }
            
            $disbaleClass='';
            $spanStyle='';
            if($result->count()==0 && $user_id!=1){
                 $disbaleClass='inactive_class';
                 $spanStyle='spanStyle';
             }
            if($val['parent_id']==0){
                echo '<ul id="'.$grpName.'" rel="'.$val['name'].'" rev='.$key.'#'.$val['parent_id'].' class="m-l-n-md no-padder"><div class="radio '.$disa.'"><input type="checkbox" id="'.$grpName.'" name="grpChkbox" rel="'.$grpName.'" rev="'.$val['name'].'" class="'.$grpNameCss.' myalertcss grpid makeCboxEnabled'.' '.$disa.' pointer'.' '.$disbaleClass.'" value="'.$key.'" style="position:relative;top:3px;left:20px;"><label for="'.$grpName.'"><span class="m-l-xs'.' '.$spanStyle.'"></span>'.$val['name'].'</label></div><span class="openTreeCss pull-right pointer m-t-n-lg"><i class="fa fa-angle-down only text" sign="+"></i></span><hr class="devider m-l-lg">';
            }else{
                $marginLeft = 10-($currLevel-1)*20;
                    $marginRight = ($currLevel-1)*10;
                echo '<ul id="'.$grpName.'" rel="'.$val['name'].'" rev='.$key.'#'.$val['parent_id'].' class="m-l-n-md" style="display:none;"><div class="radio '.$disa.'"><input type="checkbox" id="'.$grpName.'" name="grpChkbox" rel="'.$grpName.'" rev="'.$val['name'].'" class="'.$grpNameCss.' myalertcss grpid makeCboxEnabled'.' '.$disa.' pointer'.' '.$disbaleClass.'" value="'.$key.'" style="position:relative;top:3px;left:20px;"><label for="'.$grpName.'"><span class="m-l-xs'.' '.$spanStyle.'"></span>'.$val['name'].'</label></div><span class="openTreeCss pull-right pointer m-t-n-lg"><i class="fa fa-angle-down only text" sign="+" style="margin-right: '.$marginRight.'px"></i></span><hr class="devider"  style="margin-left: '.$marginLeft.'px">';
        
           }
    
            // End 
            if ($currLevel > $prevLevel) { $prevLevel = $currLevel; }
            $currLevel++; 
            $this->createTreeView2($array, $key, $currLevel, $prevLevel);
            $currLevel--;               
            }   
    }
    
    if ($currLevel == $prevLevel) echo "</ul> ";
    }

      /*****
	 *	@Function Name: getLastClickValue
	 *  @description  : get last click value
	 *	@Author		  : Vineet
	 *  @Date         : 5-may-2020
	 *****/
    public function getLastClickValue(){
        $appObj = new ApplicationController();
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
		$checkQryNew=$appObj->returnQueryData("SELECT groupId,deviceID FROM tbl_group_store WHERE userid_fk=".$user_id);
		$retType='';
		if($checkQryNew->count()>0){
			$resultRow=$checkQryNew->current();
			$groupIdStr=$resultRow[0];
			$gwayIdStr=$resultRow[1];
			
			if($groupIdStr!='' && $gwayIdStr!=''){
				$retType='GroupSide';
			}
			if($groupIdStr=='' && $gwayIdStr!=''){
				$retType='gatewaySide';
			}
			
		}
		return $retType;

}

     /*****
	 *	@Function Name: setAlertAction
	 *  @description  : set alert 
	 *	@Author		  : Vineet
	 *  @Date         : 5-may-2020
	 *****/
    public function setAlertAction(){

        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $appObj = new ApplicationController();
		$connection=$appObj->getConnection();

        $userIds=htmlspecialchars($_POST['userIds']);
        $grpIds=htmlspecialchars($_POST['grpIds']);
        $deviceIds=htmlspecialchars($_POST['deviceIds']);
        $alertId=htmlspecialchars($_POST['alertId']);
        $grp_ids_array=explode(",",$grpIds);
        $device_id_array=explode(",",$deviceIds);
        $user_id_array=explode(",",$userIds);
        

        if($grpIds !=""){
            // for group alert setting
            $sql_query="INSERT INTO tbl_alert_mapping(alert_id_fk,user_id_fk,group_id_fk,device_id_fk)values ";
            $value_array=array();
            foreach($user_id_array as $userVal){
               
                foreach($grp_ids_array as $grpval){
                    $grpId=$grpval;
                    foreach($device_id_array as $gatewayval){
                           $deviceId=$gatewayval;
                           $value_array[] = "('$alertId', '$userVal','$grpId','$deviceId')";
                           $connection->execute("DELETE FROM tbl_alert_mapping WHERE alert_id_fk=$alertId AND user_id_fk=$userVal AND device_id_fk=$deviceId AND group_id_fk=$grpId");
						   $connection->disconnect();
                    }
                }
           }
             $sql_query .= implode(',', $value_array);
             $connection->execute($sql_query);
			 $connection->disconnect();
             echo "success";die;
        }else{
            // for gateway alert setting
            
            $sql_query="INSERT INTO tbl_alert_mapping(alert_id_fk,user_id_fk,device_id_fk)values ";
            $value_array=array();
            foreach($user_id_array as $userVal){
                foreach($device_id_array as $val){
                   $deviceId=$val;
                   $value_array[] = "('$alertId', '$userVal','$deviceId')";
                 
                   $connection->execute("DELETE FROM tbl_alert_mapping WHERE alert_id_fk=$alertId AND user_id_fk=$userVal AND device_id_fk=$deviceId");
				   $connection->disconnect();
                }
            }
            
            $sql_query .= implode(',', $value_array);
            $connection->execute($sql_query);
			$connection->disconnect();
            echo "success";die;
       }
        
    }
      /*****
	 *	@Function Name: exportToCsvAction
	 *  @description  : export alert list 
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function exportToCsvAction() {
            $idx = 0;
            $data=$this->getAlertInfoTable()->fetchAll();
			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename=alertList.csv');
		
			$output = fopen('php://output', 'w');
			fputcsv($output, array('alert type', 'Min. Value (%)', 'Description', 'Start Date', 'End Date','Created By'));

			foreach($data as $row) {
				$temp = array(
							 $row['alert_name'],
							 $row['min_threshold_value'],
							 $row['description'],
                             $row['start_date'],
                             ($row['end_date']=='0000-00-00')?'':$row['end_date'],
                             $row['apploginname'],
							 );
				$jsonData[$idx ++] = $temp;
			}
				foreach($jsonData as $column)
				{
					fputcsv($output, $column);
				}
			exit();
			
    }
    
    /*****
	 *	@Function Name: getAllNestedChildAction
	 *  @description  : get all nested group
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function getAllNestedChildAction(){
        $appObj = new ApplicationController();

        $grpID=trim($_POST['grpName']);
        
        $res2  = $appObj->returnQueryData("SELECT DISTINCT(GetChildTree($grpID)) as child FROM devicegroup");

        $countRows = $res2->count();	
        			
        if($countRows>0){
            
                foreach($res2 as $data){
                $childArray[]=$data; 
            }
            $newChildArr=$childArray[0]['child'];
            if($newChildArr==""){
                $arr=$newChildArr;
            }else{
                $arr=$newChildArr.",";
            }
            $newArr=rtrim($arr,',');
        }
         echo $newArr;die;
    }

    /*****
	 *	@Function Name: getAlertByGroups
	 *  @description  : get groups by id
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function getAlertByGroupsAction(){
     
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $grpIdsData=$_POST['grpName'];
        $appObj = new ApplicationController();
       
        if($grpIdsData!=''){
            $checked='checked';
                if($user_id==1){
                    $qry="SELECT B.DeviceName, B.DeviceGroupID,B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                      INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                                      INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                      WHERE 1 AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1";
                }else{
                    $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                           INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                                           INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                           INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                                       WHERE TUA.user_id_fk=$user_id AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1";
                }
            }else{
                $checked=false;
        if($user_id==1){
             $qry="SELECT B.DeviceName, B.DeviceGroupID,B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                   INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                   INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                   WHERE 1 AND B.os_type!=-1";
         }else{
            $grpData=$appObj->returnQueryData("select DISTINCT(group_id_fk) from tbl_user_access where user_id_fk=$user_id");
                    if($grpData->count() > 0 ){
                        
                            foreach($grpData as $grpRow){
                                $grpIds .=$grpRow['group_id_fk'].",";
                        }
                        $grpIds=rtrim($grpIds,",");
                    }
             
            $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID, B.DID, A.* ,B.Version FROM tbl_sys_report AS A 
                  INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                  INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                  WHERE B.DeviceGroupID IN ($grpIds) AND B.os_type!=-1";
        }
     }	
     $sql2   = $qry;
     $finalQry="$qry ORDER BY B.DeviceGroupID ASC";

     $sql=$appObj->returnQueryData($finalQry);
        if($sql->count()>0){
           
                foreach($sql as $fetch){
                $counter++;	
                $grpID=$fetch['DeviceGroupID'];
                $newGrp=$appObj->getGroupName($grpID);
                if(strstr($newGrp,' ')){
                    $newGrp=str_replace(' ','',$newGrp);
                }
                $selChkBox='';
                if(is_array($gwayIdStrArr) && in_array($fetch['DID'],$gwayIdStrArr)){
                        $selChkBox='checked';
                }
                $version=($fetch['Version']!=-1)?$fetch['Version']:'';
                $myGatewayName=$fetch['DeviceName'];
                $strRow.="<tr id='row_".$fetch['DID']."' class='abc grpCss_".$newGrp."'><td>$myGatewayName&nbsp;<span class='noteHeading'>$misMatchNote</span></td><td>".$appObj->getGroupName($fetch['DeviceGroupID'])."</td><td align='center'><input type='checkbox' name='gwayCheckBox' id='gwayCheckBox_".$fetch['DID']."' value=".$fetch['DID']." class='chkbox makeCboxEnabled ".$newGrp."' rev=".$fetch['DID']." ".$selChkBox." $checked>
                <label for='gwayCheckBox_".$fetch['DID']."' class='text-dark pointer'><span></span></label></td></tr>";
            }//end of while
        }else{
            $strRow.="<tr><td colspan=5 align='center'><strong>There is no validated gateway available in the group(s) you selected. Please validate the same and try again.</strong></td></tr>";
        }
        
        $selAllDisabled='';		
        $rowCount=$appObj->returnQueryData($sql2);			
        if($rowCount->count()==0){
                $selAllDisabled='disabled';
        }
        $header='<tbody><tr><td>'.STR_GATEWAY_NAME.'</td><td>'.STR_GROUP_NAME.'</td><td align="center"><input type="checkbox" name="selAllChkBox" class="makeCboxEnabled" id="selAllChkBox" '.$selAllDisabled.'><label for="selAllChkBox" class="text-dark pointer"><span></span></label></td></tr></tbody>';
        echo $header.$strRow;die;

    }
    
      /*****
	 *	@Function Name: getNewAlertAction
	 *  @description  : get new alert after save 
	 *	@Author		  : Vineet
	 *  @Date         : 07-may-2020
	 *****/

     public function getNewAlertAction(){
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $appObj = new ApplicationController();
        $sql_query=$appObj->returnQueryData("SELECT A.id,A.alertid_fk FROM tbl_alert_info A INNER JOIN tbl_alert_parameter B ON B.id=A.alertid_fk LEFT JOIN appuserlist C ON C.appuserid=A.userid_fk ORDER BY id DESC LIMIT 1");
        $row=$sql_query->current();
        $alertId=$row['id'];
        $alertType=$row['alertid_fk'];
        $poll_encryption_key= POLL_ENCRYPTION_KEY;
        //$param=$aid.','.$aType;
        //echo $param;die;
        /* **************************** Gateway Stauts Report *************** */
        if($grpIdsData!=''){
            if($user_id==1){
                  $checkSql=$appObj->returnQueryData("SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                         INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                                         INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                         WHERE 1 AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1");
              }else{
                  $checkSql=$appObj->returnQueryData("SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                         INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                                         INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                         INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                                         WHERE TUA.user_id_fk=$user_id AND B.os_type!=-1");
             }
           if($checkSql->count()>0){
                if($user_id==1){
                    $qry="SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                          INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                          INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                          WHERE 1 AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1";
                }else{
                     $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                           INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                           INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                           INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                           WHERE TUA.user_id_fk=$user_id AND  B.os_type!=-1";
                }
           }else{
                if($user_id==1){
                    $qry="SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                          INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                          INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                          WHERE 1 AND B.os_type!=-1";
                }else{
                     $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                           INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                           INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                           INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                           WHERE TUA.user_id_fk=$user_id AND B.os_type!=-1"; 
               }
           }
            
        }
        else{
            
            if($user_id==1){
               
                $qry="SELECT B.DeviceName, B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                      INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                      INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                      WHERE 1 AND B.os_type!=-1";
            }else{
               $grpData=$appObj->returnQueryData("select DISTINCT(group_id_fk) from tbl_user_access where user_id_fk=$user_id");
                if($grpData->count() > 0 ){
                   // while($grpRow=mysql_fetch_array($grpData)){
                       foreach($grpData as $grpRow ){
                        $grpIds .=$grpRow['group_id_fk'].",";
                    }
                    $grpIds=rtrim($grpIds,",");
                }
                
               $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID,AES_DECRYPT(D.field2,'$poll_encryption_key') as field2, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                     INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                     INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                     WHERE B.DeviceGroupID IN ($grpIds) AND B.os_type!=-1";
           }
        }
        $sql2   = $qry;

            /* ***************  For processing Groups *************** */
            
            $qry1="SELECT * FROM devicegroup";
            $result=$appObj->returnQueryData($qry1);
            $arrayCategories = array();
            foreach($result as $row ){
 	        $arrayCategories[$row['DeviceGroupID']] = array("parent_id" => $row['DeviceMasterID'], "name" =>$row['DeviceGroup'],"grp_ID" =>$row['DeviceGroupID']);   
            }

         
              if($result->count()!=0){
                $str.=$this->createTreeView2($arrayCategories,0);
                 }
        
              $results = $appObj->returnQueryData("SELECT * FROM appuserlist");
              $str1.='<input type="hidden" id="aid" value='.$alertId.'>';

              $str1.='<input type="hidden" name="checLastClickSide" id="checLastClickSide" value='.$this->getLastClickValue().'>';
       
              $str1.='<table class="table"> 
			  <tr> 
			  <td class="font-bold">'.STR_USERNAME.'</td>
			  <td class="font-bold">'.STR_EMAIL.'</td>
              <td  style="text-align:right"><input type="checkbox" id="selUserChkBox" class="makeCboxEnabled"><label for="selUserChkBox"><span></span></label>
              </td>
              </tr>';
            
              
              if($results->count()>0){
                $count=0; 
                
                    foreach($results as $row){
                        $str1.='<tr>';
                        $str1.='<td style="word-break:break-all;width:20%">'.$row['apploginname'].'</td>';
                        $str1.='<td style="word-break:break-all;width:50%">'.$row['email'].'</td>';
                        $str1.='<td align="right">';
                        $str1.='<input type="checkbox" class="alertId makeCboxEnabled" id="alertId'.$row['appuserid'].'" name="alertId" value='.$row['appuserid'].'><label for="alertId'.$row['appuserid'].'"><span></span></label>';
                        $str1.='</td>';
                        $str1.='</tr>';

              }}else{
                $str1.='<tr><td colspan="3" align="center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
              }

              $str1.= '<tr>
              <td colspan="3"></td>
              </tr>';
              $str1.='</table>';
             
        $finalQry="$qry ORDER BY B.DeviceGroupID ASC";
        $sql=$appObj->returnQueryData($finalQry);
        if($sql->count()>0){
                foreach($sql as $fetch){
                    $counter++;	

						if($fetch['Network_status']==1){ $nwImage=$iconNWGreen; $nwTitle="ON";}
						if($fetch['Network_status']==0 || $fetch['Network_status']==-1){ $nwImage=$iconNWRed; $nwTitle="OFF";}
                        if($fetch['Network_status']==2){ $nwImage=$iconNWGreen; $nwTitle=$titleDisplay;}
						if($fetch['CPU_Status']<=50){ $cpuImage=$iconCPUGreen; $cpuTitle="Normal";}
						if($fetch['CPU_Status']>50 && $fetch['CPU_Status']<=80){ $cpuImage=$iconCPUYello; $cpuTitle="Moderate";}
						if($fetch['CPU_Status']>80){ $cpuImage=$iconCPURed; $cpuTitle="High";}
						
						if($fetch['HD_Status']<=50){ $HDImage=$iconHDnormal; $HDTitle="Normal";}
						if($fetch['HD_Status']>50 && $fetch['HD_Status']<=70){ $HDImage=$iconHDModerate; $HDTitle="Moderate";}
						if($fetch['HD_Status']>70){ $HDImage=$iconHDhigh; $HDTitle="High";}		
						
						if($fetch['wallpaper_status']==0){ $wallPStatusImg=$iconHQRed_notdownloaded; $wallpImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['wallpaper_status']==1){ $wallPStatusImg=$iconHQGreen_downloaded; $wallpImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['wallpaper_status']==2){ $wallPStatusImg=$icon_via_Set; $wallpImgMouseOverTxt=$vsmTitleGray;}
						//if($fetch['gatewayFeaturesStatus']==0){ $gwayFeatureStatusImg=$iconHQRed_notdownloaded; $gwayImgMouseOverTxt=$vsmTitleRed;}
						//if($fetch['gatewayFeaturesStatus']==1){ $gwayFeatureStatusImg=$iconHQGreen_downloaded; $gwayImgMouseOverTxt=$vsmTitleGreen;}
						//if($fetch['gatewayFeaturesStatus']==2){ $gwayFeatureStatusImg=$icon_via_Set; $gwayImgMouseOverTxt=$vsmTitleGray;}									
						if($fetch['clientFeaturesStatus']==0){ $clintFeatureStatusImg=$iconHQRed_notdownloaded; $clientImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['clientFeaturesStatus']==1){ $clintFeatureStatusImg=$iconHQGreen_downloaded; $clientImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['clientFeaturesStatus']==2){ $clintFeatureStatusImg=$icon_via_Set; $clientImgMouseOverTxt=$vsmTitleGray;}	
						// Condition added by ashu to show if dateTimesetting field has value 0 then always configSetting will show as RED i.e. (Status 0)
						if( ($fetch['dateTimeSettingStatus']==0 && ($fetch['configSettingStatus']==0 || $fetch['configSettingStatus']==1 || $fetch['configSettingStatus']==2)) || ($fetch['dateTimeSettingStatus']==1 && $fetch['configSettingStatus']==0)  ){
							 $configStatusImg=$iconHQRed_notdownloaded;
							 $configImgMouseOverTxt=$vsmTitleRed;
						}else{									
							if($fetch['configSettingStatus']==0){ $configStatusImg=$iconHQRed_notdownloaded; $configImgMouseOverTxt=$vsmTitleRed;}
							if($fetch['configSettingStatus']==1){ $configStatusImg=$iconHQGreen_downloaded; $configImgMouseOverTxt=$vsmTitleGreen;}
							if($fetch['configSettingStatus']==2){ $configStatusImg=$icon_via_Set; $configImgMouseOverTxt=$vsmTitleGray;}
						}	
						
						if($fetch['dateTimeSettingStatus']==0){ $dateTimeStatusImg=$iconHQRed_notdownloaded;}
						if($fetch['dateTimeSettingStatus']==1){ $dateTimeStatusImg=$iconHQGreen_downloaded;}
						if($fetch['dateTimeSettingStatus']==2){ $dateTimeStatusImg=$icon_via_Set;}			
			
						if($fetch['authSettingStatus']==0){ $authStatusImg=$iconHQRed_notdownloaded; $authImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['authSettingStatus']==1){ $authStatusImg=$iconHQGreen_downloaded; $authImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['authSettingStatus']==2){ $authStatusImg=$icon_via_Set; $authImgMouseOverTxt=$vsmTitleGray;}
						
						if($fetch['mobileFeaturesStatus']==0){ $mobileStatusImg=$iconHQRed_notdownloaded; $mobImgMouseOverTxt=$vsmTitleRed;}
						if($fetch['mobileFeaturesStatus']==1){ $mobileStatusImg=$iconHQGreen_downloaded; $mobImgMouseOverTxt=$vsmTitleGreen;}
						if($fetch['mobileFeaturesStatus']==2){ $mobileStatusImg=$icon_via_Set; $mobImgMouseOverTxt=$vsmTitleGray;}
									
						$imgMouseOverTxt="Gateway Status Report"; 
					  	$sqlGatewayInfo=$appObj->returnQueryData("SELECT DeviceName,DeviceIP,Active,oldIPAddess FROM DeviceInventory WHERE DID=".$fetch['DID']);	

                          if($sqlGatewayInfo){
                            $gatewayInfoArr=$sqlGatewayInfo->current();
                            $myGatewayName=$gatewayInfoArr['DeviceName'];
                            $misMatchNote='';
                            if($gatewayInfoArr[2]!='Y'){					  	
                                $misMatchNote=($gatewayInfoArr[3]!="" && $gatewayInfoArr[1]!=$gatewayInfoArr[3])?'#':'';				
                            }
                                
                        }
                        $grpID=$fetch['DeviceGroupID'];
						$newGrp=$appObj->getGroupName($grpID);
						if(strstr($newGrp,' ')){
							$newGrp=str_replace(' ','',$newGrp);
						}
								
						//$immediateParenGrpName=getImmediateParent($grpID);
						$hdStatus=($fetch['HD_Status']!=-1)?"<img src=$HDImage title=".$fetch['HD_Status'].'%'." width=32 height=32>":$sysReportPgBlank;
						$cpuStatus=($fetch['CPU_Status']!=-1)?"<img src=$cpuImage title=".$fetch['CPU_Status'].'%'." width=32 height=32>":$sysReportPgBlank;
						$version=($fetch['Version']!=-1)?$fetch['Version']:'';
						$lastActivity=($fetch['Last_Updated_Time']!='0000-00-00 00:00:00')?date($date_format,strtotime($fetch['Last_Updated_Time'])) :$sysReportPgDateNull;
						
						$selChkBox='';
                        //Warning: $gwayIdStrArr array is not defined or gets value in project.
						//if(in_array($fetch['DID'],$gwayIdStrArr)){
						//	$selChkBox='checked';
						//}
						if($fetch['field2'] !=""){ 
							$validity=date('Y-m-d', $fetch['field2']);
							$validity1=strtotime($validity);
						}else{
							$validity="";
						}
							$strRow.="<tr id='row_".$fetch['DID']."' class='abc grpCss_".$newGrp."'><td>$myGatewayName&nbsp;<span class='noteHeading'>$misMatchNote</span></td><td>".$appObj->getGroupName($fetch['DeviceGroupID'])."</td><td align='center'><input type='checkbox' name='gwayCheckBox' id='gwayCheckBox_".$fetch['DID']."' value=".$fetch['DID']." class='chkbox makeCboxEnabled".$newGrp."' rev=".$fetch['DID']." ".$selChkBox."><label for='gwayCheckBox_".$fetch['DID']."' class='text-dark pointer'><span></span></label></td></tr>";
			
            }



                }else{
					$strRow.="<tr><td colspan=3 align='center'><strong>There is no validated gateway available in the group(s) you selected. Please validate the same and try again.</strong></td></tr>";
                }
                

                   $selAllDisabled='';					
					if($appObj->returnQueryData($sql2)->count()==0){
						$selAllDisabled='disabled';
                    }
                    $str2.='<table class="table" id="punchHtml">';
                    $str2.='<tr>
                    <td>'.STR_GATEWAY_NAME.'</td>
                    <td>'.STR_GROUP_NAME.'</td>
                    <td align="center">
                    <input type="checkbox" name="selAllChkBox" id="selAllChkBox"  class="makeCboxEnabled" '.$selAllDisabled.'><label for="selAllChkBox" class="text-dark pointer"><span></span></label>
                    </td></tr>';
                    $str2.=$strRow;

                    $str2.= '<tr>
                    <td colspan="3"></td>
                    </tr>';
					$str2.='</table>';
                    echo $str.'?'.$str1.'?'.$str2;
                    die;

        }



  /*****
	 *	@Function Name: getUserPermission
	 *  @description  : get permission
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2021
	 *****/
    public function getUserPermission($grpid){
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $appObj = new ApplicationController();
        $result=$appObj->returnQueryData("SELECT group_id_fk FROM tbl_user_access where user_id_fk=".$user_id." AND group_id_fk=".$grpid);
        return $result;
    }

      /*****
	 *	@Function Name: getAlertInfoTable
	 *  @description  : get alert table
	 *	@Author		  : Vineet
	 *  @Date         : 22-april-2020
	 *****/
    public function getAlertInfoTable() {
		if(!$this->TblAlertInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblAlertInfoTable = $sm->get('Webapp\Model\TblAlertInfoTable');
		}
		return $this->TblAlertInfoTable;
    }
         /*****
	 *	@Function Name: getAlertMappingTable
	 *  @description  : get alert mapping table
	 *	@Author		  : Vineet
	 *  @Date         : 22-april-2020
	 *****/
    public function getAlertMappingTable() {
		if(!$this->TblAlertMappingTable) {
			$sm = $this->getServiceLocator();
			$this->TblAlertMappingTable = $sm->get('Webapp\Model\TblAlertMappingTable');
		}
		return $this->TblAlertMappingTable;
	}

}