<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Form\ViapadForm;

class ViapadController extends AbstractActionController {
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}


	//uisg for via pad
	public function viapadSettingsAction() {
			if(PRODUCT=='kds'){
				die('Access denied.');
			}
            $authentication='';
            $encryption='';
            $autoconnect=1;
            $ssid='';
            $txtkey='';
            $xmlurl='';
            $guestTag=0;
            $roomname='';
            $roomcode='';
            $doubleclick='';
            $roomName2='';
            $ip=DEFAULT_SERVER_IP;
            $port=DEFAULT_SERVER_PORT;
            $securityModeArray=array('open'=>'WEP Open','shared'=>'WEP Shared','WPAPSK'=>'WPA Personal','WPA2PSK'=>'WPA2 Personal');
            $encryptionArray=array('none','AES','TKIP','WEP-64bits','WEP-128bits');
            $appObj = new ApplicationController();
            list($wifiSecurityFilekey,$wifiSecurityFileIV)=explode('#',$appObj->getWifiSecurityKey());
            if(strlen($wifiSecurityFilekey)==0 || strlen($wifiSecurityFileIV)==0){
                echo MSG_ENCRYPTION_OR_KEY_NOT_DEF;
            }
            $encrypted=$appObj->file_read(DEST_PATH.FILE_WIFISECURITY_FILE);
            $decrypted=$appObj->desDecrypt($encrypted,$wifiSecurityFilekey);
            if(strstr($decrypted,'&')){
				//$decrypted = str_replace('&','amp',$decrypted);
            }
            $xmldata=$decrypted;
            $xml=simplexml_load_string($xmldata);
            $authentication=trim($xml->authentication);
            $encryption=trim($xml->encryption);
            $autoconnect=trim($xml->autoconnect);
            $ssid=trim($xml->ssid);
            //modify on 30jan17 to hanle &
            if(strstr($ssid,'amp')){
                //$ssid=str_replace('amp','&',$ssid);
            }	
			
            $txtkey=trim($xml->key);
            //modify on 30jan17 to hanle &
            if(strstr($txtkey,'amp')){
                $txtkey=str_replace('amp','&',$txtkey);
            }

            $xmlurl=trim($xml->xmlurl);
            $guest=trim($xml->guest);
			//As discussed with Amit sir on 13Jun2023 Now we will show roomname from ipadd.txt file.  
            $roomname=trim($appObj->file_read(DEST_PATH.READFILE_IPADD));//trim($xml->roomname);
            $roomcode=trim($xml->roomcode);
            $doubleclick=trim($xml->doubleclick);
            
            if($guest==0) $guestTag=0;
            if($guest==1) $guestTag=1;
			//Changed by ashu on 5April 23. Now we are using ipadd.txt
            //$file_roomnamevalueshow = file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?$appObj->file_read(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):$appObj->file_read(DEST_PATH.READFILE_IPADD);
			$file_roomnamevalueshow = $appObj->file_read(DEST_PATH.READFILE_IPADD);
            if($roomname==""){
                $roomname = $file_roomnamevalueshow;
            }

            //added on 20Jun201 for dual network. getting room name 2 ip
            if(CHECK_DUAL_NETWORK==1){
                    $dualNetworkArr=array();
                    array_push($dualNetworkArr,$file_roomnamevalueshow);
                    $configurationSql = $appObj->getTableAllData('tbl_display_settings');
                    $check_readfile_ipadd1 = file_exists(DEST_PATH.READFILE_IPADD1) ? $appObj->file_read(DEST_PATH.READFILE_IPADD1):'';
                    foreach($configurationSql as $fetchConfigData){
                            $roomName2=($fetchConfigData['field3']!='')?$fetchConfigData['field3']:$check_readfile_ipadd1;
                            if($roomName2!=''){
                                    array_push($dualNetworkArr,$roomName2);
                            }
                    }
            }
            
            $authMode['sel'] = $authentication;
            $authMode['options'] = $securityModeArray;
            
            $encryptArr['sel'] = $authentication;
            $encryptArr['options'] = $encryptionArray;
			
            $form = new ViapadForm($guestTag,$roomcode,$roomname,$autoconnect,$ssid,$authMode,$encryptArr);
            $viewmodel =  new ViewModel(array(
                'form' => $form,
                'roomname' => $roomname,
                'dualNetworkArr' => $dualNetworkArr,
                'authMode' => $authMode,
                'encryption' => $encryption,
                'encryptArr' => $encryptArr,
				'txtkey' => $txtkey,
                )
            );

            //added by niraj for load menus data into tab
            $viewmodel->setTemplate('webapp/manage-configurations/room-settings');

            return $viewmodel;
	}
        
        public function changeEncryptionBoxAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $authentiationMode = trim($request->getPost('authentiationMode'));
                $encryptionArray=array('none','AES','TKIP','WEP-64bits','WEP-128bits');
                echo "<select id='encryptionDDBox' name='encryptionDDBox' class='form-control m-b'>";
                foreach($encryptionArray as $encryptKey=>$encryptVal){	
                        if($authentiationMode=='open'){
                                $selWepOpen='';
                                if($encryptVal=='none' || $encryptVal=='WEP-64bits' || $encryptVal=='WEP-128bits'){		 
                                        echo"<option value='$encryptVal' $selWepOpen>$encryptVal</option>";
                                }
                        }
                        if($authentiationMode=='shared'){
                                if($encryptVal=='WEP-64bits' || $encryptVal=='WEP-128bits'){			 
                                        echo"<option value='$encryptVal'>$encryptVal</option>";
                                }	
                        }
                        if($authentiationMode=='WPAPSK'){
                                if($encryptVal=='TKIP'){			 
                                        echo"<option value='$encryptVal'>$encryptVal</option>";
                                }	
                        }
                        if($authentiationMode=='WPA2PSK'){
                                if($encryptVal=='AES'){			 
                                        echo"<option value='$encryptVal'>$encryptVal</option>";
                                }	
                        }	
                }
                echo"</select><label class='ddlabelCss'>".STR_ENCRYPT."</label>";die;
            }
        }
        
        public function settingWiFiSecurityAction(){
            $request = $this->getRequest();
            $session = new Container('userinfo');
	    	$loginName = $session->offsetGet('LoginName');
	    	$hostname = DEFAULT_SERVER_IP;
            if($request->isXmlHttpRequest()) {
                if(trim($request->getPost('ssid'))!='') $ssid = htmlspecialchars(trim($request->getPost('ssid')));
                $authentiationMode = trim($request->getPost('authentiationMode'));
                $encryption = trim($request->getPost('encryption'));
                $autoconnect = trim($request->getPost('autoconnect'));
                $txtRoomName = trim($request->getPost('txtRoomName'));
                $appObj = new ApplicationController();
				//Changed by ashu on 5April 23. Now we are using ipadd.txt
				//$file_roomnamevalueshow = file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?$appObj->file_read(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):$appObj->file_read(DEST_PATH.READFILE_IPADD);
				$file_roomnamevalueshow = $appObj->file_read(DEST_PATH.READFILE_IPADD);
                if(CHECK_DUAL_NETWORK==1){
                        $dualNetworkArr=array();                        
                        $check_readfile_ipadd1 = file_exists(DEST_PATH.READFILE_IPADD1) ? $appObj->file_read(DEST_PATH.READFILE_IPADD1):'';
                        array_push($dualNetworkArr,$file_roomnamevalueshow);
                        $configurationSql = $appObj->getTableAllData('tbl_display_settings');
                        foreach($configurationSql as $fetchConfigData){                                
								$roomName2=($fetchConfigData['field3']!='')?trim($fetchConfigData['field3']):trim($check_readfile_ipadd1);
                                if($roomName2!=''){
                                        array_push($dualNetworkArr,$roomName2);
                                }
                        }
                       
                        if (!in_array($txtRoomName, $dualNetworkArr)){ 
                          $txtRoomName=$file_roomnamevalueshow; 
                        } 

                }else{
                        if($txtRoomName!=$file_roomnamevalueshow){
                           $txtRoomName=$file_roomnamevalueshow;
                        }
                }
                if(trim($request->getPost('txtGuest'))==0) $txtGuest = 0;
                if(trim($request->getPost('txtGuest'))==1) $txtGuest = 1;

                $securityKey='';
                $txtRoomcode = trim($request->getPost('txtRoomcode'));	 
                if($encryption!='None'){		
                       if(trim($request->getPost('securityKey'))!='') $securityKey = trim($request->getPost('securityKey'));	
                }
                 
                $xml='';	
                if($getOS=='WIN'){
                        $xml .= '<?xml version="1.0" encoding="utf-8"?>';
                }	
                $xml .= '<viapad>';
                $xml .= '<authentication>' .trim($authentiationMode). '</authentication>';
                $xml .= '<encryption>' .trim($encryption). '</encryption>';
                $xml .= '<autoconnect>' .trim($autoconnect). '</autoconnect>';
                $xml .= '<ssid>' .trim($ssid). '</ssid>';
                $xml .= '<key>' .trim($securityKey). '</key>';
                //$xml .= '<xmlurl>https://10.0.0.125/345SDerdW/profile.xml</xmlurl>';
                $xml .= '<guest>'.trim($txtGuest).'</guest>';
                $xml .= '<roomname>'.trim(str_replace("\n","",$txtRoomName)).'</roomname>';
                $xml .= '<roomcode>'.trim($txtRoomcode).'</roomcode>';
                $xml .= '<doubleclick>250</doubleclick>';
                $xml .= '</viapad>';
                
                list($wifiSecurityFilekey,$wifiSecurityFileIV)=explode('#',$appObj->getWifiSecurityKey());
                if(strlen($wifiSecurityFilekey)==0 || strlen($wifiSecurityFileIV)==0){
                        echo 0;
                        exit;
                }
                
                $encryptedStr=$appObj->desEncrypt($xml,$wifiSecurityFilekey);
                $fileName=DEST_PATH.FILE_WIFISECURITY_FILE;
                $myfile = fopen($fileName, 'w') or die("can't open file");
                # Now UTF-8 - Add byte order mark
                //fwrite($myfile, pack("CCC",0xef,0xbb,0xbf));
                $confWrite= fwrite($myfile, $encryptedStr);
                //fwrite($f,$content);
                fclose($myfile);
                $this->getActivityLogMasterTable()->setActivity($loginName, BTN_APPLY, MSG_VIAPAD_CONFIGBY, $hostname);
			
                /* *********************** End **************** */		
                echo 1;die;
            }
        }
        
        public function getDisplaySettingsTable() {
            if(!$this->TblDisplaySettingsTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblDisplaySettingsTable = $sm->get('Webapp\Model\TblDisplaySettingsTable');
            }
            return $this->TblDisplaySettingsTable;
        }
        public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}



}
