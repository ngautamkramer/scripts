<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Form\AddAlertForm;
use Webapp\Controller\WebProducerController;

class InstantAlertController extends AbstractActionController {


    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

   public function emergencyAlertAction(){
	  if(PRODUCT=='kds'){
		die('Access denied.');
	  }
      $appObj = new ApplicationController();
      $session = new Container('userinfo');
      $user_id = $session->offsetGet('usrid');
      $queryResult =$this->getEmergencyAlertTable()->fetchInstantList();
      return new ViewModel(array('data'=>$queryResult));

   }
   /*****
	 *	@Function Name: addEmergencyAlertAction
	 *  @description  : add intant alert 
	 *	@Author		  : Vineet
	 *  @Date         : 28-april-2020
	 *****/
   public function addEmergencyAlertAction(){
        $appObj = new ApplicationController();
          $lastpicid=htmlspecialchars($_POST['lastUserId']);
          $alertName=htmlspecialchars(trim($_POST['alertName']));
          if($lastpicid!="" && $alertName!=""){
            if(strlen($alertName)<=100){
                $this->getEmergencyAlertTable()->insertInstantAlert($alertName,$lastpicid);
            }
            echo "success";die;
        }else{
            echo "Enter the value";die; 
        }

   }
   /*****
	 *	@Function Name: deleteAlertAction
	 *  @description  : delete intant alert 
	 *	@Author		  : Vineet
	 *  @Date         : 28-april-2020
	 *****/
   public function deleteAlertAction(){
	$appObj = new ApplicationController();
	$alertId=  $this->params()->fromRoute('id');
	$this->getEmergencyAlertTable()->deleteInstantAlert($alertId);
	$this->getEmergencyAlertExecuteTable()->deleteInstantAlert($alertId);
	
	//Rabbit MQ Code
	// adding command to rabbitmq
	$cmdArr=array("cmd"=>"push_alerts","sender"=>"web-vsm","display_property"=>"","interval"=>"-1");
	$cmdJson=json_encode($cmdArr);
	$producerObject=new WebProducerController();
	$producerObject->rabbitWebProducerAction($cmdJson);			
	echo "success";die;
   }

     /*****
	 *	@Function Name: showAlertAction
	 *  @description  : view intant alert 
	 *	@Author		  : Vineet
	 *  @Date         : 28-april-2020
	 *****/
   public function showAlertAction()
   {
      $request = $this->getRequest();
      if($request->isXmlHttpRequest()) {
      $appObj = new ApplicationController();
      $alertId=$_POST['id'];
      $session = new Container('userinfo');
      $user_id = $session->offsetGet('usrid');
      $sql= $appObj->returnQueryData("SELECT emergency_alert_name FROM tbl_emergency_alert WHERE id=$alertId");
      $row= $sql->current();
      $alertName=$row['emergency_alert_name'];

      $qry="SELECT b.`id`,a.`emergency_alert_name`,c.`DeviceName`,d.`DeviceGroup`,c.`DeviceIP`,c.`DID` FROM `tbl_emergency_alert` a INNER JOIN `tbl_emergency_alert_execute` b ON a.`id`=b.`emergency_alert_id_fk` INNER JOIN `DeviceInventory` c ON b.`device_id_fk`=c.`DID` LEFT JOIN `devicegroup` d ON c.`DeviceGroupID`=d.`DeviceGroupID`WHERE a.`id`=$alertId GROUP BY c.`DeviceName`";
      $gatewayData=$appObj->returnQueryData($qry);
      $str.='<div><h4 style="word-break: break-word;">Instant Alert Message :'.$row['emergency_alert_name'].'</h4></div><br>';
      $str.='<table  class="table" id="printTbl" style="width:700">';
      if($gatewayData->count() >0){
                  
                  $str.= '<tr>';
                  $str.= '<th>'.STR_GATEWAY_NAME.'</th>';
                  $str.= '<th>'.STR_GROUP_NAME.'</th>';

                   	 
                         foreach($gatewayData as $row){
                    
                        $str.= '<tr>';
                        $str.= '<td width="70%">'.$row['DeviceName'].' ( IP: '.$row['DeviceIP'].'  )</td>';
                        $str.= '<td width="70%">'.$row['DeviceGroup'].'</td>';

                        $str.='</tr>';	
		}}else{ 
			$str.='<tr><td colspan="4" align="center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
      }
      $str.= '<tr>';
      $str.='<td colspan="9"></td>';
      $str.='</tr>';
      $str.='</table>';
      echo $str ;
      die;
    }
   }


    /*****
	 *	@Function Name: getAlertdataAction
	 *  @description  : get emergeny alert data
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function getAlertdataAction(){
        $request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
		    $data = $request->getPost('data');
        $id=$_POST['id'];
        $result=$this->getEmergencyAlertTable()->getInstantAlertById($id);
        $temp = array(
        'emergency_alert_name' =>$result->emergency_alert_name,
        );
        $view = new JsonModel(array('success' =>$temp));
		    $view->setTerminal(true);
		    return $view;
         
        }
    }

       /*****
	 *	@Function Name:   updateEmergencyAlert
	 *  @description  :   get emergeny alert data
	 *	@Author		    :   Vineet
	 *  @Date         :   30-april-2020
	 *****/

    public function updateEmergencyAlertAction(){
      $request = $this->getRequest();
      if($request->isXmlHttpRequest()) {
      $alertName=htmlspecialchars(trim($_POST['alertName']));
      $alertId=htmlspecialchars(trim($_POST['alertId']));
      $this->getEmergencyAlertTable()->updateEmergencyAlert($alertId, $alertName);	
      echo "success";
      die;
        }
    }
     
    /*****
	 *	@Function Name:   setAlertAction
	 *  @description  :   get set alert view
	 *	@Author		    :   Vineet
	 *  @Date         :   30-april-2020
	 *****/

    public function setAlertAction(){
      $session = new Container('userinfo');
      $user_id = $session->offsetGet('usrid');
      $appObj = new ApplicationController();
      $alertId=trim($_POST['id']);

      if($user_id==1){
        $qry="SELECT B.DeviceName, B.DeviceGroupID, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
              INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
              INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
              WHERE 1 AND B.os_type!=-1";
    }else{
      $grpData=$appObj->returnQueryData("select DISTINCT(group_id_fk) from tbl_user_access where user_id_fk=$user_id");
           if($grpData->count() > 0 ){
                 foreach($grpData as $grpRow){
                       $grpIds .=$grpRow['group_id_fk'].",";
               }
               $grpIds=rtrim($grpIds,",");
           }
      
       $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID, B.DID, A.* ,B.Version FROM tbl_sys_report AS A 
         INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
         INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
         WHERE B.DeviceGroupID IN ($grpIds) AND B.os_type!=-1";
   }
 
      $sql2   = $qry;
      $res2= $appObj->returnQueryData($sql2);
      



      /* ***************  For processing Groups *************** */

      $qry1="SELECT * FROM devicegroup";
      $result=$appObj->returnQueryData($qry1);
      $arrayCategories = array(); 
      foreach($result as $row){
 	    $arrayCategories[$row['DeviceGroupID']] = array("parent_id" => $row['DeviceMasterID'], "name" =>$row['DeviceGroup'],"grp_ID" =>$row['DeviceGroupID']);   
      }
     
      
      if($result->count()!=0){
        $str.=$this->createTreeView($arrayCategories, 0);
      }
     
        $str1.='<input type="hidden" id="aid" value='.$alertId.'>';
        $str1.='<input type="hidden" name="checLastClickSide" id="checLastClickSide" value='.$this->getLastClickValue().'>';
        $str1.='<div class="selectdiv selectdivcss">';
        $str1.='<select name="alertTime" id="alertTime" class="form-control m-b styl">
        <option value="">select</option>
        <option value="5">5 Minutes</option>
        <option value="10">10 Minutes</option>
        <option value="15">15 Minutes</option>
        <option value="20">20 Minutes</option>
        <option value="25">25 Minutes</option>
        <option value="30">30 Minutes</option>
        <option value="35">35 Minutes</option>
        <option value="40">40 Minutes</option>
        <option value="45">45 Minutes</option>
        <option value="50">50 Minutes</option>
        </select>';
        $str1.='<label class="ddlabelCss ddlbCss">Set Flash duration</label>';
        $str1.='</div>';
        $str1.='<div class="checkbox m-t-xxs divs">';
        $str1.='<input type="checkbox" id="chkAlert" name="chkAlert" class="makeCboxEnabled">';
        $str1.='<label for="chkAlert" class="text-dark pointer"><span></span>Blinking</label>';
        $str1.='</div>';
        
        $finalQry="$qry ORDER BY B.DeviceGroupID ASC";
        $sql=$appObj->returnQueryData($finalQry);
        if($sql->count()>0){
            //while($fetch=mysql_fetch_array($sql)){
              foreach($sql as $fetch){
                $counter++;	
               
                $grpID=$fetch['DeviceGroupID'];
                $newGrp=$appObj->getGroupName($grpID);
                if(strstr($newGrp,' ')){
                    $newGrp=str_replace(' ','',$newGrp);
                }
                $selChkBox='';
                //Warning: $gwayIdStrArr array is not defined or gets value in project.
                // if(in_array($fetch['DID'],$gwayIdStrArr)){
                //     $selChkBox='checked';
                // }
                $myGatewayName=$fetch['DeviceName'];
                $version=($fetch['Version']!=-1)?$fetch['Version']:'';
                $strRow.="<tr id='row_".$fetch['DID']."' class='abc grpCss_".$newGrp."'><td>$myGatewayName&nbsp;<span class='noteHeading'>$misMatchNote</span></td><td>".$appObj->getGroupName($fetch['DeviceGroupID'])."</td><td align='center'><input type='checkbox' name='gwayCheckBox' id='gwayCheckBox_".$fetch['DID']."' value=".$fetch['DID']." class='chkbox makeCboxEnabled ".$newGrp."' rev=".$fetch['DID']." ".$selChkBox.">
                <label for='gwayCheckBox_".$fetch['DID']."' class='text-dark pointer'><span></span></label></td></tr>";
            
            
            
            
            }//end of while
        }else{
            $strRow.="<tr><td colspan=5 align='center'><strong>There is no validated gateway available in the group(s) you selected. Please validate the same and try again.</strong></td></tr>";
        }
      
        $str2.='<div>';
        $str2.='<table class="table" id="punchHtml">';

        $selAllDisabled='';					
        if(count($appObj->returnQueryData($sql2))==0){
                $selAllDisabled='disabled';
        }
        $str2.='<tr><td>'.STR_GATEWAY_NAME.'</td><td>'.STR_GROUP_NAME.'</td><td align="center"><input type="checkbox" name="selAllChkBox" class="makeCboxEnabled" id="selAllChkBox"><label for="selAllChkBox" class="text-dark pointer"><span></span></label></td></tr>';
        $str2.=$strRow;
         
        $str2.='</table>';
        $str2.='</div>';
        echo $str.'?'.$str1.'?'.$str2;
         die();

    }


    /*****
	 *	@Function Name: sendEmergencyAlertAction
	 *  @description  : set emergency alert data
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/

     public function  sendEmergencyAlertAction(){
        $appObj = new ApplicationController();
        
        $userIds=$_POST['userIds'];
        $grpIds=$_POST['grpIds'];
        $deviceIds=$_POST['deviceIds'];
        $alertId=$_POST['alertId'];
        $timeInterval=$_POST['alertDuration'];
        $property=$_POST['property'];
        $grp_ids_array=explode(",",$grpIds);
        $device_id_array=explode(",",$deviceIds);
        $user_id_array=explode(",",$userIds);
        $currDateTime=date('Y-m-d H:i:s');
        $endDateTime=date('Y-m-d H:i:s',strtotime('+'.$timeInterval.' minutes',strtotime($currDateTime)));

        if($grpIds !=""){
			
            // for group emergency alert setting
            $sql_query="INSERT INTO tbl_emergency_alert_execute(emergency_alert_id_fk,user_id_fk,group_id_fk,device_id_fk,start_dateTime,end_dateTime)values ";
            $value_array=array();
            foreach($user_id_array as $userVal){
               foreach($grp_ids_array as $grpval){
                   $grpId=$grpval;
                   foreach($device_id_array as $gatewayval){
                        $deviceId=$gatewayval;
                        $value_array[] = "('$alertId', '$userVal','$grpId','$deviceId','$currDateTime','$endDateTime')";
                        $appObj->executeQueries("DELETE FROM tbl_emergency_alert_execute WHERE emergency_alert_id_fk=$alertId AND user_id_fk=$userVal AND device_id_fk=$deviceId AND group_id_fk=$grpId");
                   }
               }
            }
            $sql_query .= implode(',', $value_array);
            $appObj->executeQueries($sql_query);
			
            // send the command
           	/* $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $rebootcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>InstantAlert</Cmd><P1></P1><P2>$property</P2><P3>$timeInterval</P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $appObj->sendMsgToAPIserver($logincmd,$rebootcmd);
			*/
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_alerts","sender"=>"web-vsm","display_property"=>"$property","interval"=>"$timeInterval");
			//echo "<pre>";print_r($cmdArr);die;
			
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);			
            echo "success";die;
        }else{

            // for gateway emergency alert setting
            $sql_query="INSERT INTO tbl_emergency_alert_execute(emergency_alert_id_fk,user_id_fk,device_id_fk,start_dateTime,end_dateTime)values ";
          
			$value_array=array();
            foreach($user_id_array as $userVal){
                foreach($device_id_array as $val){
                    $deviceId=$val;
                    $value_array[] = "('$alertId', '$userVal','$deviceId','$currDateTime','$endDateTime')";
                    $appObj->executeQueries("DELETE FROM tbl_emergency_alert_execute WHERE emergency_alert_id_fk=$alertId AND user_id_fk=$userVal AND device_id_fk=$deviceId");
                }
            }
			  
            $sql_query .= implode(',', $value_array);
            $appObj->executeQueries($sql_query);
            
            // send the command
          /*$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
          $rebootcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>InstantAlert</Cmd><P1></P1><P2>$property</P2><P3>$timeInterval</P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
          $appObj->sendMsgToAPIserver($logincmd,$rebootcmd);
		  */
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_alerts","sender"=>"web-vsm","display_property"=>"$property","interval"=>"$timeInterval");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);			
          	echo "success";die;

        }
     }



    /*****
	 *	@Function Name: getAllNestedChildAction
	 *  @description  : get all nested group
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
     public function getAllNestedChildAction(){
        $appObj = new ApplicationController();

        $grpID=trim($_POST['grpName']);
        
        $res2  = $appObj->returnQueryData("SELECT DISTINCT(GetChildTree($grpID)) as child FROM devicegroup");

        $countRows = $res2->count();	
        			
        if($countRows>0){
            
                foreach($res2 as $data){
                $childArray[]=$data; 
            }
            $newChildArr=$childArray[0]['child'];
            if($newChildArr==""){
                $arr=$newChildArr;
            }else{
                $arr=$newChildArr.",";
            }
            $newArr=rtrim($arr,',');
        }
         echo $newArr;die;
    }

    /*****
	 *	@Function Name: getAlertByGroups
	 *  @description  : get groups by id
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function getAlertByGroupsAction(){

        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
        $grpIdsData=$_POST['grpName'];
        $appObj = new ApplicationController();
       
        if($grpIdsData!=''){
            $checked='checked';
                if($user_id==1){
                    $qry="SELECT B.DeviceName, B.DeviceGroupID,B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                      INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                                      INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                      WHERE 1 AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1";
                }else{
                    $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID, B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                                           INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                                           INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                                           INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID  
                                       WHERE TUA.user_id_fk=$user_id AND B.DeviceGroupID in ($grpIdsData) AND B.os_type!=-1";
                }
            }else{
                $checked=false;
        if($user_id==1){
             $qry="SELECT B.DeviceName, B.DeviceGroupID,B.DID, A.*,B.Version FROM tbl_sys_report AS A 
                   INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk 
                   INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                   WHERE 1 AND B.os_type!=-1";
         }else{
            $grpData=$appObj->returnQueryData("select DISTINCT(group_id_fk) from tbl_user_access where user_id_fk=$user_id");
                    if($grpData->count() > 0 ){
                        
                            foreach($grpData as $grpRow){
                                $grpIds .=$grpRow['group_id_fk'].",";
                        }
                        $grpIds=rtrim($grpIds,",");
                    }
             
            $qry="SELECT DISTINCT(B.DeviceName), B.DeviceGroupID, B.DID, A.* ,B.Version FROM tbl_sys_report AS A 
                  INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk
                  INNER JOIN tbl_device_dnsname AS D ON D.DID_Fk=B.DID 
                  WHERE B.DeviceGroupID IN ($grpIds) AND B.os_type!=-1";
        }
     }	
     $sql2   = $qry;
     $finalQry="$qry ORDER BY B.DeviceGroupID ASC";
     $sql=$appObj->returnQueryData($finalQry);
        if($sql->count()>0){
           
                foreach($sql as $fetch){
                $counter++;	
                $grpID=$fetch['DeviceGroupID'];
                $newGrp=$appObj->getGroupName($grpID);
                if(strstr($newGrp,' ')){
                    $newGrp=str_replace(' ','',$newGrp);
                }
                $selChkBox='';
                if(is_array($gwayIdStrArr) && in_array($fetch['DID'],$gwayIdStrArr)){
                        $selChkBox='checked';
                }
                $version=($fetch['Version']!=-1)?$fetch['Version']:'';
                $myGatewayName=$fetch['DeviceName'];
                $strRow.="<tr id='row_".$fetch['DID']."' class='abc grpCss_".$newGrp."'><td>$myGatewayName&nbsp;<span class='noteHeading'>$misMatchNote</span></td><td>".$appObj->getGroupName($fetch['DeviceGroupID'])."</td><td align='center'><input type='checkbox' name='gwayCheckBox' id='gwayCheckBox_".$fetch['DID']."' value=".$fetch['DID']." class='chkbox makeCboxEnabled ".$newGrp."' rev=".$fetch['DID']." ".$selChkBox." $checked>
                <label for='gwayCheckBox_".$fetch['DID']."' class='text-dark pointer'><span></span></label></td></tr>";
            }//end of while
        }else{
            $strRow.="<tr><td colspan=5 align='center'><strong>There is no validated gateway available in the group(s) you selected. Please validate the same and try again.</strong></td></tr>";
        }
        
        $selAllDisabled='';					
        if($appObj->returnQueryData($sql2)->count()==0){
                $selAllDisabled='disabled';
        }
        $header='<tbody><tr><td>'.STR_GATEWAY_NAME.'</td><td>'.STR_GROUP_NAME.'</td><td align="center"><input type="checkbox" name="selAllChkBox" class="makeCboxEnabled" id="selAllChkBox" '.$selAllDisabled.'><label for="selAllChkBox" class="text-dark pointer"><span></span></label></td></tr></tbody>';
        echo $header.$strRow;die;

    }

        /*****
	 *	@Function Name: getLastClickValue
	 *  @description  : get last click value
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function getLastClickValue(){
        $appObj = new ApplicationController();
        $session = new Container('userinfo');
        $user_id = $session->offsetGet('usrid');
		$checkQryNew=$appObj->returnQueryData("SELECT groupId,deviceID FROM tbl_group_store WHERE userid_fk=".$user_id);
		$retType='';
		if($checkQryNew->count()>0){
			$resultRow=$checkQryNew->current();
			$groupIdStr=$resultRow[0];
			$gwayIdStr=$resultRow[1];
			
			if($groupIdStr!='' && $gwayIdStr!=''){
				$retType='GroupSide';
			}
			if($groupIdStr=='' && $gwayIdStr!=''){
				$retType='gatewaySide';
			}
			
		}
		return $retType;

}
   /*****
	 *	@Function Name: createTreeView
	 *  @description  : create group 
	 *	@Author		  : Vineet
	 *  @Date         : 30-april-2020
	 *****/
    public function createTreeView($array, $currentParent, $currLevel = 0, $prevLevel = -1){

    $user_grp_arr=array();
    $session = new Container('userinfo');
    $user_id = $session->offsetGet('usrid');
    $appObj = new ApplicationController();



    if($user_id!=1){
        $newQuery2=$appObj->returnQueryData("SELECT DISTINCT(DG.DeviceGroup) FROM tbl_user_access TUA
                                                        LEFT JOIN devicegroup DG ON DG.DeviceGroupID=TUA.group_id_fk
                                                        WHERE TUA.user_id_fk=".$user_id);
       
          foreach($newQuery2 as $newresult2){
             $user_grp_arr[]=$newresult2['DeviceGroup'];
        }
    }


    foreach ($array as $key => $val) {
        if ($currentParent == $val['parent_id']) {             
           // if ($currLevel > $prevLevel) echo " <ul> "; 
            if ($currLevel == $prevLevel) echo " </ul> ";
            $grpName=$val['name'];
            $grp_id=$val['grp_ID'];
            if(strstr($val['name'],' ')){
                $grpName=str_replace(' ','',$val['name']);
        }
        $grpNameCss=$grpName.'_TreeCss';
        if($user_id ==1){
                $disa="";
        }else{
            if(in_array($val['name'],$user_grp_arr)){
                $disa="";
            }else{
                $disa='dis22';
            }
        }

        if($val['parent_id']==0){
            echo '<ul id="'.$grpName.'" rel="'.$val['name'].'" rev='.$key.'#'.$val['parent_id'].' class="m-l-n-md no-padder"><div class="radio '.$disa.'"><input type="checkbox" id="'.$grpName.'" name="grpChkbox" rel="'.$grpName.'" rev="'.$val['name'].'" class="'.$grpNameCss.' myalertcss grpid makeCboxEnabled'.' '.$disa.' pointer" value="'.$key.'" style="position:relative;top:3px;left:20px;"><label for="'.$grpName.'"><span class="m-l-xs"></span>'.$val['name'].'</label></div><span class="openTreeCss pull-right pointer m-t-n-lg"><i class="fa fa-angle-down only text" sign="+"></i></span><hr class="devider m-l-lg">';
        }else{
            $marginLeft = 10-($currLevel-1)*20;
                $marginRight = ($currLevel-1)*10;
            echo '<ul id="'.$grpName.'" rel="'.$val['name'].'" rev='.$key.'#'.$val['parent_id'].' class="m-l-n-md" style="display:none;"><div class="radio '.$disa.'"><input type="checkbox" id="'.$grpName.'" name="grpChkbox" rel="'.$grpName.'" rev="'.$val['name'].'" class="'.$grpNameCss.' myalertcss grpid makeCboxEnabled'.' '.$disa.' pointer" value="'.$key.'" style="position:relative;top:3px;left:20px;"><label for="'.$grpName.'"><span class="m-l-xs"></span>'.$val['name'].'</label></div><span class="openTreeCss pull-right pointer m-t-n-lg"><i class="fa fa-angle-down only text" sign="+" style="margin-right: '.$marginRight.'px"></i></span><hr class="devider"  style="margin-left: '.$marginLeft.'px">';
    
       }
        // End 
        if ($currLevel > $prevLevel) { $prevLevel = $currLevel; }
        $currLevel++; 
        $this->createTreeView($array, $key, $currLevel, $prevLevel);
        $currLevel--;               
        }   
    }

        if ($currLevel == $prevLevel) echo "</ul> ";

    }


   /*****
	 *	@Function Name: getEmergencyAlertTable
	 *  @description  : get table
	 *	@Author		  : Vineet
	 *  @Date         : 28-april-2020
	 *****/
   public function getEmergencyAlertTable() {
		if(!$this->TblEmergencyAlertTable) {
			$sm = $this->getServiceLocator();
			$this->TblEmergencyAlertTable = $sm->get('Webapp\Model\TblEmergencyAlertTable');
		}
		return $this->TblEmergencyAlertTable;
    }

    /*****
	 *	@Function Name: getEmergencyAlertExecuteTable
	 *  @description  : get table
	 *	@Author		  : Vineet
	 *  @Date         : 28-april-2020
	 *****/
    public function getEmergencyAlertExecuteTable() {
		if(!$this->TblEmergencyAlertExecuteTable) {
			$sm = $this->getServiceLocator();
			$this->TblEmergencyAlertExecuteTable = $sm->get('Webapp\Model\TblEmergencyAlertExecuteTable');
		}
		return $this->TblEmergencyAlertExecuteTable;
    }

}