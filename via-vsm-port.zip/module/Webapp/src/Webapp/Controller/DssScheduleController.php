<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\TtfInfo\TtfInfo;
use Webapp\Controller\WebProducerController;

class DssScheduleController extends AbstractActionController {	
	protected $fileExtension = "json";
	protected $fileNamePrefix = "vsm_camp_";
	public function getPlaylistScheduleMasterTable() {
		if(!$this->TblPlaylistScheduleMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblPlaylistScheduleMasterTable = $sm->get('Webapp\Model\TblPlaylistScheduleMasterTable');
		}
		return $this->TblPlaylistScheduleMasterTable;
	}
	
	public function getPlaylistNowTable() {
		if(!$this->TblPlaylistNowTable) {
			$sm = $this->getServiceLocator();
			$this->TblPlaylistNowTable = $sm->get('Webapp\Model\TblPlaylistNowTable');
		}
		return $this->TblPlaylistNowTable;
	}

	public function getCampaignListTable() {
		if(!$this->TblCampaignListTable) {
			$sm = $this->getServiceLocator();
			$this->TblCampaignListTable = $sm->get('Webapp\Model\TblCampaignListTable');
		}
		return $this->TblCampaignListTable;
	}

	public function getScreenTemplateMasterTable() {
		if(!$this->TblScreenTemplateMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblScreenTemplateMasterTable = $sm->get('Webapp\Model\TblScreenTemplateMasterTable');
		}
		return $this->TblScreenTemplateMasterTable;
	}

	public function getDssInfoTable() {
		if(!$this->TblDssInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblDssInfoTable = $sm->get('Webapp\Model\TblDssInfoTable');
		}
		return $this->TblDssInfoTable;
	}

	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}

	public function getSettingTable() {
		if(!$this->TblSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}

	function editScheduleCampaignAction() {
		$postData = $this->getRequest()->getPost()->toArray();	
		$searchData = [];		
		//Security changes added by ashu on 30/03/22. Allow only numeric value 
		if(!is_numeric($postData["scheduleCampaignId"]) || $postData["scheduleCampaignId"] <= 0 ){
			echo "Id is not valid";die;
		}			
		$searchData["scheduleCampaignId"] = $postData["scheduleCampaignId"];
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$scheduledMasterData = $playlistMasterTable->getSelectedScheduleMaster($searchData);	

		$searchData["scheduleCampaignId"] = $postData["scheduleCampaignId"];
		foreach($scheduledMasterData as $allMediaResultSet) {
			$resultSetJson = json_encode($allMediaResultSet); 
			$resultSet = json_decode($resultSetJson, true);
		}

		$arrayForGetStatus = array(
			"startDate" => strtotime($resultSet["startdate"]), 
			"endDate" => strtotime($resultSet["enddate"]), 
			"startTime" => strtotime($resultSet["starttime"]), 
			"endTime" => strtotime($resultSet["endtime"])
		);
		$scheduledSatus = $this->getScheduleCampaignStatus($arrayForGetStatus);
		if($scheduledSatus != "Archived") {
			foreach($scheduledMasterData as $allMediaResultSet) {
				$resultSetJson = json_encode($allMediaResultSet); 
				$resultSet = json_decode($resultSetJson, true);
			}
			echo json_encode($resultSet); 
		} else {
			$responseReturn = false;
			echo json_encode($responseReturn);
		}
		exit;
	}

	public function duplicateScheduleCampaignAction() {
		$postData = $this->getRequest()->getPost()->toArray();	
		$searchData = [];
		$searchData["scheduleCampaignId"] = $postData["scheduleCampaignId"];
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$scheduledMasterData = $playlistMasterTable->fetchDataForDuplicateSchedule($searchData);
		
		foreach($scheduledMasterData as $allMediaResultSet) {
			$resultSetJson = json_encode($allMediaResultSet); 
			$resultSet = json_decode($resultSetJson, true);
		}
		$responseReturn = false;
		$arrayForGetStatus = array(
			"startDate" => strtotime($resultSet["StartDate"]), 
			"endDate" => strtotime($resultSet["EndDate"]), 
			"startTime" => strtotime($resultSet["StartTime"]), 
			"endTime" => strtotime($resultSet["EndTime"])
		);
		$scheduledSatus = $this->getScheduleCampaignStatus($arrayForGetStatus);
		if($scheduledSatus != "Archived") {
			$postData = $this->getRequest()->getPost()->toArray();		
			$session = new Container('userinfo');	
			$duplicatePlaylistMaster["CID"] = $resultSet["CID"];
			$duplicatePlaylistMaster["OrderDate"] = $resultSet["OrderDate"];
			$duplicatePlaylistMaster["StartTime"] = $resultSet["StartTime"];
			$duplicatePlaylistMaster["EndTime"] = $resultSet["EndTime"];
			$duplicatePlaylistMaster["StartDate"] = $resultSet["StartDate"];
			$duplicatePlaylistMaster["EndDate"] =  $resultSet["EndDate"];
			$duplicatePlaylistMaster["Username"] = $session->offsetGet('LoginName');
			$duplicatePlaylistMaster["hostname"] = HOSTNAME;

			$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
			$lastInsertedId = $playlistMasterTable->insertPlaylistMaster($duplicatePlaylistMaster);

			$fileName=$this->getFileNameAction($resultSet["CID"]);

			$duplicatePlaylistNow["OID"] = $lastInsertedId;
			//$duplicatePlaylistNow["fileName"] = $this->fileNamePrefix. $resultSet["CID"]. "." .$this->fileExtension;
			$duplicatePlaylistNow["fileName"]=$fileName;
			$duplicatePlaylistNow["sync_status"] = 1;
			$duplicatePlaylistNow["StartTime"] = $resultSet["StartTime"];
			$duplicatePlaylistNow["EndTime"] = $resultSet["EndTime"];
			$duplicatePlaylistNow["StartDate"] = $resultSet["StartDate"];
			$duplicatePlaylistNow["EndDate"] =  $resultSet["EndDate"];
			$duplicatePlaylistNow["ModifyDateTime"] = date("Y-m-d H:i:s");
			$duplicatePlaylistNow["UserName"] = $session->offsetGet('LoginName');
			$duplicatePlaylistNow["DID"] = "1";
			$playlistNowTable = $this->getPlaylistNowTable();
			$lastInsertedId = $playlistNowTable->insertPlaylistNow($duplicatePlaylistNow);
			$responseReturn = true;
		}
		echo $responseReturn;
		die;
	}

	public function updateScheduleCampaignAction(){
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$session = new Container('userinfo');	
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
		$crsf_tokenval=trim($postData['crsf_tokenval']);
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}
		
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$responseReturn = "";
		if(empty($postData["scheduleName"])) {
			$responseReturn = 1;
		} else if(!empty($postData["scheduleName"])) {
			if(strlen($postData['scheduleName']) > 100) {
				$responseReturn = 4;
			} else {
				$uniqueNameSearch = array();
				$uniqueNameSearch["scheduleName"] = $postData['scheduleName'];
				$uniqueNameSearch["oid"] = $postData["updateScheduleId"];
				$uniqueNameData = $playlistMasterTable->checkScheduleUniqueName($uniqueNameSearch);
				$responseReturn = count($uniqueNameData) == 0 ? "" : 3;
			}
		}
		if($responseReturn == "") {
			$updatePlaylistMaster["cid"] = $postData["campaignId"];
			$updatePlaylistMaster["schedulename"] = $postData["scheduleName"];
			$updatePlaylistMaster["modifydatetime"] = date("Y-m-d H:i:s");
			$updatePlaylistMaster["starttime"] = $postData["startTime"];
			$updatePlaylistMaster["endtime"] = $postData["endTime"];
			$updatePlaylistMaster["startdate"] = $postData["startDate"];
			$updatePlaylistMaster["enddate"] = $postData["endDate"];
			$updatePlaylistMaster["username"] = $session->offsetGet('LoginName');
			$updatePlaylistMaster["hostname"] = HOSTNAME;

			$fileName=$this->getFileNameAction($postData["campaignId"]);

			$updatePlaylistMasterWhere["oid"] = $postData["updateScheduleId"];
			$playlistMasterTable->updatePlaylistMaster($updatePlaylistMasterWhere, $updatePlaylistMaster);
			//$updatePlaylistNow["fileName"] = $this->fileNamePrefix. $postData["campaignId"]. "." .$this->fileExtension;
			$updatePlaylistNow["filename"]=$fileName;
			$updatePlaylistNow["sync_status"] = (PRODUCT=='via')?1:0;
			$updatePlaylistNow["starttime"] = $postData["startTime"];
			$updatePlaylistNow["endtime"] = $postData["endTime"];
			$updatePlaylistNow["startdate"] = $postData["startDate"];
			$updatePlaylistNow["enddate"] = $postData["endDate"];
			$updatePlaylistNow["modifydatetime"] = date("Y-m-d H:i:s");
			$updatePlaylistNow["username"] = $session->offsetGet('LoginName');
			
			$updatePlaylistNowWhere["oid"] = $postData["updateScheduleId"];

			$playlistNowTable = $this->getPlaylistNowTable();
			$playlistNowTable->updatePlaylistNow($updatePlaylistNowWhere, $updatePlaylistNow);

			if(PRODUCT=='vsm'){
				$rabbitMqData = array();
				$rabbitMqData["command"] = "new_schedule";
				$rabbitMqData["sender"] = "web-vsm";
				$rabbitMqData["orderid"] = (int)$postData["updateScheduleId"];
				$this->sendDataRabbitMq($rabbitMqData);
			}
			$responseReturn = 2;
		}
		echo $responseReturn;
		exit;
	}

	public function sendDataRabbitMq($rabbitMqData) {
		// rabbitmq command starts
		$dataBind = array();
		$dataBind["bindingKey"] = "vsm_dss";
		$rabbitMqDataJson = json_encode($rabbitMqData);
		$rabbitMqObject = new WebProducerController();
		$rabbitMqObject->rabbitWebProducerActionDss($rabbitMqDataJson, $dataBind);
	}

	public function checkUniqueScheduleNameAction() {
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
	
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		
		$uniqueNameSearch = array();
		$uniqueNameSearch["scheduleName"] = $postData['scheduleName'];
		$uniqueNameData = $playlistMasterTable->checkScheduleUniqueName($uniqueNameSearch);
		$responseReturn = count($uniqueNameData) == 0 ? "" : 1;	
		echo $responseReturn ;exit;
	}

	public function addScheduleCampaignAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$request  = $this->getRequest();	
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$crsf_tokenval=trim($postData["crsf_tokenval"]);		
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}
		
		$session = new Container('userinfo');
		if(PRODUCT == 'vsm') {
			$deviceInventoryIds = $postData["deviceInventoryIds"];	
		}	
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$responseReturn = "";
		$modelValue = $this->getGatewayModelName();
		$tableDssInfoData = $this->getDssInfoTable();
		if(PRODUCT == 'vsm') {
			$licenseStatusVal = $tableDssInfoData->getDataForDssLicenseVsm();
		} else{
			$licenseStatusVal = $tableDssInfoData->checkDssLicenseValidity();
		}	
		$licenseStatus = ($modelValue === "12" || $modelValue === "11" || $modelValue === "14" || $modelValue === "15") ? 'FULL' : $licenseStatusVal;	
		
		if($licenseStatus == 'FULL') {
			if(empty($postData["campaignId"])) {
				$responseReturn = 1;
			} else if(empty($postData["scheduleName"])) {
				$responseReturn = 2;
			} else if(!empty($postData["scheduleName"])) {
				if(strlen($postData['scheduleName']) > 100) {
					$responseReturn = 6;
				} else {
					$uniqueNameSearch = array();
					$uniqueNameSearch["scheduleName"] = $postData['scheduleName'];
					$uniqueNameData = $playlistMasterTable->checkScheduleUniqueName($uniqueNameSearch);
					$responseReturn = count($uniqueNameData) == 0 ? "" : 4;	
				}
			}
			if($responseReturn == "") {
				$insertPlaylistMaster["cid"] = $postData["campaignId"];
				$insertPlaylistMaster["schedulename"] = $postData["scheduleName"];
				$insertPlaylistMaster["orderdate"] = date("Y-m-d H:i:s");
				$insertPlaylistMaster["starttime"] = $postData["startTime"];
				$insertPlaylistMaster["endtime"] = $postData["endTime"];
				$insertPlaylistMaster["startdate"] = $postData["startDate"];
				$insertPlaylistMaster["enddate"] = $postData["endDate"];
				$insertPlaylistMaster["username"] = $session->offsetGet('LoginName');
				$insertPlaylistMaster["hostname"] = HOSTNAME;
				$lastInsertedId = $playlistMasterTable->insertPlaylistMaster($insertPlaylistMaster);
				$fileName = $this->getFileNameAction($postData["campaignId"]);
				if(PRODUCT == 'via' || PRODUCT == 'kds') {
					$insertPlaylistNow["oid"] = $lastInsertedId;
					//$insertPlaylistNow["fileName"] = $this->fileNamePrefix. $postData["campaignId"]. "." .$this->fileExtension;
					$insertPlaylistNow["filename"] = $fileName;
					$insertPlaylistNow["sync_status"] = 1;
					$insertPlaylistNow["starttime"] = $postData["startTime"];
					$insertPlaylistNow["endtime"] = $postData["endTime"];
					$insertPlaylistNow["startdate"] = $postData["startDate"];
					$insertPlaylistNow["enddate"] = $postData["endDate"];
					$insertPlaylistNow["modifydatetime"] = date("Y-m-d H:i:s");;
					$insertPlaylistNow["username"] = $session->offsetGet('LoginName');
					$insertPlaylistNow["did"] = "1";
					$playlistNowTable = $this->getPlaylistNowTable();
					$lastInsertedId = $playlistNowTable->insertPlaylistNow($insertPlaylistNow);
					$responseReturn = 3;
				} else {
					$playlistNowTable = $this->getPlaylistNowTable();
					foreach($deviceInventoryIds as $key => $value) {					
						$insertPlaylistNow["OID"] = $lastInsertedId;
						//$insertPlaylistNow["fileName"] = $this->fileNamePrefix. $postData["campaignId"]. "." .$this->fileExtension;
						$insertPlaylistNow["fileName"]=$fileName;
						$insertPlaylistNow["sync_status"] = 0;
						$insertPlaylistNow["StartTime"] = $postData["startTime"];
						$insertPlaylistNow["EndTime"] = $postData["endTime"];
						$insertPlaylistNow["StartDate"] = $postData["startDate"];
						$insertPlaylistNow["EndDate"] = $postData["endDate"];
						$insertPlaylistNow["ModifyDateTime"] = date("Y-m-d H:i:s");
						$insertPlaylistNow["UserName"] = $session->offsetGet('LoginName');
						$insertPlaylistNow["DID"] = $value;
						$playlistNowTable->insertPlaylistNow($insertPlaylistNow);
					}
					$rabbitMqData = array();
					$rabbitMqData["command"] = "new_schedule";
					$rabbitMqData["sender"] = "web-vsm";
					$rabbitMqData["orderid"] = (int)$lastInsertedId;
					$this->sendDataRabbitMq($rabbitMqData);	
					$responseReturn = 3;
				}
			}
		} else {
			$responseReturn = 5;
		}
		echo $responseReturn;
		die;
	}

	public function deleteScheduleCampaignAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$postData = $this->getRequest()->getPost()->toArray();	
		$scheduleCampaignId = $postData["scheduleCampaignId"];
		$crsf_tokenval=trim($postData["crsf_tokenval"]);
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}
		
		//Security changes added by ashu on 30/03/22. Allow only numeric value 
		if(!is_numeric($scheduleCampaignId) || $scheduleCampaignId <= 0 ){
			echo "Id is not valid";die;
		}
		$deleteDataWhere = array("oid" => $scheduleCampaignId);
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$playlistMasterTable->deletePlaylistScheduleMaster($deleteDataWhere);
		$playlistNowTable = $this->getPlaylistNowTable();
		if(PRODUCT == 'vsm') {
			$updatePlaylistNow["sync_status"] = 3;
			$updatePlaylistNowWhere["oid"] = $scheduleCampaignId; 
			$playlistNowTable->updatePlaylistNow($updatePlaylistNowWhere, $updatePlaylistNow);
			$rabbitMqData = array();
			$rabbitMqData["command"] = "delete_schedule";
			$rabbitMqData["sender"] = "web-vsm";
			$rabbitMqData["orderid"] = (int)$scheduleCampaignId; 
			$this->sendDataRabbitMq($rabbitMqData);
		} else {
			$playlistNowTable->deletePlaylistNow($deleteDataWhere);
		}
		echo true;
		die;
	}

	public function getAllCampaignsAction() {
		$campaignListTable = $this->getCampaignListTable();
		$getAllCampaign = $campaignListTable->getCampaigns();
		$campaignListing = [];
		foreach($getAllCampaign as $allMediaResultSet) {
			$resultSetJson = json_encode($allMediaResultSet); 
			$resultSet = json_decode($resultSetJson, true);
			$campaignListing[] = $resultSet; 
		}
		echo json_encode($campaignListing);exit;
	}


	public function readCampaignJsonFile($fileName) {
		if(file_exists(UPLOAD_DSS_CAMPAIGN.$fileName)) {
			$appObj = new ApplicationController();
			$fileContent = $appObj->file_read(UPLOAD_DSS_CAMPAIGN.$fileName);
			$fileContentArray = json_decode($fileContent, true);
			return $fileContentArray;
		}
	}

	public function getScheduleCampaignStatus($resultSet) {	
		$serverDateAndTimeStamp = $this->getServerDateAndTime();
		$serverDateAndTimeStampArray = explode(" ", $serverDateAndTimeStamp);	
		$currentDate = strtotime($serverDateAndTimeStampArray[0]);
		$currentTime = strtotime($serverDateAndTimeStampArray[1]);		
		$scheduledSatus = "";		
		if($resultSet["startDate"] <= $currentDate && $resultSet["endDate"] == $currentDate) {									
			if($resultSet["startTime"] < $currentTime && $resultSet["endTime"] < $currentTime) {
				$scheduledSatus = "Archived";
			} else if($resultSet["startTime"] <= $currentTime && $resultSet["endTime"] >= $currentTime) {
				$scheduledSatus = "In Use";
			} else if($resultSet["startTime"] > $currentTime && $resultSet["endTime"] > $currentTime) {
				$scheduledSatus = "Scheduled";
			}
		} else if($resultSet["startDate"] > $currentDate && $resultSet["endDate"] > $currentDate) {
			$scheduledSatus = "Scheduled";
		} else if($resultSet["startDate"] < $currentDate && $resultSet["endDate"] < $currentDate) {
			$scheduledSatus = "Archived";
		} else if($resultSet["startDate"] <= $currentDate && $resultSet["endDate"] > $currentDate) {
			$scheduledSatus = "In Use";
		}
		return $scheduledSatus;
	}
	public function getGatewayModelName() {
		$modelValue = "nojsonfile";
		if(file_exists(DEST_PATH."model.json")){
			$jsonStr = file_get_contents(DEST_PATH."model.json");
			$jsonArray = json_decode($jsonStr, true);
			$modelValue = $jsonArray['modelvalue'];			
		}	
		return $modelValue;
	}

	public function getServerDateAndTime() {
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		$serverDateAndTime = $playlistMasterTable->getServerDateTime();
		foreach($serverDateAndTime as $getServerDateAndTime) {
			$resultSetJson = json_encode($getServerDateAndTime); 
			$resultSet = json_decode($resultSetJson, true);
		}
		return $serverDateAndTimeStamp = $resultSet['current_date_time'];
	}


	public function getServerDateAndTimeAction() {
		$serverDateAndTimeStamp = $this->getServerDateAndTime();
		echo json_encode($serverDateAndTimeStamp); exit;
	}

	public function buildTree($elements, $deviceMasterId = 0) {
    	$groups = array();
		foreach ($elements as $element) {
	        if ($element['deviceMasterId'] == $deviceMasterId) {
	            $children = $this->buildTree($elements, $element['deviceGroupId']);
	            if ($children) {
	                $element['children'] = $children;
	            }
	            $groups[$element['deviceGroupId']] = $element;
	        }
	    }
    	return $groups;
	}

	public function getAllChild($elements) {
		$groups = [];
		foreach($elements as $key => $value) {			 
		 	foreach($value as $keyOne => $valueOne) {
		 		foreach((array) $valueOne as $keyTwo => $valueTwo){					
	 				$groups[$key]["children"][] = $valueTwo["deviceGroupId"];
	 				foreach((array) $valueTwo["children"] as $keyThree => $valueThree) {
	 					$groups[$key]["children"][] = $valueThree["deviceGroupId"];
	 					$groups[$valueThree["deviceMasterId"]]["children"][] = $valueThree["deviceGroupId"];	
	 					foreach($valueThree["children"] as $keyFour => $valueFour) {
	 						$groups[$key]["children"][] = $valueFour["deviceGroupId"];
	 						$groups[$valueThree["deviceMasterId"]]["children"][] = $valueFour["deviceGroupId"];
	 						$groups[$valueFour["deviceMasterId"]]["children"][] = $valueFour["deviceGroupId"];	
	 						foreach($valueFour["children"] as $keyFive => $valueFive) {
	 							$groups[$key]["children"][] = $valueFive["deviceGroupId"];
		 						$groups[$valueThree["deviceMasterId"]]["children"][] = $valueFive["deviceGroupId"];
		 						$groups[$valueFour["deviceMasterId"]]["children"][] = $valueFive["deviceGroupId"];	
		 						$groups[$valueFive["deviceMasterId"]]["children"][] = $valueFive["deviceGroupId"];	
	 						}	 						
	 					}	 					
	 				}		 		
		 		}
		 	}
		}
		return $groups;		
	}

	public function scheduleListAction() {		

		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
		if(PRODUCT == 'vsm') {
			$allGroups = $playlistMasterTable->getAllDeviceGroupAndInventory();
			$modelValue = $this->getGatewayModelName();
			$tableDssInfoData = $this->getDssInfoTable();
			$licenseStatusVal = $tableDssInfoData->getDataForDssLicenseVsm();		
			$licenseStatus = ($modelValue === "12" || $modelValue === "11" || $modelValue === "14" || $modelValue === "15") ? 'FULL' : $licenseStatusVal;
			$userGroups = $playlistMasterTable->getLoginUserAllGroups();
			// print_r($userGroups);
			$session = new Container('userinfo');
            $loginUserId = $session->offsetGet('usrid');
			$allDeviceInventory = array();
			$deviceIds = array();
			$deviceIdsGroupWise = array();
			foreach($allGroups as $row) {
				$resultSetJson = json_encode($row); 
				$result = json_decode($resultSetJson, true);
				$rows[]  = array('deviceGroupId' => $result["deviceGroupId"], 'deviceMasterId' => $result["deviceMasterId"], "deviceGroup" => $result["deviceGroup"]);
				
				if($loginUserId  == 1) {
					if($result["deviceGroupInventroyID"] != "" && $result["deviceName"] != "") {								
						$isFreeLicenseGw = $tableDssInfoData->checkFreeLicenseDevice($result["deviceInventryId"]);												
						$canIssueLicense = $isFreeLicenseGw == true ? "no" : "yes";
							if($isFreeLicenseGw == true) {
								// echo $result["deviceGroupId"],"-".$result["deviceInventryId"];
								// echo "<br>";	
								$deviceIds[$result["deviceInventryId"]] = array("deviceName" => $result["deviceName"], "deviceStatus" => strtolower($result["deviceActive"]));					
								$allDeviceInventory[$result["deviceGroupId"]][]= array("deviceName" => $result["deviceName"], "deviceInventoryId" => $result["deviceInventryId"]);
							} else {												
								$checkValidLicence = $tableDssInfoData->checkDataVsmLicenseUploaded($result["deviceInventryId"]);
								if(count($checkValidLicence) > 0) {
									$deviceIds[$result["deviceInventryId"]] = array("deviceName" => $result["deviceName"], "deviceStatus" => strtolower($result["deviceActive"]));	
									$allDeviceInventory[$result["deviceGroupId"]][]= array("deviceName" => $result["deviceName"], "deviceInventoryId" => $result["deviceInventryId"]);
							}
						}						
						$deviceIdsGroupWise[$result["deviceGroupId"]][]= $result["deviceInventryId"];	
					}	
				} else {
					if(in_array($result["deviceGroupId"], $userGroups)) {		
						if($result["deviceGroupInventroyID"] != "" && $result["deviceName"] != "") {								
							$isFreeLicenseGw = $tableDssInfoData->checkFreeLicenseDevice($result["deviceInventryId"]);												
							$canIssueLicense = $isFreeLicenseGw == true ? "no" : "yes";
								if($isFreeLicenseGw == true) {
									// echo $result["deviceGroupId"],"-".$result["deviceInventryId"];
									// echo "<br>";	
									$deviceIds[$result["deviceInventryId"]] = array("deviceName" => $result["deviceName"], "deviceStatus" => strtolower($result["deviceActive"]));						
									$allDeviceInventory[$result["deviceGroupId"]][]= array("deviceName" => $result["deviceName"], "deviceInventoryId" => $result["deviceInventryId"], "deviceActive" => $result["deviceActive"], );
								} else {												
									$checkValidLicence = $tableDssInfoData->checkDataVsmLicenseUploaded($result["deviceInventryId"]);
									if(count($checkValidLicence) > 0) {
										$deviceIds[$result["deviceInventryId"]] = array("deviceName" => $result["deviceName"], "deviceStatus" => strtolower($result["deviceActive"]));	
										$allDeviceInventory[$result["deviceGroupId"]][]= array("deviceName" => $result["deviceName"], "deviceInventoryId" => $result["deviceInventryId"]);
								}
							}						
							$deviceIdsGroupWise[$result["deviceGroupId"]][]= $result["deviceInventryId"];	
						}	
					}
				}
			}			
			$allGroups = $this->buildTree($rows);
			$allGroupsChild = [];
			foreach($allGroups as $key => $value) {
				$allGroupsChild[$key]["children"] = $value["children"];
			}

			$childWiseGroups = $this->getAllChild($allGroupsChild);
		
			$playlistMasterTable = $this->getPlaylistScheduleMasterTable();						
			$allPlaylistMaster = $playlistMasterTable->getAllPlaylistScheduleMaster();
			$scheduleDataList = [];
			foreach($allPlaylistMaster as $allPlaylistMasterResultSet) {
				$resultSetJson = json_encode($allPlaylistMasterResultSet); 
				$resultSet = json_decode($resultSetJson, true);
				//$scheduleDataList[$resultSet["OID"]] = $resultSet;
				$fileContentArray = $this->readCampaignJsonFile($resultSet["fileName"]);
				$templateId = $fileContentArray["templateId"];
				$arrayForGetStatus = array(
					"startDate" => strtotime($resultSet["StartDate"]), 
					"endDate" => strtotime($resultSet["EndDate"]), 
					"startTime" => strtotime($resultSet["StartTime"]), 
					"endTime" => strtotime($resultSet["EndTime"])
				);
				$resultSet["status"] = $this->getScheduleCampaignStatus($arrayForGetStatus);
				$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
				$templateDetailsData = $tableScreenTemplateMasterTable->getTemplateDetails($templateId);	
				$templateDetails = [];
				foreach($templateDetailsData as $detailsResultSet) {
					$hasAudio = $detailsResultSet['FrameID'] ==	$fileContentArray["audioInFrame"] ? "yes" : "no";
					$templateDetails["templateId"] = $detailsResultSet['ScreenTemplateID'];
					$templateDetails["templateName"] = $detailsResultSet['ScreenTemplateName'];
					$templateDetails['frameProperties'][] = array (
						'frameHeight' => round($detailsResultSet['FrameHeight']), 
						'frameWidth' =>round($detailsResultSet['FrameWidth']),
						'frameLeft' => round($detailsResultSet['FrameLeft']), 
						'frameTop' => round($detailsResultSet['FrameTop']),	
						'frameName' => $detailsResultSet['FrameName'], 
						'frameId' => $detailsResultSet['FrameID'],
						'hasAudio' => $hasAudio
					);
				}	
				array_push($scheduleDataList, array_merge($resultSet, $templateDetails, $fileContentArray));	
			}
			// echo "<pre>";
			// print_r($scheduleDataList);
			// echo "</pre>";exit;	
			$viewmodel = new ViewModel(array("loginUserId" => $loginUserId, "scheduleDataList" => $scheduleDataList, "licenseStatus" => $licenseStatus, "allDeviceInventory" => $allDeviceInventory, "groupSubGroupData" => $allGroups, "deviceIds" => $deviceIds, "childWiseGroups" => $childWiseGroups, "userGroups" => $userGroups));
		} else {
			$allPlaylistMaster = $playlistMasterTable->getAllPlaylistScheduleMaster();
			//echo json_enocde($allPlaylistMaster);
			$scheduleDataList = [];
		
			foreach($allPlaylistMaster as $allPlaylistMasterResultSet) {
				
				$resultSetJson = json_encode($allPlaylistMasterResultSet); 
				$resultSet = json_decode($resultSetJson, true);
				
				//$scheduleDataList[$resultSet["OID"]] = $resultSet;
				$fileContentArray = $this->readCampaignJsonFile($resultSet["filename"]);
				$templateId = $fileContentArray["templateId"];
				$arrayForGetStatus = array(
					"startDate" => strtotime($resultSet["startdate"]), 
					"endDate" => strtotime($resultSet["enddate"]), 
					"startTime" => strtotime($resultSet["starttime"]), 
					"endTime" => strtotime($resultSet["endtime"])
				);
			
				$resultSet["status"] = $this->getScheduleCampaignStatus($arrayForGetStatus);
				$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
				$templateDetailsData = $tableScreenTemplateMasterTable->getTemplateDetails($templateId);	
				$templateDetails = [];
				foreach($templateDetailsData as $detailsResultSet) {
					$hasAudio = $detailsResultSet['frameid'] ==	$fileContentArray["audioinframe"] ? "yes" : "no";
					$templateDetails["templateId"] = $detailsResultSet['screentemplateid'];
					$templateDetails["templateName"] = $detailsResultSet['screentemplatename'];
					$templateDetails['frameProperties'][] = array (
						'frameHeight' => round($detailsResultSet['frameheight']), 
						'frameWidth' =>round($detailsResultSet['framewidth']),
						'frameLeft' => round($detailsResultSet['frameleft']), 
						'frameTop' => round($detailsResultSet['frametop']),	
						'frameName' => $detailsResultSet['framename'], 
						'frameId' => $detailsResultSet['frameid'],
						'hasAudio' => $hasAudio
					);
				}
				$fileContentArray = is_array($fileContentArray) ? $fileContentArray : [];	
				array_push($scheduleDataList, array_merge($resultSet, $templateDetails, $fileContentArray));	
			}
			// echo "<pre>";
			// print_r($scheduleDataList);
			// echo "</pre>";exit;
			$modelValue = $this->getGatewayModelName();
			$tableDssInfoData = $this->getDssInfoTable();
			$licenseStatus = $tableDssInfoData->checkDssLicenseValidity();				
			$licenseStatus = ($modelValue === "12" || $modelValue === "11" || $modelValue === "14" || $modelValue === "15") ? 'FULL' : $licenseStatus;
			$viewmodel = new ViewModel(array("scheduleDataList" => $scheduleDataList, "licenseStatus" => $licenseStatus));
		}
		return $viewmodel;
	}

	public function getAllDevicesOfScheduleAction() {
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$scheduleCampaignId = $postData["scheduleCampaignId"];	
		$searchData = array();
		$searchData["scheduleCampaignId"] = $scheduleCampaignId;
		$playlistMasterTable = $this->getPlaylistScheduleMasterTable();	
		$deviceData = $playlistMasterTable->getAllDeviceIdsOfSchedule($searchData);
		$resultSet = array();
		foreach($deviceData as $row) {
			$resultSetJson = json_encode($row); 
			$resultSet[] = json_decode($resultSetJson, true);
		}
		echo json_encode($resultSet);
		exit;
	}

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		$appObj = new ApplicationController();
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		} else {
			if(PRODUCT=='via' || PRODUCT=='kds'){
				$getSettingObj = $appObj->getComplexPasswordSettings();
				$getSettingData = $getSettingObj->webadmin_session_timeout;
			}else{
				$settingTable = $this->getSettingTable();
				$dataSessionSetting = $settingTable->getSessionCheckData();
				foreach($dataSessionSetting as $contentDetailResultSet) {
					$resultSetJson = json_encode($contentDetailResultSet); 
					$resultSet = json_decode($resultSetJson, true);
					$getSettingData = $resultSet['logoutTIme'];
				}
			}
			$sessionTimeOut = ($getSettingData > 0) ? $getSettingData : 10;
			$dataSendSessionCheck = array("sessionTimeOut" => $sessionTimeOut, "sessionLoginName" => $session->offsetGet('LoginName'));
			$sessionCheckTable = $this->getSessionCheckTable();
			$dataSessionCheck = $sessionCheckTable->getSessionCheckData($dataSendSessionCheck);
			
			if(count($dataSessionCheck) > 0) {
				$dataSendUpdateSessionCheck = array("sessionLoginName" => $session->offsetGet('LoginName'));
				$sessionCheckTable->updateSessionCheckData($dataSendUpdateSessionCheck);
			} else {
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		return parent::onDispatch($e);
	}


	/*****
	 *	@Function Name: getFileNameAction
	 *  @description  : get campaign fileName
	 *	@Author		  : Vineet
	 *  @Date         : 16-feb-2021
	 *****/
	public function getFileNameAction($cid){
		$appObj = new ApplicationController();
		$row=$appObj->returnQueryData("SELECT filename FROM campaignlist where cid=$cid");
		$rowVal= $row->current();
		$fileName = $rowVal['filename'];
		return $fileName;
	}

}