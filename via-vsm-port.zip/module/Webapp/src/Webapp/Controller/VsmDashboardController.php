<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\ViewModel;
use Zend\Validator\File\Size;
use Zend\Validator\File\Extension;
use Zend\Validator\File\Rename;
use Zend\File\Transfer\Adapter\Http;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\WebProducerController;
use Webapp\Form\ViaReportForm;
  /*****
	 *	@controller Name: VsmDashboard
	 *  @description  : implemented business logic for Dashboard 
	 *	@Author		  : Rajeev
	 *  @Date         : 1-march-2021
	 *****/
class VsmDashboardController extends AbstractActionController
{
	public $session;
    public $user_id;
    public $appObj;
    public function __construct() {
        $session = new Container('userinfo');
		$this->user_id = $session->offsetGet('usrid');
        $this->appObj = new ApplicationController();
		//added by ashu to get menus from session to show popup when no devices
        $this->menu_data=$session->offsetGet('user_menu_'.$session->offsetGet('usrid'));
		
    }

        public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
	//	$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$this->appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$this->appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$this->appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
	
        public function reportAction(){
			
		
			if(PRODUCT=='kds'){
				die('Access denied.');
			}
		//	$appObj = new ApplicationController();
			$request = $this->getRequest();
			$form=new ViaReportForm();
			$whiteBoardCount=0;
			$fileCount=0;
			$thirdPartyCount=0;
			$veiwMainCount=0;
			$mediaCount=0;
			$collabCount=0;
			$recordingCount=0;
			$condition="";
	
			if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('startdate')!="") {
				$startDate  = $request->getPost('startdate');
				$endDate = $request->getPost('enddate');
				if($startDate!="" && $endDate!=""){
					$condition=" ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
				}
				
			}
			else{
				$startDate=date('Y-m-d', strtotime(date('Y-m-1')));
				$endDate=date('Y-m-d');
				$condition=" ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
			}

			$gatewayUsedJson=$this->getGatewayUsedReport($condition);
			$featureUsedJson=$this->getFeatureUsedReport($condition );
			$vesionUsedJson=$this->getGetewayVersionReport();
			$sessionTimeJson=$this->getGatewaySessionReport($condition);
			//$gatewayUsedJson1=json_encode($gatewayUsedJson);
              // echo $gatewayUsedJson;
			  
			$menuarr=$this->menu_data;
			//echo "<pre>";print_r($menuarr);
			$showNoDevicePopup=1;	
			if($menuarr['menuarr4']['Devices']!=''){			  
			  if($this->user_id==1){
					$getDevicesDataQry="SELECT DeviceInventory.*, devicegroup.DeviceGroup AS DeviceGroup, tbl_advance_sys_report.extraField3 AS extraField3, tbl_device_extra_info.airplay_name AS airplay_name, tbl_device_live_status.Network_status AS Network_status, tbl_device_dnsname.field1 AS field1 FROM DeviceInventory INNER JOIN devicegroup ON devicegroup.DeviceGroupID = DeviceInventory.DeviceGroupID INNER JOIN tbl_sys_report ON tbl_sys_report.did_fk = DeviceInventory.DID INNER JOIN tbl_advance_sys_report ON tbl_advance_sys_report.did_fk = DeviceInventory.DID INNER JOIN tbl_device_extra_info ON tbl_device_extra_info.deviceID_Fk = DeviceInventory.DID INNER JOIN tbl_device_live_status ON tbl_device_live_status.did_fk = DeviceInventory.DID LEFT JOIN tbl_device_dnsname ON tbl_device_dnsname.DID_Fk = DeviceInventory.DID";
			  
			  }else{
					$getDevicesDataQry="SELECT DISTINCT DeviceInventory.*, devicegroup.DeviceGroup AS DeviceGroup, tbl_advance_sys_report.extraField3 AS extraField3, tbl_device_extra_info.airplay_name AS airplay_name,tbl_device_live_status.Network_status AS Network_status, tbl_device_dnsname.field1 AS field1 FROM DeviceInventory INNER JOIN devicegroup ON devicegroup.DeviceGroupID = DeviceInventory.DeviceGroupID INNER JOIN tbl_user_access ON tbl_user_access.group_id_fk = devicegroup.DeviceGroupID INNER JOIN tbl_sys_report ON tbl_sys_report.did_fk = DeviceInventory.DID INNER JOIN tbl_advance_sys_report ON tbl_advance_sys_report.did_fk = DeviceInventory.DID INNER JOIN tbl_device_extra_info ON tbl_device_extra_info.deviceID_Fk = DeviceInventory.DID INNER JOIN tbl_device_live_status ON tbl_device_live_status.did_fk = DeviceInventory.DID LEFT JOIN tbl_device_dnsname ON tbl_device_dnsname.DID_Fk = DeviceInventory.DID WHERE tbl_user_access.user_id_fk =".$this->user_id;
			  
			  }
			  
			  $getDevicesDataArr=$this->appObj->returnQueryData($getDevicesDataQry);
			  $showNoDevicePopup=(count($getDevicesDataArr)>0)?count($getDevicesDataArr):0;	
			}
			/************ End ******** */
			
			  //echo $qry;
			  $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
				return new ViewModel([
					'form'=>$form,
                    'gatewayUsedList' => $gatewayUsedJson,
					'FeatureUsedList'=>$featureUsedJson,
					'versionUsedList'=>$vesionUsedJson,
					'sessionTimeList'=>$sessionTimeJson,
					'showNoDevicePopup'=>$showNoDevicePopup
                   
				]);


        }

		public function getGatewaySessionReport($condition)
		{
			$gatewaySessionJson=[];
			$startDate=date('Y-m-d', strtotime(' -1 day'));
			$endDate=date('Y-m-d');
			  
		//	$appObj = new ApplicationController();

		if($this->user_id==1)
		{
			$qry="SELECT g.UsageInMin as sessionTime,d.DeviceName 
			FROM tbl_gwayusedhourslog g inner join  deviceinventory d on g.DeviceId=d.did 
			where  $condition and  g.UsageInMin>0 group by g.DeviceId order by g.UsageInMin desc limit 10";
          //  group by g.DeviceId ,g.ActivityDate having sessionTime>0 order by sessionTime desc limit 10";
			
          //  group by   g.DeviceId ,g.ActivityDate having sessionTime>0 order by sessionTime desc limit 10";

		}
    else
	{
			$qry="SELECT g.UsageInMin as sessionTime,d.DeviceName
				FROM tbl_gwayusedhourslog g inner join  deviceinventory d on g.DeviceId=d.did 
			INNER JOIN tbl_user_access C ON C.group_id_fk=d.DeviceGroupID	
             WHERE   C.user_id_fk='$this->user_id' AND $condition and  g.UsageInMin>0 group by g.DeviceId order by g.UsageInMin desc limit 10";
			// group by   g.DeviceId,,g.ActivityDate having sessionTime>0 order by sessionTime desc limit 10";
	}
			$tblGatewayUsedSessiondataArr=$this->appObj->returnQueryData($qry);
			if(count($tblGatewayUsedSessiondataArr)>0){
				$i=0;
				foreach($tblGatewayUsedSessiondataArr as $statusdata){
					$temp=array(
					'gatewaySessionTime'=>$statusdata['sessionTime'],
					'deviceName'=>$statusdata['DeviceName'],
					);
					$gatewaySessionJson[$i++]=$temp;
					
					//$i++;
	
				}
			}
	
			return $gatewaySessionJson;
		
		}
		public function getGatewayUsedReport($condition)
		{
			$gatewayUsedJson=[];
			$startDate=date('Y-m-d', strtotime(' -1 day'));
			$endDate=date('Y-m-d');
			  
		//	$appObj = new ApplicationController();

		if($this->user_id==1)
		{
			$qry="SELECT sum(g.UsageCount) as gatewayUsedCount,d.DeviceName 
			FROM tbl_gwayusedloginlog g inner join  deviceinventory d on g.DeviceId=d.did 
             WHERE   $condition
			 group by   g.DeviceId order by gatewayUsedCount desc limit 10";

		}
    else
	{
			$qry="SELECT sum(g.UsageCount) as gatewayUsedCount,d.DeviceName 
			FROM tbl_gwayusedloginlog g inner join  deviceinventory d on g.DeviceId=d.did  WHERE d.DeviceGroupID IN (SELECT distinct C.group_id_fk FROM tbl_user_access as C WHERE C.user_id_fk='$this->user_id') AND $condition group by g.DeviceId order by gatewayUsedCount desc limit 10";
	}
			$tblGatewayUseddataArr=$this->appObj->returnQueryData($qry);
			if(count($tblGatewayUseddataArr)>0){
				$i=0;
				foreach($tblGatewayUseddataArr as $statusdata){
					$temp=array(
					'activityDate'=>$statusdata['ActivityDate'],
					'gatewayUsedCount'=>$statusdata['gatewayUsedCount'],
					'deviceName'=>$statusdata['DeviceName'],
					);
					$gatewayUsedJson[$i++]=$temp;
					
					//$i++;
	
				}
			}
	
			return $gatewayUsedJson;
	
		}
		private function getFeatureUsedReport($condition)
		{
			$featureUsedJson=[];
		


		if($this->user_id==1)
		{
			$qry="SELECT f.ActivityDate,sum(f.UsageCount) as featureUsedCount,f.FeatureName 
			FROM tbl_gwayfeaturelog f inner join  deviceinventory d on f.DeviceId=d.did 
               where   $condition 
			group by f.FeatureName  order by featureUsedCount desc ";

		}
		else
		{
			$qry="SELECT f.ActivityDate,sum(f.UsageCount) as featureUsedCount,f.FeatureName 
			FROM tbl_gwayfeaturelog f inner join  deviceinventory d on f.DeviceId=d.did 
			WHERE d.DeviceGroupID IN (SELECT distinct C.group_id_fk FROM tbl_user_access as C WHERE C.user_id_fk='$this->user_id') AND $condition group by f.FeatureName  order by featureUsedCount desc ";

		}
			$tblFeatureUseddataArr=$this->appObj->returnQueryData($qry);
			if(count($tblFeatureUseddataArr)>0){
				$i=0;
				foreach($tblFeatureUseddataArr as $statusdata){
					$temp=array(
                    'activityDate'=>$statusdata['ActivityDate'],
                    'featureUsedCount'=>$statusdata['featureUsedCount'],
					'FeatureName'=>$statusdata['FeatureName'],
					
					);
					$featureUsedJson[$i++]=$temp;
					
                }
			}

			return $featureUsedJson;

		}
		private function getGetewayVersionReport()
		{
			$vesionUsedJson=[];
		


		if($this->user_id==1)
		{
			$qry="SELECT modifydate as ActivityDate ,count(did) as VersionUsedCount,version
		   FROM  deviceinventory where version <>'-1'
			 group by version   order by  VersionUsedCount  desc";

		}
		else
		{
			$qry="SELECT modifydate as ActivityDate,count(did) as VersionUsedCount,version
			FROM  deviceinventory d WHERE d.DeviceGroupID IN (SELECT distinct C.group_id_fk FROM tbl_user_access as C WHERE C.user_id_fk='$this->user_id') AND d.version <>'-1' group  by version  order by VersionUsedCount desc" ;

		}
		
			$tblVersionUseddataArr=$this->appObj->returnQueryData($qry);
			if(count($tblVersionUseddataArr)>0){
				$i=0;
				foreach($tblVersionUseddataArr as $statusdata){
					$temp=array(
                    'activityDate'=>$statusdata['ActivityDate'],
                    'versionUsedCount'=>$statusdata['VersionUsedCount'],
					'version'=>$statusdata['version'],
					
					);
					$vesionUsedJson[$i++]=$temp;
					
                }
			}

			return $vesionUsedJson;

		}
    
    }