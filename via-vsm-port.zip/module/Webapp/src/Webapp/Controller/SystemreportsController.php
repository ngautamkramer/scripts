<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Model\UserTable;
use Webapp\Model\adduser;
use Webapp\Controller\ApplicationController;
use Webapp\Form\UserActivityLogForm;
use Zend\View\Model\JsonModel;
use Webapp\PDF\FPDF;

class SystemreportsController extends AbstractActionController {
	//checking session
	public function onDispatch(MvcEvent $e) {
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['sessionTimeOut'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
		
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index', array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	public function GwaysReportsAction() {
		
	}

	public function getProjectorLogTable() {
		if(!$this->TblProjectorLogTable) {
			$sm = $this->getServiceLocator();
			$this->TblProjectorLogTable = $sm->get('Webapp\Model\TblProjectorLogTable');
		}
		return $this->TblProjectorLogTable;
	}
	
	
	
	
}
