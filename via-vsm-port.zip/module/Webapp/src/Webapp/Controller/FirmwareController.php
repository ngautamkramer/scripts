<?php
  /*****
  * Name    : FirmwareController
  * Desc    : Upload the firmware and check the firmware
  *****/
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\WebProducerController;
use Zend\View\Model\ViewModel;
use Zend\Filter\Decompress;
use ZipArchive;

use Zend\Session\Container; // for session
use Zend\Mvc\MvcEvent;
use Webapp\Form\AppVersionForm;
use Zend\View\Model\JsonModel;
use Webapp\PDF\fpdf;
require(ROOT_BASE_PATH.'/module/Webapp/src/Webapp/PDF/mc_table.php');
class FirmwareController extends AbstractActionController
{	
    /*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is 
	 *                        logged in otherwise redirect to login page
	 *****/
	 
	//checking session
	public function onDispatch(MvcEvent $e) {
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		if(PRODUCT=='via' || PRODUCT=='kds'){
			$getSettingObj = $appObj->getComplexPasswordSettings();
			$getSettingData = $getSettingObj->webadmin_session_timeout;
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
			foreach($tblSessionTimeOutDataArr as $sessiondata){
				$getSettingData=$sessiondata['logoutTime'];
			}
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			if($this->getRequest()->isXmlHttpRequest()) {
				echo 'sessionout';exit;
			}else{
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}	
		}
		//end check session code		
		
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index', array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
	
	/*****
	 *	@Function Name		: uploadFirmwareAction
	 *  @description	    : Upload firmware
     *	@Author			    : Dileep Yadav
	 *  @Date               : 23-May-2020
	 *****/
	
	public function uploadFirmwareAction(){
		if(PRODUCT=='via'){
			if($this->getRequest()->isPost()) {
				ini_set('max_execution_time', 1000);
				set_time_limit(0);
				$firmware_password = "w0wfirmw@are";
				$path = UPLOAD_PATH;
				$appObj = new ApplicationController();
				$currentModel = $appObj->getModelName();
				$getViaModelName = $appObj->getModelNameByParam('updatefirmwaretag');
				$postData = $this->getRequest()->getPost()->toArray();
				if($postData['fileFlag'] == 'newfile') {
					$file = $this->params()->fromFiles('userfile');
					$fnameVal = explode(".", $file['name']);
					$lastElement = end($fnameVal);
					if(strtolower($lastElement)!= "zip") {
						echo "This is invalid file.";
						die;
					}
					//security check
					$chkFileName = $file['name'];					
					//Now from version 3.2, we read firmware package name from json
					$searchStringModelName = strtolower($appObj->getModelNameByParam('updatefirmwaretag')).'-';
					if(strstr($chkFileName, $searchStringModelName)) {
						$getStrLen = strlen($searchStringModelName);
						$subPart = substr($chkFileName, $getStrLen);
						$FinalSubStringArr = explode('.', $subPart);
						if(is_numeric($FinalSubStringArr[0])&& is_numeric($FinalSubStringArr[1])&& is_numeric($FinalSubStringArr[2])&& is_numeric($FinalSubStringArr[3])) {
						} else {
							echo 404;die;
						}
					} else {
						echo 404;die;
					}
					
					//Upload and extract the file
					$filepath = $path . $file['name'];
					$up = move_uploaded_file($file['tmp_name'], $path . 
											 $file['name']);
					$zip = new ZipArchive();
					if($zip->open($filepath)=== true) {
						$zip->setPassword($firmware_password);
						$zip->extractTo($path);
						$res = (array) $zip;
						$fileRes = $res['filename'];
						$zip->close();
						if($fileRes) {
							if(GET_OS == 'WIN') {
								$filename = str_replace('zip', 'exe', $file['name']);
							} else {
								$chkValid = end(explode(".", $fileRes));
								//if(trim($chkValid)== "rpm" || trim($chkValid)== "deb") {
									if($getViaModelName == "connectplus"  || $getViaModelName == "viago2" || $getViaModelName == "connect2"  || $getViaModelName == "viago3" || $getViaModelName == "connect3") {
										$filename = str_replace('zip', 'deb', $file['name']);
									} else {
										$filename = str_replace('zip', 'rpm', $file['name']);
									}
								//}
							}
							if(file_exists($filepath)) {
								unlink($filepath);
							}
							//condition added for checking existance of package after unzip									
							if(!file_exists($path.$filename)) {
								die("Corrupt");
							}
							
							/*$conn = $appObj->getConnection();
							$queryRes = $conn->execute("SELECT count(*) as rcount FROM autoupdate WHERE PackageName='$filename'");
							$checkCount = $queryRes->current();
							$connAutoObj = $appObj->getConnection();
							if($checkCount['rcount'] == 0) {
								$query = "INSERT INTO autoupdate SET PackageName='$filename', UploadDate=now()";
							} else {
								$query = "UPDATE autoupdate SET PackageName='$filename', UploadDate=now() WHERE PackageName='$filename'";
							}
							$qryResponse = $conn->execute($query);*/
							if(file_exists($path . $filename)) {
								if(GET_OS == 'WIN') {
									$appObj->updateFirmwareVersionCmd($path . 
																	  $filename);
									echo "Success";
									die;
								} else {
									if(strstr($filename, '.deb')) {
										$output = exec("/usr/bin/sudo dpkg-deb -I $path".$filename." 2> /var/www/html/public/uploads/error.txt", $totalOut, $returnval);
										sleep(0.5);
										$output = exec("/usr/bin/sudo dpkg -i $path".$filename." 2> /var/www/html/public/uploads/error.txt", $totalOut, $returnval);
										sleep(0.1);
										$lines = file("/var/www/public/html/uploads/error.txt");
										// Loop through our array, show HTML source as HTML source; and line numbers too.
	
										foreach($lines as $line_num => $line) {
											if(strstr($line, "error:")!= "") {
												$errorFlag = 1;												
												echo MSG_FAILED_INSTALL_UPDATE;
												exit;
											} else if(strstr($line, "already installed")!= "") {
												$errorFlag = 1;												
												echo MSG_UPDATE_ALREADY_INSTALL;
												exit;
											}
										}
									} else { 
										$output = exec("/usr/bin/sudo /bin/rpm -qip $path".$filename ." 2> /var/www/html/public/uploads/error.txt", $totalOut, $returnval);
										sleep(0.5);
										$output = exec("/usr/bin/sudo /bin/rpm -iUvh $path".$filename." 2> /var/www/html/public/uploads/error.txt", $totalOut, $returnval);
										sleep(0.1);
										$lines = file("/var/www/html/public/uploads/error.txt");
										// Loop through our array, show HTML source as HTML source; and line numbers too.
	
										foreach($lines as $line_num => $line) {
											if(strstr($line, "error:")!= "") {
												$errorFlag = 1;												
												echo MSG_FAILED_INSTALL_UPDATE;
												exit;
											} else if(strstr($line, "already installed")!= "") {
												$errorFlag = 1;
												echo MSG_UPDATE_ALREADY_INSTALL;
												exit;
											}
										}
									}
									echo "Success";
									die;
								}
							} else {
								echo "NotFound";
								die;
							}
						} else {
							echo "Corrupt";
							exit;
						}
					}
				}
			}
		}else{
			$session = new Container('userinfo');
			$user_id = $session->offsetGet('usrid');
			$poll_encryption_key = POLL_ENCRYPTION_KEY;
			$appObj = new ApplicationController();
			$resData=$appObj->returnQueryData("SELECT AES_DECRYPT(firmware_package_name,'$poll_encryption_key') as firmware_package_name ,id from tbl_firmware_list where status=1 ORDER BY created_on DESC"); 
			
			$result = $this->getDevicegroupTable()->fetchAll();
			$arrayCategories = array();
			foreach($result as $row){
				$arrayCategories[$row->DeviceGroupID] = array("grp_id" => $row->DeviceGroupID, "parent_id" => $row->DeviceMasterID, "name" =>$row->DeviceGroup, "level" =>$appObj->getDepth($row->DeviceGroupID));   
			}
			if($user_id !=1){
				$deviceGroup = $this->getDevicegroupTable()->getGroupWithPermission($user_id);
			}
			//get the data from tbl_firmware_port (15-March-2021)
			$portData=$appObj->returnQueryData("SELECT AES_DECRYPT(package_name,'$poll_encryption_key') as firmware_package_name ,id from tbl_firmware_port where package_url IS NOT NULL OR package_url !='' ORDER BY id DESC");
			
			//Get the server current time
		    $responseData = $appObj->returnQueryData("Select now() as cdatetime;");
		    $getDateTimeArr = $responseData->current();
			
			return new ViewModel(array(
				'data' => $resData,
				'portData'=>$portData,
				'arrayCategories'=>$arrayCategories,
				'deviceGroup'=>$deviceGroup,
                'currentDateTime' => $getDateTimeArr['cdatetime']					
			));	
		}	
	}
	
	/*****
	 *	@Function Name		: checkFirmwareFileAction
	 *  @description	    : Check firmware file 
	 *	@Author			    : Dileep Yadav
	 *  @Date               : 25-May-2020
	 *****/

	public function checkFirmwareFileAction() {
		if($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$userfile = $postData['userfile'];
			$selMode= $postData['selMode'];
			if(strstr($userfile, '\\')) {
				$url_arr = explode("\\", $userfile);
				$ct = count($url_arr);
				$userfile = $url_arr[$ct - 1];
			} else {
				$userfile = $userfile;
			}
			
			$FileExt=strtolower(trim((substr($userfile,strlen($userfile)-4,4))));
			// checking disc space
			$getOS=strtoupper(substr(PHP_OS, 0, 3));
			if($getOS=='WIN'){
				$getFreeSpace=disk_free_space("C:");
				$getSpaceInMB = floor($getFreeSpace /(1024 * 1024));
				if($getSpaceInMB < 5125){
					echo "lowDiscSpace";die;
				}
			}
			echo"newfile";exit;
		}
	}
	
	/*****
	 *	@Function Name		: uploadFirmwareProcessAction
	 *  @description	    : upload firmware process
	 *	@Author			    : Dileep Yadav
	 *  @Date               : 25-May-2020
	 *****/
	public function uploadFirmwareProcessAction(){
		if($this->getRequest()->isPost()) {
			$session = new Container('userinfo');
		    $user_id = $session->offsetGet('usrid');
			ini_set('max_execution_time', 0);
			$firmware_password ="w0wfirmw@are";
			$path = UPLOAD_PATH;
			$appObj = new ApplicationController();
			$poll_encryption_key = POLL_ENCRYPTION_KEY;	
			$postData = $this->getRequest()->getPost()->toArray();
			if($postData['fileFlag'] == 'newfile') {
				$file = $this->params()->fromFiles('userfile');
				$filename = $file['name'];
				if(!empty($filename)){
					//Upload and extract the file
				     $filepath = $path . $file['name'];
				     $up = move_uploaded_file($file['tmp_name'], $path . $file['name']);
						if($postData['setYourOption']==0 || $postData['setYourOption']==2){
							 $flag="exe";
						}else{
							 $flag="rpm";
						}
						$zip = new ZipArchive();
						if($zip->open($filepath)=== true) {
							$zip->setPassword($firmware_password);
							$zip->extractTo($path);
							$res = (array) $zip;
							$fileRes = $res['filename'];
							$zip->close();
							if($fileRes) {
								if($postData['setYourOption']==4){								
									$flag="deb";							 
								}
								//get the firmware package version
				                $packVerionArr = explode(".",str_replace("-",".",$file['name']));
								if(is_numeric($packVerionArr[1])){
									$getVersion = $packVerionArr[1].".".$packVerionArr[2];
								}else{
									$getVersion = $packVerionArr[2].".".$packVerionArr[3];
								}
								if($getVersion > 3.0){
									$filename=$filename;
									unlink($path . str_replace('zip',$flag,$filename));
								}else{
									$filename=str_replace('zip',$flag,$filename);
									unlink($path . $file['name']);
								}
								
							}else{
								echo"Corrupt";
								exit;	
							}
						}
					try{ 
					    $packageUrl=PUBLIC_URL."/uploads/".$filename;
						//update the md5 for existing entry in AutoUpdateDone.
						$autpupdateData=$appObj->returnQueryData("SELECT count(*) as cnt FROM AutoUpdateDone WHERE AES_DECRYPT(PackageName,'$poll_encryption_key')='$filename'");
						if($autpupdateData->current() > 0){
							$md5Hash="";
							if(file_exists($path.$filename)){
								$md5Hash=md5_file($path.$filename);
							}
							$appObj->returnQueryData("UPDATE AutoUpdateDone SET md5='$md5Hash' WHERE AES_DECRYPT(PackageName,'$poll_encryption_key')='$filename'");
						} 
						$get_sql_qry=$appObj->returnQueryData("SELECT id FROM tbl_firmware_list WHERE AES_DECRYPT(firmware_package_name,'$poll_encryption_key')='$filename'");
						if($get_sql_qry->current() !=""){ 
							 $appObj->returnQueryData("UPDATE tbl_firmware_list SET created_on=now(),package_md5=AES_ENCRYPT('$md5Hash','$poll_encryption_key') WHERE AES_DECRYPT(firmware_package_name,'$poll_encryption_key')='$filename' AND user_id='$user_id'");
						}else{ 
							 $appObj->returnQueryData("INSERT INTO tbl_firmware_list SET firmware_package_name=AES_ENCRYPT('$filename','$poll_encryption_key'), user_id='$user_id',package_md5=AES_ENCRYPT('$md5Hash','$poll_encryption_key'),package_url=AES_ENCRYPT('$packageUrl','$poll_encryption_key'),created_on=now()");	
						}
						echo"Success";die();	
					}catch(Exception $e){
						echo"Error";die();
					}
				}		
			}
		}
		die;
	}
	
	/*****
	 *	@Function Name		: validateFileAction
	 *  @description	    : Validate the selected file
	 *	@Author			    : Dileep Yadav
	 *  @Date               : 25-May-2020
	 *****/

	public function validateFileAction() { 
		if(PRODUCT=='via'){
			if($this->getRequest()->isPost()) {
				$postData = $this->getRequest()->getPost()->toArray();
				$userfile = $postData['userfile'];
				if(strstr($userfile, '\\')) {
					$url_arr = explode("\\", $userfile);
					$ct = count($url_arr);
					$userfile = $url_arr[$ct - 1];
				} else {
					$userfile = $userfile;
				}
				$versionArr = explode(".", trim($userfile));
				if(GET_OS == 'WIN') {
					$version = $versionArr[3];
					$getFreeSpace = disk_free_space("C:");
				} else {
					$version = $versionArr[3];
					$getFreeSpace = disk_free_space("/");
				}
				
				$appObj = new ApplicationController();
				$secondDestPath = $appObj->getModelNameByParam('firmversion');
				//$secondDestPath = $appObj->file_read(SECOND_DEST_PATH.FILE_VERSION_FILE);
				$currentVersionArr = explode(".", $secondDestPath);
				$currentVersion = $currentVersionArr[3];
				if($version != '' && $version <= $currentVersion) {
					echo "lowerVersion";
					die;
				}
				// checking disc space
				$getSpaceInMB = floor($getFreeSpace /(1024 * 1024));
				if($getSpaceInMB < 5125) {
					echo "lowDiscSpace";
					die;
				}
				$FileExt = strtolower(trim((substr($userfile, strlen($userfile)- 4, 4))));
				if($FileExt == ".zip") {
					echo "newfile";
					die;
				} else {
					echo "invalidformatExe";
					die;
				}
			}
		}else{
			if($this->getRequest()->isPost()) {
				$postData = $this->getRequest()->getPost()->toArray();
				$userfile = $postData['userfile'];
				if(strstr($userfile, '\\')) {
					$url_arr = explode("\\", $userfile);
					$ct = count($url_arr);
					$userfile = $url_arr[$ct - 1];
				} else {
					$userfile = $userfile;
				}
				//Compare package version with vsm version
				$packVerionArr = explode(".",str_replace("-",".",$userfile));
				if(is_numeric($packVerionArr[1])){
					$getVersion = $packVerionArr[1].".".$packVerionArr[2];
				}else{
					$getVersion = $packVerionArr[2].".".$packVerionArr[3];
				}
				$getVSMFileVersion = file_get_contents(SECOND_DEST_PATH.VSM_VERSION_FILE);
				$getVsmVersionArr = explode(".",$getVSMFileVersion);
				$getVsmVersion = $getVsmVersionArr[0].".".$getVsmVersionArr[1];
				if(!file_exists(SECOND_DEST_PATH."allow_package.txt")){
					if($getVersion > $getVsmVersion){
						echo "lowervsm";die;
					}
				}
				
				if($userfile){
					$this->checkFileValidationAction($userfile);	
				}
				die;
			}
		}
	}
	
	//Validate the firmware file
	function checkFileValidationAction($userfile){
		$searchStringCollage='VIA-Update-';
		$searchStringConnect='update_connect-';
		$searchStringCampus='Campus-Update-';
		$searchStringViago='update_viago-';
		$searchStringConnectPlus='update_cpplus-';		
	
		//Now from version 3.2, we read firmware package name from json
		$modelJson = DEST_PATH.'model.json';
		$modelObj = json_decode(file_get_contents($modelJson));
		foreach($modelObj as $ostype => $model){
			$searchStringModelName = strtolower($model->updatefirmwaretag).'-';
			if(strstr($userfile,$searchStringModelName)){
				$getStrLen=strlen($searchStringModelName);
				$subPart=substr($userfile,$getStrLen);
				$FinalSubStringArr=explode('.',$subPart);
				if(is_numeric($FinalSubStringArr[0]) && is_numeric($FinalSubStringArr[1]) && is_numeric($FinalSubStringArr[2]) && is_numeric($FinalSubStringArr[3]) ){
					echo $model->modellike;die;
				}else{
					// replace 4 with 404. it is error
					echo 404;die;	
				}
			}
		}
		
		if(strstr($userfile,$searchStringCollage)){
				$getStrLen=strlen($searchStringCollage);
				$subPart=substr($userfile,$getStrLen);
				$FinalSubStringArr=explode('.',$subPart);
				if(is_numeric($FinalSubStringArr[0]) && is_numeric($FinalSubStringArr[1]) && is_numeric($FinalSubStringArr[2]) && is_numeric($FinalSubStringArr[3]) ){
					echo 0;
				}else{
					// replace 4 with 404. it is error
					echo 404;	
				}
			
		}elseif(strstr($userfile,$searchStringConnect)){
				$getStrLen=strlen($searchStringConnect);
				$subPart=substr($userfile,$getStrLen);	
				if(strstr($subPart,'-')){
					$subPart=str_replace('-','.',$subPart);
					$FinalSubStringArr=explode('.',$subPart);
					if( is_numeric($FinalSubStringArr[0]) && is_numeric($FinalSubStringArr[1]) && is_numeric($FinalSubStringArr[2]) && is_numeric($FinalSubStringArr[3]) ){
						echo 1;
					}else{
						// replace 4 with 404. it is error
						echo 404;		
					}
				}else{
					// replace 4 with 404. it is error
					echo 404;	
				}

		}elseif(strstr($userfile,$searchStringCampus)){
				$getStrLen=strlen($searchStringCampus);
				$subPart=substr($userfile,$getStrLen);
				$FinalSubStringArr=explode('.',$subPart);
				if(is_numeric($FinalSubStringArr[0]) && is_numeric($FinalSubStringArr[1]) && is_numeric($FinalSubStringArr[2]) && is_numeric($FinalSubStringArr[3]) ){
					echo 2;
				}else{
					// replace 4 with 404. it is error
					echo 404;	
				}

		}elseif(strstr($userfile,$searchStringViago)){
				$getStrLen=strlen($searchStringViago);
				$subPart=substr($userfile,$getStrLen);	
				if(strstr($subPart,'-')){
					$subPart=str_replace('-','.',$subPart);
					$FinalSubStringArr=explode('.',$subPart);
					if( is_numeric($FinalSubStringArr[0]) && is_numeric($FinalSubStringArr[1]) && is_numeric($FinalSubStringArr[2]) && is_numeric($FinalSubStringArr[3]) ){
						echo 3;
					}else{
						// replace 4 with 404. it is error
						echo 404;	
					}
				}else{
					  //replace 4 with 404. it is error
					  echo 404;	
				}
		}elseif(strstr($userfile,$searchStringConnectPlus)){
				$getStrLen=strlen($searchStringConnectPlus);
				$subPart=substr($userfile,$getStrLen);	
				if(strstr($subPart,'-')){
					$subPart=str_replace('-','.',$subPart);
					$FinalSubStringArr=explode('.',$subPart);
					if( is_numeric($FinalSubStringArr[0]) && is_numeric($FinalSubStringArr[1]) && is_numeric($FinalSubStringArr[2]) && is_numeric($FinalSubStringArr[3]) ){
						echo 4;
					}else{
						// replace 4 with 404. it is error
						echo 404;		
					}
				}else{
					// replace 4 with 404. it is error
					echo 404;	
				}
		}else{
			// replace 4 with 404. it is error
			  echo 404;	
		}
		die;
	}

	
	/*****
	 *	@Function Name		: deletePackageAction
	 *  @description	    : Delete the uploaded firmware packages
     *	@Author			    : Dileep Yadav
	 *  @Date               : 26-May-2020
	 *****/
	
	public function deletePackageAction(){
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$packageName =  trim ($postData['package_name']);
			//Added condition : Delete from tbl_firmware_port(Date 11-Dec-2018)
			$firmname=explode(".",$packageName);
			array_pop($firmname);
			array_push($firmname,"zip");
			$firmPackName=implode(".", $firmname);
		    if(!empty($packageName)){ 
              $poll_encryption_key = POLL_ENCRYPTION_KEY;
		      $appObj = new ApplicationController();	
			  
			  $query=$appObj->returnQueryData("SELECT A.* FROM AutoUpdateDone A INNER JOIN events B ON B.event_id=A.event_id_fk WHERE AES_DECRYPT(A.PackageName,'$poll_encryption_key')='$packageName' AND deviceID_Fk IN (SELECT DID FROM DeviceInventory WHERE CONVERT(SUBSTRING_INDEX(Version,'.',-1),UNSIGNED INTEGER) < CONVERT(SUBSTRING_INDEX(A.pkgversion,'.',-1),UNSIGNED INTEGER))");
			  $data = $query->current();
			  if(is_array($data) && count($data)  > 0){
				  echo 1;die;  // Already Scheduled - can not be deleted
			  }else{
				  $query=$appObj->returnQueryData("SELECT event_id_fk FROM AutoUpdateDone WHERE AES_DECRYPT(PackageName,'$poll_encryption_key')='$packageName'");
				  foreach($query as $row){
					  $eventId .=$row[0].",";
				  }
				  $newEventId=rtrim($eventId,",");
				  $appObj->returnQueryData("DELETE FROM events WHERE event_id IN ('$newEventId')");
				  $appObj->returnQueryData("DELETE FROM events_detail WHERE event_id IN ('$newEventId')");
				  $appObj->returnQueryData("DELETE FROM AutoUpdateDone WHERE AES_DECRYPT(PackageName,'$poll_encryption_key')='$packageName'");
				  $appObj->returnQueryData("DELETE FROM tbl_firmware_list WHERE AES_DECRYPT(firmware_package_name,'$poll_encryption_key')='$packageName'");
				  //Delete From tbl_firmware_port (Date 11-Dec-2018)
				  $appObj->returnQueryData("DELETE FROM tbl_firmware_port WHERE AES_DECRYPT(package_name,'$poll_encryption_key')='$firmPackName'");
				  
				  unlink("../".$imgDir.$packageName);  // unlink the firmware
				  unlink("../".$imgDir.$firmPackName);  // unlink the zip file
				  echo 2;die; //For Success - Deleted Succesfully
		    }
		  }else{
			  echo 3;die;
		  }
			
		}
	}
	
	/*****
	 *	@Function Name		: getGatewayListAction
	 *  @description	    : get the gateway list based on package
     *	@Author			    : Dileep Yadav
	 *  @Date               : 11-June-2020
	 *****/
	
	public function getGatewayListAction(){
		if ($this->getRequest()->isPost()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
		    $user_id = $session->offsetGet('usrid');
			$poll_encryption_key = POLL_ENCRYPTION_KEY;
			
			$postData = $this->getRequest()->getPost()->toArray();
			$filName =  trim ($postData['package_name']);
			$modelId =  trim ($postData['modelId']);
			$modelTypeNew =  trim ($postData['new_model_type']);
			if(isset($postData['grp_ids'])){
				$newGrpIds = implode(",",$postData['grp_ids']);
			}
			if($newGrpIds==""){
				$str="Select DeviceGroupID from devicegroup order by DeviceGroup";
				$result=$appObj->returnQueryData($str); 
				foreach($result as $grpVal){
					$allGrpId.=$grpVal['DeviceGroupID'].",";
				}
				$newGrpIds=rtrim($allGrpId, ','); 
			 }
		    $firmwareName=explode("-",$filName);
			$checkFirmVer=0;
			if($modelTypeNew){ 
		        $firmwareName=explode(".",$firmwareName[1]);
				$firmwareVersion3=$firmwareName[3];
				$checkFirmVer = $firmwareName[0].".".$firmwareName[1];
			}else{
				$firmwareName=explode(".",$firmwareName[2]);
				if($modelId==1 || $modelId==3 || $modelId==4 ){   // Added new model type 4 for Connect Plus
					$firmwareVersion3=$firmwareName[2];
				}else{
					$firmwareVersion3=$firmwareName[3];
				}
			}
			$deviceIdDiffArray=array();
		    $finalDeviceIdArray=array();
			if($modelTypeNew){  // For new firmware update (3.0 onwards)
			     if($user_id==1){ 
					$sqlNew1=$appObj->returnQueryData("SELECT DISTINCT(B.DID) FROM DeviceInventory AS B INNER JOIN tbl_device_extra_info C ON C.deviceID_Fk=B.DID WHERE C.update_firmware_tag='$modelTypeNew' AND C.model_value NOT IN(2,7) AND CONVERT(SUBSTRING_INDEX(B.Version,'.',-1),UNSIGNED INTEGER)< $firmwareVersion3 AND B.DeviceGroupID IN ($newGrpIds)");
				}else{
					$sqlNew1=$appObj->returnQueryData("SELECT DISTINCT(B.DID) FROM DeviceInventory AS B INNER JOIN tbl_device_extra_info C ON C.deviceID_Fk=B.DID INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID WHERE C.update_firmware_tag='$modelTypeNew' AND C.model_value NOT IN(2,7) AND CONVERT(SUBSTRING_INDEX(B.Version,'.',-1),UNSIGNED INTEGER)< $firmwareVersion3 AND B.DeviceGroupID IN ($newGrpIds) AND TUA.user_id_fk=$user_id");  
				} 
			}
			else{ // For old firmware update
                 if($user_id==1){ 
					$sqlNew1=$appObj->returnQueryData("SELECT DISTINCT(B.DID) FROM DeviceInventory B WHERE B.os_type='$modelId' AND CONVERT(SUBSTRING_INDEX(B.Version,'.',-1),UNSIGNED INTEGER)< $firmwareVersion3 AND B.DeviceGroupID IN ($newGrpIds) AND B.DID NOT IN (SELECT deviceID_Fk FROM tbl_device_extra_info WHERE model_value IN (13,12,11))");
				}else{
					$sqlNew1=$appObj->returnQueryData("SELECT DISTINCT(B.DID) FROM DeviceInventory B INNER JOIN tbl_user_access AS TUA ON TUA.group_id_fk=B.DeviceGroupID WHERE B.os_type='$modelId' AND CONVERT(SUBSTRING_INDEX(B.Version,'.',-1),UNSIGNED INTEGER)< $firmwareVersion3 AND B.DeviceGroupID IN ($newGrpIds) AND TUA.user_id_fk=$user_id AND B.DID NOT IN (SELECT deviceID_Fk FROM tbl_device_extra_info WHERE model_value IN (13,12,11))");  
				}   				
			}
		   
			foreach($sqlNew1 as $didVal){
			       $returnDeviceId .=$didVal['DID'].",";
		    }
			$returnDeviceId=rtrim($returnDeviceId,",");
			if($returnDeviceId){
				$sqlNew2=$appObj->returnQueryData("SELECT group_concat(deviceID_Fk) as deviceId FROM AutoUpdateDone WHERE deviceID_Fk IN ($returnDeviceId) AND AES_DECRYPT(PackageName,'$poll_encryption_key')='$filName' ");
				if(count($sqlNew2) > 0){
					foreach($sqlNew2 as $fetch2){
						$exists_deviceId=$fetch2['deviceId'];
					}
					$exists_deviceId=rtrim($exists_deviceId,",");
					//echo $exists_deviceId;
					$deviceIdDiffArray=array_diff(explode(",",$returnDeviceId),explode(",",$exists_deviceId));  // array diff
				    if($exists_deviceId){
						$sqlNew3=$appObj->returnQueryData("SELECT group_concat(B.deviceID_Fk) as deviceId FROM events A INNER JOIN AutoUpdateDone B ON B.event_id_fk=A.event_id WHERE B.deviceID_Fk IN ($exists_deviceId) AND A.end_date < now()");
						if(count($sqlNew3) > 0){
						   foreach($sqlNew3 as $fetch3){
								$auto_deviceId=$fetch3['deviceId'];
						   
							}
						}  
					}
				}
				$finalDeviceIdArray=array_merge($deviceIdDiffArray,explode(",",$auto_deviceId));
				$finalDeviceIdStr=implode(",",$finalDeviceIdArray);
				$finalDeviceIdStr=rtrim($finalDeviceIdStr,",");
		        if($finalDeviceIdStr){
					if($firmwareVersion3==788){
					 $cstmVersion=" (B.Version > '1.9.000.000' OR B.Version like '2.%')";
					}else if($firmwareVersion3 >=961 ){   // Added for verion 2.4 (Date18-April-2018)	
						 $cstmVersion=" CONVERT(SUBSTRING_INDEX(B.Version,'.',-1),UNSIGNED INTEGER) >= 960";
					}else if($checkFirmVer > 3.0 ){   // Added for verion 3.0	
						 $cstmVersion=" CONVERT(SUBSTRING_INDEX(B.Version,'.',-1),UNSIGNED INTEGER) >= 1068";
					}
					else{
						 $cstmVersion=" B.Version like '2.%'";
					}
					$qry="SELECT B.DeviceName, B.DeviceGroupID, B.DID, A.*, C.*,B.Version, B.Active FROM tbl_sys_report AS A INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk INNER JOIN tbl_device_live_status AS C ON C.did_fk = A.did_fk where A.did_fk IN ($finalDeviceIdStr) AND $cstmVersion AND B.DID NOT IN (SELECT deviceID_fk FROM tbl_linuxgateway_os_version) ORDER BY B.DeviceName ASC"; 
					
					$responseData = $appObj->returnQueryData($qry);
					$cnt=0;
					foreach($responseData as $resVal){
						if($resVal['HD_Status'] < 81){
							//added by ashu on 15Jun23 for locking gateways which has C value in Active field  of DeviceInventory
							if(strtolower($resVal['Active'])=='c'){
								$lockImg=PUBLIC_URL.'/img/via/icon/locked.svg';								
								$resData .=' <div class="col-sm-12 no-padder"><div class="checkbox m-t-xxs"><label class="checkbox-custom"><input type="checkbox" name="'.$resVal['DeviceName'].'" disabled="disabled"><label for="'.$resVal['DeviceName'].'"><span class="m-l-xs"></span>'.$resVal['DeviceName'].'</label></label>&nbsp;&nbsp;<img src="'.$lockImg.'" width="20" height="20" /></div></div>';							
															
							}else{	
							$resData .=' <div class="col-sm-12 no-padder"><div class="checkbox m-t-xxs"><label class="checkbox-custom"><input type="checkbox" id="'.$resVal['DeviceName'].'" name="'.$resVal['DeviceName'].'" value="'.$resVal['DID'].'" class="gwayids" ><label for="'.$resVal['DeviceName'].'"><span class="m-l-xs"></span>'.$resVal['DeviceName'].'</label></label></div></div>';
							}
						}else{
							$resData .=' <div class="col-sm-12 no-padder"><div class="checkbox m-t-xxs"><label class="checkbox-custom" style="margin-left:10px;">'.$resVal['DeviceName'].'</label>&nbsp;(<font color="red">Space not available</font>)</div></div>';
						}
						$cnt++;
					}
				}else{
					$resData="";
				}
			}else{
				$resData="";
			}
		    
			
			
			/*if($user_id == 1){
				$qry="SELECT B.DeviceName,B.DeviceIP,B.Active,B.oldIPAddess,B.DeviceID, B.DeviceGroupID, B.DID, A.*, C.*,B.Version FROM tbl_sys_report AS A INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk LEFT JOIN tbl_device_live_status AS C ON C.did_fk = A.did_fk WHERE 1 AND B.os_type!=-1";
			}else{ 
				$grpData = $appObj->returnQueryData("select DISTINCT(group_id_fk) from tbl_user_access where user_id_fk=$user_id");
				foreach($grpData as $val){
					$grpIds .=$val['group_id_fk'].",";
				}
				$grpIds=rtrim($grpIds,",");
				$qry="SELECT DISTINCT(B.DeviceName),B.DeviceIP,B.Active,B.oldIPAddess,B.DeviceID, B.DeviceGroupID, B.DID, A.*, C.*,B.Version FROM tbl_sys_report AS A INNER JOIN DeviceInventory AS B ON B.DID = A.did_fk LEFT JOIN tbl_device_live_status AS C ON C.did_fk = A.did_fk WHERE B.DeviceGroupID IN ($grpIds) AND B.os_type!=-1";
			}*/
			if(empty($cnt)){
				$cnt = 0;
			}
			echo $cnt."|$|".$resData;die;
		}
	}
	
	//Schedule the firmware instant
	public function setInstantFirmwareAction(){
		if($this->getRequest()->isPost()) {
			$subPart="";
            $md5Hash="";
			$path = UPLOAD_PATH;
			$poll_encryption_key = POLL_ENCRYPTION_KEY;
			$postData = $this->getRequest()->getPost()->toArray();
			$optionVal=$postData['optionVal'];
			$arrChkbox=$postData['chkboxIP'];
			$filename=$postData['userfile'];
			$scheduleName=$postData['scheduleName'];
			if(file_exists($path.$filename)){
				$md5Hash=md5_file($path.$filename);
			}
			// Found Versions From File
	        $setYourOption=$postData['setYourOption'];
            
			$session = new Container('userinfo');
		    $user_id = $session->offsetGet('usrid');
		    $modelContent = $session->offsetGet('modelContent');
			//get the firmware package version
			$packVerionArr = explode(".",str_replace("-",".",$filename));
			if(is_numeric($packVerionArr[1])){
				$getVersion = $packVerionArr[1].".".$packVerionArr[2];
			}else{
				$getVersion = $packVerionArr[2].".".$packVerionArr[3];
			}
			if($getVersion > 3.0){
				$getPackageVersionArr = explode('-',$filename);
				$FinalSubStringArr = explode('.',$getPackageVersionArr[1]);
				$pkgversion=$FinalSubStringArr[0].'.'.$FinalSubStringArr[1].'.'.$FinalSubStringArr[2].'.'.$FinalSubStringArr[3];
				$buildNo=$FinalSubStringArr[3];
			}else{
				if($setYourOption=="collage"){
				$searchString='VIA-Update-';
				}
				if($setYourOption=="connect"){
					$searchString='update_connect-';
				}
				if($setYourOption=="campus"){
					$searchString='Campus-Update-';
				}
				if($setYourOption=="viago"){
					$searchString='update_viago-';
				}
				if($setYourOption=="connectplus"){
					$searchString='update_cpplus-';
				}
				$getStrLen=strlen($searchString);		
				if(strstr($filename,$searchString)){
					$subPart=substr($filename,$getStrLen);
				}
				// Find - in the subpart
				if(strstr($subPart,'-')){
					$subPart=str_replace('-','.',$subPart);
				}
				$FinalSubStringArr=explode('.',$subPart);
				$pkgversion=$FinalSubStringArr[0].'.'.$FinalSubStringArr[1].'.'.$FinalSubStringArr[2].'.'.$FinalSubStringArr[3];
				$buildNo=$FinalSubStringArr[3];
			}
			
			$countSelChkBox=(count($arrChkbox)>0)?count($arrChkbox):0;
			
			if(isset($postData['instantPush'])){
				 $sql_query="insert into events(start_date,end_date,event_name,details,event_type,userId_fk,schedule_type ) values (NOW(),NOW()+ INTERVAL 24 HOUR,'$scheduleName','',' ','$user_id','0') ";
				 $appObj = new ApplicationController();
				 $appObj->returnQueryData("START TRANSACTION");//begin transtion
				 $execute=$appObj->returnQueryData($sql_query);
				 //$lastInsertId = $execute->getResource()->insert_id;
				 //if(empty($lastInsertId)){
					$lastInsertId = isset($execute->getResource()->insert_id)? $execute->getResource()->insert_id : $execute->getGeneratedValue();
				 //}
				 
				 //$customeSql="INSERT INTO events_detail(deviceId_fk,event_id) VALUES";
				 //$value_array=array();
				
				 $customeSql2="INSERT INTO AutoUpdateDone(deviceID_Fk,PackageName,pkgversion,ModifyDateTime,md5,buildNo,event_id_fk,firmware_path) VALUES";
				 $value_array2=array();
				 //Firmware path
				 $firmwarePath = PUBLIC_URL."/uploads/".$filename;
				 foreach($arrChkbox as $gway_val){
					if(!empty($gway_val)){
						$gatewayId_fk="'".$gway_val."'";
						//$value_array[] = "($gatewayId_fk,'$lastInsertId')"; 
						$value_array2[] = "($gatewayId_fk,AES_ENCRYPT('$filename','$poll_encryption_key'),'$pkgversion',now(),'$md5Hash','$buildNo','$lastInsertId','$firmwarePath')";
						$gwayIdsArr .= $gway_val.",";
					}
				 }
				 $gwayIdsArr =rtrim($gwayIdsArr,",");
				 //$customeSql .= implode(',', $value_array);
				 //$execute1=$appObj->returnQueryData($customeSql);
				 $execute1=$appObj->returnQueryData("UPDATE tbl_device_live_status SET firmware_process=1 WHERE did_fk IN ($gwayIdsArr)");
				
				 $customeSql2 .= implode(',', $value_array2);
				 $execute2=$appObj->returnQueryData($customeSql2);
				 
				 if ($execute1 and $execute2 and $execute) {
					$appObj->returnQueryData("COMMIT");  //COMMIT IF SAVE THE DATA SUCCESSFULLY
				 } else {        
					$appObj->returnQueryData("ROLLBACK"); // ROLLBACK in case of failure
					echo "Something went wrong.";die;
				 }
			}
			if($getVersion > 3.0){
				//Rabbit MQ Code
				$cmdArr=array("cmd"=>"push_firmware","sender"=>"web-vsm");
				$cmdJson=json_encode($cmdArr);
				$producerObject=new WebProducerController();
				$producerObject->rabbitWebProducerAction($cmdJson);
			}else{
				//send the command to api server.
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$rebootcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>updatenow</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$appObj->sendMsgToAPIserver($logincmd,$rebootcmd);
			}
			
			$appObj->ActivityLogVSM(4,$filename.' Updated',13);
			echo "success";die();
			
		}
	}
	
	//Schedule the firmware 
	public function setScheduleFirmwareAction(){
		if($this->getRequest()->isPost()) {
			$appObj = new ApplicationController();
			$subPart="";
            $md5Hash="";
			$path = UPLOAD_PATH;
			$poll_encryption_key = POLL_ENCRYPTION_KEY;
			$postData = $this->getRequest()->getPost()->toArray();
			$optionVal=$postData['optionVal'];
			$arrChkbox=explode(",",$postData['chkboxIP']);
			$filename=$postData['userfile'];
			$scheduleName=$postData['scheduleName'];
			$startDate=$postData['start_date']." ".$postData['start_hour'].":00";
			$endDate=$postData['end_date']." ".$postData['end_hour'].":00";
			//check the date time diff
			$sTime=strtotime($startDate);
			$eTime=strtotime($endDate);
			$diff_min=round(abs($eTime - $sTime) / 60,2);
			if($diff_min < 360){
				echo "End date time should be greater than 6 hour from start date time.";die;
			}
			//$todayDate=strtotime(date('Y-m-d H:i:s'));
			$getTodayDateArr = $appObj->returnQueryData("Select now() as cdatetime;");
			$getTodayDate = $getTodayDateArr -> current();
			$todayDate = $getTodayDate['cdatetime'];
			if(strtotime($todayDate) > $sTime){
				echo "You can not schedule in past.";die;
			}else if($sTime > $eTime){
				echo "End date time should be greater than start date time.";die;
			} 
			
			if(file_exists($path.$filename)){
				$md5Hash=md5_file($path.$filename);
			}
			// Found Versions From File
	        $setYourOption=$postData['setYourOption'];
            
			$session = new Container('userinfo');
		    $user_id = $session->offsetGet('usrid');
		    $modelContent = $session->offsetGet('modelContent');
			//get the firmware package version
			$packVerionArr = explode(".",str_replace("-",".",$filename));
			if(is_numeric($packVerionArr[1])){
				$getVersion = $packVerionArr[1].".".$packVerionArr[2];
			}else{
				$getVersion = $packVerionArr[2].".".$packVerionArr[3];
			}
			
			if($getVersion > 3.0){
				$getPackageVersionArr = explode('-',$filename);
				$FinalSubStringArr = explode('.',$getPackageVersionArr[1]);
				$pkgversion=$FinalSubStringArr[0].'.'.$FinalSubStringArr[1].'.'.$FinalSubStringArr[2].'.'.$FinalSubStringArr[3];
				$buildNo=$FinalSubStringArr[3];
			}else{
				if($setYourOption=="collage"){
				$searchString='VIA-Update-';
				}
				if($setYourOption=="connect"){
					$searchString='update_connect-';
				}
				if($setYourOption=="campus"){
					$searchString='Campus-Update-';
				}
				if($setYourOption=="viago"){
					$searchString='update_viago-';
				}
				if($setYourOption=="connectplus"){
					$searchString='update_cpplus-';
				}
				$getStrLen=strlen($searchString);		
				if(strstr($filename,$searchString)){
					$subPart=substr($filename,$getStrLen);
				}
				// Find - in the subpart
				if(strstr($subPart,'-')){
					$subPart=str_replace('-','.',$subPart);
				}
				$FinalSubStringArr=explode('.',$subPart);
				$pkgversion=$FinalSubStringArr[0].'.'.$FinalSubStringArr[1].'.'.$FinalSubStringArr[2].'.'.$FinalSubStringArr[3];
				$buildNo=$FinalSubStringArr[3];
			}
			
			$countSelChkBox=(count($arrChkbox)>0)?count($arrChkbox):0;
			
			if(isset($postData['schedule'])){
				 $sql_query="insert into events(start_date,end_date,event_name,details,event_type,userId_fk,schedule_type ) values ('$startDate','$endDate','$scheduleName','',' ','$user_id','1') ";
				 $appObj->returnQueryData("START TRANSACTION");//begin transtion
				 $execute=$appObj->returnQueryData($sql_query);
				 //$lastInsertId = $execute->getResource()->insert_id;
				 //if(empty($lastInsertId)){
					$lastInsertId = isset($execute->getResource()->insert_id)? $execute->getResource()->insert_id : $execute->getGeneratedValue();
				 //}
				 
				//$customeSql="INSERT INTO events_detail(deviceId_fk,event_id) VALUES";
				//$value_array=array();
				
				 $customeSql2="INSERT INTO AutoUpdateDone(deviceID_Fk,PackageName,pkgversion,ModifyDateTime,md5,buildNo,event_id_fk,firmware_path) VALUES";
				 $value_array2=array();
				 //Firmware path
				 $firmwarePath = PUBLIC_URL."/uploads/".$filename;
				 foreach($arrChkbox as $gway_val){
					if(!empty($gway_val)){
						$gatewayId_fk="'".$gway_val."'";
						//$value_array[] = "($gatewayId_fk,'$lastInsertId')"; 
						$value_array2[] = "($gatewayId_fk,AES_ENCRYPT('$filename','$poll_encryption_key'),'$pkgversion',now(),'$md5Hash','$buildNo','$lastInsertId','$firmwarePath')";
						$gwayIdsArr .= $gway_val.",";
					}
				 }
				 $gwayIdsArr =rtrim($gwayIdsArr,",");
				 //$customeSql .= implode(',', $value_array);
				 //$execute1=$appObj->returnQueryData($customeSql);
				 $execute1=$appObj->returnQueryData("UPDATE tbl_device_live_status SET firmware_process=1 WHERE did_fk IN ($gwayIdsArr)");
				
				 $customeSql2 .= implode(',', $value_array2);
				 $execute2=$appObj->returnQueryData($customeSql2);
				 
				 if ($execute1 and $execute2 and $execute) {
					$appObj->returnQueryData("COMMIT");  //COMMIT IF SAVE THE DATA SUCCESSFULLY
				 } else {        
					$appObj->returnQueryData("ROLLBACK"); // ROLLBACK in case of failure
					echo "Something went wrong.";die;
				 }
			}
			$appObj->ActivityLogVSM(4,$filename.' Updated',13);
			echo "success";die();
			
		}
	}
	
	public function scheduledFirmwareAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
		$poll_encryption_key = POLL_ENCRYPTION_KEY;
		$getVal=1;

		if(isset($_GET['gateway'])){
			$getVal=2;
			if($user_id==1){
				try{
					$qry1="SELECT C.Version as cversion,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process,A.pkgversion as version,D.event_id FROM AutoUpdateDone AS A 
					INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk 
					INNER JOIN events AS D ON D.event_id=A.event_id_fk 
					INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID 
					INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE 1";
											  					  
				}catch(Exception $e){
					echo "Something went wrong.";die;
				}
			}else{
				try{
					$qry1="SELECT C.Version as cversion,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process,A.pkgversion as version,D.event_id FROM AutoUpdateDone AS A 
					INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk 
					INNER JOIN events AS D ON D.event_id=A.event_id_fk 
					INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID 
					INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE D.userId_fk=$user_id";
				  			  				  
				}catch(Exception $e){
					echo "Something went wrong.";die;
				}	
			}
			$doneData=$appObj->returnQueryData($qry1);
			
		}else{
			if($user_id==1){
				  $qry="SELECT A.event_name,A.event_id,A.start_date,A.end_date,AES_DECRYPT(C.PackageName,'$poll_encryption_key') as PackageName,C.pkgversion,group_concat(C.deviceID_Fk) as device_id,A.schedule_type FROM events A 
					 INNER JOIN AutoUpdateDone C ON C.event_id_fk=A.event_id WHERE 1 ";
			}else{
				  $qry="SELECT A.event_name,A.event_id,A.start_date,A.end_date,AES_DECRYPT(C.PackageName,'$poll_encryption_key') as PackageName,C.pkgversion,group_concat(C.deviceID_Fk) as device_id,A.schedule_type FROM events A 
					 INNER JOIN AutoUpdateDone C ON C.event_id_fk=A.event_id 
					 WHERE A.userId_fk=$user_id ";
			}
			$qry .=" GROUP BY A.event_id";
			$qry .=" ORDER BY A.end_date DESC";
			//echo $qry;die;
			$response = $appObj->returnQueryData($qry);
		}
		//get the current date time
	    $getTodayDateArr = $appObj->returnQueryData("Select now() as cdatetime;");
		$getTodayDate = $getTodayDateArr -> current();
		$todayDate = $getTodayDate['cdatetime'];
		
		return new ViewModel(array(
			'data' => $response,
            'now'  => $todayDate,
			'doneData' => $doneData,
			'appObj' => $appObj,
            'getVal' => $getVal			
            			
		));	
		
	}
	//List the gateway which have been schedule for update
	public function scheduledGatewayListAction(){
		$eventId=$_GET['eventId'];
        $pkgName=$_GET['pkgName'];
		if($eventId && $pkgName){
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$user_id = $session->offsetGet('usrid');
	
			$qry="SELECT A.event_name,B.deviceID_Fk,D.DeviceName as DeviceName,A.start_date,A.schedule_type,C.DID as dnldInfo FROM events A
			    INNER JOIN AutoUpdateDone B ON B.event_id_fk=A.event_id 
	            INNER JOIN DeviceInventory AS D ON D.DID=B.deviceID_Fk
	            LEFT JOIN tbl_firmware_update_info AS C ON C.DID=D.DID
	            WHERE A.event_id=$eventId";
			$response = $appObj->returnQueryData($qry);
			
			return new ViewModel(array(
				'data' => $response,
                'eventId'  => $eventId,				
                'pkgName'  => $pkgName			
			));	
		}
	}
	
	//Gateway remove from schedule 
	public function deleteScheduledGatewayAction(){
		if($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$selectedItems=explode(",",$postData['selectedItems']);
			foreach($selectedItems as $gWayVal){
				$selectedGwayId=explode("/#/",$gWayVal);
				$gwayIdArr .=$selectedGwayId[0].",";
				$eventId=$selectedGwayId[1];
				$pkgName=$selectedGwayId[2];
			}
			$gwayId=rtrim($gwayIdArr,",");
			if(!empty($gwayId)){
				$appObj = new ApplicationController();
		        $session = new Container('userinfo');
		        $user_id = $session->offsetGet('usrid');
		        $poll_encryption_key = POLL_ENCRYPTION_KEY;
				$appObj->returnQueryData("START TRANSACTION");//begin transtion
				$getMD=$appObj->returnQueryData("SELECT md5 FROM AutoUpdateDone WHERE AES_DECRYPT(PackageName,'$poll_encryption_key')='".$pkgName."'"); 
			    $rowData=$getMD->current();
			    $mdVal=$rowData['md5'];
				$sql_query="INSERT INTO tbl_firmware_delete (fdel_firmname,fdel_did,fdel_modifydatetime,md5) values";
				$value_array=array();
			    $newDeviceIdArr=explode(",",$gwayId);
				foreach($newDeviceIdArr as $val){
					$value_array[] ="(AES_ENCRYPT('$pkgName','$poll_encryption_key'),$val,now(),'$mdVal')";
				}
				$sql_query .= implode(',', $value_array); 
			    $execute4= $appObj->returnQueryData($sql_query);
				
				$execute1=$appObj->returnQueryData("DELETE FROM AutoUpdateDone WHERE event_id_fk=$eventId AND deviceID_Fk IN ($gwayId) AND AES_DECRYPT(PackageName,'$poll_encryption_key')='".$pkgName."'"); 
			    $execute2=$appObj->returnQueryData("DELETE FROM events_detail WHERE deviceId_fk IN ($gwayId) AND event_id=$eventId");
				if($execute1 and $execute2 and $execute4) {
					$mQry=$appObj->returnQueryData("SELECT deviceID_Fk FROM AutoUpdateDone WHERE event_id_fk=$eventId");
					$mQryCnt = $mQry->current();
					if($mQryCnt == ""){
						 $appObj->returnQueryData("DELETE FROM events WHERE event_id=$eventId"); 
					}
					$appObj->returnQueryData("COMMIT");  //COMMIT IF SAVE THE DATA SUCCESSFULLY
					
					//get the firmware package version
					$packVerionArr = explode(".",str_replace("-",".",$pkgName));
					if(is_numeric($packVerionArr[1])){
						$getVersion = $packVerionArr[1].".".$packVerionArr[2];
					}else{
						$getVersion = $packVerionArr[2].".".$packVerionArr[3];
					}
					
				    if($getVersion > 3.0){
					   //Rabbit MQ Code
						$cmdArr=array("cmd"=>"abort_firmware","sender"=>"web-vsm");
						$cmdJson=json_encode($cmdArr);
						$producerObject=new WebProducerController();
						$producerObject->rabbitWebProducerAction($cmdJson);
				    }else{
					    $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					    $rebootcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ScheduleDelete</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
						$appObj->sendMsgToAPIserver($logincmd,$rebootcmd);
				    }
					echo "success";die;
				}else{        
					$appObj->returnQueryData("ROLLBACK"); // ROLLBACK in case of failure
					echo "Something went wrong.";die;
				}
			}
		}
	}
	
	//Firmware status
	public function firmwareStatusAction(){
		if(isset($_GET['schedule'])){
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
		    $user_id = $session->offsetGet('usrid');
			$session->offsetSet('shcedule_id', $_GET['schedule']);
			$poll_encryption_key = POLL_ENCRYPTION_KEY;
			if($user_id==1){
				try{
					$qry1="SELECT C.Version as cversion,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process,A.pkgversion as version,D.event_id FROM AutoUpdateDone AS A 
					INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk 
					INNER JOIN events AS D ON D.event_id=A.event_id_fk 
					INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID 
					INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE 1";
				   //completed
				   /*$qry1="SELECT C.Version as version,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process FROM AutoUpdateDone AS A INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk AND (CONVERT(SUBSTRING_INDEX(C.Version,'.',-1),UNSIGNED INTEGER) = CONVERT(SUBSTRING_INDEX(A.pkgversion,'.',-1),UNSIGNED INTEGER)) INNER JOIN events AS D ON D.event_id=A.event_id_fk INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE 1";
					// progress
				   $qry2="SELECT AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,A.pkgversion as version,C.DeviceName as DeviceName,D.end_date,C.Version as cversion,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process FROM AutoUpdateDone AS A INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk INNER JOIN events AS D ON D.event_id=A.event_id_fk INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE 1";
				   //pending
				   $qry3="SELECT A.pkgversion as version,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.Version as cversion,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process FROM AutoUpdateDone AS A INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk AND (CONVERT(SUBSTRING_INDEX(C.Version,'.',-1),UNSIGNED INTEGER) < CONVERT(SUBSTRING_INDEX(A.pkgversion,'.',-1),UNSIGNED INTEGER)) INNER JOIN events AS D ON D.event_id=A.event_id_fk INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID";
				   */
											  					  
				}catch(Exception $e){
					echo "Something went wrong.";die;
				}
			}else{
				try{
					$qry1="SELECT C.Version as cversion,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process,A.pkgversion as version,D.event_id FROM AutoUpdateDone AS A 
					INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk 
					INNER JOIN events AS D ON D.event_id=A.event_id_fk 
					INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID 
					INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE D.userId_fk=$user_id";
				   //completed
				   /*$qry1="SELECT C.Version as version,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID FROM AutoUpdateDone AS A INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk AND (CONVERT(SUBSTRING_INDEX(C.Version,'.',-1),UNSIGNED INTEGER) = CONVERT(SUBSTRING_INDEX(A.pkgversion,'.',-1),UNSIGNED INTEGER)) INNER JOIN events AS D ON D.event_id=A.event_id_fk INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE D.userId_fk=$user_id";
					// progress
				   $qry2="SELECT AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,A.pkgversion as version,C.DeviceName as DeviceName,D.end_date,C.Version as cversion,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process FROM AutoUpdateDone AS A INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk INNER JOIN events AS D ON D.event_id=A.event_id_fk INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE D.userId_fk=$user_id";
					//pending
				   $qry3="SELECT A.pkgversion as version,AES_DECRYPT(A.PackageName,'$poll_encryption_key') as PackageNames,C.DeviceName as DeviceName,D.end_date,C.Version as cversion,C.DeviceIP,G.DeviceGroup,dls.Network_status,C.DID,dls.firmware_process FROM AutoUpdateDone AS A INNER JOIN DeviceInventory AS C ON C.DID=A.deviceID_Fk AND (CONVERT(SUBSTRING_INDEX(C.Version,'.',-1),UNSIGNED INTEGER) < CONVERT(SUBSTRING_INDEX(A.pkgversion,'.',-1),UNSIGNED INTEGER)) INNER JOIN events AS D ON D.event_id=A.event_id_fk INNER JOIN devicegroup AS G ON G.DeviceGroupID=C.DeviceGroupID INNER JOIN tbl_device_live_status dls ON dls.did_fk=C.DID WHERE D.userId_fk=$user_id";
					*/					  				  
				}catch(Exception $e){
					echo "Something went wrong.";die;
				}	
			}
			
			$shcedule_id = $session->offsetGet('shcedule_id');
			if($shcedule_id == ""){
				return $this->redirect()->toRoute('firmware',array('action' => 'firmwareStatus'));
			}else{
				$selectedScheduleId=$shcedule_id;
				$qry1.=" AND D.event_id='$selectedScheduleId' ";
				//$qry2.=" AND D.event_id='$selectedScheduleId' ";
				//$qry3.=" AND D.event_id='$selectedScheduleId' ";
			}
			//Define the array for first call
			$type="";
			if(isset($_GET['type'])){
				//Get the power status
				$type=trim($_GET['type']);
				if($type=='on'){$powerStatus=1;}
				if($type=='off'){$powerStatus=3;}
				if($type=='success'){$firmStatus=0;}
				if($type=='downloading'){$firmStatus=3;}
				if($type=='installing'){$firmStatus=4;}
				if($powerStatus){
					$qry1.=" AND dls.Network_status = '$powerStatus'";
				}else{
					if($type=='failed'){
						$qry1.=" AND dls.firmware_process = 1 AND D.end_date < now()";
					}else if($type=='pending'){
						$qry1.=" AND dls.firmware_process = 1 AND D.end_date > now()";
					}else{
						$qry1.=" AND dls.firmware_process = '$firmStatus'";
					}
				}
				
				$doneData=$appObj->returnQueryData($qry1);
			}else{
				 $doneData=$appObj->returnQueryData($qry1);
				 //$progressData=$appObj->returnQueryData($qry2);
				 //$pendingData=$appObj->returnQueryData($qry3." AND D.end_date > now()");
                 //$pendingData=$appObj->returnQueryData($qry3." AND (D.end_date > now() OR D.end_date < now())");				 
			}
			// Current date time 
			$timeSql=$appObj->returnQueryData("SELECT now() as now,AES_DECRYPT(PackageName,'$poll_encryption_key') as PackageNames FROM AutoUpdateDone WHERE event_id_fk=".$shcedule_id);
			$timeRow=$timeSql->current();
			
			$todayDate=$timeRow['now'];
			$packageName=$timeRow['PackageNames']; //get the package name
			
		    return new ViewModel(array(
				'doneData' => $doneData,
               // 'progressData'  => $progressData,				
               // 'pendingData'  => $pendingData,		
                'todayDate'  => $todayDate,		
                'packageName'  => $packageName,
                'appObj' => $appObj,
                'getVal' =>$type				
			));	
	    }	
	}
	
	//Delete the firmware schedule
	public function deleteScheduledFirmwareAction(){
		if($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$eventId=$postData['eventId'];
		    $pkgName=$postData['pkgName'];
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$user_id = $session->offsetGet('usrid');
			$poll_encryption_key = POLL_ENCRYPTION_KEY;
			if(!empty($eventId) && !empty($pkgName)){
				$data=$appObj->returnQueryData("SELECT deviceID_Fk FROM AutoUpdateDone WHERE 	event_id_fk=$eventId");
				if(count($data) >0){  
				    foreach($data as $row){
						$deviceIds .= $row['deviceID_Fk'].",";
					}
					$deviceId=rtrim($deviceIds,",");
				}
				$appObj->returnQueryData("START TRANSACTION");  // Start the Transaction
				//delete the scheduled firmware(Added 1-Aug-2018)
				$getMD=$appObj->returnQueryData("SELECT md5 FROM AutoUpdateDone WHERE AES_DECRYPT(PackageName,'$poll_encryption_key')='".$pkgName."'"); 
				$rowData=$getMD->current();
				$mdVal=$rowData['md5'];
				$sql_query="INSERT INTO tbl_firmware_delete (fdel_firmname,fdel_did,fdel_modifydatetime,md5) values";
				$value_array=array();
				$newDeviceIdArr=explode(",",$deviceId);
				
				foreach($newDeviceIdArr as $val){
					$value_array[] ="(AES_ENCRYPT('$pkgName','$poll_encryption_key'),$val,now(),'$mdVal')";
				}
				$sql_query .= implode(',', $value_array);
				$execute4= $appObj->returnQueryData($sql_query);
			
				$execute1=$appObj->returnQueryData("DELETE FROM AutoUpdateDone WHERE event_id_fk=$eventId AND deviceID_Fk IN($deviceId) AND AES_DECRYPT(PackageName,'$poll_encryption_key')='".$pkgName."'"); 
				$execute2=$appObj->returnQueryData("DELETE FROM events WHERE event_id=$eventId"); 
				$execute3=$appObj->returnQueryData("DELETE FROM events_detail WHERE event_id=$eventId");
			
				if($execute1 and $execute2 and $execute3 and $execute4) {
					$appObj->returnQueryData("COMMIT");  //COMMIT IF SAVE THE DATA SUCCESSFULLY
					//get the firmware package version
					$packVerionArr = explode(".",str_replace("-",".",$pkgName));
					if(is_numeric($packVerionArr[1])){
						$getVersion = $packVerionArr[1].".".$packVerionArr[2];
					}else{
						$getVersion = $packVerionArr[2].".".$packVerionArr[3];
					}
					if($getVersion > 3.0){
						//Rabbit MQ Code
						$cmdArr=array("cmd"=>"abort_firmware","sender"=>"web-vsm");
						$cmdJson=json_encode($cmdArr);
						$producerObject=new WebProducerController();
						$producerObject->rabbitWebProducerAction($cmdJson);
					}else{
						$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                        $rebootcmd= "<P><UN>websetting</UN><Pwd></Pwd><Cmd>ScheduleDelete</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					    $appObj->sendMsgToAPIserver($logincmd,$rebootcmd);
					}
					//create web history
					$appObj->ActivityLogVSM(5,' Scheduled for package('.$pkgName .') has been Deleted',13);
					echo "success";die;
				}else{        
					$appObj->returnQueryData("ROLLBACK"); // ROLLBACK in case of failure
					echo "Something went wrong.";die;
				}
			}
		}
	}
	
	public function getDevicegroupTable() {
		if(!$this->TblDevicegroupTable) {
			$sm = $this->getServiceLocator();
			$this->TblDevicegroupTable = $sm->get('Webapp\Model\TblDevicegroupTable');
		}
		return $this->TblDevicegroupTable;
	}
	
	/*****
	 *	@Function Name		: updateFirmwareAction
	 *  @description	    : Upload and update the firmware
	 *	@Author			    : Dileep Yadav
	 *  @Date               : 28-Jan-2020
	 *****/

	public function updateFirmwareAction() {
		//get the userid from session
		$session = new Container('userinfo');
		$usrid = $session->offsetGet('usrid');
		if(empty($usrid)) {
			return $this->redirect()->toRoute('index');
		}
		$request = $this->getRequest();
		$form = new AppVersionForm();
		$appObj = new ApplicationController();

		/*get total table*/
		$totalTable=$appObj->countTables();
		$tableCount=$totalTable['total'];
		$readMyversionFileTxt=$appObj->getModelNameByParam('firmversion');
		$result = $appObj->returnQueryData("SELECT * FROM tbl_buildinfo WHERE client_version_no='$readMyversionFileTxt'");
		if($result->count()==0)
		{
			$last_insert_id= $this->getBuildInfoTable()->insertClientVersion($readMyversionFileTxt);
		}
		if($result->count()==1)
		{
			foreach($result as $value)
			$last_insert_id=$value['id'];
		
			$record=$this->getVersionInfoTable()->deleteRecord($last_insert_id);
		}
			$versionPath=DEST_PATH."Version/";
			$listDirArr = scandir($versionPath);
			$sql="INSERT INTO tbl_versioninfo (client_version_fk,appname,version_no,modifydate,appmappingname) VALUES";
				foreach($listDirArr as $dirname){
		if(!strstr($dirname,'.')){
					if(!strstr($dirname,'QRWidget')){
			//$dirname."<br>";	
			$appName=trim($dirname);	
			$dirname=$versionPath.trim($dirname).'/';
			$fileList=$this->fileList($dirname);
			foreach($fileList as $val){
				$filename=$val;
				$fileData=$appObj->file_read($dirname.$filename);
				if(trim(strtolower($filename))=='info.txt'){
					$xml=simplexml_load_string($fileData);
					$xmlAppName=trim($xml->AppName);
					$versionnumber=trim($xml->Version);
					$modifydate=substr(trim($xml->ModifiedDate),0,19);
					$modifydate = (bool)strtotime($modifydate) && $modifydate != "0000-00-00 00:00:00" ? $modifydate: date("Y-m-d h:i:s");				
					$sql.="($last_insert_id,'$xmlAppName','$versionnumber','$modifydate','$appName'),";
				}
			}
			
		}}
		
	}
		$sql=rtrim($sql,',');
		$conn = $appObj->getConnection();
		$qryResponse = $conn->execute($sql);
		$webVersion=WEB_VERSION;
		$query= "INSERT INTO tbl_versioninfo(client_version_fk, appname, version_no, modifydate, appmappingname) VALUES ($last_insert_id,'Website','$webVersion','$modifydate','Website')";
		$qryResponse = $conn->execute($query);
		$secondDestVersionFile = $appObj->getModelNameByParam('firmversion');
		$viaUpdateFirmwareTag=$appObj->getModelNameByParam("updatefirmwaretag");
		if(PRODUCT_TYPE == 'via') {
			$currentModelName = $appObj->getModelName();
			$getViaModelName = strtolower($appObj->getModelNameByParam('model'));
			$fullpackageformat = 'N/A';
			$releaseNoteLink="https://k.kramerav.com/support/download.asp?f=61218&_gl=1*19yiue9*_ga*NjQyOTc1OTY0LjE2MzY2MzQ3NDk.*_ga_CEMNPB30MX*MTY5NjU3Njc0OS4xNS4xLjE2OTY1NzcyODkuMTMuMC4w&_ga=2.81478676.260515020.1696576748-642975964.1636634749";
			$packageformat = $viaUpdateFirmwareTag.'-';
			$fullpackageformat = $packageformat.'x.x.xxxx.xxxx.zip eg. '.$packageformat.'4.0.0.1267.zip';
		}
		
		$viewmodel =  new ViewModel(array('modelName' => $currentModelName, 'releaseNoteLink' => $releaseNoteLink, 'packageformat' => $packageformat, 'fullpackageformat' => $fullpackageformat, 'secondDestVersionFile' => $secondDestVersionFile, 'form' => $form,'tableCount'=>$tableCount,'getViaModelName'=>$getViaModelName,'viaUpdateFirmwareTag'=>$viaUpdateFirmwareTag,'appObj'=>$appObj));
		if(PRODUCT == "via"){
			$viewmodel->setTemplate("webapp/utility/system-settings");
		}
		return $viewmodel;

	}
/*****
	 *	@function Name		: buildInfoAction
	 *  @description	    : get version data
	 *	@Author			    : Vineet
	 *  @Date               : 09-sep-2020
	 *****/
	public function buildInfoAction() {
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appversionmappingArray = array('Cloud File server' => 'File Server',
											'CollabAppLauncher' => 'AppLauncher',
											'WindowsFTP Serve' => 'Streaming Server',
											'WOWApi Server' => 'Api Server',
											'WOW Mouse Server' => 'Collobration Server',
											'WOWCollab8(Admin mode)' => 'VIA/Collab8',
											'WOW Player' => 'Video Player',
											'WPG_Client_Linux(Windows)' => 'ScreenShare',
											'WOW Viewer17' => 'Viewer',
											'AirMirror_Linux' => 'Airplay Mirroring',
											'Vinagre (Linux)' => 'Viewer',
											'Tinyftp' => 'Streaming Server',
											'RTP Audio win_lin_player' => 'Audio Player',
											'Collab8Seeting' => 'AppSetting',
											'x11vnc' => 'WOWCapture',
											'vinagre' => 'WOWViewer');
			$result = $this->getBuildInfoTable()->fetchAll();
			
			foreach($result as $results) {
				$temp = array('id' =>$results->id,
							  'client_version' =>$results->client_version_no,
							 );
			}
			$clientVersionID = $temp['id'];
			$client_version = $temp['client_version'];
			$versionData = $this->getVersionInfoTable()->fetchAll($clientVersionID);
			$idx = 0;
			
			foreach($versionData as $versionDataFile) {
				$temp = array('version_id' =>$versionDataFile->version_id,
							  'client_version_fk' =>$versionDataFile->client_version_fk,
							  'clientVersion' =>$client_version,
							  'AppsFilePath' =>($versionDataFile->appmappingname == WebSite_AppName)?$versionDataFile->appmappingname . '/' : VERSION_PATH .$versionDataFile->appmappingname . '/',
							'AppName' => array_key_exists($versionDataFile->appname,
							 $appversionmappingArray)?$appversionmappingArray[$versionDataFile->appname]:$versionDataFile->appname,
							  'version_no' =>$versionDataFile->version_no,
							  'modifydate' =>$versionDataFile->modifydate,
							 );	
				$jsonData[$idx ++] = $temp;
			}
			
			$val = json_encode($jsonData);
			$view = new JsonModel(array('success' => $val));
			$view->setTerminal(true);
			return $view;
		}
	}
	
		/*****
	 *	@function Name	: exportPDFAction
	 *  @description    : export app version data
	 *	@Author			: Vineet
	 *  @Date           : 09-sep-2020
	 *****/
	public function exportPDFAction() {
		$request = $this->getRequest();
		$value=$_GET["link"];
		$result = $this->getBuildInfoTable()->getClientId($value);
		$clientId=$result->id;
		$client_version=$value;
		$allData=$this->getVersionInfoTable()->fetchAll($clientId);
		$pdf = new \PDF_MC_Table();
		$pdf->AddPage();
		$pdf->AliasNbPages();
		$pdf->SetFont('Arial', 'B', 11);
		$header=array('AppName','Build Number','Version No','ModifyDate');
		foreach($header as $heading) {
		$pdf->Cell(38, 11, $heading, 1);
		}
		foreach($allData as $row) {
		$temp = array($row->appname,
							 $client_version,
							 $row->version_no,
							  $row->modifydate,
							 );
			$jsonData[$idx ++] = $temp;
		}
		$pdf->SetWidths(array(38, 38, 38, 38));
		$pdf->Ln();
		foreach($jsonData as $row) {
			$pdf->SetFont('Arial', '', 11);
			$pdf->Row($row);
			}			
		$pdf->Output('AppVersion.pdf', "D");
		exit();
		return $this->redirect()->toRoute('firmware');
	}


	/*****
	 *	@function Name	: searchClientVersionAction
	 *  @description    : search client version
	 *	@Author			: Vineet
	 *  @Date           : 09-sep-2020
	 *****/
	public function searchClientVersionAction() {
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$allData = $this->getBuildInfoTable()->getAllData($data[0]);
			foreach($allData as $allResult) {
				$data1[] = $allResult->client_version_no;
			}
			$dataValue = json_encode($data1);
			$view = new JsonModel(array('success' =>$dataValue));
			$view->setTerminal(true);
			return $view;
		}
	}
	
	/*****
	 *	@function Name	: appVersionListAction
	 *  @description    : get app version list
	 *	@Author			: Vineet
	 *  @Date           : 09-sep-2020
	 *****/
	public function appVersionListAction()
	{
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
		$data = $request->getPost('data');
		$appversionmappingArray = array('Cloud File server' => 'File Server',
											'CollabAppLauncher' => 'AppLauncher',
											'WindowsFTP Serve' => 'Streaming Server',
											'WOWApi Server' => 'Api Server',
											'WOW Mouse Server' => 'Collobration Server',
											'WOWCollab8(Admin mode)' => 'VIA/Collab8',
											'WOW Player' => 'Video Player',
											'WPG_Client_Linux(Windows)' => 'ScreenShare',
											'WOW Viewer17' => 'Viewer',
											'AirMirror_Linux' => 'Airplay Mirroring',
											'Vinagre (Linux)' => 'Viewer',
											'Tinyftp' => 'Streaming Server',
											'RTP Audio win_lin_player' => 'Audio Player',
											'Collab8Seeting' => 'AppSetting',
											'x11vnc' => 'WOWCapture',
											'vinagre' => 'WOWViewer');
		if($data[0]=="")
		{
			$resultData=$this->getBuildInfoTable()->fetchAll();
			foreach($resultData as $results) {
			$temp = array('id' =>$results->id,
							  'client_version' =>$results->client_version_no,
							 );
			}
			$clientId = $temp['id'];
			$client_version = $temp['client_version'];
			
		}
		else{
			$result = $this->getBuildInfoTable()->getClientId($data);
			$clientId=$result->id;
			$client_version =$result->client_version_no;
		}
		
		$allData=$this->getVersionInfoTable()->fetchAll($clientId);
			foreach($allData as $allDatas) {
			$temp = array('version_id' =>$allDatas->version_id,
			 'client_version_fk' =>$allDatas->client_version_fk,
			 'clientVersion' =>$client_version,
			'AppsFilePath' =>($allDatas->appmappingname == WebSite_AppName)?$allDatas->appmappingname . '/' : VERSION_PATH .$allDatas->appmappingname . '/',
			'AppName' => array_key_exists($allDatas->appname,
			$appversionmappingArray)?$appversionmappingArray[$allDatas->appname]:$allDatas->appname,
			'version_no' =>$allDatas->version_no,
			'modifydate' =>$allDatas->modifydate,
			);
			$jsonData[$idx ++] = $temp;
			}
		$val = json_encode($jsonData);
		$view = new JsonModel(array('success' =>$val));
		$view->setTerminal(true);
		return $view;
		}
	
	}

	/*****
	 *	@function Name	: versioninfoDataAction
	 *  @description	: get versoninfo table data
	 *	@Author			: Vineet
	 *  @Date           : 09-sep-2020
	 *****/
	public function versioninfoDataAction()
	{
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
		$data = $request->getPost('data');
		$appversionmappingArray = array('Cloud File server' => 'File Server',
											'CollabAppLauncher' => 'AppLauncher',
											'WindowsFTP Serve' => 'Streaming Server',
											'WOWApi Server' => 'Api Server',
											'WOW Mouse Server' => 'Collobration Server',
											'WOWCollab8(Admin mode)' => 'VIA/Collab8',
											'WOW Player' => 'Video Player',
											'WPG_Client_Linux(Windows)' => 'ScreenShare',
											'WOW Viewer17' => 'Viewer',
											'AirMirror_Linux' => 'Airplay Mirroring',
											'Vinagre (Linux)' => 'Viewer',
											'Tinyftp' => 'Streaming Server',
											'RTP Audio win_lin_player' => 'Audio Player',
											'Collab8Seeting' => 'AppSetting',
											'x11vnc' => 'WOWCapture',
											'vinagre' => 'WOWViewer');
		$result=$this->getVersionInfoTable()->getDataByAppName($data[0]);
					foreach($result as $allDatas) {
								$temp = array(
							  'clientVersion' =>$client_version,
							  'AppsFilePath' =>($allDatas->appmappingname == WebSite_AppName)?$allDatas->appmappingname . '/' : VERSION_PATH .$allDatas->appmappingname . '/',
							  // 'AppName' =>$versionDataFile->AppName,
							'AppName' => array_key_exists($allDatas->appname,
							 $appversionmappingArray)?$appversionmappingArray[$allDatas->appname]:$allDatas->appname,
							  'version_no' =>$allDatas->version_no,
							  'modifydate' =>$allDatas->modifydate,
							 );
				$jsonData[$idx ++] = $temp;
			}
		$val = json_encode($jsonData);
		$view = new JsonModel(array('success' =>$val));
		$view->setTerminal(true);
		return $view;
		
		}
		
	}
	/*****
	 *	@function Name	: fileList
	 *  @description	    : get table
	 *	@Author			    : Vineet
	 *  @Date               : 20-sep-2020
	 *****/
	public function fileList($dir) {
		if(is_dir($dir)) {
			$fileListArray = array();
			if($dh = opendir($dir)) {

				while(($file = readdir($dh))!== false) {
					//echo "filename:" . $file . "<br>";		  		  
					if(strlen($file)> 3) {
						array_push($fileListArray, $file);
					}
				}
				return $fileListArray;
				closedir($dh);
			}
		} else {
			return 0;
		}
	}
	/*****
	 *	@function Name	: getBuildInfoTable
	 *  @description	: get table
	 *	@Author			: Vineet
	 *  @Date           : 09-sep-2020
	 *****/
	public function getBuildInfoTable() {
		if(!$this->TblBuildInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblBuildInfoTable = $sm->get('Webapp\Model\TblBuildInfoTable');
		}
		return $this->TblBuildInfoTable;
	}
	
	/*****
	 *	@function Name	: getVersionInfoTable
	 *  @description	: get table
	 *	@Author			: Vineet
	 *  @Date           : 09-sep-2020
	 *****/
	public function getVersionInfoTable() {
		if(!$this->TblVersionInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblVersionInfoTable = $sm->get('Webapp\Model\TblVersionInfoTable');
		}
		return $this->TblVersionInfoTable;
	}

}
