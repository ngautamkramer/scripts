<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\TtfInfo\TtfInfo;

class DssTemplateController extends AbstractActionController {	
	
	public function getScreenTemplateMasterTable() {
		if(!$this->TblScreenTemplateMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblScreenTemplateMasterTable = $sm->get('Webapp\Model\TblScreenTemplateMasterTable');
		}
		return $this->TblScreenTemplateMasterTable;
	}

	public function getScreenTemplateDetailsTable() {
		if(!$this->TblScreenTemplateDetailsTable) {
			$sm = $this->getServiceLocator();
			$this->TblScreenTemplateDetailsTable = $sm->get('Webapp\Model\TblScreenTemplateDetailsTable');
		}
		return $this->TblScreenTemplateDetailsTable;
	}

	public function getCampaignTemplateTable() {
		if(!$this->TblCampaignTemplateTable) {
			$sm = $this->getServiceLocator();
			$this->TblCampaignTemplateTable = $sm->get('Webapp\Model\TblCampaignTemplateTable');
		}
		return $this->TblCampaignTemplateTable;
	}

	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}

	public function getSettingTable() {
		if(!$this->TblSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}	
	public function templateListAction() {
		$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
		$predfinedTemplateResultSet = $tableScreenTemplateMasterTable->getPredefinedDssTempaltes();
		$customTemplateResultSet = $tableScreenTemplateMasterTable->getCustomDssTempaltes();
		$viewmodel = new ViewModel(array("predinedTemplateList" => $predfinedTemplateResultSet, "customTemplateList" => $customTemplateResultSet));
		return $viewmodel;
	}

	public function getTemplateDetailAction() {
		$postData = $this->getRequest()->getPost()->toArray();		
		$templateId = $postData['templateId'];
		//Security changes added by ashu on 25/03/22. Passing template id encrypted
	    if(!is_numeric($templateId) && $templateId <= 0 ){
			echo "Id is not valid";die;
		}	

		$tableCampaignTemplateTable = $this->getCampaignTemplateTable();
		$campaignTemplateAssociation = $tableCampaignTemplateTable->getTemplateAsssociationInCampaign($templateId);
		$retrunData = [];
		$retrunData["checkTemplateAssociation"] = false;
		if(count($campaignTemplateAssociation) > 0) {
			$retrunData["checkTemplateAssociation"] = true;
		}

		$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
		$templateDetails = $tableScreenTemplateMasterTable->getTemplateDetails($templateId);	
		foreach($templateDetails as $detailsResultSet) {	
			if($retrunData['ScreenTemplateID'] == "") {
				$retrunData['ScreenTemplateID'] = 	$detailsResultSet['screentemplateid'];		
				$retrunData['ScreenTemplateName'] = $detailsResultSet['screentemplatename'];
				$retrunData['AudioFrameID'] = $detailsResultSet['audioframeid'];
				$retrunData['FrameCount'] = $detailsResultSet['framecount'];
			}
			$retrunData['FrameProperties'][] = array (
				'FrameHeight' => round($detailsResultSet['frameheight']), 
				'FrameWidth' => round($detailsResultSet['framewidth']), 'FrameLeft' => round($detailsResultSet['frameleft']), 
				'FrameTop' => round($detailsResultSet['frametop']),	'FrameName' => $detailsResultSet['framename'], 
				'FrameId' => $detailsResultSet['frameid']
			);
		}		
		
		echo json_encode($retrunData);
		die();
	}

	public function deleteTemplateAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$postData = $this->getRequest()->getPost()->toArray();		
		//$templateId = $postData['templateId'];<br />
		//Security changes added by ashu on 25/03/22. Passing template id encrypted
		$encryptedTempId = $postData['templateId'];
		$crsf_tokenval=trim($postData['crsf_tokenval']);
		$appObj = new ApplicationController();
		$input=str_replace(' ','+',trim($encryptedTempId));
		$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
		$templateId=$appObj->desDecrypt($input, KEY_SEED);
		//End
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		

	    if(!is_numeric($templateId) && $templateId <= 0 ){
			echo "Id is not valid";die;
		}	
		$tableCampaignTemplateTable = $this->getCampaignTemplateTable();
		$campaignTemplateAssociation = $tableCampaignTemplateTable->getTemplateAsssociationInCampaign($templateId);
		$checkTemplateAssociation = false;
		if(count($campaignTemplateAssociation) > 0) {
			$checkTemplateAssociation = true;
		} else {
			$deleteTemplateDetailsDataWhere = array("screentemplateid" => $templateId);
			$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
			$tableScreenTemplateMasterTable->deleteScreenTemplate($deleteTemplateDetailsDataWhere);	
			$tableScreenTemplateDetailsTable = $this->getScreenTemplateDetailsTable();
			$tableScreenTemplateDetailsTable->deleteScreenTemplateDetails($deleteTemplateDetailsDataWhere);	
		}
		echo $checkTemplateAssociation; exit;
	}

	public Function addEditTemplateAction() {
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$frameProperties = $postData["frameProperties"];
		$tableScreenTemplateDetailsTable = $this->getScreenTemplateDetailsTable();
		$tableScreenTemplateMasterTable = $this->getScreenTemplateMasterTable();
		$postAction = $postData['postAction'];
		$templateId = $postData['templateId'];
		$crsf_tokenval=	trim($postData['crsf_tokenval']);
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		$responseReturn = "";
		if($postAction == "edit") {
			if(!is_numeric($templateId) && $templateId <= 0 ) {
			   $responseReturn = 7;
			}	
		}
		if($postData['screenTemplateName'] == "") {
			$responseReturn = 1; 
		} else if($postData['FrameCount'] == 0) {
			$responseReturn = 2; 
		} else if($postData['screenTemplateName'] != "") {
			if(strlen($postData['screenTemplateName']) > 100) {
				$responseReturn = 6;
			} else {
				$uniqueNameSearch = array();
				$uniqueNameSearch["ScreenTemplateName"] = $postData['screenTemplateName'];
				if($postData['postAction'] == "add") {
					$uniqueNameData = $tableScreenTemplateMasterTable->checkTemplateUniqueName($uniqueNameSearch);	
				} else if ($postData['postAction'] == "edit") {
					$uniqueNameSearch["ScreenTemplateID"] = $postData['templateId'];	
					$uniqueNameData = $tableScreenTemplateMasterTable->checkTemplateUniqueName($uniqueNameSearch);
				}
				if(count($uniqueNameData) > 0) {
					$responseReturn = 3;
				}	
			}
		} 
		
		if($responseReturn == "") {
			$session = new Container('userinfo');						
			$maximumFramesNumber = $postData['maximumFramesNumber'];		
			$staticFrameName = "frame_";
			$staticFrameDivProperties = "div_frame_";
			$screenTemplateMaster  = array();
			$screenTemplateMaster['screentemplatename'] = htmlspecialchars($postData['screenTemplateName']);
			$screenTemplateMaster['audioframeid'] = $postData['AudioFrameID'] != "" ? str_replace("div_frame_", "", $postData['AudioFrameID']) : 0;
			$screenTemplateMaster['active'] = "Y";
			$screenTemplateMaster['framecount'] = $postData['FrameCount'];		
			$screenTemplateMaster['username'] = $session->offsetGet('LoginName');
			$screenTemplateMaster['hostname'] = HOSTNAME;
			$screenTemplateMaster['modifydate'] = date("Y-m-d H:i:s");
			//added default values
			$screenTemplateMaster['aspectratio'] = '4:3';
			$screenTemplateMaster['backgroundcolor'] = 0;
			$screenTemplateMaster['appname'] = '';
			
		
			if($postAction == "add") {
				$templateId = $tableScreenTemplateMasterTable->insertScreenTemplateMaster($screenTemplateMaster);	
				$responseReturn = 4;
			} else if ($postAction == "edit") {
				$updateTemplateMasterDataWhere = array("screentemplateid" => $templateId);
				$tableScreenTemplateMasterTable->updateScreenTemplateMaster($updateTemplateMasterDataWhere, $screenTemplateMaster);

				$deleteTemplateDetailsDataWhere = array("screentemplateid" => $templateId);
				$tableScreenTemplateDetailsTable->deleteScreenTemplateDetails($deleteTemplateDetailsDataWhere);	
				$responseReturn = 5;
			}	

			foreach($frameProperties as $key => $value) {
				if(array_key_exists('frameHeight', $value)) {
					$screenTemplateDetails  = array();
					$screenTemplateDetails['frameid'] = $value["frameId"];
					$screenTemplateDetails['screentemplateid'] = $templateId;
					$screenTemplateDetails['framename'] = $key;
					$screenTemplateDetails['frameheight'] = $value["frameHeight"];
					$screenTemplateDetails['framewidth'] = $value["frameWidth"];
					$screenTemplateDetails['frameleft'] = $value["frameLeft"];
					$screenTemplateDetails['frametop'] = $value["frameTop"];
					$screenTemplateDetails['username'] = $session->offsetGet('LoginName');
					$screenTemplateDetails['hostname'] = HOSTNAME;
					$screenTemplateDetails['modifydate'] = date("Y-m-d H:i:s");
					//added for default values
					$screenTemplateDetails['strechmediatofit'] = '';
					$screenTemplateDetails['zorder'] = 0;
					$screenTemplateDetails['transparency'] = 0;
					$screenTemplateDetails['framecolor'] = 0;
					$screenTemplateDetails['defaultmedia'] = '';
					$screenTemplateDetails['defaultbackground'] = '';
					$screenTemplateDetails['aspectratio'] = '';
					$screenTemplateDetails['appname'] = '';
					$tableScreenTemplateDetailsTable->insertsScreenTemplateDetails($screenTemplateDetails);
				}
			}
		}
		echo $responseReturn; exit;
	}

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		$appObj = new ApplicationController();
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		} else {
			if(PRODUCT=='via' || PRODUCT=='kds'){
				$getSettingObj = $appObj->getComplexPasswordSettings();
				$getSettingData = $getSettingObj->webadmin_session_timeout;
			}else{
				$settingTable = $this->getSettingTable();
				$dataSessionSetting = $settingTable->getSessionCheckData();
				foreach($dataSessionSetting as $contentDetailResultSet) {
					$resultSetJson = json_encode($contentDetailResultSet); 
					$resultSet = json_decode($resultSetJson, true);
					$getSettingData = $resultSet['logoutTIme'];
				}
			}
			$sessionTimeOut = ($getSettingData > 0) ? $getSettingData : 10;
			$dataSendSessionCheck = array("sessionTimeOut" => $sessionTimeOut, "sessionLoginName" => $session->offsetGet('LoginName'));
			$sessionCheckTable = $this->getSessionCheckTable();
			$dataSessionCheck = $sessionCheckTable->getSessionCheckData($dataSendSessionCheck);
			
			if(count($dataSessionCheck) > 0) {
				$dataSendUpdateSessionCheck = array("sessionLoginName" => $session->offsetGet('LoginName'));
				$sessionCheckTable->updateSessionCheckData($dataSendUpdateSessionCheck);
			} else {
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		return parent::onDispatch($e);
	}

}