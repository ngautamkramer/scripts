<?php
  /*****
  * Name    : ApplicationController
  * Desc    : Its used for global function, here we will create the all global functions which will be frequently used. 
  * Date    : 30-Aug-2018
  *****/
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//use WebServices\Controller\ServicesController;

use Zend\Session\Container; // for session
use Zend\Mvc\MvcEvent;
use Zend\Db\Sql\Sql;
use Zend\Db\Adapter\Adapter;
class ApplicationController extends AbstractActionController
{	
  
      /*****
	 *	@Function Name		: getClientOS
	 *  @description	    : Returning OS.
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 05-Dec-2019
	 *****/
	 
public function getClientOS() {    		
    $os_platform="Unknown OS Platform";
    $os_array=array(
					'/windows nt 6.3/i'     =>  'Windows 8.1',
					'/windows nt 6.2/i'     =>  'Windows 8',
					'/windows nt 6.1/i'     =>  'Windows 7',
					'/windows nt 6.0/i'     =>  'Windows Vista',
					'/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
					'/windows nt 5.1/i'     =>  'Windows XP',
					'/windows xp/i'         =>  'Windows XP',
					'/windows nt 5.0/i'     =>  'Windows 2000',
					'/windows me/i'         =>  'Windows ME',
					'/win98/i'              =>  'Windows 98',
					'/win95/i'              =>  'Windows 95',
					'/win16/i'              =>  'Windows 3.11',
					'/macintosh|mac os x/i' =>  'Mac OS X',
					'/mac_powerpc/i'        =>  'Mac OS 9',
					'/linux/i'              =>  'Linux',
					'/ubuntu/i'             =>  'Ubuntu',
					'/iphone/i'             =>  'iPhone',
					'/ipod/i'               =>  'iPod',
					'/ipad/i'               =>  'iPad',
					'/android/i'            =>  'Android',
					'/blackberry/i'         =>  'BlackBerry',
					'/webos/i'              =>  'Mobile',
					'/windows nt 10/i'     =>  'Windows 10',
					'/CrOS/i' =>  'Chrome OS',
					'/Windows Phone/i' =>  'Mob_Window'
				);				
    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, USER_AGENT)) {
            $os_platform    =   $value;
        }

    }   

    return $os_platform;

}

     /*****
	 *	@Function Name		: getBrowser
	 *  @description	    : Returning browser.
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 05-Dec-2019
	 *****/

	public function getBrowser() {
		$user_agent=$_SERVER['HTTP_USER_AGENT'];
	//print_r($user_agent);	
		$browser="Unknown Browser";
		$browser_array  =   array(
								 '/msie/i'       =>  'Internet Explorer',
								 '/firefox/i'    =>  'Firefox',
								 '/safari/i'     =>  'Safari',
								 '/chrome/i'     =>  'Chrome',
								 '/opera/i'      =>  'Opera',
								 '/netscape/i'   =>  'Netscape',
								 '/maxthon/i'    =>  'Maxthon',
								 '/konqueror/i'  =>  'Konqueror',
								 '/mobile/i'     =>  'Handheld Browser',
								 '/edge/i'    =>  'Edge',
								 '/rv:11/i'    =>  'Edge'
								 
								 						
						   );
		
		foreach ($browser_array as $regex => $value) {
		  if (preg_match($regex, $user_agent)) {
			 $browser    =   $value;
		  }
		
		}
		return $browser;
	
	}

     /*****
	 *	@Function Name		: checkfile
	 *  @description	    : Returning 1 if file exist else 0.
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 05-Dec-2019
	 *****/
	public function checkfile($path,$filename){
		return file_exists($path.$filename)?1:0;
	}
     
	 /*****
	 *	@Function Name		: file_read
	 *  @description	    : read file and reurn data
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 05-Dec-2019
	 *****/
	
	public function file_read($file){
		if(file_exists($file)){
			$fp = fopen($file, "r");		
			if($fp){			
				$str="";			
				while(!feof($fp)){
						$fcontent = fgets($fp);//, filesize($file));					
						if($fcontent != ""){					
							$str.=$fcontent;
						}
				
				}
				fclose($fp);
				return $str;//substr($str,0,-1);
			}else{
				return "file_not_open";
			}
		}else{
			$str="#000000";
		}
		
	}
	 /*****
	 *	@Function Name		: desEncrypt
	 *  @description	    : Encrypt data
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 06-Dec-2019
	 *****/

	public function desEncrypt($input, $key_seed){
	   //clean up input
		$input = trim($input);
		$method = 'aes-256-cbc';	
		$key = substr(hash('sha256', $key_seed, true), 0, 32);
		// IV must be exact 16 chars (128 bit)
		$iv = chr(0xA) . chr(0xB) . chr(0x0) . chr(0xC) . chr(0x0) . chr(0xD) . chr(0xE) . chr(0xc) . chr(0x9) . chr(0x3) . chr(0x0) . chr(0x0) . chr(0xC) . chr(0xd) . chr(0x0) . chr(0xB);
		$ciphertext = base64_encode(openssl_encrypt($input, $method, $key, OPENSSL_RAW_DATA, $iv));
		return $ciphertext;
	
	
	 } //end function desEncrypt()
	 
	 /*****
	 *	@Function Name		: desDecrypt
	 *  @description	    : Decrypt data
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 06-Dec-2019
	 *****/
	
	public function desDecrypt($input, $key_seed){	
		$method = 'aes-256-cbc';	
		$key = substr(hash('sha256', $key_seed, true), 0, 32);
		// IV must be exact 16 chars (128 bit)
		$iv = chr(0xA) . chr(0xB) . chr(0x0) . chr(0xC) . chr(0x0) . chr(0xD) . chr(0xE) . chr(0xc) . chr(0x9) . chr(0x3) . chr(0x0) . chr(0x0) . chr(0xC) . chr(0xd) . chr(0x0) . chr(0xB); 
		$decrypted_data = openssl_decrypt(base64_decode($input), $method, $key, OPENSSL_RAW_DATA, $iv);
		return trim($decrypted_data);
	} //end function desDecrypt()
	
	 
	 /*****
	 *	@Function Name		: getModelName
	 *  @description	    : return gateway model based on file and path
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/
	public function getModelName(){
			if(file_exists(DEST_PATH."model.json")){
				$jsonStr = file_get_contents(DEST_PATH."model.json");
				$json_arr=json_decode($jsonStr,true);
				return $json_arr['modelshow'];			
			}else{
				return 'nojsonfile';
			}	
	}

	 /*****
	 *	@Function Name		: findServerConnection
	 *  @description	    : create socket connection
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/
	public function findServerConnection(){
	//global $default_server_ip,$default_server_port;
		$sock= @socket_create(AF_INET, SOCK_STREAM,  SOL_TCP);
		//added check for session manager after apache running on 8080
		$apiServerIP = '127.0.0.1';
		//$conn = @socket_connect($sock, DEFAULT_SERVER_IP, DEFAULT_SERVER_PORT);
		$conn = @socket_connect($sock, $apiServerIP, DEFAULT_SERVER_PORT);
		if($conn){
			return $sock;
		}else{
			return 0;
		}	
	} 
	
	 /*****
	 *	@Function Name		: showNetworkInfo
	 *  @description	    : returning n/w info
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/	
	public function showNetworkInfo($logincmd,$ipInfo_cmd){
		 // global $sock;	
		  $result=$this->findServerConnection();
		  if($result!=0){
				$sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
				sleep(1);
				//$sockWrrite=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
				if(!$sockWrrite){				
					$data='sendDataError';
				}else{
					//echo 'Write Successfully';
					// old value is 2048 means bytes (2kb) but now increased to 20480 bytes (20kb)
					$buf = socket_read($sock,20480); 
					if(!$buf){	
						$data='receiveDataErr'; 
					}else{					
						//if(trim($buf)=='Error12'){
						if(trim(strstr($buf,'Error13'))){						
							$data='loginerror'; 
						}else{					
							$data=$buf;
							$sockWrrite1=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
							$buf2 = socket_read($sock,20480);
							$data=	$buf2;
						}
					}
					
				}
			
		  }else{			
				$data=0;
			}

			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	} 
	
	public function showNetworkInfo_with_timeout($logincmd,$ipInfo_cmd){
		 // global $sock;	
		  $result=$this->homeServerConnection();
		  if($result!=0){
				$sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
				sleep(1);
				//$sockWrrite=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
				if(!$sockWrrite){				
					$data='sendDataError';
				}else{
					//echo 'Write Successfully';
					// old value is 2048 means bytes (2kb) but now increased to 20480 bytes (20kb)
					$buf = socket_read($sock,20480); 
					if(!$buf){	
						$data='receiveDataErr'; 
					}else{					
						//if(trim($buf)=='Error12'){
						if(trim(strstr($buf,'Error13'))){						
							$data='loginerror'; 
						}else{					
							$data=$buf;
							$sockWrrite1=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
							$buf2 = socket_read($sock,20480);
							$data=	$buf2;
							$err_code = socket_last_error($sock);
							//Check if reading timed out
							if ($data === false) {
							    $err_code = socket_last_error($sock);
							    if($err_code === SOCKET_EAGAIN || $err_code === SOCKET_EWOULDBLOCK) {
							        $data = "timeoutError";
							    }
							}
							//end Check if reading timed out							
						}
					}
					
				}
			
		  }else{			
				$data=0;
			}

			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	} 
	
	
	 /*****
	 *	@Function Name		: getMacAddress
	 *  @description	    : returning mac addres for windows and linux
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/	
	public function getMacAddress(){
		if(GET_OS=='LIN'){
			if(CHECK_LIC_DETAILS==1){
				$licfile=$destPath.'licdetails.txt';	
				$fp = fopen(DEST_PATH.FILE_LIC_DETAILS, "r");		
				if($fp){			
					$macAddrStr="";			
					while(!feof($fp)){
							$fcontent = fgets($fp);	
							if($fcontent != ""){
								if(!strstr($fcontent,'Serial no')){								
									$macAddrStr=$fcontent;
								}	
							}
					}
				}
			}else{
				$macAddrStr="";
			}
	
			$getlanMacAddrArr=explode('|',$macAddrStr);
			$getlanMacAddr=$getlanMacAddrArr[1];
			return $getlanMacAddr;
		}else{
			$deviceInventoryData=$this->getTableAllData('DeviceInventory');
			foreach($deviceInventoryData as $deviceInventoryVal){
				$getlanMacAddr=$deviceInventoryVal['macaddress'];			
			}		
		}	
		return $getlanMacAddr;
	}

	 /*****
	 *	@Function Name		: applyNetwotkSettingsLinuxDHCP
	 *  @description	    : apply n/w setting from linux when dhcp set
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/	
	function applyNetwotkSettingsLinuxDHCP($logincmd,$linuxSetHostnameCmd,$linuxDhcpCmd){
		//global $default_server_ip,$default_server_port,$sock;		
		  $result=$this->findServerConnection();
		  if($result!=0){
				$sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
				sleep(1);
				// added on 8Jun15
				$buf = socket_read($sock,512);
				$sockWrrite=socket_write($sock, $linuxSetHostnameCmd,strlen($linuxSetHostnameCmd));
				sleep(1);
				$buf = socket_read($sock,512);
				$sockWrrite=socket_write($sock, $linuxDhcpCmd,strlen($linuxDhcpCmd));			
				if(!$sockWrrite){				
					$data='sendDataError'; 
				}else{			 
					$data=1;
					
				}
		  }else{
				$data=0;
			}

			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	}

	 /*****
	 *	@Function Name		: applyNetwotkSettingsLinuxStatic
	 *  @description	    : apply n/w setting from linux when static set
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/
	function applyNetwotkSettingsLinuxStatic($logincmd,$IpSetting_cmd,$linuxStaticCmd){
	//echo $IpSetting_cmd; die;
		//global $default_server_ip,$default_server_port,$sock;	
		  $result=$this->findServerConnection();
		  if($result!=0){
				$sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
				sleep(1);
				// added on 8Jun15
				$buf = socket_read($sock,512);			
				$sockWrrite=socket_write($sock, $linuxStaticCmd,strlen($linuxStaticCmd));	
				sleep(1);					
				$sockWrrite=socket_write($sock, $IpSetting_cmd,strlen($IpSetting_cmd));
				if(!$sockWrrite){				
					$data='sendDataError';
				}else{				
					$data=1;				
				}
			
		  }else{
				$data=0;
			}
			sleep(1);

			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	} 

	 /*****
	 *	@Function Name		: homeServerConnection
	 *  @description	    : returning n/w info for home page connection
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/	
	function homeServerConnection(){
		//global $default_server_ip,$default_server_port;
		$sock= @socket_create(AF_INET, SOCK_STREAM,  SOL_TCP);
		socket_set_option($sock,SOL_SOCKET, SO_RCVTIMEO, array("sec"=>60, "usec"=>0));

		//added check for session manager after apache running on 8080
		//$apiServerIP = file_exists(DEST_PATH.FILE_SESSION_MANAGER) ? '127.0.0.1' : DEFAULT_SERVER_IP;
		$apiServerIP = '127.0.0.1';
		$conn = @socket_connect($sock, $apiServerIP, DEFAULT_SERVER_PORT);			
		if($conn){
			return $sock;
		}else{
			return 0;
		}	
	}

	 /*****
	 *	@Function Name		: homeNetworkInfo
	 *  @description	    : returning n/w info for home page connection
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/		
	function homeNetworkInfo($logincmd,$ipInfo_cmd){
		//global $default_server_ip,$default_server_port,$sock;	
		  $result=$this->homeServerConnection();
        
		  sleep(2);
		  if($result!=0){
				$sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
			
				sleep(1);
				//$sockWrrite=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
				if(!$sockWrrite){				
					$data='sendDataError';
				}else{
					//echo 'Write Successfully';
					$buf = socket_read($sock,20480); 
					if(!$buf){	
						$data='receiveDataErr'; 
					}else{					
						//if(trim($buf)=='Error12'){
						if(trim(strstr($buf,'Error13'))){						
							$data='loginerror'; 
						}else{
							$data=$buf;
							$sockWrrite1=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
							$buf2 = socket_read($sock,20480);
							$data=	$buf2;
						}
					}
					
				}
			
		  }else{			
				$data=0;
			}

			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	} 


	 /*****
	 *	@Function Name		: homeNetworkInfo
	 *  @description	    : returning mysql time zone 
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 07-Jan-2020
	 *****/		
	public function getTimeZone(){
		$sql = "SELECT count(*) from tbl_timezones WHERE tz_active_status=1";
		$res =mysql_query($sql); 
		while($row=mysql_fetch_array($res)){
			$count=$row[0];
		}
		return $count;
	}

	

	/******
      *	 @Function Name: getTableAllData
	  *  @Desc         : Get all data from table
	  *  @Date         : 05/12/2019
	  ******/
	public function getTableAllData($tblname) {	  
		  if($tblname){
			 //$ConnObject=new ServicesController();
			 $connection=$this->getConnection();
			 $queryResult = $connection->execute("SELECT * FROM $tblname");			 
			 $connection->disconnect();
			 return $queryResult;
		  }
	}

  
    /*****
	 *	@Function Name		: cleanMe
	 *  @description	    : Secures, escapes and cleans the post and get request.
     *	@Author			    : Dileep Yadav
	 *  @Date               : 30-Aug-2018
	 *****/
	 
	public function cleanMe($input) {
		   $input = mysql_real_escape_string($input);
		   $input = htmlspecialchars($input, ENT_IGNORE, 'utf-8');
		   $input = strip_tags($input);
		   $input = stripslashes($input);
		   return $input;
	}
	
	/*****
	 *	@Function Name: encriptStr
	 *  @description  : Encript the string (use the default adapter that is BlockCipher(Zend encr techique)
	 *  @Date         : 30-Oct-2018
	 *****/
	 
	public function encriptStr($str) {
		   $data = trim($str);
		   $filter = new \Zend\Filter\Encrypt();
		   $filter->setKey(ENCRPTION_KEY);
		   $encrypData=$filter->filter($data);
		   return $encrypData;
	}
	
	 /******
      *	 @Function Name: decryptStr tbl_company_calender_account
	  *  @Date         : 30-Oct-2018
	  ******/
	public function decryptStr($str) {
		  $data = trim($str);
		  $defilter = new \Zend\Filter\Decrypt();
		  $defilter->setKey(ENCRPTION_KEY);
		  $decryptData=$defilter->filter($data);
		  return $decryptData;
	}
	
	/******
      *	 @Function Name: socketConnection
	  *  @Desc         : Socket connection
	  *  @Date         : 15-Dec-2018
	  ******/
	  
	public function socketConnection($message){
		$contextOptions = array(
							'ssl' => array(
								'verify_peer' => false,
								'verify_peer_name' => false
							)
						);
						
		$context = stream_context_create($contextOptions);
		$socket = stream_socket_client('ssl://'.HOST.':'.PORT, $errno, $errstr, 20, STREAM_CLIENT_CONNECT, $context);
		if ($socket) {
			 fwrite($socket, $message);
		     fclose($socket);
		}
		/*else{
			echo "Error : Socket connection failed.";exit;
		}*/
    }
    
		//for reboot and shutdown
    	function reboot_powerOff_Server($usrInput){               	
                  $result=$this->findServerConnection();
                  if($result!=0){
                                $sock=$result;
                                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                                $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
                                sleep(1);
                                $buf = socket_read($sock,512); 
                                if($usrInput=='reboot'){
                                        $usrcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Reboot</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                                }
                                if($usrInput=='shutdown'){
                                        $usrcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>PowerOff</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                                }
                                if($usrInput=='resetnow'){
                                        $usrcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Reset</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";			    
                    }				

                                $sockWrrite=socket_write($sock, $usrcmd,strlen($usrcmd));
                                if(!$sockWrrite){				
                                        $data='sendDataError'; 
                                }else{			 
                                        $data=1;

                                }

                  }else{
                                $data=0;
                        }

                        if(!is_null($sock)){ @socket_close($sock); }
                        return $data;
        } 

        function sendMsgToAPIserver($logincmd,$actionCmd){                	
                  $result=$this->findServerConnection();
                  if($result!=0){
                                $sock=$result;
                                $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
                                sleep(2);
                                // added on 8Jun15
                                $buf = socket_read($sock,512);
                                $sockWrrite=socket_write($sock, $actionCmd,strlen($actionCmd));
                                sleep(2);
                                if(!$sockWrrite){				
                                        $data='sendDataError'; 
                                }else{			 
                                        $data=1;

                                }

                  }else{
                                $data=0;
                        }

                        if(!is_null($sock)){ @socket_close($sock); }
                        return $data;
        }

        function returnSocketData($logincmd,$ipInfo_cmd){               
                  $result=$this->findServerConnection();
                  if($result!=0){
                                $sock=$result;
                                $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
                                sleep(1);
                                //$sockWrrite=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
                                if(!$sockWrrite){
                                        $data='sendDataError';
                                }else{
                                        //echo 'Write Successfully';
                                        $buf = socket_read($sock,1024);
                                        if(!$buf){
                                                $data='receiveDataErr';
                                        }else{
                                                if(trim(strstr($buf,'Error13'))){
                                                        $data='loginerror';
                                                }else{
                                                        $data=$buf;
                                                        $sockWrrite1=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
                                                                                                        sleep(2);
                                                        $buf2 = socket_read($sock,1024);
                                                        $data=  $buf2;
                                                }
                                        }

                                }

                  }else{
                                $data=0;
                        }

                        if(!is_null($sock)){ @socket_close($sock); }
                        return $data;
        }
        
        public function strip_xss($str, $allowed=null){ 
                $str=addslashes(htmlspecialchars(str_replace("\$","",str_replace(";","",str_replace("*","",str_replace('\\','',str_replace("<","",str_replace(">","",str_replace("?","",str_replace("//","",str_replace("(","",str_replace(")","",$str))))))))))));
                if (!$allowed){
                        $allowed = array('<h1>','<h2>','<h3>','<h4>','<h5>','<h6>','<b>','<i>','<u>','<a>','<ul>','<ol>','<li>','<pre>','<hr>','<blockquote>','<img>','<font>','<span>','','
        ','<table>','<thead>','<th>','<tr>','<td>','<em>','<strong>','<applet>','<div>','<center>','<pre>','<ins>','<del>','<em>','<kbd>','<dd>','<tbody>','<tfooter>','<big>','<button>','<input>','<option>','<textarea>','<fieldset>','<form>','<legend>','code');
                }
                $disabled = array('onabort', 'onactivate', 'onafterprint', 'onafterupdate', 'onbeforeactivate', 'onbeforecopy', 'onbeforecut', 'onbeforedeactivate', 'onbeforeeditfocus', 'onbeforepaste', 'onbeforeprint', 'onbeforeunload', 'onbeforeupdate', 'onblur', 'onbounce', 'oncellchange', 'onchange', 'onclick', 'oncontextmenu', 'oncontrolselect', 'oncopy', 'oncut', 'ondataavaible', 'ondatasetchanged', 'ondatasetcomplete', 'ondblclick', 'ondeactivate', 'ondrag', 'ondragdrop', 'ondragend', 'ondragenter', 'ondragleave', 'ondragover', 'ondragstart', 'ondrop', 'onerror', 'onerrorupdate', 'onfilterupdate', 'onfinish', 'onfocus', 'onfocusin', 'onfocusout', 'onhelp', 'onkeydown', 'onkeypress', 'onkeyup', 'onlayoutcomplete', 'onload', 'onlosecapture', 'onmousedown', 'onmouseenter', 'onmouseleave', 'onmousemove', 'onmoveout', 'onmouseover', 'onmouseup', 'onmousewheel', 'onmove', 'onmoveend', 'onmovestart', 'onpaste', 'onpropertychange', 'onreadystatechange', 'onreset', 'onresize', 'onresizeend', 'onresizestart', 'onrowexit', 'onrowsdelete', 'onrowsinserted', 'onscroll', 'onselect', 'onselectionchange', 'onselectstart', 'onstart', 'onstop', 'onsubmit', 'onunload','alert');

                // remove all non-printable characters. CR(0a) and LF(0b) and TAB(9) are allowed // this prevents some character re-spacing such as <java\0script> // note that you have to handle splits with \n, \r, and \t later since they *are* allowed in some inputs
                $str = preg_replace('/([\x00-\x08,\x0b-\x0c,\x0e-\x19])/', '', $str);

                // straight replacements, the user should never need these since they're normal characters
                // this prevents like <IMG SRC=&#X40&#X61&#X76&#X61&#X73&#X63&#X72&#X69&#X70&#X74&#X3A&#X61&#X6C&#X65&#X72&#X74&#X28&#X27&#X58&#X53&#X53&#X27&#X29>
                $search = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890!@#$%^&*()~`";:?+/={}[]-_|\'\\';
                for ($i = 0; $i < strlen($search); $i++) {
                        // ;? matches the ;, which is optional // 0{0,7} matches any padded zeros, which are optional and go up to 8 chars // &#x0040 @ search for the hex values
                        $str = preg_replace('/(&#[xX]0{0,8}'.dechex(ord($search[$i])).';?)/i', $search[$i], $str); // with a ;
                        // &#00064 @ 0{0,7} matches '0' zero to seven times
                        $str = preg_replace('/(&#0{0,8}'.ord($search[$i]).';?)/', $search[$i], $str); // with a ;
                }

                return preg_replace('/\s(' . implode('|', $disabled) . ').*?([\s\>])/', '\\2', preg_replace('/<(.*?)>/i', "'<' . preg_replace(array('/javascript:[^\"\']*/i', '/(" . implode('|', $disabled) . ")[ \\t\\n]*=[ \\t\\n]*[\"\'][^\"\']*[\"\']/i', '/\s+/'), array('', '', ' '), stripslashes('\\1')) . '>'", strip_tags($str, implode('', $allowed))) );
        }
	
 	public function getConnection(){ 
		$dbAdapterConfig = array(
								'driver'   => 'Pgsql',
								'database' => DB_NAME,
								'username' => DB_USER,
						  		'password' => DB_PASSWORD,
								'hostname' => HOST_NAME,
								'port' => DB_PORT,
						  		'charset'  => 'utf8'
							);
        $dbAdapter = new Adapter($dbAdapterConfig); 
        $driver = $dbAdapter->getDriver();
	    $connection = $driver->getConnection();
	    return $connection;
	}
        
        function rgb2hex($rgb) {
            $hex = "#";
            $hex .= str_pad(dechex($rgb[0]), 2, "0", STR_PAD_LEFT);
            $hex .= str_pad(dechex($rgb[1]), 2, "0", STR_PAD_LEFT);
            $hex .= str_pad(dechex($rgb[2]), 2, "0", STR_PAD_LEFT);

            return $hex; // returns the hex value including the number sign (#)
        }
		

			/*****
	 *	@Function Name: getUptime
	 *  @description  : get system uptime
	 *  @Date         : 20-jan-2020
	 *****/
	public  function getUptime()
	{
		$connection=$this->getConnection();
		//$queryResult = $connection->execute("SELECT to_char(current_timestamp-pg_postmaster_start_time(), 'HH24h MIm') as Uptime")->current();
		$queryResult = $connection->execute("SELECT FLOOR(EXTRACT(EPOCH FROM current_timestamp - pg_postmaster_start_time()) / 3600) AS uptimeHours, (FLOOR(EXTRACT(EPOCH FROM current_timestamp - pg_postmaster_start_time()) / 60) % 60) AS uptimeMinutes")->current();
		if ($queryResult['uptimehours'] < 0 || $queryResult['uptimeminutes'] < 0) {
			return '00h 00m';
		}else{
			return str_pad($queryResult['uptimehours'], 2, '0', STR_PAD_LEFT).'h '.str_pad($queryResult['uptimeminutes'], 2, '0', STR_PAD_LEFT).'m';
		}
	}
	
	
	
				/*****
	 *	@Function Name: totalSpace
	 *  @description  : get total disk space
	 *  @Date         : 20-jan-2020
	 *****/

	public function totalSpace($rawOutput = false,$diskPath=null) {
    $diskTotalSpace = @disk_total_space($diskPath);
    if ($diskTotalSpace === FALSE) {
      //throw new Exception('totalSpace(): Invalid disk path.');
	  //echo "Invalid Drive";
	    $diskTotalSpace=0;
	  //return addUnits($diskTotalSpace);
    }else{
		//return $rawOutput ? $diskTotalSpace : addUnits($diskTotalSpace);
		return $diskTotalSpace;
	}
  }

			/*****
	 *	@Function Name: freeSpace
	 *  @description  : get freeSpace
	 *  @Date         : 20-jan-2020
	 *****/

  public function freeSpace($rawOutput = false,$diskPath=null) {
    $diskFreeSpace = @disk_free_space($diskPath);
    if ($diskFreeSpace === FALSE) {
      //throw new Exception('freeSpace(): Invalid disk path.');
	  //echo "Invalid Drive";
	  $diskFreeSpace=0;
	  //return addUnits($diskTotalSpace);
    }else{
    	//return $rawOutput ? $diskFreeSpace : addUnits($diskFreeSpace);
		return $diskFreeSpace;
	}	
  }   
  
  		/*****
	 *	@Function Name: addUnits
	 *  @description  : convert units
	 *  @Date         : 20-jan-2020
	 *****/
	 public function addUnits($bytes) {
		$units = array( 'B', 'KB', 'MB', 'GB', 'TB' );
	
		for($i = 0; $bytes >= 1024 && $i < count($units) - 1; $i++ ) {
		  $bytes /= 1024;
		}
	
		return (round($bytes, 1)-0.1).' '.$units[$i];
	  }
  
   		/*****
	 *	@Function Name: getModelDotJsonData
	 *  @description  : return all model.json data
	 *	@Author		  : Ashu
	 *  @Date         : 20-jan-2020
	 *****/
	 public function getModelDotJsonData() {
			if(file_exists(DEST_PATH."model.json")){
				$jsonStr = file_get_contents(DEST_PATH."model.json");
				$json_arr=json_decode($jsonStr,true);
				return $json_arr;			
			}else{
				return 'nojsonfile';
			}	
	 
	 }
    
	/*****
	 *	@Function Name: getSerialNumber
	 *  @description  : return serial number
	 *	@Author		  : Ashu
	 *  @Date         : 21-jan-2020
	 *****/
 
	 public function getSerialNumber() {
	 		$getSerialNo="";
			if(GET_OS=='LIN'){				
				if(CHECK_LIC_DETAILS==1){
					$licfile=$destPath.'licdetails.txt';	
					$fp = fopen(DEST_PATH.FILE_LIC_DETAILS, "r");		
					if($fp){	
						while(!feof($fp)){
								$fcontent = fgets($fp);	
								if($fcontent != ""){
									if(!strstr($fcontent,'Serial no')){			
										$getSerialNoArr=explode('|',str_replace(":","",$fcontent));
										$getSerialNo=$getSerialNoArr[1];
									}	
								}
						}
					}
				}
		
				
			}else{
				$serialNo_file=SERIALNO_FILE;
				if(CHECK_SERIALNO_FILE==1){
					$myfile = fopen(DEST_PATH.SERIALNO_FILE, "r");
					if(filesize(DEST_PATH.SERIALNO_FILE) > 0){
						$getSerialNo=fread($myfile,filesize(DEST_PATH.SERIALNO_FILE));
					}					
					fclose($myfile);
				}		
			
			} 
			return $getSerialNo;
	 } 

		/*****
		 *	@Class Name			: curl_get_contents
		 *  @description	    : web service call for getting response                   
		 *	@Author			    : Ashu
		 *  @Date               : 21-Jan-2020
		 *****/ 
		public function curl_get_contents($url){
			$ch = curl_init();
			$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, $certificate_location);
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_HEADER, false);
			$data = curl_exec($ch);
			//returning error
			if (curl_errno($ch)) {
				return curl_errno($ch);
			}else{
				return $data;
			}					
			curl_close($ch);
			
		}

    		/*****
	 *	@Function Name: webserviceToGetDataWithTimout
	 *  @description  : return all model.json data
	 *	@Author		  : Ashu
	 *  @Date         : 21-jan-2020
	 *****/
	  public function webserviceToGetDataWithTimout($username,$pass,$data,$path,$filename){	
		$myjson = json_encode($data);	
		$url=$path.$filename;//"cb.wowvision.com/fw/getmehash.php";	
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_TIMEOUT, 20);
		$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, $certificate_location);
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $url,
			CURLOPT_POST => 1,
			CURLOPT_POSTFIELDS => array(
			"UserName" =>$username,
			"UserPass" =>$pass,
			"data"=> $myjson
				
			)
		));	
	
		$resp = curl_exec($curl);
		curl_close($curl);
		return $resp;
	}

	public function activateAutoDssLicense($activateLicenseData, $proxyServerSettings, $useProxy) {			
		$jsonServerData = json_encode($activateLicenseData["licServerData"]);			
		// $proxyServerSettings["password"] = "123456";
		$urlLicense = $activateLicenseData["licServerPath"].$activateLicenseData["licServerFileName"];//"cb.wowvision.com/fw/getmehash.php";	
		$curl = curl_init("https://discovery.wowvision.com/");
		curl_setopt($curl, CURLOPT_TIMEOUT, 20);
		$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, $certificate_location);
		if($useProxy == true) {
			curl_setopt($curl, CURLOPT_HTTPPROXYTUNNEL , 1); 
			curl_setopt($curl, CURLOPT_PROXY, $proxyServerSettings["servername"]); 
			curl_setopt($curl, CURLOPT_PROXYPORT, $proxyServerSettings["port"]); 
			if($proxyServerSettings["username"] && $proxyServerSettings["password"]) {
				curl_setopt($curl, CURLOPT_PROXYUSERPWD,'$proxyServerSettings["username"]:$proxyServerSettings["password"]'); 
			}	
		}
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $urlLicense,
			CURLOPT_POST => 1,
			CURLOPT_POSTFIELDS => array(
				"UserName" => $activateLicenseData["licUserName"],
				"UserPass" => $activateLicenseData["licUserPassword"],
				"data" => $jsonServerData
			)
		));	
		$resp = curl_exec($curl);
		curl_close($curl);
		return $resp;
	}
	
	/******
      *	 @Function Name: manage_Tbl_Session_Check
	  *  @Desc         : Insert/update tbl_session_check while login
	  *  @Date         : 22/1/2020
	  ******/
	public function manage_Tbl_Session_Check() {
		$session = new Container('userinfo');						
		$connection=$this->getConnection();
		//die("SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'");
		$sessionQry=$connection->execute("SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'");		
		if(count($sessionQry)==0){
			$connection->execute("INSERT INTO tbl_session_check (userid,sessionid,datetime) VALUES('".$session->offsetGet('LoginName')."','".session_id()."',".time().")");
			//$connection->execute("INSERT INTO tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW())");
		}
	}
	
	/******
      *	 @Function Name: checkTableCount
	  *  @Desc         : return table count
	  *  @Date         : 22/1/2020
	  ******/
	public function checkTableCount($tbl) {								
		$connection=$this->getConnection();    
		$sessionQry=$connection->execute("SELECT * FROM $tbl");		
		return count($sessionQry);
	}

	/******
      *	 @Function Name: checkTableCount
	  *  @Desc         : return table count
	  *  @Date         : 22/1/2020
	  ******/
	public function insertTableData($tbl,$tbldataArr) {		
		$connection=$this->getConnection();		
		/*$tblQry="INSERT INTO $tbl  ";
		foreach($tbldataArr as $tblField=>$fieldVal){
			$tblQry.= '"'.$tblField.'"'."='".$fieldVal."',";
		}
		$tblQry=substr($tblQry,0,-1);*/
		$key = '"'.implode('","', array_keys($tbldataArr)).'"';
		$value = "'" . implode( "','", array_values($tbldataArr)) ."'";
		$tblQry = "INSERT INTO $tbl ($key) VALUES ($value)";
		$connection->execute($tblQry);		
	}
	
	/******
      *	 @Function Name: updateTableData
	  *  @Desc         : update table . we can update table with or without condition
	  *  @Date         : 22/1/2020
	  ******/
	public function updateTableData($tbl,$tbldataArr,$whrCondition=null) {	//die($whrCondition);							
		$connection=$this->getConnection();		
		$tblQry="UPDATE $tbl SET ";
		foreach($tbldataArr as $tblField=>$fieldVal){
			$tblQry.=$tblField."='".$fieldVal."',";
		}
		$tblQry=substr($tblQry,0,-1);		
		$tblQryfinal=($whrCondition!='')?$tblQry.' '.$whrCondition:$tblQry;
		$connection->execute($tblQryfinal);			
		
	}

        //get data for security setttings
        public function getComplexPasswordSettings(){
        	$appObj = new ApplicationController();
            $settingsUrl = DEST_PATH.'via_settings.json';
			$response = file_get_contents($settingsUrl);	
			//decrypt json
			$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
			$templateSettings = json_decode($decryptResponse);
			$data_complex = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->security;
            return $data_complex;
        }

         //get data for security setttings
        public function getVsmComplexPasswordSettings(){
            $connection=$this->getConnection();
            $sql_complex=$connection->execute("SELECT * FROM complexpassword ORDER BY id DESC LIMIT 1");
            $data_complex = $sql_complex->current();
            return $data_complex;
        }
        
        public function createFile($filename,$val){
            $fileOpen = fopen($filename, 'w') or die('file open error in createFile function');			
            $fileWrite= fwrite($fileOpen, $val);
            fclose($fileOpen);	
        }
	
		    		/*****
	 *	@Function Name: webserviceToGetData
	 *  @description  : return url path
	 *	@Author		  : vineet
	 *  @Date         : 22-jan-2020
	 *  @modified By  : Dileep (Change the curl request for checkforupdate: 28-June-2021)
	 *****/
	function webserviceToGetData($username,$pass,$data,$path,$filename){	
	$myjson = json_encode($data);	
	$url=$path.$filename;//"cb.wowvision.com/fw/getmehash.php";		
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_TIMEOUT, 20);
	$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, $certificate_location);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, $certificate_location);
	curl_setopt_array($curl, array(
		CURLOPT_RETURNTRANSFER => 1,
		CURLOPT_URL => $url,
		CURLOPT_POST => 1,
		CURLOPT_POSTFIELDS => array(
		"UserName" =>$username,
		"UserPass" =>$pass,
		"data"=> $data
			
		)
	));	
    $resp = curl_exec($curl);
	curl_close($curl);
	return $resp;
}



	    		/*****
	 *	@Function Name: getWifiSecurityKey
	 *  @description  : return security key
	 *	@Author		  : vineet
	 *  @Date         : 22-jan-2020
	 *****/
		public function getWifiSecurityKey(){	
			$wifiSecurityFilekey='';
			$wifiSecurityFileIV='';
			$sysMacAddrqry=$this->getTableAllData('deviceinventory');
			foreach($sysMacAddrqry as $sysMacQuery){
				$systemMacAddr= $sysMacQuery['macaddress'];
			}
			$systemMacAddr=strtoupper($systemMacAddr);
			$replaceColun=str_replace(':','',$systemMacAddr);	
			$firstPart=substr($replaceColun,2,strlen($replaceColun)); // skip first 2 characters			
			$orignalStr= substr($firstPart,0,-2);		
			$wifiSecurityFilekey=$orignalStr.strrev($orignalStr);	
			$wifiSecurityFileIV=strrev($orignalStr).($orignalStr);
		    return $wifiSecurityFilekey.'#'.$wifiSecurityFileIV;
		}
		
	  /******
      *	 @Function Name: getExchangeVersion
	  *  @Desc         : Get all exchange verison
	  *  @Date         : 18-Jan-2019
	  ******/
	 public function getExchangeVersion() {
		     $exchengeArr=array();
			 $connection=$this->getConnection();
			 $queryRes = $connection->execute("SELECT exchange_verison,exchange_name FROM tbl_exchange_version WHERE  status=1 ORDER BY id ASC");
			 foreach ($queryRes as $result) {
				$exchengeArr[$result['exchange_name']] = $result['exchange_verison'];
			 }
			 return $exchengeArr;
	 }
	
                public function truncateTable($tblname) {	  
                          if($tblname){
                                 $connection=$this->getConnection();
                                 $queryResult = $connection->execute("TRUNCATE TABLE $tblname RESTART IDENTITY");
                          }
                }
				
				
	/******
      *	 @Function Name: delete_Tbl_Session_CheckData
	  *  @Desc         : delete tbl_session_check while logout
	  *  @Date         : 29/1/2020
	  ******/
	public function delete_Tbl_Session_CheckData() {
		$session = new Container('userinfo');						
		$connection=$this->getConnection();	
		$sessionQry=$connection->execute("DELETE FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'");		
	}
	
	/******
      *	 @Function Name: ActivityLog
	  *  @Desc         : Create log
	  *  @Date         : 29/1/2020
	  ******/
	
	public function ActivityLog($actionTaken,$remarks){
		$session = new Container('userinfo');
		$connection=$this->getConnection();
		$connection->execute("INSERT INTO ActivityLogMaster (UserID,ActionTaken,ActivityDate,hostname,remarks) VALUES ('".$session->offsetGet('LoginName')."','".$actionTaken."',NOW(),'".HOSTNAME."','".$remarks."')");	
		//$connection->execute("INSERT INTO ActivityLogMaster SET userid='".$session->offsetGet('LoginName')."', ActionTaken='".$actionTaken."', ActivityDate = now(),hostname='".HOSTNAME."',hostname='".$remarks."'");
		$connection->disconnect();
	}	
	
    // Command for update firmware verison	
	function updateFirmwareVersionCmd($filepath)
	{ 
         $result=$this->findServerConnection();
	     if($result!=0){
			 $sock=$result;
			 $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			 $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
			 sleep(1);			
			 $buf = socket_read($sock,512);
			 $usrcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>SUpdate</Cmd><P1>$filepath</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";			
			 $sockWrrite=socket_write($sock, $usrcmd,strlen($usrcmd));
			 if(!$sockWrrite){				
				 $data='sendDataError';
			 }else{		 
				$data=1;
			 }
	   }else{
			$data=0;
	   }

	   if(!is_null($sock)){ @socket_close($sock); }
	   return $data;
	}  
	
	/******
      *	 @Function Name: deleteTableData
	  *  @Desc         : deleting table data
	  *  @Date         : 04/02/2020
	  ******/	
	public function deleteTableData($tblname,$whrcondition) {	  
			  if($tblname){
					 $connection=$this->getConnection();
					 $queryResult = $connection->execute("DELETE FROM $tblname $whrcondition");
			  }
	}
	
	 /*****
	 *	@Function Name		: getModelNameByParam
	 *  @description	    : return gateway model based on file and path
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 04-Feb-2020
	 *****/
	public function getModelNameByParam($param){
			if(file_exists(DEST_PATH."model.json")){
				$jsonStr = file_get_contents(DEST_PATH."model.json");
				$json_arr = json_decode($jsonStr,true);
				return $json_arr[$param];			
			}else{
				return 'nojsonfile';
			}	
	}
	
	 /*****
	 *	@Function Name		: executeQueries
	 *  @description	    : execute prepared query statments
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 04-Feb-2020
	 *****/
	public function executeQueries($query){	
		$connection=$this->getConnection();
		$queryResult = $connection->execute($query);
		$connection->disconnect(); //disconnect the mysql connection
	}

	 /*****
	 *	@Function Name		: returnQueryData
	 *  @description	    : execute query and return query data
     *	@Author			    : Ashu Chauhan
	 *  @Date               : 05-Feb-2020
	 *****/

	public function returnQueryData($query){
		$connection=$this->getConnection();		
		$queryResult = $connection->execute($query);
		$connection->disconnect();
		return $queryResult;
	}
	
	/*****
	 *	@Function Name		: securePassword
	 *  @description	    : Encrypt the password using sha1,md5 and salt
     *	@Author			    : Dileep
	 *  @Date               : 11-Feb-2020
	 *****/
	public function securePassword($psw){	
		 if($psw){
			 $pass = md5($psw);     // Encrypt the password into md5
			 $salt = sha1($pass);     //Encrypt the salt in sha1
			 $password = sha1($pass.$salt);
			 return $password;
		 }
	}
	
	/*****
	 *	@Function Name		: updatePassAlgo
	 *  @description	    : update the password with new algo
     *	@Author			    : Dileep
	 *  @Date               : 11-Feb-2020
	 *****/
	public function updatePassAlgo($uname){	
		if($uname){
			$connection=$this->getConnection();
			$queryResult = $connection->execute("select length(password) as pass_length,password from appuserlist WHERE apploginname='$uname';");
			$getRes = $queryResult->current();
			$passLenght = $getRes['pass_length'];
			if($passLenght == 32){
			     $pass = $getRes['password'];	// already md5 encrypted  
			     $salt = sha1($pass);     //Encrypt the salt in sha1
			     $password = sha1($pass.$salt);
				 $connection->execute("UPDATE appuserlist SET password='$password' WHERE apploginname='$uname';");
			}
		}
	}
	
	/*****
	 *	@Function Name		: getLandingpage
	 *  @description	    : Get redirect page based on permission
     *	@Author			    : Ashu
	 *  @Date               : 3-March-2020
	 *****/
	
	public function getLandingpage($user_id){
			if($user_id!=1){
				$quryArr=$this->returnQueryData("SELECT DISTINCT(B.url) FROM tbl_user_access A INNER JOIN tbl_menus B ON B.id=A.menu_id_fk WHERE B.status=1 AND A.user_id_fk=$user_id");
				foreach($quryArr as $quryData){
					$homepage_array[]=$quryData['url'];
				}
				if(is_array($homepage_array) && in_array("systemReports.php",$homepage_array)){
					$homepage='gateways#list';
				}else{
					$homepage='vsmdashboard#report';
				}
			}else{
				$homepage='gateways#list';
			}
	   
		return $homepage;
	}
	
	/*****
	 *	@Function Name		: getmenusbyrole
	 *  @description	    : Getting menus based on Role
     *	@Author			    : Ashu
	 *  @Date               : 4-March-2020
	 *****/

    public function getmenusbyrole($user_id){
		$session = new Container('userinfo');		
		if($user_id==1){
			$queryArr=$this->returnQueryData("SELECT MO.id as module_id,MO.module_name,ME.menu_name,ME.id as menu_id,ME.parent_menu_id,ME.url FROM tbl_modules MO LEFT JOIN tbl_menus ME ON ME.module_id_fk=MO.id WHERE ME.status=1 ORDER BY ME.id ASC");
		}else{
			 $queryArr=$this->returnQueryData("SELECT MO.id as module_id,MO.module_name,ME.menu_name,ME.id as menu_id,ME.parent_menu_id,ME.url FROM tbl_user_access TUA LEFT JOIN tbl_menus ME ON ME.id=TUA.menu_id_fk LEFT JOIN tbl_modules MO ON MO.id=TUA.module_id_fk WHERE TUA.user_id_fk=$user_id AND ME.status=1 ORDER BY ME.id ASC");
		}		
			//$res2  = mysql_query($query);
			$menuarr=array();   //User
			$menuarr1=array();  //Support
			$menuarr2=array();  //Reports 
			$menuarr4=array();  //Device Mgmt
			$menuarr5=array();  // VSM Management
			$menuarr6=array();  // Firmware Management
			$menuarr7=array();  // alert mgmt
			$menuarr8=array();  // recording mgmt
			$menuarr9=array();  // poll
			$menuarr10=array(); // Dss
			$menuarr11=array(); // Calendar
			$menuarr12=array(); //VIA mgmt
			$menuarr13=array(); //KDS mgmt

		foreach($queryArr as $row){		
			if(isset($row['module_id']) && $row['module_id']==1){
				$menuarr[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==2 && ($row['parent_menu_id']=="" || $row['parent_menu_id']==2)){
				$menuarr4[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==3){
				$menuarr2[$row['menu_name']]=$row['url'];
			}
			else if(isset($row['module_id']) && $row['module_id']==5){
				$menuarr5[$row['menu_name']]=$row['url'];
			}
			else if(isset($row['module_id']) && $row['module_id']==6){
				$menuarr6[$row['menu_name']]=$row['url'];
			}
			else if(isset($row['module_id']) && $row['module_id']==7){
				$menuarr7[$row['menu_name']]=$row['url'];
			}
			else if(isset($row['module_id']) && $row['module_id']==8){
				$menuarr8[$row['menu_name']]=$row['url'];
			}
			else if(isset($row['module_id']) && $row['module_id']==10){
				$menuarr10[$row['menu_name']]=$row['url'];
			}
			else if(isset($row['module_id']) && $row['module_id']==11){
				$menuarr11[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==12){
				$menuarr12[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==13){
				$menuarr13[$row['menu_name']]=$row['url'];
			}
			
			
		}		
		$menuarr1['Support']='index/support';  // common for all
		$items = array(
			'menuarr' => $menuarr,
			'menuarr4' => $menuarr4,
			'menuarr2' => $menuarr2,
			'menuarr5' => $menuarr5,
			'menuarr6' => $menuarr6,
			'menuarr7' => $menuarr7,
			'menuarr8' => $menuarr8,
			'menuarr10' => $menuarr10,
			'menuarr11' => $menuarr11,
			'menuarr12' => $menuarr12,
			'menuarr13' => $menuarr13,
		);
		return $session->offsetSet('user_menu_'.$user_id, $items);
	}

	/*****
	 *	@Function Name		: getViaMenus
	 *  @description	    : Getting all menus of VIA
     *	@Author			    : Ranjan
	 *  @Date               : 11-Sept-2020
	 *****/

    public function getViaMenus($user_id){
		$session = new Container('userinfo');		
		$queryArr=$this->returnQueryData("SELECT MO.id as module_id,MO.module_name,ME.menu_name,ME.id as menu_id,ME.parent_menu_id,ME.url FROM tbl_modules MO LEFT JOIN tbl_menus ME ON ME.module_id_fk=MO.id WHERE ME.status=1 ORDER BY ME.id ASC");
		$menuarr=array();   //User Mgmt
		$menuarr1=array();  //Home
		$menuarr2=array();  //Reports
		$menuarr3=array();  //Utility
		$menuarr4=array();  //VIA Management
		$menuarr8=array();  // recording
		$menuarr10=array(); // Dss

		foreach($queryArr as $row){		
			if(isset($row['module_id']) && $row['module_id']==2){
				$menuarr[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==1){
				$menuarr1[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==6){
				$menuarr2[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==7){
				$menuarr3[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==3){
				$menuarr4[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==4){
				$menuarr8[$row['menu_name']]=$row['url'];
			}else if(isset($row['module_id']) && $row['module_id']==5){
				$menuarr10[$row['menu_name']]=$row['url'];
			}
		}		
		$menuarr1['Support'] = HELP_URL;  // common for all
		$items = array(
			'menuarr' => $menuarr,
			'menuarr1' => $menuarr1,
			'menuarr2' => $menuarr2,
			'menuarr3' => $menuarr3,
			'menuarr4' => $menuarr4,
			'menuarr8' => $menuarr8,
			'menuarr10' => $menuarr10,
		);
		$session->offsetSet('user_menu_'.$user_id, $items);
	}
        
    public function getModelType($did){
        $checkQryNew=$this->returnQueryData("SELECT os_type FROM DeviceInventory WHERE DID=$did");
        $retType='';
        if($checkQryNew->count()>0){
            $resultRow=$checkQryNew->current();
            $osType=$resultRow['os_type'];		
            if($osType=='-1'){
                $retType='-';
            }else{
                if($osType==0){
                    $retType=(PRODUCT_TYPE=='via')?'Campus Plus [1 & 2]':'Collab8';
                }
                if($osType==1){
                    $retType=(PRODUCT_TYPE=='via')?'Connect Pro':'Collab8 Lite';
                }
                if($osType==2){
                    $retType='Campus [1 & 2] / VIAWare';
                }
                if($osType==3){
                    $retType='VIAGO [1 & 2]';
                }
                if($osType==4){
                    $retType=(PRODUCT_TYPE=='via')?'Connect Plus':'Collab8 Plus';
                }
            }
        }
        return $retType;
    }

        public function getCustomTemplatesId(){
            $qry=$this->returnQueryData("SELECT * FROM  screentemplatemaster where ScreenTemplateID not in(1,2,3,4,5,6)");
            $templIdArray=array();
            if($qry->count()>0){
                foreach($qry as $fetch){
                    $templIdArray[]=$fetch['ScreenTemplateID'];
                }		
            }	
            return $templIdArray;
        }
        
        public function getCategories($user_id){
            if($user_id==1){
                $sql = "SELECT * from devicegroup order by DeviceGroup";	
            }else{
                $sql="SELECT distinct(DG.DeviceGroupID),DG.DeviceMasterID,DG.DeviceGroup,DG.Comments,GROUP_CONCAT(TUA.menu_id_fk) as menu_id_fk FROM devicegroup DG LEFT JOIN tbl_user_access TUA  ON TUA.group_id_fk=DG.DeviceGroupID WHERE TUA.user_id_fk=$user_id GROUP BY TUA.group_id_fk";
            }
            $res = $this->returnQueryData($sql); 	
            $new_array=array();
            foreach($res as $row){
                $new_array[] = $row;
            }
            $tree = $this->buildTree($new_array);
            $this->printTree($tree);
        }
        
        public function buildTree(Array $data, $parent = 0) {
            $tree = array();
            foreach ($data as $d) {
                if ($d['DeviceMasterID'] == $parent) {
                    $children = $this->buildTree($data, $d['DeviceGroupID']);
                    // set a trivial key
                    if (!empty($children)) {
                        $d['_children'] = $children;
                    }
                    $tree[] = $d;
                }
            }
            return $tree;
        }
        
        public function printTree($tree, $r = 0, $p = null) {
            global $DeviceMasterID;	
            foreach ($tree as $i => $t) {
                $selected='';
                if($DeviceMasterID==$t['DeviceGroupID']){
                        $selected='selected';
                }
                //modify condition based on level
                $countLevel=$this->getTreeLevel($t['DeviceGroupID']);		
                $dash = ($t['DeviceMasterID'] == 0) ? '' : str_repeat('-', $countLevel) .'   ';
                printf("\t<option $selected value='%d'>%s%s</option>\n", $t['DeviceGroupID'], $dash, $t['DeviceGroup']);
                if ($t['DeviceMasterID'] == $p) {
                    $r = 0;
                }
                if (isset($t['_children'])) {
                    $this->printTree($t['_children'], ++$r, $t['DeviceMasterID']);
                }
            }
        }
        
        public function getTreeLevel($id){   
            $data=$this->getGroupsAllData();
            $current = $data[$id];	
            $parent_id = $current["DeviceMasterID"] === 0 ? 0 : $current["DeviceMasterID"];
            $parents = array();
            while (isset($data[$parent_id])) {
                $current = $data[$parent_id];
                $parent_id = $current["DeviceMasterID"] === 0 ? 0 : $current["DeviceMasterID"];
                //$parents[] = $current["DeviceGroup"];
                $parents[] = $current["DeviceGroupID"];
            }
            	
            return count($parents);
        }
        
        public function getGroupsAllData(){
            $data = array();	
            $query = $this->returnQueryData("SELECT DeviceGroupID, DeviceMasterID, DeviceGroup FROM devicegroup ORDER BY DeviceGroup");	
            foreach ($query as $row) {
                $id = $row["DeviceGroupID"];
                $parent_id = $row["DeviceMasterID"] === 0 ? 0 : $row["DeviceMasterID"];
                $data[$id] = $row;    
            }
            return $data;
        }
        
	public function getGroupName($grpID){
			$dataQry1=$this->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroupID=$grpID");	
			$datarow=$dataQry1->current();			
			$DeviceGroup=$datarow['DeviceGroup'];
			return $DeviceGroup;		
	}

	public function get_time_ago($time){
		$currentTime = $this->returnQueryData("SELECT NOW() AS time")->current();
		$time_difference = strtotime($currentTime['time']) - strtotime($time);
		if( $time_difference < 1 ) { return 'less than 1 second ago'; }
		$condition = array( 12 * 30 * 24 * 60 * 60 =>  'year',
					30 * 24 * 60 * 60       =>  'month',
					24 * 60 * 60            =>  'day',
					60 * 60                 =>  'hour',
					60                      =>  'minute',
					1                       =>  'second'
		);

		foreach( $condition as $secs => $str ){
			$d = $time_difference / $secs;
			if( $d >= 1 ){
				$t = round( $d );
				if($str=='year'){return $time;}
				return $t . ' ' . $str . ( $t > 1 ? 's' : '' ) . ' ago';
			}
		}
	}
	
	public function getParentAllNestedChild($id)// return all nested childs
	{
		$ar = array();
		$result = $this->returnQueryData("SELECT DeviceGroupID,DeviceGroup FROM devicegroup WHERE DeviceMasterID = '$id'");
		if($result->count() > 0){
			foreach($result as $row){
				//echo $row->DeviceGroupID;
				$ar[] = $row['DeviceGroupID'];
				$r = $this->returnQueryData("SELECT * FROM devicegroup WHERE DeviceMasterID = '".$row['DeviceGroupID']."'");
				if($r->count() > 0)
					$ar = array_merge($ar, $this->getParentAllNestedChild($row['DeviceGroupID'], 1));
			}
		}
	   return $ar;   
	}
	
	public function getDepth($id, $depth = 0) {
		$temp = array();
		$appObj = new ApplicationController();
		$res = $appObj->returnQueryData("SELECT * FROM devicegroup");
		foreach($res as $row) {
		   $temp[$row['DeviceGroupID']] = $row['DeviceMasterID'];
		}
		do{
			$depth = $depth + 1; 
		}while($id = $temp[$id]); 
		return $depth;       
	}
	
	public function returnRoomNameValue(){
		$file_roomnamevalueshow=file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?$this->file_read(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):$this->file_read(DEST_PATH.READFILE_IPADD);
		return trim(htmlspecialchars($file_roomnamevalueshow));
	}
	
	public function gethcf($a, $b){ 
		// Everything divides 0 
		if($a==0 || $b==0) 
			return 0 ; 
	  
		// base case 
		if($a == $b) 
			return $a ; 
		  
		// a is greater 
		if($a > $b) 
			return $this->gethcf( $a-$b , $b ) ; 
	  
		return $this->gethcf( $a , $b-$a ) ; 
	}
	
	public function getNexttemplateName(){
		$nextWallSqlArr=$this->returnQueryData("SELECT template_name FROM tbl_templates WHERE template_name ILIKE 'template%' ORDER BY id DESC LIMIT 1");
		if(count($nextWallSqlArr)>0){
			foreach($nextWallSqlArr as $nextWallSqlData){
				$wallpaperName=$nextWallSqlData['template_name'];
				$wallCount = (int) filter_var($wallpaperName, FILTER_SANITIZE_NUMBER_INT);
				$fileStringName=str_replace($wallCount,'',$wallpaperName);
				$wallCount+=1;
				$fileWithoutExt=$fileStringName.$wallCount;
			}
		
		}else{
			$fileWithoutExt='template1';
		}
		// $nextWallSql = $this->returnQueryData("SELECT AUTO_INCREMENT AS id FROM information_schema.TABLES WHERE TABLE_SCHEMA = '".DB_NAME."' AND TABLE_NAME = 'tbl_templates'")->current();
		// $fileStringName = 'template';
		// $fileWithoutExt = $fileStringName.$nextWallSql['id'];
		return $fileWithoutExt;  
	}
	
	public function getMysqlDateTime(){
		$fetchMysqlDataArr=$this->returnQueryData('SELECT now()::timestamp as curretnttimestamp');
		foreach($fetchMysqlDataArr as $fetchMysqlData){
			$mySqlCurrentTime=$fetchMysqlData['curretnttimestamp'];
		}	
		return $mySqlCurrentTime;	
	}
	
	public function createOnOffToggle($settingId,$settingValue,$vsmValue){
		$addcss='';
		if(strstr($settingId,'bordercolornone')){
			$addcss='borderchkboxcss';
		}
		if($settingId=='qrCodeChkbox' || $settingId=='qrBypassChkbox' || $settingId=='qrTopChkbox'){
			$addcss='qrActivateClass';
		}
		
		$divhtml='';
		$checked = ($settingValue==1)?"checked":"";
		$disabled = ($vsmValue==1)?"disabled":"";
		$divhtml.='<div class="custom-control custom-switch" style="margin-left:2px;margin-bottom:5px;"><input type="checkbox" class="custom-control-input commontogglecss '.$addcss.'" name="'.$settingId.'" id="'.$settingId.'" '.$checked.' '.$disabled.'><label class="custom-control-label" for="'.$settingId.'"></label></div>';
		return $divhtml;																			
	}
	
	public function getDiffDateByLang($lang,$dateFormat){
		$month_ch=array('1'=>'一月', '2'=>'二月', '3'=>'游行', '4'=>'四月', '5'=>'可能', '6'=>'六月', '7'=>'七月', '8'=>'八月', '9'=>'九月', '10'=>'十月', '11'=>'十一月', '12'=>'十二月');
		// portuges 
		$month_pr=array('1'=>'janeiro', '2'=>'fevereiro', '3'=>'procissão', '4'=>'abril', '5'=>'pode', '6'=>'Junho', '7'=>'Julho', '8'=>'agosto', '9'=>'setembro', '10'=>'Outubro', '11'=>'novembro', '12'=>'dezembro');
		// french 
		$month_fr=array('1'=>'Janvier', '2'=>'Février', '3'=>'Mars', '4'=>'Avril', '5'=>'Mai', '6'=>'Juin', '7'=>'Juillet', '8'=>'Août', '9'=>'Septembre', '10'=>'Octobre', '11'=>'Novembre', '12'=>'Décembre');
		// spanish 
		$month_sp=array('1'=>'enero', '2'=>'febrero', '3'=>'procesión', '4'=>'abril', '5'=>'mayo', '6'=>'junio', '7'=>'julio', '8'=>'agosto', '9'=>'septiembre', '10'=>'octubre', '11'=>'noviembre', '12'=>'diciembre');
		// japanese
		$month_ja=array('1'=>'1月', '2'=>'2月', '3'=>'行列', '4'=>'4月', '5'=>'かもしれない', '6'=>'六月', '7'=>'7月', '8'=>'8月', '9'=>'9月', '10'=>'10月', '11'=>'11月', '12'=>'12月');
		// polish 
		$month_po=array('1'=>'styczeń', '2'=>'luty', '3'=>'procesja', '4'=>'kwiecień', '5'=>'może', '6'=>'czerwiec', '7'=>'lipiec', '8'=>'sierpień', '9'=>'wrzesień', '10'=>'październik', '11'=>'listopad', '12'=>'grudzień');
		// german 
		$month_gr=array('1'=>'Januar', '2'=>'Februar', '3'=>'Prozession', '4'=>'April', '5'=>'kann', '6'=>'Juni', '7'=>'Juli', '8'=>'August', '9'=>'September', '10'=>'Oktober', '11'=>'November', '12'=>'Dezember');
		// russian 
		$month_crs=array('1'=>'январь', '2'=>'февраль', '3'=>'шествие', '4'=>'апрель', '5'=>'май', '6'=>'июнь', '7'=>'июль', '8'=>'августейший', '9'=>'сентябрь', '10'=>'октября', '11'=>'ноябрь', '12'=>'Декабрь');
		
		
		
		// chinses 
		$days_ch=array('1'=>'星期一', '2'=>'星期二', '3'=>'星期三', '4'=>'星期四', '5'=>'星期五', '6'=>'星期六', '7'=>'星期日');
		// portuges 
		$days_pr=array('1'=>'Segunda-feira', '2'=>'terça', '3'=>'Quarta-feira', '4'=>'Quinta-feira', '5'=>'Sexta-feira', '6'=>'sábado', '7'=>'domingo');
		// french 
		$days_fr=array('1'=>'Lundi', '2'=>'Mardi', '3'=>'Mercredi', '4'=>'Jeudi', '5'=>'Vendredi', '6'=>'samedi', '7'=>'dimanche');
		// spanish 
		$days_sp=array('1'=>'lunes', '2'=>'martes', '3'=>'miércoles', '4'=>'jueves', '5'=>'viernes', '6'=>'sábado', '7'=>'domingo');
		
		// japanese
		$days_ja=array('1'=>'月曜', '2'=>'火曜日', '3'=>'水曜日', '4'=>'木曜日', '5'=>'金曜日', '6'=>'土曜日', '7'=>'日曜日');
		
		// polish 
		$days_pl=array('1'=>'poniedziałek', '2'=>'wtorek', '3'=>'środa', '4'=>'czwartek', '5'=>'piątek', '6'=>'sobota', '7'=>'niedziela');
		// german 
		$days_gr=array('1'=>'Montag', '2'=>'Dienstag', '3'=>'Mittwoch', '4'=>'Donnerstag', '5'=>'Freitag', '6'=>'Samstag', '7'=>'Sonntag');
		// russian 
		$days_rs=array('1'=>'понедельник', '2'=>'вторник', '3'=>'среда', '4'=>'Четверг', '5'=>'пятница', '6'=>'суббота', '7'=>'Воскресенье');
		
		//DD/MM/YYYY
		if($dateFormat=='DD/MM/YYYY'){
			if($lang=='en'){
				$systemDateDMY=date('d F, Y');								
			}
			//japanese
			elseif($lang=='ja'){																	
				$systemDateDMY=date('d').' '.$month_ja[intval(date("m"))].' '.date("Y");								
			}
			//chinese
			elseif($lang=='zh'){																	
				$systemDateDMY=date('d').' '.$month_ch[intval(date("m"))].' '.date("Y");								
			}
			//spanish
			elseif($lang=='es'){																	
				$systemDateDMY=date('d').' '.$month_sp[intval(date("m"))].' '.date("Y");						
			}
			// german 
			elseif($lang=='de'){																	
				$systemDateDMY=date('d').' '.$month_gr[intval(date("m"))].' '.date("Y");								
			}
			// russian
			elseif($lang=='ru'){																	
				$systemDateDMY=date('d').' '.$month_crs[intval(date("m"))].' '.date("Y");									
			}
			//polish
			elseif($lang=='pl'){																	
				$systemDateDMY=date('d').' '.$month_po[intval(date("m"))].' '.date("Y");								
			}								
			//french
			elseif($lang=='fr'){																	
				$systemDateDMY=date('d').' '.$month_fr[intval(date("m"))].' '.date("Y");								
			}								
			
			// portuges
			elseif($lang=='pt'){																	
				$systemDateDMY=date('d').' '.$month_pr[intval(date("m"))].' '.date("Y");								
			}
			
			// Traditional Chinese
			elseif($lang=='zh-TW'){																	
				$systemDateDMY=date('d').' '.$month_ch[intval(date("m"))].' '.date("Y");								
			}else{
				$systemDateDMY=date('d F, Y');
			}	
			
				
			return $systemDateDMY;
		}
		//MM/DD/YYYY
		if($dateFormat=='MM/DD/YYYY'){		
			if($lang=='en'){
				$systemDateMDY=date('F d, Y');							
			}
			//japanese
			elseif($lang=='ja'){																	
				$systemDateMDY=$month_ja[intval(date("m"))].' '.date('d').' '.date("Y");							
			}
			//chinese
			elseif($lang=='zh'){																	
				$systemDateMDY=$month_ch[intval(date("m"))].' '.date('d').' '.date("Y");								
			}
			//spanish
			elseif($lang=='es'){																	
				$systemDateMDY=$month_sp[intval(date("m"))].' '.date('d').' '.date("Y");							
			}
			// german 
			elseif($lang=='de'){																	
				$systemDateMDY=$month_gr[intval(date("m"))].' '.date('d').' '.date("Y");									
			}
			// russian
			elseif($lang=='ru'){																	
				$systemDateMDY=$month_crs[intval(date("m"))].' '.date('d').' '.date("Y");								
			}
			//polish
			elseif($lang=='pl'){																	
				$systemDateMDY=$month_po[intval(date("m"))].' '.date('d').' '.date("Y");							
			}								
			//french
			elseif($lang=='fr'){																	
				$systemDateMDY=$month_fr[intval(date("m"))].' '.date('d').' '.date("Y");							
			}								
			
			// portuges
			elseif($lang=='pt'){																	
				$systemDateMDY=$month_pr[intval(date("m"))].' '.date('d').' '.date("Y");									
			}
			// Traditional Chinese
			elseif($lang=='zh-TW'){																	
				$systemDateMDY=$month_ch[intval(date("m"))].' '.date('d').' '.date("Y");								
			}else{
				$systemDateMDY=date('F d, Y');
			}
			return $systemDateMDY;	
		}	
		//DD/MM
		if($dateFormat=='DD/MM'){		
			if($lang=='en'){
				$systemDateDM=date('d F');							
			}
			//japanese
			elseif($lang=='ja'){																	
				$systemDateDM=date('d').' '.$month_ja[intval(date("m"))];								
			}
			//chinese
			elseif($lang=='zh'){																	
				$systemDateDM=date('d').' '.$month_ch[intval(date("m"))];								
			}
			//spanish
			elseif($lang=='es'){																	
				$systemDateDM=date('d').' '.$month_sp[intval(date("m"))];						
			}
			// german 
			elseif($lang=='de'){																	
				$systemDateDM=date('d').' '.$month_gr[intval(date("m"))];								
			}
			// russian
			elseif($lang=='ru'){																	
				$systemDateDM=date('d').' '.$month_crs[intval(date("m"))];									
			}
			//polish
			elseif($lang=='pl'){																	
				$systemDateDM=date('d').' '.$month_po[intval(date("m"))];								
			}								
			//french
			elseif($lang=='fr'){																	
				$systemDateDM=date('d').' '.$month_fr[intval(date("m"))];								
			}								
			
			// portuges
			elseif($lang=='pt'){																	
				$systemDateDM=date('d').' '.$month_pr[intval(date("m"))];								
			}
			// Traditional Chinese
			elseif($lang=='zh-TW'){																	
				$systemDateDM=date('d').' '.$month_ch[intval(date("m"))];								
			}else{
				$systemDateDM=date('d F');	
			}			
			return $systemDateDM;
		}	
		//MM/DD
		if($dateFormat=='MM/DD'){		
			if($lang=='en'){
				$systemDateMD=date('F d');							
			}
			//japanese
			elseif($lang=='ja'){																	
				$systemDateMD=$month_ja[intval(date("m"))].' '.date('d');							
			}
			//chinese
			elseif($lang=='zh'){																	
				$systemDateMD=$month_ch[intval(date("m"))].' '.date('d');								
			}
			//spanish
			elseif($lang=='es'){																	
				$systemDateMD=$month_sp[intval(date("m"))].' '.date('d');							
			}
			// german 
			elseif($lang=='de'){																	
				$systemDateMD=$month_gr[intval(date("m"))].' '.date('d');									
			}
			// russian
			elseif($lang=='ru'){																	
				$systemDateMD=$month_crs[intval(date("m"))].' '.date('d');								
			}
			//polish
			elseif($lang=='pl'){																	
				$systemDateMD=$month_po[intval(date("m"))].' '.date('d');							
			}								
			//french
			elseif($lang=='fr'){																	
				$systemDateMD=$month_fr[intval(date("m"))].' '.date('d');							
			}								
			
			// portuges
			elseif($lang=='pt'){																	
				$systemDateMD=$month_pr[intval(date("m"))].' '.date('d');									
			}
			// Traditional Chinese
			elseif($lang=='zh-TW'){																	
				$systemDateMD=$month_ch[intval(date("m"))].' '.date('d');								
			}else{
				$systemDateMD=date('F d');
			}			
			
			return $systemDateMD;	
		}	
		
	}

	/*****
	 *	@Function Name		: getDefaultDateByLang
	 *  @description	    : returning date and time based on lang
     *	@Author			    : Ashu
	 *  @Date               : 11-Feb-2020
	 *****/	
	public function getDefaultDateByLang($lang){
		$month_ch=array('1'=>'一月', '2'=>'二月', '3'=>'游行', '4'=>'四月', '5'=>'可能', '6'=>'六月', '7'=>'七月', '8'=>'八月', '9'=>'九月', '10'=>'十月', '11'=>'十一月', '12'=>'十二月');
		// portuges 
		$month_pr=array('1'=>'janeiro', '2'=>'fevereiro', '3'=>'procissão', '4'=>'abril', '5'=>'pode', '6'=>'Junho', '7'=>'Julho', '8'=>'agosto', '9'=>'setembro', '10'=>'Outubro', '11'=>'novembro', '12'=>'dezembro');
		// french 
		$month_fr=array('1'=>'Janvier', '2'=>'Février', '3'=>'Mars', '4'=>'Avril', '5'=>'Mai', '6'=>'Juin', '7'=>'Juillet', '8'=>'Août', '9'=>'Septembre', '10'=>'Octobre', '11'=>'Novembre', '12'=>'Décembre');
		// spanish 
		$month_sp=array('1'=>'enero', '2'=>'febrero', '3'=>'procesión', '4'=>'abril', '5'=>'mayo', '6'=>'junio', '7'=>'julio', '8'=>'agosto', '9'=>'septiembre', '10'=>'octubre', '11'=>'noviembre', '12'=>'diciembre');
		// japanese
		$month_ja=array('1'=>'1月', '2'=>'2月', '3'=>'行列', '4'=>'4月', '5'=>'かもしれない', '6'=>'六月', '7'=>'7月', '8'=>'8月', '9'=>'9月', '10'=>'10月', '11'=>'11月', '12'=>'12月');
		// polish 
		$month_po=array('1'=>'styczeń', '2'=>'luty', '3'=>'procesja', '4'=>'kwiecień', '5'=>'może', '6'=>'czerwiec', '7'=>'lipiec', '8'=>'sierpień', '9'=>'wrzesień', '10'=>'październik', '11'=>'listopad', '12'=>'grudzień');
		// german 
		$month_gr=array('1'=>'Januar', '2'=>'Februar', '3'=>'Prozession', '4'=>'April', '5'=>'kann', '6'=>'Juni', '7'=>'Juli', '8'=>'August', '9'=>'September', '10'=>'Oktober', '11'=>'November', '12'=>'Dezember');
		// russian 
		$month_crs=array('1'=>'январь', '2'=>'февраль', '3'=>'шествие', '4'=>'апрель', '5'=>'май', '6'=>'июнь', '7'=>'июль', '8'=>'августейший', '9'=>'сентябрь', '10'=>'октября', '11'=>'ноябрь', '12'=>'Декабрь');
		
		
		
		// chinses 
		$days_ch=array('1'=>'星期一', '2'=>'星期二', '3'=>'星期三', '4'=>'星期四', '5'=>'星期五', '6'=>'星期六', '7'=>'星期日');
		// portuges 
		$days_pr=array('1'=>'Segunda-feira', '2'=>'terça', '3'=>'Quarta-feira', '4'=>'Quinta-feira', '5'=>'Sexta-feira', '6'=>'sábado', '7'=>'domingo');
		// french 
		$days_fr=array('1'=>'Lundi', '2'=>'Mardi', '3'=>'Mercredi', '4'=>'Jeudi', '5'=>'Vendredi', '6'=>'samedi', '7'=>'dimanche');
		// spanish 
		$days_sp=array('1'=>'lunes', '2'=>'martes', '3'=>'miércoles', '4'=>'jueves', '5'=>'viernes', '6'=>'sábado', '7'=>'domingo');
		
		// japanese
		$days_ja=array('1'=>'月曜', '2'=>'火曜日', '3'=>'水曜日', '4'=>'木曜日', '5'=>'金曜日', '6'=>'土曜日', '7'=>'日曜日');
		
		// polish 
		$days_pl=array('1'=>'poniedziałek', '2'=>'wtorek', '3'=>'środa', '4'=>'czwartek', '5'=>'piątek', '6'=>'sobota', '7'=>'niedziela');
		// german 
		$days_gr=array('1'=>'Montag', '2'=>'Dienstag', '3'=>'Mittwoch', '4'=>'Donnerstag', '5'=>'Freitag', '6'=>'Samstag', '7'=>'Sonntag');
		// russian 
		$days_rs=array('1'=>'понедельник', '2'=>'вторник', '3'=>'среда', '4'=>'Четверг', '5'=>'пятница', '6'=>'суббота', '7'=>'Воскресенье');	
		
		if($lang=='en'){			
			$systemDateTime=date("l d F Y");							
		}
		//japanese
		elseif($lang=='ja'){																	
			$systemDateTime=$days_ja[date("N")].' '.date('d').' '.$month_ja[intval(date("m"))].' '.date("Y");									
		}
		//chinese
		elseif($lang=='zh'){																	
			$systemDateTime=$days_ch[date("N")].' '.date('d').' '.$month_ch[intval(date("m"))].' '.date("Y");								
		}
		//spanish
		elseif($lang=='es'){																	
			$systemDateTime=$days_sp[date("N")].' '.date('d').' '.$month_sp[intval(date("m"))].' '.date("Y");						
		}
		// german 
		elseif($lang=='de'){																	
			$systemDateTime=$days_gr[date("N")].' '.date('d').' '.$month_gr[intval(date("m"))].' '.date("Y");							
		}
		// russian
		elseif($lang=='ru'){																	
			$systemDateTime=$days_rs[date("N")].' '.date('d').' '.$month_crs[intval(date("m"))].' '.date("Y");									
		}
		//polish
		elseif($lang=='pl'){																	
			$systemDateTime=$days_pl[date("N")].' '.date('d').' '.$month_po[intval(date("m"))].' '.date("Y");								
		}								
		//french
		elseif($lang=='fr'){																	
			$systemDateTime=$days_fr[date("N")].' '.date('d').' '.$month_fr[intval(date("m"))].' '.date("Y");							
		}								
		
		// portuges
		elseif($lang=='pt'){																	
			$systemDateTime=$days_pr[date("N")].' '.date('d').' '.$month_pr[intval(date("m"))].' '.date("Y");				
		}
		//Traditional chinese
		elseif($lang=='zh-TW'){																	
			$systemDateTime=$days_ch[date("N")].' '.date('d').' '.$month_ch[intval(date("m"))].' '.date("Y");								
		}else{
			$systemDateTime=date("l d F Y");
		}
			
		return $systemDateTime;
	}

	/*	@Function Name		: countTables
	*  @description	    : return total table
	*	@Author			    : vineet
	*  @Date               : 8/April/2020
	*****/	
	public function countTables(){
	   $DBName=DB_NAME;
	   //$count_table = $this->returnQueryData("SELECT COUNT(*) as total  FROM information_schema.tables WHERE table_schema='$DBName' ");	
	   $count_table = $this->returnQueryData("SELECT COUNT(*) as total FROM information_schema.tables WHERE table_schema='public'");			
	   return $count_table->current();
   }

		 	/*****
	 *	@Function Name		: getGatewayName
	 *  @description	    : return gateway name by deviceid
     *	@Author			    : vineet
	 *  @Date               : 13/April/2020
	 *****/	
	public function getGatewayName($did){
		$seGwayQry=$this->returnQueryData("SELECT DeviceName FROM DeviceInventory WHERE DID=$did ");
		$deviceName='';
		if($seGwayQry->count()>0){
			$resultRow=$seGwayQry->current();
			$deviceName=$resultRow['DeviceName'];
		}
		return $deviceName;

	}


			 	/*****
	 *	@Function Name		: getExistData
	 *  @description	    : count data  by deviceid
     *	@Author			    : vineet
	 *  @Date               : 13/April/2020
	 *****/	
	public function getExistData($deviceId)
	{
		$session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
		$seGwayQry=$this->returnQueryData("SELECT count(*) as total FROM tbl_user_access A WHERE A.user_id_fk=$user_id AND A.menu_id_fk=51 AND A.group_id_fk='$deviceId' ");
		$resultRow=$seGwayQry->current();
		$ExistData=$resultRow['total'];
		return $ExistData;
	}


				 	/*****
	 *	@Function Name		: wowisString
	 *  @description	    : check string 
     *	@Author			    : vineet
	 *  @Date               : 15/April/2020
	 *****/	
	public function wowisString($str){
		return (strlen($str)>1 && is_string ($str))?1:0;
	}

			 	/*****
	 *	@Function Name		: checkDateFormat
	 *  @description	    : check date fromat
     *	@Author			    : vineet
	 *  @Date               : 15/April/2020
	 *****/	
	public function checkDateFormat($date){
		return (preg_match("/\d{4}\-\d{2}-\d{2}/", $date))?1:0;
	}

		/*****
	 *	@Function Name		: sendMsgToAPIserverForTestMail
	 *  @description	    : send msg to api server
     *	@Author			    : vineet
	 *  @Date               : 29/April/2020
	 *****/	
	function sendMsgToAPIserverForTestMail($logincmd,$actionCmd){
		global $default_server_ip,$default_server_port,$sock;		
		  $result=$this->findServerConnection();
		  if($result!=0){
				  $sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
				sleep(1);
				$sockWrrite=socket_write($sock, $actionCmd,strlen($actionCmd));
				sleep(2);
				if(!$sockWrrite){				
					$data='sendDataError'; 
				}else{
					while(true){
						$buf2 = socket_read($sock,1024);
						$data=	explode("|",$buf2);
						$data=$data[1];
						if(!empty($data)){
							break;
						}else{
							sleep(2);
						}
					}				
				}
			
		  }else{
				$data=0;
			}
			
			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	}

	public function getfileType($imginfo){
		$file_ext = "";
		switch ($imginfo) {
			case "image/gif":
				 $file_ext = "gif";
				break;
			case "image/jpeg":
				 $file_ext = "jpeg";
				break;
			case "image/png":
				 $file_ext = "png";
				break;
			case "image/bmp":
				 $file_ext = "bmp";
				break;
					 
		} 		
		return 	$file_ext;
	} 
	
	public function returnCorrectFunction($ext){
		$function = "";
		switch($ext){
			case "png":
				$function = "imagecreatefrompng"; 
				break;
			case "jpeg":
				$function = "imagecreatefromjpeg"; 
				break;
			case "jpg":
				$function = "imagecreatefromjpeg";  
				break;
			case "gif":
				$function = "imagecreatefromgif"; 
				break;
		}
		return $function;
	}

	function checkTemplateAssigned($tempid){
		if(PRODUCT_TYPE == 'vsm' || PRODUCT_TYPE == 'c8hq'){
		$sqlArr=$this->returnQueryData("SELECT COUNT(*) AS rcount FROM tbl_templates_mapping WHERE template_id=$tempid")->current();
		return $sqlArr['rcount'];
		}
	}

	function getGatewatName($did){
		$seGwayQry=$this->returnQueryData("SELECT DeviceName FROM DeviceInventory WHERE DID=$did");
		$deviceName='';
		if($seGwayQry->count()>0){
			$resultRow=$seGwayQry->current();
			$deviceName=$resultRow['DeviceName'];
		}
		return $deviceName;
	}

	//return model name based on type
	function getModelnameByType($ostype){
		if($ostype==0){
			$model='Collage/Campus Plus';
		}
		if($ostype==1){
			$model='Connect Pro';
		}
		if($ostype==2){
			$model='Campus/VIAware';
		}
		if($ostype==3){
			$model='Via Go';
		}	
		if($ostype==4){
			$model='Connect Plus';
		}
		return $model;
		
	}

	public function changebackgroundOpacity($hex,$opacity){
		list($r, $g, $b) = sscanf($hex, "#%02x%02x%02x");
		return "rgba($r,$g,$b,$opacity)";
	}

	public function getscreenfontsize($fontsize,$screenWidthRatio,$destWidth,$sourceWidth){
		if($destWidth>$sourceWidth){
			return $fontsize;
		}else{
			return $fontsize=number_format(str_replace('px','',$fontsize)*$screenWidthRatio,2).'px';
		}	
	}

	/*****
	 *	@Function Name		: returndateformat
	 *  @description	    : function for return dateformat
     *	@Author			    : Ashu
	 *  @Date               : 11-Feb-2020
	 *****/	
	public function returndateformat($dateformat){
		if($dateformat=='DD/MM/YYYY'){
			$dateformat='DD/MMMM/YYYY';
		}
		if($dateformat=='MM/DD/YYYY'){
			$dateformat='MMMM/DD/YYYY';
		}
		if($dateformat=='DD/MM'){
			$dateformat='DD/MMMM';
		}
		if($dateformat=='MM/DD'){
			$dateformat='MMMM/DD';
		}
		return $dateformat;
	}
	
	public function revertReturndateformat($getdateformat){
		if(trim($getdateformat)==='DD/MMMM/YYYY'){
			$getdateformat='DD/MM/YYYY';
		}	
		if($getdateformat=='MMMM/DD/YYYY'){
			$getdateformat='MM/DD/YYYY';
		}
		if($getdateformat=='DD/MMMM'){
			$getdateformat='DD/MM';
		}
		if($getdateformat=='MMMM/DD'){
			$getdateformat='MM/DD';
		}
		return $getdateformat;
	}

	public function convertImageFormat($originalImage, $outputImage, $quality)
	{
		// jpg, png, gif or bmp?
		$exploded = explode('.',$originalImage);
		$ext = $exploded[count($exploded) - 1]; 
		if (preg_match('/jpg|jpeg/i',$ext))
			$imageTmp=imagecreatefromjpeg($originalImage);
		else if (preg_match('/png/i',$ext))
			$imageTmp=imagecreatefrompng($originalImage);
		else if (preg_match('/gif/i',$ext))
			$imageTmp=imagecreatefromgif($originalImage);    
		else
			return 0;
	
		// quality is a value from 0 (worst) to 100 (best)
		imagejpeg($imageTmp, $outputImage, $quality);
		imagedestroy($imageTmp);
	
		return 1;
	}

	public function convertImage($originalImage, $outputImage, $quality){
		// jpg, png, gif or bmp?
		$exploded = explode('.',$originalImage);
		$ext = $exploded[count($exploded) - 1]; 
		if (preg_match('/jpg|jpeg/i',$ext))
			$imageTmp=imagecreatefromjpeg($originalImage);
		else if (preg_match('/png/i',$ext))
			$imageTmp=imagecreatefrompng($originalImage);
		else if (preg_match('/gif/i',$ext))
			$imageTmp=imagecreatefromgif($originalImage);    
		else
			return 0;
	
		// quality is a value from 0 (worst) to 100 (best)
		imagejpeg($imageTmp, $outputImage, $quality);
		imagedestroy($imageTmp);
	
		return 1;
	}

	public function convertImagePNG($originalImage, $outputImage, $quality){
		// jpg, png, gif or bmp?
		$exploded = explode('.',$originalImage);
		$ext = $exploded[count($exploded) - 1]; 
	
		if (preg_match('/jpg|jpeg/i',$ext))
			$imageTmp=imagecreatefromjpeg($originalImage);
		else if (preg_match('/png/i',$ext))
			$imageTmp=imagecreatefrompng($originalImage);
		else if (preg_match('/gif/i',$ext))
			$imageTmp=imagecreatefromgif($originalImage);
		else if (preg_match('/bmp/i',$ext))
			$imageTmp=imagecreatefrombmp($originalImage);
		else
			return 0;
	
		imagepng($imageTmp, $outputImage);
		imagedestroy($imageTmp);
		return 1;
	}

	public function getUniqueName($custTempName){
		$lastWallSqlArr=$this->returnQueryData("SELECT template_name FROM tbl_templates WHERE template_name='".$custTempName."'");
		if(count($lastWallSqlArr)>0){
			foreach($lastWallSqlArr as $lastWallSqlData){
				$wallpaperName=$lastWallSqlData['template_name'];
				$wallCount = (int) filter_var($wallpaperName, FILTER_SANITIZE_NUMBER_INT);
				$fileStringName=str_replace($wallCount,'',$wallpaperName);
				$wallCount+=1;
				$custTempName=$fileStringName.$wallCount;
				$custTempName=$this->getUniqueName($custTempName);	
			}
		}
	}

	public function create_thumb($pathToImage, $pathToThumb, $file_ext, $thumbWidth)
	{
		if(strtolower($file_ext)=='png'){
			$img = imagecreatefrompng($pathToImage);
		}else if(strtolower($file_ext)=='gif'){
			$img = imagecreatefromgif($pathToImage);
		}else{
			$img = imagecreatefromjpeg($pathToImage);
		}
		$width = imagesx($img);
		$height = imagesy($img);
		$new_width = $thumbWidth;
		$new_height = 80;//floor($height * ($thumbWidth / $width));
		$tmp_img = imagecreatetruecolor($new_width, $new_height);
		imagecopyresampled($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
		imagejpeg($tmp_img, $pathToThumb);
		imagedestroy($tmp_img);
		imagedestroy($img);
	}
	
	function getVIASettingsNextTemplateName(){
		$nextWallSqlArr=$this->returnQueryData("SELECT template_name FROM tbl_via_settings_templates WHERE template_name ILIKE 'template%' ORDER BY id DESC LIMIT 1");
		if(count($nextWallSqlArr)>0){
			foreach($nextWallSqlArr as $nextWallSqlData){
				$wallpaperArr = explode('_', $nextWallSqlData['template_name']);
				$wallpaperName = $wallpaperArr[0];
				$wallCount = (int) filter_var($wallpaperName, FILTER_SANITIZE_NUMBER_INT);
				$fileStringName=str_replace($wallCount,'',$wallpaperName);
				$wallCount+=1;
				$fileWithoutExt=$fileStringName.$wallCount;
				$checkTemplateSql=$this->returnQueryData("SELECT template_name FROM tbl_via_settings_templates WHERE template_name = '".$fileWithoutExt."'");
				while($checkTemplateSql->count()>0){
					$wallCount+=1;
					$fileWithoutExt=$fileStringName.$wallCount;
					$checkTemplateSql=$this->returnQueryData("SELECT template_name FROM tbl_via_settings_templates WHERE template_name = '".$fileWithoutExt."'");
				}
			}
		
		}else{
			$fileWithoutExt='template1';
		}
		return $fileWithoutExt;  
	}
	
	/*****
	 *	@Function Name		: getFileContents
	 *  @description	    : function for return file contents
     *	@Author			    : Ashu
	 *  @Date               : 17-July-2020
	 *****/		 
	public function getFileContents($path){
		$content=file_get_contents($path);
		return $content;
	}

	public function getCopiedName($originalName){
		if (strpos($originalName, '_copy') !== false) {
		    $matches = array();
	    	preg_match('#(\d+)$#', $originalName, $matches);
	    	$match = ($matches[1]=='')?'':(int)$matches[1];
		    $fileStringName = rtrim($originalName,$matches[1]);
			$nextWallSqlArr = $this->returnQueryData("SELECT template_name FROM tbl_via_settings_templates WHERE template_name ILIKE '".$originalName."%' ORDER BY id");
			if($nextWallSqlArr->count() > 0){
				$value = $nextWallSqlArr->current();
    			$number = ($match=='')?1:$match+1;
				$copiedName = $fileStringName.$number;
				$copiedName = $this->getCopiedName($copiedName);
				
			}else{
				$copiedName = $originalName;
			}
		}else{
			$copiedName = $originalName.'_copy';
			$copiedName = $this->getCopiedName($copiedName);
		}
		return $copiedName;
	}

	/*****
	 *	@Function Name		: readJsonFile
	 *  @description	    : Passing json file path and return json data
     *	@Author			    : Ashu
	 *  @Date               : 8/April/2020
	 *****/	
	public function readJsonFile($jsonfile){
		//showing changeel based on network.json
		if(file_exists($jsonfile)){
			$strJson=file_get_contents($jsonfile);
			$arrayJson = (array)json_decode($strJson);
			return $arrayJson;
		}else{
			return 'filenotexist';
		}	
	}
	
	/*****
	 *	@Function Name		: checkLicenseInfo
	 *  @description	    : for checking dss license info
     *	@Author			    : Ashu
	 *  @Date               : 13/April/2020
	 *****/	

	//added by ashu on 22 Nov 2017 for checking dss license info 
	public function checkLicenseInfo(){
			$licened='notfound';	
			//$authSqlArr=$this->returnQueryData("SELECT id,filename,AES_DECRYPT(datetime,'".POLL_ENCRYPTION_KEY."') as datetime FROM dss_info ORDER BY id DESC limit 1");	
			$authSqlArr=$this->returnQueryData("SELECT id,filename,convert_from(decrypt(datetime,'".POLL_ENCRYPTION_KEY."','aes'),'utf-8') as datetime FROM dss_info ORDER BY id DESC limit 1");
			if(count($authSqlArr)>0){
				$authSqlArr = $authSqlArr->current();		
				$getAuthFile=$authSqlArr['filename'];
				$getAuthDateTime=$authSqlArr['datetime'];
				if($getAuthDateTime!='FULL'){	
					if($getAuthDateTime < time()){
						$licened='expired';
					}else{
						$licened='FULL';
					}							
				}else{
					$licened='FULL';
				}	
			}
		return $licened;
	}

	/*****
	 *	@Function Name		: allowMiracastAndWifi
	 *  @description	    : checking supported wifi/ap/client
     *	@Author			    : Ashu
	 *  @Date               : 13/April/2020
	 *****/	
	public function allowMiracastAndWifi($jsonfile){	
		$arrayJson=$this->readJsonFile($jsonfile);
		//echo "<pre>";print_r($arrayJson);die;
		$wifiArray=$arrayJson['Wifi'];	
		$wifiInterface='allowwifi';
		if(count($wifiArray)>1){			
				// Miracast + AP or or miracast + apclient
				$wifiInterface='allowmiracast';
			
		}
		return $wifiInterface;
	}
	/*****
	 *	@Function Name		: getScreenStatus
	 *  @description	    : get recording screen status
     *	@Author			    : vineet
	 *  @Date               : 08-sep-2020
	 *****/	
	public function getScreenStatus($key){
		$row = $this->returnQueryData("select screen as screen from recordingchild where filename='$key' ");			
		return $row->current();
	}

	public function getModelFromJson($osType){
		$modelJson = DEST_PATH.'model.json';
		$modelObj = json_decode(file_get_contents($modelJson));
		if(property_exists($modelObj, $osType)){
			$modelType = $modelObj->$osType;
			if(PRODUCT_TYPE == 'c8hq'){
				if($modelType->modelvalue == 4){
					$modelType->model = 'c8lite';
					$modelType->modelshow = 'Collab8 Lite';
					$modelType->updatefirmwaretag = 'c8lite';
				}
				if($modelType->modelvalue == 7){
					$modelType->model = 'collab8';
					$modelType->modelshow = 'Collab8';
					$modelType->updatefirmwaretag = 'collab8';
				}
				if($modelType->modelvalue == 9){
					$modelType->model = 'collab82';
					$modelType->modelshow = 'Collab8 2';
					$modelType->updatefirmwaretag = 'collab8';
				}
			}
			return $modelType;
		}
	}
	
	public function getViaSettingTemplate(){
		if(file_exists(DEST_PATH."model.json")){
			$jsonStr = file_get_contents(DEST_PATH."model.json");
			$json_arr=json_decode($jsonStr,true);
			$modelLike = $json_arr['modellike'];
			if(PRODUCT_TYPE=='collab8'){
				if($modelLike==0){
					$sourceFile = DEST_PATH.'collab8.json';
				}
				if($modelLike==4){
					$sourceFile = DEST_PATH.'c8lite.json';
				}
			}
			if(PRODUCT_TYPE=='via'){
				if($modelLike==0){
					$sourceFile = DEST_PATH.'collage.json';
				}
				if($modelLike==1){
					$sourceFile = DEST_PATH.'connectpro.json';
				}
				if($modelLike==2){
					$sourceFile = DEST_PATH.'campus.json';
				}
				if($modelLike==3){
					$sourceFile = DEST_PATH.'viago.json';
				}
				if($modelLike==4){
					$sourceFile = DEST_PATH.'connectplus.json';
				}
			}
			return $sourceFile;
		}else{
			return 'nojsonfile';
		}
	}

	public function getDecryptJsonFileData($filepath){
		if(file_exists($filepath)){
			$response=file_get_contents($filepath);
			//decrypt json				
			$decryptResponse=$this->desDecrypt($response,POLL_ENCRYPTION_KEY);	
			if($decryptResponse!=''){
				$jsonArray=json_decode($decryptResponse, true);
				return $jsonArray;
			}		
				
		}
	}

	//get total no of activated devices on vsm
	public function getActivateDevicesLicenseData(){
		$getActivateLicenseQryData=$this->returnQueryData("SELECT SUM(no_of_devices) as no_of_devices FROM license_master WHERE license_expiry_date>=CURRENT_DATE()");				
		foreach($getActivateLicenseQryData as $activateLicenseArr) {
			$check_gwayCounterFile = $activateLicenseArr['no_of_devices'];
		}
		$check_gwayCounterFile=($check_gwayCounterFile>0)?$check_gwayCounterFile:0;
		return $check_gwayCounterFile;	
	}
	
	//get total no of activated devices on vsm
	public function upgradeViaActiveJson($upgradeTag,$tagvalue){
		$appObj = new ApplicationController();
		//get active template
		$getActivateTemplateQryData=$this->returnQueryData("SELECT template_path FROM tbl_via_settings_templates WHERE status=1");				
		foreach($getActivateTemplateQryData as $activateTempArr) {
			$activeTemplate = UPLOAD_DIR_ZEND.$activateTempArr['template_path'];
		}
		
		$defailt_settings_json = DEST_PATH.'via_settings.json';	
		//echo UPLOAD_DIR_ZEND;	
		if(file_exists($activeTemplate)){
			$response = file_get_contents($activeTemplate);
			//decrypt json
			$decryptResponse=$appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);			
			$jsonArray=json_decode($decryptResponse, true);
			//$jsonArray['VIA_CONFIG_TEMPLATE']['via_details']['hostname']=$tagvalue;
			$jsonArray['VIA_CONFIG_TEMPLATE']['via_details'][$upgradeTag]=$tagvalue;			
			$encodedData = json_encode($jsonArray,JSON_FORCE_OBJECT);
			//encrypt json data		
			$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRYPTION_KEY);			
			file_put_contents($activeTemplate, $encryptedJson);	
			copy($activeTemplate, $defailt_settings_json);	
			return 'success';
		}else{
			return 'No json file found';
		}
	
	}
	// we will get model_type based on via/vsm/kds and using it for screen editor/settings
	public function get_model_type(){	
		$modelArray=array(0=>"via",1=>'kds');
		if(in_array(PRODUCT,$modelArray)){
			return array_search (PRODUCT, $modelArray);
		}
	}


	public function getUniqueRandomNumber($length) {
		return $uniqueId = substr(md5(microtime()), 0, $length);
	}
	
	//checking DNS name
	public function check_dns_name($dnsname){
		$str='';
		if(checkdnsrr($dnsname,"MX")) {
		  $str="success";
		} else {
		  $str="error";
		}
		return $str;
	}
	 /*****
	 *	@Function Name: webserviceToValidateProxy
	 *  @description  : validate proxy server setting
	 *	@Author		  : vineet
	 *  @Date         : 24-feb-2021
	 *****/
	public function webserviceToValidateProxy($serverName,$port,$userName,$pass,$url){	
		$url=$url;
		$proxyipadd = $serverName; 
		$proxyport = $port; 
		$proxyuserid = $userName; 
		$proxypass =$pass; 
		// Initialize curl  
		$ci = curl_init($url); 
		// Set curl attributes 
		$certificate_location = BASE_PATH.'/config/cacertupdates.crt';
		curl_setopt($ci, CURLOPT_TIMEOUT, 10);
		curl_setopt($ci, CURLOPT_RETURNTRANSFER, true); 
		curl_setopt($ci, CURLOPT_SSL_VERIFYHOST, $certificate_location);
		curl_setopt($ci, CURLOPT_SSL_VERIFYPEER, $certificate_location); 
		curl_setopt($ci, CURLOPT_HTTPPROXYTUNNEL , 1); 
		curl_setopt($ci, CURLOPT_PROXY, $proxyipadd); 
		curl_setopt($ci, CURLOPT_PROXYPORT, $proxyport); 
		curl_setopt($ci, CURLOPT_PROXYUSERPWD,"$proxyuserid:$proxypass");
		curl_setopt($ci, CURLOPT_FOLLOWLOCATION, true);
		$result = curl_exec($ci); 
		 if(!curl_errno($ci)){ 
		  $response = curl_getinfo($ci,CURLINFO_HTTP_CODE);
		 }else{
			$response= curl_error($ci);
		 }
		curl_close($ci); 
		return $response;
	} 
	
	//get audio input/output device
	public function getAudioInOutDevice($feature){
		if($feature=='input'){
			$getData=trim(file_get_contents(DEST_PATH.'AudioInputDevice.txt'));
			if(strtolower($getData)=='usb'){
				$getData=trim(file_get_contents(DEST_PATH.'DefaultUSBInput.txt'));
			}
		}
		if($feature=='output'){
			$getData=trim(file_get_contents(DEST_PATH.'AudioOutputDevice.txt'));
			if(strtolower($getData)=='usb'){
				$getData=trim(file_get_contents(DEST_PATH.'DefaultUSBOutput.txt'));
			}
		}
		return $getData;
	}


	 /*****
	 *	@Function Name: getActionTaken
	 *  @description  : get action by passing the number
	 *	@Author		  : vineet
	 *  @Date         : 12-march-2021
	 *****/
	public function getActionTaken($key){
		$action_array=array(
			'1'=> 'Login',
			'2'=> 'Logout',
			'3'=> 'Create',
			'4'=> 'Update',
			'5'=> 'Delete',
			'6'=> 'Upload',
			'7'=> 'Activate'
		);
		return $action_array[$key];
	}

	 /*****
	 *	@Function Name: getWidgetName
	 *  @description  : get module name
	 *	@Author		  : vineet
	 *  @Date         : 12-march-2021
	 *****/
	public function getWidgetName($key){
		$module_array=array(
			'1'=>'User',
			'2'=>'Location',
			'3'=>'Devices',
			'4'=>'Register Devices',
			'5'=>'Calendar Account',
			'6'=>'Manage Configurations',
			'7'=>'Screen Editior',
			'8'=>'Wallpaper',
			'9'=>'Modify VSM Home page',
			'10'=>'License Deatails',
			'11'=>'Settings',
			'12'=>'Upload Firmware',
			'13'=>'Scheduled Updates',
			'14'=>'Alert List',
			'15'=>'SMTP Configuration',
			'16'=>'Instant Alert',
			'17'=>'Recording',
			'18'=>'Manage Content',
			'19'=>'Template Manager',
			'20'=>'Campaign Editior',
			'21'=>'Schedule Campaign',
			'22'=>'DSS Management'
		);
        if ($key=='Login'|| $key=='Logout') {
            $module=$key;
        }else{
			$module= $module_array[$key];
		}
		return $module;
	}

	 /*****
	 *	@Function Name: ActivityLogVSM
	 *  @description  : insert log in vsm
	 *	@Author		  : vineet
	 *  @Date         : 12-march-2021
	 *****/
	public function ActivityLogVSM($actionTaken,$remarks,$moduleName){
		$actionTaken=$this->getActionTaken($actionTaken);
		$moduleName=$this->getWidgetName($moduleName);
		$session = new Container('userinfo');
		$connection=$this->getConnection();			
		//$connection->execute("INSERT INTO ActivityLogMaster SET (userid)='".$session->offsetGet('LoginName')."', ActionTaken='".$actionTaken."', ActivityDate='".date("Y-m-d H:i:s")."',hostname='".HOSTNAME."',hostname='".$remarks."',moduleName='".$moduleName."'");
		$connection->execute("INSERT INTO ActivityLogMaster (UserID,ActionTaken,ActivityDate,hostname,remarks,moduleName) VALUES ('".$session->offsetGet('LoginName')."','".$actionTaken."',NOW(),'".HOSTNAME."','".$remarks."','".$moduleName."')");	
		$connection->disconnect();
	}
	
	//check internet connection
	function checkInternet(){
		if (fopen("https://cb.wowvision.com", "r") ){
		  $is_conn = 1;
		} 
		else{
		  $is_conn = 0;
		} 	
		return $is_conn;
	}	

	//create CRSF Token
	function create_crsftoken(){
		$crsf_token=md5(uniqid(rand(),true));
		return $crsf_token;
	}
		
	/*	Created by ashu on 21/12/2022 */
	/*	Getting Network SSID, Mode and Host */		
	public function getNetworkBasicInfoAction(){
			$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$ipInfo_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetNetworkInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$returnResult = $this->homeNetworkInfo($logincmd, $ipInfo_cmd);					
			$returnResultArray = (array)json_decode($returnResult);
			$networkData=array();
			foreach($returnResultArray as $returnKey=>$returnVal){
				$returnValArray=(array)$returnVal;		
				if($returnKey=='LAN1'){	
					$networkData['Lan1_Host']=$returnValArray['Host'];
				}
				// added by niraj
				if(strtolower($returnKey)=='wifi'){
					$networkData['wifi1_Host']=$returnValArray['Host'];
				}
				// end added by niraj	
				if(strtolower($returnKey)=='wifiinfo'){
					$networkData['mode']=$returnValArray['Mode'];
					$networkData['SSID']=$returnValArray['SSID'];
				}else{
					$networkData['mode']=$returnValArray[''];
				}
				
			}//end of foreach
			return $networkData;		
		}
	

	/*
	Desc: check wifiquickconnect.txt is exist or not if exist return 1 otherwise 0 
	By: Niraj Gautam
	Date: 12/05/2023
	*/
	function checkQuickWifiConnectStatus(){
		return file_exists(LIN_WIFI_PATH.FILE_WIFI_QUICK_CONNECT)?1:0;
	}


	/*
	Desc: this function return roomname with its type according to sessionNetworkData data 
	By: Niraj Gautam
	Date: 12/05/2023
	*/
	function getRoomNameWithType($sessionNetworkData){
		$arrValue = array("roomname" => "", "via_roomname_type" => 0);
		if(strtolower($sessionNetworkData['mode'])=="wd"){
			$arrValue['roomname'] =	file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?file_get_contents(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):file_get_contents(LIN_WIFI_PATH.FILE_WD_SSID);
			$arrValue['via_roomname_type'] = file_exists(LIN_WIFI_PATH.FILE_WD_ONLY) ? 3 : 1;
		}else if(strtolower($sessionNetworkData['mode'])=="ap"){
			$wifiQuickConnectEnable = $this->checkQuickWifiConnectStatus(); // check wifi quick connect is enable 
			if($wifiQuickConnectEnable == 1){
				$arrValue['roomname'] =	file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?file_get_contents(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):"VIA_".trim($sessionNetworkData['SSID']);
				$arrValue['via_roomname_type'] = 3;
			}else{
				$arrValue['roomname'] = file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?file_get_contents(DEST_PATH.READFILE_ROOMNAMEVALUESHOW):trim($sessionNetworkData['SSID']);
				$arrValue['via_roomname_type'] = 1;
			}
		}else if(file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)){
			$arrValue['roomname'] = file_get_contents(DEST_PATH.READFILE_ROOMNAMEVALUESHOW);
			$arrValue['via_roomname_type'] = 1;
		}else{
			$arrValue['roomname'] = !empty($sessionNetworkData['Lan1_Host'])?$sessionNetworkData['Lan1_Host']:$sessionNetworkData['wifi1_Host'];
			$arrValue['via_roomname_type'] = 1;
		}
		return $arrValue;
	}

	function tableCount(){
		$wpgTableCount = 0;
		$con = $this->getConnection();
		if($con->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_table_count'")->count()==1){
	        $chkTable=$con->execute("SELECT table_count FROM tbl_table_count")->current();
	        $wpgTableCount = (isset($chkTable['table_count']) && $chkTable['table_count'] > 0) ? $chkTable['table_count'] : 0;
	    }
	    return $wpgTableCount;
	}


	function addFileExtensionIfBlank(){
		$session 	=	new Container('userinfo');
		$loginName 	=	$session->offsetGet('LoginName');
		$fileSharingJsonFile	=	'auth_fileformat_'.$loginName.'.txt';
		$authFileArray = [["ext_name" => "All", "status" => "1"],["ext_name" => "M4v", "status" => "1"],["ext_name" => "avi", "status" => "1"],["ext_name" => "bmp", "status" => "1"],["ext_name" => "dbt", "status" => "1"],["ext_name" => "divx", "status" => "1"],["ext_name" => "doc", "status" => "1"],["ext_name" => "docx", "status" => "1"],["ext_name" => "dot", "status" => "1"],["ext_name" => "ett", "status" => "1"],["ext_name" => "flv", "status" => "1"],["ext_name" => "gif", "status" => "1"],["ext_name" => "html", "status" => "1"],["ext_name" => "jpeg", "status" => "1"],["ext_name" => "jpg", "status" => "1"],["ext_name" => "m4a", "status" => "1"],["ext_name" => "mht", "status" => "1"],["ext_name" => "mkv", "status" => "1"],["ext_name" => "mov", "status" => "1"],["ext_name" => "mp3", "status" => "1"],["ext_name" => "mp4", "status" => "1"],["ext_name" => "mpeg", "status" => "1"],["ext_name" => "mpg", "status" => "1"],["ext_name" => "pdf", "status" => "1"],["ext_name" => "png", "status" => "1"],["ext_name" => "ppt", "status" => "1"],["ext_name" => "pptx", "status" => "1"],["ext_name" => "prs", "status" => "1"],["ext_name" => "rm", "status" => "1"],["ext_name" => "rmv", "status" => "1"],["ext_name" => "rmvb", "status" => "1"],["ext_name" => "rtf", "status" => "1"],["ext_name" => "svg", "status" => "1"],["ext_name" => "tiff", "status" => "1"],["ext_name" => "txt", "status" => "1"],["ext_name" => "vob", "status" => "1"],["ext_name" => "wav", "status" => "1"],["ext_name" => "wma", "status" => "1"],["ext_name" => "wmv", "status" => "1"],["ext_name" => "wps", "status" => "1"],["ext_name" => "wpt", "status" => "1"],["ext_name" => "xls", "status" => "1"],["ext_name" => "xlt", "status" => "1"],["ext_name" => "xml", "status" => "1"]];
		file_put_contents(UPLOAD_PATH_INTERNAL.$fileSharingJsonFile, json_encode($authFileArray));
		return $authFileArray;
	}


	//Check device version and VSM version
	function checkGatewayAndVSMVerion($groups){
		$isGatewayHigerfromVSM = 0;
		if(!empty($groups)){
			//getting VSM version
			$readVsmVersion = file_get_contents(SECOND_DEST_PATH.VSM_VERSION_FILE);
			$vsmVersionArray = explode('.',$readVsmVersion);
			$vsmVersion = trim($vsmVersionArray[0]).'.'.trim($vsmVersionArray[1]);
			
			//check vsm version and gateway version from selected groups
			$deviceVerions = $this->returnQueryData("SELECT DISTINCT Version from DeviceInventory WHERE DeviceGroupID IN($groups) AND Version<>-1 AND Version<>''");
			
			foreach($deviceVerions as $versionData){
				//getting gateway version
				$gatewayVersionArray = explode('.',$versionData["Version"]);
				$gatewayVersion = trim($gatewayVersionArray[0]).'.'.trim($gatewayVersionArray[1]);				
				if($vsmVersion < $gatewayVersion){
					$isGatewayHigerfromVSM = 1;
					break;
				}
			}
		}
		return $isGatewayHigerfromVSM;		
	}


	/*****
	 *	@Function Name: checkUserAccess
	 *  @description  : check for user access level
	 *	@Author		  : niraj gautam
	 *  @Date         : 26feb, 2024
	 *****/
	function checkUserAccess(){
		// dss user: 41, moderator user: 4, participants user: 9
		$session = new Container('userinfo');
		$sessionUserId = $session->offsetGet('usrid');
		$sessionUtype = $session->offsetGet('utype');

		if(!empty($sessionUtype) && !empty($sessionUserId)){
			if($sessionUtype == 1){
				//add checks for administrator user
			}else if($sessionUtype == 41 || $sessionUtype == 4 || $sessionUtype == 9){
				
				//$requestUrlPath = str_replace("/VIA-VSM", '', $_SERVER['REQUEST_URI']); //for development
				$requestUrlPath = $_SERVER['REQUEST_URI']; //for production
				$currURLArr = explode("/", $requestUrlPath);
				$currURLArr = array_values(array_filter($currURLArr));
				$controllerName = isset($currURLArr[0]) ? strtok($currURLArr[0], '?') : '';

				if(!empty($controllerName)){

					$checkDssPermission = $this->returnQueryData("SELECT * from AppUserGroups where AppUserID = ".$sessionUserId." and AppGroupID = 41")->count();

					$allowedRequestURLArr = ["/manageconfigurations/getAudioInputOutput", "/manageconfigurations/advancedConfiguration", "/viauser/changePassword", "/viauser/changePasswordFile", "/viauser/serverActivity"];
					
					if($checkDssPermission > 0){
						// this is for dss user and moderator/participant (if has dss permision)
						$allowedControllerArr = ["viaIndex", "index", "home", "getrecording", "dsscontent", "dsstemplate", "dsscampaign", "dssschedule", "dssfont"];
					}else{
						//for if don't have dss permission
						$allowedControllerArr = ["viaIndex", "index", "home", "getrecording"];
					}

					//check for allowed URL
					$isValidReuqestURL = 0;
					if(in_array($requestUrlPath, $allowedRequestURLArr)){
						$isValidReuqestURL = 1;
					}

					//check for allowed controller
					$isValidAccessController = 0;
					if(in_array($controllerName, $allowedControllerArr)){
						$isValidAccessController = 1;
					}

					//return error if any case mismathed
					if($isValidReuqestURL == 0 && $isValidAccessController == 0){
						die("Invalid request");
					}
				}
			}
		}
	}


	function getModelNameWithoutSpace($modelshow){

		if($modelshow == "Connect 2"){
			return "Connect2";
		}else if($modelshow == "Connect 3"){
			return "Connect3";
		}else if($modelshow == "VIA GO 2"){
			return  "VIA GO2";
		}else if($modelshow == "VIA GO 3"){
			return  "VIA GO3";
		}else{
			return $modelshow;
		}
	}



	/*****
	 *	@Function Name		: apiServerConnection
	 *  @description	    : returning data from API Server
     *	@Author			    : Niraj Gautam
	 *  @Date               : 21-Oct-2024
	 *****/	
	function apiServerConnection($timeout = 5){
		$sock= @socket_create(AF_INET, SOCK_STREAM,  SOL_TCP);
		socket_set_option($sock,SOL_SOCKET, SO_RCVTIMEO, array("sec"=>$timeout, "usec"=>0));
		$apiServerIP = '127.0.0.1';
		$conn = @socket_connect($sock, $apiServerIP, DEFAULT_SERVER_PORT);			
		if($conn){
			return $sock;
		}else{
			return 0;
		}	
	}


	public function getDataFromAPIServer($logincmd,$ipInfo_cmd){
		
		  $result=$this->apiServerConnection();
		  if($result!=0){
				$sock=$result;
				$sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
				sleep(1);
				//$sockWrrite=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
				if(!$sockWrrite){				
					$data='sendDataError';
				}else{
					//echo 'Write Successfully';
					// old value is 2048 means bytes (2kb) but now increased to 20480 bytes (20kb)
					$buf = socket_read($sock,20480); 
					if(!$buf){	
						$data='receiveDataErr'; 
					}else{					
						//if(trim($buf)=='Error12'){
						if(trim(strstr($buf,'Error13'))){						
							$data='loginerror'; 
						}else{					
							$data=$buf;
							$sockWrrite1=socket_write($sock, $ipInfo_cmd,strlen($ipInfo_cmd));
							$buf2 = socket_read($sock,20480);
							$data=	$buf2;
							$err_code = socket_last_error($sock);
							//Check if reading timed out
							if ($data === false) {
							    $err_code = socket_last_error($sock);
							    if($err_code === SOCKET_EAGAIN || $err_code === SOCKET_EWOULDBLOCK) {
							        $data = "timeoutError";
							    }
							}
							//end Check if reading timed out							
						}
					}
					
				}
			
		  }else{			
				$data=0;
			}

			if(!is_null($sock)){ @socket_close($sock); }
			return $data;
	}

	public function checkURLRequestsIfSessionTimeout($string){
		if(!empty($string)){
			//for local test
			$keywords = ["/viauser/getUserdata", "/viauser/checkUserAvailability"];
			if (in_array($string, $keywords)){
				echo "sessionTimeOut"; die;
			}
		}
	}

}