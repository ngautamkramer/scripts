<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\LoginForm;
use Zend\Session\Container;
use Webapp\Controller\ApplicationController;
use Zend\View\Model\JsonModel;

class ViaIndexController extends AbstractActionController {

	public function generateAction() {
		$response = $this->getResponse();
		$response->getHeaders()->addHeaderLine('Content-Type', "image/png");
		$id = $this->params('id', false);
		if($id) {
			$image = './data/captcha/' . $id;
			if(file_exists($image)!== false) {
				$imagegetcontent = @ file_get_contents($image);
				$response->setStatusCode(200);
				$response->setContent($imagegetcontent);
				if(file_exists($image)== true) {
					unlink($image);
				}
			}
		}
		return $response;
	}

	  public function productAction(){
	 	if(PRODUCT=="via" || PRODUCT=="kds"){
	  		return $this->redirect()->toRoute('viaIndex', ['action'=>'index']);
	 	}
	  	if(PRODUCT == 'vsm'){
			return $this->redirect()->toRoute('index', ['action' => 'index']);
		}
	  }

	public function indexAction() {
		if(PRODUCT == 'vsm'){
			return $this->redirect()->toRoute('index', ['action' => 'index']);
		}
		//code for showing set default language
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('lang');
		$appObj = new ApplicationController();
		$connection = $appObj->getConnection();
		//This dbrestoreflag flag handling the case when we truncate the table then this flag is using to restrict redirect to index page. bcoz in that case table count is equals to db count
		$dbrestoreflag=1;				
		
   /* ***************** Checking users default tables i.e. appuserlist,appusergroups and appgroups has no data then call this script *****/     
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='appuserlist'")->count()==1){
			$chkUsername=$connection->execute('SELECT apploginname FROM appuserlist where apploginname=\'su\'')->current();
		}
		
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='appusergroups'")->count()==1){
			$chk_tbl_AppUserGroups=$connection->execute('SELECT * FROM appusergroups where appuserid=1');
			$count_tbl_AppUserGroups=count($chk_tbl_AppUserGroups);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='appgroups'")->count()==1){
			$chk_tbl_AppGroups=$connection->execute("SELECT * FROM appgroups");
			$count_tbl_AppGroups=count($chk_tbl_AppGroups);
		}			
		
	 /* ***************** Checking Gateway/Client/Mobile features tables has no data then call this script *****/ 
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_gateway_features'")->count()==1){
			$chk_tbl_gateway_features=$connection->execute("SELECT * FROM tbl_gateway_features");
			$count_tbl_gateway_features=count($chk_tbl_gateway_features);
		}
		
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_clients_features'")->count()==1){
			$chk_tbl_clients_features=$connection->execute("SELECT * FROM tbl_clients_features");
			$count_tbl_clients_features=count($chk_tbl_clients_features);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_mobile_features'")->count()==1){
			$chk_tbl_mobile_features=$connection->execute("SELECT * FROM tbl_mobile_features");
			$count_tbl_mobile_features=count($chk_tbl_mobile_features);
		}		
	/* ***************** Checking tbl_menus and tbl_timezones and tbl_auth_fileformat tables has no data then call this script *****/	
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_timezones'")->count()==1){
			$chk_tbl_timezones=$connection->execute("SELECT * FROM tbl_timezones");
			$count_tbl_timezones=count($chk_tbl_timezones);
		}		
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_auth_fileformat'")->count()==1){
			$chk_tbl_Auth_FileFormat=$connection->execute("SELECT * FROM tbl_auth_fileformat");
			$count_tbl_Auth_FileFormat=count($chk_tbl_Auth_FileFormat);
		}		
	/* ***************** Checking tbl_menus and tbl_modules tables has no data then call this script *****/ 	
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_menus'")->count()==1){
			$chk_tbl_menus=$connection->execute("SELECT * FROM tbl_menus");
			$count_tbl_menus=count($chk_tbl_menus);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_modules'")->count()==1){
			$chk_tbl_modules=$connection->execute("SELECT * FROM tbl_modules");
			$count_tbl_modules=count($chk_tbl_modules);
		}
	/* ***************** Checking DSS default tables has no data then call this script *****/ 
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='dss_font'")->count()==1){
			$chk_dss_font=$connection->execute("SELECT * FROM dss_font");
			$count_dss_font=count($chk_dss_font);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='mediacomponentmaster'")->count()==1){
			$chk_MediaComponentMaster=$connection->execute("SELECT * FROM mediacomponentmaster");
			$count_MediaComponentMaster=count($chk_MediaComponentMaster);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='mediatypemaster'")->count()==1){
			$chk_MediaTypeMaster=$connection->execute("SELECT * FROM mediatypemaster");
			$count_MediaTypeMaster=count($chk_MediaTypeMaster);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='screentemplatemaster'")->count()==1){
			$chk_ScreenTemplateMaster=$connection->execute("SELECT * FROM screentemplatemaster");
			$count_ScreenTemplateMaster=count($chk_ScreenTemplateMaster);
		}
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='screentemplatedetails'")->count()==1){
			$chk_ScreenTemplateDetails=$connection->execute("SELECT * FROM screentemplatedetails");
			$count_ScreenTemplateDetails=count($chk_ScreenTemplateDetails);
		}
	/* ***************** Checking Calendar default table has no data then call this script *****/ 	
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_exchange_version'")->count()==1){
			$chk_tbl_exchange_version=$connection->execute("SELECT * FROM tbl_exchange_version");
			$count_tbl_exchange_version=count($chk_tbl_exchange_version);
		}
		

	/* ***************** Checking tbl_via_settings_templates default table has no data then call this script *****/ 	
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_via_settings_templates'")->count()==1){
			$chk_tbl_via_settings_templates=$connection->execute("SELECT * FROM tbl_via_settings_templates");
			$count_tbl_via_settings_templates=count($chk_tbl_via_settings_templates);
		}
	/* ***************** Checking tbl_templates default table has no data then call this script *****/ 	
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='tbl_templates'")->count()==1){
			$chk_tbl_templates=$connection->execute("SELECT * FROM tbl_templates");
			$count_tbl_templates=count($chk_tbl_templates);
		}
		
	
	/* ***************** Checking thirdpartyapps default table has no data then call this script *****/		
		if($connection->execute("SELECT 1 FROM pg_tables WHERE tablename='thirdpartyapps'")->count()==1){
			$modellike = $appObj->getModelNameByParam('modellike');
			if($modellike == 3){
				// for go2 GW
				$count_thirdpartyapps = 1;
			}else{
				$chk_thirdpartyapps=$connection->execute("SELECT * FROM thirdpartyapps");
				$count_thirdpartyapps=count($chk_thirdpartyapps);
			}
		}

		//users default tables i.e. appuserlist,appusergroups and appgroups has no data then call this script
		//die($chkUsername['apploginname'].' '.$count_tbl_AppUserGroups);
		if($chkUsername['apploginname']=="" || $chkUsername['apploginname'] !="su" || $count_tbl_AppUserGroups==0 || $count_tbl_AppGroups==0 || $count_tbl_gateway_features==0 || $count_tbl_clients_features==0 || $count_tbl_mobile_features==0 || $count_tbl_timezones==0 || $count_tbl_Auth_FileFormat==0 || $count_tbl_menus==0 || $count_tbl_modules==0 || $count_dss_font==0 || $count_MediaComponentMaster==0 || $count_MediaTypeMaster==0 || $count_ScreenTemplateMaster==0 || $count_ScreenTemplateDetails==0 || $count_tbl_exchange_version==0 || $count_tbl_via_settings_templates==0 ||	$count_tbl_templates==0 || $count_thirdpartyapps==0 ){		
			$dbrestoreflag=0;
			return $this->redirect()->toRoute('dbrestore',array('action' => 'index'),array('query' => ['dbrestoreflag' => $appObj->desEncrypt($dbrestoreflag, KEY_SEED)]) );			
			exit;
		}
		
				 
		// Check total table count
		$wpgTableCount = $appObj->tableCount();
		$chkTblCnt=$connection->execute("SELECT COUNT(*) AS tblcount FROM information_schema.tables WHERE table_schema = 'public'")->current();
		if($wpgTableCount == 0 || $chkTblCnt['tblcount'] < $wpgTableCount){   
			$dbrestoreflag=0;               
			return $this->redirect()->toRoute('dbrestore',array('action' => 'index'),array('query' => ['dbrestoreflag' => $appObj->desEncrypt($dbrestoreflag, KEY_SEED)]) );
			exit;
		}

		if(!isset($sessionLoginName)) {
			//echo 'set default';
			$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
			if($lang == "zh") {
				if(strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 5))== "zh-tw")
					$lang = "zh-TW";
				if(strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 10))== "zh-hant-tw")
					$lang = "zh-TW";
			}
			if($lang == "en")
				$lang = "eng";
			if($lang == "ja")
				$lang = "jap";
			if($lang == "zh")
				$lang = "chi";
			if($lang == "es")
				$lang = "spa";
			if($lang == "de")
				$lang = "ger";
			if($lang == "ru")
				$lang = "rus";
			if($lang == "pl")
				$lang = "pol";
			if($lang == "fr")
				$lang = "fre";
			if($lang == "pt")
				$lang = "por";
			//if($lang=="zh-TW")  $lang="trchi";
			if($lang == "zh-TW")
				$lang = "trchi";
			$session->offsetSet('lang', $lang);
		}
		$this->layout('layout/landing');
		$appObj = new ApplicationController();
		$getos = $appObj->getClientOS();
		if(strstr($getos, 'Chrome OS')) {
			$clientOS = 'ChromeOS';
		} else if(strstr($getos, 'Mob_Window')) {
			$clientOS = 'windowsMobile';
		} else {
			$clientOS = strtoupper(substr($getos, 0, 3));
		}
		if($clientOS == "WIN") {
			if(PRODUCT_TYPE=='via'){
				$linkImgVirtualRun = "../download.php?filename=VIAApp.exe";
				$linkImgInstaller = "../download.php?filename=VIASetup.exe";
			}else{
				$linkImgVirtualRun = "../download.php?filename=Collab8App.exe";
				$linkImgInstaller = "../download.php?filename=Collab8Setup.exe";
			}
			
			$imgVirtualRunAlt = "images/via/via_index_10.gif";
			$imgInstallerAlt = "images/via/via_index_12.gif";
		}
		if($clientOS == "MAC") {
			if(PRODUCT_TYPE=='via'){
				$linkImgVirtualRun = "../download.php?filename=VIAApp.dmg";
				$linkImgInstaller = "../download.php? filename=VIASetup.dmg";
			}else{
				$linkImgVirtualRun = "../download.php?filename=Collab8App.dmg";
				$linkImgInstaller = "../download.php? filename=Collab8Setup.dmg";
			}
			
			$imgVirtualRun = "images/via" . $_SESSION['lang'] . "/via_index_05.gif";
			$imgInstaller = "images/via" . $_SESSION['lang'] . "/via_index_07.gif";
			$imgVirtualRunAlt = "images/via/via/via_index_10.gif";
			$imgInstallerAlt = "images/via/via_index_12.gif";
		}
		if($clientOS == "AND") {
			$linkImgVirtualRun = "https://play.google.com/store/apps/details?id=com.Activities.VIA&hl=en";
			$linkImgInstaller = "https://play.google.com/store/apps/details?id=com.Activities.VIA&hl=en";
			
			/*$imgVirtualRun="images/via/".$_SESSION['lang']."/via_index_05_ios.gif";
			 $imgInstaller="images/via/".$_SESSION['lang']."/via_index_07_android.gif";
			 */
			$imgVirtualRunAlt = "images/via/via_index_10_ios.gif";
			$imgInstallerAlt = "images/via/via_index_12_android.gif";
		}
		if($clientOS == "IPA" || $clientOS == "IPH") {
			$linkImgVirtualRun = "https://itunes.apple.com/us/app/via-app/id883509803";
			$linkImgInstaller = "https://itunes.apple.com/us/app/via-app/id883509803";
			
			$imgVirtualRunAlt = "images/via/via_index_10_ios.gif";
			$imgInstallerAlt = "images/via/via_index_12_android.gif";
		}
		if($clientOS == "ChromeOS") {
			$linkImgVirtualRun = "https://cb.wowvision.com/chrome.php";
			$linkImgInstaller = "https://cb.wowvision.com/chrome.php";
			
			$imgVirtualRunAlt = "images/via/via_index_10.gif";
			$imgInstallerAlt = "images/via/via_index_12.gif";
		}
		if($clientOS == "windowsMobile") {
			$linkImgVirtualRun = "https://www.microsoft.com/en-us/store/p/via/9wzdncrd2qlr";
			$linkImgInstaller = "https://www.microsoft.com/en-us/store/p/via/9wzdncrd2qlr";
			
			$imgVirtualRunAlt = "images/via/via_index_10_ios.gif";
			$imgInstallerAlt = "images/via/via_index_12_android.gif";
		}
		$check_fc23_file = CHECK_FC23_FILE;
		$check_serialNo_file = $appObj->checkfile(DEST_PATH, SERIALNO_FILE);
		$getBrowser = $appObj->getBrowser();
		$chromePortFileData = $appObj->file_read(DEST_PATH . FILE_CHROME_PORT);
		$chromeServerFileData = $appObj->file_read(DEST_PATH . FILE_CHROME_SERVER);
		$chromeHostData = $appObj->file_read(DEST_PATH . FILE_CHROME_HOST);
		$ipAddrFileData = $appObj->file_read(DEST_PATH . READFILE_IPADD);		
		$customRoomnameHost = file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)? $appObj->file_read(DEST_PATH . READFILE_ROOMNAME_VALUESHOW): trim($_SERVER['HTTP_HOST']);
		if(GET_OS == 'WIN' || GET_OS == 'LIN') {
			$gatewayId = $appObj->file_read(DEST_PATH.FILE_MAC_ADDRESS);
		}
		if(GET_OS == 'ChromeOS') {
			$gatewayId=$appObj->file_read(DEST_PATH.$macAddr_file);
		}
		$settingsUrl = DEST_PATH.'via_settings.json';
		$response = file_get_contents($settingsUrl);	
		//decrypt json
		$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
		$templateSettings = json_decode($decryptResponse);
		$advanceConfig = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->presentation;
		$chromeValue =($advanceConfig->chrome == '')? 0 : $advanceConfig->chrome;
		if( isset( $advanceConfig->run_via ) ){
			$run_via_value = $advanceConfig->run_via;
		}else{
			$run_via_value = 1;
		}
		if( isset( $advanceConfig->install_via ) ){
			$install_via_value = $advanceConfig->install_via;
		}else{
			$install_via_value = 1;
		}
		$miracastValue =($advanceConfig->miracast->status == '')? 0 : $advanceConfig->miracast->status;
		//get custom name from active json
		$get_custom_roomName=trim($templateSettings->VIA_CONFIG_TEMPLATE->via_details->dnsname);
		/* changed priority at 7 Feb, 2024: if dnsname is blank then read from roomnamevalueshow.txt, if roomnamevalueshow.txt is not exist then read form $_SERVER['HTTP_HOST'].*/
		/* again change the flow on 25July24. Now priority is roomnamevalueshow.txt*/ 
		$customRoomnameIP=$customRoomnameHost;//($get_custom_roomName!='')?$get_custom_roomName: $customRoomnameHost;		
		//$customRoomnameIP=($get_custom_roomName!='')?$get_custom_roomName: $customRoomnameHost;		
		//code aded by ashu on 21St Dec23 for adding moderator mode
		$moderator_mode_status = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->moderator_mode->status;	
		//modify code for central server
		if(file_exists(DEST_PATH.'centralservercloud.txt') ){
			$moderator_mode_status=6;
		}else{	
			if($moderator_mode_status==1){
				$moderator_mode_status = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->moderator_mode->config->moderator_type;
			}else{
				$moderator_mode_status=0;
			}
		}
		$qryString = "gatewayId=$gatewayId&server=$chromeServerFileData&port=$chromePortFileData&ipAddr=$ipAddrFileData&customroomname=$customRoomnameIP&login_mode=$moderator_mode_status";
		$encryptedString = "https://" . $chromeHostData . "/App/via.php?" . trim($appObj->desEncrypt($qryString, KEY_SEED));
		
		/*added on 22/Jan/2020. Check and Insert default data into tables */
	    $getHqConfigTotalRecords=$appObj->checkTableCount('tbl_hq_configuration');
		if($getHqConfigTotalRecords==0){		
			$hqConfigArr=array('HQ_WallpaperSetting'=>2,'HQ_AuthSetting'=>2,'HQ_ConfigSetting'=>2,'HQ_GwayFeatureSetting'=>2,'HQ_ClientFeatureSetting'=>2,'HQ_MobileFeatureSetting'=>2);
			$appObj->insertTableData('tbl_hq_configuration',$hqConfigArr);
		}
		$getHqMoreConfigTotalRecords=$appObj->checkTableCount('tbl_hq_more_configuration');
		if($getHqMoreConfigTotalRecords==0){
			$hqMoreConfigArr=array('featureStatus1'=>2,'featureStatus2'=>2,'featureStatus3'=>2,'featureStatus4'=>2,'featureStatus5'=>2,'featureStatus6'=>2);
			$appObj->insertTableData('tbl_hq_more_configuration',$hqMoreConfigArr);
		
		}
		$getFeatureConfigTotalRecords=$appObj->checkTableCount('tbl_feature_config_settings');
		if($getFeatureConfigTotalRecords==0){
           $mobdata = $this->getTblMobileFeaturesTable()->getFeatureName();
           $str=''; 
           foreach($mobdata as $val){
            $str.=$val.'#';
           }
           $str=trim(substr($str,0,-1));
		   $tbl_feature_config_settings_Arr=array('feature_name'=>'mobile','feature_data'=>$str,'feature_dateTime'=>date("Y-m-d H:i:s"));
		   $appObj->insertTableData('tbl_feature_config_settings',$tbl_feature_config_settings_Arr);		   
		}
		
		$getTblAdvanceConfigRecords=$appObj->checkTableCount('tbl_Advance_Configuration');
		if($getTblAdvanceConfigRecords==0){
			$advanceConfigArr=array('feature1'=>0,'feature2'=>96,'feature3'=>0,'feature4'=>0,'feature5'=>0,'feature6'=>0,'last_updated'=>date("Y-m-d H:i:s"));
			$appObj->insertTableData('tbl_Advance_Configuration',$advanceConfigArr);
		
		}
		
		$getTblRecordingTransferRecords=$appObj->checkTableCount('tbl_recording_transfer');
		if($getTblRecordingTransferRecords==0){
			$recordingTransferArr=array('transfer_option'=>'system_default');
			$appObj->insertTableData('tbl_recording_transfer',$recordingTransferArr);		
		}
		
		$getTblDisplaySettingsRecords=$appObj->checkTableCount('tbl_display_settings');
		if($getTblDisplaySettingsRecords==0){
			$displaySettingsArr=array('show_RoomName_Color'=>'255,255,255', 'show_RoomCode_Color'=>'255,255,255','activate_RoomName'=>1,'field1'=>'1','field2'=>'255,255,255');
			$appObj->insertTableData('tbl_display_settings',$displaySettingsArr);
		}
		
		if(CHECK_FILE_DPI==0){
			$dpiFileOpen = fopen(DEST_PATH.FILE_DPI, 'w') or die("can't open file");			
			fwrite($dpiFileOpen, 96);
			fclose($dpiFileOpen);		
		}
		if(CHECK_FILE_DPI==0){
			$dpiFileOpen = fopen(DEST_PATH.FILE_DPI, 'w') or die("can't open file");			
			fwrite($dpiFileOpen, 96);
			fclose($dpiFileOpen);		
		}
		$check_dualDisplay_file=(CHECK_FILE_DISPLAYCOUNT==1)?$appObj->file_read(DEST_PATH.FILE_DISPLAYCOUNT):1;
		if($check_dualDisplay_file==2){			
			$tbldataArr=array('reserve1'=>0,'reserve2'=>0);			
			$appObj->updateTableData('tbl_streaming_settings',$tbldataArr);
		}		
		
		if(CHECK_FILE_LAYOUT==1){
			$layoutFileVal=$appObj->file_read(DEST_PATH.FILE_LAYOUT);
		}
		if($layoutFileVal==0){
			$myfileAutoHide = fopen(DEST_PATH.FILE_DYNAMICLAYOUT, 'w');			
			$confWriteAutoHideCont= fwrite($myfileAutoHide, '');			
			fclose($myfileAutoHide);								
		}
		
		if(CHECK_FILE_LANGTXT==0){
			$fileName=DEST_PATH.READFILE_LANGTXT;
			$myfile = fopen($fileName, 'w') or die("can't open file");			
			$confWrite= fwrite($myfile, 'en');
			fclose($myfile);						
		}

		if(CHECK_FILE_DATEFORMAT==0){
			$dateFormatfileName=DEST_PATH.FILE_DATEFORMAT;
			$dateFormatFileOpen = fopen($dateFormatfileName, 'w') or die("can't open file");			
			$dateFormatFilefWrite= fwrite($dateFormatFileOpen, 'Y-m-d H:i:s');
			fclose($dateFormatFileOpen);
			
		}		
		/* end enter default data if not found*/
		$deviceSerialNo=$appObj->getSerialNumber();
		$model=$appObj->getModelName();	
		$modelshow=strtolower($appObj->getModelNameByParam('model'));
		$modellike=$appObj->getModelNameByParam('modellike');
		$modelOsType=strtolower($appObj->getModelNameByParam('ostype'));
		//added by niraj
		$modelShowWithoutSpace = $appObj->getModelNameWithoutSpace($model);
		//$checkInternet=$appObj->checkInternet();
		//store check internet into session
		//$session->offsetSet('session_checkInternet', $checkInternet);
		/*$check_dnsName='';
		if($get_custom_roomName!=''){
			if($checkInternet==1){
				$check_dnsName=$appObj->check_dns_name($get_custom_roomName);
			}
		}*/
	//aded by ashu on 10/July/24 after Udi feedback for showing firmware version inplace of web version
	$firmwareVersion = $appObj->getModelNameByParam('firmversion');		
		return array('clientOS' =>$clientOS,
					 'miracastValue' =>$miracastValue,
					 'check_serialNo_file' =>$check_serialNo_file,
					 'getBrowser' =>$getBrowser,
					 'gatewayId' =>$gatewayId,
					 'customRoomnameIP' =>$customRoomnameIP,
					 'check_fc23_file' =>$check_fc23_file,
					 'chromeServerFileData' =>$chromeServerFileData,
					 'chromePortFileData' =>$chromePortFileData,
					 'ipAddrFileData' =>$ipAddrFileData,
					 'encryptedString' =>$encryptedString,
					 'linkImgVirtualRun' =>$linkImgVirtualRun,
					 'linkImgInstaller' =>$linkImgInstaller,
					 'model'=>$model,
					 'deviceSerialNo'=>$deviceSerialNo,
					 'chromeValue'=>$chromeValue,
					 'run_via_value'=>$run_via_value,
					 'install_via_value'=>$install_via_value,
					 'modelshow'=>$modelshow,
					 'modellike'=>$modellike,
					 'modelOsType'=>$modelOsType,
					 //'check_dnsName'=>$check_dnsName,
					 'get_custom_roomName'=>$get_custom_roomName,
					 'checkInternet'=>$checkInternet,
					 'firmwareVersion'=>$firmwareVersion,
					 'modelShowWithoutSpace' => $modelShowWithoutSpace
					);
	}

	public function loginAction() {

		if(file_exists(DEST_PATH.'web_network_data.json')){
			unlink(DEST_PATH.'web_network_data.json');
		}
		if(file_exists(DEST_PATH.'web_check_discovery.txt')){
			unlink(DEST_PATH.'web_check_discovery.txt');
		}
		if(file_exists(DEST_PATH.'web_audio_input_data.txt')){
			unlink(DEST_PATH.'web_audio_input_data.txt');
		}
		if(file_exists(DEST_PATH.'web_audio_output_data.txt')){
			unlink(DEST_PATH.'web_audio_output_data.txt');
		}

		$appObj = new ApplicationController();
		$model=$appObj->getModelName();
		$getmodelbyparam=$appObj->getModelNameByParam('model');
        $getosbyparam=strtolower($appObj->getModelNameByParam('ostype'));
		$data = $appObj->getTableAllData('DeviceInventory')->current();
		$viaServerIP = $data['deviceip'];
		
		//getting captcha value from table
		$settingsUrl = DEST_PATH.'via_settings.json';
		$response = file_get_contents($settingsUrl);	
		//decrypt json
		$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
		$templateSettings = json_decode($decryptResponse);
		$sessionSettings = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->security;
		$captchaVal = ($sessionSettings->captcha!='') ? $sessionSettings->captcha : 1;
		$deviceSerialNo=$appObj->getSerialNumber();
		
		$session = new Container('userinfo');
		$user = $session->offsetGet('usrid');
		$session->offsetSet('model', $model);
		$session->offsetSet('modelSerialNo', $deviceSerialNo);
		$session->offsetSet('getmodelbyparam', $getmodelbyparam);
        $session->offsetSet('getosbyparam', $getosbyparam);
        $session->offsetSet('firmwareVersion', $appObj->getModelNameByParam('firmversion'));
		$session->offsetSet('modelShowWithoutSpace', $appObj->getModelNameWithoutSpace($model));

		if(!empty($user)) {
			return $this->redirect()->toRoute('home', array('action' => 'systemInfo'));
		}
		$this->layout('layout/login');
		$form = new LoginForm($this->getRequest()->getBaseUrl().'/data/captcha/',$captchaVal);
		$loginStatus = 0;
		if($this->getRequest()->isPost()) {
			//regenerate session
			session_regenerate_id(true);
			$postData = $this->getRequest()->getPost()->toArray();
			unset($postData['submit']);

			//convert ' \ characters #added by niraj
			$postData['login_name'] = str_replace(["'", '\\'], '&', $postData['login_name']);

			//$postData = array_map('trim', $postData);
			//$adduser = new adduser();
			$request = $this->getRequest();
			$form->setData($request->getPost());
			if($form->isValid()) {
				$postData['status'] = 'Y';
				
				$arrObject = []; //for ad server data
				$authUserCount = 0;
				if (CHECKFILE_ADSETTINGS == 1 && filter_var($postData['login_name'], FILTER_VALIDATE_EMAIL)) {
					$arrObject = $appObj->validateOnActiveDirectoryServer($postData['login_name'], $postData['login_password']);
					if($arrObject['status'] == 'success'){
						$authUserCount = 1;
						$user_detail = $arrObject['userinfo'];
					}
				} else {
					$result = $this->getAppuserListTable()->checkLoginUser($postData);
					$authUserCount = $result->count();
					$user_detail = $result->current();
				}

				
				if($authUserCount > 0) {
					//get crsf token and store in session
					$crsf_token=$appObj->create_crsftoken();
					//$user_detail = $result->current();
					
					$session = new Container('userinfo');
					$session->offsetSet('LoginName', $user_detail['apploginname']);
					$session->offsetSet('usrid', $user_detail['appuserid']);
					$session->offsetSet('utype', $user_detail['appgroupid']);
					$session->offsetSet('read_only', 1);
					$session->offsetSet('modelContent', PRODUCT_TYPE);
					//store crsf_token into session
					$session->offsetSet('crsf_token', $crsf_token);	
					
					//set if ad user loggedin
					if(isset($arrObject['status']) && $arrObject['status'] == 'success'){
						$session->offsetSet('is_ad_user', true);
					}

					//setting menus to session					
					$appObj->getViaMenus($user_detail['appuserid']);
					//manage tbl_session_check 
					$appObj->manage_Tbl_Session_Check();	
					//manage log			
					$appObj->ActivityLog('Login',MSG_SUCCESS);
					//Create wizard.txt if not exist.
					if(!file_exists(DEST_PATH.FILE_WIZARD)){
						$wizardFile = fopen(DEST_PATH.FILE_WIZARD, 'w');
						$wizardFileWrite= fwrite($wizardFile, '');			
						fclose($wizardFile);	
					}
					return $this->redirect()->toRoute('home', array('action' =>'systemInfo'));
				}else{
					if($postData['login_name'] == '' || $postData['login_password'] == ''){
						$form->setMessages(array('login_name' => array(STR_USERNAME_PASSWORD_NOT_EMPTY)));
					}else if(isset($arrObject['status']) && $arrObject['status'] == "error"){
						$form->setMessages(array('login_name' => [$arrObject['message']]));
					}else{
						$form->setMessages(array('login_name' => array(STR_INVALID_USERNAME_PASSWD)));
					}
					$loginStatus = 1;
					// set error if login fails.
				}
			}
		}
		return array('form' =>$form,'model'=>$model,'captchaVal'=>$captchaVal,'deviceSerialNo'=>$deviceSerialNo,'loginStatus'=>$loginStatus,'viaServerIP'=>$viaServerIP);
	}
	

	public function logoutAction() {
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		//delete data from tbl_session_check 
		$appObj->delete_Tbl_Session_CheckData();
		$appObj->ActivityLog('Logout',MSG_SUCCESS);
		$session->getManager()->destroy();
		$session->offsetSet('login_email', '');
		$session->offsetSet('user_cmpid', '');
		$session->offsetSet('crsf_token', '');	
		return $this->redirect()->toRoute('viaIndex');
	}
	
	
	/*****
	 *	@Class Name			: changeLangAction
	 *  @description	    : Using for change lang from drop down                     
	 *	@Author			    : Ashu
	 *  @Date               : 17-Jan-2020
	 *****/ 		
	public function changeLangAction(){
		$postData = $this->getRequest()->getPost()->toArray();
		$selectedLang=$postData['selectedLang'];
		if($selectedLang=='Chinese'){
			$lang='chi';
		}
		else if($selectedLang=='Polish'){
			$lang='pol';
		}
		else if($selectedLang=='German'){
			$lang='ger';
		}
		else if($selectedLang=='Japanese'){
			$lang='jap';
		}
		else if($selectedLang=='Russian'){
			$lang='rus';
		}
		else if($selectedLang=='Spanish'){
			$lang='spa';
		}
		else if($selectedLang=='French'){
			$lang='fre';
		}else if($selectedLang=='Portuguese'){
			$lang='por';
		}else if($selectedLang=='Traditional chinese'){
			$lang='trchi';
		}else{
			$lang='eng';
		} 
		
		$session = new Container('userinfo');	
		$session->offsetSet('lang', $lang);
		//$this->layout('layout/login');		
		die;			
	}
	
	/*****
	 *	@Class Name			: registerDevice
	 *  @description	    : Using for register device                    
	 *	@Author			    : Ashu
	 *  @Date               : 21-Jan-2020
	 *****/ 		
	public function registerDeviceAction(){
		$appObj=new ApplicationController();
		$model=$appObj->getModelName();	
		$modelvalue=strtolower($appObj->getModelNameByParam('modelvalue'));
		$modellike=$appObj->getModelNameByParam('modellike');				
		//Checking internet based on the model 
		if($modelvalue==1 || $modelvalue==5){
			$connected=1;				
		}else{
			$connected=$appObj->checkInternet();
		}
		if ($connected==1){			
			$email=urlencode(trim($_POST['email']));
			$password=urlencode(trim($_POST['password']));
			$OemSN=urlencode(trim($_POST['OemSN']));
			//$url='https://25.wowvision.in/api/ViaApi/?email='.$email.'&password='.$password.'&OemSN='.$OemSN."&AspxAutoDetectCookieSupport=1";
			$url='https://www.kramerav.com/api/ViaApi/?email='.$email.'&password='.$password.'&OemSN='.$OemSN."&AspxAutoDetectCookieSupport=1";
			$res=$appObj->curl_get_contents($url);
			//added by ashu to fix bug id 8854
			if($res==7){
				echo $res; die;
			}
			$data=json_decode($res, true);
			if($data['result']=="fail"){
				echo $data['value'];die;
			}
			else if($data['result']=="success"){
				$getOS=strtoupper(substr(PHP_OS, 0, 3));
				if($getOS=='WIN'){
					$checkConfPath='C:/Collab8/';
					$destPath=(is_dir($checkConfPath))?'C:/Collab8/config/':'C:/tc/config/';
				}else{
					$destPath='/var/www/html/Collab8/config/';
				}
				$myFile=fopen($destPath."register.txt", "w");
				echo $data['value'];die;
			}else{
				echo $data['value'];die;
			}
			//hit the curl
		}else{
			echo 7; die;
		}
	}
	
	
	/*****
	 *	@Class Name			: refreshAction
	 *  @description	    : refresh captcha                  
	 *	@Author			    : vineet
	 *  @Date               : 01-Jun-2020
	 *****/ 
	public function refreshAction(){
		$appObj = new ApplicationController();
		$captchaVal='';
		$captchaData = $appObj->getTableAllData('tbl_session_settings');
		foreach($captchaData as $captchaVal) {
			$captchaVal = $captchaVal['captcha'];
		}
		$form = new LoginForm($this->getRequest()->getBaseUrl().'/data/captcha',$captchaVal);
		$captcha = $form->get('captcha')->getCaptcha();
		 $data = array();
		 $data['id']  = $captcha->generate();
		 $data['src'] = $captcha->getImgUrl().
		 			   $captcha->getId() .
		 			   $captcha->getSuffix();
	    $view = new JsonModel(array('success' => $data));
	    $view->setTerminal(true);
	    return $view;
	}
	
	/*****
	 *	@Function Name: loginBridgeAction
	 *  @description  : Check the auto login from vsm
	 *	@Author		  : Dileep
	 *  @Date         : 13-July-2020
	 *****/
	public function bridgeAction() {
		if(isset($_GET['key'])){
			$encryptedkey = trim($_GET['key']);
			$appObj = new ApplicationController();
			$decryptedKey=$appObj->desDecrypt($encryptedkey, '1324587099345678');
			if(trim($decryptedKey)==trim(BRIDGE_KEYWORD)){
				$connection=$appObj->getConnection();
				$response = $connection->execute("SELECT A.appuserid, A.apploginname, A.active, A.password, B.appgroupid FROM appusergroups AS B INNER JOIN appuserlist AS A ON A.appuserid=B.appuserid WHERE A.active='Y' AND B.appgroupid=1 ORDER BY A.appuserid ASC limit 1");
				$user_detail = $response->current();
				if($user_detail['appuserid']){
					$session = new Container('userinfo');
				    $session->offsetSet('LoginName', $user_detail['apploginname']);
				    $session->offsetSet('usrid', $user_detail['appuserid']);
				    $session->offsetSet('utype', $user_detail['appgroupid']);
				    $session->offsetSet('modelContent', PRODUCT_TYPE);
				    $session->offsetSet('bridge', 1);
					//manage tbl_session_check 
					$appObj->manage_Tbl_Session_Check();	
					
					//Save the model info in session
					$model=$appObj->getModelName();
		            $getmodelbyparam=$appObj->getModelNameByParam('model');
                    $getosbyparam=$appObj->getModelNameByParam('ostype');
					$deviceSerialNo=$appObj->getSerialNumber();
					$session->offsetSet('model', $model);
		            $session->offsetSet('modelSerialNo', $deviceSerialNo);
		            $session->offsetSet('getmodelbyparam', $getmodelbyparam);
                    $session->offsetSet('getosbyparam', $getosbyparam);

					//setting menus to session					
					$appObj->getViaMenus($user_detail['appuserid']);					
					//manage log			
					$appObj->ActivityLog('Login',MSG_SUCCESS);
					return $this->redirect()->toRoute('home', array('action' =>'systemInfo'));
				}else{
					return $this->redirect()->toRoute('viaIndex');
				}
			}
		}
	}
	

	/*****
	 *	@Class Name			: altersessionAction
	 *  @description	    : Re-assing session                     
	 *	@Author			    : Niraj
	 *  @Date               : 09-Jan-2025
	 *****/
	public function altersessionAction(){
		if (file_exists(filename: DEST_PATH.'tmp_web_session.txt')) {
			$fileContent = json_decode(file_get_contents(DEST_PATH.'tmp_web_session.txt'), true);
			if(!empty($fileContent)){
				$appObj = new ApplicationController();
				$session = new Container('userinfo');
				$session->exchangeArray($fileContent);
				$appObj->manage_Tbl_Session_Check();
				unlink(DEST_PATH.'tmp_web_session.txt');
			}
			return $this->redirect()->toRoute('home', array('action' =>'systemInfo'));
		}else{
			return $this->redirect()->toRoute('viaIndex');
		}
	}


	/*****
	 *	@Class Name			: checkInternetAjaxAction
	 *  @description	    : Using for check internet connection                     
	 *	@Author			    : Ashu
	 *  @Date               : 25-Jun-2021
	 *****/ 		
	public function checkInternetAjaxAction(){
		$appObj = new ApplicationController();
		$checkInternet=$appObj->checkInternet();
		echo $checkInternet;
		die;
	}
	

	public function getAppuserListTable() {
		if(!$this->TblAppuserListTable) {
			$sm = $this->getServiceLocator();
			$this->TblAppuserListTable = $sm->get('Webapp\Model\TblAppuserListTable');
		}
		return $this->TblAppuserListTable;
	}
	public function getTblMobileFeaturesTable() {
		if(!$this->TblMobileFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblMobileFeaturesTable = $sm->get('Webapp\Model\TblMobileFeaturesTable');
		}
		return $this->TblMobileFeaturesTable;
	}	
	
}
