<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\NetworksettingsForm;
use Webapp\Form\ViaConfigurationForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
//use Webapp\Model\UserTable;
//use Webapp\Model\adduser;
use Webapp\Form\SourceSwitchForm;
use Webapp\Form\ModeratorModeForm;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;

class ViasettingsController extends AbstractActionController {
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['sessionTimeOut'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	//VIA Settings - added by Ranjan
	public function viaConfigurationAction() {
		$autoPowerOffData = '';
		$autoRebootData = '';
		$AppObject = new ApplicationController();
		$model=$AppObject->getModelNameByParam('model');
		$deviceostype=$AppObject->getModelNameByParam('ostype');
		$check_viago=($model=='viago')?1:0;
		
		if(FILE_ROOMNAME) {
			$get_roomnameRGBCode = $AppObject->file_read(DEST_PATH . READFILE_ROOMNAME);
			list($r1, $g1, $b1)= explode(",", $get_roomnameRGBCode);
			$rgb_roomname = array($r1,$g1,$b1);
			$file_roomname_hexCode = $AppObject->rgb2hex($rgb_roomname);
		}
		if(FILE_ROOMCODE) {
			$get_roomcodeRGBCode = $AppObject->file_read(DEST_PATH . READFILE_ROOMCODE);
			list($r2, $g2, $b2)= explode(",", $get_roomcodeRGBCode);
			$rgb_roomcode = array($r2,$g2,$b2);
			$file_roomcode_hexCode = $AppObject->rgb2hex($rgb_roomcode);
		}
		if(CHECKFILE_STRDATETIME) {
			$get_strDateTimeRGBCode = $AppObject->file_read(DEST_PATH . READFILE_STRDATETIME);
			list($r3, $g3, $b3)= explode(",", $get_strDateTimeRGBCode);
			$rgb_strDateTime = array($r3,$g3,$b3);
			$file_strDateTime_hexCode = $AppObject->rgb2hex($rgb_strDateTime);
		}
		if(CHECK_FILE_AUTO_POWEROFF == 1) {
			$autoPowerOffData = $AppObject->file_read(DEST_PATH . FILE_AUTO_POWEROFF);
			list($hh, $mm)= explode(':', $autoPowerOffData);
		}
		if(CHECK_FILE_AUTO_REBOOT == 1) {
			$autoRebootData = $AppObject->file_read(DEST_PATH . FILE_AUTO_REBOOT);
			list($autoRebootHours, $autoRebootMints)= explode(':', $autoRebootData);
		}
		$session = new Container('userinfo');
		$fsetWidth =($session->offsetGet('lang')== 'eng')? 'fsetWidth_def' : 'fsetWidth_' . $session->offsetGet('lang');
		$leftPaddLang =($session->offsetGet('lang')== 'ger' || $session->offsetGet('lang')== 'spa' || $session->offsetGet('lang')== 'rus')? 'leftPadding_' . $session->offsetGet('lang'): '';
		$newBtnClassLang =($session->offsetGet('lang')== 'ger' || $session->offsetGet('lang')== 'spa' || $session->offsetGet('lang')== 'rus' || $session->offsetGet('lang')== 'pol')? 'newBtnClass_' . $session->offsetGet('lang'): 'newBtnClass';
		$rebootBtnLeftPadding =($session->offsetGet('lang')== 'ger' || $session->offsetGet('lang')== 'spa' || $session->offsetGet('lang')== 'rus' || $session->offsetGet('lang')== 'pol')? 'rebootBtnPadding_' . $session->offsetGet('lang'): 'rebootBtnDefPadding';
		$langArr['option'] = array('zh' => STR_LANG_CHI,
								   'en' => STR_LANG_ENG,
								   'de' => STR_LANG_GER,
								   'ja' => STR_LANG_JAP,
								   'pl' => STR_LANG_POL,
								   'ru' => STR_LANG_RUS,
								   'es' => STR_LANG_SPA,
								   'fr' => STR_LANG_FRE,
								   'pt' => STR_LANG9_PORTUGUESE,
								   'zh-TW' => STR_TRADITIONAL_CHINESE);
		
		/******************* read lang file. already created in header *************************** */
		if(CHECK_FILE_LANGTXT) {
			$langFile_val = $AppObject->file_read(DEST_PATH . READFILE_LANGTXT);
		}
		$langArr['sel'] = $langFile_val;
		
		/******************* read wallpaperSetting  file. already created in header *************************** */
		if(CHECK_FILE_WALLPAPERSETTING) {
			$wallpaperSettingVal = $AppObject->file_read(DEST_PATH . FILE_WALLPAPERSETTING);
		}
		
		/******************* create gway feature Setting file. Already created in header*************************** */
		if(CHECK_FILE_GWAY_FEATURESETTING) {
			$gwaySettingVal = $AppObject->file_read(DEST_PATH . FILE_GWAY_FEATURESETTING);
		}
		
		/******************* read Client feature Setting file. already created in header *************************** */
		if(CHECK_FILE_CLIENT_FEATURESETTING) {
			$clientSettingVal = $AppObject->file_read(DEST_PATH . FILE_CLIENT_FEATURESETTING);
		}
		// read chat button file
		if(CHECK_FILE_CHAT) {
			$chatFileVal = $AppObject->file_read(DEST_PATH . FILE_CHAT);
		}
		$layoutFileVal = 0;
		if(CHECK_FILE_LAYOUT == 1) {
			$layoutFileVal = $AppObject->file_read(DEST_PATH . FILE_LAYOUT);
		}
		if(GET_OS == 'WIN') {
			$last4digit =(CHECK_FILE_SERIALNO == 1)? '_' . substr($AppObject->file_read(DEST_PATH . FILE_SERIALNO), - 4): '';
		}
		if(GET_OS == 'LIN') {
			$last4digit =($gwayMacAddr != "")? '_' . substr(str_replace(':', '', $gwayMacAddr), - 4): '';
		}
		$mirrorFile_data = '';
		if(CHECK_FILE_MIRRORNAME == 1) {
			$mirrorFile_data = $AppObject->file_read(DEST_PATH . FILE_MIRRORNAME);
		}
		for($mirrVal = 1;
		$mirrVal < DD_MAX_CONN;
		$mirrVal ++ ) {
			$mirrorArr['mirror'][$mirrVal] = $mirrVal;
		}
		$mirrorArr['selected'] = '';
		if(CHECK_FILE_MIRROR_MAXCON == 1) {
			$maxCon_mirrorFile_data = $AppObject->file_read(DEST_PATH . FILE_MIRROR_MAXCON);
			$mirrorArr['selected'] = $maxCon_mirrorFile_data;
		}
		if(CHECK_IMAGE_QRCODE == 1) {
			copy(DEST_PATH.IMAGE_QRCODE, UPLOAD_PATH.IMAGE_QRCODE);
		}
		$displaySetting = $this->getDisplaySettingsTable()->fetchAll();
		$activateRoomOverlay = $displaySetting['activateRoomOverlay'];
		$RoomOverlayValue = $displaySetting['RoomOverlayValue'];
		$twentyfourHoursFormat = $displaySetting['twentyfourHoursFormat'];
		$chatStatus = $this->getClientsFeaturesTable()->featureStatus('Chat');
		$timezoneArray = $this->getTimezonesTable()->fetchAll('');

		foreach($timezoneArray as $timezone) {
			$timezoneData['option'][$timezone['tz_name']] = $timezone['tz_name'];
			if($timezone['tz_active_status'] == 1) {
				$timezoneData['sel'] = $timezone['tz_name'];
			}
		}
		//print_r($timezoneData);die;
		$advanceConfig = $this->getAdvanceConfigurationTable()->fetchAll();
		$clearCloud = $advanceConfig['feature1'];
		$dpiFileValue = $advanceConfig['feature2'];
		$whiteBoradOptions = $advanceConfig['feature3'];
		$recordingConfig = $advanceConfig['feature4'];
		$apiCmdValue = $advanceConfig['feature5'];
		//$audioConfig = $advanceConfig['feature7'];
		$pollConfig = $advanceConfig['feature8'];
		// using for polling
		$chromeConfigStatus = $advanceConfig['feature9'];
		//Chrome Settings
		//$miracastConfigStatus=($advanceConfig['feature10']!='')?$arr['feature10']:0; //Miracast Settings
		$miracastConfigStatus = CHECK_FILE_MIRACAST;
        $check_miracastFrequecyFile=file_exists(LIN_WIFI_PATH.FILE_MIRACAST_FREQUENCY)?$AppObject->file_read(LIN_WIFI_PATH.FILE_MIRACAST_FREQUENCY):0;
		$imgPath = PUBLIC_URL . '/' . IMG_DIR . IMAGE_QRCODE;
		// QR code image path
		$fileFormatStatus = $this->getAuthFileFormatTable()->fetchFileStatus('All');
		$fileFormat =($fileFormatStatus == 1)? 'all' : 'selected';
		$fileFormatArr = $this->getAuthFileFormatTable()->fetchAllFileFormat();
		$selectedFileFormatArr = $this->getAuthFileFormatTable()->fetchSelectedFileFormat();
		//remove jpeg and pdf from existing values		
		if(in_array('jpeg', $selectedFileFormatArr)) {
			$key1 = array_search('jpeg', $selectedFileFormatArr);
			unset($selectedFileFormatArr[$key1]);
		}
		if(in_array('pdf', $selectedFileFormatArr)) {
			$key2 = array_search('pdf', $selectedFileFormatArr);
			unset($selectedFileFormatArr[$key2]);
		}
		if(in_array('jpg', $selectedFileFormatArr)) {
			$key3 = array_search('jpg', $selectedFileFormatArr);
			unset($selectedFileFormatArr[$key3]);
		}
		if(in_array('png', $selectedFileFormatArr)) {
			$key4 = array_search('png', $selectedFileFormatArr);
			unset($selectedFileFormatArr[$key4]);
		}
		$selAll = $this->getAuthFileFormatTable()->fetchFileStatus('All');
		$resetSessionConfigStatus = $this->getAdvanceMoreFeaturesTable()->fetchProperty('ResetSession');
		//Reset Session Settings
		$DspEncodeValueStatus = $this->getAdvanceMoreFeaturesTable()->fetchProperty('DspEncodeValue');
		//jpeg H264 Settings
		$defaultAudioVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('DefAudioSetting');
		//default audio level
		$zoomVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('Zoom');
		//zoom value
		$blueJeansVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('BlueJeans');
		//bluejeans value
		$HDMIVal = $this->getAdvanceMoreFeaturesTable()->fetchProperty('DefHDMIMod');
                //Microsoft Teams value
                $MSTeams = $this->getAdvanceMoreFeaturesTable()->fetchProperty('MSTeams');
                //Close TP Apps value
                $TPCollabAppClose = $this->getAdvanceMoreFeaturesTable()->fetchProperty('TPCollabAppClose');
		$templateArr = array('status' => 1);
		//check qrcode value using activate template
		//$templatename = $this->getTemplatesTable()->getTableSpecificNameById('template_name',$templateArr);
		//$checkQrcodeFromXml= json_decode(file_get_contents($templateDir.$templatename.'.json'));
		//$getQRCodeWhenPageLoade=($checkQrcodeFromXml==1 && $check_qrcodeImage==1)?'showDownloadBtn':'';		
		if(($AppObject->getModelNameByParam('model')== 'campus' || $AppObject->getModelNameByParam('model')== 'campusplus' || $AppObject->getModelNameByParam('model')== 'campus2plus') && CHECK_FILE_FREE_FLOW == 1) {
			$displayLayoutArr['option'] = array('Dynamic Layout View','Left Thumbnail View','Right Thumbnail View','Bottom Thumbnail View','Free Flow');
		} else {
			$displayLayoutArr['option'] = array('Dynamic Layout View','Left Thumbnail View','Right Thumbnail View','Bottom Thumbnail View');
		}
		if(CHECK_FILE_DATEFORMAT == 0) {
			$dateFormatfileName = DEST_PATH . FILE_DATEFORMAT;
			$dateFormatFileOpen = fopen($dateFormatfileName, 'w')or die("can't open file");
			$dateFormatFilefWrite = fwrite($dateFormatFileOpen, 'Y-m-d H:i:s');
		} else {
			$show_date_format = $AppObject->file_read(DEST_PATH . FILE_DATEFORMAT);
		}
		$transfer_option = $this->getRecordingTransferTable()->fetchTransferOption();
		$streamArr = $this->getStreamingSettingsTable()->fetchAll();
		if(count($streamArr)> 0) {

			foreach($streamArr as $stream) {
				$stream_option =($stream->status == '')? 0 : $stream->status;
				$stream_url1 = $stream->display_url_1;
				$stream_url2 = $stream->display_url_2;
			}
		} else {
			$stream_option = 0;
			$stream_url1 = '';
			$stream_url2 = '';
		}
		$streamFormData['stream_option'] = $stream_option;
		$streamFormData['stream_url1'] = $stream_url1;
		$streamFormData['stream_url2'] = $stream_url2;
		//added on 26may2017
		if(GET_OS == 'LIN') {
			$url1Txt = STR_STREAMING_URL;
		}
		if(CHECK_FILE_DISPLAYCOUNT == 1){
			$content = $AppObject->file_read(DEST_PATH.FILE_DISPLAYCOUNT);
		}
		$url1Txt =(GET_OS == 'WIN' && $content == 2)? STR_STREAMING_URL_1 : STR_STREAMING_URL;
		$url2Txt = STR_STREAMING_URL_2;
		$displayLayoutArr['sel'] = $layoutFileVal;
		$proxyDataArr = $this->getProxyData();
		$disableSaveProxyBtn = ($proxyDataArr['servername']=='')?'':'disabled';
		$proxyPassword = $proxyDataArr['password'];
		if(file_exists(DEST_PATH.FILE_ENERGYSAVER_MODE)){
			$sleep_time = file_get_contents(DEST_PATH.FILE_ENERGYSAVER_MODE);
			$energy_saver_sleep_time = ($sleep_time=='')?10:$sleep_time;
		}else{
			$energy_saver_sleep_time = 10;
		}
		$sleepArr['option'] = array('5'=>5,'10'=>10,'30'=>30,'60'=>60,'120'=>120);
		$sleepArr['sel'] = trim($energy_saver_sleep_time);
		$formData = array(  'timezoneData' =>$timezoneData,
                            'mirrorFile_data' =>$mirrorFile_data,
                            'mirrorArr' =>$mirrorArr,
                            'displayLayoutArr' =>$displayLayoutArr,
                            'langArr' =>$langArr,
                            'dpiFileValue' =>$dpiFileValue,
                            'autoPowerOffData' =>$autoPowerOffData,
                            'autoRebootData' =>$autoRebootData,
                            'show_date_format' =>$show_date_format,
                            'clearCloud' =>$clearCloud,
                            'TPCollabAppClose' =>$TPCollabAppClose,
                            //'audioConfigArr' =>$audioConfigArr,
                            'defaultAudioVal' =>$defaultAudioVal,
                            'streamFormData' =>$streamFormData,
                            'proxyDataArr' =>$proxyDataArr,
							//'audioInputConfigArr' =>$audioInputConfigArr,
							'sleepArr' => $sleepArr,
                        );
		$form = new ViaConfigurationForm($formData);
		$request = $this->getRequest();
		
		$AppObj = new ApplicationController();
		$settingValue = $AppObj->getTableAllData('tbl_hq_configuration')->current();
		$configSettingVal = $settingValue['hq_configsetting'];
		$advSettingValue = $AppObj->getTableAllData('tbl_hq_more_configuration')->current();
		$advanceConfigurationSettingVal = $advSettingValue['featurestatus1'];
		$data = $AppObj->getTableAllData('DeviceInventory')->current();
		$viaServerIP = $data['deviceip'];
		//getting value to allow wifi or miracast
		$wifiMiracastFlag=$AppObj->allowMiracastAndWifi(DEST_PATH.'network.json');
		//getting miracast value from network.json. Now Miracast will be read from json not from file
		$networkJsonData=$AppObj->readJsonFile(DEST_PATH.'network.json');
		$supportMiracast=($networkJsonData['Miracast']!='')?trim($networkJsonData['Miracast']):0;
		
		return new ViewModel(array('activateRoomOverlay' => $activateRoomOverlay, 'RoomOverlayValue' => $RoomOverlayValue, 'RoomOverlayValue' => $RoomOverlayValue, 'twentyfourHoursFormat' => $twentyfourHoursFormat, 'clearCloud' => $clearCloud, 'dpiFileValue' => $dpiFileValue, 'whiteBoradOptions' => $whiteBoradOptions, 'recordingConfig' => $recordingConfig, 'apiCmdValue' => $apiCmdValue, 'DspEncodeValueStatus' => $DspEncodeValueStatus, 'defaultAudioVal' => $defaultAudioVal, 'audioConfig' => $audioConfig, 'pollConfig' => $pollConfig, 'chromeConfigStatus' => $chromeConfigStatus, 'miracastConfigStatus' => $miracastConfigStatus, 'check_miracastFrequecyFile' => $check_miracastFrequecyFile, 'maxCon_mirrorFile_data' => $maxCon_mirrorFile_data, 'imgPath' => $imgPath, 'fileFormat' => $fileFormat, 'selAll' => $selAll, 'fileFormatArr' => $fileFormatArr, 'selectedFileFormatArr' => $selectedFileFormatArr, 'resetSessionConfigStatus' => $resetSessionConfigStatus, 'transfer_option' => $transfer_option, 'stream_option' => $stream_option, 'url1Txt' => $url1Txt,'url2Txt' => $url2Txt, 'zoomVal' => $zoomVal, 'blueJeansVal' => $blueJeansVal, 'form' => $form, 'configSettingVal' => $configSettingVal, 'advanceConfigurationSettingVal' => $advanceConfigurationSettingVal, 'viaServerIP' => $viaServerIP, 'MSTeams' => $MSTeams,'wifiMiracastFlag'=>$wifiMiracastFlag,'supportMiracast'=>$supportMiracast,'disableSaveProxyBtn' => $disableSaveProxyBtn,'proxyPassword' => $proxyPassword,'content'=>$content));
	}

	public function getAudioInputOutputAction(){
		//audio config change . Now commands will be same for window/Linux. output 'GetAudioDevice|1|HDMI#USB|USB'; it means HDMI and USB will be show in dropdown and USB will be selected 
		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$audioOutput_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetAudioDevice</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$audioInput_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetAudioInputDevice</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		
		/* **********************audio Input code  ******************* */
		$appObj = new ApplicationController();		
		$returnResultAudioInput = $appObj->showNetworkInfo($logincmd, $audioInput_cmd);
		//checking command output
		$audioInputArray = explode('|', $returnResultAudioInput);			
		if($returnResultAudioInput!='' && $audioInputArray[1]!=''){	
			//$audioInputArray = explode('|', $returnResultAudioInput);
			$audioInputString='';
			foreach($audioInputArray as $audioInkey=>$audioInval){
				//echo '<br>'.$k.'. and '.$val;
				if($audioInkey==1){
					//for drop down					
					$audioInputString.=$audioInputArray[$audioInkey];
				}
				if($audioInkey==2){
					//showing selected option	
					$selectedAudioInput=$audioInputArray[$audioInkey];
				}
				
			}//end of foreach
			if(strstr($audioInputString,'#')){
				$audioInputConfigNumericArray=explode('#',$audioInputString);
			}else{
				$audioInputConfigNumericArray=array($audioInputString);
			}				
			//change numeric array to associative array				
			foreach($audioInputConfigNumericArray as $myInval){
				$audioInputConfigArray[$myInval]=$myInval;
			}				
			$audioInputConfig=$selectedAudioInput;
		}
		/***************** audio Input code end ******************* */

		/* ****************audio Output code  ********************* */
		$returnResult = $appObj->showNetworkInfo($logincmd, $audioOutput_cmd);
		//checking command output
		$returnResultArray = explode('|', $returnResult);
		if($returnResult!='' && $returnResultArray[1]!=""){
			$audioOutputString='';
			foreach($returnResultArray as $audiokey=>$audioval){
				//echo '<br>'.$k.'. and '.$val;
				if($audiokey==1){
					//for drop down					
					$audioOutputString.=$returnResultArray[$audiokey];
				}
				if($audiokey==2){
					//showing selected option					
					$selectedAudioOutput=$returnResultArray[$audiokey];
				}
				
			}			
			
			if(strstr($audioOutputString,'#')){
				$audioConfigNumericArray=explode('#',$audioOutputString);
			}else{
				$audioConfigNumericArray=array($audioOutputString);
			}
			//change numeric array to associative array
			foreach($audioConfigNumericArray as $myval){
				$audioConfigArray[$myval]=$myval;
			}				
			$audioConfig=$selectedAudioOutput;
			//end	
		}

		if(isset($audioConfigArray)){
            $audioConfigArr['option'] = $audioConfigArray;
        }else{
            $audioConfigArr['option'][] = MSG_NO_RECORD;
        }
		
		//Audio Input Code
        if(isset($audioInputConfigArray)){
            $audioInputConfigArr['option'] = $audioInputConfigArray;
        }else{
            $audioInputConfigArr['option'][] = MSG_NO_RECORD;
        }

		$audioConfigArr['sel'] = $audioConfig;
		$audioInputConfigArr['sel'] = $audioInputConfig;
		$audioArr = array('inputOpt' => $audioInputConfigArr['option'], 'inputVal' => $audioInputConfig, 'outputOpt' => $audioConfigArr['option'], 'outputVal' => $audioConfig);
		echo json_encode($audioArr);die;
	}

	//Via setting Ajax - Added by Ranjan
	public function serverConfigurationAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$selChkBoxName = trim($request->getPost('chkBoxName'));
			$chkBoxVal = trim($request->getPost('chkBoxVal'));
			if($selChkBoxName == 'showRoomName') {
				$fileName = DEST_PATH . READFILE_ROOMNAME;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "0,0,0";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ROOM_NAMEBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					if(file_exists(DEST_PATH . READFILE_ROOMNAME_VALUESHOW)) {
						unlink(DEST_PATH . 
							   READFILE_ROOMNAME_VALUESHOW);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ROOM_NAMEBY, $hostname);
					echo 'showRoomNameFileDeleted';
					die;
				}
			}
			if($selChkBoxName == 'activationRoomCode') {
				$fileName = DEST_PATH . READFILE_ROOMCODE;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "0,0,0";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ROOM_CODEBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					//added on 25Apr2017 for delete roomcodeshow.txt file when unchecked.
					unlink(DEST_PATH . 
						   READFILE_ROOMCODESHOW);
					//end
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ROOM_CODEBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'showDateTime') {
				$fileName = DEST_PATH . READFILE_STRDATETIME;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "0,0,0";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DATE_TIMEBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DATE_TIMEBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'alwaysShowOnWallp') {
				$fileName = DEST_PATH . READFILE_ROOMCODESHOW;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ALWAYS_SHOWBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ALWAYS_SHOWBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'pipMode') {
				$fileName = DEST_PATH . READFILE_PIP;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PIP_MODE, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PIP_MODE, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'sysLog') {
				$fileName = DEST_PATH . READFILE_ENABLELOG;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					if(!file_exists(CLIENT_SYSLOG_DIR))
						mkdir(CLIENT_SYSLOG_DIR);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_SYSTEM_LOG, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					if(is_dir(CLIENT_SYSLOG_DIR)) {
						$this->rmrf(CLIENT_SYSLOG_DIR);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_SYSTEM_LOG, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'presentationMode') {
				$fileName = DEST_PATH . READFILE_CHKPRESENTATION_MODE;
				$OuGroupFile = DEST_PATH . READFILE_STROUGROUP;
				$adDbFile = DEST_PATH . READFILE_STRADSETTINGS;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PRESENTATION_MODEBY, $hostname);
					echo 'pmodesuccess';
					die;
				} else {
					unlink($fileName);
					if(file_exists($OuGroupFile)) {
						unlink($OuGroupFile);
					}
					if(file_exists($adDbFile)) {
						unlink($adDbFile);
					}
					// added by ashu on 6Sept2017 for reset chat,Participant and poll			
					unlink(DEST_PATH . 
						   FILE_CHAT);
					$featureStr = 'feature6=0,feature8=0';
					$advanceConfigData = array('feature6' => 0,
											   'feature8' => 0);
					$advanceMoreFeaturesData = array('ivalue' => 0,
													);
					$advanceMoreFeaturesWhere = array('property_name' => 'ModFeatEnable');
					$this->getAdvanceConfigurationTable()->updateFeatures($advanceConfigData);
					$this->getAdvanceMoreFeaturesTable()->updateFeatures($advanceMoreFeaturesData, $advanceMoreFeaturesWhere);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PRESENTATION_MODEBY, $hostname);
					echo 'pmodesuccess';
					die;
				}
			}
			if($selChkBoxName == 'appendPresentationMode') {
				$fileName = DEST_PATH . READFILE_CHKPRESENTATION_MODE;
				if($chkBoxVal == 3) {
					$advanceMoreFeaturesData = array('ivalue' => 0,
													);
					$advanceMoreFeaturesWhere = array('property_name' => 'ModFeatEnable');
					$this->getAdvanceMoreFeaturesTable()->updateFeatures($advanceMoreFeaturesData, $advanceMoreFeaturesWhere);
				}
				if(file_exists($fileName)) {
					unlink($fileName);
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $chkBoxVal;
					$confWrite = fwrite($myfile, $content);
					echo 'File Updated';
					die;
				}
			}
			if($selChkBoxName == 'mediaMode') {
				$fileName = DEST_PATH . READFILE_MEDIA;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_MEDIA_MODEBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_MEDIA_MODEBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'quickClientAccess') {
				$fileName = DEST_PATH . READFILE_QUICK;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_CLIENT_ACCESSBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_CLIENT_ACCESSBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'showSecondDisplay') {
				$fileName = DEST_PATH . READFILE_SECOND_DISPLAY;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_SECOND_DISPLAYBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_SECOND_DISPLAYBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'refreshTime') {
				$fileName = DEST_PATH . READFILE_REFRESHTIME;
				if(file_exists($fileName)) {
					unlink($fileName);
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $chkBoxVal;
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Apply';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_REFRESH_TIMEBY, $hostname);
					echo 'File Updated';
					die;
				} else {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $chkBoxVal;
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Apply';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_REFRESH_TIMEBY, $hostname);
					echo 'File Created';
					die;
				}
			}
			if($selChkBoxName == 'resetPIPSettings') {
				$fileName = DEST_PATH . $chkBoxVal;
				if(file_exists($fileName)) {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PIP_SETTINGBY, $hostname);
					echo 'File Updated';
					die;
				} else {
					echo "No File";
					die;
				}
			}
			if(($selChkBoxName == 'groupBased')||($selChkBoxName == 'ouBased')) {
				$fileName = DEST_PATH . READFILE_STROUGROUP;
				if(file_exists($fileName)) {
					unlink($fileName);
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $chkBoxVal;
					$confWrite = fwrite($myfile, $content);
					echo 'File Updated';
					die;
				} else {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $chkBoxVal;
					$confWrite = fwrite($myfile, $content);
					echo 'File Created';
					die;
				}
			}
			if($selChkBoxName == 'applyADSettings') {
				$AppObject = new ApplicationController();
				$fileName = DEST_PATH . READFILE_STRADSETTINGS;
				list($adDomain, $adModerator, $adParticipant, $accRadioBtnval)= explode(",", $chkBoxVal);
				$adDomain = $AppObject->strip_xss(trim($adDomain));
				$adParticipant = $AppObject->strip_xss(trim($adParticipant));
				$adModerator = $AppObject->strip_xss(trim($adModerator));
				$accRadioBtnval = $AppObject->strip_xss(trim($accRadioBtnval));
				$newStr = $adDomain . "\r\n" . $adModerator . "\r\n" . $adParticipant . "\r\n" . $accRadioBtnval;
				$actionTaken = 'Apply';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_AD_SETTINGBY, $hostname);
				if(file_exists($fileName)) {
					unlink($fileName);
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $newStr;
					$confWrite = fwrite($myfile, $content);
					echo 'settingApply';
					die;
				} else {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $newStr;
					$confWrite = fwrite($myfile, $content);
					echo 'settingApply';
					die;
				}
			}
			if($selChkBoxName == 'deleteAuthenticationFiles') {
				$fileName1 = DEST_PATH . READFILE_STROUGROUP;
				$fileName2 = DEST_PATH . READFILE_STRADSETTINGS;
				if(file_exists($fileName1)) {
					unlink($fileName1);
					echo 'File1 Deleted';
					die;
				}
				if(file_exists($fileName2)) {
					unlink($fileName2);
					echo 'File2 Deleted';
					die;
				}
			}
			if($selChkBoxName == 'activateEnergySaver') {
				$fileName = DEST_PATH . FILE_ENERGYSAVER_MODE;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = 10;
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ENERGY_SAVER_MODEBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ENERGY_SAVER_MODEBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'hdmiInputNotStart') {
				$fileName = DEST_PATH . FILE_NOPIP;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_HDMI_INPUTBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_HDMI_INPUTBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'show24hourFormat') {
				$fileName = DEST_PATH . FILE_STR24HOUR_FORMAT;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$data = array('24HoursFormat' => 1);
					$this->getDisplaySettingsTable()->updateSettings($data);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_CONFIG_24HRS_FORMATBY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$data = array('24HoursFormat' => 0);
					$this->getDisplaySettingsTable()->updateSettings($data);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_CONFIG_24HRS_FORMATBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'setDateFormat') {
				$fileName = DEST_PATH . FILE_DATEFORMAT;
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $chkBoxVal);
				$actionTaken = 'Apply';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DATE_FORMATBY, $hostname);
				echo 'File Created';
				die;
			}
			if($selChkBoxName == 'setTimeFormat') {
				$fileName = DEST_PATH . FILE_TIMEFORMAT;
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $chkBoxVal);
				$actionTaken = 'Apply';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_TIME_FORMATBY, $hostname);
				echo 'File Created';
				die;
			}
			if($selChkBoxName == 'setAMPM') {
				$fileName = DEST_PATH . FILE_TIMEAMPM;
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $chkBoxVal);
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_TIME_AMPMBY, $hostname);
				echo 'File Created';
				die;
			}
			// added on 21stApril 15
			if($selChkBoxName == 'activateDNDChkbox') {
				$fileName = DEST_PATH . FILE_DND;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DND_BY, $hostname);
					echo 'File Created';
					die;
				} else {
					unlink($fileName);
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DND_BY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'activateChatChkbox') {
				$fileName = DEST_PATH . FILE_CHAT;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $chkBoxVal;
					$confWrite = fwrite($myfile, $content);
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
				}
				$actionTaken = 'Activate';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_CHAT_BY, $hostname);
				echo 'File Created';
				die;
			}
			if($selChkBoxName == 'dynamicLayoutChkbox') {
				$fileName = DEST_PATH . FILE_DYNAMICLAYOUT;
				if($chkBoxVal == 0) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DYNAMIC_LAYOUT_BY, $hostname);
					echo 'File Created';
					die;
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DYNAMIC_LAYOUT_BY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'activateThrdPartyShortcutChkbox') {
				$fileName = DEST_PATH . FILE_THIRDPARTYSHORTCUT;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_THIRD_PARTY_SHORCUT, $hostname);
					echo 'File Created';
					die;
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_THIRD_PARTY_SHORCUT, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'activateDisableOnTopChkbox') {
				$fileName = DEST_PATH . FILE_DISABLE_ONTOP;
				if($chkBoxVal == 0) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DISABLED_ON_TOPBY, $hostname);
					echo 'File Created';
					die;
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DISABLED_ON_TOPBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'qrTopChkbox') {
				$fileName = DEST_PATH . FILE_QRTOP;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ACTIVATE_QR_TOPBY, $hostname);
					echo 'File Created';
					die;
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DEACTIVATE_QR_TOPBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'qrBypassChkbox') {
				$fileName = DEST_PATH . FILE_QRBYPASS;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ACTIVATE_QR_BYPASSBY, $hostname);
					echo 'File Created';
					die;
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DEACTIVATE_QR_BYPASSBY, $hostname);
					echo 'File Deleted';
					die;
				}
			}
			if($selChkBoxName == 'qrCodeChkbox') {
				$fileName = DEST_PATH . FILE_QRCODE;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "";
					$confWrite = fwrite($myfile, $content);
					// write bycode file when qrcode check
					$fileName1 = DEST_PATH . FILE_QRBYPASS;
					$myfile1 = fopen($fileName1, 'w')or die("can't open file");
					$confWrite1 = fwrite($myfile1, '');
					$actionTaken = 'Activate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ACTIVATE_QR_CODEBY, $hostname);
					echo(file_exists(DEST_PATH . $qrcodeFile)== 1 && $check_qrcodeImage == 1)? 'qrcodeEnable' : 'qrcodeDisable';
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
					//delete bypass file
					if(file_exists(DEST_PATH . FILE_QRBYPASS)) {
						unlink(DEST_PATH . 
							   FILE_QRBYPASS);
					}
					if(file_exists(DEST_PATH . FILE_QRTOP)) {
						unlink(DEST_PATH . 
							   FILE_QRTOP);
					}
					//added on 25Oct16 for deleting qrpoint.txt file
					if(file_exists(DEST_PATH . FILE_QRPOINT)) {
						unlink(DEST_PATH . 
							   FILE_QRPOINT);
					}
					$actionTaken = 'Deactivate';
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_DEACTIVATE_QR_CODEBY, $hostname);
					echo 'qrcodeDisable';
					die;
				}
			}
			// added on 21April2017 for participant preseent settings
			if($selChkBoxName == 'participantConfChkbox') {
				$data = array('feature6' =>$chkBoxVal);
				$setActivity = $this->getDisplaySettingsTable()->updateSettings($data);
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PRESENTATION_MODEBY, $hostname);
				echo 'File Created';
				die;
			}
			// added on 05Jan2019 for disable all feature settings by moderator
			if($selChkBoxName == 'disableAllFeaturesChkbox') {
				$advanceMoreFeaturesData = array('ivalue' =>$chkBoxVal,
												);
				$advanceMoreFeaturesWhere = array('property_name' => 'ModFeatEnable');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advanceMoreFeaturesData, $advanceMoreFeaturesWhere);
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_ALL_DISABLEBY, $hostname);
				echo 'File Created';
				die;
			}
		}
	}
	//Ajax for ios mirroring ON-OFF - Added by Ranjan
	public function enableDisabledMirrorFilesAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
                $AppObj = new ApplicationController();
		if($request->isXmlHttpRequest()) {
			$keyword = trim($request->getPost('keyword'));
			$AppObject = new ApplicationController();
			$fileName1 = DEST_PATH . FILE_MIRRORNAME;
			$fileName2 = DEST_PATH . FILE_MIRROR_MAXCON;
			if(GET_OS == 'WIN') {
				$last4digit =(CHECK_SERIALNO_FILE == 1)? '_' . substr($AppObject->file_read(DEST_PATH . SERIALNO_FILE), - 4): '';
			}
			$gwayMacAddr = "";
			if(GET_OS == 'LIN') {
				$gwayMacAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
				$last4digit =($gwayMacAddr != "")? '_' . substr(str_replace(':', '', $gwayMacAddr), - 4): '';
			}
			if($keyword == 'create') {
				$myfile1 = fopen($fileName1, 'w')or die("can't open file");
				$confWrite1 = fwrite($myfile1, FILE_MIRRORNAME_TEXT . 
									 $last4digit);
				$myfile2 = fopen($fileName2, 'w')or die("can't open file");
				$confWrite1 = fwrite($myfile2, FILE_MIRROR_MAX_CONN);
				$actionTaken = 'Activate';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_CONFIG_IOS_MIRRORBY, $hostname);
				echo trim(FILE_MIRRORNAME_TEXT . 
						  $last4digit);
				die;
			}
			if($keyword == 'delete') {
				unlink($fileName1);
				unlink($fileName2);
				$actionTaken = 'Deactivate';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_CONFIG_IOS_MIRRORBY, $hostname);
				echo 'success';
				die;
			}
			if($keyword == 'newMirrorSettings') {
				$mirrorName = $AppObject->strip_xss(trim($_POST['mirrorName']));
				$maxNoOfMirrors = trim($_POST['maxNoOfMirrors']);
				$myfile1 = fopen($fileName1, 'w')or die("can't open file");
				$confWrite1 = fwrite($myfile1, $mirrorName);
				$myfile2 = fopen($fileName2, 'w')or die("can't open file");
				$confWrite1 = fwrite($myfile2, $maxNoOfMirrors);
				$actionTaken = 'Apply';
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_CONFIG_IOS_MIRRORBY, $hostname);
				echo 'success';
				die;
			}
		}
	}
	//VIA Setting Advance configuration Ajax - Added by Ranjan
	public function advancedConfigurationAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$selChkBoxName = trim($request->getPost('chkBoxName'));
			$chkBoxVal = trim($request->getPost('chkBoxVal'));
			$AppObject = new ApplicationController();
			if($selChkBoxName == 'clearCloud') {
				$clearCloudData = array('feature1' =>$chkBoxVal,'feature3' => 0,'last_updated' => date("Y-m-d h:i:s"));
				if($chkBoxVal == 1) {
					$this->getAdvanceConfigurationTable()->updateFeatures($clearCloudData);
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_ACTIVATED_CLEAR_CLOUD, $hostname);
					echo 'success';
					die;
				} else {
					$this->getAdvanceConfigurationTable()->updateFeatures($clearCloudData);
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Deactivate', MSG_DEACTIVATED_CLEAR_CLOUD, $hostname);
					echo 'success';
					die;
				}
			}
			if($selChkBoxName == 'setWhiteBoardOptions') {
				$whiteBoardData = array('feature3' =>$chkBoxVal,
										'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($whiteBoardData);
				echo 'success';
				die;
			}
			if($selChkBoxName == 'audioConfigBox') {
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetAudioDevice</Cmd><P1>$chkBoxVal</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$return = $AppObject->returnSocketData($logincmd, $actionCmd);
				$explode = explode("|", $return);
				$strValue = $explode[1];
				if($strValue == 1) {
					echo 'successAndReboot';
				} else {
					echo 'unsuccess';
				}
				
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_AUDIO_CONFIGBY, $hostname);
				//echo 'successAndReboot';
				die;
			}
			//set audio Input device
			if($selChkBoxName == 'audioInConfigBox') {
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetAudioInputDevice</Cmd><P1>$chkBoxVal</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$return = $AppObject->returnSocketData($logincmd, $actionCmd);
				$explode = explode("|", $return);
				$strValue = $explode[1];
				if($strValue == 1) {
					echo 'successAndReboot';
				} else {
					echo 'unsuccess';
				}
				
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_AUDIO_IN_CONFIGBY, $hostname);
				//echo 'successAndReboot';
				die;
			}
			
			
			if($selChkBoxName == 'timezoneConfigBox') {
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetTimeZone</Cmd><P1>$chkBoxVal</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$return = $AppObject->returnSocketData($logincmd, $actionCmd);
				$explode = explode("|", $return);
				if(isset($explode[1])) {
					$strValue = $explode[1];
					if($strValue == 1) {
						echo 'successAndReboot';
					} else {
						echo 'unsuccess';
					}
				} else {
					echo 'unsuccess';
				}
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_TIMEZONE_CONFIGBY, $hostname);
				die;
			}
			if($selChkBoxName == 'dpiConfigBox') {
				$dpiFileOpen = fopen(DEST_PATH . FILE_DPI, 'w')or die("can't open file");
				fwrite($dpiFileOpen, $chkBoxVal);
				$dpiConfigData = array('feature2' =>$chkBoxVal,'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($dpiConfigData);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_TIMEZONE_CONFIGBY, $hostname);
				echo 'successAndReboot';
				die;
			}
			//sleeptime
			if($selChkBoxName == 'sleeptime') {
				$sleeptimeFileOpen = fopen(DEST_PATH . FILE_ENERGYSAVER_MODE, 'w')or die("can't open file");
				fwrite($sleeptimeFileOpen, $chkBoxVal);
				echo 'successAndReboot';die;
			}
			//Recording Configuration
			if($selChkBoxName == 'setRecordingConfiguration') {
				$recordingConfigurationData = array('feature4' =>$chkBoxVal,'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($recordingConfigurationData);
				if($chkBoxVal == 1) {
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_RECORDINGBY, $hostname);
				} else {
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Deactivate', MSG_SET_RECORDINGBY, $hostname);
				}
				// added on 17May2017 for sending command to api server in case of recording off
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>ForceStopRecord</Cmd><P1>$loginName</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$AppObject->sendMsgToAPIserver($logincmd, $actionCmd);
				echo 'successAndReboot';
				die;
			}
			//Streaming Configuration. added for 2.2 and updated on 19May2017
			if($selChkBoxName == 'setStramingConfiguration') {
				$url1 = trim($_POST['url1']);
				$url2 = trim($_POST['url2']);
				if($chkBoxVal == 1) {
					$countStreamingRows = $this->getStreamingSettingsTable()->countRows();
					$stramingData = array('display_url_1' =>$url1,'display_url_2' =>$url2,'status' =>$chkBoxVal);
					if($countStreamingRows > 0) {
						$this->getStreamingSettingsTable()->updateStreaming($stramingData);
					} else {
						$this->getStreamingSettingsTable()->insertStreaming($stramingData);
					}
				} else {
					$stramingStatusData = array('status' =>$chkBoxVal);
					$this->getStreamingSettingsTable()->updateStreaming($stramingStatusData);
					// added on 17May2017 for sending command to api server in case of streaming off
					$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>ForceStopStream</Cmd><P1>$loginName</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$AppObject->sendMsgToAPIserver($logincmd, $actionCmd);
				}
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_STREAMINGBY, $hostname);
				//echo 'successAndReboot';
				die;
			}
			//Polling Configuration. added for 2.2
			if($selChkBoxName == 'setPollingConfiguration') {
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				$PollingConfigurationData = array('feature8' =>$chkBoxVal,'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($PollingConfigurationData);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_POLL_BY, $hostname);
				echo 'successAndReboot';
				die;
			}
			//chrome settings added for 2.2
			if($selChkBoxName == 'setChromeSettings') {
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				$chromeData = array('feature9' =>$chkBoxVal,'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($chromeData);
				$fileName = DEST_PATH . FILE_CHROMERUN;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w');
					$confWrite = fwrite($myfile, $chkBoxVal);
				} else {
					if(file_exists(DEST_PATH . FILE_CHROMERUN)) {
						unlink(DEST_PATH . 
							   FILE_CHROMERUN);
					}
				}
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_CHROME_BY, $hostname);
				echo 'successAndReboot';
				die;
			}
			//miracst settings added for 2.3
			if($selChkBoxName == 'setMiracastSettings') {
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				if($chkBoxVal == 0) {
					$session['mira_off'] = 1;
				}
				$miracastData = array('feature10' =>$chkBoxVal, 'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($miracastData);
				$fileName = DEST_PATH . FILE_MIRACAST;
				if($chkBoxVal == 1) {
					$myfile = fopen($fileName, 'w');
					$confWrite = fwrite($myfile, $chkBoxVal);
				} else {
					unlink(DEST_PATH . 
						   FILE_MIRACAST);
				}
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_MIRACAST_BY, $hostname);
				echo 'successAndReboot';
				die;
			}
		}
	}
	//VIA Setting Advance config Ajax - Added by Ranjan
	public function advancedMoreConfigurationAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$settingName = trim($request->getPost('settingName'));
			$settingVal = trim($request->getPost('settingVal'));
			$advancedMoreConfigArr = array('ivalue' =>$settingVal,'modifydatetime' => date("Y-m-d h:i:s"));
			// set reset session setting
			if($settingName == 'setResetSessionSettings') {
				$actionTaken =($settingVal == 1)? 'Activate' : 'Deactivate';
				$resetSessionWhere = array('property_name' => 'ResetSession');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $resetSessionWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, 'Reset session by', $hostname);
				echo 'successAndReboot';
				die;
			}
			// set JPEG/H264
			if($settingName == 'setjpegH264') {
				$setLogMode =($settingVal == 1)? 'Auto/H264 Mode by' : 'Jpeg Mode by';
				$jpegH264Where = array('property_name' => 'DspEncodeValue');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $jpegH264Where);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', $setLogMode, $hostname);
				//$logqry=mysql_query("insert into ActivityLogMaster(UserID,ActionTaken,ActivityDate,remarks,hostname) values('$name','$activatePowerOff',now(),'$setLogMode $name','$hostname')");			
				echo 'success';
				die;
			}
			//set audio level
			if($settingName == 'setAudioLevel') {
				$audioLevelWhere = array('property_name' => 'DefAudioSetting');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $audioLevelWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'Set Audio Level By', $hostname);
				echo 'success';
				die;
			}
			//set zoom
			if($settingName == 'ZoomSettings') {
				$zoomWhere = array('property_name' => 'Zoom');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $zoomWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'Zoom Setting By', $hostname);
				echo 'success';
				die;
			}
			//set blueJeans
			if($settingName == 'BlueJeansSettings') {
				$blueJeansWhere = array('property_name' => 'BlueJeans');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $blueJeansWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'BlueJeans Setting By', $hostname);
				echo 'success';
				die;
			}
			if($settingName == 'setmiracastFrequency') {
				$miracastFrequencyFile = fopen(DEST_PATH . 'wifi/' . FILE_MIRACAST_FREQUENCY, 'w')or die("can't open file");
				$confWrite = fwrite($miracastFrequencyFile, $settingVal);
				fclose($confWrite);
				$setLogMode =($settingVal == 5)? $frequencytxt . ' ' . $frequency5Ghztxt . ' ' . $byTxt : $frequencytxt . ' ' . $frequency2point4Ghztxt . ' ' . $byTxt;
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', $setLogMode, $hostname);
				echo 'success';
				die;
			}
			if($settingName == 'DefHDMIMod') {
				$defHDMIModWhere = array('property_name' => 'DefHDMIMod');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $defHDMIModWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'HDMI Auto switch by', $hostname);
				if($settingVal == 1) {
					$HdmiFile = fopen(DEST_PATH . FILE_HDMIMODE, 'w')or die("can't open file");
				} else {
					unlink(DEST_PATH . FILE_HDMIMODE);
				}
				echo 'hdmimode';
				die;
			}
                        //set MSTeams
			if($settingName == 'MSTeams') {
				$MSTeamsWhere = array('property_name' => 'MSTeams');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $MSTeamsWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'MSTeams Setting By', $hostname);
				echo 'success';
				die;
			}
                        
                        //Close all Third party Apps
			if($settingName == 'TPCollabAppClose') {
				$TPCollabAppCloseWhere = array('property_name' => 'TPCollabAppClose');
				$this->getAdvanceMoreFeaturesTable()->updateFeatures($advancedMoreConfigArr, $TPCollabAppCloseWhere);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'Close all action tiles By', $hostname);
				echo 'success';
				die;
			}
		}
	}
	//Apply All file Ajax - Added by Ranjan
	public function applyDefaultFileTypeConfigAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		//sort(ARR_DEFAULT_FILE_TYPES);
		//restrict jpeg/jpg/pdf/png
		$this->getAuthFileFormatTable()->updateStatus(1);
		$allFilesSql = $this->getAuthFileFormatTable()->fetchAll();
		$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'All file set by', $hostname);
		echo implode(',', $allFilesSql);
		die;
	}
	//Apply Selected file Ajax - Added by Ranjan
	public function applySelectedFileTypeConfigAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$textareaValues = trim($request->getPost('textareaValues'));
			$this->getAuthFileFormatTable()->updateStatus(0);
			$textareaValuesArr = explode(',', $textareaValues);
			$customFileString = '';

			foreach($textareaValuesArr as $fileValues) {
				$customFileString .= "'" . $fileValues . "'" . ',';
			}
			$customFileString = substr($customFileString, 0, - 1);
			$this->getAuthFileFormatTable()->updateSelectedFileStatus(1, $customFileString);
			$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'Selected file set by', $hostname);
			echo 'success';
			die;
		}
	}
	//Add custom file Ajax - Added by Ranjan
	public function addCustomFileTypesAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$chkBoxVal = trim($request->getPost('chkBoxVal'));
                        $textareaValues = trim($request->getPost('textareaValues'));	
			if($chkBoxVal == 1) {
				$existValuesArr = array();
				$textareaValuesArr = array_unique(explode(',', $textareaValues));
				$customFileString = '';

				foreach($textareaValuesArr as $fileValues) {
					$customFileString .= "'" . $fileValues . "'" . ',';
				}
				$customFileString = substr($customFileString, 0, - 1);
				// get existing filetype list
				$getFileSql = $this->getAuthFileFormatTable()->fetchFileFormatWithoutStatus($customFileString);
				if($getFileSql != 0) {

					foreach($getFileSql as $fetchData) {
						$existValuesArr[] = $fetchData;
						$existValuesString .= $fetchData . ",";
					}
					$finalexistValuesString = rtrim($existValuesString, ",");
				}
                                
				foreach($textareaValuesArr as $myVal) {
					if($myVal != '') {
						if(!in_array($myVal, $existValuesArr)) {
							$newFormatArr = array('fileformat' =>$myVal,'formatstatus' => '0');
							$this->getAuthFileFormatTable()->addNewFileFormat($newFormatArr);
						}
					}
				}
			}
			$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Add', 'Add new file type by', $hostname);
			if(count($existValuesArr)> 0) {
				echo $finalexistValuesString;
			}
			echo '#@#@#';
			$fileFormatArr = $this->getAuthFileFormatTable()->fetchAllFileFormat();
			foreach($fileFormatArr as $dataArr){
				if(in_array($dataArr['FileFormat'],ARR_DEFAULT_FILE_TYPES)){
						$checkFileType='default';
						$mark='';
				}else{
						$filetypeVal='user';
						$checkFileType='userDefined';
						$mark='*';
				}
				$checked = ($dataArr['formatstatus']==1)?"checked":"";
				$filetype = ($mark!='')?'<span class="note pointer '.$checkFileType.'" rev="'.$dataArr['FileFormat'].'"><a href="#" class="active" data-toggle="class">&nbsp;<i class="fa fa-times text-dark"></i></a></span>':'';
				if($checkFileType=='userDefined'){
					echo '<div class="col-lg-3" style="height:30px;"><div class="no-padder" style="border:1px solid;border-radius: 25px;border-color:whitesmoke;" id="chk_"'.$dataArr["FileFormat"].'"><td><input type="checkbox" name="fileType" id="'.$dataArr['FileFormat'].'" value="'.$dataArr['FileFormat'].'" rev="'.$checkFileType.'" class="fileTypeChkboxCss" '.$checked.' /><label for="'.$dataArr['FileFormat'].'"><span style="vertical-align:top;"></span>'.$dataArr['FileFormat'].'</label>'.$filetype.'</div></div>';
				} else{
					echo '<div class="col-lg-3"><div class="no-padder" id="chk_'.$dataArr['FileFormat'].'" style="height:30px;"><td><input type="checkbox" name="fileType" id="'.$dataArr['FileFormat'].'" value="'.$dataArr['FileFormat'].'" rev="'.$checkFileType.'" class="fileTypeChkboxCss" '.$checked.'/><label for="'.$dataArr['FileFormat'].'"><span style="vertical-align:top;"></span>'.$dataArr['FileFormat'].'</label>'.$filetype.'</div></div>';
				}	
			}
			die;
		}
	}
	//Delete custom file Ajax - Added by Ranjan
	public function deleteCustomFileTypesAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$chkBoxVal = trim($request->getPost('chkBoxId'));
			$this->getAuthFileFormatTable()->deleteFileFormat(array('FileFormat' => $chkBoxVal));
			$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Delete', 'Delete file type by', $hostname);
			$fileFormatArr = $this->getAuthFileFormatTable()->fetchAllFileFormat();
			foreach($fileFormatArr as $dataArr){
				if(in_array($dataArr['FileFormat'],ARR_DEFAULT_FILE_TYPES)){
						$checkFileType='default';
						$mark='';
				}else{
						$filetypeVal='user';
						$checkFileType='userDefined';
						$mark='*';
				}
				$checked = ($dataArr['formatstatus']==1)?"checked":"";
				$filetype = ($mark!='')?'<span class="note pointer '.$checkFileType.'" rev="'.$dataArr['FileFormat'].'"><a href="#" class="active" data-toggle="class">&nbsp;<i class="fa fa-times text-dark"></i></a></span>':'';
				if($checkFileType=='userDefined'){
					echo '<div class="col-lg-3" style="height:30px;"><div class="no-padder" style="border:1px solid;border-radius: 25px;border-color:whitesmoke;" id="chk_"'.$dataArr["FileFormat"].'"><td><input type="checkbox" name="fileType" id="'.$dataArr['FileFormat'].'" value="'.$dataArr['FileFormat'].'" rev="'.$checkFileType.'" class="fileTypeChkboxCss" '.$checked.' /><label for="'.$dataArr['FileFormat'].'"><span style="vertical-align:top;"></span>'.$dataArr['FileFormat'].'</label>'.$filetype.'</div></div>';
				} else{
					echo '<div class="col-lg-3"><div class="no-padder" id="chk_'.$dataArr['FileFormat'].'" style="height:30px;"><td><input type="checkbox" name="fileType" id="'.$dataArr['FileFormat'].'" value="'.$dataArr['FileFormat'].'" rev="'.$checkFileType.'" class="fileTypeChkboxCss" '.$checked.'/><label for="'.$dataArr['FileFormat'].'"><span style="vertical-align:top;"></span>'.$dataArr['FileFormat'].'</label>'.$filetype.'</div></div>';
				}	
			}
			die;
		}
	}
	//Api command setting Ajax - Added by Ranjan
	public function applyApiCmdAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$getApiCmdBtnval = trim($request->getPost('getApiCmdBtnval'));
			$apiCmdData = array('feature5' =>$getApiCmdBtnval,'last_updated' => date("Y-m-d h:i:s"));
			$this->getAdvanceConfigurationTable()->updateFeatures($apiCmdData);
			$setLogMode =($getApiCmdBtnval == 1)? 'Activated Secure Mode by' : 'Activated Non Secure Mode by';
			$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', $setLogMode, $hostname);
			echo 'success';
			die;
		}
	}
	//Transfer recording Ajax - Added by Ranjan
	public function transferRecordingAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$optValue = trim($request->getPost('optValue'));
			//Recording Configuration
			$tranferArr = array('transfer_option' =>$optValue);
			$this->getRecordingTransferTable()->updateRecording($tranferArr);
			if($optValue == "system_default") {
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Set Recording', 'Set recording to System Default by', $hostname);
				echo 'success';
				die;
			}
			if($optValue == "usb") {
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Set Recording', 'Set recording to USB by', $hostname);
				echo 'success';
				die;
			}
			if($optValue == "cloud") {
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Set Recording', 'Set recording to cloud by', $hostname);
				echo 'success';
				die;
			}
			if($optValue == "vsm") {
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Set Recording', 'Set recording to VSM by', $hostname);
				echo 'success';
				die;
			}
		}
	}
	//Display layout Ajax - Added by Ranjan
	public function setDisplayLayoutAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$optName = trim($request->getPost('optName'));
			$fileName = DEST_PATH . FILE_LAYOUT;
			if(CHECK_FILE_LAYOUT == 1) {
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $optName);
			} else {
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $optName);
			}
			// added on 6Sept 2017 for reset Auto-Hide Thumbnails	
			if($optName == 0) {
				$myfileAutoHide = fopen(DEST_PATH . FILE_DYNAMICLAYOUT, 'w')or die("can't open file");
				$confWriteAutoHideCont = fwrite($myfileAutoHide, '');
				fclose($confWriteAutoHideCont);
			}
			fclose($myfile);
			$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', 'Display Layout set by', $hostname);
			echo 'success';
			die;
		}
	}
	//Set language Ajax - Added by Ranjan
	public function setLanguageAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$langName = trim($request->getPost('langName'));
			$AppObject = new ApplicationController();
			$fileName = DEST_PATH . FILE_LANGTXT;
			if(CHECK_FILE_LANGTXT == 1) {
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $langName);
				// send command when language change on linux
				if(GET_OS == 'LIN') {
					$langStr = '';
					if($langName == 'zh')
						$langStr = "zh_CN.UTF-8";
					if($langName == 'en')
						$langStr = "en_US.UTF-8";
					if($langName == 'de')
						$langStr = "de_DE.UTF-8";
					if($langName == 'ja')
						$langStr = "ja_JP.UTF-8";
					if($langName == 'pl')
						$langStr = "pl_PL.UTF-8";
					if($langName == 'ru')
						$langStr = "ru_RU.UTF-8";
					if($langName == 'es')
						$langStr = "es_ES.UTF-8";
					if($langName == 'fr')
						$langStr = "fr_FR.UTF-8";
					if($langName == 'pt')
						$langStr = "pt_PT.UTF-8";
					if($langName == 'zh-TW')
						$langStr = "zh_TW.UTF-8";
					$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>ChangeLang</Cmd><P1>$langStr</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$AppObject->sendMsgToAPIserver($logincmd, $actionCmd);
				}
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_LANGBY, $hostname);
				echo 'success';
				die;
			}
		}
	}
	//Auto reboot Ajax - Added by Ranjan
	public function autoRebootAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$autoRebootChkBoxVal = trim($request->getPost('autoRebootChkBoxVal'));
			$concatVal = trim($request->getPost('concatVal'));
			$fileName = DEST_PATH . FILE_AUTO_REBOOT;
			if($autoRebootChkBoxVal == 1) {
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $concatVal);
				if($concatVal == "00:00") {
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_AUTO_REBOOTBY, $hostname);
					echo 'success';
					die;
				} else {
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Set Reboot Timing', MSG_SET_REBOOT_TIME_BY, $hostname);
					echo 'success';
					die;
				}
			} else {
				unlink($fileName);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Deactivate', MSG_AUTO_REBOOTBY, $hostname);
				echo 'success';
				die;
			}
		}
	}
	//Auto power off Ajax - Added by Ranjan
	public function autoPowerOffAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$autpPowerChkBoxVal = trim($request->getPost('autpPowerChkBoxVal'));
			$concatVal = trim($request->getPost('concatVal'));
			$fileName = DEST_PATH . FILE_AUTO_POWEROFF;
			if($autpPowerChkBoxVal == 1) {
				$myfile = fopen($fileName, 'w')or die("can't open file");
				$confWrite = fwrite($myfile, $concatVal);
				if($concatVal == "00:00") {
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_AUTO_POWEROFFBY, $hostname);
					echo 'success';
					die;
				} else {
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Set Power Off Timing', MSG_SET_POWER_TIME_BY, $hostname);
					echo 'success';
					die;
				}
			} else {
				unlink($fileName);
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Deactivate', MSG_AUTO_POWEROFFBY, $hostname);
				echo 'success';
				die;
			}
		}
	}
	//Proxy setting Ajax - Added by Ranjan
	public function proxySettingAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$poll_encryption_key = POLL_ENCRPTION_KEY;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$serverName = trim($request->getPost('servername'));
			$port = trim($request->getPost('port'));
			$username = trim($request->getPost('username'));
			$password = trim($request->getPost('password'));
			if($serverName != '') {
				$AppObj = new ApplicationController();
				$connection = $AppObj->getConnection();
				$query = $connection->execute("SELECT id FROM tbl_proxy_setting WHERE servername='" . $serverName . "'");
				$numRows = $query->count();
				if($numRows > 0) {
					$resData = $query->current();
					$id = $resData['id'];
					if($password != '')
                                            $connection->execute("UPDATE tbl_proxy_setting SET servername='" . $serverName . "', port=$port, username='" . $username . "', password=AES_ENCRYPT('$password','$poll_encryption_key'), createdate=NOW() WHERE id=$id");
					else 
                                            $connection->execute("UPDATE tbl_proxy_setting SET servername='" . $serverName . "', port=$port, username='" . $username . "', password='', createdate=NOW() WHERE id=$id");
				} else {
					$connection->execute("INSERT INTO tbl_proxy_setting(servername,port,username,password) values('" . $serverName . "',$port,'" . $username . "',AES_ENCRYPT('$password','$poll_encryption_key'))");
				}
				$this->getActivityLogMasterTable()->setActivity($loginName, 'Set', 'Proxy Setting by', $hostname);
				echo "success";
				die;
			}
		}
	}
	//Reset proxy setting Ajax - Added by Ranjan
	public function resetProxySettingAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$AppObj = new ApplicationController();
		$connection = $AppObj->getConnection();
		$sql = $connection->execute("SELECT id FROM tbl_proxy_setting");
		if($sql->count()> 0) {
			$connection->execute("DELETE FROM tbl_proxy_setting");
			$this->getActivityLogMasterTable()->setActivity($loginName, 'Reset', 'Proxy Setting by', $hostname);
			echo "success";die;
		} else {
			echo 'nodata';die;
		}
	}

	public function rmrf($dir) {

		foreach(glob($dir)as $file) {
			if(is_dir($file)) {
				$this->rmrf("$file/*");
				rmdir($file);
			} else {
				unlink($file);
			}
		}
	}
        
	public function getProxyData() {
		$AppObj = new ApplicationController();
		$connection = $AppObj->getConnection();
		$results = $connection->execute("SELECT servername,port,username,AES_DECRYPT(password,'" . POLL_ENCRPTION_KEY . "') as password FROM tbl_proxy_setting");
		$resData = $results->current();
		return $resData;
	}
        
        public function serverResetAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $flag = trim($request->getPost('flag'));
                $ip = trim($request->getPost('ip'));
                $port = trim($request->getPost('port'));
                if($flag=='resetnow'){ 
                    $input='resetnow';
                }
                $AppObj = new ApplicationController();
                $res=$AppObj->reboot_powerOff_Server($input);
                    if($res==1){
                        echo 'Reboot';die;
                }else{
                    echo 'Error';die;
                }
            }
        }

	//Ranjan
	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}

	public function getClientsFeaturesTable() {
		if(!$this->TblClientsFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
		}
		return $this->TblClientsFeaturesTable;
	}

	public function getDisplaySettingsTable() {
		if(!$this->TblDisplaySettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblDisplaySettingsTable = $sm->get('Webapp\Model\TblDisplaySettingsTable');
		}
		return $this->TblDisplaySettingsTable;
	}

	public function getTimezonesTable() {
		if(!$this->TblTimezonesTable) {
			$sm = $this->getServiceLocator();
			$this->TblTimezonesTable = $sm->get('Webapp\Model\TblTimezonesTable');
		}
		return $this->TblTimezonesTable;
	}

	public function getAdvanceConfigurationTable() {
		if(!$this->TblAdvanceConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationTable = $sm->get('Webapp\Model\TblAdvanceConfigurationTable');
		}
		return $this->TblAdvanceConfigurationTable;
	}

	public function getAdvanceMoreFeaturesTable() {
		if(!$this->TblAdvanceMoreFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceMoreFeaturesTable = $sm->get('Webapp\Model\TblAdvanceMoreFeaturesTable');
		}
		return $this->TblAdvanceMoreFeaturesTable;
	}

	public function getAuthFileFormatTable() {
		if(!$this->TblAuthFileFormatTable) {
			$sm = $this->getServiceLocator();
			$this->TblAuthFileFormatTable = $sm->get('Webapp\Model\TblAuthFileFormatTable');
		}
		return $this->TblAuthFileFormatTable;
	}

	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}

	public function getStreamingSettingsTable() {
		if(!$this->TblStreamingSettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblStreamingSettingsTable = $sm->get('Webapp\Model\TblStreamingSettingsTable');
		}
		return $this->TblStreamingSettingsTable;
	}

	public function getRecordingTransferTable() {
		if(!$this->TblRecordingTransferTable) {
			$sm = $this->getServiceLocator();
			$this->TblRecordingTransferTable = $sm->get('Webapp\Model\TblRecordingTransferTable');
		}
		return $this->TblRecordingTransferTable;
	}

	public function getProxySettingTable() {
		if(!$this->TblProxySettingTable) {
			$sm = $this->getServiceLocator();
			$this->TblProxySettingTable = $sm->get('Webapp\Model\TblProxySettingTable');
		}
		return $this->TblProxySettingTable;
	}

	public function getTemplatesTable() {
		if(!$this->TblTemplatesTable) {
			$sm = $this->getServiceLocator();
			$this->TblTemplatesTable = $sm->get('Webapp\Model\TblTemplatesTable');
		}
		return $this->TblTemplatesTable;
	}
        
        
}
