<?php
  /*****
  * Name    : WebserviceController
  * Desc    : Validate and save vsm from via
  *****/
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Webapp\Controller\ApplicationController;
use Zend\View\Model\ViewModel;

use Zend\Session\Container; // for session
use Zend\Mvc\MvcEvent;

class WebserviceController extends AbstractActionController
{	
    
	//List the gateway which have been schedule for update
	public function webserviceResponseAction(){
		if(isset($_GET['gwayBoxId'])) $gwayBoxId=$_GET['gwayBoxId'];
		if(isset($_GET['macAddr']))  $gwayMacAddr=$_GET['macAddr'];
		if(isset($_GET['fVersion'])) $fVersion=explode(".",$_GET['fVersion']); //get the version 13-sept-2017
		$appObj = new ApplicationController();
		
		$where = array('DeviceID' => $gwayBoxId);
		$sqlQry = $this->getDeviceInventoryTable()->getData($where);
		$count = $sqlQry->count();
		if($count>0){
			$row = $sqlQry->current();
			$hqGwayBoxID = $row['DeviceID'];
			$hqMacAddr = $row['MacAddress'];
			$did = $row['DID'];
			// added by ashu to reset tbl_sys_report table
			$appObj->executeQueries("UPDATE tbl_sys_report SET setting_version='-1',client_version='-1',wallpaper_status=0,clientFeaturesStatus=0,configSettingStatus=0,dateTimeSettingStatus=0,authSettingStatus=0,mobileFeaturesStatus=0,Last_Updated_Time=NOW() WHERE did_fk IN (SELECT DID FROM DeviceInventory WHERE DeviceID='$gwayBoxId')");
			//reset the DSS, Epolling,global setting(30-Jan-2018)
			$appObj->executeQueries("UPDATE tbl_advance_sys_report SET advanceConfigStatus=0,extraField1=0,extraField2=0,extraField3=0 WHERE did_fk IN (SELECT DID FROM DeviceInventory WHERE DeviceID='$gwayBoxId')");
			
			//Global Settings resynced when new gateway validated (Added Date 2-Apr-2019 By Dileep)
			$checkHostInfoExist = $appObj->returnQueryData("SELECT * from tbl_hosts_info_sync WHERE gateway_id_fk=$did");
			if($checkHostInfoExist->count() > 0){
				 $appObj->executeQueries("UPDATE tbl_hosts_info_sync SET status=0,modifydatetime=NOW() WHERE gateway_id_fk=$did");	
			}
			$checkSessionSettingExist = $appObj->returnQueryData("SELECT * from tbl_session_settings_sync WHERE gateway_id=$did");
			if($checkSessionSettingExist->count() > 0){
				 $appObj->executeQueries("UPDATE tbl_session_settings_sync SET status=0,updateddatetime=NOW() WHERE gateway_id=$did");	
			}
			
			//added on 22 Feb2019 for reset tbl_templates_mapping
			$appObj->executeQueries("UPDATE tbl_templates_mapping SET modifydatetime=NOW() WHERE isGrpIdOrDeviceId=$did AND entryType=1");
			
			//update the version and Status(Sept 5, 2019)
		    $this->getDeviceInventoryTable()->updateWhere(array('MacAddress' => '', 'oldIPAddess' => '', 'Version' => '-1'), array('DID' => $gwayBoxId));
		    $appObj->executeQueries("UPDATE tbl_device_live_status SET Network_status='-1',HD_Status='-1',CPU_Status='-1',firmware_process=0 WHERE did_fk=$gwayBoxId");
			
			if($gwayMacAddr==$hqMacAddr && $gwayBoxId==$hqGwayBoxID){
				$msg='assignedToSelf';
			}
			if($gwayBoxId==$hqGwayBoxID && $hqMacAddr==""){
				$msg="success";
			}
			if($hqMacAddr!=""){
				if($gwayMacAddr!=$hqMacAddr){
					$msg="assignedToOther";
				}
			}
		}else{
			$msg="failure";
		}
		echo $msg;die;
	}

	public function updBoxIDWebserviceRespAction(){
		if(isset($_GET['gwayBoxId'])) $gwayBoxId=$_GET['gwayBoxId'];
		if(isset($_GET['macAddr'])) $gwayMacAddr=$_GET['macAddr'];
		if(isset($_GET['takeAction'])) $takeAction=$_GET['takeAction'];
		$where = array('MacAddress' => $gwayMacAddr);
		if($takeAction == 'updateExistMac'){
			$sqlQry = $this->getDeviceInventoryTable()->getData($where);
			$count = $sqlQry->count();
			if($count>0){
				$this->getDeviceInventoryTable()->updateWhere(array('MacAddress' => ''), array('MacAddress' => $gwayMacAddr));
			}
			
			$this->getDeviceInventoryTable()->updateWhere(array('MacAddress' => $gwayMacAddr), array('DeviceID' => $gwayBoxId));
		}

		if($takeAction == 'updateBlankMac'){
			$sqlQry = $this->getDeviceInventoryTable()->getData($where);
			$count = $sqlQry->count();
			if($count>0){
				$this->getDeviceInventoryTable()->updateWhere(array('MacAddress' => ''), array('MacAddress' => $gwayMacAddr));
			}
			$this->getDeviceInventoryTable()->updateWhere(array('MacAddress' => $gwayMacAddr), array('DeviceID' => $gwayBoxId));

		}	
		echo 'success';die;
	}

	public function resetBoxIDWebserviceRespAction(){
		if(isset($_GET['gwayBoxId'])) $gwayBoxId=$_GET['gwayBoxId'];
		if(isset($_GET['macAddr']))  $gwayMacAddr=$_GET['macAddr'];
		$where = array('MacAddress' => $gwayMacAddr,'DeviceID'=>$gwayBoxId);
		$appObj = new ApplicationController();
		$sqlQry = $this->getDeviceInventoryTable()->getData($where);
		$count = $sqlQry->count();
		if($count>0){
			//adding oldIPAddess blank when reset gateway
			$this->getDeviceInventoryTable()->updateWhere(array('MacAddress' => '', 'oldIPAddess' => ''), array('DeviceID' => $gwayBoxId));
			// added by ashu to reset tbl_sys_report table
			$appObj->executeQueries("UPDATE tbl_sys_report SET web_version='-1',setting_version='-1',client_version='-1',wallpaper_status=2,clientFeaturesStatus=2,configSettingStatus=2,dateTimeSettingStatus=2,authSettingStatus=2,mobileFeaturesStatus=2,Last_Updated_Time=now() WHERE did_fk IN (SELECT DID FROM DeviceInventory WHERE DeviceID='$gwayBoxId')") or die(mysql_error());
			//change tbl_device_live_status data.
			$appObj->executeQueries("UPDATE tbl_device_live_status SET Network_status=0, HD_Status='-1', CPU_Status='-1' WHERE did_fk IN (SELECT DID FROM DeviceInventory WHERE DeviceID='$gwayBoxId')");		
			
			//reset the DSS, Epolling,global setting(30-Jan-2018)
			$appObj->executeQueries("UPDATE tbl_advance_sys_report SET advanceConfigStatus=2,extraField1=2,extraField2=2,extraField3=2 WHERE did_fk IN (SELECT DID FROM DeviceInventory WHERE DeviceID='$gwayBoxId')");
			
			//update the version (Sept 5, 2019)
			$this->getDeviceInventoryTable()->updateWhere(array('Version' => '-1'), array('DID' => $gwayBoxId));
		}
		echo 'success';die;
	}
	
	public function upgradeSettingTemplatesAction(){	
 			$appObj = new ApplicationController();
			$flag=trim($_POST['flag']);			
			$ntpJsonFile='upgrade_ntp.txt';
			$fileSharingJsonFile='upgrade_file_sharing.txt';			
			if(file_exists(UPLOAD_PATH_INTERNAL.$ntpJsonFile)){
				$strJsonNTP=file_get_contents(UPLOAD_PATH_INTERNAL.$ntpJsonFile);			
				$arrayJsonNTP = (array)json_decode($strJsonNTP);		
				foreach ($arrayJsonNTP as $key=>$value){ 				
				 $arrayJsonNTP[$key] = (array) $value;
				}	
				$ntpArray=array();
				foreach ($arrayJsonNTP as $ntp_key=>$ntp_value){ 
					$ntpArray[]=array("ntp_name"=>$ntp_value['ntp_name'],"ntp_uuid"=>$ntp_value['ntp_uuid']);
				}
			}		
			
			$fileSharing=trim($_POST['fileSharing']);
			if(file_exists(UPLOAD_PATH_INTERNAL.$fileSharingJsonFile)){
				$strJsonAuthFormats=file_get_contents(UPLOAD_PATH_INTERNAL.$fileSharingJsonFile);
				$arrayJsonAuthFormats = (array)json_decode($strJsonAuthFormats);
				foreach ($arrayJsonAuthFormats as $authFilekey=>$authFilevalue){ 				
					$arrayJsonAuthFile[$authFilekey] = (array) $authFilevalue;
				}
				$authFileArray=array();
				foreach ($arrayJsonAuthFile as $authfile_key=>$authfile_value){ 
					$authStstus=$authfile_value['status'];
					$authFileArray[]=array("ext_name"=>$authfile_value['ext_name'],"status"=>"$authStstus");
				}
					
			}
				
			$sysLog=(trim($_POST['sysLog'])!='')?trim($_POST['sysLog']):0;
			$energysaver=trim($_POST['energysaver']);
			$sleepTime=($energysaver==1)?trim($_POST['sleepTime']):"0";
			$quickClientAccess=(trim($_POST['quickClientAccess'])!='')?trim($_POST['quickClientAccess']):0;
			$apiCmd=trim($_POST['apiCmd']);
			$setLang=trim($_POST['setLang']);
			$broadcast=trim($_POST['broadcast']);
			
			$mirroring=trim($_POST['mirroring']);
			$chrome=trim($_POST['chrome']);
			$miracast=trim($_POST['miracast']);
			$frequency=trim($_POST['frequency']);
			$activateDNDChkbox=trim($_POST['activateDNDChkbox']);
			$resetSession=trim($_POST['resetSession']);	
			$encoding=(trim($_POST['encoding'])==1)?'h264':'jpeg';
			$autoPowerOff=trim($_POST['autoPowerOff']);			
			$selhoursdd=trim($_POST['selhoursdd']);
			$selminsdd=trim($_POST['selminsdd']);
			$autoPowerOffTime=($autoPowerOff==1)?$selhoursdd.':'.$selminsdd:'00:00';
			
			$autoReboot=trim($_POST['autoReboot']);
			$selAutoRebootHoursList=trim($_POST['selAutoRebootHoursList']);
			$selAutoRebootMinsList=trim($_POST['selAutoRebootMinsList']);
			$autoRebootTime=($autoReboot==1)?$selAutoRebootHoursList.':'.$selAutoRebootMinsList:'00:00';
			
			$autoPowerOn=trim($_POST['autoPowerOn']);
			$selAutoPowerOnHoursList=trim($_POST['selAutoPowerOnHoursList']);
			$selAutoPowerOnMinsList=trim($_POST['selAutoPowerOnMinsList']);
			$autoPowerOnTime=($autoPowerOn==1)?$selAutoPowerOnHoursList.':'.$selAutoPowerOnMinsList:'00:00';
			
			$selDateFormatDD=trim($_POST['selDateFormatDD']);
			$timezoneConfigBox=trim($_POST['timezoneConfigBox']);
			$winTimezoneConfigBox=trim($_POST['winTimezoneConfigBox']);
			$hdmiInputNotStart=trim($_POST['hdmiInputNotStart']);
			$pipMode=trim($_POST['pipMode']);
			$activateHDMIChkbox=trim($_POST['activateHDMIChkbox']);
			$manualOnOff=trim($_POST['manualOnOff']);
			$clearCloud=trim($_POST['clearCloud']);
			$closeWhiteBoardBtn=trim($_POST['closeWhiteBoardBtn']);
			
			$setDynamicLayout=trim($_POST['setDynamicLayout']);
			$dynamicLayoutChkbox=trim($_POST['dynamicLayoutChkbox']);
			$dpiConfigBox=trim($_POST['dpiConfigBox']);
			$logoutTime=trim($_POST['logoutTime']);
			$getCaptcha=trim($_POST['getCaptcha']);
			$getAlplhanumric=trim($_POST['getAlplhanumric']);
			$getSpecialChar=trim($_POST['getSpecialChar']);
			$getCaptLetter=trim($_POST['getCaptLetter']);
			
			$minimumChar=trim($_POST['minimumChar']);
			$getBasicModeFlag=trim($_POST['getBasicModeFlag']);
			$transferRecording=trim($_POST['transferRecording']);
			$getRecording=trim($_POST['getRecording']);
			$proxyServerName=trim($_POST['proxyServerName']);
			$proxyPort=trim($_POST['proxyPort']);
			$proxyUserName=trim($_POST['proxyUserName']);
			$proxyPassword=trim($_POST['proxyPassword']);
			$host_config=trim($_POST['host_config']);
			$via_certificate=trim($_POST['via_certificate']);
			$certificateKey=trim($_POST['certificateKey']);
			$audioOutput=trim($_POST['audioOutput']);
			$audioLevel=trim($_POST['audioLevel']);
			
			$zoomVal=trim($_POST['zoomVal']);
			$bluejeansVal=trim($_POST['bluejeansVal']);
			$msTeamVal=trim($_POST['msTeamVal']);
			$TPCollabAppCloseVal=trim($_POST['TPCollabAppCloseVal']);
			$thirdpartyapp=trim($_POST['thirdpartyapp']);
			$mediamode=trim($_POST['mediamode']);

			
			$collageGwayfeaturesStr=trim(substr($_POST['collageGwayfeaturesStr'],0,-1));
			$collageClientfeaturesStr=trim(substr($_POST['collageClientfeaturesStr'],0,-1));
			$collageMobfeaturesStr=trim(substr($_POST['collageMobfeaturesStr'],0,-1));
			
			$connectGwayfeaturesStr=trim(substr($_POST['connectGwayfeaturesStr'],0,-1));
			$connectClientfeaturesStr=trim(substr($_POST['connectClientfeaturesStr'],0,-1));
			$connectMobfeaturesStr=trim(substr($_POST['connectMobfeaturesStr'],0,-1));
			
			$campusGwayfeaturesStr=trim(substr($_POST['campusGwayfeaturesStr'],0,-1));
			$campusClientfeaturesStr=trim(substr($_POST['campusClientfeaturesStr'],0,-1));			
			$campusMobfeaturesStr=trim(substr($_POST['campusMobfeaturesStr'],0,-1));
			
			$viagoClientfeaturesStr=trim(substr($_POST['viagoClientfeaturesStr'],0,-1));
			$viagoMobfeaturesStr=trim(substr($_POST['viagoMobfeaturesStr'],0,-1));
			
			$connectplusGwayfeaturesStr=trim(substr($_POST['connectplusGwayfeaturesStr'],0,-1));			
			$connectplusClintfeaturesStr=trim(substr($_POST['connectplusClintfeaturesStr'],0,-1));
			$connectplusMobfeaturesStr=trim(substr($_POST['connectplusMobfeaturesStr'],0,-1));
			
			$moderatorString=trim($_POST['moderatorString']);
			$presentationMode=trim($_POST['collagePresentaionMode']);
			$moderator_type=trim($_POST['collageMode']);
			$collageParticipantConfChkbox=trim($_POST['collageParticipantConfChkbox']);
			$participantConfChkbox=trim($_POST['collageParticipantConfChkbox']);
			$wait_moderator=trim($_POST['collageDisableAllFeaturesChkbox']);
			$activateChatChkbox=trim($_POST['collageActivateChatChkbox']);
			$adDomain=trim($_POST['collageAdDomain']);
			$accountName=trim($_POST['collageAccName']);
			$group_ou=trim($_POST['collageOuGroupBased']);
			$moderatorValue=trim($_POST['collageAdModerator']);
			$participantValue=trim($_POST['collageAdParticipant']);			
			$viaAdminPassword=(trim($_POST['viaAdminPassword'])!='')?$appObj->securePassword(trim($_POST['viaAdminPassword'])):'';
			$viaBasicPassword=(trim($_POST['viaBasicPassword'])!='')?$appObj->securePassword(trim($_POST['viaBasicPassword'])):'';
			$templateName=trim($_POST['templateName']);
			$historyFlag="Create";
			$myFile = UPLOAD_DIR_ZEND."uploads/".TEMPLATE_DIR_CONFIG.$templateName.'.json';
			
			
			$arr =array(
			"VIA_CONFIG_TEMPLATE"=>array(
			"via_settings"=>array(
			"system"=>array(
			"system_logs"=>$sysLog,
			"energy_saver"=>array(
			"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>$broadcast,"thirdparty_app"=>$thirdpartyapp),		 			"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
			"chrome"=>$chrome,
			"miracast"=>array("status"=>$miracast,"band"=>$frequency),
			"dnd"=>$activateDNDChkbox,
			"reset_session"=>$resetSession,
			"encoding"=>$encoding,"mediamode"=>$mediamode),
			"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
			"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
			"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
			"file_sharing_settings"=>array("extensions"=>$authFileArray),
			'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
			"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
			"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
			"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
			"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
								
			"NTP"=>$ntpArray,
			"host_config"=>$host_config,
			"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
			"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
			),	
			"gway_features"=>array('4'=>$connectplusGwayfeaturesStr,'2'=>$campusGwayfeaturesStr,'1'=>$connectGwayfeaturesStr,'0'=>$collageGwayfeaturesStr),
			"client_features"=>array('4'=>$connectplusClintfeaturesStr,'3'=>$viagoClientfeaturesStr,'2'=>$campusClientfeaturesStr,'1'=>$connectClientfeaturesStr,'0'=>$collageClientfeaturesStr),
			"mobile_features"=>array('4'=>$connectplusMobfeaturesStr,'3'=>$viagoMobfeaturesStr,'2'=>$campusMobfeaturesStr,'1'=>$connectMobfeaturesStr,'0'=>$collageMobfeaturesStr),
			"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
			)
			);
			//echo"<pre>";print_r($arr);echo"<br>";
			//die($myFile);
			//die;
			//JSON_FORCE_OBJECT is sued to set numeric key 
			//$encodedData = json_encode($arr,JSON_FORCE_OBJECT);	
			$encodedData = json_encode($arr,true);	
			//encrypt json data		
			$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRYPTION_KEY);
			//file_put_contents($myFile.'decrypt.json', $encodedData);
			if(file_put_contents($myFile, $encryptedJson)) {
				//die('aa'.$checkCount);
				
				$dataArr=array('template_name'=>$templateName,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>'uploads/'.TEMPLATE_DIR_CONFIG,'modifydatetime'=>date('Y-m-d H:i:s'));
				//echo "<pre>";print_r($dataArr);die;
				$whereArr=array('template_name'=>$templateName);
				$checkCount=$this->getViaSettingsTemplatesTable()->checkTemplate($whereArr);
				if($checkCount==0)	{		
					$last_insert_id=$this->getViaSettingsTemplatesTable()->insertData($dataArr);
					$finalTemplateName="uploads/".TEMPLATE_DIR_CONFIG.'settings_'.$last_insert_id.'.json';			
					rename($myFile ,UPLOAD_DIR_ZEND.$finalTemplateName);
					$dataArr=array("template_path"=>"$finalTemplateName");
					$whrArr=array("id"=>$last_insert_id);
					//print_r($whrArr);die;
					$this->getViaSettingsTemplatesTable()->updateTableData($dataArr,$last_insert_id);	
					//echo 'success#'.$appObj->desEncrypt($templateName, KEY_SEED).'#'.$last_insert_id;
					//entry for all groups in tbl_via_settings_templates_mapping
					$deviceGroupData =$appObj->getTableAllData("devicegroup");					
					$value_array=array();
					$mappinyquery="INSERT INTO tbl_via_settings_templates_mapping (template_id,isGrpIdOrDeviceId,entryType,modifydatetime) VALUES ";	
					foreach($deviceGroupData as $deviceGroupVal){
						$grpId=$deviceGroupVal['DeviceGroupID'];
						 $modifydatetime=date("Y-m-d h:i:s");
						$value_array[] = "($last_insert_id, $grpId, 0, '".$modifydatetime."')";
					}
					$mappinyquery .= implode(',', $value_array);
					$appObj->executeQueries($mappinyquery);
					unlink(UPLOAD_PATH_INTERNAL.$ntpJsonFile);
					unlink(UPLOAD_PATH_INTERNAL.$fileSharingJsonFile);
					//unlink checkupdate.txt
					unlink(DEST_PATH.VSM_CHECK_UPDATE_FILE);
					//updating version hq_version.txt
					$exploadeWebVersion=explode('VIA Server Version W-',WEB_VERSION);
					$getwebVersion=$exploadeWebVersion[1];
					$vsmVersionFileName=SECOND_DEST_PATH.VSM_VERSION_FILE;
					$myfile = fopen($vsmVersionFileName, 'w') or die("can't open file -4 ");		
					$confWrite= fwrite($myfile, $getwebVersion);
					
					//remove duplicate groups
					//we can assign one template to multiple grp but not via versa						
					$appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE id NOT IN (SELECT * FROM (SELECT MAX(id) FROM tbl_templates_mapping GROUP BY isGrpIdOrDeviceId)x)");
					$appObj->executeQueries("DELETE FROM tbl_via_settings_templates_mapping WHERE id NOT IN (SELECT * FROM (SELECT MAX(id) FROM tbl_via_settings_templates_mapping GROUP BY isGrpIdOrDeviceId)x)");	
					//Checking default screen editor template is assigned on other groups except default. In this case we are overwrite existing default.json and  default.jpg with new default.json and default.jpg (according to 3.0 json and image)					
					//$checkDefaultTempAssigned = $appObj->returnQueryData("SELECT * FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId!=1");
					//if($checkDefaultTempAssigned->count() > 0){
						$defImgName='default.jpg';
						$defTemplate='default.json';
						copy(DEST_PATH.$defImgName,BASE_PATH.'/public/uploads/large/'.$defImgName);
						copy(DEST_PATH.$defTemplate,BASE_PATH.'/public/uploads/templates/'.$defTemplate);
						 	
					//}									
					echo 'success';					
				}
				//updating global sync status
				$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=1");
				//manage log			
				$appObj->ActivityLog($historyFlag,STR_CONFIG_TEMPLATE.' : '.$templateName);
				
			}
			else{ 
			   echo "error";
			}			
			die;
	}
	
	 /*****
	 *	@Function Name: checkTemplateNameAjaxAction
	 *  @description  : ajax call to check template name
	 *	@Author		  : Ashu
	 *  @Date         : 13-june-2020
	 *****/	
	public function checkTemplateNameAjaxAction(){
		$appObj = new ApplicationController();				
		$custTempName = trim($_POST['custTempName']);		
		$selQry =$appObj->getTableAllData("tbl_via_settings_templates WHERE template_name='".$custTempName."'");
		if(count($selQry)==0){
			echo 'ok';exit;
		}else{
			echo"exists";
		}	
		die;
	}
	
		

		
	
	
	
	
		 /*****
		 *	@Function Name: getViaSettingsTemplatesTable
		 *  @description  : get viasetting table
		 *	@Author		  : Ashu
		 *  @Date         : 22-april-2020
		 *****/
		public function getViaSettingsTemplatesTable() {
			if (!$this->TblViaSettingsTemplatesTable) {	
				$sm = $this->getServiceLocator();		
				$this->TblViaSettingsTemplatesTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesTable');
				
			}
			return $this->TblViaSettingsTemplatesTable;
		}

	
	public function getDeviceInventoryTable() {
        if(!$this->TblDeviceInventoryTable) {
                $sm = $this->getServiceLocator();
                $this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
        }
        return $this->TblDeviceInventoryTable;
	}
	
}
