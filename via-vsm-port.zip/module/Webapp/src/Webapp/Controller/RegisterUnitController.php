<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Form\RegisterUnitForm;
use Webapp\Controller\WebProducerController;

class RegisterUnitController extends AbstractActionController {

    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{	
            if($this->getRequest()->isXmlHttpRequest()) {
				echo 'sessionout';exit;
			}else{
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}		
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
        public function registerViaUnitAction(){
			if(PRODUCT=='kds'){
				die('Access denied.');
			}
			$appObj = new ApplicationController();
				//getting table info
			$poll_encryption_key=POLL_ENCRYPTION_KEY;
			$getSqlData=$appObj->returnQueryData("SELECT (AES_DECRYPT(email,'$poll_encryption_key')) as email,(AES_DECRYPT(password,'$poll_encryption_key')) as password from tbl_registration_info");
			if($getSqlData->count()>0){
				$infoData=$getSqlData->current();
				$getEmail=urldecode(trim($infoData['email']));
				$getPass=trim($infoData['password']);
			}
			$sql_query_list = "SELECT a.`DID`,a.`DeviceName`,a.`DeviceGroupID`,a.`os_type`,b.`status`,td.model_value FROM `DeviceInventory` a 
			           INNER JOIN tbl_device_extra_info td ON td.deviceID_Fk=a.DID
					   INNER JOIN `tbl_registration_status` b ON a.`DID`=b.`DID` 
					   WHERE a.`os_type`<>'-1'";
			$sql_list = $appObj->returnQueryData($sql_query_list);
			$sql_check = $appObj->returnQueryData("SELECT * FROM tbl_registration_info");
			$form=new RegisterUnitForm();

			 $form->setData(array('txtRegEmail' => $getEmail,
		
			));

			return new ViewModel(array('data'=> $sql_list,'sqlcheck'=>$sql_check,'form'=>$form,'getPass'=>$getPass));


		}
        	/*****
	 *	@Function Name: saveRegisterUnitAction
	 *  @description  : save register unit
	 *	@Author		  : Vineet
	 *  @Date         : 6-may-2020
	 *****/
        public function saveRegisterUnitAction(){
            $appObj = new ApplicationController();
            $emailId = urlencode(trim($_POST['email']));
            $password = urlencode(trim($_POST['password']));
            
            $emailIdDec = trim($_POST['email']);
            $passwordDec = trim($_POST['password']);
            $poll_encryption_key=POLL_ENCRYPTION_KEY;
            
           
            if(!empty($emailId)){
                $url = 'https://www.kramerav.com/api/ViaApi/?email='.$emailId.'&password='.$password.'&OemSN=WOWV1484FB8411A3&AspxAutoDetectCookieSupport=1';
             
                $inserttext = 'Email or Password incorrect.';
            
                $response = json_decode(file_get_contents($url));
                

                if($response!=''){
                
                    if(strcmp($response->value,$inserttext)){
                       $sql_check = $appObj->returnQueryData("SELECT * FROM tbl_registration_info");
                       $rowCount=$sql_check->count();	
                   
                       if($rowCount==0){
                           $sql_query="INSERT INTO tbl_registration_info (email,password) VALUES (AES_ENCRYPT('$emailIdDec','$poll_encryption_key'),AES_ENCRYPT('$passwordDec','$poll_encryption_key'))";
                       }else{                 
                           $sql_query="UPDATE tbl_registration_info SET email=AES_ENCRYPT('$emailIdDec','$poll_encryption_key'),password=AES_ENCRYPT('$passwordDec','$poll_encryption_key')";
                       }
					  
						$getMacInfo = $appObj->returnQueryData("SELECT A.DID_Fk,A.field1 from tbl_device_dnsname A 
                             WHERE (A.DID_Fk NOT IN (select B.DID from tbl_registration_status B) OR A.DID_Fk=-1)");
                            
						if($getMacInfo->count() > 0){
						   $sql_query_status="INSERT INTO tbl_registration_status(DID,status)values ";
						   $value_array=array();
                              foreach($getMacInfo as $row){
							   $getDID=$row['DID_Fk'];
							   $value_array[] = "($getDID, 0)"; 
						   }
							$sql_query_status .= implode(',', $value_array);
							$appObj->executeQueries($sql_query_status);
						}
					   
                        $appObj->executeQueries($sql_query);
						//Rabbit MQ Code
						$cmdArr=array("cmd"=>"register_via","sender"=>"web-vsm");
						$cmdJson=json_encode($cmdArr);
						$producerObject=new WebProducerController();
						$producerObject->rabbitWebProducerAction($cmdJson);
						echo 'success';die;
                    }else{
                        echo '';
                        die;
                    }
                    
                }else{
                    echo 'empty';
                    die;
                }
                
            }
            

        }

          	/*****
	 *	@Function Name: resetUnitAction
	 *  @description  : reset  unit
	 *	@Author		  : Vineet
	 *  @Date         : 6-may-2020
	 *****/
        public function resetUnitAction(){

            $appObj = new ApplicationController();
            $resetVal = trim($_POST['btnVal']);
            if($resetVal == 'Reset'){
                $sql_reset_info =  $appObj->executeQueries("TRUNCATE TABLE tbl_registration_info");
                $sql_reset_status = $appObj->executeQueries("TRUNCATE TABLE tbl_registration_status");
                echo"success";
                die;
               
             }

        }

}