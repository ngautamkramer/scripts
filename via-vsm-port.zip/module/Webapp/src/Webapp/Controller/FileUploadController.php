<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Validator\File\Size;
use Zend\Validator\File\Extension;
use Zend\Validator\File\Rename;
use Zend\File\Transfer\Adapter\Http;

class FileUploadController extends AbstractActionController
{
        public function uploadFile($file = '',$destination = '',$extension = '',$max_size = '')
	{
		$return_array = array();
		if($file != '') {
			try {
				if($destination == '') {
					$return_array['error'] = array("File could not be uploaded, Destination not found");
					return $return_array;
				}
				if($max_size != '') {
					$size = new Size(array('max'=>$max_size));
				} else {
					$size = new Size(array('max'=>20000));
				}
				$original_extenstion = $extension;
				if($extension != '') {
					$extenstion = new Extension($extension);
				}
				$adapter = new Http();
				$adapter->setValidators(array($extenstion,$size), $file['name']);
				if (!$adapter->isValid()){
					$dataError = $adapter->getMessages();
					$error = '';
					foreach($dataError as $key=>$row)
					{
                                            $error .= $row;
					}
					$return_array['error'] = array("Required. ".$original_extenstion." upto 2 MB allowed");
				} else {
					$adapter->setDestination($destination);
					$adapter->addFilter('File\Rename',
					array('target' => $adapter->getDestination().'/'.$file['name'],
					'overwrite' => true));

					if ($adapter->receive($file['name'])) {
						$return_array['success'] = $file['name'];
					}
					
				}
			} catch (Exception $e) {
				$return_array['error'] = array("File could not be uploaded, Please try again");
			}
		} else {
			$return_array['error'] = array("Empty File, Please upload a file");
		}
		return $return_array;
	}
        
	public function getFileExtension($file_name = '')
	{
		$ext = '';
		if($file_name != '') {
			$ext = strtolower(trim(substr($file_name,strrpos($file_name,".")+1,strlen($file_name))));
		}
		return $ext;
	}

	
}
