<?php
  /*****
  * Name    : CalendarController
  * Desc    : Add the third party calendars
  *****/
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Webapp\Controller\ApplicationController;
use Zend\View\Model\ViewModel;
use Webapp\Form\CalendarAccountForm;
use Webapp\Controller\WebProducerController;
use Zend\Session\Container; // for session
use Zend\Mvc\MvcEvent;

class CalendarController extends AbstractActionController
{	
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		if(PRODUCT=='via' || PRODUCT=='kds'){
			$getSettingObj = $appObj->getComplexPasswordSettings();
			$getSettingData = $getSettingObj->webadmin_session_timeout;
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
			foreach($tblSessionTimeOutDataArr as $sessiondata){
				$getSettingData=$sessiondata['logoutTime'];
			}
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	/*****
	 *	@Function Name		: addListAction
	 *  @description	    : List the account
     *	@Author			    : Ranjan
	 *  @Date               : 20-May-2020
	 *****/
	public function calendarListAction(){
		$session = new Container('userinfo');
		$usrid = $session->offsetGet('usrid');
		$appObj = new ApplicationController();
		try{
			 $doneData=$appObj->returnQueryData("SELECT DISTINCT B.calender_id,(case when A.account_type=1 then 'Google' when A.account_type=2 then 'Office 365' when A.account_type=3 then 'MS Exchange' when A.account_type=4 then 'Office 365 OAuth 2.0' end) as account_type ,A.account_id,AES_DECRYPT(A.email,'".POLL_ENCRYPTION_KEY."') as email,B.name,A.display_name FROM tbl_calender_account A INNER JOIN tbl_calendars B ON B.account_id=A.account_id");
			 
			 $rslt=$appObj->returnQueryData("SELECT DISTINCT calendar_id FROM tbl_gway_cal_relation WHERE sync_status IN (0,1)");
			 if($rslt->count() > 0){
				   $calIdArr=array();
				   foreach($rslt as $row){
					   $calIdArr[]=$row['calendar_id'];
				   } 
			 }
		}catch(Exception $e){
			echo "Something went wrong.";die;
		}

		try{
			$syncData=$appObj->returnQueryData("SELECT B.DeviceName,B.DeviceIP,A.sync_status,C.name FROM tbl_gway_cal_relation A INNER JOIN DeviceInventory B ON B.DID=A.device_id INNER JOIN tbl_calendars C ON C.calender_id=A.calendar_id WHERE A.sync_status IN (0,1)");
		}catch(Exception $e){
			echo "Something went wrong.";die;
		}
		return new ViewModel(
			array('doneData' => $doneData,'syncData' => $syncData )
		);
	}

	/*****
	 *	@Function Name		: addAccountAction
	 *  @description	    : Add the account
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-Jan-2020
	 *****/
	 
    public function calendarAccountAction()
    {	
        //get the userid from session
        $session = new Container('userinfo');
		$usrid = $session->offsetGet('usrid');
	    //get ms exchange all version
	    $ConnObject = new ApplicationController();
		$getExchageVersionArr=$ConnObject->getExchangeVersion();
		$form = new CalendarAccountForm($getExchageVersionArr);
	    //$getCalendarAccountArray = $ConnObject->returnQueryData("SELECT id,account_id,account_type ,permission_type,created_on,AES_DECRYPT(email,'".POLL_ENCRYPTION_KEY."') as email FROM tbl_calender_account");		
		$getCalendarAccountArray = $ConnObject->returnQueryData("SELECT id,account_id,account_type ,permission_type,created_on,convert_from(decrypt(email,'".POLL_ENCRYPTION_KEY."','aes'),'utf-8') as email FROM tbl_calender_account");
		$calAccountArr =array();
		$connToken=$ConnObject->getConnection();
	    $rsltToken = $connToken->execute("SELECT id FROM tbl_access_token");
	    $accountCount=$rsltToken->current();
		$connCalAccount=$ConnObject->getConnection();
		$var_key=POLL_ENCRYPTION_KEY;
	    if($accountCount['id']){
		  //$rsltCal = $connCalAccount->execute("SELECT name,AES_DECRYPT(email,'$var_key') as email,account_type FROM tbl_calendars INNER JOIN tbl_calender_account ON tbl_calender_account.account_id=tbl_calendars.account_id");
		  $rsltCal = $connCalAccount->execute("SELECT name,convert_from(decrypt(email,'$var_key','aes'),'utf-8') as email,account_type FROM tbl_calendars INNER JOIN tbl_calender_account ON tbl_calender_account.account_id=tbl_calendars.account_id");
		   
		  $accountCal=$rsltCal->current();
		  if($accountCal['name']){
		  		$accountType=$accountCal['account_type'];
		  		if($accountCal['account_type']==1){
					$calType=STR_GOOGLE;
				}
		  		if($accountCal['account_type']==2){
					$calType='Office 365';
				}
		  		if($accountCal['account_type']==4){
					$calType='Office 365 OAuth 2.0';
				}
				
				
				//$calType=STR_GOOGLE;
				$uname=$accountCal['name'];
				$gmail=$accountCal['email'];  
		  }else{
			  $connCalTru=$ConnObject->getConnection();
			  $connCalTru->execute("truncate tbl_calendars;");
			  $connTokenTrun=$ConnObject->getConnection();
			  $connTokenTrun->execute("truncate tbl_access_token;");
			  $connAccountTrun=$ConnObject->getConnection();
			  $connAccountTrun->execute("truncate tbl_calender_account;");
			  return $this->redirect()->toRoute('calendar',array('action' => 'calendarAccount'));
		  }
	  }else{
		  //$rslt = $connCalAccount->execute("SELECT AES_DECRYPT(tbl_calender_account.email,'$var_key') as email,AES_DECRYPT(tbl_calender_account.password,'$var_key') as password,tbl_calendars.name,tbl_calender_account.permission_type,tbl_calender_account.account_type FROM tbl_calender_account LEFT JOIN tbl_calendars ON tbl_calendars.account_id=tbl_calender_account.account_id");
		  $rslt = $connCalAccount->execute("SELECT decrypt(tbl_calender_account.email,'$var_key','aes') as email,convert_from(decrypt(tbl_calender_account.password,'$var_key','aes'),'utf-8') as password,tbl_calendars.name,tbl_calender_account.permission_type,tbl_calender_account.account_type FROM tbl_calender_account LEFT JOIN tbl_calendars ON tbl_calendars.account_id=tbl_calender_account.account_id");
		  $rowData=$rslt->current();
		  if($rowData){
			  $calType=STR_OFFICE365_BASIC_AUTH;
			  $uname=$rowData['email'];
			  $calname=$rowData['name'];
			  $password=$rowData['password'];
			  $permissionType=$rowData['permission_type'];
			  $accountType=$rowData['account_type'];
			  if($permissionType==1){
				  $permissonShowTxt=STR_IMPERSONATION;
			  }else if($permissionType==2){
				  $permissonShowTxt=STR_DELEGATE;
			  }else{
				  $permissonShowTxt="";
			  }
			  if($accountType==3){
				   $calType=STR_MS_EXCHANGE;
				   $connHostUrl=$ConnObject->getConnection();
				   $serverData = $connHostUrl->execute("SELECT host_url,version FROM tbl_host_url ORDER BY id DESC LIMIT 1");
				   $rowServer=$serverData->current();
				   $hostServerURL=$rowServer['host_url'];
				   $hostServerVersion=$rowServer['version'];
			  }  
		  }		  
		}
		 if(PRODUCT=='via'){
			$settingValue = $ConnObject->getTableAllData('tbl_hq_more_configuration')->current();			
		}
		$calSettingVal = $settingValue['featurestatus5'];
	    $viewmodel = new ViewModel(array(
                'results' => $getCalendarAccountArray,
				'getExchageVersionArr'=>$getExchageVersionArr,
				'form' =>$form,
				'calType' =>$calType,
				'hostServerURL' =>$hostServerURL,
				'hostServerVersion' =>$hostServerVersion,
				'accountType' =>$accountType,
				'permissionType' =>$permissionType,
				'uname' =>$uname,
				'calname' =>$calname,
				'gmail' =>$gmail,
				'permissonShowTxt' =>$permissonShowTxt,
				'calPass' =>$password,
				'calSettingVal' => $calSettingVal
            ));
    	
    	if(PRODUCT == 'via'){
				$viewmodel->setTemplate('webapp/manage-configurations/room-settings');
			}
			return $viewmodel;
    }
	
	/*****
	 *	@Function Name		: getCalendarAction
	 *  @description	    : ajax to get calendar list.
     *	@Author			    : Ranjan
	 *  @Date               : 25-May-2020
	 *****/
	public function getCalendarAction(){
		$request = $this->getRequest();
		if($request->isPost()){
			$appObj = new ApplicationController();
	  		$actId = trim($request->getPost('calid'));
	  		$accountType = trim($request->getPost('atype'));
	  		$permissionType = trim($request->getPost('ptype'));
	  		try{
				$results=$appObj->returnQueryData("SELECT name,created_at,calender_id FROM tbl_calendars WHERE account_id='$actId'");
			}catch(Exception $e){
				echo "Something went wrong.";die;
			}
			if(trim($request->getPost('cal_email'))) {
				$calName = trim($request->getPost('cal_email'));
				$accountId = trim($request->getPost('cal_account'));
				$aType = trim($request->getPost('atype'));
				$pType = trim($request->getPost('ptype'));
				if($calName && $accountId){
					$sqrQuery=$appObj->executeQueries("INSERT INTO tbl_calendars(name,account_id,calender_id,color) values('".$calName."','".$accountId."','".$calName."','#ff7537')");
				}
			}
			if(($accountType==2 && $permissionType !=0) || ($accountType==3 && $permissionType !=0)){
				$response = '<table class="table table-responsive">';
				$response .= '<tr>
				
				<td align="left">
				  <div class="form-group m-t col-md-12">
				  <fieldset class="m-r-none m-l-none form-group">
			      <input name="cal_email" type="text" maxlength="50" id="cal_email" class="form-control styl"  />
				  <label for="cal_email" class="animate-lbl activeCss">'.STR_RESOURCE_CALENDAR.'</label>
				  </fieldset></div>
				  <input name="cal_account" type="hidden" id="cal_account" value="'.$actId.'" />
				  <input name="atype" type="hidden" id="atype" value="'.$accountType.'" />
				  <input name="ptype" type="hidden" id="ptype" value="'.$permissionType.'" />
				</td>
				<td colspan="3"><div class="form-group m-t col-md-12">
					<input type="submit" name="calemailsave" value="'.STR_ADD_CALENDAR.'" id="calemailsave" class="btn btn-viablue"  /></div>
				</td></tr>';
				$response .= '</table>';
			}
			$response .= '<table class="table table-responsive m-t">';
			$response .= '<tr>
			<th width="30%">Name</th>
			<th width="40%" class="text-center">'.STR_CREATION_DATE.'</th>
			<th width="30%" class="text-right">'.STR_DELETE.'</th>
			</tr><tr>';
			if($results->count() > 0 ){
				foreach ($results as $key => $value) {
					$response .= '<tr><td width="30%">'.$value['name'].'</td>
		         <td width="40%" class="text-center">'.$value['created_at'].'</td> 
				  <td width="30%" class="text-right">
					<div style="cursor:pointer;" id="delList_"'.$value['calender_id'].'" value="'.$value['calender_id']."$#$$actId".'"><img src="'. PUBLIC_URL.'/img/via/icon-delete.svg" alt="Delete " class="actionCss"></div>
				 </td></tr>';
				}
			}else{
				$response .= '<td colspan="3" class="text-center">'.MSG_NO_RECORD_FOUND.'</td>';
			}
			$response .= '<td colspan="3"></td></tr></table>';
			echo $response;die;
		}
	}

	/*****
	 *	@Function Name		: editCalendarAccountAction
	 *  @description	    : Edit calendar.
     *	@Author			    : Ranjan
	 *  @Date               : 25-May-2020
	 *****/
	public function editCalendarAccountAction(){
		$request = $this->getRequest();
		if($request->isPost()){
			$appObj = new ApplicationController();
	  		$getActId = trim($request->getPost('accountId'));
	  		$getActData=$appObj->returnQueryData("SELECT A.account_id,A.account_type,A.permission_type,B.host_url,B.version FROM tbl_calender_account A LEFT JOIN tbl_host_url B ON B.account_id=A.account_id where A.account_id='$getActId'");

		  	if($getActData->count() > 0){
			   foreach ($getActData as $key => $row) {
			   		$getActType=$row['account_type'];
				    $getPermissionType=$row['permission_type'];
				    $getActName=$row['account_id'];
					$getHostUrl=$row['host_url'];
					$getExVersion=$row['version'];
			   } 
		  	}
		  	if($getExVersion){
			   $getVrData=$appObj->returnQueryData("SELECT exchange_verison FROM tbl_exchange_version WHERE exchange_name='$getExVersion'")->current();
			   $exchangeVer = $getVrData['exchange_verison'];
		 	}
		 	if($getActType==2){
				$calTypeOpt = '<option value="office365basic">'.STR_OFFICE365_BASIC_AUTH.'</option>';
			}else if($getActType==3){
				$calTypeOpt = '<option value="msexchange">'.STR_MS_EXCHANGE.'</option>';
			}else if($getActType==4){
				$calTypeOpt = '<option value="office365auth2">'.STR_OFFICE365.'</option>';
			}else if($getActType==1){
				$calTypeOpt = '<option value="google">'.STR_GOOGLE.'</option>';				
			}

		 	$accountArr = array('getActType' =>$getActType, 'getPermissionType' =>$getPermissionType, 'getActName' =>$getActName, 'getHostUrl' => $getHostUrl, 'getExVersion' => $getExVersion, 'exchangeVer' => $exchangeVer, 'calTypeOpt' => $calTypeOpt);
		  	
	  	}
	  	echo json_encode($accountArr);die;
	}

	/*****
	 *	@Function Name		: accountConfigAction
	 *  @description	    : Account configuration like google client id,secret key etc.
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-Jan-2020
	 *****/
	 public function accountConfigAction(){
		    $client = new \Google_Client();
			//use the certificate pem file
			$http = new \GuzzleHttp\Client(['verify' =>OPEN_SSL_PATH]);
			$client->setHttpClient($http);
			//set the client id ,secret key and other details
			$client->setClientId(GOOGLE_CLIENT_ID);
			$client->setClientSecret(GOOGLE_CLIENT_SECRET);
			$client->setRedirectUri(GOOGLE_REDIRECT_URL);
			$client->setScopes(explode(",",GOOGLE_SCOPES));
			$client->setApprovalPrompt("force");
			$client->setAccessType("offline");
			return $client;
	 }
	 
	 /*****
	 *	@Function Name		: accountLoginAction
	 *  @description	    : Login the user first time in google api
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-May-2020
	 *****/
	 
	 public function accountLoginAction()
	 {
	 	$request = $this->getRequest();
	 	//create the connection object
		$ConnObject=new ApplicationController();
		$connection=$ConnObject->getConnection();
	 	//Update the tbl_calendar
		if($request->isPost()){
			$calArr=explode("$#$",$_POST['val']);
			$calenderId=$calArr[0];
			$name=$calArr[1];
			$accountId=$calArr[2];
			$sqrQuery=$ConnObject->returnQueryData("INSERT INTO tbl_calendars(color,name,account_id,calender_id) values('','".$name."','".$accountId."','".$calenderId."')");
			if($sqrQuery){
				echo 1;die;
			}else{
			     echo 2;die;	
			}
		}
		 //create the account config
		$client = $this->accountConfigAction();
		$auth_url = $client->createAuthUrl();
		$code="";
		//if got the code into get request 
		if($this->getRequest()){
			$code=$this->params()->fromQuery('code');
		}
		if($code != ""){ 
		      try{
			    $client->authenticate($code);
			 }catch(Exception $e) {
				  echo 500;die;
			 }
			 $accessToken = $client->getAccessToken();
			 $access_token=$accessToken['access_token'];
			 $refresh_token=$accessToken['refresh_token'];
			 $token_type=$accessToken['token_type'];
			 $expires_in=$accessToken['expires_in'];
			 $created=$accessToken['created'];
			
			 $plus = new \Google_Service_Plus($client); //create the plus service object
			 $google_user = $plus->people->get('me');
			 $id = $google_user['id'];
			 $email = $google_user['emails'][0]['value'];
			 $display_name = $google_user['displayName'];
			 $var_key=POLL_ENCRYPTION_KEY;
			 $created_on = date('Y-m-d H:i:s');
			 if(PRODUCT=='via'){
				 $peopleResults = $connection->execute("INSERT INTO tbl_calender_account (account_id,email,display_name,account_type,permission_type,created_on) values('$id',encrypt('$email','$var_key','aes'),'$display_name',1,0,'$created_on')");
				  if($peopleResults){
					 $connObj=$ConnObject->getConnection();
					 $result=$connObj->execute("INSERT INTO tbl_access_token (account_id,user_id,access_token,refresh_token,token_type,expires_in,created) values('$id',0,'$access_token','$refresh_token','$token_type','$expires_in','$created')");
					 
					 $service = new \Google_Service_Calendar($client); //create the calender object
					 //Get the calnder list
					 $calendarList = $service->calendarList->listCalendarList();
					 foreach ($calendarList->getItems() as $calenderData){
						 $etag=$calenderData->getEtag();
						 $calenderId=$calenderData->getId();
						 $summary=$calenderData->getSummary();
						 $timeZone=$calenderData->getTimeZone();
						 $backgroundColor=$calenderData->getBackgroundColor();
						 $calOptions .= '<option value="'.$calenderId."$#$".$summary."$#$".$id.'">'.$summary.'</option>';
					 }
					 echo $calOptions;die;
				  }
			 }else{
				 $getAccountTblData=$ConnObject->returnQueryData("SELECT account_id FROM tbl_calender_account where account_id='$id'");
				 $connObj=$ConnObject->getConnection();
				  if($getAccountTblData->count() == 0){
					 $connObj->execute("INSERT INTO tbl_calender_account (account_id,email,display_name,account_type,permission_type,created_on) values('$id',encrypt('$email','$var_key','aes'),'$display_name',1,0,'$created_on')");

					 $connObj->execute("INSERT INTO tbl_access_token (account_id,user_id,access_token,refresh_token,token_type,expires_in,created) values('$id',0,'$access_token','$refresh_token','$token_type','$expires_in','$created')");
				  }else{
					 $connObj->execute("UPDATE tbl_access_token SET access_token='$access_token',refresh_token='$refresh_token',token_type='$token_type',expires_in='$expires_in',created='$created' WHERE account_id='$id'");
					 $connObj->execute("UPDATE tbl_calender_account SET created_on=now() WHERE account_id='$id'");
					 echo 1;die;
				 }
					 
				 $service = new \Google_Service_Calendar($client); //create the calender object
				 //Get the calnder list
				 $calendarList = $service->calendarList->listCalendarList();
				 $sql_query="INSERT INTO tbl_calendars(color,name,account_id,calender_id,etag,timezone) values ";
				 foreach ($calendarList->getItems() as $calenderData){
					 //$etag=$calenderData->getEtag();
					 $etag="";
					 $calenderId=$calenderData->getId();
					 $summary=$calenderData->getSummary();
					 $timeZone=$calenderData->getTimeZone();
					 $backgroundColor=$calenderData->getBackgroundColor();
					 
					 $getCalendarTblData=$ConnObject->returnQueryData('SELECT calender_id FROM tbl_calendars where calender_id="'.$calenderId.'" AND account_id="'.$id.'"');
					 if($getCalendarTblData->count()==0){
						 $value_array[] = '("'.$backgroundColor.'","'.$summary.'","'.$id.'", "'.$calenderId.'","'.$etag.'", "'.$timeZone.'")'; 
					 }
				 }
				 $sql_query .= implode(',', $value_array);
				 $results = $connObj->execute($sql_query);
				 echo 1;die;
			 }
			 
		}else{
			//Redirect the login allow page 
			return $this->redirect()->toUrl($auth_url);
		} 
	  }

	  /*****
	 *	@Function Name		: associateCalendarAction
	 *  @description	    : Get Associate calendar data
     *	@Author			    : Ranjan
	 *  @Date               : 20-May-2020
	 *****/
	  public function associateCalendarAction(){
	  		$request = $this->getRequest();
	  		$session = new Container('userinfo');
			$user_id = $session->offsetGet('usrid');
			if(PRODUCT=='via'){
				if(isset($_REQUEST['val'])){
					$calArr=explode("$#$",$_REQUEST['val']);
					$calenderId=$calArr[0];
					$name=$calArr[1];
					$accountId=$calArr[2];
					$ConnObject=new ApplicationController();
					$connection=$ConnObject->getConnection();
					$sqrQuery=$connection->execute("INSERT INTO tbl_calendars(name,account_id,calender_id) values('$name','$accountId','$calenderId')");
					if($sqrQuery){
						echo 1;die;
					}else{
						 echo 2;die;	
					}
				}
			}else{
				if($request->isPost()){
					$appObj = new ApplicationController();
					$calendar_id = urldecode(trim($request->getPost('calid')));
					$getCalNameArr=$appObj->returnQueryData("SELECT name FROM tbl_calendars WHERE calender_id='$calendar_id'");
					$calRow=$getCalNameArr->current();
					$getCalName=$calRow['name'];
					//Get the gateway list which is not associated with calendar
					if($user_id==1){
						$sqlQry="SELECT A.*,td.model_value FROM deviceinventory A
						INNER JOIN tbl_device_extra_info td ON td.deviceid_fk=A.did
						WHERE substring_index(A.version,'.',-1) > 960 AND did NOT IN (SELECT device_id FROM tbl_gway_cal_relation WHERE sync_status IN (0,1))";	
					}else{
						$sqlQry="SELECT DISTINCT A.*,td.model_value FROM deviceinventory A 
						INNER JOIN tbl_device_extra_info td ON td.deviceid_fk=A.did
						INNER JOIN tbl_user_access AS B ON B.group_id_fk=A.devicegroupid WHERE substring_index(A.version,'.',-1) > 960 AND A.did NOT IN (SELECT device_id FROM tbl_gway_cal_relation WHERE sync_status IN (0,1)) AND B.user_id_fk=$user_id";
					}
					$calData = $appObj->returnQueryData($sqlQry);
					$response = '<div class="text-danger text-center m-b">'.$getCalName.'</div>';
					$response .= '<table class="table table-responsive">';
					$response .= '<thead><tr><th>'.STR_SNO.'</th>
					<th>'.STR_GATEWAY_NAME.'</th>
					<th class="text-center">'.STR_MODEL.'</th><th class="text-right"><input type="checkbox" name="selectAllCbox" id="selectAllCbox" class="selectAllCbox" /><label for="selectAllCbox"><span></span></label></th></tr></thead><tbody>';
					
					if($calData->count() > 0){
						$count=1;
						foreach ($calData as $row) {
							$modelObj = $appObj->getModelFromJson($row['model_value']);
							$modelType = $modelObj->modelshow;
							$response .= '<tr><td align="center">'.$count.'</td>
							<td>'.$row['DeviceName'].'</td>
							<td class="text-center">'.$modelType.'</td>
							<td class="text-right"><input type="checkbox" name="selChkBox[]" class="makeCboxEnabled" value="'.$row['did'].'" id="selChkBox_'.$count.'"/><label for="selChkBox_'.$count.'"><span></span></label></td></tr>';
							$count++;
						}
						$response .= '<tr><td colspan="4"></td></tr></tbody></table>';
						$response .= '<div class="form-group m-b-xs m-t-lg pull-right"><button type="button" class="btn btn-via m-r-sm cancel" data-dismiss="modal">'.CANCEL_BTN.'</button><button type="button" class="btn btn-viablue btn-s-xs assignBtnClass" name="calassociatebtn" id="calassociatebtn" rev="'.$calendar_id.'">'.STR_ASSOCIATE.'</button></div>';
					}else{
						$response .= '<tr><td colspan="4" class="text-center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
						$response .= '<tr><td colspan="4"></td></tr></tbody></table>';
						$response .= '<div class="form-group m-b-xs m-t-lg pull-right"><button type="button" class="btn btn-via m-r-sm cancel" data-dismiss="modal">'.CANCEL_BTN.'</button></div>';
					}
					echo $response;die;
				}
			}
	  		
	  }

	 /*****
	 *	@Function Name		: unlinkGatewayAjaxAction
	 *  @description	    : Delete Associated Gateway from calendar
     *	@Author			    : Ranjan
	 *  @Date               : 20-May-2020
	 *****/
	 public function unlinkGatewayAjaxAction(){
	 	if(!empty($_POST['calendarId'])){
			$calendarId=trim($_POST['calendarId']);
			$gwayIdsArr=$_POST['gwayIdsArr'];
			if(count($gwayIdsArr) > 0){
			    foreach($gwayIdsArr as $val){
					$gwayIdsStr .=$val.",";
				}	
				$finalGwayIdsStr=rtrim($gwayIdsStr,",");
				$appObj = new ApplicationController();
				
				$rslt=$appObj->returnQueryData("UPDATE tbl_gway_cal_relation SET sync_status=2 WHERE device_id IN ($finalGwayIdsStr) AND calendar_id='$calendarId'");
				//Rabbit MQ Code
				$cmdArr=array("cmd"=>"push_calender","sender"=>"web-vsm");
				$cmdJson=json_encode($cmdArr);
				$producerObject=new WebProducerController();
				$producerObject->rabbitWebProducerAction($cmdJson);
		        if($rslt){
					echo 1;die;	
			   }else{
				   echo 0;die; 
			   }
			}
		}
 	 }

	 /*****
	 *	@Function Name		: showCalendarDetailAction
	 *  @description	    : Calendar list to unlink
     *	@Author			    : Ranjan
	 *  @Date               : 20-May-2020
	 *****/
	 public function showCalendarDetailAction(){
	 		$request = $this->getRequest();
	  		$session = new Container('userinfo');
			$user_id = $session->offsetGet('usrid');
	  		if($request->isPost()){
	  			$appObj = new ApplicationController();
	  			$getParam = urldecode(trim($request->getPost('calid')));
	  			$calDelimeter=explode('|*|',$getParam);
			  	$chkType="";
			  	if(count($calDelimeter) > 1){
				  $chkType=$calDelimeter[0];
				  $calendarId=$calDelimeter[1];
			  	}else{
				  $calendarId=$calDelimeter[0];
			  	}

			  	if($user_id==1){
		 			$rsltRes="SELECT DeviceName,DID FROM DeviceInventory WHERE DID IN (SELECT device_id FROM tbl_gway_cal_relation WHERE calendar_id='$calendarId' AND sync_status IN (0,1))";  
	  			}else{
		 			$newQuery=$appObj->returnQueryData("SELECT DISTINCT(group_id_fk) FROM tbl_user_access WHERE user_id_fk=".$user_id);
					foreach($newQuery as $newresult){
						$newString .=$newresult['group_id_fk'].",";
					}
		 			$grpIdsData=rtrim($newString,","); 
		 			$rsltRes="SELECT DISTINCT DID,DeviceName FROM DeviceInventory WHERE DID IN (SELECT device_id FROM tbl_gway_cal_relation WHERE calendar_id='$calendarId' AND sync_status IN (0,1)) AND DeviceGroupID IN ($grpIdsData)";
	  			}
	  			$calData = $appObj->returnQueryData($rsltRes);
				
				$response .= '<table class="table table-responsive">';
				$response .= '<thead><th>'.STR_GATEWAY_NAME.'</th>';
				if(!empty($chkType)){
					$response .= '
					<th class="text-right"><input type="checkbox" name="selectAllCbox" id="selectAllCbox" class="selectAllCbox" /><label for="selectAllCbox"><span></span></label></th></tr></thead><tbody>';
				}
				//$response .= '</tr></thead><tbody>';
				if($calData->count() > 0){
					$count=1;
					foreach ($calData as $row) {
						$response .= '<tr><td>'.$row['DeviceName'].'</td>';
				 		if(!empty($chkType)){
				 			$response .= '<td class="text-right"><input type="checkbox" name="selChkBox[]" class="makeCboxEnabled" value="'.$row['DID'].'" id="selChkBox_'.$count.'"/><label for="selChkBox_'.$count.'"><span></span></label></td>';
				 		}
						$count++;
					}
					$response .= '</tr><tr><td colspan="2"></td></tr></tbody></table>';
					if(!empty($chkType)){
					$response .= '<div class="form-group m-b-xs m-t-lg pull-right"><button type="button" class="btn btn-via m-r-sm cancel" data-dismiss="modal">'.CANCEL_BTN.'</button><button type="button" class="btn btn-viablue btn-s-xs assignBtnClass" name="unlinkGway" id="unlinkGway" rev="'.$calendarId.'">'.STR_BTN_DELETE.'</button></div>';
					}else{
						$response .= '<div class="form-group m-b-xs m-t-lg pull-right"><button type="button" class="btn btn-via m-r-sm cancel" data-dismiss="modal">'.CANCEL_BTN.'</button></div>';
					}
				}else{
					$response .= '<tr><td colspan="4" class="text-center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
					$response .= '<tr><td colspan="3"></td></tr></tbody></table>';
					$response .= '<div class="form-group m-b-xs m-t-lg pull-right"><button type="button" class="btn btn-via m-r-sm cancel" data-dismiss="modal">'.CANCEL_BTN.'</button></div>';
				}
				echo $response;die;
	  		}
	 }

	 //Ajax to associate calendar
	 public function linkGatewayAjaxAction(){
	 	if(!empty($_POST['calendarId'])){
	 		$appObj = new ApplicationController();
			$calendarId=trim($_POST['calendarId']);
			$gwayIdArr=$_POST['gwayIdsArr'];
			if(count($gwayIdArr) > 0 && !empty($calendarId)){
				 foreach($gwayIdArr as $val){
				 	$checkData = $appObj->returnQueryData("SELECT * FROM tbl_gway_cal_relation where device_id=$val");
				 	if($checkData->count() > 0){
				 		$appObj->executeQueries("UPDATE tbl_gway_cal_relation SET calendar_id='$calendarId',sync_status=0 WHERE device_id=$val");
				 	}else{
				 		$appObj->executeQueries("INSERT INTO tbl_gway_cal_relation(device_id,calendar_id,sync_status,modifydate) values ('$val','$calendarId',0,now())");
				 	}
				 	$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID=$val");
				 }
				//Rabbit MQ Code
				$cmdArr=array("cmd"=>"push_calender","sender"=>"web-vsm");
				$cmdJson=json_encode($cmdArr);
				$producerObject=new WebProducerController();
				$producerObject->rabbitWebProducerAction($cmdJson);
				 echo 1;die;
			}
		}
	 }

	 /*****
	 *	@Function Name		: deleteCalendarAction
	 *  @description	    : Delete calendar account
     *	@Author			    : Ranjan
	 *  @Date               : 21-May-2020
	 *****/
	 public function deleteCalendarAction(){
	 	$request = $this->getRequest();
	 	if($request->isPost()){
	 		$appObj = new ApplicationController();
	 		if(!empty($_POST['cal_id'])){
				$idsArray=explode("$#$",trim($_POST['cal_id']));
				$calendarId=$idsArray[0];
				$accountId=$idsArray[1];
				$rsltRes=$appObj->returnQueryData("SELECT * FROM tbl_gway_cal_relation WHERE calendar_id='$calendarId' AND sync_status IN (0,1)");
				if($rsltRes->count() == 0){
				    $appObj->executeQueries("DELETE FROM tbl_calendars WHERE account_id='$accountId' AND calender_id='$calendarId'");
					//Update the tbl_gway_cal_relation sysnc_status with 2
					$appObj->executeQueries("UPDATE tbl_gway_cal_relation SET sync_status=2 WHERE calendar_id='$calendarId'");
					//Check if no any calendar found then delete the account and access token also.
					$rsltQry=$appObj->returnQueryData("SELECT * FROM tbl_calendars WHERE account_id='$accountId'");
					if($rsltQry->count() == 0){
						$appObj->executeQueries("DELETE FROM tbl_calender_account WHERE account_id='$accountId'");
						$appObj->executeQueries("DELETE FROM tbl_access_token WHERE account_id='$accountId'");
					}
					echo 1;die;	
			   }else{
				   echo 0;die; //Error
			   }
			}
	 	}	
	 }

	 /*****
	 *	@Function Name		: resetCalendarAction
	 *  @description	    : Reset the calendar account
     *	@Author			    : Dileep Yadav
	 *  @Date               : 27-Jan-2020
	 *****/
	 
	 public function resetCalendarAction()
	 {
		 if($this->getRequest()->getPost()){ 
			  $postData = $this->getRequest()->getPost()->toArray();
			  $connObject=new ApplicationController();
			  if($postData['calType']){
				  $connCalTru=$connObject->getConnection();
				  $connCalTru->execute("truncate tbl_calendars;");
				  $connTokenTrun=$connObject->getConnection();
				  $connTokenTrun->execute("truncate tbl_access_token;");
				  $connAccountTrun=$connObject->getConnection();
				  $connAccountTrun->execute("truncate tbl_calender_account;");
			  }
		 }
		 echo 1;die;
	 }
	 
	   /*****
	 *	@Function Name		: saveOfficeDetailAction
	 *  @description	    : Save the office and ms exchange details
     *	@Author			    : Dileep Yadav
	 *  @Date               : 27-Jan-2020
	 *****/
	 
	 public function saveOfficeDetailAction()
	 {
		if($this->getRequest()->isPost()) {
			 $postData = $this->getRequest()->getPost()->toArray();
		     $caluserid=trim($postData['caluserid']);
		     $caluserpass=trim($postData['caluserpass']);
			 $accessType=0;
			 $hostUrl="";
			 $exchangeVer="";
			 if($postData['permission_type']){
				 $accessType=trim($postData['permission_type']);
			 }
			 if($postData['accountType']=='office'){
				 $accountType=2;
			 }
			 if($postData['accountType']=='exchange'){
				 $accountType=3;
				 $hostUrl=trim($postData['hosturl']);
				 $exchangeVer=trim($postData['exchange_ver']);
			 }
			 $calName="";
			 if($postData['calname']){
				   $calName=$postData['calname'];
			 }
			 $var_key=POLL_ENCRYPTION_KEY;
			 $connObject=new ServicesController();
			 $connectionAccount=$connObject->getConnection();
			 $appObj = new ApplicationController();

			$getAccountTblData=$appObj->returnQueryData("SELECT account_id FROM tbl_calender_account where account_id='$caluserid'");
			if($getAccountTblData->count()==0){
			  $appObj->executeQueries("INSERT INTO tbl_calender_account (account_id,email,display_name,account_type,password,permission_type) values('$caluserid',AES_ENCRYPT('$caluserid','".$var_key."'),'$caluserid',$accountType,AES_ENCRYPT('$caluserpass','".$var_key."'),$accessType)");
			  if(PRODUCT=='vsm' && $accessType==0){
					$appObj->executeQueries("INSERT INTO tbl_calendars(name,account_id,calender_id) values('".$caluserid."','".$caluserid."','".$caluserid."')");	
			  }
			  if(PRODUCT=='via' && $calName){
					 $connectionCalendar=$connObject->getConnection();
					 $sqrQuery=$connectionCalendar->execute("INSERT INTO tbl_calendars(name,account_id,calender_id) values('".$calName."','".$caluserid."','".$calName."')");	
			  }
			  if($accountType==3){
				$sqlQry=$appObj->executeQueries("INSERT INTO tbl_host_url (host_url,account_id,version,account_type) values('$hostUrl','$caluserid','$exchangeVer',$accountType)");	
			  }
			}else{
				if(PRODUCT=='vsm'){
					if($accessType==0){
						$appObj->executeQueries("DELETE FROM tbl_calendars WHERE account_id='$caluserid'");
						$appObj->executeQueries("INSERT INTO tbl_calendars(name,account_id,calender_id) values('".$caluserid."','".$caluserid."','".$caluserid."')");	
				    }
					
					$appObj->executeQueries("UPDATE tbl_calender_account SET password=AES_ENCRYPT('$caluserpass','$var_key'),permission_type=$accessType WHERE account_id='$caluserid'");
					//Now when reauthenticate we are upgrading sync status in tbl_gway_cal_relation and sending command
					$getGwayCalRelationTblData=$appObj->returnQueryData("SELECT * FROM tbl_gway_cal_relation where calendar_id='$caluserid'");
					if($getGwayCalRelationTblData->count()>0){
						$appObj->executeQueries("UPDATE tbl_gway_cal_relation SET sync_status=0 WHERE calendar_id='$caluserid'");
						//Rabbit MQ Code
						$cmdArr=array("cmd"=>"push_calender","sender"=>"web-vsm");
						$cmdJson=json_encode($cmdArr);
						$producerObject=new WebProducerController();
						$producerObject->rabbitWebProducerAction($cmdJson);						
					}
										
				}
			}
		    echo 1;die;
		}
	 }
	

	 /*****
	 *	@Function Name		: getTblCalendarAccountTable
	 *  @description	    : get calendar account model
	 
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-Jan-2020
	 *****/
    public function getTblCalendarAccountTable()
    {
         $sm = $this->getServiceLocator();
         $this->calendarAccountTable = $sm->get('Webapp\Model\TblCalendarAccountTable');
         return $this->calendarAccountTable;
    }
	
	/*****
	 *	@Function Name		: getTblCalendarTable
	 *  @description	    : get calendar model
     *	@Author			    : Dileep Yadav
	 *  @Date               : 25-Jan-2020
	 *****/
    public function getTblCalendarTable()
    {
         $sm = $this->getServiceLocator();
         $this->calendarTable = $sm->get('Webapp\Model\TblCalendarTable');
         return $this->calendarTable;
    }
		
}
