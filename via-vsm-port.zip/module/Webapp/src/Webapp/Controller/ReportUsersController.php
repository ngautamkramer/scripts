<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Form\ViaReportForm;
use Webapp\Controller\ApplicationController;

class ReportUsersController extends AbstractActionController {


    public $session;
    public $user_id;
    public $appObj;
    public function __construct() {
        $session = new Container('userinfo');
		$this->user_id = $session->offsetGet('usrid');
        $this->appObj = new ApplicationController();
        
    }
    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
     /*****
	 *	@Function Name: topActiveUsersAction
	 *  @description  : get top 25 active users
	 *	@Author		  : Vineet
	 *  @Date         : 17-april-2020
	 *****/
    public function topActiveUsersAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('enddate')!="" ) {
            $startDate  = htmlspecialchars($request->getPost('startdate'));
            $endDate = htmlspecialchars($request->getPost('enddate'));
            if($startDate!="" && $endDate!=""){
                $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
            }
        }
        else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
        }
        if($this->user_id==1){
            $qrery = "SELECT count(*) as totalTimes,UserName FROM ProjectorLog WHERE Comments IN ('Display Start') AND UserName NOT IN ('viaadmin','ApiUser') AND !(UserProfile REGEXP '^-?[0-9]+$') $condition Group by UserName order by totalTimes DESC limit 25 ";   
          }else{
            $qrery = "SELECT count(DISTINCT(A.ProjectorLogID)) as totalTimes,A.UserName FROM ProjectorLog A
            INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
            INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID						 
            WHERE C.user_id_fk='$user_id' AND A.Comments IN ('Display Start') AND A.UserName NOT IN ('viaadmin','ApiUser') AND !(UserProfile REGEXP '^-?[0-9]+$') $condition Group by A.UserName order by totalTimes DESC limit 25";
          }
          $queryResult = $this->appObj->returnQueryData($qrery);
        foreach($queryResult as $result){
            $testArr[]=array((string)$result['UserName'],(int)$result['totalTimes']);  
        }
        $json_arr=json_encode($testArr);
        $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
        return new ViewModel(array('form'=>$form,'json_arr'=>$json_arr));
    }

    /*****
	 *	@Function Name: topInactiveUsersAction
	 *  @description  : get top 25 Inactive users
	 *	@Author		  : Vineet
	 *  @Date         : 17-april-2020
	 *****/
    public function topInactiveUsersAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('enddate')!="" ) {
            $startDate  = htmlspecialchars($request->getPost('startdate'));
            $endDate = htmlspecialchars($request->getPost('enddate'));
            if($startDate!="" && $endDate!=""){
                $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
            }
        }
        else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
        }
        
        // get the user count based on login 
		 if($this->user_id==1){
            $qrery = "SELECT count(*) as totalTimes,UserName FROM ProjectorLog WHERE UserName NOT IN (SELECT UserName FROM ProjectorLog WHERE Comments ='Display Start' ) AND UserName NOT IN ('viaadmin','ApiUser') AND !(UserProfile REGEXP '^-?[0-9]+$') $condition Group by UserName order by totalTimes DESC limit 25";   
          }else{
              $qrery = "SELECT count(DISTINCT(A.ProjectorLogID)) as totalTimes,A.UserName FROM ProjectorLog A
                        INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                        INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID						 
                        WHERE C.user_id_fk='$this->user_id' AND A.UserName NOT IN (SELECT UserName FROM ProjectorLog WHERE Comments ='Display Start' ) AND A.UserName NOT IN ('viaadmin','ApiUser') AND !(UserProfile REGEXP '^-?[0-9]+$') $condition Group by A.UserName order by totalTimes DESC limit 25"; 
          }
        
        $queryResult = $this->appObj->returnQueryData($qrery);
        foreach($queryResult as $result){
            $testArr[]=array((string)$result['UserName'],(int)$result['totalTimes']);
        }
        $json_arr=json_encode($testArr);
        $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
        return new ViewModel(array('form'=>$form,'json_arr'=>$json_arr));

    }


}