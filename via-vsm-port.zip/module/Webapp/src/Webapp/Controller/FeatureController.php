<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;

class FeatureController extends AbstractActionController {
	//checking session
	public function onDispatch(MvcEvent $e) {
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['sessionTimeOut'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
		
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index', array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
        
	public function gatewayFeaturesAction() {
		$session = new Container('userinfo');
                $loginName = $session->offsetGet('LoginName');
                $this->getTblGatewayFeatureTempTable()->clearTableData();
                if(CHECK_FILE_ASSOCIATE_FILE == 1){
                    $get_whiteBoardAssociateFileContent=file_read(DEST_PATH.FILE_ASSOCIATE_FILE);
                }
                if(CHECK_FILE_BROWSE_ASSOCIATE==1){
                    $get_browseAssociateFileContent=file_read(DEST_PATH.FILE_BROWSE_ASSOCIATE);
                }
                if(CHECK_FILE_LYNC_ASSOCIATE==1){
                    $get_lyncAssociateFileContent=file_read(DEST_PATH.FILE_LYNC_ASSOCIATE);
                }
                if(CHECK_FILE_SKYPE_ASSOCIATE==1){
                    $get_skypeAssociateFileContent=file_read(DEST_PATH.FILE_SKYPE_ASSOCIATE);
                }

                $checkViaFile=file_exists(SECOND_DEST_PATH.'via.txt')?1:0;

                $rcount = $this->getTblGatewayFeaturesPositionTable()->getGwayFeaturesPositionCount();
                if($rcount==0){
                    $this->getTblGatewayFeaturesTable()->updateFeatureStatus('1');
                    $icon_sql = $this->getTblGatewayFeaturesTable()->fetchAll();
                }else{
                    $icon_sql = $this->getTblGatewayFeaturesTable()->fetchAllWithPosition();
                }
 
                // Sort the array  
                usort($icon_sql, function($a, $b) {
                    return $b['feature_status'] - $a['feature_status'];
                });
                $featureCount = count($icon_sql);
                $AppObj = new ApplicationController();
                $settingValue = $AppObj->getTableAllData('tbl_hq_configuration')->current();
                $gwaySettingVal = $settingValue['HQ_GwayFeatureSetting'];
                return new ViewModel(array(
                    'gwaySettingVal' => $gwaySettingVal,
                    'icon_sql' => $icon_sql,
                    'featureCount' => $featureCount,
                ));		
	}
        
        //Ajax to reposition gateway feature icons - Added by Ranjan
        public function applyGatewayFeaturesToFileAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname=DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $flag = trim($request->getPost('flag'));
                $reorderFeatures = trim($request->getPost('reorderFeatures'));
                // Flag 1 means data saved into text file
                $flag1Rows = $this->getTblGatewayFeatureTempTable()->getDeletedFeatures(1);
                if($flag1Rows['count']>0){
                    foreach($flag1Rows['data'] as $tempData){
                        $temp_featured_id=$tempData['feature_deleted_id'];
                        $this->getTblGatewayFeaturesTable()->updateStatusWhere('0',$temp_featured_id);
                    }
                    $this->getTblGatewayFeatureTempTable()->truncateTable();
                }  

                $flag2Rows = $this->getTblGatewayFeatureTempTable()->getDeletedFeatures(2);
                if($flag2Rows['count']>0){		   
                    foreach($flag2Rows['data'] as $tempData){
                       $newtemp_featured_id=$tempData['feature_deleted_id'];
                       $this->getTblGatewayFeaturesTable()->updateStatusWhere('1',$newtemp_featured_id);
                    }
                    $this->getTblGatewayFeatureTempTable()->truncateTable();
              }  

                if($flag==1){
                    $rcount = $this->getTblGatewayFeaturesPositionTable()->getGwayFeaturesPositionCount();
                    if($rcount==0){
                        $featureData = $this->getTblGatewayFeaturesTable()->fetchAll();
                        foreach($featureData as $data){
                            $this->getTblGatewayFeaturesPositionTable()->insertFeaturesPosition($data['id']);
                        }
                    }
                    $qry1 = $this->getTblGatewayFeaturesTable()->fetchAllWithPosition();
                }


                if($flag==2){
                    $this->getTblGatewayFeaturesPositionTable()->truncateTable();
                    $explodeArr=explode(',',$reorderFeatures);
                    //var_dump($explodeArr);
                    foreach($explodeArr as $key=>$val){
                            $this->getTblGatewayFeaturesPositionTable()->insertFeaturesPosition($val);
                    }
                    $qry1 = $this->getTblGatewayFeaturesTable()->fetchAllWithPosition();
                }
                $this->getActivityLogMasterTable()->setActivity($loginName, APPLY_BTN, MSG_GATEWAY_FEATURESBY, $hostname);
                sleep(1);
                if(count($qry1)>0){
                    $str="";
                    foreach($qry1 as $data){
                        $status=$data['feature_status'];
                        $feature_btn_name=($data['feature_status']==1)?$data['feature_btn_name']:'BL';
                        if($status==1){
                            $str.=$feature_btn_name."#";
                        }else{
                            $str.=$feature_btn_name."#";
                        }
                    }
                }

                $newstr=substr_replace($str,'',-1);								
                if(GET_OS=="LIN"){
                        $strArr=explode("#",$newstr);
                        $firstStr=$strArr[0]."#BL#BL#";
                        $linuxStr="";
                        for($i=0;$i<count($strArr);$i++){
                            if($i!=0){
                                $linuxStr.=$strArr[$i]."#";
                            }
                        }					
                        $linuxNewStr=substr_replace($linuxStr,'',-1);
                        $newstr=$firstStr.$linuxNewStr;
                }				
                $file=DEST_PATH.FILE_GATEWAY_FEATURES;	
                if(file_exists($file)){
                        $fileOpen = fopen($file, 'r+');				
                        file_put_contents($file,$newstr);
                        fclose($fileOpen);
                        echo 'success';
                        exit;		
                }else{
                   $fh = fopen($file, 'w') or die("can't open file");
                   fwrite($fh, $newstr);
                   fclose($fh);
                   echo 'success';
                   exit;
                }
            }    	
        }
        
        //Ajax to deactivate gateway features - Added by Ranjan
        public function deactivateGatewayFeaturesAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname=DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $iconID = trim($request->getPost('iconID'));
                $delFlag = trim($request->getPost('delFlag'));
                $modelContent = PRODUCT_TYPE;
                $this->getTblGatewayFeatureTempTable()->insertData(array('feature_deleted_id'=>$iconID, 'delete_flag'=>$delFlag));
                echo $modelContent;exit;
            }
        }
        
        public function resetGatewayOrClientsFeaturesAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname=DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $resetFlag = trim($request->getPost('resetFlag'));
                if($resetFlag==1){
                        $this->getTblGatewayFeaturesTable()->updateAll('1');
                        $this->getTblGatewayFeaturesPositionTable()->truncateTable();
                        $this->getTblGatewayFeatureTempTable()->truncateTable();
                        $file=DEST_PATH.FILE_GATEWAY_FEATURES;					
                        if(file_exists($file)){
                            unlink($file);
                        }
                        $this->getActivityLogMasterTable()->setActivity($loginName, RESET_BTN, MSG_GATEWAY_FEATURESBY, $hostname);
                        echo"success";
                        exit;
                }

                if($resetFlag==2){
                        $this->getTblClientFeaturesTable()->updateAll('1');
                        $this->getTblClientFeaturesPositionTable()->truncateTable();
                        $this->getTblClientFeatureTempTable()->truncateTable();		
                        $file=DEST_PATH.FILE_CLIENT_FEATURES;					
                        if(file_exists($file)){
                                unlink($file);
                        }
                        $this->getActivityLogMasterTable()->setActivity($loginName, RESET_BTN, MSG_CLIENT_FEATURESBY, $hostname);
                        echo"success";
                        exit;
                }

                if($resetFlag==3){
                        $icon = trim($request->getPost('iconname'));
                        if($icon=='whiteboard'){
                                $file=DEST_PATH.FILE_ASSOCIATE_FILE;
                        }
                        if($icon=='browser'){
                                $file=DEST_PATH.FILE_BROWSE_ASSOCIATE;
                        }
                        if($icon=='lync'){
                                $file=DEST_PATH.FILE_LYNC_ASSOCIATE;
                        }
                        if($icon=='skype'){
                                $file=DEST_PATH.FILE_SKYPE_ASSOCIATE;
                        }				
                        if(file_exists($file)){
                                unlink($file);
                        }
                        echo"success";
                        exit;
                }
            }
           
        }
        
	public function clientFeaturesAction() {
		$session = new Container('userinfo');
                $loginName = $session->offsetGet('LoginName');
                $this->getTblClientFeatureTempTable()->clearTableData();
 		
                $rcount = $this->getTblClientFeaturesPositionTable()->getClientsFeaturesPositionCount();
                if($rcount==0){
                    $this->getTblClientFeaturesTable()->updateFeatureStatus('1');
                    $icon_sql = $this->getTblClientFeaturesTable()->fetchAll();
                }else{
                    $icon_sql = $this->getTblClientFeaturesTable()->fetchAllWithPosition();
                }
                $featureCount = count($icon_sql);
                $AppObj = new ApplicationController();
                $settingValue = $AppObj->getTableAllData('tbl_hq_configuration')->current();
                $clientSettingVal = $settingValue['HQ_ClientFeatureSetting'];
                // Sort the array  
                usort($icon_sql, function($a, $b) {
                    return $b['feature_status'] - $a['feature_status'];
                });
                return new ViewModel(array(
                    'clientSettingVal' => $clientSettingVal,
                    'icon_sql' => $icon_sql,
                    'featureCount' => $featureCount,
                ));
	}
        
        public function applyClientFeaturesToFileAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname=DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $flag = trim($request->getPost('flag'));
                $reorderFeatures = trim($request->getPost('reorderFeatures'));
                // Flag 1 means data saved into text file
                $flag1Rows = $this->getTblClientFeatureTempTable()->getDeletedFeatures(1);
                if($flag1Rows['count']>0){
                    $AppObj = new ApplicationController();
                    $connection = $AppObj->getConnection();
                    $chatRecordExist = $this->getTblClientFeaturesTable()->getChatInfo();
                    if($chatRecordExist==1){
                        $chatfileName=DEST_PATH.FILE_CHAT;
                        if(file_exists($chatfileName)){
                                unlink($chatfileName);
                        }
                    }
                    foreach($flag1Rows['data'] as $tempData){
                        $temp_featured_id=$tempData['feature_deleted_id'];
                        $this->getTblClientFeaturesTable()->updateStatusWhere('0',$temp_featured_id);
                    }
                    $this->getTblClientFeatureTempTable()->truncateTable();
                }  

                $flag2Rows = $this->getTblClientFeatureTempTable()->getDeletedFeatures(2);
                if($flag2Rows['count']>0){		   
                    foreach($flag2Rows['data'] as $tempData){
                       $newtemp_featured_id=$tempData['feature_deleted_id'];
                       $this->getTblClientFeaturesTable()->updateStatusWhere('1',$newtemp_featured_id);
                    }
                    $this->getTblClientFeatureTempTable()->truncateTable();
              }  

                if($flag==1){
                    $rcount = $this->getTblClientFeaturesPositionTable()->getClientsFeaturesPositionCount();
                    if($rcount==0){
                        $featureData = $this->getTblClientFeaturesTable()->fetchAll();
                        foreach($featureData as $data){
                            $this->getTblClientFeaturesPositionTable()->insertFeaturesPosition($data['id']);
                        }
                    }
                    $qry1 = $this->getTblClientFeaturesTable()->fetchAllWithPosition();
                }


                if($flag==2){
                    $this->getTblClientFeaturesPositionTable()->truncateTable();
                    $explodeArr=explode(',',$reorderFeatures);
                    //var_dump($explodeArr);
                    foreach($explodeArr as $key=>$val){
                            $this->getTblClientFeaturesPositionTable()->insertFeaturesPosition($val);
                    }
                    $qry1 = $this->getTblClientFeaturesTable()->fetchAllWithPosition();
                }
                $this->getActivityLogMasterTable()->setActivity($loginName, APPLY_BTN, MSG_CLIENT_FEATURESBY, $hostname);
                if(count($qry1)>0){
                    $str="";
                    foreach($qry1 as $data){
                        $status=$data['feature_status'];
                        $feature_btn_name=($data['feature_status']==1)?$data['feature_btn_name']:'BL';
                        if($status==1){
                            $str.=$feature_btn_name."#";
                        }else{
                            $str.=$feature_btn_name."#";
                        }
                    }
                }

                $newstr=substr_replace($str,'',-1);								
                $file=DEST_PATH.FILE_CLIENT_FEATURES;	
                if(file_exists($file)){
                        $fileOpen1 = fopen($file, 'r+');				
                        file_put_contents($file,$newstr);
                        echo 'success';
                        exit;		
                }else{
                   $fh1 = fopen($file, 'w') or die("can't open file");
                   fwrite($fh1, $newstr);
                   echo 'success';
                   exit;
                }
            }    	
        }
        
        public function deactivateClientFeatuesAction(){
                $session = new Container('userinfo');
                $loginName = $session->offsetGet('LoginName');
                $hostname=DEFAULT_SERVER_IP;
                $request = $this->getRequest();
                if($request->isXmlHttpRequest()){
                    $iconID = trim($request->getPost('iconID'));
                    $delFlag = trim($request->getPost('delFlag'));
                    $modelContent = PRODUCT_TYPE;
                    $this->getTblClientFeatureTempTable()->insertData(array('feature_deleted_id'=>$iconID, 'delete_flag'=>$delFlag));
                    echo $modelContent;exit;
                }
        }

	public function mobileFeaturesAction() {
		$session = new Container('userinfo');
                $loginName = $session->offsetGet('LoginName');
                $this->getTblMobileFeatureTempTable()->clearTableData();
 		
                $rcount = $this->getTblMobileFeaturesPositionTable()->getMobileFeaturesPositionCount();
                if($rcount==0){
                    $this->getTblMobileFeaturesTable()->updateFeatureStatus('1');
                    $icon_sql = $this->getTblMobileFeaturesTable()->fetchAll();
                }else{
                    $icon_sql = $this->getTblMobileFeaturesTable()->fetchAllWithPosition();
                }
                $featureCount = count($icon_sql);
                $AppObj = new ApplicationController();
                $settingValue = $AppObj->getTableAllData('tbl_hq_configuration')->current();
                $mobileSettingVal = $settingValue['HQ_MobileFeatureSetting'];
                // Sort the array  
                usort($icon_sql, function($a, $b) {
                    return $b['feature_status'] - $a['feature_status'];
                });
                return new ViewModel(array(
                    'mobileSettingVal' => $mobileSettingVal,
                    'icon_sql' => $icon_sql,
                    'featureCount' => $featureCount,
                ));
	}
        
        public function applyMobileFeaturesToFileAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname=DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $flag = trim($request->getPost('flag'));
                $reorderFeatures = trim($request->getPost('reorderFeatures'));
                // Flag 1 means data saved into text file
                $flag1Rows = $this->getTblMobileFeatureTempTable()->getDeletedFeatures(1);
                if($flag1Rows['count']>0){
                    $AppObj = new ApplicationController();
                    $connection = $AppObj->getConnection();
                    foreach($flag1Rows['data'] as $tempData){
                        $temp_featured_id=$tempData['feature_deleted_id'];
                        $this->getTblMobileFeaturesTable()->updateStatusWhere('0',$temp_featured_id);
                    }
                    $this->getTblMobileFeatureTempTable()->truncateTable();
                }  

                $flag2Rows = $this->getTblMobileFeatureTempTable()->getDeletedFeatures(2);
                if($flag2Rows['count']>0){		   
                    foreach($flag2Rows['data'] as $tempData){
                       $newtemp_featured_id=$tempData['feature_deleted_id'];
                       $this->getTblMobileFeaturesTable()->updateStatusWhere('1',$newtemp_featured_id);
                    }
                    $this->getTblMobileFeatureTempTable()->truncateTable();
              }  

                if($flag==1){
                    $rcount = $this->getTblMobileFeaturesPositionTable()->getMobileFeaturesPositionCount();
                    if($rcount==0){
                        $featureData = $this->getTblMobileFeaturesTable()->fetchAll();
                        foreach($featureData as $data){
                            $this->getTblMobileFeaturesPositionTable()->insertFeaturesPosition($data['id']);
                        }
                    }
                    $qry1 = $this->getTblMobileFeaturesTable()->fetchAllWithPosition();
                }


                if($flag==2){
                    $this->getTblMobileFeaturesPositionTable()->truncateTable();
                    $explodeArr=explode(',',$reorderFeatures);
                    //var_dump($explodeArr);
                    foreach($explodeArr as $key=>$val){
                            $this->getTblMobileFeaturesPositionTable()->insertFeaturesPosition($val);
                    }
                    $qry1 = $this->getTblMobileFeaturesTable()->fetchAllWithPosition();
                }
                $this->getActivityLogMasterTable()->setActivity($loginName, APPLY_BTN, MSG_MOBILE_FEATURESBY, $hostname);
                if(count($qry1)>0){
                    $str="";
                    foreach($qry1 as $data){
                        $status=$data['feature_status'];
                        $feature_btn_name=($data['feature_status']==1)?$data['feature_btn_name']:'BL';
                        if($status==1){
                            $str.=$feature_btn_name."#";
                        }else{
                            $str1.=$feature_btn_name."#";
                        }
                    }
                }
                $concatStr=$str.$str1;
                $newstr=substr_replace($concatStr,'',-1);
                $configCount = $this->getTblFeatureConfigSettingTable()->fetchFeatures('mobile');
                if($configCount>0){
                    $this->getTblFeatureConfigSettingTable()->updateFeatureConfigSetting('mobile', $newstr);
                    echo 'success';
                    exit;			
                }else{
                    $this->getTblFeatureConfigSettingTable()->insertFeatureConfigSetting('mobile', $newstr);
                    echo 'success';
                    exit;
                }
            }    	
        }
        
        public function deactivateMobileFeatuesAction(){
                $session = new Container('userinfo');
                $loginName = $session->offsetGet('LoginName');
                $hostname=DEFAULT_SERVER_IP;
                $request = $this->getRequest();
                if($request->isXmlHttpRequest()){
                    $iconID = trim($request->getPost('iconID'));
                    $delFlag = trim($request->getPost('delFlag'));
                    $modelContent = PRODUCT_TYPE;
                    $this->getTblMobileFeatureTempTable()->insertData(array('feature_deleted_id'=>$iconID, 'delete_flag'=>$delFlag));
                    echo $modelContent;exit;
                }
        }
        
        public function resetMobileFeaturesAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname=DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $resetFlag = trim($request->getPost('resetFlag'));
                if($resetFlag==2){
                        $this->getTblMobileFeaturesTable()->updateFeatureStatus('1');
                        $this->getTblMobileFeaturesPositionTable()->truncateTable();	
                        $this->getTblMobileFeatureTempTable()->truncateTable();
                        $defaultMobileFeatures = $this->getDefaultMobileFeatures();
                        $this->getTblFeatureConfigSettingTable()->updateFeatureConfigSetting('mobile', $defaultMobileFeatures);
                        $this->getActivityLogMasterTable()->setActivity($loginName, RESET_BTN, MSG_MOBILE_FEATURESBY, $hostname);
                        echo"success";
                        exit;
                }
            }
        }
        
        //Get default mobile features
        function getDefaultMobileFeatures(){
            $mobdata = $this->getTblMobileFeaturesTable()->getFeatureName();
            $str=''; 
            foreach($mobdata as $val){
                        $str.=$val.'#';
            }
            return $str=trim(substr($str,0,-1));	
        }
	
        public function getTblGatewayFeaturesTable(){
            if (!$this->TblGatewayFeaturesTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblGatewayFeaturesTable = $sm->get('Webapp\Model\TblGatewayFeaturesTable');
            }
            return $this->TblGatewayFeaturesTable;
        }
        
        public function getTblGatewayFeaturesPositionTable(){
            if (!$this->TblGatewayFeaturesPositionTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblGatewayFeaturesPositionTable = $sm->get('Webapp\Model\TblGatewayFeaturesPositionTable');
            }
            return $this->TblGatewayFeaturesPositionTable;
        }
        
        public function getTblGatewayFeatureTempTable(){
            if (!$this->TblFeatureTempTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblFeatureTempTable = $sm->get('Webapp\Model\TblFeatureTempTable');
            }
            return $this->TblFeatureTempTable;
        }
        
	public function getTblClientFeaturesTable() {
		if(!$this->TblClientsFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
		}
		return $this->TblClientsFeaturesTable;
	}
        
        public function getTblClientFeaturesPositionTable(){
            if (!$this->TblClientsFeaturesPositionTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblClientsFeaturesPositionTable = $sm->get('Webapp\Model\TblClientsFeaturesPositionTable');
            }
            return $this->TblClientsFeaturesPositionTable;
        }
        
        public function getTblClientFeatureTempTable(){
            if (!$this->TblClientsFeatureTempTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblClientsFeatureTempTable = $sm->get('Webapp\Model\TblClientsFeatureTempTable');
            }
            return $this->TblClientsFeatureTempTable;
        }
        
	public function getTblMobileFeaturesTable() {
		if(!$this->TblMobileFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblMobileFeaturesTable = $sm->get('Webapp\Model\TblMobileFeaturesTable');
		}
		return $this->TblMobileFeaturesTable;
	}
        
        public function getTblMobileFeaturesPositionTable(){
            if (!$this->TblMobileFeaturesPositionTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblMobileFeaturesPositionTable = $sm->get('Webapp\Model\TblMobileFeaturesPositionTable');
            }
            return $this->TblMobileFeaturesPositionTable;
        }

        public function getTblMobileFeatureTempTable(){
            if (!$this->TblMobileFeatureTempTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblMobileFeatureTempTable = $sm->get('Webapp\Model\TblMobileFeatureTempTable');
            }
            return $this->TblMobileFeatureTempTable;
        }

	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}
        
        public function getTblFeatureConfigSettingTable(){
            if(!$this->TblFeatureConfigSettingTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblFeatureConfigSettingTable = $sm->get('Webapp\Model\TblFeatureConfigSettingTable');
            }
            return $this->TblFeatureConfigSettingTable;
        }

        
}
