<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Form\ViaReportForm;
use Webapp\Controller\ApplicationController;

class ReportFeatureController extends AbstractActionController {

    public $session;
    public $user_id;
    public $appObj;
    public function __construct() {
        $session = new Container('userinfo');
		$this->user_id = $session->offsetGet('usrid');
        $this->appObj = new ApplicationController();
        
    }

    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
       /*****
	 *	@Function Name: viaFeatureUsageAction
	 *  @description  : get via feature usage
	 *	@Author		  : Vineet
	 *  @Date         : 14-april-2020
	 *****/
    public function viaFeatureUsageAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        $whiteBoardCount=0;
        $fileCount=0;
        $thirdPartyCount=0;
        $veiwMainCount=0;
        $mediaCount=0;
        $collabCount=0;
        $recordingCount=0;
        $codition="";

        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('startdate')!="") {
            $startDate  = $request->getPost('startdate');
            $endDate = $request->getPost('enddate');
            if($startDate!="" && $endDate!=""){
				$codition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
			}
            
        }
        else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $codition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
        }
        /***WhiteBoard count***/
	     if($this->user_id==1){
            $query1 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='WhiteBoardStart' $codition";
        }else{
            $query1 = "SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
                                   INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                   INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                                   WHERE C.user_id_fk='$this->user_id' AND Comments='WhiteBoardStart' $codition";
        }
        $resutData = $this->appObj->returnQueryData($query1);
        if($resutData->count()>0)
        {
            $totalWhite= $resutData->current();
            $whiteBoardCount=$totalWhite['count'];
        }
        /***File Transfer count***/
		if($this->user_id==1){
            $query2 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='FileTransferStart' $codition";
        }else{
            $query2 = "SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
                                   INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                   INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                                   WHERE C.user_id_fk='$this->user_id' AND Comments='FileTransferStart' $codition";
        }

        $queryResult = $this->appObj->returnQueryData($query2);
        if($queryResult->count()>0)
        {
            $totalfile= $queryResult->current();
            $fileCount=$totalfile['count'];
        }


        /***Third party apps count***/
		if($this->user_id==1){
            $query3 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='ThirdPartyAppStart' $codition";
        }else{
            $query3 ="SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
                                   INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                   INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                                   WHERE C.user_id_fk='$this->user_id' AND Comments='ThirdPartyAppStart' $codition";
        }
        $query3Result = $this->appObj->returnQueryData($query3);
        if($query3Result->count()>0){
           $totalThird= $query3Result->current();
           $thirdPartyCount=$totalThird['count'];
       }

       /***View main display count***/
		if($this->user_id==1){
            $query4 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='VMDStart' $codition";
        }else{
            $query4 = "SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
                                   INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                   INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                                   WHERE C.user_id_fk='$this->user_id' AND Comments='VMDStart' $codition";
        }
       $query4Result = $this->appObj->returnQueryData($query4);
       if($query4Result->count()>0){
           $totalView= $query4Result->current();
           $veiwMainCount=$totalView['count'];
       }

       	/****Media count***/
		if($this->user_id==1){
            $query5 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='MediaStart' $codition";
        }else{
            $query5 ="SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
                                   INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                   INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                                   WHERE C.user_id_fk='$this->user_id' AND Comments='MediaStart' $codition";
        }
        $query5Result = $this->appObj->returnQueryData($query5);
       if($query5Result->count()>0){
        $totalMedia= $query5Result->current();
        $mediaCount=$totalMedia['count'];
       }

       /***Collaboration count***/
		if($this->user_id==1){
            $query6 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='CollaborationStart' $codition";
        }else{
            $query6 = "SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
                                   INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                   INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                                   WHERE C.user_id_fk='$this->user_id' AND Comments='CollaborationStart' $codition";
        }
        $query6Result = $this->appObj->returnQueryData($query6);
       if($query6Result->count()>0){
           $totalCollab =$query6Result->current();
           $collabCount=$totalCollab['count'];
       }
        /***Recording ***/
		if($this->user_id==1){
			 $query7 = "SELECT count(*) as count FROM ProjectorLog WHERE Comments='RecordingStart' $codition";
		 }else{
			 $query7 = "SELECT count(DISTINCT(A.ProjectorLogID)) as count FROM ProjectorLog A
			                        INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                                    INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
			                        WHERE C.user_id_fk='$this->user_id' AND Comments='RecordingStart' $codition";
         }
         $query7Result = $this->appObj->returnQueryData($query7);
		if($query7Result->count()>0){
            $totalRecord =$query7Result->current();
		    $recordingCount=$totalRecord['count'];
        }
        $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
        return new ViewModel(array('form'=>$form,
        'whiteBoardCount'=> $whiteBoardCount,
        'fileCount'=>$fileCount,
        'thirdPartyCount'=>$thirdPartyCount,
        'veiwMainCount'=>$veiwMainCount,
        'mediaCount'=>$mediaCount,
        'collabCount'=>$collabCount,
        'recordingCount'=>$recordingCount));
    }

}