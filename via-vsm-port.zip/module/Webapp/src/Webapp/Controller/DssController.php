<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\Controller\WebProducerController;

class DssController extends AbstractActionController {	

	protected $wifiSecurityFilekey = "1324587099345678";	
	protected $logincmd = "<P>
		<UN>websetting</UN>
		<Pwd></Pwd>
		<Cmd>Login</Cmd>
		<P1></P1>
		<P2></P2>
		<P3></P3>
		<P4></P4>
		<P5></P5>
		<P6></P6>
		<P7></P7>
		<P8></P8>
		<P9></P9>
		<P10></P10>
	</P>";
	protected $actionCmd = "<P>
		<UN>websetting</UN>
		<Pwd></Pwd>
		<Cmd>fontCheck</Cmd>
		<P1></P1>
		<P2></P2>
		<P3></P3>
		<P4></P4>
		<P5></P5>
		<P6></P6>
		<P7></P7>
		<P8></P8>
		<P9></P9>
		<P10></P10>
	</P>";
	
	public function getPlaylistScheduleMasterTable() {
		if(!$this->TblPlaylistScheduleMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblPlaylistScheduleMasterTable = $sm->get('Webapp\Model\TblPlaylistScheduleMasterTable');
		}
		return $this->TblPlaylistScheduleMasterTable;
	}

	public function getPlaylistNowTable() {
		if(!$this->TblPlaylistNowTable) {
			$sm = $this->getServiceLocator();
			$this->TblPlaylistNowTable = $sm->get('Webapp\Model\TblPlaylistNowTable');
		}
		return $this->TblPlaylistNowTable;
	}

	public function sendDataRabbitMq($rabbitMqData) {
		// rabbitmq command starts
		$dataBind = array();
		$dataBind["bindingKey"] = "vsm_dss";
		$rabbitMqDataJson = json_encode($rabbitMqData);
		$rabbitMqObject = new WebProducerController();
		$rabbitMqObject->rabbitWebProducerActionDss($rabbitMqDataJson, $dataBind);
	}

	public function getGatewayModelName() {
		$modelValue = "nojsonfile";
		if(file_exists(DEST_PATH."model.json")){
			$jsonStr = file_get_contents(DEST_PATH."model.json");
			$jsonArray = json_decode($jsonStr, true);
			$modelValue = $jsonArray['modelvalue'];			
		}	
		return $modelValue;
	}

	public function deleteDssLicenseUsedAction() {
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$id = $postData["id"];
		$uniqueId = $postData["uniqueId"];
		$tableDssInfoData = $this->getDssInfoTable();
		$deviceId = $tableDssInfoData->getDeviceIdByIdDssFileAuth($id);
		$deleteFilter = array("id" => $id);		
		$dataDeleted = $tableDssInfoData->deleteDssActiveLicenseData($deleteFilter);
		foreach($dataDeleted as $key => $value) {			
			$searchFilter = array("uniqueId" => $value);
			$tableDssLicenseMaster = $this->getDssLicenseMasterTable();
			$licenseUsedData = $tableDssLicenseMaster->getNumLicenseUsed($searchFilter);
			foreach($licenseUsedData as $row) {
				$resultSetJson = json_encode($row); 
				$resultSet = json_decode($resultSetJson, true);
			}
			$numLicenseUsed = $resultSet["num_of_lic_used"]; 
			$numLicenseUsedUpdate = $numLicenseUsed - 1;
			$dataUpdate = array("numLicenseUsed" => $numLicenseUsedUpdate, "uniqueId" => $value);
			$tableDssLicenseMaster->updateNumLicenseUsed($dataUpdate);
		}
		$playlistNowTable = $this->getPlaylistNowTable();
		
		$updatePlaylistNow = array();
		$updatePlaylistNow["sync_status"] = 3;
		$updatePlaylistNowWhere["DID"] = $deviceId; 
		$playlistNowTable->updatePlaylistNow($updatePlaylistNowWhere, $updatePlaylistNow);

		$playListOrderIdsData = $playlistNowTable->getAllOrderIdsByDid($deviceId);
		// 14315 issue reopened fixed missed the data count check
		if(count($playListOrderIdsData) > 0) {
			foreach($playListOrderIdsData as $row) {
				$resultPlayListJson = json_encode($row); 
				$resultSet = json_decode($resultPlayListJson, true);
				$rabbitMqData = array();
				$rabbitMqData["command"] = "delete_schedule";
				$rabbitMqData["sender"] = "web-vsm";
				$rabbitMqData["orderid"] = (int)$resultSet["OID"]; 
				$this->sendDataRabbitMq($rabbitMqData);
			}	
		}	
		echo true;
		exit;
	}

	public function getActivateDssLicenseAction() {
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$uniqueId = $postData["uniqueId"];
		$seachFilter = array("uniqueId" => $uniqueId);
		$tableDssInfoData = $this->getDssInfoTable();
		$dssActiveData = $tableDssInfoData->getDssActiveLicenseData($seachFilter);
		$resultSet = array();	
		$dataSet = array();	
		foreach($dssActiveData as $row) {
			$resultSetJson = json_encode($row); 
			$resultSet = json_decode($resultSetJson, true);
			$dataSet[$resultSet["id"]] = $resultSet;
			if($dataSet[$resultSet["id"]]["licenseDate"] < date("Y-m-d")) {
				$dataSet[$resultSet["id"]]["expired"] = "yes";
			} else {
				$dataSet[$resultSet["id"]]["expired"] = "no";
			}
			$freeLicenseCheck = $tableDssInfoData->checkFreeLicenseDevice($resultSet["did"]);
			$dataSet[$resultSet["id"]]["freeLicense"] = $freeLicenseCheck == true ? "yes" : "no";
		}
		echo json_encode($dataSet);
		exit;
	}

	// re-balancing of license
	public function licenseReBalancingAction() {
		$tableDssInfoData = $this->getDssInfoTable();
		$allUniqueIds = array();
		// fetching all the license currently active.
		$data = $tableDssInfoData->getAllActiveLicensedDevices();	
		foreach($data as $row) {
			$resultSetJson = json_encode($row); 
			$result = json_decode($resultSetJson, true);
			$diff = strtotime($result["expiry_date"]) - strtotime(date("Y-m-d"));  
			//creating the array of the devices which are currently active. Array conatins the id of dss_file_auth, expiry date and days remaining for device to get expire.      
			$expiryRemaining[] = array("id" => $result["id"], 
				"daysRemaining" => abs(round($diff / 86400)), 
				"expiryDate" => $result["expiry_date"], 
				"uniqueId" => $result["unique_id"]
			);    
		}		
		// sum of the total number of days remaining of all the devices.
		$totalRemainingExpirySum = array_sum(array_column($expiryRemaining, 'daysRemaining'));
		// average of the days remaining in expiry and the average days willl be added to the expiry date of each device.
		$daysAddedInExpiryOfEachDevice = round($totalRemainingExpirySum/count($expiryRemaining));		
		foreach($expiryRemaining as $key => $value) {			
			// adding average of the days remaining in expiry to the expiry date.
			$newExpiryDate = date('Y-m-d', strtotime($value["expiryDate"]. ' + '.$daysAddedInExpiryOfEachDevice.' day'));
			$dateSendForUpdateDssAuth = array("id" => $value["id"], "dateTimeStamp" => $newExpiryDate);	 			
			// making the array of unique ids and new expiry date to update the dss master table as well.
			$allUniqueIds[$value["uniqueId"]] = $newExpiryDate;	
	 	    $tableDssInfoData->updateDataDssFileAuthById($dateSendForUpdateDssAuth);			
		}
		// updating the dss master passing the data array to the model
		$tableDssInfoData->updateDssMasterExpiryDate($allUniqueIds);
		echo "done";
		exit;
	}

	public function liscenceInfoAction() {					
		if(PRODUCT == 'via' || PRODUCT == 'kds') {
			$tableDssInfoData = $this->getDssInfoTable();
			$selectResultSet = $tableDssInfoData->getDataForDssLicense();			
			$licensedStatus = $tableDssInfoData->checkDssLicenseValidity();				
			$modelValue = $this->getGatewayModelName();
			if($modelValue === "12" || $modelValue === "11") {
				$viewData = array("modelValue" => $modelValue);
			} else {
				$viewData = array("modelValue" => $modelValue, "selectResultSet" => $selectResultSet, "licensedStatus" => $licensedStatus);
			}
		} else {
			$playlistMasterTable = $this->getPlaylistScheduleMasterTable();
			$allGroups = $playlistMasterTable->getAllDeviceGroupAndInventory();
			$modelValue = $this->getGatewayModelName();
			$tableDssInfoData = $this->getDssInfoTable();
			$licenseStatusVal = $tableDssInfoData->getDataForDssLicenseVsm();		
			$licenseStatus = ($modelValue === "12" || $modelValue === "11") ? 'FULL' : $licenseStatusVal;			
			$allDeviceInventory = array();
			$deviceIds = array();
			$deviceIdsGroupWise = array();
			foreach($allGroups as $row) {
				$resultSetJson = json_encode($row); 
				$result = json_decode($resultSetJson, true);
				$rows[]  = array('deviceGroupId' => $result["deviceGroupId"], 'deviceMasterId' => $result["deviceMasterId"], "deviceGroup" => $result["deviceGroup"]);
				if($result["deviceGroupInventroyID"] != "" && $result["deviceName"] != "") {					
					$isFreeLicenseGw = $tableDssInfoData->checkFreeLicenseDevice($result["deviceInventryId"]);	
					$modelValue = $tableDssInfoData->getDeviceModelValue($result["deviceInventryId"]);		
					$canIssueLicense = $isFreeLicenseGw == true ? "no" : "yes";
					if($isFreeLicenseGw == true) {
						$deviceIds[$result["deviceInventryId"]] =  array("deviceName" => $result["deviceName"], "licenseIssued" => "yes", "canIssueLicense" => $canIssueLicense, "modelValue" => $modelValue);
						$allDeviceInventory[$result["deviceGroupId"]][]= array("deviceName" => $result["deviceName"], "deviceInventoryId" => $result["deviceInventryId"]);
					} else {	
						$newRowData = array();								
						$checkValidLicence = $tableDssInfoData->checkDataVsmLicenseUploaded($result["deviceInventryId"]);
						$isLicenseIssued = count($checkValidLicence) == 0 ? "no" : "yes";
						if($isLicenseIssued == "yes") {
							foreach($checkValidLicence as $newRow) {
								$newRowJson = json_encode($newRow); 
								$newRowData = json_decode($newRowJson, true);
							}									
						}	
						// echo "<pre>";
						// print_r($licenseIssued);
						// echo "</pre>";																			
						$deviceIds[$result["deviceInventryId"]] = array("deviceName" => $result["deviceName"], "licenseIssued" => $isLicenseIssued, "uniqueId" => $newRowData["unique_id"], "licenseMasterId" => $newRowData["id"], "canIssueLicense" => $canIssueLicense, "modelValue" => $modelValue);
						$allDeviceInventory[$result["deviceGroupId"]][]= array("deviceName" => $result["deviceName"], "deviceInventoryId" => $result["deviceInventryId"]);
					}
					$deviceIdsGroupWise[$result["deviceGroupId"]][]= $result["deviceInventryId"];
				}		
			}	
			$allGroups = $this->buildTree($rows);				
			$allGroupsChild = [];
			foreach($allGroups as $key => $value) {
				$allGroupsChild[$key]["children"] = $value["children"];
			}
			$childWiseGroups = $this->getAllChild($allGroupsChild);		
			$this->wifiSecurityFilekey = "1324587099345678";
			$tableDssInfoData = $this->getDssInfoTable();
			$modelValue = $this->getGatewayModelName();
			//if(GET_OS == 'WIN') {
				// this stops the insert entry in dss_license_master table for via go2 and connect2		
				// $tableDssInfoData->insertDataInDssAuthForViaGoTwo();
			//}
			$licenseStatusVal = $tableDssInfoData->getDataForDssLicenseVsm();
			//adding check for go3 and connect3	
			$licenseStatus = ($modelValue === "12" || $modelValue === "11" || $modelValue === "14" || $modelValue === "15") ? 'FULL' : $licenseStatusVal;	
			
			$selectResultSet = $tableDssInfoData->getDataForDssLicenseVsmList();	

			$tableDssLicenseMaster = $this->getDssLicenseMasterTable();
			$getAllDssMaster = $tableDssLicenseMaster->fetchAllDssLicenseMaster();
			
			foreach($getAllDssMaster as $dataDssMaster) {
				$resultSetJson = json_encode($dataDssMaster); 
				$dssMasterDataLicense[] = json_decode($resultSetJson, true);	
			}
			
			foreach( $selectResultSet as $resultSetValue) {
				$resultSetJson = json_encode($resultSetValue); 
				$resultSet[] = json_decode($resultSetJson, true);	
			}			
			// echo "<pre>";
			// print_r($dssMasterDataLicense);
			// echo "</pre>";exit;
			$dssFontInfoData = $this->getDssFontInfoTable();
			$dssUploadedFonts = $dssFontInfoData->getUploadedDssFonts();
			$modelValue = $this->getGatewayModelName();
			$viewData = array("modelValue" => $modelValue, "selectResultSet" => $selectResultSet, "licenseData" => $resultSet, "dssUploadedFonts" => $dssUploadedFonts, "licenseStatus" => $licenseStatus, "modelValue" => $modelValue, "dssMasterDataLicense" => $dssMasterDataLicense, "allDeviceInventory" => $allDeviceInventory, "groupSubGroupData" => $allGroups, "deviceIds" => $deviceIds, "childWiseGroups" => $childWiseGroups);
		}
		
		//Activate via license button code
		if($this->getRequest()->getPost('activateLicensebtn')) {
			$gwayMacAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
			$macAddr=str_replace(':','-',$gwayMacAddr);
			$path="https://license.wowvision.com/";		
			$filename ='KRAMER_'.$macAddr.'.lic';	
			$save_to=realpath(DEST_PATH) . '/'.$filename;	
			$serverurl=$path.$filename;
			$curl = curl_init();
			//die(getcwd().'/config/cacertupdates.crt');
			curl_setopt_array($curl, array(
				CURLOPT_POST => 0,
				CURLOPT_URL => $serverurl,
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_SSL_VERIFYHOST=>0,		
				CURLOPT_CAINFO=>BASE_PATH.'/config/cacertupdates.crt',
				//by pass certificate		
				CURLOPT_SSL_VERIFYPEER=>false,
				CURLOPT_VERBOSE=>1
			));
			
			   $actFlag=1;
			  $file_content = curl_exec($curl);
			 // print_r($file_content);die;
			   if(strstr($file_content,'Not Found')){
					$actFlag=0;
			   }
		 //  die($actFlag);
				curl_close($curl);
				if($actFlag==1)	{ 
					$downloaded_file = fopen($save_to, 'w');
					fwrite($downloaded_file, $file_content);
					fclose($downloaded_file);			
						if(file_exists(DEST_PATH.$filename)){
							copy(DEST_PATH.$filename,DEST_PATH."activation.lic");
							unlink(DEST_PATH.$filename);
							system("sync");
							system("sync");	
							$myfileName=DEST_PATH."newfile.txt";
							$myfile = fopen($myfileName, 'w') or die("can't open file");
							$content = "Last updated on ".date("Y-m-d H:i:s");	
							$confWrite= fwrite($myfile, $content);		
							fclose($myfile);
							sleep(5);	
							$appObj=new ApplicationController();
							$appObj->ActivityLog('Activate','Activated License');
							$appObj = new ApplicationController();
							$retVal=$appObj->reboot_powerOff_Server('reboot');	
							echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";
                                                        die;
						}else{
							echo"<script language='javascript'>alert('License file is not available. Please contact Kramer Support.')</script>";			
						}		
				}else{
					echo"<script language='javascript'>alert('License file is not available. Please contact Kramer Support.');</script>";					
				}
				

		}		
		$viewmodel = new ViewModel($viewData);
		if(PRODUCT == "via"){
			$viewmodel->setTemplate("webapp/utility/system-settings");
		}
		return $viewmodel;
	}

	public function buildTree($elements, $deviceMasterId = 0) {
    	$groups = array();
		foreach ($elements as $element) {
	        if ($element['deviceMasterId'] == $deviceMasterId) {
	            $children = $this->buildTree($elements, $element['deviceGroupId']);
	            if ($children) {
	                $element['children'] = $children;
	            }
	            $groups[$element['deviceGroupId']] = $element;
	        }
	    }
    	return $groups;
	}

	public function getAllChild($elements) {
		$groups = [];
		foreach($elements as $key => $value) {			 
		 	foreach($value as $keyOne => $valueOne) {
		 		foreach((array) $valueOne as $keyTwo => $valueTwo){					
	 				$groups[$key]["children"][] = $valueTwo["deviceGroupId"];
	 				foreach((array) $valueTwo["children"] as $keyThree => $valueThree) {
	 					$groups[$key]["children"][] = $valueThree["deviceGroupId"];
	 					$groups[$valueThree["deviceMasterId"]]["children"][] = $valueThree["deviceGroupId"];	
	 					foreach($valueThree["children"] as $keyFour => $valueFour) {
	 						$groups[$key]["children"][] = $valueFour["deviceGroupId"];
	 						$groups[$valueThree["deviceMasterId"]]["children"][] = $valueFour["deviceGroupId"];
	 						$groups[$valueFour["deviceMasterId"]]["children"][] = $valueFour["deviceGroupId"];	
	 						foreach($valueFour["children"] as $keyFive => $valueFive) {
	 							$groups[$key]["children"][] = $valueFive["deviceGroupId"];
		 						$groups[$valueThree["deviceMasterId"]]["children"][] = $valueFive["deviceGroupId"];
		 						$groups[$valueFour["deviceMasterId"]]["children"][] = $valueFive["deviceGroupId"];	
		 						$groups[$valueFive["deviceMasterId"]]["children"][] = $valueFive["deviceGroupId"];	
	 						}	 						
	 					}	 					
	 				}		 		
		 		}
		 	}
		}
		return $groups;		
	}

	// public function liscenceInfoAction() {		
	// 	// $this->wifiSecurityFilekey = "1324587099345678";			
	// 	$tableDssInfoData = $this->getDssInfoTable();
	// 	$selectResultSet = $tableDssInfoData->getDataForDssLicense();			
	// 	$licensedStatus = $tableDssInfoData->checkDssLicenseValidity();		
	// 	$dssFontInfoData = $this->getDssFontInfoTable();
	// 	$dssUploadedFonts = $dssFontInfoData->getUploadedDssFonts();		
	// 	$modelValue = $this->getGatewayModelName();
	// 	if($modelValue === "12") {
	// 		$viewData = array("modelValue" => $modelValue, "dssUploadedFonts" => $dssUploadedFonts);
	// 	} else {
	// 		$viewData = array("modelValue" => $modelValue, "selectResultSet" => $selectResultSet, "licensedStatus" => $licensedStatus, 
	//     		"dssUploadedFonts" => $dssUploadedFonts);
	// 	}
	//     $viewmodel = new ViewModel($viewData);
	// 	return $viewmodel;
	// }

	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}

	public function getDssInfoTable() {
		if(!$this->TblDssInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblDssInfoTable = $sm->get('Webapp\Model\TblDssInfoTable');
		}
		return $this->TblDssInfoTable;
	}

	public function getDssFontInfoTable() {
		if(!$this->TblDssFontInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblDssFontInfoTable = $sm->get('Webapp\Model\TblDssFontInfoTable');
		}
		return $this->TblDssFontInfoTable;
	}

	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}

	public function getSettingTable() {
		if(!$this->TblSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}

	public function getDssLicenseMasterTable() {
		if(!$this->TblDssLicenseMasterTable) {
            $sm = $this->getServiceLocator();
            $this->TblDssLicenseMasterTable = $sm->get('Webapp\Model\TblDssLicenseMasterTable');
        }
        return $this->TblDssLicenseMasterTable;
	}

	public function updateDssLicenseVsmValidityAction() {
		$postData = $this->getRequest()->getPost()->toArray();	
		$uniqueId = $postData["uniqueId"];		
		// $expiryDate = $postData["expiryDate"];		
		$purchaseDate = $postData["purchaseDate"];	
		$tableDssLicenseMaster = $this->getDssLicenseMasterTable();	
		$tableDssInfoData = $this->getDssInfoTable();
		$macAddr = $tableDssInfoData->getMacAddressForLicense();	
		$validityMonths = $postData["validityMonths"];	 
		foreach($macAddr as $key => $value) {
			$checkDssAuth = $tableDssInfoData->checkDataVsmLicenseUploaded($value["deviceId"]);			
			if(count($checkDssAuth) == 1) {
				foreach($checkDssAuth as $row) {
					$resultSetJson = json_encode($row); 															
					$resultSet = json_decode($resultSetJson, true);																				
					if($resultSet["exipryDaysLeft"] <= 60) {
						$gatewayName = $tableDssInfoData->getDeviceNameById($resultSet["did"]);
						$expiryDate = date("Y-m-d", strtotime("+". $validityMonths ."months", strtotime($resultSet["expiry_date"])));	
						$dateSendForInsertDssAuth = array("did" => $resultSet["did"], "dateTimeStamp" => $expiryDate, "uniqueId" => $uniqueId, "gatewayName" => $gatewayName, "purchaseDate" => $purchaseDate);		
						$tableDssInfoData->insertDataDssFileAuth($dateSendForInsertDssAuth);
					}				
				}
			}
		}
		
		$seachFilter = array("uniqueId" => $uniqueId);
		$uploadedCount = $tableDssInfoData->getDssActiveLicenseCount($seachFilter);
		
		foreach($uploadedCount as $statusData){
			$licenseDataCountJson = json_encode($statusData); 
			$licenseDataCountArray = json_decode($licenseDataCountJson, true);				
		}	
		
		$updateData["num_of_lic_used"] = $licenseDataCountArray['licenseCount'];
		$updateWhere["unique_id"] = $uniqueId;		
		echo $isLicenseUsedUpdated = $tableDssLicenseMaster->updateLicenseUsed($updateWhere, $updateData);exit;
	}

	public function updateDssLicenseVsmAction() {
		$request  = $this->getRequest();
		$postData = \Zend\Json\Json::decode($request->getContent(), true);
		$uniqueId = $postData["uniqueId"];		
		$expiryDate = $postData["expiryDate"];
		$deviceInventoryIds = $postData["deviceInventoryIds"];	
		$purchaseDate = $postData["purchaseDate"];	
		$tableDssLicenseMaster = $this->getDssLicenseMasterTable();	
		$searchFilter = array("uniqueId" => $uniqueId);
		$licenseUsedData = $tableDssLicenseMaster->getNumLicenseUsed($searchFilter);
		foreach($licenseUsedData as $row) {
			$resultSetJson = json_encode($row); 
			$resultSet = json_decode($resultSetJson, true);
		}
		$numLicenseRemaining = $resultSet["num_of_devices"] - $resultSet["num_of_lic_used"]; 		
		if(count($deviceInventoryIds) <= $numLicenseRemaining) {
			$tableDssInfoData = $this->getDssInfoTable();	
			foreach($deviceInventoryIds as $key => $value) {
				$checkDssAuth = $tableDssInfoData->checkDataVsmLicenseUploaded($value);			
				$gatewayName = $tableDssInfoData->getDeviceNameById($value);
	            $dateSendForInsertDssAuth = array("did" => $value, "dateTimeStamp" => $expiryDate, "uniqueId" => $uniqueId, "gatewayName" => $gatewayName, "purchaseDate" => $purchaseDate);	            
	            if(count($checkDssAuth) == 0) { 
					$tableDssInfoData->insertDataDssFileAuth($dateSendForInsertDssAuth);	
	            } else {
	                $tableDssInfoData->updateDataDssFileAuth($dateSendForInsertDssAuth);
	            } 
			}

			$seachFilter = array("uniqueId" => $uniqueId);
			$uploadedCount = $tableDssInfoData->getDssActiveLicenseCount($seachFilter);

			foreach($uploadedCount as $statusData){
				$licenseDataCountJson = json_encode($statusData); 
				$licenseDataCountArray = json_decode($licenseDataCountJson, true);				
			}	
			
			$updateData["num_of_lic_used"] = $licenseDataCountArray['licenseCount'];
			$updateWhere["unique_id"] = $uniqueId;		
			echo $isLicenseUsedUpdated = $tableDssLicenseMaster->updateLicenseUsed($updateWhere, $updateData);
		} else {
			echo "invalid";
		}
		exit;
	} 

	//activate license for VSM starts
	public function activateDssLicenseVsmAction() {
		$postData = $this->getRequest()->getPost()->toArray();			
		$uniqueId = $postData["uniqueId"];
		$expiryDate = $postData["expiryDate"];
		$purchaseDate = $postData["purchaseDate"];
		$numDevices = $postData["numDevices"];
		$tableDssInfoData = $this->getDssInfoTable();
		$macAddr = $tableDssInfoData->getMacAddressForLicense();					

		foreach($macAddr as $key => $value) {
			$checkDssAuth = $tableDssInfoData->checkDataVsmLicenseUploaded($value["deviceId"]);
            $dateSendForInsertDssAuth = array("did" => $value["deviceId"], "dateTimeStamp" => $expiryDate, "uniqueId" => $uniqueId, "gatewayName" => $value["gatewayName"], "purchaseDate" => $purchaseDate);
            if(count($checkDssAuth) == 0) {
				$tableDssInfoData->insertDataDssFileAuth($dateSendForInsertDssAuth);	
            } else {
                $tableDssInfoData->updateDataDssFileAuth($dateSendForInsertDssAuth);
            } 
		}
		
		$seachFilter = array("uniqueId" => $uniqueId);
		$uploadedCount = $tableDssInfoData->getDssActiveLicenseCount($seachFilter);

		foreach($uploadedCount as $statusData){
			$licenseDataCountJson = json_encode($statusData); 
			$licenseDataCountArray = json_decode($licenseDataCountJson, true);				
		}	
		$tableDssLicenseMaster = $this->getDssLicenseMasterTable();	
		$updateData["num_of_lic_used"] = $licenseDataCountArray['licenseCount'];
		$updateWhere["unique_id"] = $uniqueId;		
		echo $isLicenseUsedUpdated = $tableDssLicenseMaster->updateLicenseUsed($updateWhere, $updateData);exit;
	}
	//activate license for VSM ends

	// update license functionality starts	
	public function updateLicenseAction() {				
		$postData = $this->getRequest()->getPost()->toArray();		
		$licenseFile = $this->params()->fromFiles('licenseFile');	
		$appObj = new ApplicationController();			
		if($postData['fileFlag'] == 'newDssLicenseFile') {
			$tableDssInfoData = $this->getDssInfoTable();
			if($licenseFile['error'] == 0) {
				$responseReturn = "license invalid data";
				$licenseFileName = $licenseFile['name'];
				if(PRODUCT == 'via') {
					$upload = move_uploaded_file($licenseFile['tmp_name'], DEST_PATH.$licenseFileName);
				} else {
					$upload = move_uploaded_file($licenseFile['tmp_name'], UPLOAD_DSS_LICENSE.$licenseFileName);
				}
				if($upload) {
					if(PRODUCT == 'via') {
						$wifiSecurityFile = DEST_PATH.$licenseFileName;
						$appObj = new ApplicationController();
						$encrypted = $appObj->file_read($wifiSecurityFile);										
						$decrypted = $appObj->desDecrypt($encrypted,$this->wifiSecurityFilekey);			
						$explodeDecrypted = explode(',',$decrypted);						
						if(GET_OS == 'WIN') {	
							$macAddr = $appObj->file_read(DEST_PATH.FILE_SERIALNO);
						} else {
							$tableDeviceInventoryData = $this->getDeviceInventoryTable();
							$macAddr = $tableDeviceInventoryData->fetchMACAddressForDssLicence();
						}						
						list($serialKey, $dateTimeValue) = explode('|', $explodeDecrypted[0]);							
						if($macAddr == $serialKey) {
							$currentDate = date("y-m-d");
							//if(strtotime($changeDateFormat) > strtotime($currentDate)) {
								if(trim($dateTimeValue) != 'FULL') {
									$changeDateFormat = '20'.substr($dateTimeValue,0,2).'-'.substr($dateTimeValue,2,2).'-'.substr($dateTimeValue,4,2);
									$dayMonthLength = strlen(trim($dateTimeValue));
									$getLicYr = trim(substr($dateTimeValue,0,2));
									$getLicMonth = trim(substr($dateTimeValue,2,2));
									$getLicDays = trim(substr($dateTimeValue,4,2));
									$currentYear = date('y');								
									if($dayMonthLength != 6  || $getLicDays <= 0 || $getLicDays > 31 || $getLicMonth <= 0 || $getLicMonth > 12 || $getLicYr < $currentYear) {
										$flag = 0;
									} else {
										$dateTimeStamp = strtotime($changeDateFormat);
										//store dss expoiry
										$dssExpiryDate=$changeDateFormat;
										$flag = 1;								
									}
								} else if(trim($dateTimeValue) == 'FULL') {
									$dateTimeStamp = 'FULL';
									//store dss expoiry
									$dssExpiryDate='FULL';												
									$flag = 1;	
								}								
								if($flag == 1) {
									$tableDssInfoData = $this->getDssInfoTable();
				                    //$dssInfoTableRec = $tableDssInfoData->getDataForDssLicense();
									$dateSendForInsertDssLicense = array("licenseFileName" => $licenseFileName, "dateTimeStamp" => $dateTimeStamp);
				                    //if(count($dssInfoTableRec) == 0) {
										$tableDssInfoData->inserDataForDssLicense($dateSendForInsertDssLicense);
										//file created dssVIAExpiry.txt
										$dssExpiryfilePath=DEST_PATH.'dssVIAExpiry.txt';
										$dssExpiryFile = fopen($dssExpiryfilePath, 'w');								
										$expiryWrite= fwrite($dssExpiryFile, $dateTimeStamp);
										fclose($dssExpiryFile);			
											
				                    //} else {
				                        //$tableDssInfoData->updateDataForDssLicense($dateSendForInsertDssLicense);
				                    //} 
				                   	$responseReturn = "license uploaded";
								} else if($flag == 0) {
									unlink(DEST_PATH.$licenseFileName);
								}	
							//}
						}
						echo $responseReturn;
						exit;
					} else {
						// error code 4: duplicate file, 5: expiry of file already past, 6: invalid domain, 7: more license are in the file as compare to the total available devices, 8: not a valid license file for DSS 	
						$wifiSecurityFile = DEST_PATH.$licenseFileName;								
						$wifiSecurityFile = UPLOAD_DSS_LICENSE.$licenseFileName;
						$appObj = new ApplicationController();
						$encrypted = $appObj->file_read($wifiSecurityFile);	
						// decrypt the uploaded file									
						$decrypted = $appObj->desDecrypt($encrypted,$this->wifiSecurityFilekey);							
						// convert the uploaded file in an array
						$explodeDecrypted = explode('|',$decrypted);
						$isValidDomain = false;
						// checking the file upload is for the dss
						if($explodeDecrypted[5] != "" && $explodeDecrypted[5] == "DS") {
							// checking the domain is equal to the first value in the file
							if($_SERVER["HTTP_HOST"] == $explodeDecrypted[0]) {
								$isValidDomain = true; 
							} else {
								// if domain is not equal the read the macaddress as per the gateway linux or windows								
								if(GET_OS == 'WIN') {
									$fileContent = $appObj->file_read(FILE_LICENSE_DETAILS);
						            $decodedContent = $appObj->desDecrypt($fileContent, KEY_SEED_NEW);
						            $contentArray = explode("|", $decodedContent);
						            $serialNumber = $contentArray[1];
						            if($serialNumber == $explodeDecrypted[0]) {
							    		$isValidDomain = true; 
							    	}
								} else {
									$macAddress = trim(file_get_contents($_SERVER["DOCUMENT_ROOT"]."/../bin/config/macaddress.txt"));
									if($macAddress == $explodeDecrypted[0]) {
							    		$isValidDomain = true; 
							    	}	
								}	
							}	
							// if the domain or macaddress is equal to the first variable in the file then go in the if case
							if($isValidDomain == true) {
								$unique_id = $appObj->getUniqueRandomNumber(5);
								$order_id = $explodeDecrypted[1];
								$num_of_devices = $explodeDecrypted[2];
								$purchase_date = $explodeDecrypted[3];
								$validity_months = $explodeDecrypted[4];
								$expiry_date = date("Y-m-d", strtotime("+". $explodeDecrypted[4] ."months", strtotime($explodeDecrypted[3])));								
								$currentDate = date("Y-m-d");	
								// checking if file uploaded has the valid as per the expiry must be grater than the current date							
								if($expiry_date > $currentDate) {
									// calculating the total of number of device has active licencse
									$activeLicenseDataCount = $tableDssInfoData->getDssActiveLicenseCount("");
									foreach($activeLicenseDataCount as $statusData){
										$licenseDataCountJson = json_encode($statusData); 
										$licenseDataCountArray = json_decode($licenseDataCountJson, true);				
									}											
									// fetching the record by record id in the database if exixts error message elso go ahead				
									$orderIdCheck = array('orderId' => $order_id);
									$tableDssLicenseMaster = $this->getDssLicenseMasterTable();
									$duplicateCheckData = $tableDssLicenseMaster->checkDuplicateOrder($orderIdCheck);
									foreach($duplicateCheckData as $statusData) {
										$resultJson = json_encode($statusData); 
										$resultArray = json_decode($resultJson, true);				
									}		
									$orderIdCount = $resultArray['cnt'];
									
									// if record as per the uploaded file order id not exists
									if($orderIdCount == 0) {
										$insertDataToLicenseMaster = array("unique_id" => $unique_id,
											"order_id" => $order_id,
											"num_of_devices" => $num_of_devices,
											"purchase_date" => $purchase_date,
											"validity_months" => $validity_months,
											"expiry_date" => $expiry_date									
										);
										// insert the uploaded file content ot the database dss_license_master table
										$dssLicenseMasterId = $tableDssLicenseMaster->insertDataDssLicenseMaster($insertDataToLicenseMaster);
										//$dssLicenseMasterId = true;
										$totalInactiveDevices = "";
										$response = "";
										if($dssLicenseMasterId) {			
											// fetching the total number of devices still neeed to be get activated				
											$tableDssInfoData = $this->getDssInfoTable();
											$macAddr = $tableDssInfoData->getMacAddressForLicense();
											$totalDevicesAvailable = is_array($macAddr) ? count($macAddr) : 0;
											$isInitialUpload = $tableDssInfoData->isInitialLicenseUpload();
											if($isInitialUpload == "true") {
												$macAddr = $tableDssInfoData->getMacAddressForLicense();
												if($num_of_devices == $totalDevicesAvailable) {
													$response = 1;
													// activate all message 
												} else {
													// just uploaded the file and later activate manually
													$response = 2;
												} 
											} else {												
												foreach($macAddr as $key => $value) {
													$checkDssAuth = $tableDssInfoData->checkDataVsmLicenseUploaded($value["deviceId"]);
													if(count($checkDssAuth) == 1) {
														foreach($checkDssAuth as $row) {
															$resultSetJson = json_encode($row); 															
															$resultSet = json_decode($resultSetJson, true);															
															if($resultSet["exipryDaysLeft"] <= 60) {
																$totalInactiveDevices = $totalInactiveDevices + 1;
															}				
														}
													}
												}
												if($num_of_devices == $totalInactiveDevices) {
													// activate all devices already activated and about to expire
													$response = 3;													
												} else {
													// just uploaded the file and later activate manually
													$response = 2;
												}				
											}														
											echo $licenseDataCountArray['licenseCount']."~".$unique_id."~".$expiry_date."~".$purchase_date."~".$num_of_devices."~".$response."~".$validity_months;
											exit;
										}	
									}  else {
										// duplicate file
										$response = 4;
									}
								} else {
									// old file;
									$response = 5;
								}
							} else {
								// invalid domain						
								$response = 6;
							}		
						} else {
							// file not for a DSS
							$response = 8;
						}
						echo $response;
						exit;	
					}
				}
			}
		}
	}
	// update license functionality ends
	
	// activate license functionality starts
	function activateDssLicenseAction() {
		$requestType = $this->getRequest()->getPost('type');
		if($requestType == "activateDssLicense") {
			$responseReturn = false;
			$appObj = new ApplicationController();
			// if(GET_OS == 'WIN') {
			// 	$macAddr = trim(file_get_contents(DEST_PATH."/macaddress.txt"));
			// 	$productType = 'via collage';
			// } else {
			// 	$macAddr = trim(file_get_contents($_SERVER["DOCUMENT_ROOT"]."/../bin/config/macaddress.txt"));
			// 	$productType = 'via connect pro';
			// }	
			if(GET_OS == 'WIN') {	
				$macAddr = $appObj->file_read(DEST_PATH.FILE_SERIALNO);
				$productType = 'via collage';
			}
			if(GET_OS == 'LIN') {
				$productType = 'via connect pro';
				$tableDeviceInventoryData = $this->getDeviceInventoryTable();
				$macAddr = $tableDeviceInventoryData->fetchMACAddressForDssLicence();
				$macAddr = str_replace(":", "", $macAddr);
			}
			
			if($macAddr != "") {
				$dateAfterThreeMonths = date("ymd", strtotime("+3 months", strtotime(date("y-m-d"))));
				$vaildId = $macAddr.'|'.$dateAfterThreeMonths;
				$activateLicenseData = array("licUserName" => "viaadmin", 
					"licUserPassword" => "v1dm1n#-09123!#", 
					"licServerData" => array("ProductType" => $productType, "VaildId" => $vaildId), 
					"licServerPath" => "https://discovery.wowvision.com/dss/", 
					"licServerFileName" => "SaveDataN.php"
				);
				$tableDssInfoData = $this->getDssInfoTable();
				$proxyServerSettings = $tableDssInfoData->getProxyServerSettings();				
				$fileContent = $appObj->activateAutoDssLicense($activateLicenseData, $proxyServerSettings, true);
				if($fileContent == "") {
					$fileContent = $appObj->activateAutoDssLicense($activateLicenseData, $proxyServerSettings, false);
				}
				$fileContentMatch =	"https://discovery.wowvision.com/d/downloadFile.php";							
				if(strstr("$fileContent", $fileContentMatch)) {		
					$fileContentArray = explode('?',basename($fileContent)); 
			
					if(isset($fileContentArray)) {
						$filename = $fileContentArray[1].'.lic';
						//file get contents not working that why using curl to read url data
						$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $fileContent);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_POST, 1);
						curl_setopt($ch, CURLOPT_CAINFO, __DIR__."/cacert.crt");
						curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
						curl_setopt($ch, CURLOPT_VERBOSE, 1);
						$contents = curl_exec($ch);
					   
						$downloadededFile = fopen(DEST_PATH.$filename, 'w');
						fwrite($downloadededFile, $contents);
						fclose($downloadededFile);
						if(file_exists(DEST_PATH.$filename)) {
							$myfileName = DEST_PATH.FILE_NEW;
							$myfile = fopen($myfileName, 'w') or die("can't open file");
							$content = "Last updated on ".date("Y-m-d H:i:s");	
							$confWrite= fwrite($myfile, $content);	                        
							fclose($myfile);
							//sleep(5);                                                                     
							$decrypted = $appObj->desDecrypt($contents, $this->wifiSecurityFilekey);
							list($serialKey, $dateTimeValue) = explode('|',$decrypted);
							if(trim($dateTimeValue) != 'FULL') {                        	
							   $changeDateFormat = '20'.substr($dateTimeValue, 0, 2). '-' .substr($dateTimeValue, 2, 2). '-' .substr($dateTimeValue, 4, 2);
								$dayMonthLength = strlen(trim($dateTimeValue));
								$getLicYr = trim(substr($dateTimeValue,0,2));
								$getLicMonth = trim(substr($dateTimeValue,2,2));
								$getLicDays = trim(substr($dateTimeValue,4,2));
								$currentYear = date('y');
								if($dayMonthLength != 6  || $getLicDays <= 0 || $getLicDays > 31 || $getLicMonth <= 0 || $getLicMonth > 12 || $getLicYr < $currentYear) {
									$flag = 0;
								} else {
									$flag = 1; 
									$dateTimeStamp = strtotime($changeDateFormat);
									//store dss expiry
									$dssExpiryDate=trim($changeDateFormat);
								}
							} else if(trim($dateTimeValue) == 'FULL') {
								$flag = 1; 
								$dateTimeStamp = 'FULL';
								//store dss expiry
								$dssExpiryDate='FULL';	
							}
							if ($flag == 1) {							
								// $dssInfoTableRec = $tableDssInfoData->getDataForDssLicense();	
								$dateSendForInsertDssLicense = array("licenseFileName" => $filename, "dateTimeStamp" => $dateTimeStamp);
								// if(count($dssInfoTableRec) == 0) {
									$tableDssInfoData->inserDataForDssLicense($dateSendForInsertDssLicense);
									//file created dssVIAExpiry.txt
									$dssExpiryfilePath=DEST_PATH.'dssVIAExpiry.txt';
									$dssExpiryFile = fopen($dssExpiryfilePath, 'w');								
									$expiryWrite= fwrite($dssExpiryFile, $dateTimeStamp);
									fclose($dssExpiryFile);	
									
								// } else {
									// $tableDssInfoData->updateDataForDssLicense($dateSendForInsertDssLicense);
								// } 
							   	$responseReturn = true;
							} else if($flag == 0) {
								unlink(DEST_PATH.$filename);
							}  
						} 
					}
				}  else {					
					$actFlag = 1;
					if(strstr($fileContent, 'Error')) {            	
						$actFlag = 0;
					}
				}
			} else {
				$responseReturn = 2;
			}
        echo $responseReturn;
        exit;
		}
	}
	// activate license functionality ends

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		$appObj = new ApplicationController();
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		} else {
			if(PRODUCT=='via' || PRODUCT=='kds'){
				$getSettingObj = $appObj->getComplexPasswordSettings();
				$getSettingData = $getSettingObj->webadmin_session_timeout;
			}else{
				$settingTable = $this->getSettingTable();
				$dataSessionSetting = $settingTable->getSessionCheckData();
				foreach($dataSessionSetting as $contentDetailResultSet) {
					$resultSetJson = json_encode($contentDetailResultSet); 
					$resultSet = json_decode($resultSetJson, true);
					$getSettingData = $resultSet['logoutTIme'];
				}
			}
			$sessionTimeOut = ($getSettingData > 0) ? $getSettingData : 10;
			$dataSendSessionCheck = array("sessionTimeOut" => $sessionTimeOut, "sessionLoginName" => $session->offsetGet('LoginName'));
			$sessionCheckTable = $this->getSessionCheckTable();
			$dataSessionCheck = $sessionCheckTable->getSessionCheckData($dataSendSessionCheck);
			
			if(count($dataSessionCheck) > 0) {
				$dataSendUpdateSessionCheck = array("sessionLoginName" => $session->offsetGet('LoginName'));
				$sessionCheckTable->updateSessionCheckData($dataSendUpdateSessionCheck);
			} else {
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		return parent::onDispatch($e);
	}
	
	//VIA License code added by ashu
	public function uploadLicenseFileAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$userfile = trim($request->getPost('via_licensefile'));	
			if(strstr($userfile,'\\')){	
				$url_arr = explode ("\\", $userfile);
				$ct = count($url_arr);
				$userfile = $url_arr[$ct-1];

			}else{
				$userfile=$userfile;
			}
			$FileExt=strtolower(trim((substr($userfile,strlen($userfile)-4,4))));
			if($FileExt=='.lic'){
				echo'Ok';
				exit;
			
			}else{ 
				echo'invalidformat';
				exit;
			}
		}
						
	}

	public function uploadWpglicenseAction(){
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$userfile = $this->params()->fromFiles('via_licensefile');		
		$request = $this->getRequest();
		$postData = $this->getRequest()->getPost()->toArray();
		if($postData['via_license_fileFlag']=='newfile'){
			if($userfile['error']== '0'){
				//check for differentiate dss file and  system license file	
				if(strstr($_FILES['via_licensefile']['name'],'_dss.lic') ){
					unlink(DEST_PATH.$userfile['name']);
					echo "<script>alert('Invalid License File'); window.location.href='liscenceInfo';</script>";
					die;
				}
				$up = move_uploaded_file($_FILES['via_licensefile']['tmp_name'], DEST_PATH.$_FILES['via_licensefile']['name']);
				
				if($up){
				
					$wifiSecurityFilekey="1324587099345678";
					$wifiSecurityFileIV ="9131557057664220";	
					$wifiSecurityFile=DEST_PATH.$_FILES['via_licensefile']['name'];	
					
				
					$filepath="";
					$filename=$_FILES['via_licensefile']['name'];
					if(file_exists(DEST_PATH.$filename)){
						copy(DEST_PATH.$filename,DEST_PATH."activation.lic");
						unlink(DEST_PATH.$filename);
						system("sync");
						system("sync");
						$myfileName=DEST_PATH.'newfile.txt';
						$myfile = fopen($myfileName, 'w') or die("can't open file");
						$content = "Last updated on ".date("Y-m-d H:i:s");	
						$confWrite= fwrite($myfile, $content);		
						fclose($myfile);					
						sleep(1);
						$appObj = new ApplicationController();
						$retVal=$appObj->reboot_powerOff_Server('reboot');	
						echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";
                                                die;
					}else{
						echo"<script language='javascript'>alert('File Not Found!')</script>";
					}								
				}else{
						echo"<script language='javascript'>alert('Error: File not supported!')</script>";
				}
			}
		}
		
		
/*		if($request->getPost('activateLicensebtn')) {
			$gwayMacAddr = $this->getDeviceInventoryTable()->fetchMACAddress();
			$macAddr=str_replace(':','-',$gwayMacAddr);
			$path="https://license.wowvision.com/";		
			$filename ='KRAMER_'.$macAddr.'.lic';	
			$save_to=realpath(DEST_PATH) . '/'.$filename;	
			$serverurl=$path.$filename;
			$curl = curl_init();
			//die(getcwd().'/config/cacertupdates.crt');
			curl_setopt_array($curl, array(
				CURLOPT_POST => 0,
				CURLOPT_URL => $serverurl,
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_SSL_VERIFYHOST=>0,		
				CURLOPT_CAINFO=>BASE_PATH.'/config/cacertupdates.crt',
				//by pass certificate		
				CURLOPT_SSL_VERIFYPEER=>false,
				CURLOPT_VERBOSE=>1
			));
			
			   $actFlag=1;
			  $file_content = curl_exec($curl);
			 // print_r($file_content);die;
			   if(strstr($file_content,'Not Found')){
					$actFlag=0;
			   }
		 //  die($actFlag);
				curl_close($curl);
				if($actFlag==1)	{ 
					$downloaded_file = fopen($save_to, 'w');
					fwrite($downloaded_file, $file_content);
					fclose($downloaded_file);			
						if(file_exists(DEST_PATH.$filename)){
							copy(DEST_PATH.$filename,DEST_PATH."activation.lic");
							unlink(DEST_PATH.$filename);
							system("sync");
							system("sync");	
							$myfileName=DEST_PATH."newfile.txt";
							$myfile = fopen($myfileName, 'w') or die("can't open file");
							$content = "Last updated on ".date("Y-m-d H:i:s");	
							$confWrite= fwrite($myfile, $content);		
							fclose($myfile);
							sleep(5);	
							$appObj=new ApplicationController();
							$appObj->ActivityLog('Activate','Activated License');
							$appObj = new ApplicationController();
							$retVal=$appObj->reboot_powerOff_Server('reboot');	
							echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";
                                                        die;
						}else{
							echo"<script language='javascript'>alert('License file is not available. Please contact Kramer Support.')</script>";			
						}		
				}else{
					echo"<script language='javascript'>alert('License file is not available. Please contact Kramer Support.');</script>";					
				}
				

		}
*/		
		
		//echo $str;//die;
		/*$form = new UtilityForm();
		$viewmodel =  new ViewModel(array(
			'form' => $form,
			'str' => $str,
		));

		$viewmodel->setTemplate("webapp/utility/system-settings");
		return $viewmodel;*/
					
	}
}