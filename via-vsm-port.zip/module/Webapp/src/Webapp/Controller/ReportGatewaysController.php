<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Form\ViaReportForm;
use Webapp\Controller\ApplicationController;

class ReportGatewaysController extends AbstractActionController {

    public $session;
    public $user_id;
    public $appObj;
    public function __construct() {
        $session = new Container('userinfo');
		$this->user_id = $session->offsetGet('usrid');
        $this->appObj = new ApplicationController();
        
    }
    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

    /*****
	 *	@Function Name: mostUsedGatewaysAction
	 *  @description  : get top 25 most used gateways
	 *	@Author		  : Vineet
	 *  @Date         : 20-april-2020
	 *****/
    public function mostUsedGatewaysAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('enddate')!="" ) {
            $startDate  = htmlspecialchars($request->getPost('startdate'));
            $endDate = htmlspecialchars($request->getPost('enddate'));
            if($startDate!="" && $endDate!=""){
                $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
            }
        }
        else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
    
        }

        if($this->user_id==1){
            $qrery = "SELECT count(DISTINCT(A.ProjectorLogID)) as totalTimes,B.DeviceName FROM `ProjectorLog` A
                      INNER JOIN DeviceInventory B ON B.DID=A.DeviceID WHERE A.Comments='LoggedIn' $condition
                      GROUP BY A.DeviceID order by totalTimes DESC limit 25 ";	
       }else{
            $qrery = "SELECT count(DISTINCT(A.ProjectorLogID)) as totalTimes,B.DeviceName FROM `ProjectorLog` A
                      INNER JOIN DeviceInventory B ON B.DID=A.DeviceID 
                      INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                      WHERE A.Comments='LoggedIn' AND C.user_id_fk='$this->user_id' $condition
                      GROUP BY A.DeviceID order by totalTimes DESC limit 25 ";	
       }
       $queryResult = $this->appObj->returnQueryData($qrery);
       foreach($queryResult as $result){
        if(is_numeric($result['DeviceName'])){
            $result['DeviceName']="'".$result['DeviceName']."'";
        }
        if($result['DeviceName'] !=""){
            $testArr[]=array((string)$result['DeviceName'],(int)$result['totalTimes']);
       }
       }
       $json_arr=json_encode($testArr);
       $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
       return new ViewModel(array('form'=>$form,'json_arr'=>$json_arr));

    }
 /*****
	 *	@Function Name: leastUsedGatewaysAction
	 *  @description  : get top 25 most least gateways
	 *	@Author		  : Vineet
	 *  @Date         : 20-april-2020
	 *****/
    public function leastUsedGatewaysAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('enddate')!="" ) {
            $startDate  = htmlspecialchars($request->getPost('startdate'));
            $endDate = htmlspecialchars($request->getPost('enddate'));
            if($startDate!="" && $endDate!=""){
                $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
            }
        }
        else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $condition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
        }
        if($this->user_id==1){
            $qrery = "SELECT count(DISTINCT(A.ProjectorLogID)) as totalTimes,B.DeviceName FROM `ProjectorLog` A
                      INNER JOIN DeviceInventory B ON B.DID=A.DeviceID WHERE A.Comments='LoggedIn' $condition
                      GROUP BY A.DeviceID order by totalTimes ASC limit 25 ";
       }else{
            $qrery = "SELECT count(DISTINCT(A.ProjectorLogID)) as totalTimes,B.DeviceName FROM `ProjectorLog` A
                      INNER JOIN DeviceInventory B ON B.DID=A.DeviceID 
                      INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                      WHERE A.Comments='LoggedIn' AND C.user_id_fk='$this->user_id' $condition
                      GROUP BY A.DeviceID order by totalTimes ASC limit 25 ";	
       }
        $queryResult = $this->appObj->returnQueryData($qrery);
       foreach($queryResult as $result){
        if(is_numeric($result['DeviceName'])){
            $result['DeviceName']="'".$result['DeviceName']."'";
        }
        if($result['DeviceName'] !=""){
            $testArr[]=array((string)$result['DeviceName'],(int)$result['totalTimes']);
       }
       }
       $json_arr=json_encode($testArr);
       $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
       return new ViewModel(array('form'=>$form,'json_arr'=>$json_arr));

    }

     /*****
	 *	@Function Name: gatewaysNeverUsedAction
	 *  @description  : get via gateways never used
	 *	@Author		  : Vineet
	 *  @Date         : 13-april-2020
	 *****/
    public function gatewaysNeverUsedAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        if($this->user_id==1){
            $qrery = "SELECT B.DeviceName,B.DeviceID,B.DeviceIP FROM DeviceInventory B
                      WHERE B.DID NOT IN (SELECT DeviceID FROM ProjectorLog)
                      LIMIT 25";
        }else{
            $qrery = "SELECT DISTINCT(B.DeviceName),B.DeviceID,B.DeviceIP FROM DeviceInventory B
                      INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                      WHERE C.user_id_fk='$this->user_id' AND B.DID NOT IN (SELECT DeviceID FROM ProjectorLog)
                      LIMIT 25 ";
        }
        $resutData = $this->appObj->returnQueryData($qrery);
        return new ViewModel(array('data'=>$resutData));
    }
     

}