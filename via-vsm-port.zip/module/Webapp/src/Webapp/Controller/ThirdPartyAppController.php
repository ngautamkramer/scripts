<?php

namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//use Webapp\Form\AdduserForm;
use Webapp\Form\ThirdpartyappForm;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;

use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;

class ThirdPartyAppController extends AbstractActionController
{
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}


	/*****
	 *	@Function Name		: tpaList
	 *  @description	    : It works return TPA list.
	 *****/
	public function tpaListAction(){
		$appObj=new ApplicationController();
		$form = new ThirdpartyappForm();		
		$data=$this->getThirdpartyappsTable()->fetchAll();
		//echo count($data);die;
		//load add user form
		$viewmodel = new ViewModel(array(	
			'data' => $data,
			'form' => $form,	
			'file_chkPresentationMode'=>1,     
		));
		$viewmodel->setTemplate('webapp/manage-configurations/room-settings');
		return $viewmodel;		
	}
	
	/*****
	 *	@Function Name		: upload
	 *  @description	    : It will upload app image using jquery and return uploaded image path
	 *****/	
	public function uploadAction(){
		$appObj=new ApplicationController();
		$postData = $this->getRequest()->getPost()->toArray();
		$tpaiconfileInfo = $this->params()->fromFiles('file');
		$tpaiconfileArr = explode(".", $tpaiconfileInfo['name']);		
		$imgTypeArr=strtolower($tpaiconfileInfo['type']);		
		$imgTypeExplode=explode("/",$imgTypeArr);
		$imgType=trim($imgTypeExplode[1]);		
		$iconExt = strtolower(end($tpaiconfileArr));

		//Getting mime type		
		$arrImgInfo = getimagesize($tpaiconfileInfo['tmp_name']);
		$arrImgInfoType=$arrImgInfo['mime'];
		$imgType = trim($appObj->getfileType($arrImgInfo['mime']));
		if($iconExt == 'jpeg'){
			$iconExt = 'jpg';
		}
		if($imgType == 'jpeg'){
			$imgType = 'jpg';
		}
		//Checking both extension in case of some one chnage the ext	
		if($imgType!=$iconExt){
			die('error');	
		}
		
		
		if($imgType== "jpg" || $imgType== "jpeg" || $imgType== "png") {
			$filepath = UPLOAD_PATH.'TPImages/'.$tpaiconfileInfo['name'];
			$up = move_uploaded_file($tpaiconfileInfo['tmp_name'], $filepath);
			chmod(UPLOAD_PATH.'TPImages/'.$tpaiconfileInfo['name'], 0777);
			$returnPath=WEB_DATA_PATH.'/uploads/TPImages/'.$tpaiconfileInfo['name'];
			//added on 9Dec22 for creating thumb
			$outputFile=UPLOAD_PATH.'TPImages/'.$tpaiconfileInfo['name'];
			$thumb_image=$tpaiconfileInfo['name'];		
			
			if($imgType== "jpg" || $imgType== "jpeg"){
				$explodedImg = explode('.',$tpaiconfileInfo['name']);
				$imgName=$explodedImg[0];
				$ext=$exploded[1];    		
				$outputFile=UPLOAD_PATH.'TPImages/'.$imgName.".png";			
				$appObj->convertImagePNG($filepath, $outputFile, 100);
				unlink(UPLOAD_PATH.'/TPImages/'.$tpaiconfileInfo['name']);
				$returnPath=WEB_DATA_PATH.'/uploads/TPImages/'.$imgName.".png";
				$thumb_image=$imgName.".png";
			}
			//create thumb
			$img = imagecreatefrompng($outputFile);
			$width = imagesx($img);
			$height = imagesy($img);
			$new_width = 106;
			$new_height = 106;//floor($height * ($thumbWidth / $width));
			$tmp_img = imagecreatetruecolor($new_width, $new_height);
			imagecopyresampled($tmp_img, $img, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
			imagepng($tmp_img, UPLOAD_PATH.'TPImages/'.$thumb_image);
			imagedestroy($tmp_img);
			imagedestroy($img);	
			
			die($returnPath);
		}else{
			die('error');					
		}
	}

	/*****
	 *	@Function Name		: add
	 *  @description	    : It will Add/Update all tpa data. Also it checks unique appname and url
	 *****/	
	public function addAction(){
		$appObj=new ApplicationController();
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('LoginName');
		//echo "<pre>";print_r($_POST);die;
		if($this->getRequest()->isPost()) {	
			$postData = $this->getRequest()->getPost()->toArray();			
			$request = $this->getRequest();
			$form = new ThirdpartyappForm();
			$mode=trim($postData['mode']);
			//	$log_tpaname is using for shoing appname in activity log
			$log_tpaname=strlen($postData['tpaname'])>5?ucfirst(substr($postData['tpaname'],0,5)).'...':ucfirst($postData['tpaname']);
			if($mode=='editmode'){
				$tpa_id=trim($postData['tpa_id']);	
				$id=str_replace(' ','+',trim($tpa_id));
				$id=htmlspecialchars($id, ENT_QUOTES, 'UTF-8');
				$postData['tpa_id'] = $appObj->desDecrypt($id, KEY_SEED);
				
				$result = $this->getThirdpartyappsTable()->checkAppNameById($postData);
				$appNameCount = $result->count();
				$result1 = $this->getThirdpartyappsTable()->checkAppUrlById($postData);
				$appUrlCount = $result1->count();
				if($appNameCount>0){
					die('appnameexist');
				}elseif($appUrlCount>0){
					die('appurlexist');
				}else{
					$this->getThirdpartyappsTable()->updateApp($postData,$sessionLoginName);
					//manage log			
					$appObj->ActivityLog('Update',$log_tpaname.' ('.strtolower(NAV_TPA).')');
					/*$iconnameExplode=explode("/",$postData['iconname']);					
					$get_imageName= trim(end($iconnameExplode));
					rename(UPLOAD_PATH.'TPImages/'.$get_imageName ,UPLOAD_PATH.'TPImages/'.$postData['tpaname'].".png");*/									
					die('updatesuccess');
				}		
			}else{
				$result = $this->getThirdpartyappsTable()->checkAppName($postData);
				$appNameCount = $result->count();
				$result1 = $this->getThirdpartyappsTable()->checkAppUrl($postData);
				$appUrlCount = $result1->count();
				if($appNameCount>0){
					die('appnameexist');
				}elseif($appUrlCount>0){
					die('appurlexist');
				}else{
					$this->getThirdpartyappsTable()->saveApp($postData,$sessionLoginName);
					//manage log			
					$appObj->ActivityLog('Create',$log_tpaname.' ('.strtolower(NAV_TPA).')');
					/*$iconnameExplode=explode("/",$postData['iconname']);					
					$get_imageName= trim(end($iconnameExplode));
					rename(UPLOAD_PATH.'TPImages/'.$get_imageName ,UPLOAD_PATH.'TPImages/'.$postData['tpaname'].".png");	*/								
					
					die('addsuccess');
				}		
			
			}			
		}
	}

	/*****
	 *	@Function Name		: getTpadata
	 *  @description	    : It returns all tpa data by id
	 *	@Author			    : Ashu	 
	 *****/	
	public function getTpadataAction(){
		$appObj=new ApplicationController();
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('LoginName');
		$utype = $session->offsetGet('utype');
	
		//print_r($_POST);
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();	
			$id=trim($postData['id']);			
			$id=str_replace(' ','+',trim($id));
			$id=htmlspecialchars($id, ENT_QUOTES, 'UTF-8');
			$id = $appObj->desDecrypt($id, KEY_SEED);
			//Security changes added by ashu on 28/03/22. Allow only numeric value 
			if(!is_numeric($id) || $id <= 0 ){
				echo "Id is not valid";die;
			}		
			
			$getTpaDataArr=$this->getThirdpartyappsTable()->getTpaDataById($id);			
	 		$tpName=trim($getTpaDataArr->tpname);
			//$tpicon=trim($getTpaDataArr->tpimage);
			$tpPath=trim($getTpaDataArr->tppath);			
			//echo $tpName.'###'.WEB_DATA_PATH.'/uploads/TPImages/'.$tpicon.'###'.$tpPath;
			echo $tpName.'###'.$tpPath;
			die;			
		}
	
	}
	
	/*****
	 *	@Class Name			: deleteAppAction
	 *  @description	    : Using for delete apps                     
	 *	@Author			    : Ashu	 
	 *****/ 	
	 public function deleteAppAction(){
	 	$appObj=new ApplicationController();
		$session = new Container('userinfo');
		$encryptedUserid =trim($this->params()->fromQuery('id'));		
		//decrypt id
		$input=str_replace(' ','+',trim($encryptedUserid));
		$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
		$tpa_id=$appObj->desDecrypt($input, KEY_SEED);
		
		//Security changes added by ashu on 31/03/22. Allow only numeric value 
		if(!is_numeric($tpa_id) || $tpa_id <= 0 ){
			echo "Id is not valid";die;
		}
		//Getting app icon and delete icon	
		$getTpaDataArr=$this->getThirdpartyappsTable()->getTpaDataById($tpa_id);	
		$tpicon=trim($getTpaDataArr->tpimage);
		//	$log_tpaname is using for shoing appname in activity log
		$log_tpaname=strlen($getTpaDataArr->tpname)>5?ucfirst(substr($getTpaDataArr->tpname,0,5)).'...':ucfirst($getTpaDataArr->tpname);		
		unlink(UPLOAD_PATH.'TPImages/'.$tpicon);	
		
		$deldata=$this->getThirdpartyappsTable()->deleteApp($tpa_id);
		$this->flashMessenger()->addMessage('App deleted successfully');
		//manage log			
		$appObj->ActivityLog('Delete',$log_tpaname.' ('.strtolower(NAV_TPA).')');			
		return $this->redirect()->toRoute('thirdpartyapp', array('action' => 'tpaList'));
		//return $this->redirect()->toRoute('thirdpartyapp');
	}
	

	
	/*****
	 *	@Function Name		: getThirdpartyappsTable
	 *  @description	    : Using for accessing function from table
	 *****/		
	public function getThirdpartyappsTable() {
		if (!$this->TblThirdpartyappsTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblThirdpartyappsTable = $sm->get('Webapp\Model\TblThirdpartyappsTable');
			
		}
		return $this->TblThirdpartyappsTable;
	}
	

}
