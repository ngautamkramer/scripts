<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Form\ViaReportForm;
use Webapp\Controller\ApplicationController;

class ReportViaSessionsController extends AbstractActionController {

    public $session;
    public $user_id;
    public $appObj;
    public function __construct() {
        $session = new Container('userinfo');
		$this->user_id = $session->offsetGet('usrid');
        $this->appObj = new ApplicationController();
        
    }
    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

    /*****
	 *	@Function Name: longestViaSessionsAction
	 *  @description  : get longest via sessions
	 *	@Author		  : Vineet
	 *  @Date         : 21-april-2020
	 *****/
    public function longestViaSessionsAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        
        $deleteQuery="DELETE FROM tbl_temp_session_graph WHERE user_id=$this->user_id";
        $this->appObj->executeQueries($deleteQuery);

        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('enddate')!="" ) {
            
            $startDate = htmlspecialchars($request->getPost('startdate'));
            $endDate = htmlspecialchars($request->getPost('enddate'));
            if( $startDate!="" &&  $endDate!=""){
                $codition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
            }

        }else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $codition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
        }

        if($this->user_id==1){
            $qry = "SELECT DISTINCT(A.DeviceID),A.Comments,B.DeviceName,A.ActivityDate,A.StartTime FROM `ProjectorLog` A 
                    INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                    WHERE Comments IN ('SessionStart','SessionStop') $codition "; 
      }else{
            $qry = "SELECT DISTINCT(A.DeviceID),A.Comments,B.DeviceName,A.ActivityDate,A.StartTime FROM `ProjectorLog` A 
                    INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                    INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                    WHERE C.user_id_fk='$this->user_id' AND Comments IN ('SessionStart','SessionStop') $codition "; 
      }
    
     
        $queryResult = $this->appObj->returnQueryData($qry);

        foreach($queryResult as $result){
            $newArr[]=$result;
        }

        $customeSql="INSERT INTO tbl_temp_session_graph (device_name,calculated_time,user_id) VALUES ";
        $value_array=array();
	    for($i=0;$i<=count(!is_null($newArr)?$newArr:[]);$i++){
            if($newArr[$i]['Comments']=="SessionStart" && $newArr[$i+1]['Comments']=="SessionStop" && $newArr[$i]['DeviceID']==$newArr[$i+1]['DeviceID']){
                $dName=$newArr[$i]['DeviceName'];
                $stime=$newArr[$i]['ActivityDate']." ".$newArr[$i]['StartTime'];
                $etime=$newArr[$i+1]['ActivityDate']." ".$newArr[$i+1]['StartTime'];

                $totaltime=(strtotime($etime)- strtotime($stime))/60;
                $finalTimeMin=round($totaltime,0);
                $finalTimeHou=round($finalTimeMin/60,2);
                
                $value_array[] = "('$dName','$finalTimeHou','$this->user_id')"; 
            }else if($newArr[$i]['Comments']=="SessionStart" && $newArr[$i+1]['Comments']=="SessionStart" && $newArr[$i]['DeviceID']==$newArr[$i+1]['DeviceID']){
                $dName=$newArr[$i]['DeviceName'];
                $stime=$newArr[$i]['ActivityDate']." ".$newArr[$i]['StartTime'];
                $etime=$newArr[$i+1]['ActivityDate']." ".$newArr[$i+1]['StartTime'];

                $totaltime=(strtotime($etime)- strtotime($stime))/60;
                $finalTimeMin=round($totaltime,0);
                $finalTimeHou=round($finalTimeMin/60,2);
                
                $value_array[] = "('$dName','$finalTimeHou','$this->user_id')"; 
            }
        }
         if(!empty($value_array)) {
            $customeSql .= implode(',', $value_array);
            $this->appObj->executeQueries($customeSql);
         }
            // Get the data from temprary table tbl_temp_session_graph.
		     $qrery2Result = $this->appObj->returnQueryData("SELECT * FROM `tbl_temp_session_graph` WHERE user_id=$this->user_id AND calculated_time > -.001 ORDER BY calculated_time DESC LIMIT 25");
		    
             foreach($qrery2Result as $result){
                $testArr[]=array((string)$result['device_name'],(float)$result['calculated_time']);
                $gName[]=array((string)$result['device_name']);
            }

        $json_testArr=json_encode($testArr);
        $json_gName=json_encode($gName);
        $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
        return new ViewModel(array('form'=>$form,'json_testArr'=>$json_testArr,'json_gName'=>$json_gName));

    }
     /*****
	 *	@Function Name: shortestViaSessionsAction
	 *  @description  : get shortest via sessions
	 *	@Author		  : Vineet
	 *  @Date         : 21-april-2020
	 *****/
    public function shortestViaSessionsAction()
    {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
        $request = $this->getRequest();
        $form=new ViaReportForm();
        $deleteQuery="DELETE FROM tbl_temp_session_graph WHERE user_id=$this->user_id";
        $this->appObj->executeQueries($deleteQuery);

        if($request->isPost() && $request->getPost('startdate')!="" && $request->getPost('enddate')!="" ) {
            
            $startDate = htmlspecialchars($request->getPost('startdate'));
            $endDate =htmlspecialchars( $request->getPost('enddate'));
            if( $startDate!="" &&  $endDate!=""){
                $codition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
            }

        }else{
            $startDate=date('Y-m-d', strtotime(' -1 day'));
            $endDate=date('Y-m-d');
            $codition=" AND ActivityDate BETWEEN '".$startDate.' 00:00:00'."' AND '".$endDate.' 23:59:00'."'";
        }

        if($this->user_id==1){
            $qry = "SELECT DISTINCT(A.DeviceID),A.Comments,B.DeviceName,A.ActivityDate,A.StartTime FROM `ProjectorLog` A 
                    INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                    WHERE Comments IN ('SessionStart','SessionStop') $codition "; 
      }else{
            $qry = "SELECT DISTINCT(A.DeviceID),A.Comments,B.DeviceName,A.ActivityDate,A.StartTime FROM `ProjectorLog` A 
                    INNER JOIN DeviceInventory B ON B.DID=A.DeviceID
                    INNER JOIN tbl_user_access C ON C.group_id_fk=B.DeviceGroupID	
                    WHERE C.user_id_fk='$this->user_id' AND Comments IN ('SessionStart','SessionStop') $codition "; 
      }

      $queryResult = $this->appObj->returnQueryData($qry);
      foreach($queryResult as $result){
          $newArr[]=$result;
      }


      $customeSql="INSERT INTO tbl_temp_session_graph (device_name,calculated_time,user_id) VALUES ";
		    $value_array=array();
		    for($i=0;$i<=count(!is_null($newArr)?$newArr:[]);$i++){
				if($newArr[$i]['Comments']=="SessionStart" && $newArr[$i+1]['Comments']=="SessionStop" && $newArr[$i]['DeviceID']==$newArr[$i+1]['DeviceID']){
					$dName=$newArr[$i]['DeviceName'];
					$stime=$newArr[$i]['ActivityDate']." ".$newArr[$i]['StartTime'];
					$etime=$newArr[$i+1]['ActivityDate']." ".$newArr[$i+1]['StartTime'];

					$totaltime=(strtotime($etime)- strtotime($stime))/60;
					$finalTimeMin=round($totaltime,0);
					$finalTimeHou=round($finalTimeMin/60,2);
					
					$value_array[] = "('$dName','$finalTimeHou','$this->user_id')"; 
			    }else if($newArr[$i]['Comments']=="SessionStart" && $newArr[$i+1]['Comments']=="SessionStart" && $newArr[$i]['DeviceID']==$newArr[$i+1]['DeviceID']){
					$dName=$newArr[$i]['DeviceName'];
					$stime=$newArr[$i]['ActivityDate']." ".$newArr[$i]['StartTime'];
					$etime=$newArr[$i+1]['ActivityDate']." ".$newArr[$i+1]['StartTime'];

					$totaltime=(strtotime($etime)- strtotime($stime))/60;
					$finalTimeMin=round($totaltime,0);
					$finalTimeHou=round($finalTimeMin/60,2);
					
					$value_array[] = "('$dName','$finalTimeHou','$this->user_id')"; 
			    }
            }
            if(!empty($value_array)) {
                $customeSql .= implode(',', $value_array);
                $this->appObj->executeQueries($customeSql);
             }

             // Get the data from temprary table tbl_temp_session_graph.
             $qrery2Result = $this->appObj->returnQueryData("SELECT * FROM `tbl_temp_session_graph` WHERE user_id=$this->user_id AND calculated_time > -.001 ORDER BY calculated_time ASC LIMIT 25");
             
             foreach($qrery2Result as $result){
                $testArr[]=array((string)$result['device_name'],(float)$result['calculated_time']);
                $gName[]=array((string)$result['device_name']);
            }

        $json_testArr=json_encode($testArr);
        $json_gName=json_encode($gName);
        $form->setData(array('startdate' => $startDate, 'enddate' => $endDate));
        return new ViewModel(array('form'=>$form,'json_testArr'=>$json_testArr,'json_gName'=>$json_gName));
		   
        return new ViewModel();
    }




}