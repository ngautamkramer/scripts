<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\NetworksettingsForm;
use Webapp\Form\ViaConfigurationForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Form\ModeratorModeForm;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;

class HomeController extends AbstractActionController {
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{	
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	public function systemInfoAction() {
		$session = new Container('userinfo');
		$usrid = $session->offsetGet('usrid');
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['sessiontimeout'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
		
		//$utype = $session->offsetGet('utype');
		if(empty($usrid)) {
			return $this->redirect()->toRoute('index');
		}
	
		$appObj = new ApplicationController();
		$modelOSType =$appObj->getModelNameByParam('ostype');
		$modelOSVersion =$appObj->getModelNameByParam('osversion');
		$modelOSVersion = substr($modelOSVersion, 0, 2);
		$hardware =$appObj->getModelNameByParam('hardware');//(FILE_2955 == 1)? '2955' : '3010';
		$viaModel=$appObj->getModelNameByParam('model');
		$viaModelShow=$appObj->getModelNameByParam("modelshow");
		$modellike=$appObj->getModelNameByParam("modellike");
		$viaUpdateFirmwareTag=$appObj->getModelNameByParam("updatefirmwaretag");
		$getlanMacAddr = $appObj->getMacAddress();
		$modelShowWithoutSpace = $appObj->getModelNameWithoutSpace($viaModelShow);

		
		if(GET_OS == 'WIN') {
			$diskTotalSpaceByte = $appObj->totalSpace($rawOutput = false, 'c:')+ $appObj->totalSpace($rawOutput = false, 'd:')+ $appObj->totalSpace($rawOutput = false, 'e:');
			$diskTotalFreeSpaceByte = $appObj->freeSpace($rawOutput = false, 'c:')+ $appObj->freeSpace($rawOutput = false, 'd:')+ $appObj->freeSpace($rawOutput = false, 'e:');
		} else {
			$diskTotalSpaceByte = disk_total_space("/");
			$diskTotalFreeSpaceByte = disk_free_space("/");
		}
		$diskTotalSapce = $appObj->addUnits($diskTotalSpaceByte);
		$diskTotalFreeSapce = $appObj->addUnits($diskTotalFreeSpaceByte);
		$freePercentval =($diskTotalFreeSpaceByte * 100 / $diskTotalSpaceByte);
		
		/*VINEET*/
		$firmwareVersion = $appObj->getModelNameByParam('firmversion');
		//$checkVersionFile = $appObj->checkfile(SECOND_DEST_PATH, FILE_VERSION_FILE);
		$val = $appObj->checkfile(DEST_PATH, READFILE_ROOMNAMEVALUESHOW);
		if($val == 0) {
			$roomName = $appObj->file_read(DEST_PATH . READFILE_IPADD);
		} else {
			$roomName = $appObj->file_read(DEST_PATH . READFILE_ROOMNAMEVALUESHOW);
		}
		$tblWidth = '35%';
		$getMode = '';
		if(CHECK_WIFI_FILE == 1) {
			$getMode =(CHECK_APICLIENT == 1)? 'clientMode' : 'apMode';
			$tblWidth =(CHECK_WIFI_FILE == 1)? '72%' : '35%';
			if($getMode == 'apMode') {
				setcookie("current_network", "", time()- 3600);
				// setcookie("current_network_list", "", time()- 3600);
				/* code added by niraj to get remove network list file ## 06/02/2023 */	
				$networkListFilePath = BASE_PATH . "/public/uploads/networklist_".$session->offsetGet('LoginName').".txt";
				if (file_exists($networkListFilePath)) {
					unlink($networkListFilePath);
				}
				/* end code added by niraj to get remove network list file ## 06/02/2023 */	
			}
		}
		if(CHECK_FILE_MIRRORNAME == 1) {
			$mirrorFile_data = $appObj->file_read(DEST_PATH . FILE_MIRRORNAME);
		}
		if(CHECK_FILE_MIRROR_MAXCON == 1) {
			$maxCon_mirrorFile_data = $appObj->file_read(DEST_PATH . FILE_MIRROR_MAXCON);
		}
		if(CHECK_FILE_DATEFORMAT == 1) {
			$readDateTimeFormat = $appObj->file_read(DEST_PATH . FILE_DATEFORMAT);
			$arrayFormat = explode(" ", $readDateTimeFormat, 2);
			$readDateTimeFormat = implode(" | ", $arrayFormat);
		}
		if(PRODUCT_TYPE == 'via') {
			$currentModelName = $appObj->getModelName();
			if($viaModel == "campus" || $viaModel == "campus2") {
				$releaseNoteLink = "https://k.kramerav.com/support/?rnotes=via-campus";
			} else if(trim($viaModel)== "collage") {
				$releaseNoteLink = "https://k.kramerav.com/support/?rnotes=via-collage";
			} else if(trim($viaModel)== "campusplus" || trim($viaModel)== "campus2plus") {
				$releaseNoteLink = "https://k.kramerav.com/support/download.asp?f=53935";
			} else if(trim($viaModel)== "viago") {
				$releaseNoteLink = "https://k.kramerav.com/support/?rnotes=via-go";
			} else if(trim($viaModel)== "connectpro") {
				$releaseNoteLink = "https://k.kramerav.com/support/?rnotes=via-connect-pro";
			} else if(trim($viaModel)== "connectplus") {
				$releaseNoteLink = "https://k.kramerav.com/support/?rnotes=via-connect-plus";
			}else if(trim($viaModel)== "viago2") {
				$releaseNoteLink = "https://k.kramerav.com/support/?rnotes=via-go2";
			}
		}
		if(PRODUCT_TYPE == 'collab8/') {
			//$currentModelName = getCollab8ModelName();
		}
		if(GET_OS == 'LIN') {
			$checkDeviceInUse =(CHECK_FILE_PATCOUNT == 1)? ' Device Type in use' : '';
			//$currentModelName = $currentModelName . "&nbsp;&nbsp;[OS Type : $modelOSType | Hardware Model : $hardware] $checkDeviceInUse";
			$currentModelName = $hardware;
		}
		if(GET_OS == 'WIN') {
			$checkDeviceInUse =(CHECK_FILE_PATCOUNT == 1)? ' Device type in use' : '';
			$currentModelName = $currentModelName;
		}
		$hardwareModel = $checkDeviceInUse==''?STR_HARDWARE_MODEL:$checkDeviceInUse;


		$broadcastResult = $appObj->getTableAllData("tbl_session_settings");

		foreach($broadcastResult as $broadcastResults) {
			$broadcastSql = $broadcastResults['field1'];
		}
		
		/*Chrome Status*/
		$advQry = $appObj->getTableAllData('tbl_Advance_Configuration');

		foreach($advQry as $advQrys) {
			$chromeValue = $advQrys['feature9'];
		}
		//getting data from network.json		
		$networkJsonData=$appObj->readJsonFile(DEST_PATH.'network.json');
		$miracastSupportValue=($networkJsonData['Miracast']!='')?$networkJsonData['Miracast']:0;
		$miracastValue = CHECK_FILE_MIRACAST;		
		$miracastStatus =($miracastValue == 1)? 'ON' : 'OFF';
		$chromestatusDB = 'OFF';
		if($chromeValue == 1) {
			$chromestatusDB = 'ON';
			if($appObj->checkfile(DEST_PATH, FILE_CHROME_STATUS)!= 0) {
				$chromestatus =($appObj->file_read(DEST_PATH.FILE_CHROME_STATUS)== 1)? 'Success' : "Fail";
				if($appObj->file_read(DEST_PATH.FILE_CHROME_STATUS)== 2) {
					$chromestatusFail = 'Connection to ' .$appObj->file_read(DEST_PATH . FILE_CHROME_SERVER). ' at port ' . $appObj->file_read(DEST_PATH . 
																												  FILE_CHROME_PORT). ' not open';
				}
				if($appObj->file_read(DEST_PATH.FILE_CHROME_STATUS)== 3) {
					$chromestatusFail = 'Serial number not registered with server';
				}
			}
		}
		$sb6300 = $appObj->checkfile(DEST_PATH, FILE_WUSB6300);
		$vsmFileStatus = $appObj->checkfile(DEST_PATH, FILE_VSM_STATUS);
		$vsmFileStatusVal = $appObj->file_read(DEST_PATH.FILE_VSM_STATUS);
		$licStatus=$appObj->checkfile(DEST_PATH, FILE_LIC_STATUS);
		$licStatusVal=$appObj->file_read(DEST_PATH.FILE_LIC_STATUS);
		
		/*get uptime()*/
		$upTimeData = $appObj->getUptime();
		$data = $appObj->getTableAllData('DeviceInventory');

		foreach($data as $allData) {
			$viaServerIP = $allData['deviceip'];
		}
		//get audio input/out data
		//Warning remove: Now do not use of this variable
		$audioInput="";	
		$audioOutput="";	

		$currentTime=$appObj->getMysqlDateTime();

		//get active via settings & screen editor details
		$queryData = $appObj->returnQueryData("SELECT id,template_name FROM tbl_via_settings_templates WHERE status=1 OR status=2");
		$activeViaSettingsData = $queryData->current();

		$queryData = $appObj->returnQueryData("SELECT id,template_name FROM tbl_templates WHERE status=1");
		$activeScreenEditorData = $queryData->current();

		$settingValue = $appObj->getTableAllData('tbl_hq_configuration')->current();
		$configSettingVal = $settingValue['hq_configsetting'];
		$wallpaperSettingVal= $settingValue['hq_wallpapersetting'];
		//end get active via settings & screen editor details

		
		//if license not activated then all green tick will show into res corss icon ## 30 july,204 by niraj
		$isViaLicenseActivated = 0;
		if(GET_OS=='LIN'){
			if(file_exists(DEST_PATH.'licdetails.txt')){
				$licfile=DEST_PATH.'licdetails.txt';
				$fp = fopen($licfile, "r");		
				if($fp){
					$str="";			
					while(!feof($fp)){
						$fcontent = fgets($fp);				
						if($fcontent != ""){
							if(!strstr($fcontent,'Serial no')){								
								$str.=str_replace("|"," - ",$fcontent)."</p>";
							}
						}
					}
					if(strstr($str,'Locked') || strstr($str,'DEMO')){
						$isViaLicenseActivated = 0;
					}else{
						$isViaLicenseActivated = 1;
					} 
				}
			}
		}
		//Added by ashu for checking miracast on wifisettings tab on dashboard
		//getting miracast value from json		
		$settingsUrl = DEST_PATH.'via_settings.json';
		$response = file_get_contents($settingsUrl);	
		//decrypt json
		$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
		$templateSettings = json_decode($decryptResponse);
		$advanceConfig = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->presentation;		
		$miracastConfigStatus =($advanceConfig->miracast->status == '')? 0 : $advanceConfig->miracast->status;	
		//getting value to allow wifi or miracast
		$wifiMiracastFlag=$appObj->allowMiracastAndWifi(DEST_PATH.'network.json');

		return array('modelName' =>$currentModelName,
                     'hardwareModel' => $hardwareModel,
					 'modelOSType' =>$modelOSType,
					 'modelOSVersion' => $modelOSVersion,
					 'hardware' =>$hardware,
					 'checkDeviceInUse' =>$checkDeviceInUse,
					 'releaseNoteLink' =>$releaseNoteLink,
					 'secondDestVersionFile' =>$firmwareVersion,
					 'readDateTimeFormat' =>$readDateTimeFormat,
					 'mirrorFile_data' =>$mirrorFile_data,
					 'broadcastSql' =>$broadcastSql,
					 'miracastStatus' =>$miracastStatus,
					 'sb6300' =>$sb6300,
					 'chromestatus' =>$chromestatus,
					 'chromestatusDB' =>$chromestatusDB,
					 'chromeValue' =>$chromeValue,
					 'diskTotalSapce' =>$diskTotalSapce,
					 'diskTotalFreeSapce' =>$diskTotalFreeSapce,
					 'upTimeData' =>$upTimeData,
					 'vsmFileStatus' =>$vsmFileStatus,
					 //'checkVersionFile' =>$checkVersionFile,
					 'mode' =>$mode,
					 'getMode' =>$getMode,
					 'viaServerIP' =>$viaServerIP,
					 'freePercentval' =>$freePercentval,
					 'roomName' =>$roomName,					 
					 'macAddress' =>$macAddress,					 
					 'getViaModel'=>$viaModel,
					 'viaModelShow'=>$viaModelShow,
					 'currentTime'=>$currentTime,
					 'miracastSupportValue'=>$miracastSupportValue,
					 'viaUpdateFirmwareTag'=>$viaUpdateFirmwareTag,
					 'appObj' =>$appObj,
					 'vsmFileStatusVal' =>$vsmFileStatusVal,
					 'licStatus'=> $licStatus,
					 'licStatusVal'=>$licStatusVal,
					 'audioInput'=>$audioInput,
					 'audioOutput'=>$audioOutput,
					 'modellike'=>$modellike,
					 'activeViaSettingsData'=>$activeViaSettingsData,
					 'activeScreenEditorData'=>$activeScreenEditorData,
					 'isViaLicenseActivated'=>$isViaLicenseActivated,
					 'configSettingVal' => $configSettingVal,
					 'wallpaperSettingVal' => $wallpaperSettingVal,
					 'miracastConfigStatus'=>$miracastConfigStatus,
					 'wifiMiracastFlag'=>$wifiMiracastFlag,
					 'modelShowWithoutSpace'=>$modelShowWithoutSpace
					 );
	}
			/*****
	 *	@Function Name: checkUpdateFirmWareAction
	 *  @description  : checkFirmWare Version
	 *	@Author		  : Vineet
	 *  @Date         : 21-jan-2020
	 *****/
	public function checkUpdateFirmWareAction() {
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		if($request->isXmlHttpRequest()) {
	        $checkFirmwareUrl = $appObj->checkfile(DEST_PATH, "FirmwareURL.txt");
			if($checkFirmwareUrl==1){
				$getDetailsData = file_get_contents(DEST_PATH."FirmwareURL.txt");
				$getDetailsArr = explode("|",$getDetailsData);
				$filepathtodownload  = $getDetailsArr[0];
				$size  = $getDetailsArr[1];
				$md5  = $getDetailsArr[2];
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";			 
				//Download and install command
				$updatePckCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>FirmUpdate</Cmd><P1>$filepathtodownload</P1><P2>$size</P2><P3>$md5 </P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$getResponse=$appObj->homeNetworkInfo($logincmd,$updatePckCmd);
				 echo 4;die;
				
			}else{
				$data = $request->getPost('data');
				$getModel = $data[0];
				$buildNo = $data[1];

				list($wifiSecurityFilekey,$wifiSecurityFileIV)=explode('#',$appObj->getWifiSecurityKey());
			
				$vstrMyID=substr($wifiSecurityFilekey,0,8);
				$vstrYourID=substr($wifiSecurityFileIV,0,8);
				$vstrKey = $vstrMyID.$vstrYourID;         
				$vstrVI = $vstrYourID.$vstrMyID; 
				$data=array('VaildP'=>$buildNo,"model"=>$getModel,'myid'=>$vstrMyID,'yourid'=>$vstrYourID);
				$myjson = json_encode($data);	
				if(file_exists(DEST_PATH."devEnd.txt")){
					$path="https://dev.wowvision.com/fw/";
				}else{
					$path="https://updates.wowvision.com/fw/";
				}	
							
				//$filename ='checkforupdaten.php';
				$filename ='checkforupdate3.php';
				$username="viafirmwaremgmt";		 
				$pass="L4kd#@93k29k#4kd92@";
				$returnVal=$appObj->webserviceToGetData($username,$pass,$myjson,$path,$filename);
				$decrypted=$appObj->desDecrypt($returnVal,$vstrKey);	
				
			 if(strstr($decrypted,'&')){
				$decrypted = str_replace('&','amp',$decrypted);
			 }		 	 		 
			 $pckUrl=explode(":",$decrypted);
			 
			 //print_r($pckUrl);die;
			 if($pckUrl[1]==999){
				 //echo "http:".$pckUrl[3];exit;
				 $filePath = "https:".$pckUrl[3];  //get the file path
				 //Get the MD5
				 $firmwarePackage=explode("/",$pckUrl[3]);
				 $firmwarePackageName=end($firmwarePackage);
				 $dataMd5=json_encode(array('VaildP'=>$firmwarePackageName,'myid'=>$vstrMyID,'yourid'=>$vstrYourID));
				 //$filenameMd5 ='getmehashn.php';
				 $filenameMd5 ='getmehash3.php';
				 $returnValMd5=$appObj->webserviceToGetData($username,$pass,$dataMd5,$path,$filenameMd5);
				 
				 $decryptedMd5=$appObj->desDecrypt($returnValMd5,$vstrKey);	
				 if(strstr($decryptedMd5,'&')){
					$decryptedMd5 = str_replace('&','amp',$decryptedMd5);
				 }	
				 $md5HashArr=explode(":",$decryptedMd5);
				 $md5Hash=$md5HashArr[2];
				 if($md5Hash !="" && $pckUrl[3] !=""){
					  $dataArr=array("success"=>1,"file_path"=>$filePath,"md5_hash"=>$md5Hash);
					  //echo json_encode($dataArr);die;
				 }else{
					  $dataArr=array("success"=>3,"file_path"=>$filePath);
					 //echo json_encode($dataArr);die;
				 }
			 }else{
				 $dataArr=array("success"=>2);
				 //echo json_encode($dataArr);die;
			 }
				$view = new JsonModel($dataArr);
				$view->setTerminal(true);
				return $view;	
			}
		}
		return new JsonModel();
	}
			/*****
	 *	@Function Name: automaticUpadteFimrware
	 *  @description  : update firmawre using file path and md5hash
	 *	@Author		  : Vineet
	 *  @Date         : 21-jan-2020
	 *****/
	public function automaticUpadteFimrwareAction()
	{
		$request = $this->getRequest();
		$appObj =new ApplicationController();
		if($request->isXmlHttpRequest()) {
		$data = $request->getPost('data');
		$filePath = $data[0];
		$md5Hash = $data[1];
	
		$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";			 
		 //Download and install command
		$updatePckCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>FirmUpdate</Cmd><P1>$filePath</P1><P2>1024</P2><P3>$md5Hash</P3><P4>1</P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$getResponse=$appObj->homeNetworkInfo($logincmd,$updatePckCmd);
		$view = new JsonModel(array('success'=>$getResponse));
		$view->setTerminal(true);
		return $view;	
		
		}
		return new JsonModel();
	}
	
				/*****
	 *	@Function Name: getlandingPageInfoAjax
	 *  @description  : get lan and wifi setting
	 *	@Author		  : Vineet
	 *  @Date         : 4-feb-2020
	 *****/
	
public function getlandingPageInfoAjaxAction(){	
	$session = new Container('userinfo');	
	$request = $this->getRequest();
	$appObj = new ApplicationController();
	$modelOsType=$appObj->getModelNameByParam('ostype');
	$viaStr=$appObj->checkQuickWifiConnectStatus() == 1 ? 'VIA_' : ''; // condition changed by niraj
	if($request->isXmlHttpRequest()) {
		/* Lan information*/
		$getMode =$request->getPost('getMode');	
		//Fix security issue if anyone post query
		if( strstr(strtolower($getMode),'select') ||  strstr(strtolower($getMode),'and') || strstr(strtolower($getMode),'or') ){		
			die('Invalid request');
		}			
		$macAddress = $appObj->getMacAddress();
		
		/*WIFI*/
		$returnResult = '';
		if(file_exists(DEST_PATH.'web_network_data.json') && filesize(DEST_PATH.'web_network_data.json') != 0){
			$returnResult = file_get_contents(DEST_PATH.'web_network_data.json');
		}else{
			$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$ipInfo_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetNetworkInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$returnResult = $appObj->homeNetworkInfo($logincmd, $ipInfo_cmd);
			file_put_contents(DEST_PATH.'web_network_data.json', $returnResult);
		}

		if($returnResult === 0) {
			$error = 'noconnection';
		} else if($returnResult == 'loginerror') {
			$error = 'loginerror';
		} else {
			//json change
			$returnResultArray = json_decode($returnResult);		
		//define flags for wifi exist and wifi details
		//if wifi tag found then wifi exists and if WifiInfo tab exist then wifi is ON otherwsie wifi is OfF
			$check_Wifi_ONOFF=0;
			foreach($returnResultArray as $returnKey=>$returnVal){
				//convert object into array
				$returnValArray=(array)$returnVal;			
				if($returnKey=='LAN1'){			
					//list($ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr)= explode("|", $lan1Settings);
					$lan1Settings='';
					$networkData=array();
					foreach($returnValArray as $lan1key=>$lan1Val){
						if($lan1key=='DNS'){
							$DNS1Arr=$lan1key.':'.$lan1Val;
							$networkData['Lan1_Dns']=$lan1Val;
						}
						if($lan1key=='GAT'){
							$defgatewayArr=$lan1key.':'.$lan1Val;
							$networkData['Lan1_Gatway']=$lan1Val;
						}
						if($lan1key=='Host'){
							$lanHostNameArr=$lan1key.':'.$lan1Val;
							$networkData['Lan1_Host']=$lan1Val;
						}
						if($lan1key=='IP'){
							$ipaddrArr=$lan1key.':'.$lan1Val;
							$networkData['Lan1_IP']=$lan1Val;
						}
						if($lan1key=='SUB'){
							$subnetmaskArr=$lan1key.':'.$lan1Val;
							$networkData['Lan1_Sub']=$lan1Val;
						}
						if($lan1key=='DHCP'){
							$networkData['Lan1_Dhcp']=$lan1Val;
						}
						if($lan1key=='Mac'){
							$lan1MacAddrArr=$lan1key.'#'.$lan1Val;
							$networkData['Lan1_Mac']=$lan1Val;
						}
						
						$lan1Settings.=$lan1key.':'.$lan1Val.'|';
						
					}
					
					
				}
				
				if($returnKey=='LAN2'){
					//list($ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr, $DHCPArr, $DNS2Arr, $macAddrArr2)= explode("|", $lan2Settings);
					$lan2Settings='';
					foreach($returnValArray as $lan2key=>$lan2Val){
						if($lan2key=='DNS'){
							$DNS1ArrLan2=$lan2key.':'.$lan2Val;
							$networkData['Lan2_Dns']=$lan2Val;
						}
						if($lan2key=='GAT'){
							$defgatewayArrLan2=$lan2key.':'.$lan2Val;
							$networkData['Lan2_Gatway']=$lan2Val;
						}
						if($lan2key=='Host'){
							$lanHostNameArrLan2=$lan2key.':'.$lan2Val;
							$networkData['Lan2_Host']=$lan2Val;
						}
						if($lan2key=='IP'){
							$ipaddrArrLan2=$lan2key.':'.$lan2Val;
							$networkData['Lan2_IP']=$lan2Val;
						}
						if($lan2key=='SUB'){
							$subnetmaskArrLan2=$lan2key.':'.$lan2Val;
							$networkData['Lan2_Sub']=$lan2Val;
						}
						if($lan2key=='DHCP'){
							$networkData['Lan2_Dhcp']=$lan2Val;
						}
						if($lan2key=='Mac'){
							$lan2MacAddrArr=$lan2key.'#'.$lan2Val;
							$networkData['Lan2_Mac']=$lan2Val;
						}
					
					
						$lan2Settings.=$lan2key.':'.$lan2Val.'|';
					}
					//echo "<br>". substr($lan2Settings,0,-1);
				
				}
				
				
				if($returnKey=='Wifi'){					
					//list($ipaddrArrWifi, $subnetmaskArrWifi, $defgatewayArrWifi, $DNS1ArrWifi, $DNS2ArrWifi)= explode("|", $wifiSettings);
					$wifiSettings='';
					foreach($returnValArray as $wifikey=>$wifiVal){
						if($wifikey=='DNS'){
							$DNS1ArrWifi=$wifikey.':'.$wifiVal;
							$networkData['wifi1_Dns']=$wifiVal;
						}
						if($wifikey=='GAT'){
							$defgatewayArrWifi=$wifikey.':'.$wifiVal;
							$networkData['wifi1_Gatway']=$wifiVal;
						}
						if($wifikey=='Host'){
							$HostNameArrWifi=$wifikey.':'.$wifiVal;
							$networkData['wifi1_Host']=$wifiVal;
						}
						if($wifikey=='IP'){
							$ipaddrArrWifi=$wifikey.':'.$wifiVal;
							$networkData['wifi1_IP']=$wifiVal;
						}
						if($wifikey=='SUB'){
							$subnetmaskArrWifi=$wifikey.':'.$wifiVal;
							$networkData['wifi1_Sub']=$wifiVal;
						}
						if($wifikey=='Mac'){
							$macAddrArrWifi=$wifikey.'#'.$wifiVal;
							$networkData['wifi1_Mac']=$wifiVal;
						}
						
						
						$wifiSettings.=$wifikey.':'.$wifiVal.'|';
					}
					//echo "<br>". substr($wifiSettings,0,-1);
				}				
				
				if(strtolower($returnKey)=='wifiinfo'){					
					$check_Wifi_ONOFF=1;
					$wifiClientSettings='';
					foreach($returnValArray as $wifiInfoKey=>$wifiInfoVal){
						$channels=$returnValArray['Channel'];
						$checkInternetFile=($returnValArray['EnableInternet']!='')?$returnValArray['EnableInternet']:0;
						$checkGuestMode=($returnValArray['Guestmode']!='')?$returnValArray['Guestmode']:0;
						$checkStandAloneFile=($returnValArray['Standalone']!='')?$returnValArray['Standalone']:0;					
						$getMode=$returnValArray['Mode'];
						$SSIDApMode=$returnValArray['SSID'];	
						$signals=$returnValArray['Signal'];
						$rate=$returnValArray['Rate'];
						$security=$returnValArray['Security'];	
						$dualNetwork=$returnValArray['DualNetwork'];
						$hiddenNetwork=$returnValArray['Hidden'];														
						$frequency=$returnValArray['Frequency'];														


														
						$wifiClientSettings.=$wifiInfoKey.':'.$wifiInfoVal.'|';						
					}
					//echo "<br>". substr($wifiClientSettings,0,-1);
					$networkData['mode']=strtolower($getMode);
					$networkData['dualNetwork']=$dualNetwork;
					$networkData['hiddenNetwork']=$hiddenNetwork;
					$networkData['SSID']=$SSIDApMode;
					$networkData['EnableInternet']=$checkInternetFile;
					$networkData['Standalone']=$checkStandAloneFile;
					$networkData['Guestmode']=$checkGuestMode;
					$networkData['Channel']=$channels;
					$networkData['Frequency']=$frequency;
					
				}
				
			
			}//end of foreach

		//showing changeel based on network.json
		$lanDivDisplay=($checkStandAloneFile==1)?'none':'block';
		if(file_exists(DEST_PATH.'network.json')){
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			//echo "<pre>";print_r($arrayNetworkJson);die;
			$wifiArray=$arrayNetworkJson['Wifi'];			
			$checkWifi=0;			
			if(count($wifiArray)>0){
				$checkWifi=1;
			}	
		}

		//storing wifi exist or not		
		$networkData['check_wifi']=$checkWifi;
		//storing wifi ON OFF
		$networkData['check_wifi_OnOff']=$check_Wifi_ONOFF;

	//store netwrok data into session
	$session->offsetSet('networkData', $networkData);
	$session->offsetSet('isWifi_ON_OFF', $check_Wifi_ONOFF);
	//echo "<pre>";print_r($session->offsetGet('networkData'));
	
	
	 }//end of else

				// get Mac address for Linux
		if(GET_OS == 'LIN') {
			if($appObj->checkfile(DEST_PATH,FILE_LIC_DETAILS)) {
				$licfile = DEST_PATH .FILE_LIC_DETAILS;
				$fp = fopen($licfile, "r");
				if($fp) {
					$macAddrStr = "";

					while(!feof($fp)) {
						$fcontent = fgets($fp);
						if($fcontent != "") {
							if(!strstr($fcontent, 'Serial no')) {
								$macAddrStr = $fcontent;
							}
						}
					}
				}
			} else {
				$macAddrStr = "";
			}
			$getlanMacAddrArr = explode('|', $macAddrStr);
			$macAddrLinuxLan1Val = $getlanMacAddrArr[1];
			$modelOSType =$appObj->getModelNameByParam('ostype');
			$hardware =$appObj->getModelNameByParam('hardware');
			//$modelOSType =(CHECK_FC23_FILE == 1)? 'FC 23' : 'FC 20';
			//$hardware =(CHECK_FILE_2955 == 1)? '2955' : '3010';
		}
		/*lan1 settings*/
		if($lan1Settings != '') {
			if(GET_OS == 'WIN') {
				//list($ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr, $DHCPArr, $DNS2Arr, $macAddrArr1)= explode("|", $lan1Settings);
				//list(   $ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr, $DNS2Arr)= explode("|", $lan1Settings);
			}
			if(GET_OS == 'LIN') {
				//list($ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr, $DNS2Arr)= explode("|", $lan1Settings);
			}
			list($tagnameIP, $ipaddr1)= explode(':', $ipaddrArr);
			list($tagnameSubnetMask, $subnetmask1)= explode(':', $subnetmaskArr);
			list($tagnameDefGateWay, $defgateway1)= explode(':', $defgatewayArr);
			list($tagnameDNS1, $dns1)= explode(':', $DNS1Arr);
			// DNS2 has been removed so we use for Hostname
			list($tagnameDNS2, $lan1hostname)= explode(':', $lanHostNameArr);
			//list($tagnameDNS2, $dns2hostname)= explode(':', $DNS2Arr);
			//list($tagnamehost, $hostName1)= explode(':', $DHCPArr);
			list($macAddrLan1key, $macAddrLan1Val)= explode('#', $lan1MacAddrArr);
			$macAddrLan1Val = str_replace(';', ':', $macAddrLan1Val);
			
		
			/*if(GET_OS == 'WIN') {
				list($macAddrLan1key, $macAddrLan1Val)= explode(':', $macAddrArr1);
				$macAddrLan1Val = str_replace(';', ':', $macAddrLan1Val);
			}
			if(GET_OS == 'LIN') {
				$macAddrLan1Val = $macAddrLinuxLan1Val;
			}*/
				$str.= '<div class="col-md-6" id="lanInfoDiv" style="display:'.$lanDivDisplay.'">';
				$str.='<header class="panel-heading b1 p-0">LAN</header>';
				$str.='<section class="panel panel-default">';
				$str.='<table class="table" id="lanmactbl" >';
				$str.='<tr>';
				$str.='<td class="tbllanwifiheading">'.STR_MAC_ADDRESS.'</td>';
				$str.='<td class="tbllaninformation copy-mac-td">'.$macAddrLan1Val.' <div class="copy-mac-div via-hover-icon" data-mac="'.$macAddrLan1Val.'"><img src="'.PUBLIC_URL.'/img/via/icon-duplicate.svg" class="display-block"><img src="'.PUBLIC_URL.'/img/via/icon-duplicate-hover.svg" class="display-none"></div></td>';
				$str.='</tr>';
				$str.='</table></section>';
				$str.='<section class="panel panel-default">';
				$str.='<table class="table" id="lantbl">';
				$str.='<tr>';
				$str.='<td class="tbllanwifiheading">'.  STR_HOST_NAME.' </td>';
				$str.='<td class="tbllaninformation">'. $lan1hostname.'</td>';
				$str.='</tr>';
				$str.='<tr>';
				$str.='<td class="tbllanwifiheading">' .STR_GATEWAY_IP.'</td>';
				$str.='<td class="tbllaninformation"> '.$ipaddr1.'</td>';
				$str.='</tr>';
				$str.='<tr>';
				$str.='<td class="tbllanwifiheading">'.STR_SUBNET_MASK.'</td>';
				$str.='<td class="tbllaninformation">'.$subnetmask1.'</td>';
				$str.='</tr>';
				$str.='<tr>';
				$str.='<td class="tbllanwifiheading"> '.STR_DEFAULT_GATEWAY.'</td>';
				$str.='<td class="tbllaninformation">'.$defgateway1.'</td>';
				$str.='</tr>';
				
				$str.='<tr>';
				$str.='<td class="tbllanwifiheading"> '.STR_DNS_SERVER1.'</td>';
				$str.='<td class="tbllaninformation">'.$dns1.'</td>';
				$str.='</tr>';
				$str.='</tr>';
				$str.='</table>';
				$str.='</section>';
				   
		}
		if($lan2Settings=='')
			  $str.='</div>';
			  
		if($lan2Settings != '') {
			if(GET_OS == 'WIN') {
				//list($ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr, $DHCPArr, $DNS2Arr, $macAddrArr2)= explode("|", $lan2Settings);
			}
			if(GET_OS == 'LIN') {
				//list($ipaddrArr, $subnetmaskArr, $defgatewayArr, $DNS1Arr, $DNS2Arr)= explode("|", $lan2Settings);
			}
			list($tagnameIP, $ipaddr2)= explode(':', $ipaddrArrLan2);
			list($tagnameSubnetMask, $subnetmask2)= explode(':', $subnetmaskArrLan2);
			list($tagnameDefGateWay, $defgateway2)= explode(':', $defgatewayArrLan2);
			list($tagnameDNS1, $dns2)= explode(':', $DNS1ArrLan2);
			list($macAddrLan2key, $macAddrLan2Val)= explode('#', $lan2MacAddrArr);
			
			// DNS2 has been removed so we use for Hostname
			//list($tagnameDNS2, $dns2)= explode(':', $DNS2ArrLan2);
			list($tagnamehost, $dns2hostname2)= explode(':', $lanHostNameArrLan2);
			/*if(GET_OS == 'WIN') {
				list($macAddrLan2key, $macAddrLan2Val)= explode(':', $macAddrArr2);
				$macAddrLan2Val = str_replace(';', ':', $macAddrLan2Val);
			}
			if(GET_OS == 'LIN') {
				$macAddrLan2Val = $macAddrLinuxLan1Val;
			}*/
				
				    $str.='<header class="panel-heading b1 p-0">LAN</header>';
				    $str.='<section class="panel panel-default">';
				    $str.='<table class="table" id="lanmactbl" >';
				    $str.='<tr>';
				   $str.='<td class="tbllanwifiheading">'.STR_MAC_ADDRESS.'</td>';
				    $str.='<td class="tbllaninformation">'.$macAddrLan2Val.'</td>';
				    $str.='</tr>';
					$str.='</table></section>';
					$str.='<section class="panel panel-default">';
                    $str.='<table class="table" id="lantbl">';
					$str.='<tr>';
					$str.='<td class="tbllanwifiheading">'.  STR_HOST_NAME.' </td>';
					$str.='<td class="tbllaninformation">'. $dns2hostname2.'</td>';
					$str.='</tr>';
					$str.='<tr>';
					$str.='<td class="tbllanwifiheading">' .STR_GATEWAY_IP.'</td>';
					$str.='<td class="tbllaninformation"> '.$ipaddr2.'</td>';
					$str.='</tr>';
					$str.='<tr>';
					$str.='<td class="tbllanwifiheading">'.STR_SUBNET_MASK.'</td>';
					$str.='<td class="tbllaninformation">'.$subnetmask2.'</td>';
					$str.='</tr>';
					$str.='<tr>';
					$str.='<td class="tbllanwifiheading"> '.STR_DEFAULT_GATEWAY.'</td>';
					$str.='<td class="tbllaninformation">'.$defgateway2.'</td>';
					$str.='</tr>';
					
					$str.='<tr>';
					$str.='<td class="tbllanwifiheading"> '.STR_DNS_SERVER1.'</td>';
					$str.='<td class="tbllaninformation">'.$dns2.'</td>';
					$str.='</tr>';
					$str.='</tr>';
					$str.='</table>';
                    $str.='</section>';
					$str.= '</div>';
			
				}				
				
			
				
				if(GET_OS=='LIN' && $checkWifi==1 && $check_Wifi_ONOFF==1){
				//(CHECK_FILE_FC23_UBUNTU==1)?exec('ifconfig wlan0 | grep HWaddr | rev | tr -s " " | cut -d " " -f2 | rev'):
				//exec('ifconfig wlan0 | grep ether | tr -s " " | cut -d " " -f3');
				  if(strtolower($modelOsType)=='ubuntu'){
					$macAddrWifiVal= exec('ifconfig wlan0 | grep HWaddr | rev | tr -s " " | cut -d " " -f2 | rev');
				  }
				  else{
					$macAddrWifiVal=exec('ifconfig wlan0 | grep ether | tr -s " " | cut -d " " -f3');
				  }
					  
				}
				
			if(GET_OS == 'WIN') {
			if($wifiSettings != '') {
				/*list($ipaddrArrWifi, $subnetmaskArrWifi, $defgatewayArrWifi, $DNS1ArrWifi, $DHCPArr, $DNS2ArrWifi, $wifiMacAddrArr)= explode("|", $wifiSettings);*/
				list($tagnameIPWifi, $ipaddrWifi)= explode(':', $ipaddrArrWifi);
				list($tagnameSubnetMaskWifi, $subnetmaskWifi)= explode(':', $subnetmaskArrWifi);
				list($tagnameDefGateWayWifi, $defgatewayWifi)= explode(':', $defgatewayArrWifi);
				list($tagnameDNS1Wifi, $dns1Wifi)= explode(':', $DNS1ArrWifi);
				// DNS2 has been removed so we use for Hostname
				list($tagnameDNS2Wifi, $dns2Wifi)= explode(':', $DNS2ArrWifi);
				list($macAddrWifikey, $macAddrWifiVal)= explode('#', $macAddrArrWifi);				
			}
		}
			
		if($checkWifi== 1 && $check_Wifi_ONOFF == 1) {
			if(strtolower($getMode) == 'ap') {
				$mode = 'AP';				
				//$SSIDApMode = $appObj->file_read(LIN_WIFI_PATH.FILE_APMODE_SSID);
				
				$str.= '<div class="col-md-6">';
				$str.= '<header class="panel-heading b1 p-0">'.STR_BTN_WIFI.'</header>';
				if(GET_OS == 'LIN') {
					$str.='<section class="panel panel-default">';
					$str.='<table class="table">';
					$str.='<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_MAC_ADDRESS.'</td>';
					$str.= '<td class="tbllaninformation">'.$macAddrWifiVal.'</td>';
					$str.= '</tr>';
					$str.= '</table></section>';
				}
				$str.= '<section class="panel panel-default">';
				$str.= '<table class="table">';
				$str.= '<tr>';
				$str.= '<td class="tbllanwifiheading">'.STR_MODE.'</td>';
				$str.= '<td class="tbllaninformation">'.$mode.'</td>';
				$str.= '</tr>';
				$str.= '<tr>';
				$str.= '<td class="tbllanwifiheading"> '.STR_SSID.'</td>';
				$str.= '<td class="tbllaninformation" style="word-break: break-all">'.$viaStr.$SSIDApMode.'</td>';
				$str.= '</tr>';


				if(GET_OS == 'LIN') {
					//$read_apmodeChannelFile = $appObj->file_read(LIN_WIFI_PATH.FILE_APMODE_CHANNEL);
					$checkInternetFile =($checkInternetFile == 1)? 'Enabled' : STR_DISABLED;
					$checkStandAloneFile =($checkStandAloneFile == 1)? 'Enabled' : STR_DISABLED;
					$checkGuestMode =($checkGuestMode == 1)? 'Enabled' : STR_DISABLED;
					
					
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_CHANNELS.'</td>';
        			$str.= '<td class="tbllaninformation">'.$channels .'</td>';
					$str.= '</tr>';
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_INTERNET_ACCESS.'</td>';
        			$str.= '<td>'.$checkInternetFile .'</td>';
					$str.= '</tr>';
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_STANDALONE_WIFI.'</td>';
        			$str.= '<td class="tbllaninformation">'.$checkStandAloneFile.'</td>';
					$str.= '</tr>';
					$str.= '<tr style="display:none">';
					$str.= '<td class="tbllanwifiheading">'.STR_GUEST_MODE.'</td>';
        			$str.= '<td class="tbllaninformation">'.$checkGuestMode .'</td>';
					$str.= '</tr>';
				}
			}


			// for wd (wifidirect) mode #added by niraj
			if(strtolower($getMode) == 'wd'){
				$mode = 'WD';								
				$str.= '<div class="col-md-6">';
				$str.= '<header class="panel-heading b1 p-0">'.STR_BTN_WIFI.'</header>';
				$str.='<section class="panel panel-default">';
				$str.='<table class="table">';
				$str.='<tr>';
				$str.= '<td class="tbllanwifiheading">'.STR_MAC_ADDRESS.'</td>';
				$str.= '<td class="tbllaninformation">'.$macAddrWifiVal.'</td>';
				$str.= '</tr>';
				$str.= '</table></section>';
				$str.= '<section class="panel panel-default">';
				$str.= '<table class="table">';
				$str.= '<tr>';
				$str.= '<td class="tbllanwifiheading">'.STR_MODE.'</td>';
				$str.= '<td class="tbllaninformation">'.$mode.'</td>';
				$str.= '</tr>';
				$str.= '<tr>';
				$str.= '<td class="tbllanwifiheading"> '.STR_SSID.'</td>';
				$str.= '<td class="tbllaninformation" style="word-break: break-all">'.$SSIDApMode.'</td>';
				$str.= '</tr>';
				$str.= '<tr>';
				$str.= '<td class="tbllanwifiheading">'.STR_CHANNELS.'</td>';
    			$str.= '<td class="tbllaninformation">'.$channels .'</td>';
				$str.= '</tr>';
				$str.= '<tr>'; 								
				$str.= '<td class="tbllanwifiheading">'.STR_FREQUENCY.'</td>';
    			$str.= '<td>'.$frequency .'</td>';
				$str.= '</tr>';
			}


			if(strtolower($getMode) == 'client') {
				//list($SSID,$channels,$rate,$signals,$security)=explode("|",$wifiClientSettings);
				$mode = 'Client';
				$str.= '<div class="col-md-6">';
				$str.= '<header class="panel-heading b1 p-0">'.STR_BTN_WIFI.'</header>';
			    $str.='<section class="panel panel-default">';
				$str.='<table class="table">';
				$str.='<tr>';
				$str.= '<td class="tbllanwifiheading">'.STR_MAC_ADDRESS.'</td>';
				$str.= '<td class="tbllaninformation">'.$macAddrWifiVal.'</td>';
				$str.= '</tr>';
				$str.= '</table></section>';
		
				$str.='<section class="panel panel-default">';
				$str.='<table class="table">';
				$str.= '<tr>';
				$str.= '<td class="tbllanwifiheading">'.STR_MODE.'</td>';
				$str.= '<td class="tbllaninformation">'.$mode.'</td>';
				$str.= '</tr>';
			
				
				if(GET_OS == 'LIN') {
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading"> '.STR_SSID.'</td>';
					$str.= '<td class="tbllaninformation" style="word-break: break-all">'.$SSIDApMode.'</td>';
					$str.= '</tr>';
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_CHANNELS.'</td>';
					$str.= '<td class="tbllaninformation">'.$channels.'</td>';
					$str.= '</tr>';
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_SIGNAL.'</td>';
					$str.= '<td class="tbllaninformation">'.$signals.'</td>';
					$str.= '</tr>';
					$str.= '<tr>';
					$str.= '<td class="tbllanwifiheading">'.STR_SECURITY.'</td>';
					$str.= '<td class="tbllaninformation">'.$security.'</td>';
					$str.= '</tr>';
					
				}
				if($wifiSettings != '') {
					if(GET_OS == 'LIN') {
						//list($ipaddrArrWifi, $subnetmaskArrWifi, $defgatewayArrWifi, $DNS1ArrWifi, $DNS2ArrWifi)= explode("|", $wifiSettings);
						list($tagnameIPWifi, $ipaddrWifi)= explode(':', $ipaddrArrWifi);
						list($tagnameSubnetMaskWifi, $subnetmaskWifi)= explode(':', $subnetmaskArrWifi);
						list($tagnameDefGateWayWifi, $defgatewayWifi)= explode(':', $defgatewayArrWifi);
						list($tagnameDNS1Wifi, $dns1Wifi)= explode(':', $DNS1ArrWifi);
						// DNS2 has been removed so we use for Hostname
						list($tagnameDNS2Wifi, $dns2Wifi)= explode(':', $HostNameArrWifi);
					}
					//make common interface for windows and linux. Move this part from bottom
					if(GET_OS == 'WIN') {
						//list($ipaddrArrWifi, $subnetmaskArrWifi, $defgatewayArrWifi, $DNS1ArrWifi, $DHCPArr, $DNS2ArrWifi, $wifiMacAddrArr)= explode("|", $wifiSettings);
						list($tagnameIPWifi, $ipaddrWifi)= explode(':', $ipaddrArrWifi);
						list($tagnameSubnetMaskWifi, $subnetmaskWifi)= explode(':', $subnetmaskArrWifi);
						list($tagnameDefGateWayWifi, $defgatewayWifi)= explode(':', $defgatewayArrWifi);
						list($tagnameDNS1Wifi, $dns1Wifi)= explode(':', $DNS1ArrWifi);
						// DNS2 has been removed so we use for Hostname
						list($tagnameDNS2Wifi, $dns2Wifi)= explode(':', $HostNameArrWifi);
					}
				
				   		$str.= '<tr>';
						$str.= '<td class="tbllanwifiheading">'.STR_HOST_NAME.'</td>';
						$str.= '<td class="tbllaninformation">'.$dns2Wifi.'</td>';
						$str.= '</tr>';
						$str.= '<tr>';
						$str.= '<td class="tbllanwifiheading">'.STR_GATEWAY_IP.'</td>';
						$str.= '<td class="tbllaninformation">'.$ipaddrWifi.'</td>';
						$str.= '</tr>';
						$str.= '<tr>';
						$str.= '<td class="tbllanwifiheading">'.STR_SUBNET_MASK.'</td>';
						$str.= '<td class="tbllaninformation">'.$subnetmaskWifi.'</td>';
						$str.= '</tr>';
						$str.= '<tr>';
						$str.= '<td class="tbllanwifiheading">'.STR_DEFAULT_GATEWAY.'</td>';
						$str.= '<td class="tbllaninformation">'.$defgatewayWifi.'</td>';
						$str.= '</tr>';
						$str.= '<tr>';
						$str.= '<td class="tbllanwifiheading">'.STR_DNS_SERVER1.'</td>';
						$str.= '<td class="tbllaninformation">'.$dns1Wifi.'</td>';
						$str.= '</tr>';
				}
			}
				$str.= '</table>';
			    $str.= '</section>';
				$str.= '</div>';

		}

			 echo $str;
			 die;
		
			}
	}
	
	//ajax function for checing server is working or not	
	public function getMirroringInfoAjaxAction(){
		if(file_exists(DEST_PATH.'web_check_discovery.txt')){
			echo trim('Success');
		}else{
			$appObj = new ApplicationController();
			$path = "https://discovery.wowvision.com/";
			$filename = 'index.html';
			$username = "viafirmwaremgmt";
			$pass = "L4kd#@93k29k#4kd92@";
			$data = 1;
			$resp = $appObj->webserviceToGetDataWithTimout($username, $pass, $data, $path, $filename);
			if(strstr($resp,'CHROME Mirroring Server')){
				file_put_contents(DEST_PATH.'web_check_discovery.txt', 1);
				echo trim('Success');
			}else{
				echo trim('Fail');
			}
		}
		die;
	}
	
	// Ajax call for updating date and time
	public function updateDateTimeAjaxAction(){	
		$session = new Container('userinfo');	
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		$currentTime=date('Y-m-d H:i',strtotime($appObj->getMysqlDateTime()));
		$convertTimeStamp=strtotime($currentTime);
		$setDatetime=trim($_POST['datetime']);
		$setDatetimeTimeStamp=strtotime(trim($_POST['datetime']));
		$userData = $session->getArrayCopy();
		//die($currentTime.' and '.$convertTimeStamp.' and '.$setDatetime);
		//Code changed by ashu on 12Sept22. Now we have removed if and else block. Now we can set the time in the past also
		$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetDateTime</Cmd><P1>0</P1><P2>$setDatetime</P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		
		$socketData=trim($appObj->returnSocketData($logincmd,$actionCmd));
		$explodeSocketData=explode("|",$socketData);
		if(strtolower(trim($explodeSocketData[1]))=='success'){
			if(!empty($userData)){
				//store session json to reassign in session
				$appObj->delete_Tbl_Session_CheckData();
				file_put_contents(DEST_PATH.'tmp_web_session.txt', json_encode($userData, true));
			}
			die('success');
		}else{
			die('failure');
		}
		
		
	}	
	

}