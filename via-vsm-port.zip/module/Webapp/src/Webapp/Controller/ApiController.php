<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Webapp\Controller\ApplicationController;
use Zend\View\Model\JsonModel;
use Webapp\Controller\WebProducerController;


class ApiController extends AbstractActionController{

    /*
    * 200 : Success
    * 400 : Bad Request
    * 405 : Method Not Allowed
    */

    

    /*
    * @Function Name    : restAPIsendMsgToAPIserver
    * @Author           : Niraj Gautam
    * @Created Date     : 10/05/2023
    * @Description      : This function will connect to the API server and send requested commands.
    */
    function restAPIsendMsgToAPIserver($logincmd, $actionCmd){  
        $appObj = new ApplicationController();                        
        $result = $appObj->findServerConnection();
        if($result!=0){
            $sock=$result;
            $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
            sleep(1);

            $buf = socket_read($sock,20480);
            $sockWrrite=socket_write($sock, $actionCmd,strlen($actionCmd));
            //sleep(2);
            if(!$sockWrrite){               
                $data='sendDataError'; 
            }else{           
                $data=1;
            }
        }else{
            $data=0;
        }
        if(!is_null($sock)){ @socket_close($sock); }
        return $data;
    }


     /*****
     *  @Function Name      : restAPIsendMsgToAPIserverOther
     *  @description        : returning n/w info for home page connection
     *  @Author             : Niraj Gautam
     *  @Date               : 11-Nov-2023
     *****/     
    function restAPIsendMsgToAPIserverOther($logincmd,$actionCmd){
        $appObj     =   new ApplicationController();                        
        $result     =   $appObj->findServerConnection();
        if($result != 0){   
            $sock = $result;
            $sockWrrite = socket_write($sock, $logincmd,strlen($logincmd));
            sleep(1);
            $buf = socket_read($sock,20480);
            if(trim(strstr($buf,'Error13'))){                       
                $data = 0; 
            }else{
                $sockWrrite = socket_write($sock, $actionCmd,strlen($actionCmd));
                $data = socket_read($sock,20480);
            }
        }else{
            $data = 0;
        }
        if(!is_null($sock)){ @socket_close($sock); }
        return $data;
    } 



    /*
    * @Function Name    : calendarInfoAction
    * @Author           : Niraj Gautam
    * @Created Date     : 10/05/2023
    * @Description      : This function will receive JSON data from session manager and then this create a file CalendarMeetings.txt thne QT will do further process.
    */    
    public function calendarInfoAction(){
        if($this->getRequest()->isPost()){
            $requestData = json_decode(file_get_contents('php://input'), true);
            $filePath = DEST_PATH."CalendarMeetings.txt";
            if(!empty($requestData)){

                if(is_array($requestData["meetingDetails"]) && count($requestData["meetingDetails"]) > 0){
                    //converting into actual json format as QT needs
                    $meetingDetails = [];
                    foreach($requestData["meetingDetails"] as $eventList){
                        $meetingDetails[] = ["event_id" => $eventList["eventId"], "change_key" => $eventList["changeKey"], "name" => $eventList["name"], "title" => $eventList["title"], "start_date" => date("Y-m-d H:i:s", strtotime($eventList["startDate"])), "end_date" => date("Y-m-d H:i:s", strtotime($eventList["endDate"])), "meeting_link" => $eventList["meetingLink"]];
                    }
                    $finalCalendarJson = ["success" => "1", "calendar_type" => $requestData["calendarType"], "MeetingDetails" => $meetingDetails];
                    //writing final json into CalendarMeetings.txt
                    $fp = fopen($filePath, 'w');
                    if($fp){
                        fwrite($fp, json_encode($finalCalendarJson, true));
                        fclose($fp);
                        $this->getResponse()->setStatusCode(200);
                        return new JsonModel(["success" => 1]);
                    }else{
                        $this->getResponse()->setStatusCode(400);
                        return new JsonModel(["success" => 0]);
                    }
                }else{

                    // if meetingDetails object is empty and CalendarMeetings.txt exist then remove CalendarMeetings.txt 
                    if(file_exists($filePath)){
                        unlink($filePath);
                    }
                    $this->getResponse()->setStatusCode(200);
                    return new JsonModel(["success" => 1]);
                }    
            }else{
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }
        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        } 
    }




    /*
    * @Function Name    : publishScreenAction
    * @Author           : Niraj Gautam
    * @Created Date     : 10/05/2023
    * @Description      : This function will receive JSON data from session manager and then inform to QT to publish screen.
    */
    public function publishScreenAction(){
        if($this->getRequest()->isPost()){
            $requestData = json_decode(file_get_contents('php://input'), true);
            $filePath = DEST_PATH.FILE_SESSION_MANAGER;

            if(!empty($requestData)){

                $arrValue = [
                    "roomCode" => $requestData['roomCode'],
                    "roomName" => $requestData['roomName'],
                    "qrCode" => $requestData['qrCode'],
                    "calendar" => $requestData['calendar'],
                    "urlInfo" => $requestData['urlInfo'],
                    "popupCode" => $requestData['popupCode'],
                    "3rdParty" => $requestData['3rdParty'],
                    "popupDimension" => $requestData['popupDimension'],
                    "roomCodeRefreshtime" => $requestData['roomCodeRefreshtime'],
                    "#ipaddress1#" => $requestData['ipAddress1'],
                    "#ipaddress2#" => $requestData['ipAddress2'],
                    "#apname#" => $requestData['apName'],
                    "#appass#" => $requestData['apPass'],
                    "#airplayname#" => $requestData['airplayName'],
                    "qrCodeBypassCode" => $requestData['qrCodeBypassCode'],
                    "teamsGuestMode" => $requestData['teamsGuestMode'],
                    "meeting_launch_on" => $requestData['meetingLaunchOn'],
                    "roomCodeOverlay" => $requestData['roomCodeOverlay'],
                    "via" => $requestData['via']
                ];
                $jsonContent = json_encode($arrValue, true);

                //put values in sessionmanager.json
                file_put_contents($filePath, $jsonContent);

                //put roomName value in roomnamevalueshow.txt
                $roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
                file_put_contents($roomnameTxtFile, $requestData['roomName']);

                $appObj = new ApplicationController();
                // get sessionmanager json data
                $sessionmanagerPath = DEST_PATH.'sessionmanager.json';
                $sessionJsonData = file_get_contents($sessionmanagerPath);
                $sessionjsonArray=json_decode($sessionJsonData, true);

                $settingsUrl = DEST_PATH.'via_settings.json';
                $response = file_get_contents($settingsUrl);
                //decrypt json
                $decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
                $jsonArray=json_decode($decryptResponse, true);

                //update confmod and reserved_screen tag value
                $viaActive = $sessionjsonArray['via']['active'];
                if($viaActive == true){
                    $jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['confmod']='1';
                    $viaShowOnDisplay = $sessionjsonArray['via']['showOnDisplay'];
                    if($viaShowOnDisplay == 1){
                        $jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['reserved_screen']='1';
                    }elseif($viaShowOnDisplay == 2){
                        $jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['reserved_screen']='0';
                    }
                }else{
                    $jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['confmod']='0';
                    $jsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['reserved_screen']='';
                }
                		
                //Encrypt to json				
                $encodedData = json_encode($jsonArray,true);	
                $encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);	
                file_put_contents($settingsUrl, $encryptedJson);

                //send command according to file exist
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $response = $this->restAPIsendMsgToAPIserver($logincmd, $actionCmd);
                if($response == 1){
                    $this->getResponse()->setStatusCode(200);
                    return new JsonModel(["success" => 1]);
                }else{
                    $this->getResponse()->setStatusCode(400);
                    return new JsonModel(["success" => 0]);
                }

            }else{
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }   

        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        } 
    }




    /*
    * @Function Name    : launchMeetingAction
    * @Author           : Niraj Gautam
    * @Created Date     : 10/05/2023
    * @Description      : This function will receive JSON data from session manager and then this informs to the QT to launch meeting.
    */
    public function launchMeetingAction(){
        if($this->getRequest()->isPost()){
            $requestData = json_decode(file_get_contents('php://input'), true);
            if(!empty($requestData)){
                $eventName = $requestData['eventName'];
                $eventType = $requestData['eventType'];
                $eventValue = $requestData['eventValue'];
                $eventOpenAs = strtolower($requestData['openAs']);
                $eventArgs = $requestData['args'];
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Launch</Cmd><P1>7</P1><P2>$eventName</P2><P3>$eventType</P3><P4>$eventValue</P4><P5>$eventOpenAs</P5><P6>$eventArgs</P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $response = $this->restAPIsendMsgToAPIserver($logincmd, $actionCmd);
                if($response == 1){
                    $this->getResponse()->setStatusCode(200);
                    return new JsonModel(["success" => 1]);
                }else{
                    $this->getResponse()->setStatusCode(400);
                    return new JsonModel(["success" => 0]);
                }
            }else{
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }
        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        }
    } 




    /*
    * @Function Name    : launchMeetingAction
    * @Author           : Niraj Gautam
    * @Created Date     : 10/05/2023
    * @Description      : This function will return actual values from sessionmanagerresponse.json.  sessionmanagerresponse.json keep real values of secreen template which is updated QT. and this data QT also post to the session manager.
    */
    public function screenInfoAction(){
        if($this->getRequest()->isGet()){
            $filePath = DEST_PATH."sessionmanagerresponse.json";
            $responseContent = file_get_contents($filePath);
            $responseContent = !empty($responseContent) ? json_decode($responseContent, true) : [];
            $this->getResponse()->setStatusCode(200);
            return new JsonModel($responseContent);
        }else{
            $this->getResponse()->setStatusCode(405); //405: method not allowd
            return new JsonModel(["success" => 0]);
        }
    }




    /*
    * @Function Name    : updateRoomNameAction
    * @Author           : Niraj Gautam
    * @Created Date     : 10/26/2023
    * @Description      : This function will update the roomname in active sessionmanager.json/roomnamevalueshow.txt when session manager call this API
    */
    public function updateRoomNameAction(){

        if($this->getRequest()->isPost()){
            $requestData = json_decode(file_get_contents('php://input'), true);

            if(isset($requestData['roomName'])){

                $filePath = DEST_PATH.FILE_SESSION_MANAGER;
                $roomName = trim($requestData['roomName']);

                //get sessionmanager json data
                $sessionJsonData = file_get_contents($filePath);
                $sessionjsonArray = json_decode($sessionJsonData, true);

                //set roomname and convert into json
                $sessionjsonArray['roomName'] = $roomName;
                $jsonContent = json_encode($sessionjsonArray, true);

                //put values in sessionmanager.json
                file_put_contents($filePath, $jsonContent);

                //put roomName value in roomnamevalueshow.txt
                $roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
                file_put_contents($roomnameTxtFile, $roomName);               

                //send command according to file exist
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $response = $this->restAPIsendMsgToAPIserver($logincmd, $actionCmd);
                if($response == 1){
                    $this->getResponse()->setStatusCode(200);
                    return new JsonModel(["success" => 1]);
                }else{
                    $this->getResponse()->setStatusCode(400);
                    return new JsonModel(["success" => 0]);
                }

            }else{
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }   

        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        } 
    }





    /*
    * @Function Name    : pairViaAction
    * @Author           : Niraj Gautam
    * @Created Date     : 11-Nov-2023
    * @Description      : This function will create sessionmanager.json with default value and send reset command to the api server.
    */
    public function pairViaAction(){
        if($this->getRequest()->isPost() || $this->getRequest()->isGet()){
            $logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $ipInfo_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetNetworkInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            
            $returnResult = $this->restAPIsendMsgToAPIserverOther($logincmd, $ipInfo_cmd);
        
            if($returnResult == 0){
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }else{

                $returnResultArray = json_decode($returnResult, true);  
                $roomName = isset($returnResultArray['LAN1']['Host']) ? $returnResultArray['LAN1']['Host'] : $returnResultArray['Wifi']['Host'];

                $defaultJson = '{"roomCode":"0","roomName": "'.$roomName.'","qrCode":"0","calendar":"0","urlInfo":"http://127.0.0.1:47888/index.html","popupCode":"0","3rdParty":[],"popupDimension":{"fontSize":14,"xCoordinate":100,"yCoordinate":250,"width":250,"height":200,"alignment":"center","backgroundColor":"255,255,255","opacity":"100%","fontColor":"255,255,255"},"roomCodeRefreshtime":0,"#ipaddress1#":"0","#ipaddress2#":"0","#apname#":"0","#appass#":"0","#airplayname#":"0","qrCodeBypassCode":"0","teamsGuestMode":true,"meeting_launch_on":"app"}';

                //put values in sessionmanager.json
                file_put_contents(DEST_PATH.FILE_SESSION_MANAGER, $defaultJson);

                //put roomName value in roomnamevalueshow.txt
                $roomnameTxtFile = DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
                file_put_contents($roomnameTxtFile, $roomName);

                //send command according to file exist
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Reset</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $response = $this->restAPIsendMsgToAPIserver($logincmd, $actionCmd);
                if($response == 1){
                    $this->getResponse()->setStatusCode(200);
                    return new JsonModel(["success" => 1]);
                }else{
                    $this->getResponse()->setStatusCode(400);
                    return new JsonModel(["success" => 0]);
                }
            }
        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        }

    }





    /*
    * @Function Name    : unpairViaAction
    * @Author           : Niraj Gautam
    * @Created Date     : 11-Nov-2023
    * @Description      : This function will remove sessionmanager.json and send Reset command to api server.
    */
    public function unpairViaAction(){
        if($this->getRequest()->isPost() || $this->getRequest()->isGet()){
            unlink(DEST_PATH.FILE_SESSION_MANAGER);
            //send command according to file exist
            $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Reset</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $response = $this->restAPIsendMsgToAPIserver($logincmd, $actionCmd);
            if($response == 1){
                $this->getResponse()->setStatusCode(200);
                return new JsonModel(["success" => 1]);
            }else{
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }
        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        }
    }





    /*
    * @Function Name    : settingsAction
    * @Author           : Niraj Gautam
    * @Created Date     : 30-Jan-2024
    * @Description      : This function is for other settings.
    */
    public function settingsAction(){
        if($this->getRequest()->isPost()){
            $requestData = json_decode(file_get_contents('php://input'), true);
            if(!empty($requestData)){

                $appObj = new ApplicationController();

                $miracastStatus = $requestData['miracastStatus'];

                //getting current via_settings.json data
                $viaSettingJosnPath = DEST_PATH.'via_settings.json';
                $sourceFile_content = file_get_contents($viaSettingJosnPath);  
                $decryptSourceFile = $appObj->desDecrypt($sourceFile_content,POLL_ENCRPTION_KEY);
                $viaSettingJsonArray = json_decode($decryptSourceFile, true);
                
                //updating miracast setting status in via_settings.json
                $viaSettingJsonArray['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['miracast']['status'] = $miracastStatus;

                //encrypting to json               
                $encodedData = json_encode($viaSettingJsonArray, true);
                $encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);                                      
                file_put_contents($viaSettingJosnPath, $encryptedJson);

                // creating/updating sessionmanagersettings.json
                file_put_contents(DEST_PATH."sessionmanagersettings.json", json_encode($requestData, true));
                
                //publish settings
                $getMacAddr=strrev(file_get_contents(DEST_PATH.FILE_MAC_ADDRESS));
                $cmdArr=array("cmd"=>"set_sessionmanager_settings","sender"=>"web-vsm");
                $cmdJson=json_encode($cmdArr);
                $producerObject=new WebProducerController();
                $producerObject->sentRabbitCmdWebProducerAction($cmdJson,array('exchange_name'=>'apiclient','bindingKey'=>$getMacAddr));
                return new JsonModel(["success" => 1]);
                
            }else{
                $this->getResponse()->setStatusCode(400);
                return new JsonModel(["success" => 0]);
            }
        }else{
            $this->getResponse()->setStatusCode(405);
            return new JsonModel(["success" => 0]);
        }
    }

    


}