<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\BrainWareForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
putenv("LD_LIBRARY_PATH=/home/Collab8/Qt-5.12.4/lib");
//use Webapp\Model\TblCertificates;
//use Zend\View\Model\JsonModel;
//use Zend\Mvc\Plugin\FlashMessenger;
//use Webapp\Controller\FileUploadController;
use Webapp\Controller\ApplicationController;

class BrainController extends AbstractActionController {
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
	
	public function uploadBrainlicenseAction(){
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$brainPath=getcwd()."/data";
	
		$appObj = new ApplicationController();
		$deviceInventoryData = $appObj->getTableAllData('DeviceInventory');
		foreach($deviceInventoryData as $deviceInventoryVal) {
			$device_id=trim($deviceInventoryVal['MacAddress']);
			
		}
		
		
		//$this->layout('layout/login');
			$path = UPLOAD_PATH; // upload directory			
			if($this->getRequest()->isPost()) {		
				$serialNo=trim($_POST['serial_number']);
				$external_id=21479;
				//$device_id=trim($gwayMacAddr);//"1A:1E:39:E3:11:1A";
				//182970067130005
				$authData = 'payload={"machine_type":"2","external_id":"'.$external_id.'","device_id":"'.$device_id.'","serial_number":"'.$serialNo.'"}';
				//print_r($authData);
				
				//die;
				$value=$this->kramerav_dss("https://api.kramerav.com/BrainWebAPI.asmx/GetCredentialsReturnBrainJsonDetails",$authData);
				if($value==1){
					//echo 'ok';		
						
					copy($brainPath.'/brain/license.txt',$path."BrainLicense");
					copy($path."BrainLicense","/opt/brain/resources/license/BrainLicense");
					$myfileName=DEST_PATH.FILE_brains;
					$myfile = fopen($myfileName, 'w');				
					$content= "Licensed|LIFETIME";								
					$confWrite= fwrite($myfile, $content);		
					fclose($myfile);
					//write brain serial no in brainserial.txt
					$brainSrNo=DEST_PATH.FILE_BRAIN_SERIAL;
					$mybrainfile = fopen($brainSrNo, 'w');	
					$confWrite= fwrite($mybrainfile, $serialNo);		
					fclose($mybrainfile);
					$flag='active';
					$error='';
					//echo 'License activated successfully.Do you want to reboot VIA to start Brain?';
						
				}else{	
					$flag='inactive';
					//echo $jsonArray=json_decode($value, true);	
					//echo $jsonArray['errMessage'];
					$responseFile=$brainPath.'/brain/responsebody.txt';
					if(file_exists($responseFile)){
						$getJsonData=$appObj->file_read($responseFile);
						$jsonDataArray=json_decode($getJsonData, true);		
						$error=$jsonDataArray['errMessage'];
						
					}		
					
				}
				
			}
			//if($flag=='active'){
					//$fcontent='';	
					$licFile="/opt/brain/resources/license/BrainLicense";		
					$brainSrno=(file_exists(DEST_PATH.FILE_BRAIN_SERIAL))?$appObj->file_read(DEST_PATH.FILE_BRAIN_SERIAL):'';						
					if(file_exists($licFile)){			
						$fileDataJson=$appObj->file_read($licFile);
						$jsonArray=json_decode($fileDataJson, true);		
						$str="";
						$str.='Brain id'.' : '.$jsonArray['brain_id']."</p>";
						$str.='Device id'.' : '.$jsonArray['device_id']."</p>";
						$str.='Serial number'.' : '.$brainSrno."</p>";
						//echo $str;
					}
			
			//}
			
			
			
			
			
			 $form = new BrainWareForm();	
			 return new ViewModel(array(
                'form' => $form,
				'flag'=>$flag,
				'str'=>$str,
				'brainerr'=>$error,
                )
			 );
			
	}
	
	public function getBrainStateAction(){
		$url='https://'.$_SERVER['SERVER_ADDR'].':8000/api/v1/general';
		$response=file_get_contents($url);
		
		if(file_exists(DEST_PATH.FILE_brains)){
			if($response!=''){
				$jsonArray=json_decode($response, true);
				$jsonArray=$jsonArray['result'];
				$brain_state=$jsonArray['brain_state'];
				$brain_status_reason=$jsonArray['brain_status_reason'];
				$brain_version=$jsonArray['brain_version'];
				$project_name=$jsonArray['project_name'];	
			echo "<table width=100% class=gridtable><tr><td align=left><header class='subheader'>STATUS</header></td></tr><tr><td align=left>State</td><td align=left>".$brain_state."</td></tr><tr><td align=left>Reason</td><td align=left>".$brain_status_reason."</td></tr><tr><td align=left>Version</td><td align=left>".$brain_version."</td></tr><tr><td align=left>Project Name</td><td align=left>".$project_name."</td></tr></table>";
			}else{
				//echo 'OFF';
				echo '<table width=100% class=gridtable><tr><td align=left><header class="subheader">STATUS</header></td></tr><tr><td align=left>State</td><td align=left>OFF</td></tr></table></span>';
			}
		}else{
			echo '<table width=100% class=gridtable><tr><td align=left><header class="subheader">STATUS</header></td></tr><tr><td align=left>State</td><td align=left>License not available</td></tr></table>';
		}
		die;
	}
	
	public function kramerav_dss($url,$authData){
		$brainPath=getcwd()."/data/";
		$gaUrl = $url; 	
		// create a new cURL resource
		$ch = curl_init();
	 
		// set URL and other appropriate options

		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HEADER, 0); 
		$headers[] = 'Accept: application/json';
		$headers[] = 'Content-Type: application/x-www-form-urlencoded';
		//$headers[] = 'Content-length: '.strlen($authData)+1;
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers); 
		curl_setopt($ch, CURLOPT_POSTFIELDS, $authData);
		curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		// grab URL and pass it to the browser
		$response = curl_exec($ch);
	   // $resutl="-1";
		if(curl_exec($ch) === false)
		{
			echo '0';
		}
		else
		{
		//echo "Response". $response;die;
		$varOutput=json_decode($response);
		//print_r($varOutput);
		//echo $response;
		//added by ashu. Leave last 3 char in place of 2 as when we we got error proper json was not getting
		$outputData=substr($response,0,strpos($response,"signature")-3);
		//echo $outputData;
		
		$fresponse=fopen($brainPath."brain/responsebody.txt","w");	
		//added by ashu for fix the json format when we get error
		fputs($fresponse,$outputData."\"}\n");
		fclose($fresponse);

		$fresponse=fopen($brainPath."brain/signatre.txt","w");	
		fputs($fresponse,$varOutput->signature);
		fclose($fresponse);
		
		//added by ashu for write response in license file
		$frlicense=fopen($brainPath."brain/license.txt","w");		
		fputs($frlicense,$response);
		fclose($frlicense);		
		
		$systemcmd=exec($brainPath."brain/verifySHAsting",$varReturn);				 
		 return $varReturn[0];
		  
		}
		// close cURL resource, and free up system resources
		curl_close($ch);
		return null;
	}
}
