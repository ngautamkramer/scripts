<?php

namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\AdduserForm;
use Webapp\Form\ChangePasswordForm;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;

use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;

class VsmUserController extends AbstractActionController
{
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

   

	public function userListAction()
	{
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
		$mode='';
		$id = $this->params()->fromRoute('id');
		$getUserData="";
		$userPermissionArr="";
		if ($id!='') {
			$mode='editmode';
			$getUserData=$this->getAppuserListTable()->getUserDataById($id);
			 $getUserPermissions=$this->getAppUserGroupsTable()->fetchUserPermissionsById($id);			
			 $userPermissionArr=array();
			 foreach($getUserPermissions as $key=>$val){
			 	$userPermissionArr[]=$val->appgroupid;
			 }
		}
		$request = $this->getRequest();
		$uNameText ="";
		if($request->isPost()){
			 $uNameText = htmlspecialchars(trim($request->getPost('search')));
		}
		
		$form = new AdduserForm();
		$result = $this->getComplexPasswordTable()->fetchComplexPassword();
		foreach($result as $val) {
			$specialCharVal = $val->specialchar;
			$alphanumericVal = $val->alphanumeric;
			$capitalLtrVal = $val->capitalltr;
			$minCharVal = $val->minimumchar;
			$basicModeVal = $val->applyin_basicmode;
		}
		$form->setData(array('specialCharVal' => $specialCharVal, 'alphanumericVal' => $alphanumericVal, 'capitalLtrVal' => $capitalLtrVal, 'minCharVal' => $minCharVal, 'basicModeVal' => $basicModeVal));
		
		$data=$this->getAppuserListTable()->fetchAll($uNameText);	
		$data->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
		$data->setItemCountPerPage(50);	
        
		$appObj = new ApplicationController();
        $result = $this->getDevicegroupTable()->fetchAll();
		$arrayCategories = array();
		foreach($result as $row){
			$arrayCategories[$row->DeviceGroupID] = array("grp_id" => $row->DeviceGroupID, "parent_id" => $row->DeviceMasterID, "name" =>$row->DeviceGroup, "level" =>$appObj->getDepth($row->DeviceGroupID));   
		}
		$user_grp_arr=array();
		if($user_id !=1){
			$deviceGroup = $this->getDevicegroupTable()->getGroupWithPermission($user_id);
		}
		
		return new ViewModel(array(
			'data' => $data,
			'form' => $form,			
			'mode'=>$mode,
			'userPermissionArr'=>$userPermissionArr,  
            'arrayCategories'=>$arrayCategories,
			'deviceGroup'=>$deviceGroup,
            'search' => $uNameText,
            'appObj' => $appObj			
		));				
	}
	
	/*****
	 *	@Class Name			: delUsersAction
	 *  @description	    : Using for delete users                     
	 *	@Author			    : Dileep
	 *  @Date               : 30-April-2020
	 *****/ 
	
	 public function delUserAction(){
	 	$appObj=new ApplicationController();
		$userid = $this->getRequest()->getPost('userid');
		$deldata=$this->getAppuserListTable()->deleteUser($userid);
		$delPermissiondata=$this->getTblUserAccessTable()->deletePermission($userid);
		//manage log			
		$appObj->ActivityLogVSM(5,STR_USERNAME.' '.MSG_USER_DELETED,1);	
		echo '1'; die;	
	}
	
	/*****
	 *	@Class Name			: addUserAction
	 *  @description	    : Using for adding users                    
	 *	@Author			    : Dileep
	 *  @Date               : 29-Apr-2020
	 *****/ 	
	
	public function addUserAction(){
		$appObj=new ApplicationController();
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('LoginName');
		$form = new AdduserForm();		
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();		
			$username=trim($postData['txtUserId']);
			$password=trim($postData['txtPassword']);
			$conf_password=trim($postData['txtConfirmPassword']);
			$mode=trim($postData['usermode']);
			
		    $getComplexResponse=$this->checkComplexPassRuleAction($password,$mode);	
			if($getComplexResponse !=""){
				echo $getComplexResponse;die;
			}
			
			if($mode=='editmode'){
				$userid=trim($postData['userid']);
				//die('edit mode');
				if($password && $userid){
					$this->getAppuserListTable()->updateUser($userid,$password);
				}
				if(isset($postData['userPermission'])){
					$this->getTblUserAccessTable()->deletePermission($userid);
				}else{
				    $appObj->returnQueryData("DELETE FROM tbl_user_access WHERE user_id_fk=$userid AND menu_id_fk IN (1,2,24,65,18,68)");	
				}
				$this->getTblUserAccessTable()->saveUserPermission($postData,$userid);
				//manage log			
				$appObj->ActivityLogVSM(4,STR_USERNAME.' '.MSG_USER_UPDATED,1);	
				//return $this->redirect()->toRoute('user');
				die('updatesuccess');
			
			}else{
				//$checkuser=$this->checkUserAction($username);	
				if( strlen($username) < 4 && $session->offsetGet('lang')=='eng') {
					die('length_error');
				}else if(preg_match('/[^a-z_.\-0-9]/i', $username) && $session->offsetGet('lang')=='eng'){
					die('format_error');
				}else if(str_contains($username, "'") == true || str_contains($username, '\\') == true){
					// check if username contains ' \ for all languages
					die('format_error');
				}else if($password!=$conf_password){
					die('password_not_match_error');
				}
				/*else if($checkuser=='exist'){
					die('exist');
				}*/
				else{				
					$lastInsertId= $this->getAppuserListTable()->saveUser($postData,$sessionLoginName);				
					$this->getTblUserAccessTable()->saveUserPermission($postData,$lastInsertId);
					//remove in 3.1
					$appObj->returnQueryData("INSERT INTO appusergroups (appuserid,appgroupid,modifydate ,hostname ,UserName) VALUES('$lastInsertId','1',now(),'192.168.100.28','su')");
					
					//manage log			
					$appObj->ActivityLogVSM(3,STR_USERNAME.' '.MSG_USER_CREATE,1);	
					die('success');
					//$this->flashMessenger()->addMessage('User added successfully');
					//return $this->redirect()->toRoute('user');
				}
			}
		}
	}

	/*****
	 *	@Class Name			: getUserDataAction
	 *  @description	    : get the user data for update user                  
	 *	@Author			    : Dileep
	 *  @Date               : 30-April-2020
	 *****/ 	
	
	public function getUserDataAction()
	{
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();	
			$id=trim($postData['id']);
			$getUserData=$this->getAppuserListTable()->getUserDataById($id);
			$getUserPermissions=$this->getTblUserAccessTable()->fetchPermissionsById($id);
			$userPermissionArr=array();
			foreach($getUserPermissions as $key=>$val){
			 	$userPermissionArr[]=$val->menu_id_fk;
			}
			
	 		$apploginname=($getUserData->apploginname!='')?$getUserData->apploginname:'';
	 		$email=($getUserData->email!='')?$getUserData->email:'';
			$userPermissionsStr=implode(',',$userPermissionArr);
			$role='';
			if(in_array(1,$userPermissionArr)){
				$role.=$apploginname."#".$email."#"."1";
			}else{
				$role.=$apploginname."#".$email.'#'.$userPermissionsStr;
			}
			echo $role;die;
		}
	
	}
	
	//Check the user is already exists
	public function checkUserAction()
	{	
        if($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$apploginname = $postData['uname'];
			$appObj = new ApplicationController();
			$query = "SELECT * FROM appuserlist WHERE apploginname='".$apploginname."'" ;
			$response = $appObj->returnQueryData($query);
		    echo ($response->count()==0)?'notexist':'exist';die;
        }				
	}
	//Check the email is already exists
	public function checkEmailAction()
	{		
	    if($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$email = $postData['email'];
			$appObj = new ApplicationController();
			$query = "SELECT * FROM appuserlist WHERE email='".$email."'" ;
			$response = $appObj->returnQueryData($query);
			echo ($response->count()==0)?'notexist':'exist';die;	
	    }
	}
	

	/*****
	 *	@Class Name			: serverActivityAction
	 *  @description	    : Using for reboot and shutdown         
	 *	@Author			    : Ashu
	 *  @Date               : 17-December-2019
	 *****/ 	 
	public function serverActivityAction(){
		$appObj=new ApplicationController();
		$flag=trim($_POST['flag']);
		$input=($flag=='reboot')?'reboot':'shutdown';
		$res=$appObj->reboot_powerOff_Server($input);
                echo "<script>document.write('<html><head><title>VIA</title></head><body style=\"color: #000000;font-family: Open Sans,sans-serif;font-size: 14px;\">Please wait while system is rebooting...</body></html>')</script>";
                die;
		if($res==1){
			echo 'Reboot';
		}	
		die;
	}
    
	/*****
	 *	@Class Name			: setPermissionAction
	 *  @description	    : Set the permission action                  
	 *	@Author			    : Dileep
	 *  @Date               : 19-May-2020
	 *****/ 	
	
	public function setPermissionAction()
	{
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
				
			$grp_ids = $postData['grp_ids'];
			$menu_ids = $postData['permission_ids'];
			$lastpicid = $postData['lastUserId'];
			$menu_ids_array=explode(",",$menu_ids);
		    $permission_array=array();
		    $permission_array1=array();
		    $permission_array2=array();
		    $permission_array3=array();
            $appObj=new ApplicationController();
            $connection=$appObj->getConnection();			
			// Select the permission start
			foreach($menu_ids_array as $perValue){
			   if($perValue==1){
				  $resData=$connection->execute("SELECT id FROM tbl_menus WHERE status=1");	
				  foreach($resData as $row){
					  $permission_array1[]=$row['id'];
				  }
				  break;
			    }else if($perValue==7){
				    $permission_array2=array(3,4,5,6,69,72,73,70,74,7,8,9,10,11,12,13);   // New Menu Added for calendar Setting(13-Aug-2018)
				}else{
					$permission_array3[]=$perValue;    
				}
                $connection->disconnect();				
			 }
            if(count($permission_array2)>1){
				   $permission_array=array_unique(array_merge_recursive($permission_array2,$permission_array3));
			}else{
				 $permission_array=$permission_array1;
			}
			if(empty($permission_array)){
				$permission_array=$permission_array3;
			}
			//end
            $appObj->returnQueryData("DELETE FROM tbl_user_access WHERE user_id_fk=$lastpicid AND menu_id_fk NOT IN (56,57,58,60,61,1,2,67,24,65,17,68)");			
			$grp_ids_arr=explode(",",$grp_ids);
			foreach($grp_ids_arr as $row){
					$final_grp_ids[]=$row;
					$grp=$row;
			 }
			 // insert the user access
			 $sql_query="INSERT INTO tbl_user_access(module_id_fk,menu_id_fk,access_id_fk,user_id_fk,group_id_fk)values ";
			 $value_array=array();
			 foreach($final_grp_ids as $grp_val){
				 foreach($permission_array as $menu_val){
					 $data = $connection->execute("SELECT module_id_fk FROM tbl_menus WHERE id=$menu_val");
					 $row = $data->current();				 
					 $module_id=$row['module_id_fk'];
					 $menu_id=$menu_val;
					 $access_id="0";
					 $user_id=$lastpicid;
					 $group_id=$grp_val;
					 if($module_id !="" && $menu_id !=""){
						  $value_array['module_id'] = $module_id;
						  $value_array['menu_id'] = $menu_id;
						  $value_array['access_id'] = $access_id;
						  $value_array['user_id'] = $user_id;
						  $value_array['group_id'] = $group_id;
						  $value_array_final[] = $value_array;
					 }
					$connection->disconnect();	
				 }	 
			 }
			 $this->getTblUserAccessTable()->saveAllPermission($value_array_final);
			 //$sql_query .= implode(',', $value_array);
			//echo"<pre>";print_r($sql_query);die;
			 //$appObj->returnQueryData($sql_query);
			 echo "success";die;
	  }
	
  }
  /*****
	 *	@Class Name			: getPermissionAction
	 *  @description	    : Get all permission to respective user                 
	 *	@Author			    : Dileep
	 *  @Date               : 19-May-2020
	 *****/ 	
	
	public function getPermissionAction()
	{
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$userid = trim($postData['user_id']);
            if($userid){
				 $queryResponse = $this->getTblUserAccessTable()->fetchPermissionsById($userid);
				 foreach($queryResponse as $val){
					 $menuIdArr[] = $val->menu_id_fk;
					 $groupIdArr[] = $val->group_id_fk;
				 }
				 $menuIds = implode(",",array_unique($menuIdArr));
				 $groupIds = implode(",",array_unique($groupIdArr)); 
				 $permissionData=array("menu_id"=>$menuIds,"group_id"=>$groupIds);
			     $encodedData = json_encode($permissionData);
				 echo $encodedData;die;
			}		
			
		}
	}
	


	public function getAppuserListTable() {
		if (!$this->TblAppuserListTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblAppuserListTable = $sm->get('Webapp\Model\TblAppuserListTable');
			
		}
		return $this->TblAppuserListTable;
	}
	
	public function getTblUserAccessTable() {
		if (!$this->TblUserAccessTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblUserAccessTable = $sm->get('Webapp\Model\TblUserAccessTable');
			
		}
		return $this->TblUserAccessTable;
	}
	public function getDevicegroupTable() {
		if(!$this->TblDevicegroupTable) {
			$sm = $this->getServiceLocator();
			$this->TblDevicegroupTable = $sm->get('Webapp\Model\TblDevicegroupTable');
		}
		return $this->TblDevicegroupTable;
	}
	 
	/*public function getAppUserGroupsTable() {
		if (!$this->TblAppUserGroupsTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblAppUserGroupsTable = $sm->get('Webapp\Model\TblAppUserGroupsTable');
			
		}
		return $this->TblAppUserGroupsTable;
	}*/
	
	public function changePasswordAction(){
		$form = new ChangePasswordForm();
		$result = $this->getComplexPasswordTable()->fetchComplexPassword();
		foreach($result as $val) {
			$specialCharVal = $val->specialchar;
			$alphanumericVal = $val->alphanumeric;
			$capitalLtrVal = $val->capitalltr;
			$minCharVal = $val->minimumchar;
			$checkOldPassVal = $val->checkoldpass;
		}
		$form->setData(array('specialCharVal' => $specialCharVal, 'alphanumericVal' => $alphanumericVal, 'capitalLtrVal' => $capitalLtrVal, 'minCharVal' => $minCharVal, 'checkOldPassVal' => $checkOldPassVal));
		return new ViewModel(array(
			'form' => $form,
		));
	}
	
	public function changePasswordFileAction(){
		$appObj=new ApplicationController();
		$session = new Container('userinfo');
		$name = $session->offsetGet('LoginName');
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {	
			$strusrName =  trim($request->getPost('uname'));
			$oldpasswd  =  trim($request->getPost('oldpasswd'));
			$newpasswd  =  trim($request->getPost('newpasswd'));
			//$userid  =  trim($request->getPost('userid'));
			$txtRemarks="Added By ".$name;
			$hostname = DEFAULT_SERVER_IP;
			
			if($name==$strusrName){
				$cond = array('apploginname'=>$strusrName,'password'=>$appObj->securePassword($oldpasswd));
				$qry = $this->getAppuserListTable()->checkUserByNameAndPass($cond);
				if($qry==0){
				echo"wrong";die;
				}else{
				$this->getAppuserListTable()->updateUserByName($strusrName,$newpasswd);
				$appObj->ActivityLogVSM(3,'Change password for '.STR_USERNAME,1);
				$session->getManager()->destroy();
				echo"success";die;
				}
			}
			
			
		}
		die;	
	}
	
	//Check the complex password validation
	public function checkComplexPassRuleAction($password,$mode)
	{
	    $appObj=new ApplicationController();
        $connection = $appObj->getConnection();
	    $qryRes = $connection->execute("SELECT * FROM complexpassword");
	    $rowData=$qryRes->current();
		$error = '';
		if($mode !='editmode'){
			if($password == ""){
				$error = "Enter the password"; 
			}
		}
		
		if($password){
			if($rowData['alphanumeric'] == 1 ){ 
				if ( ctype_alnum($password)){
					$error = ''; 
				}else{
					$error = "Enter alphanumeric!"; 
				} 
			}
			if($rowData['specialchar'] == 1 ){
				if ( ctype_alnum($password)){
					$error = 'Enter at least one special character!'; 
				}else{
					$error = ''; 
				} 
			}
			if (strlen($password) < $rowData['minimumchar']){
				$error = 'Password should not be less than '.$rowData['minimumchar'];				
			}
		}
		return $error;	
   }
	/*****
	 *	@Class Name			: getComplexPasswordTable
	 *  @description	    : get complexpass table      
	 *	@Author			    : vineet
	 *  @Date               : 1-jun-2020
	 *****/ 	 
	 
	public function getComplexPasswordTable() {
		if(!$this->TblComplexPasswordTable) {
			$sm = $this->getServiceLocator();
			$this->TblComplexPasswordTable = $sm->get('Webapp\Model\TblComplexPasswordTable');
		}
		return $this->TblComplexPasswordTable;
	}
	 
}
