<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\GlobalSettingsForm;
use Webapp\Form\CertificateForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Model\TblCertificates;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
//use Webapp\Controller\FileUploadController;
use Webapp\Controller\ApplicationController;

class SettingsController extends AbstractActionController {
	//checking session
	public function onDispatch(MvcEvent $e) {
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['sessionTimeOut'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
		
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index', array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	//Auto power off Ajax - Added by Ranjan
	public function autoPowerOffAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$autpPowerChkBoxVal = trim($request->getPost('autpPowerChkBoxVal'));
			$concatVal = trim($request->getPost('concatVal'));
			$fileName = DEST_PATH . FILE_AUTO_POWEROFF;
		}
	}
        
      
	public function globalSettingsAction() {
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $AppObj = new ApplicationController();
            if($this->getRequest()->isPost()) {
                $tblCertificates = new TblCertificates();
                $certForm = new CertificateForm();
                $certForm->setInputFilter($tblCertificates->getInputFilter());
                $certForm->setData($this->getRequest()->getPost());
                if($certForm->isValid()) {
                    $postData = $this->getRequest()->getPost()->toArray();
                    $certFile = $this->params()->fromFiles('certificateCertFile');
                    $keyFile = $this->params()->fromFiles('certificateKeyFile');
                    $certFileArr=explode(".",$certFile['name']);
                    $certName=end($certFileArr);
                    $certKeyArr=explode(".",$keyFile['name']);
                    $certKey=end($certKeyArr);
                    //Check the file extension
                    if(strtolower($certName) !="crt"){
                            echo "<script>alert('".MSG_VALID_CERTIFICATE."');</script>";die;
                    }
                    if(strtolower($certKey) !="key"){
                            echo "<script>alert('".MSG_SELECT_VALID_KEY."');</script>";die;
                    }
                    //check the file size
                    if($_FILES['certificateFile']['size'] > 20000 ){
                            echo "<script>alert('".MSG_INVALID_CERTIFICATE_SIZE."');</script>";die;
                    }
                    if($_FILES['certificateKeyFile']['size'] > 20000){
                            echo "<script>alert('".MSG_INVALID_KEY_SIZE."');</script>";die;
                    }
                    if(isset($certFile['error']) && $certFile['error'] == 0 && isset($keyFile['error']) && $keyFile['error'] == 0) {
                        $certificateData = $this->getCertificatesTable()->getCertificateCount();
                        if($certificateData['count']>0){
                            unlink(CERTIFICATE_UPLOAD_PATH."/".$certificateData['cert_file_name']);
                            unlink(CERTIFICATE_UPLOAD_PATH."/".$certificateData['key_file_name']);
                        }

                        move_uploaded_file($certFile['tmp_name'], CERTIFICATE_UPLOAD_PATH."/".$certFile['name']);
                        $md5hashCertificateFile=md5_file(CERTIFICATE_UPLOAD_PATH."/".$certFile['name']);	
                        move_uploaded_file($keyFile['tmp_name'], CERTIFICATE_UPLOAD_PATH."/".$keyFile['name']);	
                        $md5hashcertificateKeyFile=md5_file(CERTIFICATE_UPLOAD_PATH."/".$keyFile['name']);

                        $certificateflag=0;
                        $certificateArr = array('cert_file_name'=>$certFile['name'], 'cert_file_md5'=>$md5hashCertificateFile, 'key_file_name'=>$keyFile['name'], 'key_file_md5'=>$md5hashcertificateKeyFile, 'status'=>0);
                        $certificateflag = $this->getCertificatesTable()->insertOrTruncateCertificate($certificateArr);

                        if($certificateflag==1){
                            $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                            $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Certificate</Cmd><P1>1</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                            $returnResult=$AppObj->returnSocketData($logincmd,$actionCmd);
                            $explodeReturnResult=explode('|',$returnResult);	
                            $getResponse=(trim($explodeReturnResult[2])==1)?MSG_SUCCESS_CERT:MSG_FAILED_CERT;	
                            $this->flashMessenger()->addMessage($getResponse);
                            return $this->redirect()->toRoute('settings',array('action' => 'globalSettings'));
                        }
                    }     
                }  
            }
            
            //Get or insert session value
            $sessionVal = $this->getSessionSettingsTable()->getOrInsertSessionValue($loginName); 
            //Get NTP Setting
            $getNTPData = $this->getNtpServerTable()->getNtp();
            
            $settingValue = $AppObj->getTableAllData('tbl_hq_more_configuration')->current();
            $globalSettingsVal = $settingValue['featureStatus4'];
            $cmplxSettings = $AppObj->getComplexPasswordSettings();
            
            
            $sessionTimeOutArray=array('10'=>'10 Minute','20'=>'20 Minute','30'=>'30 Minute','60'=>'1 Hour','120'=>'2 Hours','360'=>'6 Hours','1440'=>'24 Hours');
            //$form->setData(array('sessionTimeOutArray' => $sessionTimeOutArray, 'sessionVal' => $sessionVal));
            $form = new GlobalSettingsForm($sessionTimeOutArray,$sessionVal,$cmplxSettings);
            return new ViewModel(array(
                'form' => $form, 
                'globalSettingsVal' => $globalSettingsVal,
                'alphanumericSetting' => $cmplxSettings['alphanumeric'], 
                'specialCharSetting' => $cmplxSettings['specialchar'], 
                'capitalLtrSetting' => $cmplxSettings['capitalltr'], 
                'oldPassSetting' => $cmplxSettings['checkoldpass'],
                'minCharSetting' => $cmplxSettings['minimumchar'],
                'passValiditySetting' => $cmplxSettings['passvalidity'],
                'basicModeSetting' => $cmplxSettings['applyin_basicmode'],
                'getNTPData' => $getNTPData,
                'logoutTime' => $sessionVal['sessionTimeOut'],
                'captchaTxt' => $sessionVal['captcha'],
                'broadcastSettings' => $sessionVal['field1'],
                )
            );   
	}
        
        //Ajax to set session and broadcast value
        public function sessionBroadcastSettingAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $timeVal = trim($request->getPost('timeVal'));
                $broadcastValue = trim($request->getPost('broadcastValue'));
                $this->getSessionSettingsTable()->insertOrUpdateSessionValue($timeVal,$broadcastValue,$loginName);
                $filename=DEST_PATH.FILE_BROADCAST_IP;
                if($broadcastValue==1){
                    $AppObj = new ApplicationController();
                    if(!file_exists($filename)){
                        $AppObj->createFile($filename,$val='');
                    }		  
                }else{
                    unlink($filename);
                }
                echo "success";die();
            }
        }
        
        //Ajax for upload certificate
        public function checkCertifiacteFileAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $certificateFile = trim($request->getPost('certificateFile'));
                $certificateKeyFile = trim($request->getPost('certificateKeyFile'));
                if(strstr($certificateFile,'\\')){	
                    $url_arr = explode ("\\", $certificateFile);
                    $ct = count($url_arr);
                    $certificateFile = $url_arr[$ct-1];
                }
                if(strstr($certificateKeyFile,'\\')){	
                    $url_arr = explode ("\\", $certificateKeyFile);
                    $ct = count($url_arr);
                    $certificateKeyFile = $url_arr[$ct-1];
                }
                $whereArr = array('cert_file_name'=>$certificateFile,'key_file_name'=>$certificateKeyFile);
                $certCount = $this->getCertificatesTable()->checkCertificate($whereArr);
                if($certCount>0){
                    echo 'exists';exit;
                }else{
                    echo 'notexists'; exit;
                }
            }
        }
        
        public function resetCertifiacteFileAction(){
            $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Certificate</Cmd><P1>0</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
            $AppObj = new ApplicationController();
            $returnResult=$AppObj->returnSocketData($logincmd,$actionCmd);
            $explodeReturnResult=explode('|',$returnResult);	
            $getResponse=trim($explodeReturnResult[2]);
            if($getResponse==1){
                $this->getCertificatesTable()->truncateTable();
            }
            echo $getResponse;					
            exit;
        }
        
        //Ajax for NTP setting
        public function getNtpAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $ntpServer = trim($request->getPost('ntpServer'));
                $ntpId = trim($request->getPost('ntpId'));
                $selectedNTP = $this->getNtpServerTable()->getSelectedNtp($ntpId);
                $ntpData = $selectedNTP->id . '#'. $selectedNTP->ntp_name;
                echo $ntpData;die;
            }   
        }
        
        public function saveNTPServerSettingAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $ntpServer = trim($request->getPost('ntpServer'));
                $randStringNtpQuid = mt_rand(10000, 9999999)."".rand(10,999)."".time();
                $ntpCount = $this->getNtpServerTable()->getNtpByName($ntpServer);
                if($ntpCount>0){
                    echo 'serverExist'; exit;
                }else{
                    $insertArr = array('ntp_name'=>$ntpServer,'status'=>'0', 'ntp_uuid'=>$randStringNtpQuid, 'modifydatetime'=>date("Y-m-d h:i:s"));
                    $this->getNtpServerTable()->insertNtp($insertArr);
                }
                
                $AppObj = new ApplicationController();
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>NTPInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $AppObj->sendMsgToAPIserver($logincmd,$actionCmd);
                echo 'success';exit;
            }
        }
        
        public function updateNTPServerSettingAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $ntpServer = trim($request->getPost('ntpServer'));
                $ntpId = trim($request->getPost('ntpId'));
                $ntpCount = $this->getNtpServerTable()->checkNtp($ntpId, $ntpServer);
                if($ntpCount>0){
                    echo 'serverExist'; exit;
                }
                $updateArr = array('ntp_name'=>$ntpServer,'status'=>'2');
                $where = array('id'=>$ntpId);
                $this->getNtpServerTable()->updateNtp($updateArr, $where);
                $AppObj = new ApplicationController();
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>NTPInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $AppObj->sendMsgToAPIserver($logincmd,$actionCmd);
                echo 'success';exit;
            } 
        }
        
        public function deleteNTPServerAction(){
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()){
                $ntpId = trim($request->getPost('ntpId'));
                $getOptValue = trim($request->getPost('getOptValue'));
                $where = array('id'=>$ntpId);
                if($getOptValue==0){
                    $updateArr = array('status'=>3);
                    $this->getNtpServerTable()->updateNtp($updateArr, $where);			
                }	
                if($getOptValue==1){
                    $updateArr = array('status'=>0);
                        $this->getNtpServerTable()->updateNtp($updateArr, $where);
                }
                $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>NTPInfo</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
                $AppObj = new ApplicationController();
                $AppObj->sendMsgToAPIserver($logincmd,$actionCmd);
                $countDel = $this->getNtpServerTable()->getNtp();
                echo (count($countDel)>0)?'success':0;		
                die;
            }
        }
        
        //Ajax for Security settings
        public function securitySettingsAction(){
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $hostname = DEFAULT_SERVER_IP;
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $captchaVal = trim($request->getPost('captchaVal'));
                $alphanumericValue = trim($request->getPost('alphanumericVal'));
                $specialCharValue = trim($request->getPost('specialCharVal'));
                $capitalLtrValue = trim($request->getPost('capitalLtrVal'));
                //$checkOldPassValue = trim($request->getPost('checkOldPassVal'));
                $minimumCharValue = trim($request->getPost('minimumCharVal'));
                //$passValidityValue = trim($request->getPost('passValidityVal'));
                $basicModeValue = trim($request->getPost('basicModeVal'));
            }
            $captchaArr = array('captcha'=>$captchaVal);
            $this->getSessionSettingsTable()->updateCaptcha($captchaArr);
            $policyArr = array('alphanumeric'=>$alphanumericValue, 'specialchar'=>$specialCharValue, 'capitalltr'=>$capitalLtrValue, 'minimumchar'=>$minimumCharValue,'applyin_basicmode'=>$basicModeValue);
            $this->getComplexPasswordTable()->updatePasswordPolicy($policyArr);
            $this->getActivityLogMasterTable()->setActivity($loginName, APPLY_BTN, MSG_PASS_POLICYC, $hostname);
            echo "success"; die;
        }

	public function getActivityLogMasterTable() {
            if(!$this->TblActivityLogMasterTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
            }
            return $this->TblActivityLogMasterTable;
	}

	public function getSessionSettingsTable() {
            if(!$this->TblSessionSettingsTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblSessionSettingsTable = $sm->get('Webapp\Model\TblSessionSettingsTable');
            }
            return $this->TblSessionSettingsTable;
	}
        
        public function getCertificatesTable() {
            if(!$this->TblCertificatesTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblCertificatesTable = $sm->get('Webapp\Model\TblCertificatesTable');
            }
            return $this->TblCertificatesTable;
	}
        
        public function getNtpServerTable() {
            if(!$this->TblNtpServerTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblNtpServerTable = $sm->get('Webapp\Model\TblNtpServerTable');
            }
            return $this->TblNtpServerTable;
	}

	 public function getComplexPasswordTable() {
            if(!$this->TblComplexPasswordTable) {
                    $sm = $this->getServiceLocator();
                    $this->TblComplexPasswordTable = $sm->get('Webapp\Model\TblComplexPasswordTable');
            }
            return $this->TblComplexPasswordTable;
	}
}
