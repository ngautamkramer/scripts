<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//use Webapp\Form\ViaConfigurationForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\IndexController;

class HomePageController extends AbstractActionController {
	//checking session
	public function onDispatch(MvcEvent $e) {
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	//Modify VSM Home Page - added by Ranjan
	public function modifyHomePageAction() {
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$appObj = new ApplicationController();
		$hqSettingSql=$appObj->returnQueryData("SELECT dns_settings FROM tbl_hq_settings");
		$settingRow=$hqSettingSql->current();
		$uploaddir =UPLOAD_DIR_ZEND.'img/Logo/';	
		$images = glob($uploaddir . "*.*");
		foreach($images as $image)
		{ 
			$imageName = basename($image);
		}
		$uploadLogo=(file_exists($image))?PUBLIC_URL.'/img/Logo/'.$imageName:PUBLIC_URL.'/img/via/logo.jpg';
		$logoUrl="";
	    $logoUrlSql=$appObj->returnQueryData("SELECT field2 FROM settings ORDER BY id DESC LIMIT 1");
		if($logoUrlSql->count()>0){ 
			$data= $logoUrlSql->current();
				$logoUrl=$data['field2'];	
			
		}
		//get tpl content
		$templateDir = BASE_PATH.'/module/Webapp/view/webapp/index/';
		$tplFile=$templateDir.'index.phtml';
		if(file_exists($tplFile)){	
			$fileContents=file_get_contents($tplFile);
		}else{
			die('Default template error');
		}
		//implement homecolortheme.json on index page.
		$filepath = DEST_PATH.'homecolortheme.json';
		$jsonFileDataArray=$appObj->getDecryptJsonFileData($filepath);
		return new ViewModel(array('settingRow' => $settingRow, 'uploadLogo' => $uploadLogo, 'logoUrl' => $logoUrl, 'fileContents' => $fileContents, 'jsonFileDataArray'=>$jsonFileDataArray));
	}

	public function uploadCustomLogoAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$name = $session->offsetGet('LoginName');
		$time = time();
		$utype=$session->offsetGet('utype');
		if($_GET['state']=='mainImage'){
			if($_FILES['userfile']['tmp_name']!=''){
				$arrImgInfo = getimagesize($_FILES['userfile']['tmp_name']);	
				$imgsize=round(filesize($_FILES['userfile']['tmp_name'])/1024,2);
				$getUploadImgType=image_type_to_extension($arrImgInfo[2]);
				if($imgsize>2000){
					echo"sizeerror"; 
					exit;
				}
					
				$file_ext = $appObj->getfileType($arrImgInfo['mime']);		 
				 
				$uploaddir =UPLOAD_DIR_ZEND.'img/Logo/';	
				$images = glob($uploaddir . "*.*");

				foreach($images as $image)
				{
					unlink($image);
				}
				
				if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploaddir.$_FILES['userfile']['name']) ) {
					echo "Uploaded";die;
				} else {
				   echo "File was not uploaded";die;
				}
				
			}
		}
	}

	public function saveLogoUrlAction(){
		$request = $this->getRequest();
        if($request->getPost('logoUrl')) {
            $appObj = new ApplicationController();
            $url = urldecode($request->getPost('logoUrl'));
            $sql=$appObj->returnQueryData("SELECT * FROM settings ORDER BY id DESC LIMIT 1");
		   	if($sql->count()>0){
			  	$appObj->executeQueries("UPDATE settings SET field2='".$url."'");
		   	}else{
			  	$appObj->executeQueries("INSERT INTO settings(field2) values('".$url."')"); 
		   	} 
		   	echo "1";die;
        }
	}

	public function saveDNSOptionAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
            $appObj = new ApplicationController();
            $chkBoxVal = trim($request->getPost('chkBoxVal'));
            if($chkBoxVal==1){
				$appObj->executeQueries("UPDATE tbl_hq_settings SET dns_settings=1");
			}else{
				$appObj->executeQueries("UPDATE tbl_hq_settings SET dns_settings=0");
			}
			echo 'success';die;
        }	
	}

	//Show template preview
	public function previewAction(){
		/*$viewModel = new \Zend\View\Model\ViewModel();
        $viewModel->setTerminal(true);
        return $viewModel;*/
        $this->layout('layout/landing');
		$indexObj = new IndexController();
		$returnData = $indexObj->indexAction();
        return $returnData;
	}

	//Create template preview
	public function showPreviewAction(){
        $request = $this->getRequest();
		if($request->isPost()){
			$homeTemplBody = $request->getPost('homeTemplBody');
            $tplPreviewFile = BASE_PATH.'/module/Webapp/view/webapp/home-page/preview.phtml';
			if(file_exists($tplPreviewFile)){		
				$myfile = fopen($tplPreviewFile, 'w') or die("error101");
				fwrite($myfile, $homeTemplBody);
				fclose($myfile);		
			}
			$content = '<style type="text/css">
						a, input[type=text], input[type=button]{
							pointer-events: none;
						}
						</style>';
			$myfile = fopen($tplPreviewFile, 'a') or die("error103");
			fwrite($myfile, $content);
			fclose($myfile);
			echo "success";die;
		}
	}

	public function saveTemplateAction(){
		$request = $this->getRequest();
		if($request->isPost()){
			$homeTemplBody = $request->getPost('homeTemplBody');
			//get tpl content
			$templateDir = BASE_PATH.'/module/Webapp/view/webapp/index/';
			$tplFile=$templateDir.'index.phtml';
			if(file_exists($tplFile)){		
				$myfile = fopen($tplFile, 'w') or die("error101");		
				fwrite($myfile, $homeTemplBody);
				fclose($myfile);		
			}else{
				$myfile = fopen($tplFile, 'w') or die("error102");
				$content = "";	
				fwrite($myfile, $homeTemplBody);
				fclose($myfile);	
			}
			echo "success";die;
		}
	}

	public function resetTemplateAction(){
		$appObj = new ApplicationController();
		$tplDefalutFile = BASE_PATH.'/module/Webapp/view/webapp/home-page/default.phtml';
		$tplFile = BASE_PATH.'/module/Webapp/view/webapp/index/index.phtml';
		$previewFile = BASE_PATH.'/module/Webapp/view/webapp/home-page/preview.phtml';
		if(file_exists($tplDefalutFile)){	
			$fileContents = file_get_contents($tplDefalutFile);
			if(file_exists($tplFile)){	
				$myfile = fopen($tplFile, 'w') or die("error101");		
				fwrite($myfile, $fileContents);
				$logo = BASE_PATH.'/public/img/Logo/logo.jpg';
				if(file_exists($logo)){
					unlink(BASE_PATH.'/public/img/Logo/logo.jpg');
				}
				if(file_exists($previewFile)){
					$myfile = fopen($previewFile, 'w') or die("error103");
					fwrite($myfile, $fileContents);
				}
				
				$appObj->executeQueries("UPDATE settings SET field2=''");
			}
			echo"1";die;
		}else{
			die('Default template error');
		}
	}

	//ajax call for colortheme
	public function saveColorThemesAction(){
		$appObj = new ApplicationController();
		$request = $this->getRequest();
		$myFile = DEST_PATH.'homecolortheme.json';
		if($request->isPost()){
			$topbar_bg = trim($request->getPost('topbar_bg'));
			$welcome_bg = trim($request->getPost('welcome_bg'));
			$searchbar_bg = trim($request->getPost('searchbar_bg'));
			$vialist_bg = trim($request->getPost('vialist_bg'));
			$footer_bg = trim($request->getPost('footer_bg'));
			$searchbar_vialisting=trim($request->getPost('searchbar_vialisting'));
			$install_mes_box=trim($request->getPost('install_mes_box'));
			$autoredirect_homepage=trim($request->getPost('autoredirect_homepage'));			
			$arr =array("topbar_bg_color"=>$topbar_bg,"welcome_bg_color"=>$welcome_bg,"searchbar_bg_color"=>$searchbar_bg,"vialist_bg_color"=>$vialist_bg,"footer_bg_color"=>$footer_bg,"searchbar_vialisting"=>$searchbar_vialisting,"install_mes_box"=>$install_mes_box,"autoredirect_homepage"=>$autoredirect_homepage);
			$jsonData = json_encode($arr,true);
			//encrypt json data		
			$encryptedJson = $appObj->desEncrypt($jsonData,POLL_ENCRYPTION_KEY);
			file_put_contents($myFile, $encryptedJson);
			//file_put_contents($myFile.'decrypt.json', $jsonData);	
			die;		
		}		
	}	

	//ajax call for reset colortheme
	public function resetColorThemesAction(){
		$appObj = new ApplicationController();
		$request = $this->getRequest();
		$myFile = DEST_PATH.'homecolortheme.json';
		if($request->isPost()){
			//reset logo to default
			$uploaddir =BASE_PATH.'/public/img/Logo/';	
			$images = glob($uploaddir . "*.*");
			foreach($images as $image)
			{
				unlink($image);
			}
			$appObj->executeQueries("UPDATE settings SET field2=''");
			//reset color theme			
			unlink($myFile);			
			echo 1;	
			die;
		}
	}
	
	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}
 
        
}
