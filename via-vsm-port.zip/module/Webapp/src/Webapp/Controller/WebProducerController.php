<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
use Webapp\Controller\ApplicationController;

Class WebProducerController extends AbstractActionController
{
	
	/*****
	 *	@Function Name		: rabbitMQConnectionAction
	 *  @description	    : Stablish the RabbitMQ Connection 
     *	@Author			    : Dileep
	 *  @Date               : 06-July-2020
	 *****/
	 
	public function rabbitMQConnectionAction(){
		$rabbitMQ_file=(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq")?"rabbitmqvsm.conf":"rabbitmq.conf";
		$reponseData = file_get_contents(DEST_PATH.$rabbitMQ_file);
		$appObj = new ApplicationController();
		$getRabbitMqDetail = json_decode($appObj->desDecrypt($reponseData,RABBIT_MQ_KEY_SEED));		
		$rabbitMqHost = $getRabbitMqDetail->hostname;
		$rabbitMqPort = $getRabbitMqDetail->nonsslport;
		$rabbitMqUsername = $getRabbitMqDetail->username;
		$rabbitMqPassword = $getRabbitMqDetail->password;
		$rabbitMqVhost = $getRabbitMqDetail->vhost;
		
		try{
			$connection = new AMQPStreamConnection(
			                        $rabbitMqHost,
									$rabbitMqPort,
									$rabbitMqUsername,
									$rabbitMqPassword,
									$rabbitMqVhost
						 );
			return $connection;
		}catch(Exception $e){
			echo "Error Message : ".$e->getMessage();
		}
	}
	
	/*****
	 *	@Function Name		: rabbitWebProducerAction
	 *  @description	    : Producer for queue
     *	@Author			    : Dileep
	 *  @Date               : 06-July-2020
	 *****/
	public function rabbitWebProducerAction($data){ 
		try{
			$bindingKey ="vsmserver"; // TO DO
			//get the connection object
			$connection = $this->rabbitMQConnectionAction();
			$channel = $connection->channel();
			$channel->exchange_declare("vsmserver", 'direct', false, false, false);
			$msg = new AMQPMessage($data);
			$channel->basic_publish($msg,"vsmserver", $bindingKey);
		    $channel->close();
		    $connection->close();
			
		}catch(Exception $e) {
			  echo 'Message: ' .$e->getMessage();
		}
	}


	public function rabbitWebProducerActionDss($data, $dataBind) {  
		try {
			//get the connection object
			$connection = $this->rabbitMQConnectionAction();
			$channel = $connection->channel();
			$channel->exchange_declare($dataBind["bindingKey"], 'direct', false, false, false);
			$msg = new AMQPMessage($data);
			$channel->basic_publish($msg, $dataBind["bindingKey"] , $dataBind["bindingKey"]);
		    $channel->close();
		    $connection->close();
			
		} catch(Exception $e) {
			  echo 'Message: ' .$e->getMessage();
		}
	}
	
	//using for sending data over rabbitmq with dynamic exchange and bindkey
	public function sentRabbitCmdWebProducerAction($data, $dataBind) {  
		try {
			//get the connection object
			$connection = $this->rabbitMQConnectionAction();
			$channel = $connection->channel();
			$channel->exchange_declare($dataBind["exchange_name"], 'direct', false, false, false);
			$msg = new AMQPMessage($data);
			$channel->basic_publish($msg, $dataBind["exchange_name"] , $dataBind["bindingKey"]);
		    $channel->close();
		    $connection->close();
			
		} catch(Exception $e) {
			  echo 'Message: ' .$e->getMessage();
		}
	}
	
	
}

?>