<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\NetworksettingsForm;
use Webapp\Form\ViaConfigurationForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Webapp\Form\ModeratorModeForm;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;

class ModeratorController extends AbstractActionController {
	//checking session
	public function onDispatch(MvcEvent $e) {
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['sessionTimeOut'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
		
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index', array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	public function viaAdsettingsAction() {
		//$this->layout('layout/login');	
		$form = new ModeratorModeForm();
		$checked =(FILE_CHKPRESENTATION_MODE == 1)? 'checked' : '';
		if(FILE_CHKPRESENTATION_MODE == 1) {
			$pmodeFileData = file_get_contents(DEST_PATH . 
											   READFILE_CHKPRESENTATION_MODE);
		}
		if(FILE_STROUGROUP == 1) {
			$file = DEST_PATH . READFILE_STROUGROUP;
			$arr = file_get_contents($file);
			$group_ou_fileVal = $arr[0];
		}
		if(FILE_STRADSETTINGS == 1) {
			$myfile = DEST_PATH . READFILE_STRADSETTINGS;
			$fp = fopen($myfile, "r");
			if($fp) {
				$myarr = array();

				while(!feof($fp)) {
					$fcontent = fgets($fp, filesize($myfile));
					if($fcontent != "") {
						array_push($myarr, $fcontent);
					}
				}
			}
			$var1 = $myarr[0];
			$var2 = $myarr[1];
			$var3 = $myarr[2];
			//$accfileVal=(trim($myarr[3])!='')?trim($myarr[3]):0;
			if($myarr[3] == '')
				$accfileVal = 0;
			else 
				$accfileVal = trim($myarr[3]);
		}
		$result = $this->getAdvanceConfigurationTable()->getParticipantCheckboxVal();

		foreach($result as $value) {
			$participantConfChkbox = $value->feature6;
			$pollConfig = $value->feature8;
		}
		$result = $this->getAdvanceMoreFeaturesTable()->getAdavnceMoreFeatures();

		foreach($result as $value) {
			$disableAllFeaturesChkboxVal = $value->ivalue;
		}
		$result = $this->getComplexPasswordTable()->fetchComplexPassword();

		foreach($result as $val) {
			$specialCharVal = $val->specialchar;
			$alphanumericVal = $val->alphanumeric;
			$capitalLtrVal = $val->capitalltr;
			$minCharVal = $val->minimumchar;
			$basicModeVal = $val->applyin_basicmode;
		}
		$chatFileVal = file_get_contents(DEST_PATH . 
										 FILE_CHAT_FILE);
		
		/********** Get Client Chat feature value. It will disable chat button enable or disabled*/
		$result = $this->getClientFeaturesTable()->getClientFeatures();

		foreach($result as $val) {
			$chatStatus = $val->feature_status;
		}
		
		/********** Get Mobile Chat feature value. It will disable chat button enable or disabled*/
		$result = $this->getMobileFeaturesTable()->getMobileFeatures();

		foreach($result as $val) {
			$mobileChatStatus = $val->feature_status;
		}
		
		/********** Get Gateway Chat feature value. It will disable chat button enable or disabled*/
		$result = $this->getGatewayFeaturesTable()->getGatewayFeatures();

		foreach($result as $val) {
			$gatewayChatStatus = $val->feature_status;
		}
		
		/***************getAuthSetting*******************/
		$result = $this->getHqConfigurationTable()->getAllHqConfig();

		foreach($result as $val) {
			$hq_AuthSetting = $val->HQ_AuthSetting;
		}
		$form->setData(array('presentationMode' => FILE_CHKPRESENTATION_MODE, 'file_strADSettings ' => FILE_STRADSETTINGS, 'file_strOUGroup' => FILE_STROUGROUP, 'pmodeFileData' => $pmodeFileData, 'checkPmode' => FILE_CHKPRESENTATION_MODE, 'participantConfChkbox' => $participantConfChkbox, 'pollTabVal' => $pollConfig, 'disableAllFeaturesChkbox' => $disableAllFeaturesChkboxVal, 'activatepolling' => $pollConfig, 'adDomain' => $var1, 'adModerator' => $var2, 'adParticipant' => $var3, 'accRadioBtn' => $accfileVal == "" ? 0 : $accfileVal, 'adRadioBtn' => $group_ou_fileVal, 'specialCharVal' => $specialCharVal, 'alphanumericVal' => $alphanumericVal, 'capitalLtrVal' => $capitalLtrVal, 'minCharVal' => $minCharVal, 'basicModeVal' => $basicModeVal, 'chatStatus' => $chatStatus, 'mobileChatStatus' => $mobileChatStatus, 'gatewayChatStatus' => $gatewayChatStatus, 'activateChatChkbox' => $chatFileVal, 'hq_AuthSetting' => $hq_AuthSetting));
		$viewmodel = new ViewModel(array('form' => $form));
		return $viewmodel;
	}
	
	
	
	/*****
	 *	@function Name			: serverConfigurationAjaxAction
	 *  @description	    : Using for  change moderator mode setting
	 *	@Author			    : Vineet
	 *  @Date               : 11-JAN-2010
	 *****/
	public function serverConfigurationAjaxAction() {
		$request = $this->getRequest();
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$msg = null;
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$checkBoxName = trim($data[0]);
			$checkBoxVal = trim($data[1]);
			if($checkBoxName == 'presentationMode') {
				$fileName = DEST_PATH . READFILE_CHKPRESENTATION_MODE;
				$OuGroupFile = DEST_PATH . READFILE_STROUGROUP;
				$adDbFile = DEST_PATH . READFILE_STRADSETTINGS;
				if($checkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = "1";
					$confWrite = fwrite($myfile, $content);
					$actionTaken = 'Activate';
					$this->getActivityLogMasterTable()->setActivity('su', $actionTaken, MSG_PRESENTATION_MODEBY, $hostname);
					$msg = true;
				} else {
					unlink($fileName);
					if(file_exists($OuGroupFile)) {
						unlink($OuGroupFile);
					}
					if(file_exists($adDbFile)) {
						unlink($adDbFile);
					}
				}
				unlink(DEST_PATH . 
					   FILE_CHAT_FILE);
				$result = $this->getAdvanceConfigurationTable()->updateAdvanceConfiguration(null, $checkBoxName);
				$result = $this->getAdvanceMoreFeaturesTable()->updateMoreFeatures(0, 'ModFeatEnable');
				if($result == 0 || $result == 1)
					$msg = true;
				$actionTaken = 'Deactivate';
				$this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PRESENTATION_MODEBY, $hostname);
			}
			if($checkBoxName == 'appendPresentationMode') {
				$fileName = DEST_PATH . READFILE_CHKPRESENTATION_MODE;
				if($checkBoxVal == 3) {
					$result = $this->getAdvanceMoreFeaturesTable()->updateMoreFeatures(0, 'ModFeatEnable');
				}
				if(file_exists($fileName)) {
					unlink($fileName);
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $checkBoxVal;
					$confWrite = fwrite($myfile, $content);
					$msg = true;
				}
			}
			if($checkBoxName == 'deleteAuthenticationFiles') {
				$fileName1 = DEST_PATH . READFILE_STROUGROUP;
				$fileName2 = DEST_PATH . READFILE_STRADSETTINGS;
				if(file_exists($fileName1)) {
					unlink($fileName1);
					$msg = true;
				}
				if(file_exists($fileName2)) {
					unlink($fileName2);
					$msg = true;
				}
			}
			if($checkBoxName == 'participantConfChkbox') {
				$result = $this->getAdvanceConfigurationTable()->updateAdvanceConfiguration($checkBoxVal, $checkBoxName);
				if($result == 0 || $result == 1)
					$msg = true;
				$actionTaken =($chkBoxVal == 1)? 'Activate' : 'Deactivate';
				$this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, MSG_PRESENTATION_BY, $hostname);
			}
			if($checkBoxName == 'disableAllFeaturesChkbox') {
				$ivalue = $checkBoxVal;
				$property_name = 'ModFeatEnable';
				$result = $this->getAdvanceMoreFeaturesTable()->updateMoreFeatures($ivalue, $property_name);
				if($result == 0 || $result == 1)
					$actionTaken =($checkBoxVal == 1)? 'Activate' : 'Deactivate';
				$this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, 'All features disabled by', $hostname);
				$msg = true;
			}
			if($checkBoxName == 'activateChatChkbox') {
				$fileName = DEST_PATH . FILE_CHAT_FILE;
				if($checkBoxVal == 1) {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $checkBoxVal;
					$confWrite = fwrite($myfile, $content);
				} else {
					if(file_exists($fileName)) {
						unlink($fileName);
					}
				}
				$this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_CHAT_BY, $hostname);
				$msg = true;
			}
			return new JsonModel(array('status' => $msg));
		}
	}
	
	/*****
	 *	@function Name			: advanceConfigurationSettingAction
	 *  @description	    : Using for  change activate ePolling
	 *	@Author			    : Vineet
	 *  @Date               : 11-JAN-2010
	 *****/
	public function advanceConfigurationSettingAction() {
		$request = $this->getRequest();
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$selChkBoxName = $data[0];
			$checkBoxVal = $data[1];
			if($selChkBoxName == 'setPollingConfiguration') {
				$result = $this->getAdvanceConfigurationTable()->updateAdvanceConfiguration($checkBoxVal, $selChkBoxName);
				if($result == 0 || $result == 1)
					$actionTaken =($checkBoxVal == 1)? 'Activate' : 'Deactivate';
				$this->getActivityLogMasterTable()->setActivity($loginName, $actionTaken, STR_POLL_BY, $hostname);
				$msg = true;
			}
			return new JsonModel(array('status' => $loginName));
		}
	}
	
	/*****
	 *	@function Name			: applyPassBasicModeAction
	 *  @description	    : Using for  change activate ePolling
	 *	@Author			    : Vineet
	 *  @Date               : 11-JAN-2010
	 *****/
	public function applyPassBasicModeAction() {
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$pass = $request->getPost('pass');
			$result = $this->getBasicAuthenticationTable()->updateInsertAuthentication($pass);
			if($result == 0 || $result == 1)
				$msg = true;
			return new JsonModel(array('status' => $msg));
		}
	}
	
	/*****
	 *	@function Name	: serverConfigurationAdSetting
	 *  @description	    : Using for  apply active directory setting
	 *	@Author			    : Vineet
	 *  @Date               : 17-JAN-2010
	 *****/
	public function serverConfigurationAdSettingAction() {
		$request = $this->getRequest();
		$msg = "";
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$selChkBoxName = $data[0];
			if($selChkBoxName == 'applyADSettings') {
				$record = explode(",", $data[1]);
				$adDomain = $record[0];
				$adModerator = $record[1];
				$adParticipant = $record[2];
				$accRadioBtnval = $record[3];
				$grp_OuBased = $record[4];
				if($adDomain == '' || $adModerator == '' || $adParticipant == '' || $grp_OuBased == 0) {
					$msg = "validationerror";
				} else {
					$fileName = DEST_PATH . READFILE_STRADSETTINGS;
					$newStr = $adDomain . "\r\n" . $adModerator . "\r\n" . $adParticipant . "\r\n" . $accRadioBtnval;
					//$logqry=mysql_query("insert into ActivityLogMaster(UserID,ActionTaken,ActivityDate,remarks,hostname) values('$name','Apply',now(),'$logMsgADSettings $name','$hostname')") or die('error_sca24');			
					if(file_exists($fileName)) {
						unlink($fileName);
						$myfile = fopen($fileName, 'w')or die("can't open file");
						$content = $newStr;
						$confWrite = fwrite($myfile, $content);
						$msg = true;
					} else {
						$myfile = fopen($fileName, 'w')or die("can't open file");
						$content = $newStr;
						$confWrite = fwrite($myfile, $content);
						$msg = true;
					}
				}
			}
			return new JsonModel(array('status' => $msg));
		}
	}
	
	/*****
	 *	@function Name	: groupOuBassedSetting
	 *  @description	    : change group/ou based setting
	 *	@Author			    : Vineet
	 *  @Date               : 17-JAN-2010
	 *****/
	public function groupOuBassedSettingAction() {
		$request = $this->getRequest();
		$msg = "";
		if($request->isXmlHttpRequest()) {
			$data = $request->getPost('data');
			$checkBoxName = trim($data[0]);
			$checkBoxVal = trim($data[1]);
			if(($checkBoxName == 'groupBased')||($checkBoxName == 'ouBased')) {
				$fileName = DEST_PATH . READFILE_STROUGROUP;
				if(file_exists($fileName)) {
					unlink($fileName);
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $checkBoxVal;
					$confWrite = fwrite($myfile, $content);
					$msg = true;
				} else {
					$myfile = fopen($fileName, 'w')or die("can't open file");
					$content = $checkBoxVal;
					$confWrite = fwrite($myfile, $content);
					$msg = true;
				}
			}
			return new JsonModel(array('status' => $msg));
		}
	}
	
	/*****
	 *  @description	    : get all tables
	 *	@Author			    : Vineet
	 *  @Date               : 17-JAN-2010
	 *****/

	public function getBasicAuthenticationTable() {
		if(!$this->TblBasicAuthenticationTable) {
			$sm = $this->getServiceLocator();
			$this->TblBasicAuthenticationTable = $sm->get('Webapp\Model\TblBasicAuthenticationTable');
		}
		return $this->TblBasicAuthenticationTable;
	}

	public function getComplexPasswordTable() {
		if(!$this->TblComplexPasswordTable) {
			$sm = $this->getServiceLocator();
			$this->TblComplexPasswordTable = $sm->get('Webapp\Model\TblComplexPasswordTable');
		}
		return $this->TblComplexPasswordTable;
	}

	public function getClientFeaturesTable() {
		if(!$this->TblClientsFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
		}
		return $this->TblClientsFeaturesTable;
	}

	public function getMobileFeaturesTable() {
		if(!$this->TblMobileFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblMobileFeaturesTable = $sm->get('Webapp\Model\TblMobileFeaturesTable');
		}
		return $this->TblMobileFeaturesTable;
	}

	public function getGatewayFeaturesTable() {
		if(!$this->TblGatewayFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblGatewayFeaturesTable = $sm->get('Webapp\Model\TblGatewayFeaturesTable');
		}
		return $this->TblGatewayFeaturesTable;
	}

	public function getHqConfigurationTable() {
		if(!$this->TblHqConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblHqConfigurationTable = $sm->get('Webapp\Model\TblHqConfigurationTable');
		}
		return $this->TblHqConfigurationTable;
	}
	//Ranjan
	public function getActivityLogMasterTable() {
		if(!$this->TblActivityLogMasterTable) {
			$sm = $this->getServiceLocator();
			$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
		}
		return $this->TblActivityLogMasterTable;
	}

	public function getClientsFeaturesTable() {
		if(!$this->TblClientsFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
		}
		return $this->TblClientsFeaturesTable;
	}

	public function getDisplaySettingsTable() {
		if(!$this->TblDisplaySettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblDisplaySettingsTable = $sm->get('Webapp\Model\TblDisplaySettingsTable');
		}
		return $this->TblDisplaySettingsTable;
	}

	public function getTimezonesTable() {
		if(!$this->TblTimezonesTable) {
			$sm = $this->getServiceLocator();
			$this->TblTimezonesTable = $sm->get('Webapp\Model\TblTimezonesTable');
		}
		return $this->TblTimezonesTable;
	}

	public function getAdvanceConfigurationTable() {
		if(!$this->TblAdvanceConfigurationTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationTable = $sm->get('Webapp\Model\TblAdvanceConfigurationTable');
		}
		return $this->TblAdvanceConfigurationTable;
	}

	public function getAdvanceMoreFeaturesTable() {
		if(!$this->TblAdvanceMoreFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceMoreFeaturesTable = $sm->get('Webapp\Model\TblAdvanceMoreFeaturesTable');
		}
		return $this->TblAdvanceMoreFeaturesTable;
	}

	public function getAuthFileFormatTable() {
		if(!$this->TblAuthFileFormatTable) {
			$sm = $this->getServiceLocator();
			$this->TblAuthFileFormatTable = $sm->get('Webapp\Model\TblAuthFileFormatTable');
		}
		return $this->TblAuthFileFormatTable;
	}

	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}

	public function getStreamingSettingsTable() {
		if(!$this->TblStreamingSettingsTable) {
			$sm = $this->getServiceLocator();
			$this->TblStreamingSettingsTable = $sm->get('Webapp\Model\TblStreamingSettingsTable');
		}
		return $this->TblStreamingSettingsTable;
	}

	public function getRecordingTransferTable() {
		if(!$this->TblRecordingTransferTable) {
			$sm = $this->getServiceLocator();
			$this->TblRecordingTransferTable = $sm->get('Webapp\Model\TblRecordingTransferTable');
		}
		return $this->TblRecordingTransferTable;
	}

	public function getProxySettingTable() {
		if(!$this->TblProxySettingTable) {
			$sm = $this->getServiceLocator();
			$this->TblProxySettingTable = $sm->get('Webapp\Model\TblProxySettingTable');
		}
		return $this->TblProxySettingTable;
	}

	public function getTemplatesTable() {
		if(!$this->TblTemplatesTable) {
			$sm = $this->getServiceLocator();
			$this->TblTemplatesTable = $sm->get('Webapp\Model\TblTemplatesTable');
		}
		return $this->TblTemplatesTable;
	}

	public function getFeatureTempTable() {
		if(!$this->TblFeatureTempTable) {
			$sm = $this->getServiceLocator();
			$this->TblFeatureTempTable = $sm->get('Webapp\Model\TblFeatureTempTable');
		}
		return $this->TblFeatureTempTable;
	}

	public function getTblGatewayFeaturesTable() {
		if(!$this->TblGatewayFeaturesTable) {
			$sm = $this->getServiceLocator();
			$this->TblGatewayFeaturesTable = $sm->get('Webapp\Model\TblGatewayFeaturesTable');
		}
		return $this->TblGatewayFeaturesTable;
	}

	public function getTblGatewayFeaturesPositionTable() {
		if(!$this->TblGatewayFeaturesPositionTable) {
			$sm = $this->getServiceLocator();
			$this->TblGatewayFeaturesPositionTable = $sm->get('Webapp\Model\TblGatewayFeaturesPositionTable');
		}
		return $this->TblGatewayFeaturesPositionTable;
	}
}
