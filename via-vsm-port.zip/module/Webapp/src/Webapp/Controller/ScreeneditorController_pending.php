<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Form\ScreeneditorForm;
use Webapp\Validator\ServicesValidator;
use ZipArchive;
use Webapp\Controller\WebProducerController;

class ScreeneditorController extends AbstractActionController {	
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		if(PRODUCT=='via' || PRODUCT=='kds'){
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT sessionTimeOut FROM tbl_session_settings ORDER BY id DESC LIMIT 1");
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		}
		
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if($tblSessionCheckdataArr->count()>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	/*****
	 *	@Class Name			: templateListAction
	 *  @description	    : Using for template list                     
	 *	@Author			    : Ashu
	 *  @Date               : 13-Feb-2020
	 *****/ 	
	public function templateListAction(){	
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');		
		$form = new ScreeneditorForm();
		$request = $this->getRequest();
		if($request->isPost()){
			$template = trim($request->getPost('wallpaperSearchBox'));
			$form->setData($request->getPost());
		}
		//Fix security issue if anyone post query
		if( isset($_GET['time']) && (!is_numeric($_GET['time']) || $_GET['time'] <= 0 || strstr($_GET['time'],'select') || strstr($_GET['time'],'and') || strstr($_GET['time'],'or')) ){			
				die('Invalid request');			
		}

		$data=$this->getTemplatesTable()->fetchAll($template);
		//pagination code
		$data->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
		$data->setItemCountPerPage(50);		
		$tblHQConfigurationData=$appObj->getTableAllData('tbl_hq_configuration');
		foreach($tblHQConfigurationData as $hqConfigData){
			$wallpaperSettingVal= $hqConfigData['hq_wallpapersetting'];
		}		
		if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
			$result = $this->getDevicegroupTable()->fetchAll();
			$arrayCategories = array();
			foreach($result as $row){
				$arrayCategories[$row->DeviceGroupID] = array("grp_id" => $row->DeviceGroupID, "parent_id" => $row->DeviceMasterID, "name" =>$row->DeviceGroup, "level" =>$appObj->getDepth($row->DeviceGroupID));   
			}
			$user_grp_arr=array();
			if($user_id !=1){
				$deviceGroup = $this->getDevicegroupTable()->getGroupWithPermission($user_id);
			}
		}
		//Get groups with already set template
		if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
			$assignedGroupSql = $appObj->returnQueryData("SELECT B.DeviceGroup FROM tbl_templates_mapping A INNER JOIN DeviceGroup B ON A.isGrpIdOrDeviceId=B.DeviceGroupID AND A.template_id<>1");
			foreach ($assignedGroupSql as $key => $value) {
				$assignedGroup[] = $value['DeviceGroup'];
			}
		}else{
			$assignedGroup=array();
		}
		
		$tblHQConfigurationData=$appObj->getTableAllData('tbl_hq_configuration');
		foreach($tblHQConfigurationData as $hqConfigData){
			$wallpaperSettingVal=$hqConfigData['hq_wallpapersetting'];
		}
	    $viewmodel = new ViewModel(array(
			'data'=>$data,
			'wallpaperSettingVal'=>$wallpaperSettingVal,
			'arrayCategories'=>$arrayCategories,
			'deviceGroup'=>$deviceGroup,
			'assignedGroup'=>$assignedGroup,
			'form' => $form,
		));
		return $viewmodel;
	}

	public function templateDesignAction(){
		$this->layout('layout/template');
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$session->offsetSet('templatename', '');
		$opacityArr=array(10,20,30,40,50,60,70,80,90,100);
		$utype=$session->offsetGet('utype');
		$iconPath=OLD_URL.'images/'.$session->offsetGet('modelContent');
		$getImageWidth=1920;
		$getImageHeight=1080;
		$gethcf=$appObj->gethcf($getImageWidth , $getImageHeight);
		$getAspectRaio=($getImageHeight/$gethcf).'/'.($getImageWidth/$gethcf);
		//getting float value of aspect ratio
		$getRatioDecimalVal=number_format(($getImageWidth/$gethcf)/($getImageHeight/$gethcf),2);

		$screenwidth = $session->offsetGet('screenwidth');
		if($screenwidth < 1366){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt');
		}else if($screenwidth >= 1366 && $screenwidth < 1920){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt');
		}else if($screenwidth >= 1920 && $screenwidth < 2560){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt','50px'=>'50 pt','52px'=>'52 pt','54px'=>'54 pt','56px'=>'56 pt','58px'=>'58 pt','60px'=>'60 pt','62px'=>'62 pt','64px'=>'64 pt','66px'=>'66 pt','68px'=>'68 pt','70px'=>'70 pt','72px'=>'72 pt');
		}else if($screenwidth >= 2560 && $screenwidth < 3240){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt','50px'=>'50 pt','52px'=>'52 pt','54px'=>'54 pt','56px'=>'56 pt','58px'=>'58 pt','60px'=>'60 pt','62px'=>'62 pt','64px'=>'64 pt','66px'=>'66 pt','68px'=>'68 pt','70px'=>'70 pt','72px'=>'72 pt','74px'=>'74 pt','76px'=>'76 pt','78px'=>'78 pt','80px'=>'80 pt','82px'=>'82 pt','84px'=>'84 pt','86px'=>'86 pt','88px'=>'88 pt','90px'=>'90 pt','92px'=>'92 pt','94px'=>'94 pt','96px'=>'96 pt','98px'=>'98 pt','100px'=>'100 pt','102px'=>'102 pt','104px'=>'104 pt','106px'=>'106 pt','108px'=>'108 pt','110px'=>'110 pt','112px'=>'112 pt','114px'=>'114 pt','116px'=>'116 pt','118px'=>'118 pt','120px'=>'120 pt','122px'=>'122 pt','124px'=>'124 pt','126px'=>'126 pt','128px'=>'128 pt','130px'=>'130 pt','132px'=>'132 pt','134px'=>'134 pt','136px'=>'136 pt','138px'=>'138 pt','140px'=>'140 pt','142px'=>'142 pt','144px'=>'144 pt','146px'=>'146 pt','148px'=>'148 pt','150px'=>'150 pt','152px'=>'152 pt','154px'=>'154 pt','156px'=>'156 pt','158px'=>'158 pt');
		}else if($screenwidth > 3240){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt','50px'=>'50 pt','52px'=>'52 pt','54px'=>'54 pt','56px'=>'56 pt','58px'=>'58 pt','60px'=>'60 pt','62px'=>'62 pt','64px'=>'64 pt','66px'=>'66 pt','68px'=>'68 pt','70px'=>'70 pt','72px'=>'72 pt','74px'=>'74 pt','76px'=>'76 pt','78px'=>'78 pt','80px'=>'80 pt','82px'=>'82 pt','84px'=>'84 pt','86px'=>'86 pt','88px'=>'88 pt','90px'=>'90 pt','92px'=>'92 pt','94px'=>'94 pt','96px'=>'96 pt','98px'=>'98 pt','100px'=>'100 pt','102px'=>'102 pt','104px'=>'104 pt','106px'=>'106 pt','108px'=>'108 pt','110px'=>'110 pt','112px'=>'112 pt','114px'=>'114 pt','116px'=>'116 pt','118px'=>'118 pt','120px'=>'120 pt','122px'=>'122 pt','124px'=>'124 pt','126px'=>'126 pt','128px'=>'128 pt','130px'=>'130 pt','132px'=>'132 pt','134px'=>'134 pt','136px'=>'136 pt','138px'=>'138 pt','140px'=>'140 pt','142px'=>'142 pt','144px'=>'144 pt','146px'=>'146 pt','148px'=>'148 pt','150px'=>'150 pt','152px'=>'152 pt','154px'=>'154 pt','156px'=>'156 pt','158px'=>'158 pt','160px'=>'160 pt','162px'=>'162 pt','164px'=>'164 pt','166px'=>'166 pt','168px'=>'168 pt','170px'=>'170 pt','172px'=>'172 pt','174px'=>'174 pt','176px'=>'176 pt','178px'=>'178 pt','180px'=>'180 pt','182px'=>'182 pt','184px'=>'184 pt','186px'=>'186 pt','188px'=>'188 pt','190px'=>'190 pt','192px'=>'192 pt','194px'=>'194 pt','196px'=>'196 pt','198px'=>'198 pt','200px'=>'200 pt','202px'=>'202 pt','204px'=>'204 pt','206px'=>'206 pt','208px'=>'208 pt','210px'=>'210 pt','212px'=>'212 pt','214px'=>'214 pt');
		}
		$fontSizeOpt='';
		foreach($fontsizeArray as $k=>$v){
			if($k=='18px') $sel='selected';
			else $sel='';
			$fontSizeOpt.='<option value='.$k.' '.$sel.'>'.$k.'</option>';
		}
			
		$textalignArray=array('left'=>'Left','right'=>'Right','vertical'=>'Center');
		$txtAlignArrOpt='';
		foreach($textalignArray as $k=>$v){
			$txtAlignArrOpt.='<option value='.$k.'>'.$v.'</option>';
		}
		
		$opacityArrOpt='';		
		foreach($opacityArr as $key=>$val){
			$opacityArrOpt.='<option value='.($val/100).'>'.$val.'%'.'</option>';
		}
		
		$roomcodepopupFontsize='48px';
		if($screenwidth < 1920){	
			$roomcodepopupFontsize='42px';
				$setResolutionFontCodepopup=48;
		}elseif($screenwidth >= 1920 && $screenwidth < 2560){
				$roomcodepopupFontsize='48px';
				$setResolutionFontCodepopup=72;
		}elseif($screenwidth >= 2560 && $screenwidth < 3240){
			$roomcodepopupFontsize='72px';
			$setResolutionFontCodepopup=158;
		}else{
			$roomcodepopupFontsize='158px';
			$setResolutionFontCodepopup=220;
		}
		$custTempName=$appObj->getNexttemplateName(); 
		//getting templates data
		$wallSql=$appObj->returnQueryData('SELECT wallpaper_name FROM tbl_templates');
		$fetchTblHqInfoDataArr=$appObj->getTableAllData('tbl_hq_configuration');
		foreach($fetchTblHqInfoDataArr as $fetchTblHqInfoData){
			$configSettingVal=$fetchTblHqInfoData['hq_configsetting'];
		}
		if(PRODUCT=='via'){
			$file_roomnamevalueshow=$appObj->returnRoomNameValue();
			$fetchConfigDataArr=$appObj->getTableAllData('tbl_display_settings');
			foreach($fetchConfigDataArr as $fetchConfigData){
				$check_readfile_ipadd1=file_exists(DEST_PATH.READFILE_IPADD1)?$appObj->file_read(DEST_PATH.READFILE_IPADD1):'';
				$activate_RoomName2_DNS=($fetchConfigData['field3']!='')?trim($fetchConfigData['field3']):trim($check_readfile_ipadd1);
				$getCustomRoomname2=trim($fetchConfigData['field3']);
			}
		}else{
			$file_roomnamevalueshow='(VIA IP 1)';
			$activate_RoomName2_DNS='(VIA IP 2)';
		}
		return new ViewModel(
			array(
				'fontsizeArray'=>$fontsizeArray,
				'fontSizeOpt'=>$fontSizeOpt,
				'textalignArray'=>$textalignArray,
				'txtAlignArrOpt'=>$txtAlignArrOpt,
				'opacityArr'=>$opacityArr,
				'opacityArrOpt'=>$opacityArrOpt,
				'getAspectRaio'=>$getAspectRaio,
				'getRatioDecimalVal'=>$getRatioDecimalVal,
				'wallSql'=>$wallSql,
				'custTempName'=>$custTempName,
				'configSettingVal'=>$configSettingVal,
				'file_roomnamevalueshow'=>$file_roomnamevalueshow,
				'activate_RoomName2_DNS'=>$activate_RoomName2_DNS
			)
		);
	}
	
	//ajaxcall to upload wallpaper
	public function uploadgwaywallpaperAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		if($session->offsetGet('time')==''){	
			$session->offsetSet('time',time());
		}
		//$newimgDir=PUBLIC_URL.'/uploads/';
		$newimgDir=WEB_DATA_PATH.'/'.IMG_DIR;		
		$name=$session->offsetGet('LoginName');	
		$hostname=$_SERVER['REMOTE_ADDR'];
		$time = time();
		$utype=$session->offsetGet('utype');
		if($_GET['state']=='mainImage'){			
			if($_FILES['file']['tmp_name']!=''){
			 	$arrImgInfo = getimagesize($_FILES['file']['tmp_name']);
				//getting aspect ratio
				$getImageWidth=$arrImgInfo[0];
				$getImageHeight=$arrImgInfo[1];
				$gethcf=$appObj->gethcf($getImageWidth , $getImageHeight);
				$getAspectRaio=($getImageWidth/$gethcf).':'.($getImageHeight/$gethcf);
				// end code for asect ratio	
				$imgsize=round(filesize($_FILES['file']['tmp_name'])/1024,2);
				$getUploadImgType=image_type_to_extension($arrImgInfo[2]);
				if($imgsize>4000){
					echo"sizeerror"; 
					exit;
				}
				$file_ext = $appObj->getfileType($arrImgInfo['mime']);	 
				 if($file_ext == 'jpeg'){
					$file_ext = 'jpg';
				}	
				$function = $appObj->returnCorrectFunction($file_ext);
				$tempImageLocation="";	//echo BASE_PATH;die;		
				//$uploaddir=BASE_PATH.'/public/uploads/large/';
				$uploaddir=HTML_PUBLIC_DIR.'/uploads/large/';
				
				$custImage=(isset($session['custtempImage']) && $session['custtempImage']!='')?$session->offsetGet('custtempImage'):$time.'.'.$file_ext;	
				$tempImageLocation = $newimgDir.'large/'.$custImage;
				if($session->offsetGet('uploadtempfile')==''){					
					$session->offsetSet('uploadtempfile', $uploaddir.$session->offsetGet('custtempImage'));
				}else{					
					$session->offsetSet('uploadtempfile','');
				}			
				move_uploaded_file($_FILES['file']['tmp_name'], $uploaddir.$custImage);	
				if(GET_OS=='WIN'){
					if($file_ext=='gif' || $file_ext=='png'){
						$originalFile=$uploaddir.$custImage;
						$exploded = explode('.',$custImage);
						$imgNa=$exploded[0];
						$ext=$exploded[1];    		
						$outputFile=$uploaddir.$imgNa.".jpg";			
						$appObj->convertImage($originalFile, $outputFile, 100);
						$custImage=$imgNa.".jpg";
						$file_ext = 'jpg';
						unlink($originalFile);
					}
				}else{
					if($file_ext=='gif' || $file_ext=='jpg'){
						$originalFile=$uploaddir.$custImage;
						$exploded = explode('.',$custImage);
						$imgNa=$exploded[0];
						$ext=$exploded[1];    		
						$outputFile=$uploaddir.$imgNa.".png";			
						$appObj->convertImagePNG($originalFile, $outputFile, 100);
						$custImage=$imgNa.".png";
						$file_ext = 'png';
						unlink($originalFile);
					}
				}
				$session->offsetSet('uploadtempfile', IMG_DIR.'large/'.$custImage);
				$returnImage=$newimgDir.'large/'.$custImage;
			}
			echo $returnImage.'#'.$getAspectRaio.'#'.$getImageWidth.'#'.$getImageHeight;	
		}
		die;
	}
	
	//ajax call when click on wallpaper to set
	public function setWallpaperAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		if($session->offsetGet('time')==''){	
			$session->offsetSet('time',time());
		}
		//$newimgDir=PUBLIC_URL.'/'.IMG_DIR;
		$newimgDir=WEB_DATA_PATH.'/'.IMG_DIR;
		$utype=$session->offsetGet('utype');
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$state = trim($request->getPost('state'));
			if($state=='mainImage'){
				$file = UPLOAD_DIR_ZEND.trim($request->getPost('file'));
				if($file!=''){
					$arrImgInfo = getimagesize($file);
					$getImageWidth=$arrImgInfo[0];
					$getImageHeight=$arrImgInfo[1];
					$gethcf=$appObj->gethcf($getImageWidth , $getImageHeight);
					$getAspectRaio=($getImageWidth/$gethcf).':'.($getImageHeight/$gethcf);
					// end code for asect ratio	
					$imgsize=round(filesize($file)/1024,2);
					$getUploadImgType=image_type_to_extension($arrImgInfo[2]);
					
					$file_ext =$appObj->getfileType($arrImgInfo['mime']);		 
					 if($file_ext == 'jpeg'){
						$file_ext = 'jpg';
					}		
					$file_init = pathinfo($file, PATHINFO_FILENAME);
					$function = $appObj->returnCorrectFunction($file_ext);
					$tempImageLocation="";
					$uploaddir =BASE_PATH.'/public/'.IMG_DIR.'large/';	
					$custImage=$file_init.'.'.$file_ext;
					$tempImageLocation = $newimgDir.'large/'.$custImage;				
					$session->offsetSet('uploadtempfile',IMG_DIR.'large/'.$custImage);				
					$returnImage=$newimgDir.'large/'.$custImage;
				}
				echo $returnImage.'#'.$getAspectRaio.'#'.$getImageWidth.'#'.$getImageHeight;die;
			}
		}	
	}
	
	public function addcustomTemplatenameAction(){
		$this->layout('layout/template');
		$appObj = new ApplicationController();
		$session = new Container('userinfo');	
		/*$qryArr=$appObj->returnQueryData("SELECT `AUTO_INCREMENT` FROM  INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '".DB_NAME."' AND   TABLE_NAME   = 'tbl_templates'")->current();
		$tblAutoIncreamentNo=$qryData['AUTO_INCREMENT'];*/
		/*$qryArr=$appObj->returnQueryData("SELECT nextval('tbl_templates_id_seq') as auto_increment")->current();  
		$tblAutoIncreamentNo=$qryArr['auto_increment'];*/

		if($session->offsetGet('templatename')==''){
			$template_name=$appObj->getNexttemplateName();			
			$session->offsetSet('templatename',$template_name);	
		
		}
		if(isset($_GET['action']) && $_GET['action']=='saveas'){
			$template_name=$this->getUniqueName($session->offsetGet('templatename'));
			$session->offsetSet('templatename',$template_name);	
		}
	}
	
	public function showLayoutDetailsAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$tempid = str_replace(' ','+',trim($request->getPost('tempid')));
			$counter=0;
			$grpArray=array();
			$sql=$appObj->returnQueryData("SELECT A.isGrpIdOrDeviceId,A.template_id,A.entryType FROM tbl_templates_mapping A INNER JOIN DeviceGroup B ON A.isGrpIdOrDeviceId = B.DeviceGroupID WHERE A.template_id=$tempid");
			if($sql->count() >0){  
				foreach($sql as $row){
					$counter++;
					$grpArray[] = $row['isGrpIdOrDeviceId'];
					$layout = $this->getTemplatesTable()->getData(array('id'=>$tempid))->current();
					if($row['entryType']==0){
						$seGrpQry=$appObj->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroupID=".$row['isGrpIdOrDeviceId']);
						$deviceOrGrpName='';
						if($seGrpQry->count()>0){
							$resultRow=$seGrpQry->current();
							$deviceOrGrpName=$resultRow['DeviceGroup'];
						}
					}
				}
			}
			
			$grpArray = array_unique($grpArray);
			if(count($grpArray)>0){
				$response .= '<div style="height:30px; color:#000000"><h4>Group Information</h4></div><table  class="table teble-responsive"> 
				<th align="left">'.STR_LOCATION_NAME.'&nbsp;</th>';
				foreach($grpArray as $grpId=>$val){
						$seGrpQry=$appObj->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroupID=".$val);
						$GrpName='';
						if($seGrpQry->count()>0){
							$resultRow=$seGrpQry->current();
							$GrpName=$resultRow['DeviceGroup'];
						}
						$response .= '<tr>					
							<td>'.$GrpName.'</td>';
				}//end of foreach
				$response .= '</table>';
			}
			
			if(count($grpArray)==0){
				$response .= '<table  class="table table-responsive">	
				<th  width="100%" align="left">'.STR_LOCATION_NAME.'&nbsp;</th>  
				<tr><td align="center">'.MSG_NO_RECORD_FOUND.'</td></tr>
			</table>';
			}
			$response .= '<hr class="devider m-t-n-md">';
			echo $response;die;
		}
	}

	//ajax call when enter custom name
	public function addCustomTemplateNameAjaxAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		if($session->offsetGet('LoginName')==''){
			echo 'sessionout';
			exit;
		}
		
		$custTempName = htmlspecialchars(trim($_POST['custTempName']));
		$session->offsetSet('templatename',$custTempName);		
		$selQry =$appObj->getTableAllData("tbl_templates WHERE template_name ILIKE '".$custTempName."'");
		if(count($selQry)==0){
			echo 'ok';exit;
		}else{
			echo"exists";exit;
		}
	}
	
	public function saveTemplateDataAjaxAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$name = $session->offsetGet('LoginName');
			$currentWallpaper=$session->offsetGet('uploadtempfile');
			//get crsf value from session
			$session_crsf_token=$session->offsetGet('crsf_token');			
			$jsonValue=json_decode(str_replace('alert(',"",$request->getPost('templatejson')));
			$gridVal=trim($request->getPost('gridChkVal'));
			$screenwidth=trim($request->getPost('screenwidth'));
			$screenheight=trim($request->getPost('screenheight'));
			$getclickbtnId=trim($request->getPost('getclickbtnId'));
			$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			
			$templatename=trim($session->offsetGet('templatename'));
			$explodeImageBySlash=explode('/',$currentWallpaper);
			$explodeImageByDot=explode('.',$currentWallpaper);
			$imgExt='.'.$explodeImageByDot[1];
			//$getImageName = BASE_PATH.'/public/'.IMG_DIR.'large/'.$templatename.$imgExt;
			$getImageName=UPLOAD_DIR_ZEND.IMG_DIR.'large/'.$templatename.$imgExt;
			$getImageNameForDB = IMG_DIR.'large/'.$templatename.$imgExt;
			copy(UPLOAD_DIR_ZEND.$session->offsetGet('uploadtempfile'),$getImageName);
			$session->offsetSet('uploadtempfile',$getImageNameForDB);
			//wallpaper
			$wallpaperJson=array('imagePath'=>$getImageNameForDB,'width'=>intval($screenwidth),'height'=>intval($screenheight),'gridvalue'=>$gridVal);
			$jsonValue->wallpaper=(object)$wallpaperJson;
			$json_templateName = time().'.json';
			//roomname 1
			if(isset($jsonValue->roomname1)){	
				//chnage on 15/01/2019. if roomname is blank then delete roomnamevalueshow.txt file
				$filePath=DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
				$roomNameCustomIP=$jsonValue->roomname1->customNameText;
				//added on 1stJuly22. Now we are moving custom name to via settings
/*				if($roomNameCustomIP!=''){
					// check added on 15/01/2019 if $roomNameCustomIP is not equal to ipadd.txt file content then write value of roomNameCustomIP in roomnamevalueshow.txt otherwise not		
					if(trim($appObj->file_read(DEST_PATH.READFILE_IPADD))!=trim($roomNameCustomIP)){			
						if(file_exists($filePath)){
							unlink($filePath);
							$myfile = fopen($filePath, 'w') or die("can't open file");
							$content = $roomNameCustomIP;	
							$confWrite= fwrite($myfile, $content);
						}else{
							$myfile = fopen($filePath, 'w') or die("can't open file");
							$content = $roomNameCustomIP;	
							$confWrite= fwrite($myfile, $content);
						}
						//upgrade setting json when upgrade dnsname
						if(PRODUCT_TYPE=="via" || PRODUCT_TYPE=="collab8"){								
							$appObj->upgradeViaActiveJson('dnsname',$roomNameCustomIP);
						}
						
						
					}else{
						if(file_exists($filePath)) unlink($filePath);
						//upgrade setting json when upgrade dnsname
						if(PRODUCT_TYPE=="via" || PRODUCT_TYPE=="collab8"){								
							$appObj->upgradeViaActiveJson('dnsname','');
						}
					}	
				}else{
					if(file_exists($filePath)) unlink($filePath);
					//upgrade setting json when upgrade dnsname
					if(PRODUCT_TYPE=="via" || PRODUCT_TYPE=="collab8"){								
						$appObj->upgradeViaActiveJson('dnsname','');
					}
				}
*/				//end
				$jsonValue->roomname1->posLeft=intval(trim($jsonValue->roomname1->posLeft));
				$jsonValue->roomname1->posTop=intval(trim($jsonValue->roomname1->posTop));
				$jsonValue->roomname1->width=intval(trim($jsonValue->roomname1->width));
				$jsonValue->roomname1->height=intval(trim($jsonValue->roomname1->height));
				$roomname1txt=($jsonValue->roomname1->text!='')?str_replace("~@~",",",trim($jsonValue->roomname1->text)):'Room Name:#roomname#';
				$jsonValue->roomname1->text=$roomname1txt;
				
			}
				
			//roomname 2
			if(isset($jsonValue->roomname2)){
				$roomname2txt=($jsonValue->roomname2->text!='')?str_replace("~@~",",",trim($jsonValue->roomname2->text)):'Room Name 2:#roomname#';
				$jsonValue->roomname2->text=$roomname2txt;
				$jsonValue->roomname2->roomname2Text=str_replace("~@~",",",$jsonValue->roomname2->text);
			}
			
			//date
			if(isset($jsonValue->date)){
				$dateformat=$appObj->returndateformat(trim($jsonValue->date->dateFormat));
				$jsonValue->date->dateFormat=$dateformat;
			}
			
			//added on 28Nov2018 for dynamic text
			$levelArrayArrayData=urldecode(trim(substr($_POST['levelArray'],0,-2)));
			//added condition to restrict blank xml
			$levelArrayArrayDataJson=[];
			$levelArrayArrayDataJson = array_keys(json_decode(trim($request->getPost('templatejson')), true));
			foreach($levelArrayArrayDataJson as $val){
				if(trim(substr($val,0,-2))=='level'){
					$jsonValue->{$val}->text=str_replace("~@~",",",htmlentities($jsonValue->{$val}->text));
				}
			}
			
			$jsonContent = json_encode($jsonValue, JSON_PRETTY_PRINT);

			$selQry = $this->getTemplatesTable()->getData(array('template_name'=>$templatename));
			if($selQry->count()>0){
				/*if(file_exists(TEMPLATE_DIR_ZEND.$templatename.'.json')){
					unlink(TEMPLATE_DIR_ZEND.$templatename.'.json');
				}
				if(file_exists(TEMPLATE_DIR_ZEND.$templatename.'.txt')){
					unlink(TEMPLATE_DIR_ZEND.$templatename.'.txt');
				}*/
				if(file_exists(TEMPLATE_DIR_ZEND.$json_templateName)){
					unlink(TEMPLATE_DIR_ZEND.$templatename);
				}				
				
				if(PRODUCT=='vsm'){
					$this->getTemplatesTable()->updateData(array('template_name'=>$templatename,'wallpaper_name'=>$getImageNameForDB,'model_type'=>0,'modifydatetime'=>date('Y-m-d H:i:s'),'model_type'=>0,'json_name'=>$json_templateName), array('template_name'=>$templatename));
				}else{
					$this->getTemplatesTable()->updateData(array('template_name'=>$templatename,'wallpaper_name'=>$getImageNameForDB,'model_type'=>0,'modifydatetime'=>date('Y-m-d H:i:s'),'model_type'=>0,'json_name'=>$json_templateName), array('template_name'=>$templatename));				
				}
			}else{
				if(PRODUCT=='vsm'){
					$this->getTemplatesTable()->insertData(array('template_name'=>$templatename,'wallpaper_name'=>$getImageNameForDB,'model_type'=>0,'json_name'=>$json_templateName,'modifydatetime'=>date('Y-m-d H:i:s')));
				}else{
					$this->getTemplatesTable()->insertData(array('template_name'=>$templatename,'status'=>0,'wallpaper_name'=>$getImageNameForDB,'model_type'=>0,'json_name'=>$json_templateName,'modifydatetime'=>date('Y-m-d H:i:s')));
				
				}
			}	
			
			$encryptedJson = $appObj->desEncrypt($jsonContent,POLL_ENCRYPTION_KEY);
			$fileName = TEMPLATE_DIR_ZEND.$json_templateName;
			if(!file_exists($fileName)){
				$myfile = fopen($fileName, 'w') or die("can't open file");
				fwrite($myfile, $encryptedJson);
				fclose($myfile);
			}


			//if someone save and not publish template
			if(PRODUCT=='via' && $getclickbtnId==='submitBtn'){
				$queryData=$appObj->returnQueryData("SELECT status FROM tbl_templates WHERE template_name='$templatename'");
				$result=$queryData->current();
				if($result['status']==1){
					$appObj->executeQueries("UPDATE tbl_templates SET status=2 WHERE template_name='$templatename'");
				}
			}

			
			if(PRODUCT=='via' && $getclickbtnId==='publishBtn'){
				$jsonContent= file_get_contents($fileName);
				//decrypt template data
				$jsonContent=$appObj->desDecrypt($jsonContent,POLL_ENCRYPTION_KEY);
				
				if (strpos($jsonContent, 'upcomingmeetings') !== false) {
				   echo"1";
				}else{
					$appObj->executeQueries("UPDATE tbl_templates SET status=0");		
					$appObj->executeQueries("UPDATE tbl_templates SET status=1 WHERE template_name='$templatename'");
	
					// code added on 12march2019 for update default wallpaper in config dir 
					$wallpaper_name = $getImageName;	
					if(GET_OS=='WIN'){		
							copy($wallpaper_name,DEST_PATH."default.jpg");
					}else{
							copy($wallpaper_name,DEST_PATH."Default.png");
					}
					$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$appObj->sendMsgToAPIserver($logincmd,$actionCmd);
					echo"2";
				}   
			}
			if(PRODUCT=='via'){
				$appObj->ActivityLog("Create","$templatename by $name");
			}else{
                $appObj->ActivityLogVSM(3, "$templatename by $name",7);
            }
			die;
		}	
	}

	public function getTemplateAjaxAction(){
		$appObj = new ApplicationController();
		$qry1Arr=$appObj->returnQueryData("SELECT template_name FROM tbl_templates ORDER BY id DESC LIMIT 1");
		foreach($qry1Arr as $qry1Data){
			$templatename=$qry1Data['template_name'];
		}
		echo $templatename;die; 
	}

	//calling when click on publish template btn
	public function publishTemplateAjaxAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');	
		$sessiontemplate=trim($session->offsetGet('templatename'));
		$templatename=trim($_POST['templatename'])=='' ? $sessiontemplate : trim($_POST['templatename']);
		$explodeImageBySlash=explode('/',$session->offsetGet('uploadtempfile'));
		$explodeImageByDot=explode('.',$session->offsetGet('uploadtempfile'));
		$imgExt='.'.$explodeImageByDot[1];
		
		//this var $getImageNameForDB is using for storing data in db 
		$getImageNameForDB=IMG_DIR.'large/'.$templatename.$imgExt;
		//this var $getImageName is using for copy data in dir
		$getImageName=UPLOAD_PATH.'large/'.$templatename.$imgExt;
		copy(BASE_PATH.'/public/'.$session->offsetGet('uploadtempfile'),$getImageName);
		//change code for session on 28Feb2020

		$session->offsetSet('uploadtempfile',$getImageNameForDB);
		$appObj->executeQueries("UPDATE tbl_templates SET status=0");		
		$appObj->executeQueries("UPDATE tbl_templates SET status=1 WHERE template_name='$templatename'");
		
		// code added on 12march2019 for update default wallpaper in config dir 
		$wallpaper_name = $getImageName;	
		if(GET_OS=='WIN'){		
				copy($wallpaper_name,DEST_PATH."default.jpg");
		}else{
				copy($wallpaper_name,DEST_PATH."Default.png");
		}
		$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$appObj->sendMsgToAPIserver($logincmd,$actionCmd);
		echo"2";
		die;	
	}

	//ajax call from template list
	public function checkCalendarAjaxAction(){
		$appObj = new ApplicationController();
		$tmpId=trim($_POST['tmpId']);
		$qry1Arr=$appObj->returnQueryData("SELECT template_name,id FROM tbl_templates WHERE id=$tmpId");
		foreach($qry1Arr as $qry1Data){
			$templatename=$qry1Data[0];
		}		
		//$templateJson=BASE_PATH.'/templatedesigner/templates/'.$templatename.'.json';
		$templateJson=TEMPLATE_DIR_ZEND.$templatename.'.json';
		$json= file_get_contents($templateJson);
		$msg=0;
		if (strpos($json, 'upcomingmeetings') !== false) {
			 $calendarConfigSqlArr = $appObj->returnQueryData("SELECT * FROM tbl_calender_account");			 
			 if(count($calendarConfigSqlArr)==0){
				echo"1";die;
			 }
		}	
		die;
	}

	//ajax call when click on submit button
	public function checkCalconfigAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$calendarConfigCount=$appObj->checkTableCount('tbl_calender_account');
		if($calendarConfigCount==0){
			echo 1;die;
		}else{
			echo 2;die;
		}
	}
	
	//update template
	public function templateDesignUpdateAction(){
		$this->layout('layout/template');
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$fetchTblHqInfoDataArr=$appObj->getTableAllData('tbl_hq_configuration')->current();
		$configSettingVal=$fetchTblHqInfoDataArr['hq_configsetting'];
		$colPickCss='color-box';//($configSettingVal==1)?'color-box-disabled':'color-box';
		$check_roomcodevalue_file=file_exists(DEST_PATH.READFILE_ROOMCODEVALUE_SHOW)?$appObj->file_read(DEST_PATH.READFILE_ROOMCODEVALUE_SHOW):0;		
		$getroomcode=($check_roomcodevalue_file!=0)?$check_roomcodevalue_file:'';
		$lang=(CHECK_FILE_LANGTXT==1)?$appObj->file_read(DEST_PATH.READFILE_LANGTXT):'en';
		$opacityArr=array(10,20,30,40,50,60,70,80,90,100);
		$textalignArray=array('left'=>'Left','right'=>'Right','vertical'=>'Center');
		$refreshTimeArr=array(1=>3,2=>5,3=>10,4=>20,5=>30,6=>50,7=>60);
		$screenwidth = $session->offsetGet('screenwidth');
		//Fix security issue if anyone post query
		if( strstr(strtolower($_GET['destWidth']),'select') ||  strstr(strtolower($_GET['destWidth']),'and') || strstr(strtolower($_GET['destWidth']),'or') || $_GET['destWidth']>5000){
			die('Invalid request');
		}
		if( strstr(strtolower($_GET['destHeight']),'select') ||  strstr(strtolower($_GET['destHeight']),'and') || strstr(strtolower($_GET['destHeight']),'or') || $_GET['destHeight']>5000 ){
			die('Invalid request');
		}
		
		
		if($screenwidth < 1366){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt');
		}else if($screenwidth >= 1366 && $screenwidth < 1920){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt');
		}else if($screenwidth >= 1920 && $screenwidth < 2560){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt','50px'=>'50 pt','52px'=>'52 pt','54px'=>'54 pt','56px'=>'56 pt','58px'=>'58 pt','60px'=>'60 pt','62px'=>'62 pt','64px'=>'64 pt','66px'=>'66 pt','68px'=>'68 pt','70px'=>'70 pt','72px'=>'72 pt');
		}else if($screenwidth >= 2560 && $screenwidth < 3240){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt','50px'=>'50 pt','52px'=>'52 pt','54px'=>'54 pt','56px'=>'56 pt','58px'=>'58 pt','60px'=>'60 pt','62px'=>'62 pt','64px'=>'64 pt','66px'=>'66 pt','68px'=>'68 pt','70px'=>'70 pt','72px'=>'72 pt','74px'=>'74 pt','76px'=>'76 pt','78px'=>'78 pt','80px'=>'80 pt','82px'=>'82 pt','84px'=>'84 pt','86px'=>'86 pt','88px'=>'88 pt','90px'=>'90 pt','92px'=>'92 pt','94px'=>'94 pt','96px'=>'96 pt','98px'=>'98 pt','100px'=>'100 pt','102px'=>'102 pt','104px'=>'104 pt','106px'=>'106 pt','108px'=>'108 pt','110px'=>'110 pt','112px'=>'112 pt','114px'=>'114 pt','116px'=>'116 pt','118px'=>'118 pt','120px'=>'120 pt','122px'=>'122 pt','124px'=>'124 pt','126px'=>'126 pt','128px'=>'128 pt','130px'=>'130 pt','132px'=>'132 pt','134px'=>'134 pt','136px'=>'136 pt','138px'=>'138 pt','140px'=>'140 pt','142px'=>'142 pt','144px'=>'144 pt','146px'=>'146 pt','148px'=>'148 pt','150px'=>'150 pt','152px'=>'152 pt','154px'=>'154 pt','156px'=>'156 pt','158px'=>'158 pt');
		}else if($screenwidth > 3240){
			$fontsizeArray=array('10px'=>'10 pt','12px'=>'12 pt','14px'=>'14 pt','16px'=>'16 pt','18px'=>'18 pt','20px'=>'20 pt','22px'=>'22 pt','24px'=>'24 pt','26px'=>'26 pt','28px'=>'28 pt','30px'=>'30 pt','32px'=>'32 pt','34px'=>'34 pt','36px'=>'36 pt','38px'=>'38 pt','40px'=>'40 pt','42px'=>'42 pt','44px'=>'44 pt','46px'=>'46 pt','48px'=>'48 pt','50px'=>'50 pt','52px'=>'52 pt','54px'=>'54 pt','56px'=>'56 pt','58px'=>'58 pt','60px'=>'60 pt','62px'=>'62 pt','64px'=>'64 pt','66px'=>'66 pt','68px'=>'68 pt','70px'=>'70 pt','72px'=>'72 pt','74px'=>'74 pt','76px'=>'76 pt','78px'=>'78 pt','80px'=>'80 pt','82px'=>'82 pt','84px'=>'84 pt','86px'=>'86 pt','88px'=>'88 pt','90px'=>'90 pt','92px'=>'92 pt','94px'=>'94 pt','96px'=>'96 pt','98px'=>'98 pt','100px'=>'100 pt','102px'=>'102 pt','104px'=>'104 pt','106px'=>'106 pt','108px'=>'108 pt','110px'=>'110 pt','112px'=>'112 pt','114px'=>'114 pt','116px'=>'116 pt','118px'=>'118 pt','120px'=>'120 pt','122px'=>'122 pt','124px'=>'124 pt','126px'=>'126 pt','128px'=>'128 pt','130px'=>'130 pt','132px'=>'132 pt','134px'=>'134 pt','136px'=>'136 pt','138px'=>'138 pt','140px'=>'140 pt','142px'=>'142 pt','144px'=>'144 pt','146px'=>'146 pt','148px'=>'148 pt','150px'=>'150 pt','152px'=>'152 pt','154px'=>'154 pt','156px'=>'156 pt','158px'=>'158 pt','160px'=>'160 pt','162px'=>'162 pt','164px'=>'164 pt','166px'=>'166 pt','168px'=>'168 pt','170px'=>'170 pt','172px'=>'172 pt','174px'=>'174 pt','176px'=>'176 pt','178px'=>'178 pt','180px'=>'180 pt','182px'=>'182 pt','184px'=>'184 pt','186px'=>'186 pt','188px'=>'188 pt','190px'=>'190 pt','192px'=>'192 pt','194px'=>'194 pt','196px'=>'196 pt','198px'=>'198 pt','200px'=>'200 pt','202px'=>'202 pt','204px'=>'204 pt','206px'=>'206 pt','208px'=>'208 pt','210px'=>'210 pt','212px'=>'212 pt','214px'=>'214 pt');
		}
		
		$input=str_replace(' ','+',trim($this->params()->fromQuery('id')));
		$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
		$templateid=$appObj->desDecrypt($input, KEY_SEED);
		//Security changes added by ashu on 31/03/22. Allow only numeric value 
		if(!is_numeric($templateid) || $templateid <= 0 ){
			echo "Id is not valid";die;
		}		
		
		$tempQryData = $this->getTemplatesTable()->getData(array('id'=>$templateid))->current();
		$sessionImage=$tempQryData['wallpaper_name'];
		$session->offsetSet('uploadtempfile',$sessionImage);
		$activewallpaper=UPLOAD_DIR_ZEND.$tempQryData['wallpaper_name'];
		//$lastWallSqlArr=$appObj->returnQueryData("SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = '".DB_NAME."' AND TABLE_NAME = 'tbl_templates'")->current();		
		/*$lastWallSqlArr=$appObj->returnQueryData("SELECT nextval('tbl_templates_id_seq') as auto_increment")->current();  
		if(count($lastWallSqlArr)>0){
			$newId=$lastWallSqlArr['auto_increment'];
			$newIdEnc=$appObj->desEncrypt($newId, KEY_SEED);						
		}*/
		$wallSql=$appObj->returnQueryData('SELECT wallpaper_name FROM tbl_templates');
		if(PRODUCT=='via'){
			$file_roomnamevalueshow=$appObj->returnRoomNameValue();
			$fetchConfigDataArr=$appObj->getTableAllData('tbl_display_settings');
			foreach($fetchConfigDataArr as $fetchConfigData){
				$check_readfile_ipadd1=file_exists(DEST_PATH.READFILE_IPADD1)?$appObj->file_read(DEST_PATH.READFILE_IPADD1):'';
				$activate_RoomName2_DNS=($fetchConfigData['field3']!='')?trim($fetchConfigData['field3']):trim($check_readfile_ipadd1);
				$getCustomRoomname2=trim($fetchConfigData['field3']);
			}
		}else{
			$file_roomnamevalueshow='(VIA IP 1)';
			$activate_RoomName2_DNS='(VIA IP 2)';
		}
		return new ViewModel(array(
			'colPickCss'=>$colPickCss,
			'getroomcode'=>$getroomcode,
			'lang'=>$lang,
			'configSettingVal'=>$configSettingVal,
			'opacityArr'=>$opacityArr,
			'textalignArray'=>$textalignArray,
			'fontsizeArray'=>$fontsizeArray,
			'refreshTimeArr'=>$refreshTimeArr,
			'templateid'=>$templateid,
			'tempQryData'=>$tempQryData,
			//'newIdEnc'=>$newIdEnc,
			'activewallpaper'=>$activewallpaper,
			'wallSql'=>$wallSql,
			'file_roomnamevalueshow'=>$file_roomnamevalueshow,
			'activate_RoomName2_DNS'=>$activate_RoomName2_DNS
		));					 
	}	

	public function updateTemplateDataAjaxAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$name = $session->offsetGet('LoginName');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');			
		
		if($session->offsetGet('LoginName')==''){
			echo 'sessionout';
			exit;
		}
		
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$tempid=trim($request->getPost('tempid'));
			//Security changes added by ashu on 31/03/22. Allow only numeric value 
			if(!is_numeric($tempid) || $tempid <= 0 ){
				echo "Id is not valid";die;
			}	
			
			$currentWallpaper=$session->offsetGet('uploadtempfile');
			$jsonValue=json_decode(trim($request->getPost('templatejson')));
			$gridVal=trim($request->getPost('gridChkVal'));
			$screenwidth=trim($request->getPost('screenwidth'));
			$screenheight=trim($request->getPost('screenheight'));
			$getclickbtnId=trim($request->getPost('getclickbtnId'));
			$templatename=trim($request->getPost('tempname'));
			$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			
			$explodeImageBySlash=explode('/',$currentWallpaper);
			$explodeImageByDot=explode('.',$currentWallpaper);
			$imgExt='.'.$explodeImageByDot[1];
			$getImageName=BASE_PATH.'/public/'.IMG_DIR.'large/'.$templatename.$imgExt;
			$getImageNameForDB=IMG_DIR.'large/'.$templatename.$imgExt;
			copy(UPLOAD_DIR_ZEND.$session->offsetGet('uploadtempfile'),$getImageName);
			$session->offsetSet('uploadtempfile',$getImageNameForDB);
			$wallpaperJson=array('imagePath'=>$getImageNameForDB,'width'=>intval($screenwidth),'height'=>intval($screenheight),'gridvalue'=>$gridVal);
			$jsonValue->wallpaper=(object)$wallpaperJson;
			$json_templateName = time().'.json';
			if(isset($jsonValue->roomname1)){
				//chnage on 15/01/2019. if roomname is blank then delete roomnamevalueshow.txt file
				$filePath=DEST_PATH.READFILE_ROOMNAMEVALUESHOW;
				$roomNameCustomIP=$jsonValue->roomname1->customNameText;
				//added on 1stJuly22. Now we are moving custom name to via settings				
/*				if($roomNameCustomIP!=''){				
					// check added on 15/01/2019 if $roomNameCustomIP is not equal to ipadd.txt file content then write value of roomNameCustomIP in roomnamevalueshow.txt otherwise not		
					if(trim($appObj->file_read(DEST_PATH.READFILE_IPADD))!=trim($roomNameCustomIP)){			
						if(file_exists($filePath)){
							unlink($filePath);
							$myfile = fopen($filePath, 'w') or die("can't open file");
							$content = $roomNameCustomIP;	
							$confWrite= fwrite($myfile, $content);
						}else{
							$myfile = fopen($filePath, 'w') or die("can't open file");
							$content = $roomNameCustomIP;	
							$confWrite= fwrite($myfile, $content);
						}
						//upgrade setting json when upgrade dnsname
						if(PRODUCT_TYPE=="via" || PRODUCT_TYPE=="collab8"){								
							$appObj->upgradeViaActiveJson('dnsname',$roomNameCustomIP);
						}
						
						
					}else{
						if(file_exists($filePath)) unlink($filePath);
						//upgrade setting json when upgrade dnsname
						if(PRODUCT_TYPE=="via" || PRODUCT_TYPE=="collab8"){								
							$appObj->upgradeViaActiveJson('dnsname','');
						}
						
					}	
				}else{
					if(file_exists($filePath)) unlink($filePath);
					//upgrade setting json when upgrade dnsname
					if(PRODUCT_TYPE=="via" || PRODUCT_TYPE=="collab8"){								
						$appObj->upgradeViaActiveJson('dnsname','');
					}
					
				}
*/				//end
				$jsonValue->roomname1->posLeft=intval(trim($jsonValue->roomname1->posLeft));
				$jsonValue->roomname1->posTop=intval(trim($jsonValue->roomname1->posTop));
				$jsonValue->roomname1->width=intval(trim($jsonValue->roomname1->width));

				$jsonValue->roomname1->height=intval(trim($jsonValue->roomname1->height));
				$roomname1txt=($jsonValue->roomname1->text!='')?str_replace("~@~",",",trim($jsonValue->roomname1->text)):'Room Name:#roomname#';
				$jsonValue->roomname1->text=$roomname1txt;
			}

			if(isset($jsonValue->roomname2)){
				$roomname2txt=($jsonValue->roomname2->text!='')?str_replace("~@~",",",trim($jsonValue->roomname2->text)):'Room Name 2:#roomname#';
				$jsonValue->roomname2->text=$roomname2txt;
				$jsonValue->roomname2->roomname2Text=str_replace("~@~",",",$jsonValue->roomname2->text);
			}

			if(isset($jsonValue->date)){
				$dateformat=$appObj->returndateformat(trim($jsonValue->date->dateFormat));
				$jsonValue->date->dateFormat=$dateformat;
			}
			
			//for dynamic text
			$levelArrayArrayData=[];
			$levelArrayArrayData = array_keys(json_decode(trim($_POST['templatejson']), true));
			foreach($levelArrayArrayData as $val){
				if(trim(substr($val,0,-2))=='level'){
					$jsonValue->{$val}->text=str_replace("~@~",",",htmlentities($jsonValue->{$val}->text));
				}
			}
			$jsonContent = json_encode($jsonValue, JSON_PRETTY_PRINT);
			if(PRODUCT=='vsm'){
				/* when updated a active wallpaper then set wallpaper_status to 0 of tbl_sys_report. So that updated wallpaper can replicate to gateways  */
				//Getting assigned template info
				$getTempltInfoSql=$appObj->returnQueryData("SELECT B.DID,B.DeviceName,A.isGrpIdOrDeviceId,A.template_id,A.entryType,B.os_type FROM tbl_templates_mapping A INNER JOIN DeviceInventory B ON A.isGrpIdOrDeviceId=B.DeviceGroupID WHERE A.template_id=$tempid");	
				$gatewayStrBygrp='';
				$gatewayStr='';
				if($getTempltInfoSql->count()>0){
					foreach($getTempltInfoSql as $arrayData){
						$gwayList.=$arrayData["DID"].',';
					}//end foreach loop
					$gatewayStrBygrp = rtrim($gwayList,",");
					if($gatewayStrBygrp!=''){
						$getGwayList=implode(',',array_unique(explode(',', $gatewayStrBygrp)));
						$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0 WHERE did_fk IN ($getGwayList)");
						$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($getGwayList)");
					}
				}
			}
			
				
			//End updated wallpaper code
			$appObj->executeQueries("UPDATE tbl_templates set wallpaper_name='$getImageNameForDB',template_name='$templatename', modifydatetime=now(),model_type=0,json_name='$json_templateName' where id=$tempid");
			$encryptedJson = $appObj->desEncrypt($jsonContent,POLL_ENCRYPTION_KEY);
			$fileName = TEMPLATE_DIR_ZEND.$templatename.'.json';
			if(file_exists($fileName)){
				unlink($fileName);		
			}
			$fileName = TEMPLATE_DIR_ZEND.$json_templateName;			
			if(file_exists($fileName)){
				unlink($fileName);		
			}
			
			$myfile = fopen($fileName, 'w') or die("can't open file");
			fwrite($myfile, $encryptedJson);
			fclose($myfile);

			//if someone save and not publish template
			if(PRODUCT=='via' && $getclickbtnId==='submitBtn'){
				$queryData=$appObj->returnQueryData("SELECT status FROM tbl_templates WHERE id=$tempid");
				$result=$queryData->current();
				if($result['status']==1){
					$appObj->executeQueries("UPDATE tbl_templates SET status=2 WHERE template_name='$templatename' AND id=$tempid");
				}
			}

		}
		if(PRODUCT=='via'){
			$appObj->ActivityLog('Update',$templatename.' by '.$session->offsetGet('LoginName'));
		}else{
			$appObj->ActivityLogVSM(4,$templatename.' by '.$session->offsetGet('LoginName'),7);
		}
		if(PRODUCT=='via' && $getclickbtnId==='publishBtn'){
			$templateJson=TEMPLATE_DIR_ZEND.$templatename.'.json';
			$json= file_get_contents($templateJson);
			$json=$appObj->desDecrypt($json,POLL_ENCRYPTION_KEY);
			if (strpos($json, 'upcomingmeetings') !== false) {
				 echo"1";die;
			}else{
				$appObj->executeQueries("UPDATE tbl_templates SET status=0");
				$appObj->executeQueries("UPDATE tbl_templates SET status=1 WHERE template_name='$templatename' AND id=$tempid");
				$wallpaper_name = $getImageName;	
				if(GET_OS=='WIN'){		
					copy($wallpaper_name,DEST_PATH."default.jpg");
				}else{
					copy($wallpaper_name,DEST_PATH."Default.png");
				}				
				
				$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$appObj->sendMsgToAPIserver($logincmd,$actionCmd);
				echo"2";die;
			}
        }
		die;
	}	
	
	//store screen resolution in session
	public function getScreenResolutionAction(){
		$request = $this->getRequest();
		$session = new Container('userinfo');
		if($request->isPost()){
			$screenwidth = trim($request->getPost('screenwidth'));
			$session->offsetSet('screenwidth', $screenwidth);die;
		}
	}
	
	//ajax call for preview from update template.
	public function templatepreviewAjaxAction(){
		$html=str_replace('alert(',"",$_POST['html']);
		$fileName=TEMPLATE_DIR_ZEND.'previewWallpaper.tpl';		
		$myfile = fopen($fileName, 'w') or die("can't open file");
		$confWrite= fwrite($myfile, $html);	
		die;
	}
	
	//ajax call to delete templates	
	public function deltemplatedesignrAjaxAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$name = $session->offsetGet('LoginName');
			//get crsf value from session
			$session_crsf_token=$session->offsetGet('crsf_token');
			
			$tmpId=trim($request->getPost('tmpId'));			
			$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			
			$queryArr=$appObj->returnQueryData("SELECT * FROM tbl_templates WHERE id IN ($tmpId)");
			foreach($queryArr as $queryData){
				$template_name=$queryData['template_name'];				
				$wallpaper_name=HTML_PUBLIC_DIR."/".$queryData['wallpaper_name'];
				$templateName=$template_name.'.txt';
				$templateNamejson=($queryData['json_name']!='')?$queryData['json_name']:$template_name.'.json';
				if(file_exists($wallpaper_name)){
					  unlink($wallpaper_name);
				}	
				if(file_exists(TEMPLATE_DIR_ZEND.$templateName)){
					 unlink(TEMPLATE_DIR_ZEND.$templateName);
				}
				if(file_exists(TEMPLATE_DIR_ZEND.$templateNamejson)){
					 unlink(TEMPLATE_DIR_ZEND.$templateNamejson);		
				}
			}
			$appObj->executeQueries("DELETE FROM tbl_templates WHERE id IN ($tmpId)");
			if(PRODUCT=='via'){
				$appObj->ActivityLog('Delete',$template_name.' by '.$session->offsetGet('LoginName'));
			}else{
				$appObj->ActivityLogVSM(5,$template_name.' by '.$session->offsetGet('LoginName'),7);
			}
			die;
		}		
	}	
	
	//export templates
	public function exporttemplatesAction(){
		if(isset($_POST['exportTempBtn'])){
			$filesArr=$_POST['exportTempChkbox'];		
			$zip = new ZipArchive();	
            $zip_name = 'Template_'.date('Y-M-d').".screen";
            if($zip->open($zip_name, ZIPARCHIVE::CREATE)!==TRUE){
				$error .=  "* Sorry screen creation failed at this time<br/>";
            }
			
            foreach($filesArr as $file){
                    $explodeTemplate=explode('#',$file);
                    $templateJson=$explodeTemplate[0];
					$fileWithoutExt = pathinfo($templateJson, PATHINFO_FILENAME);
					$templateFileWtExnt=pathinfo($explodeTemplate[1], PATHINFO_FILENAME);
					$templateXml = TEMPLATE_DIR_ZEND.$fileWithoutExt.'.txt';
                    $wallpaperFile = HTML_PUBLIC_DIR.'/'.$explodeTemplate[1];					
					//Preventing Directory Traversal(24-Sept-2019)
					$basepathJson = TEMPLATE_DIR_ZEND;
					$realBaseJson = realpath($basepathJson);
					$realUserPathJson = realpath($explodeTemplate[0]);
					$basepath = HTML_PUBLIC_DIR.'/'.IMG_DIR.'large/';
					$realBase = realpath($basepath);
					$realUserPath= realpath(HTML_PUBLIC_DIR.'/'.$explodeTemplate[1]);
					
					if ($realUserPathJson === false || strpos($realUserPathJson, $realBaseJson) !== 0 || $realUserPath === false || strpos($realUserPath, $realBase) !== 0) {
						echo "Path is not correct";die;
					}
					//End
                    //$zip->addFile($templateJson,basename($templateJson));
					$zip->addFile($templateJson,$templateFileWtExnt.'.json');
                    $zip->addFile($wallpaperFile,basename($wallpaperFile));
					if(file_exists($templateXml)){
						//$zip->addFile($templateJson,basename($templateXml));
					}
            }
            $zip->close();
			//echo 'aaa'.$zip_name;die;
		   if(file_exists($zip_name)){
				ob_end_clean();
				header('Content-type: application/zip');
				header('Content-Disposition: attachment; filename="'.$zip_name.'"');
				header("Content-Length:".filesize($zip_name));
				readfile($zip_name);
				unlink($zip_name);
			}			
			die;
		}
	}
	
	public function importTemplateAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');				
		$name=$session->offsetGet('LoginName');		
        $filename=$_FILES['zipUploadFile']['name'];
        $tmp_Path = $_FILES['zipUploadFile']['tmp_name'];
		if(isset($filename)){
			$dirForDb="uploads/";
			$dir =BASE_PATH.'/public/'.IMG_DIR;
            $extracted_path=$dir.'extractTemplates/';
            $target_Path = $dir.$filename;
            move_uploaded_file($tmp_Path, $target_Path);
            $zip = new ZipArchive();
            $response=$zip->open($target_Path);
			if ($response === TRUE){
                $zip->extractTo($extracted_path);
                $zip->close();
                unlink($target_Path);
				$timeVal=0;				
				foreach (glob("$extracted_path*.{jpg,jpeg,png,gif}", GLOB_BRACE) as $file) {
                    $fileInfo = pathinfo($file);
                    $ext=$fileInfo['extension'];
                    $fileWithoutExt=$fileInfo['filename'];
                    $fileWithoutExtNew=$fileWithoutExt;
					$fileWithoutExtNew=$this->getUniqueName($fileWithoutExt);
                    if(file_exists($extracted_path.$fileWithoutExt.'.txt')){
                        $filePath="$extracted_path"."$fileWithoutExt";
                        $this->parseXmlToJson($filePath);
                    }
					$xmlTemplate = $extracted_path.$fileWithoutExt.'.txt';
					$jsonTemplate = $extracted_path.$fileWithoutExt.'.json';
					$fileWithoutExtJSON=time().$timeVal.'.json';
					if(file_exists($jsonTemplate)){
						//$templateJson=TEMPLATE_DIR_ZEND.$fileWithoutExtNew.'.json';
						$templateJson=TEMPLATE_DIR_ZEND.$fileWithoutExtJSON;
                        $template_name=$fileWithoutExtNew;
                        $wallpaper_name=HTML_PUBLIC_DIR.'/uploads/large/'.$fileWithoutExtNew.'.'.$ext;
						$wallpaper_name_forDb=$dirForDb.'large/'.$fileWithoutExtNew.'.'.$ext;
                        rename("$extracted_path"."$fileWithoutExt.$ext", $wallpaper_name);
                        rename("$extracted_path"."$fileWithoutExt.json", $templateJson);
						$jsonContent=file_get_contents($templateJson) or die("Error: Cannot create json object");
						$jsonContent=$appObj->desDecrypt($jsonContent,POLL_ENCRYPTION_KEY);
                        $imagepathJson = str_replace($fileWithoutExt, $fileWithoutExtNew, $jsonContent);
                        file_put_contents($templateJson, $imagepathJson);
                        //encrypt template. this code will encypt templates < 3.0
						$jsonContent=file_get_contents($templateJson) or die("Error: Cannot create json object");
                        $isJson = is_string($jsonContent) && is_array(json_decode($jsonContent, true)) ? true : false;
                        if($isJson){
							$jsonContentDecode = json_decode($jsonContent);
							foreach($jsonContentDecode as $key => $value){
								if($key=='wallpaper'){	
									$encryptedStr=$appObj->desEncrypt($jsonContent,POLL_ENCRYPTION_KEY);
									$jsonContent = json_encode($encryptedStr, JSON_PRETTY_PRINT);
									$myfileJson = fopen($templateJson, 'w') or die("can't open file");						
									$confWrite= fwrite($myfileJson, $jsonContent);
									fclose($myfileJson);
								}
							}
						}
                    }
					$fileWithoutExtTxt=time().$timeVal.'.txt';
					if(file_exists($xmlTemplate)){
						//$templateXml=TEMPLATE_DIR_ZEND.$fileWithoutExtNew.'.txt';
						$templateXml=TEMPLATE_DIR_ZEND.$fileWithoutExtTxt;
                        $template_name=$fileWithoutExtNew;
                        $wallpaper_name=HTML_PUBLIC_DIR.'/uploads/large/'.$fileWithoutExtNew.'.'.$ext;
						$wallpaper_name_forDb=$dirForDb.'large/'.$fileWithoutExtNew.'.'.$ext;
                        rename("$extracted_path"."$fileWithoutExt.$ext", $wallpaper_name);
                        rename("$extracted_path"."$fileWithoutExt.txt", $templateXml);
						$xml= file_get_contents($templateXml);
                        $imagepath = str_replace($fileWithoutExt, $fileWithoutExtNew, $xml);
                        file_put_contents($templateXml, $imagepath);
						//encrypt template. this code will encypt templates < 3.0
						$xmlContent=file_get_contents($templateXml) or die("Error: Cannot create xml object");
						$encryptedStr=$appObj->desEncrypt($xmlContent,POLL_ENCRYPTION_KEY);
						$myfileXml = fopen($templateXml, 'w') or die("can't open file");						
						$confWrite= fwrite($myfileXml, $encryptedStr);
						fclose($myfileXml);
                    }
					if(PRODUCT=='via'){
						$appObj->executeQueries("INSERT INTO tbl_templates (template_name,status,created_at,wallpaper_name,model_type,json_name,modifydateTime) VALUES ('".$template_name."',0,NOW(),'".$wallpaper_name_forDb."',0,'".$fileWithoutExtJSON."',NOW())");
					}else{
						$appObj->executeQueries("INSERT INTO tbl_templates (template_name,created_at,wallpaper_name,model_type,json_name,modifydateTime) VALUES ('".$template_name."',NOW(),'".$wallpaper_name_forDb."',0,'".$fileWithoutExtJSON."',NOW())");
					}
					
					
					$timeVal++;
				}//end of foreach
			}else{
                $msg='';
                switch($response) {
                    case ZipArchive::ER_NOZIP:
                        $msg = 'not a screen archive';break;
                    case ZipArchive::ER_INCONS :
                        $msg = 'consistency check failed';break;
                    case ZipArchive::ER_CRC :
                        $msg = 'checksum failed';break;
                    case ZipArchive::ER_OPEN:
                        $msg = 'unable to open file';break;
                    default:
                        $msg = 'error ' . $response;
                }
                if($msg!=''){
                    echo $msg;die;
                }
            }die;
		}
		die;
    } 
	 
	//function calling from this page
	public function getUniqueName($fileWithoutExt){
		$lastWallSqlArr = $this->getTemplatesTable()->getData(array('template_name'=>$fileWithoutExt));
		if($lastWallSqlArr->count()>0){
			foreach($lastWallSqlArr as $lastWallSqlData){                
				$wallpaperName=$lastWallSqlData['template_name'];
				$wallCount = (int) filter_var($wallpaperName, FILTER_SANITIZE_NUMBER_INT);
				$fileStringName=str_replace($wallCount,'',$wallpaperName);
				$wallCount+=1;
				$fileWithoutExt=$fileStringName.$wallCount;
				$fileWithoutExt=$this->getUniqueName($fileWithoutExt);
			}
		}
		return $fileWithoutExt;  
	}

	//ajax call from template list to set template
	public function settemplatedesignrAjaxAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');		
		$name=$session->offsetGet('LoginName');	
		$hostname=$_SERVER['REMOTE_ADDR'];	
		$tmpId=trim($_POST['tmpId']);
		$templateIdSqlArr = $appObj->returnQueryData("SELECT id,template_name,wallpaper_name FROM tbl_templates WHERE id=$tmpId");
		foreach($templateIdSqlArr as $templateIdSqlData){
			$templateid = $templateIdSqlData['id'];
			$templatename=$templateIdSqlData['template_name'];
			$get_temp_wallName=$templateIdSqlData['wallpaper_name'];
		}
		if(PRODUCT=='via'){
			$wallpaper_name = HTML_PUBLIC_DIR.'/'.$get_temp_wallName;		
			if(GET_OS=='WIN'){		
				copy($wallpaper_name,DEST_PATH."default.jpg");
			}else{
				copy($wallpaper_name,DEST_PATH."Default.png");
			}
		}
		
		$templateJson=TEMPLATE_DIR_ZEND.$templatename.'.json';

		$json = file_get_contents($templateJson);
		$json = $appObj->desDecrypt($json,POLL_ENCRYPTION_KEY);
		$msg=0;
		if (strpos($json, 'upcomingmeetings') !== false) {
			$calendarConfigSql = $appObj->returnQueryData("SELECT * FROM tbl_calender_account");
			if(count($calendarConfigSql)==0){
				echo 2;die;
			}else{
				$appObj->executeQueries("UPDATE tbl_templates SET status = CAST((id = $tmpId) AS INTEGER)");
			}
		}else{
			$appObj->executeQueries("UPDATE tbl_templates SET status = CAST((id = $tmpId) AS INTEGER)");
		}
		$result=$appObj->findServerConnection();
		if($result!=0){
			  $sock=$result;
			  $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			  $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
			  sleep(1);
			  $buf = socket_read($sock,512);
			  $usrcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			  $sockWrrite=socket_write($sock, $usrcmd,strlen($usrcmd));
			  if(!$sockWrrite){				
				  $data='sendDataError'; 
			  }else{			 
				  $data=1;
			  }
		}else{
		  	$data=0;
	   }
		if(!is_null($sock)){ @socket_close($sock); }
		if($data==1){
		   //echo 'ResetWallpaper';
		}
		die;	
	}
	
	//ajax call from KDS template list to set wallpaer
	public function setkdswallpaperAjaxAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');		
		$name=$session->offsetGet('LoginName');	
		$hostname=$_SERVER['REMOTE_ADDR'];	
		$tmpId=trim($_POST['tmpId']);
		$templateIdSqlArr = $appObj->returnQueryData("SELECT id,template_name,wallpaper_name FROM tbl_templates WHERE id=$tmpId");
		foreach($templateIdSqlArr as $templateIdSqlData){
			$templateid = $templateIdSqlData['id'];
			$templatename=$templateIdSqlData['template_name'];
			$get_temp_wallName=$templateIdSqlData['wallpaper_name'];
		}
		
		$wallpaper_name = HTML_PUBLIC_DIR.'/'.$get_temp_wallName;		
		if(GET_OS=='WIN'){		
			copy($wallpaper_name,DEST_PATH."default.jpg");
		}else{
			copy($wallpaper_name,DEST_PATH."Default.png");
		}
		
		
		$msg=0;
		
		$appObj->executeQueries("UPDATE tbl_templates SET status = (id = $tmpId)");		
		$result=$appObj->findServerConnection();
		if($result!=0){
			  $sock=$result;
			  $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			  $sockWrrite=socket_write($sock, $logincmd,strlen($logincmd));
			  sleep(1);
			  $buf = socket_read($sock,512);
			  $usrcmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>ResetWallpaper</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			  $sockWrrite=socket_write($sock, $usrcmd,strlen($usrcmd));
			  if(!$sockWrrite){				
				  $data='sendDataError'; 
			  }else{			 
				  $data=1;
			  }
		}else{
		  	$data=0;
	   }	
		if(!is_null($sock)){ @socket_close($sock); }	
		die;	
	}
	
	
		
	//function calling from this page
    public function parseXmlToJson($file){
            $xmlFile=$file.'.txt';
            $xml = simplexml_load_file($xmlFile);
            $json=json_encode($xml);
            $array = json_decode($json,TRUE);
            $xmlArr=$array['P'];
            $jsonValue = new \StdClass;

            foreach($xmlArr as $value){
                if($value['Cmd']=='wallpaper'){
                    $jsonValue->wallpaper->imagePath=$value['P1'];
                    $jsonValue->wallpaper->width=$value['P2'];
                    $jsonValue->wallpaper->height=$value['P3'];
                    $jsonValue->wallpaper->gridvalue=$value['P4'];
                }
                if($value['Cmd']=='roomname1'){
                    $jsonValue->roomname1->posLeft=$value['P1'];
                    $jsonValue->roomname1->posTop=$value['P2'];
                    $jsonValue->roomname1->width=$value['P3'];
                    $jsonValue->roomname1->height=$value['P4'];
                    $jsonValue->roomname1->roomname1Text=$value['P5'];
                    $jsonValue->roomname1->activateRoomName=$value['P6'];
                    $jsonValue->roomname1->showSecondDisplay=$value['P7'];
                    $jsonValue->roomname1->activateRoomOverlay=$value['P8'];
                    $jsonValue->roomname1->RoomOverlayValue=$value['P9'];
                    $jsonValue->roomname1->backgroundColor=$value['P10'];
                    $jsonValue->roomname1->borderColor=(isset($value['P11']) && !empty($value['P11']))?$value['P11']:'';
                    $jsonValue->roomname1->fontColor=$value['P12'];
                    $jsonValue->roomname1->fontSize=$value['P13'];
                    $jsonValue->roomname1->textAlign=$value['P14'];
                    $jsonValue->roomname1->opacity=$value['P15'];
                    $jsonValue->roomname1->borderNoneChkbox=$value['P16'];
                    $jsonValue->roomname1->text=(isset($value['P17']) && !empty($value['P17']))?$value['P17']:'';
                    $jsonValue->roomname1->customNameText=(isset($value['P18']) && !empty($value['P18']))?$value['P18']:'';
                    $jsonValue->roomname1->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                }
                if($value['Cmd']=='roomname2'){
                    $jsonValue->roomname2->posLeft=$value['P1'];
                    $jsonValue->roomname2->posTop=$value['P2'];
                    $jsonValue->roomname2->width=$value['P3'];
                    $jsonValue->roomname2->height=$value['P4'];
                    $jsonValue->roomname2->roomname2Text=$value['P5'];
                    $jsonValue->roomname2->activateRoomName=$value['P6'];
                    $jsonValue->roomname2->backgroundColor=$value['P7'];
                    $jsonValue->roomname2->borderColor=(isset($value['P8']) && !empty($value['P8']))?$value['P8']:'';
                    $jsonValue->roomname2->fontColor=$value['P9'];
                    $jsonValue->roomname2->fontSize=$value['P10'];
                    $jsonValue->roomname2->textAlign=$value['P11'];
                    $jsonValue->roomname2->opacity=$value['P12'];
                    $jsonValue->roomname2->borderNoneChkbox=$value['P16'];
                    $jsonValue->roomname2->text=(isset($value['P17']) && !empty($value['P17']))?$value['P17']:'';
                    $jsonValue->roomname2->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                    $jsonValue->roomname2->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
                if($value['Cmd']=='roomcode'){
                    $jsonValue->roomcode->posLeft=$value['P1'];
                    $jsonValue->roomcode->posTop=$value['P2'];
                    $jsonValue->roomcode->width=$value['P3'];
                    $jsonValue->roomcode->height=$value['P4'];
                    $jsonValue->roomcode->text=$value['P5'];
                    $jsonValue->roomcode->activateRoomCode=$value['P6'];

                    $jsonValue->roomcode->activateShowOnWallpaper=$value['P7'];
                    $jsonValue->roomcode->refreshTime=$value['P8'];
                    $jsonValue->roomcode->backgroundColor=$value['P9'];
                    $jsonValue->roomcode->borderColor=(isset($value['P10']) && !empty($value['P10']))?$value['P10']:'';
                    $jsonValue->roomcode->fontColor=$value['P11'];
                    $jsonValue->roomcode->fontSize=$value['P12'];
                    $jsonValue->roomcode->textAlign=$value['P13'];
                    $jsonValue->roomcode->opacity=$value['P14'];
                    $jsonValue->roomcode->showSecondDisplay=$value['P15'];
                    $jsonValue->roomcode->borderNoneChkbox=$value['P16'];
                    $jsonValue->roomcode->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                }
                if($value['Cmd']=='codepopup'){
                    $jsonValue->codepopup->posLeft=$value['P1'];
                    $jsonValue->codepopup->posTop=$value['P2'];
                    $jsonValue->codepopup->width=$value['P3'];
                    $jsonValue->codepopup->height=$value['P4'];
                    $jsonValue->codepopup->backgroundColor=$value['P5'];
                    $jsonValue->codepopup->borderColor=(isset($value['P6']) && !empty($value['P6']))?$value['P6']:'';
                    $jsonValue->codepopup->fontColor=$value['P7'];
                    $jsonValue->codepopup->fontSize=$value['P8'];
                    $jsonValue->codepopup->textAlign=$value['P9'];
                    $jsonValue->codepopup->opacity=$value['P10'];
                    $jsonValue->codepopup->borderNoneChkbox=$value['P16'];
                    $jsonValue->codepopup->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
                if($value['Cmd']=='date'){
                    $jsonValue->date->posLeft=$value['P1'];
                    $jsonValue->date->posTop=$value['P2'];
                    $jsonValue->date->width=$value['P3'];
                    $jsonValue->date->height=$value['P4'];
                    $jsonValue->date->activateDate=$value['P5'];
                    $jsonValue->date->dateFormat=$value['P6'];
                    $jsonValue->date->backgroundColor=$value['P7'];
                    $jsonValue->date->borderColor=(isset($value['P8']) && !empty($value['P8']))?$value['P8']:'';
                    $jsonValue->date->fontColor=$value['P9'];
                    $jsonValue->date->fontSize=$value['P10'];
                    $jsonValue->date->textAlign=$value['P11'];
                    $jsonValue->date->opacity=$value['P12'];
                    $jsonValue->date->borderNoneChkbox=$value['P16'];
                    $jsonValue->date->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                    $jsonValue->date->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
                if($value['Cmd']=='time'){
                    $jsonValue->time->posLeft=$value['P1'];
                    $jsonValue->time->posTop=$value['P2'];
                    $jsonValue->time->width=$value['P3'];
                    $jsonValue->time->height=$value['P4'];
                    $jsonValue->time->activateDate=$value['P5'];
                    $jsonValue->time->timeFormat=$value['P6'];
                    $jsonValue->time->backgroundColor=$value['P7'];
                    $jsonValue->time->borderColor=(isset($value['P8']) && !empty($value['P8']))?$value['P8']:'';
                    $jsonValue->time->fontColor=$value['P9'];
                    $jsonValue->time->fontSize=$value['P10'];
                    $jsonValue->time->textAlign=$value['P11'];
                    $jsonValue->time->opacity=$value['P12'];
                    $jsonValue->time->borderNoneChkbox=$value['P16'];
                    $jsonValue->time->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                    $jsonValue->time->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
                if($value['Cmd']=='datetimecombined'){
                    $jsonValue->datetimecombined->posLeft=$value['P1'];
                    $jsonValue->datetimecombined->posTop=$value['P2'];
                    $jsonValue->datetimecombined->width=$value['P3'];
                    $jsonValue->datetimecombined->height=$value['P4'];
                    $jsonValue->datetimecombined->activateDatetimecombined=$value['P5'];
                    $jsonValue->datetimecombined->dateTimeFormat=$value['P6'];
                    $jsonValue->datetimecombined->backgroundColor=$value['P7'];
                    $jsonValue->datetimecombined->borderColor=(isset($value['P8']) && !empty($value['P8']))?$value['P8']:'';
                    $jsonValue->datetimecombined->fontColor=$value['P9'];
                    $jsonValue->datetimecombined->fontSize=$value['P10'];
                    $jsonValue->datetimecombined->textAlign=$value['P11'];
                    $jsonValue->datetimecombined->opacity=$value['P12'];
                    $jsonValue->datetimecombined->borderNoneChkbox=$value['P16'];
                    $jsonValue->datetimecombined->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                    $jsonValue->datetimecombined->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
                if($value['Cmd']=='qrcode'){
                    $jsonValue->qrcode->posLeft=$value['P1'];
                    $jsonValue->qrcode->posTop=$value['P2'];
                    $jsonValue->qrcode->width=$value['P3'];
                    $jsonValue->qrcode->height=$value['P4'];
                    $jsonValue->qrcode->checkQrcodeFile=$value['P5'];
                    $jsonValue->qrcode->checkQrbypassFile=$value['P6'];
                    $jsonValue->qrcode->checkQrtopFile=$value['P7'];
                    $jsonValue->qrcode->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';

                }
                if($value['Cmd']=='upcomingmeetings'){
                    $jsonValue->upcomingmeetings->posLeft=$value['P1'];
                    $jsonValue->upcomingmeetings->posTop=$value['P2'];
                    $jsonValue->upcomingmeetings->width=$value['P3'];
                    $jsonValue->upcomingmeetings->height=$value['P4'];
                    $jsonValue->upcomingmeetings->showTitle=$value['P5'];
                    $jsonValue->upcomingmeetings->showOrganisor=$value['P6'];
                    $jsonValue->upcomingmeetings->meetingRecords=$value['P7'];
                    $jsonValue->upcomingmeetings->meetingupcomingEventsColor=$value['P8'];
                    $jsonValue->upcomingmeetings->meetinginuseEventsColor=$value['P9'];
                    $jsonValue->upcomingmeetings->meetingavailableEventsColor=$value['P10'];
                    $jsonValue->upcomingmeetings->meetingupcomingfontColor=$value['P11'];
                    $jsonValue->upcomingmeetings->meetinginusefontcolor=$value['P12'];
                    $jsonValue->upcomingmeetings->meetingavailablefontcolor=$value['P13'];
                    $jsonValue->upcomingmeetings->backgroundColor=$value['P14'];
                    $jsonValue->upcomingmeetings->meetingTitleBackgroundColor=$value['P15'];
                    $jsonValue->upcomingmeetings->meetingTitleFontColor=$value['P16'];
                    $jsonValue->upcomingmeetings->meetingTitleFontsize=$value['P17'];
                    $jsonValue->upcomingmeetings->meetingfontsize=$value['P17'];
                    $jsonValue->upcomingmeetings->opacity=$value['P18'];
                    $jsonValue->upcomingmeetings->timeFormat=$value['P19'];
                    $jsonValue->upcomingmeetings->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1'; 
                }
                if($value['Cmd']=='meetingnotify'){
                    $jsonValue->meetingnotify->posLeft=$value['P1'];
                    $jsonValue->meetingnotify->posTop=$value['P2'];
                    $jsonValue->meetingnotify->width=$value['P3'];
                    $jsonValue->meetingnotify->height=$value['P4'];
                    $jsonValue->meetingnotify->backgroundColor=$value['P5'];
                    $jsonValue->meetingnotify->borderColor=(isset($value['P6']) && !empty($value['P6']))?$value['P6']:'';
                    $jsonValue->meetingnotify->fontColor=$value['P7'];
                    $jsonValue->meetingnotify->topTextFontSize=$value['P8'];
                    $jsonValue->meetingnotify->middleTextFontSize=$value['P9'];
                    $jsonValue->meetingnotify->bottomTextFontSize=$value['P10'];
                    $jsonValue->meetingnotify->lineProperty=$value['P11'];
                    $jsonValue->meetingnotify->opacity=$value['P12'];
                    $jsonValue->meetingnotify->displayAlert=$value['P13'];
                    $jsonValue->meetingnotify->borderNoneChkbox=$value['P16'];
                    $jsonValue->meetingnotify->availability=$value['P17'];
                    $jsonValue->meetingnotify->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
                if(trim(substr($value['Cmd'],0,5))=='level'){
                    $jsonValue->{$value['Cmd']}->posLeft=$value['P1'];
                    $jsonValue->{$value['Cmd']}->posTop=$value['P2'];
                    $jsonValue->{$value['Cmd']}->width=$value['P3'];
                    $jsonValue->{$value['Cmd']}->height=$value['P4'];
                    $jsonValue->{$value['Cmd']}->text=$value['P5'];
                    $jsonValue->{$value['Cmd']}->backgroundColor=$value['P6'];
                    $jsonValue->{$value['Cmd']}->borderColor=(isset($value['P7']) && !empty($value['P7']))?$value['P7']:'';
                    $jsonValue->{$value['Cmd']}->fontColor=$value['P8'];
                    $jsonValue->{$value['Cmd']}->fontSize=$value['P9'];
                    $jsonValue->{$value['Cmd']}->textAlign=$value['P10'];
                    $jsonValue->{$value['Cmd']}->opacity=$value['P11'];
                    $jsonValue->{$value['Cmd']}->borderNoneChkbox=$value['P16'];
                    $jsonValue->{$value['Cmd']}->autoResize=(isset($value['P19']) && !empty($value['P19']))?$value['P19']:'1';
                    $jsonValue->{$value['Cmd']}->showSecondDisplay=(isset($value['P20']) && !empty($value['P20']))?$value['P20']:'1';
                }
            }

            $jsonContent = json_encode($jsonValue, JSON_PRETTY_PRINT);
            $jsonFile=$file.'.json';	
            $myfile = fopen($jsonFile, 'w') or die("can'ttt open file");
            $confWrite= fwrite($myfile, $jsonContent);
            fclose($myfile);
            unlink($xmlFile);
    }
		
	//for template preview from listing page
	public function templatePreviewAction(){
		$appObj = new ApplicationController();
		$this->layout('layout/template');
		$input=str_replace(' ','+',trim($_GET['imgID']));
		$templateid=$appObj->desDecrypt($input, KEY_SEED);
		$activewallpaperArr=$appObj->returnQueryData("SELECT wallpaper_name,template_name,json_name FROM tbl_templates WHERE id=$templateid");	
		foreach($activewallpaperArr as $activewallpaperData){
			$activewallpaper=UPLOAD_DIR_ZEND.'/'.$activewallpaperData['wallpaper_name'];
			$sessionImage=$activewallpaperData['wallpaper_name'];
			$templatename=$activewallpaperData['template_name'];
			$json_name=trim($activewallpaperData['json_name']);
		}
		$templatePreview=$templatename;
		//overwrite json_name  field on template_name.
		$templatename=($json_name!='')?$json_name:$templatename;
		$lang=(CHECK_FILE_LANGTXT==1)?$appObj->file_read(DEST_PATH.READFILE_LANGTXT):'en';
		return new ViewModel(array(
			'activewallpaper'=>$activewallpaper,
			'sessionImage'=>$sessionImage,
			'templatename'=>$templatename,
			'lang'=>$lang,
			'templatePreview'=>$templatePreview
			
		));				
	}
	
	//for template preview from inner pages
	public function templatePreviewInnerAction(){
		$this->layout('layout/template');
		$viewmodel = new ViewModel(array());
	}

	//for template preview from create page
	public function templatePreviewCreateAction(){
		$this->layout('layout/template');
		$viewmodel = new ViewModel(array());
	}
	
	public function setLayoutAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$tempid=trim($request->getPost('tempid'));
			$model_type=trim($request->getPost('model_type'));
			$grpIdStr=trim($request->getPost('grpId'));
			$grpIdArr = explode(',',$grpIdStr);
			//create default entry for unchecked grps	
			$uncheckedGrpIdStr=trim($request->getPost('uncheckedGrpIds'));
			$uncheckedGrpIdArr = explode(',',$uncheckedGrpIdStr);

			//Check for VSM and Gateway version check
			$statusVersion = $appObj->checkGatewayAndVSMVerion($grpIdStr);			
			if($statusVersion == 1){
				echo 2; die;
			}
			
			//deleting previously assigned templated for a group
			//$appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE entryType=0 AND isGrpIdOrDeviceId NOT IN ($grpIdStr)");
			$appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE template_id=$tempid AND entryType=0 AND model_type=$model_type AND isGrpIdOrDeviceId NOT IN ($grpIdStr)");
			foreach($grpIdArr as $grp){
				$os_qry = $appObj->returnQueryData("SELECT * FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId=$grp AND entryType=0 AND model_type=$model_type");
				if($os_qry->count()==0){
					$appObj->executeQueries("INSERT INTO tbl_templates_mapping (template_id,isGrpIdOrDeviceId,entryType,modifydatetime,model_type) VALUES($tempid,$grp,0,NOW(),$model_type)");
				}else{
					$appObj->executeQueries("UPDATE tbl_templates_mapping SET template_id=$tempid, isGrpIdOrDeviceId=$grp, modifydatetime=NOW() WHERE  isGrpIdOrDeviceId=$grp AND entryType=0 AND model_type=$model_type");
				}
			}
			
			//create default entry for unchecked grps	
			if($uncheckedGrpIds!=''){
				foreach($uncheckedGrpIdArr as $uncheckedGrpId){
					$checkUncheckGrpQry = $appObj->returnQueryData("SELECT * FROM  tbl_templates_mapping WHERE isGrpIdOrDeviceId=$uncheckedGrpId AND entryType=0 AND model_type=$model_type");
					if($checkUncheckGrpQry->count()==0){
							$appObj->executeQueries("INSERT INTO tbl_templates_mapping (template_id,isGrpIdOrDeviceId,entryType,modifydatetime,model_type) VALUES(1,$uncheckedGrpId,0,NOW(),$model_type)");				
					}
				}	
			}
			
			
			$gatewayIdArray = $this->getDeviceInventoryTable()->getDIDFromGroupId($grpIdStr);
			foreach ($gatewayIdArray as $key => $value) {
				$getGwayList .=$value['DID'].",";
			}
			$gwayList=rtrim($getGwayList,",");
			if($gwayList != ''){
				$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0 WHERE did_fk IN ($gwayList) AND wallpaper_status=1");
				$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($gwayList)");
				//Rabbit MQ Code
				$cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
				$cmdJson=json_encode($cmdArr);
				$producerObject=new WebProducerController();
				$producerObject->rabbitWebProducerAction($cmdJson);
			}
			
			
			echo "1";die;
		}
	}
	
	public function getLayoutDataAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$tempid=trim($request->getPost('tempid'));
			$model_type=trim($request->getPost('model_type'));
			$grp_qry = $appObj->returnQueryData("SELECT DISTINCT isGrpIdOrDeviceId FROM tbl_templates_mapping WHERE template_id=$tempid AND entryType=0 AND model_type=$model_type");
			if($grp_qry->count()>0){
				$grpArr = array();
				foreach($grp_qry as $grp){
					$grpArr[]= $grp['isGrpIdOrDeviceId'];
				}
				echo json_encode($grpArr);die;
			}
			echo "nodata";die;
		}
	}

	public function exitTemplateAction(){
		//Rabbit MQ Code
		$producerObject = new WebProducerController();
		$cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
		$cmdJson=json_encode($cmdArr);
		$producerObject->rabbitWebProducerAction($cmdJson);
		die;
	}
	//upload wallpaper for kds
	public function uploadWallpaperAction(){
		$appObj = new ApplicationController();
		//$model_type=$appObj->get_model_type();
		//$model_type=(PRODUCT=='via')?$appObj->get_model_type():1;
		if($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();
			$imgFile = $this->params()->fromFiles('uploadWallpaperFile');
			$wallpaperName = $imgFile['name'];	
			$uploadedMediaType = strtolower(substr($wallpaperName, strrpos($wallpaperName, '.') +1));
			$uploadPath=HTML_PUBLIC_DIR.'/'.IMG_DIR.'large/';
			$upload = move_uploaded_file($imgFile['tmp_name'], $uploadPath.$wallpaperName);
			
			$error='';
			if($upload) {
				$file_ext_array = explode("/",$imgFile['type']);
				$file_ext=strtolower($file_ext_array[1]);	 
				 if($file_ext == 'jpeg'){
					$file_ext = 'jpg';
				}
				
				//create wallpaper json
				list($wallpaperWidth, $wallpaperHeight) = getimagesize($uploadPath.$wallpOrignalName);
				//wallpaper json			
				$wallpaperJson=array("wallpaper"=>array('imagePath'=>IMG_DIR.'large/'.$templatename.$wallpOrignalName,'width'=>intval($wallpaperWidth).'px','height'=>intval($wallpaperHeight).'px'));
				$jsonValue->wallpaper=(object)$wallpaperJson;
				$encodedData = json_encode($wallpaperJson,true);	
				//encrypt json data		
				$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRYPTION_KEY);				
				$json_templateName = time().'.json';
				$json_templatePath = UPLOAD_DIR_ZEND."uploads/templates/".$json_templateName;
				//file_put_contents($myFile, $encodedData);				
				file_put_contents($json_templatePath, $encryptedJson);						
				
					
			
				$wallpaperData=array('template_name'=>$wallpaperName,'wallpaper_name'=>IMG_DIR.'large/'.$wallpaperName,'modifydatetime'=>date('Y-m-d H:i:s'),'model_type'=>PRODUCT_MODEL_TYPE,'json_name'=>$json_templateName);
				$lastInsertedId=$this->getTemplatesTable()->insertAndGetId($wallpaperData);
				$wallpOrignalName = 'F_'.$lastInsertedId.'.'.$uploadedMediaType;				
				//convert to png 
				if($file_ext=='gif' || $file_ext=='jpg'){
					$originalFile=$uploadPath.$wallpaperName;
					$outputFile=$uploadPath.'F_'.$lastInsertedId.'.png';
					$wallpOrignalName='F_'.$lastInsertedId.'.png';
					$appObj->convertImagePNG($originalFile, $outputFile, 100);									
				}			
				
				//update db record
				$updateData=array('template_name'=>$wallpOrignalName,'wallpaper_name'=>IMG_DIR.'large/'.$wallpOrignalName,'modifydatetime'=>date('Y-m-d H:i:s'));
				$where=array('id'=>$lastInsertedId);
				rename($uploadPath.$wallpaperName, $uploadPath.$wallpOrignalName);
				unlink($uploadPath.$wallpaperName);
				$this->getTemplatesTable()->updateData($updateData,$where);
				//$error='success';	
				$this->flashMessenger()->addMessage(STR_WALLPAPER_UPLOAD_MSG);	
				if(PRODUCT=='via'){				
					return $this->redirect()->toRoute('screeneditor',array('action' => 'template-list'));
				}else{
					return $this->redirect()->toRoute('wallpaper',array('action' => 'template-list'));
				}	

			}
		}
		
	}


	public function getNextTemplateIdAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$session_crsf_token=$session->offsetGet('crsf_token');			
			$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}
			$qryArr = $appObj->returnQueryData("SELECT last_value FROM tbl_templates_id_seq")->current(); 
			$newIdEnc=$appObj->desEncrypt($qryArr['last_value'], KEY_SEED);
			echo $newIdEnc;
		}
		die;
	}
	
	public function getTemplatesTable() {
		if (!$this->TblTemplatesTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblTemplatesTable = $sm->get('Webapp\Model\TblTemplatesTable');	
		}
		return $this->TblTemplatesTable;
	}
	
	public function getDevicegroupTable() {
		if(!$this->TblDevicegroupTable) {
			$sm = $this->getServiceLocator();
			$this->TblDevicegroupTable = $sm->get('Webapp\Model\TblDevicegroupTable');
		}
		return $this->TblDevicegroupTable;
	}

	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}
	
}