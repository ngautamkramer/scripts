<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\ViewModel;
use Webapp\Form\ViaConfigurationForm;
use Zend\Validator\File\Size;
use Zend\Validator\File\Extension;
use Zend\Validator\File\Rename;
use Zend\File\Transfer\Adapter\Http;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\FeatureController;
use Webapp\Controller\WebProducerController;
use ZipArchive;
class ManageConfigurationsController extends AbstractActionController {    
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		if(PRODUCT=='via'){
			$getSettingObj = $appObj->getComplexPasswordSettings();
			$getSettingData = $getSettingObj->webadmin_session_timeout;
		}else{
			$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
			foreach($tblSessionTimeOutDataArr as $sessiondata){
				$getSettingData=$sessiondata['logoutTime'];
			}
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if($tblSessionCheckdataArr->count()>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{
			//check if session timeout and click on refresh button of get audio and video device
			if(strpos($_SERVER['REQUEST_URI'], '/manageconfigurations/getAudioInputOutput') !== false) {
			    echo "sessionTimeOut"; die;
			}else{				
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

		 /*****
		 *	@Function Name: templateListAction
		 *  @description  : return table data
		 *	@Author		  : Ashu
		 *  @Date         : 08/May/2020
		 *****/
        public function templateListAction(){
            $session = new Container('userinfo');
            $user_id = $session->offsetGet('usrid');
			$loginName = $session->offsetGet('LoginName');
            $appObj = new ApplicationController();
            $settingValue = $appObj->getTableAllData('tbl_hq_configuration')->current();
			$configSettingVal = $settingValue['hq_configsetting'];
			$data=$this->getViaSettingsTemplatesTable()->fetchAll();	
			//pagination code
			$data->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
			$data->setItemCountPerPage(50);		
			
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				//Tree
				$result = $this->getDevicegroupTable()->fetchAll();
				$arrayCategories = array();
				foreach($result as $row){
					$arrayCategories[$row->DeviceGroupID] = array("grp_id" => $row->DeviceGroupID, "parent_id" => $row->DeviceMasterID, "name" =>$row->DeviceGroup, "level" =>$appObj->getDepth($row->DeviceGroupID));   
				}
				$user_grp_arr=array();
				if($user_id !=1){
					$deviceGroup = $this->getDevicegroupTable()->getGroupWithPermission($user_id);
				}	
			}			
			//Get groups with already set template
			//add check for via and vsm
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				$assignedGroupSql = $appObj->returnQueryData("SELECT B.DeviceGroup FROM tbl_via_settings_templates_mapping A INNER JOIN DeviceGroup B ON A.isGrpIdOrDeviceId=B.DeviceGroupID AND A.template_id<>1");
				foreach ($assignedGroupSql as $key => $value) {
					$assignedGroup[] = $value['DeviceGroup'];
				}
			}else{
				$assignedGroup=array();
			}		            
            return new ViewModel(array(   
				'data' => $data,
				'arrayCategories'=>$arrayCategories,
				'deviceGroup'=>$deviceGroup,
				'user_id'=>$user_id,
				'loginName'=>$loginName,
				'assignedGroup'=>$assignedGroup,
				'configSettingVal'=>$configSettingVal,					
            ));
        }

		 /*****
		 *	@Function Name: templateListAction
		 *  @description  : return table data
		 *	@Author		  : Ashu
		 *  @Date         : 08/May/2020
		 *****/
        public function createTemplateAction(){
            $session = new Container('userinfo');
            $user_id = $session->offsetGet('usrid');
            $loginName = $session->offsetGet('LoginName');
            $appObj = new ApplicationController();
			$langArr['option']=array('zh'=>'Chinese','en'=>"English",'de'=>"German",'ja'=>'Japanese','pl'=>'Polish','ru'=>"Russian",'es'=>'Spanish','fr'=>'French','pt'=>'Portuguese','zh-TW'=>'Traditional chinese');
			//3.3 bug fixing. make drop down as multilingual
			$displayLayoutArr['option'] = array(STR_DYNAMIC_LAYOUT_VIEW,STR_LEFT_THUMBNAIL_VIEW,STR_RIGHT_THUMBNAIL_VIEW,STR_BOTTOM_THUMBNAIL_VIEW,STR_FREE_FLOW);				
			$displayLayoutArr['sel'] = $layoutFileVal;
			$dpiFileValue=96;
			$langArr['sel'] = 'en';
			//$sessionTimeOutArray['option']=array('10'=>'10 Minute','20'=>'20 Minute','30'=>'30 Minute','60'=>'1 Hour','120'=>'2 Hours','360'=>'6 Hours','1440'=>'24 Hours');
			$sessionTimeOutArray['option'] = array('10'=>'10 Minute','20'=>'20 Minute','30'=>'30 Minute','60'=>'1 Hour','120'=>'2 Hours','360'=>'6 Hours','1440'=>'24 Hours');
			$sessionTimeOutArray['sel'] = 1440;
			$sleepArr['option']=array('5'=>5,'10'=>10,'30'=>30,'60'=>60,'120'=>120);
			$sleepArr['sel'] = 10;			
			$audiolevelArr['option']=array('10'=>'10%','20'=>'20%','30'=>'30%','40'=>'40%','50'=>'50%','60'=>'60%','70'=>'70%','80'=>'80%','90'=>'90%','100'=>'100%');		
			//Added by ashu on 25May2022. Now we are changing default audio from 80 to 100%	
			$audiolevelArr['sel'] = 100;			
			$audioOutputArr['option']=array('Analog Output'=>'Analog Output','HDMI'=>'HDMI','Display Port'=>'Display Port','USB'=>'USB');			
			$audioOutputArr['sel'] = 'HDMI';
			//add check for via and vsm
			$viaModel="";
			$modellike="";
			$modelshow='';
			$modelValue='';
			$deviceostype='';
			$maxCon_mirrorFile_data='';
			$mirror_name='';
			$viaServerIP='';
			$displayCount_content='';
			$clientOS='';
			$wifiMiracastFlag='';
			$supportMiracast='';
			$check_wifi='';
			$check_wifi_OnOff='';
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				$linuxTimezoneArray = $this->getTblTimezonesTable()->fetchAll(1);					
			}else{
				if(GET_OS=='LIN'){
					$linuxTimezoneArray = $this->getTblTimezonesTable()->fetchAll(" ");
				}
				$viaModel=$appObj->getModelNameByParam('model');
				$modellike=$appObj->getModelNameByParam('modellike');
				$modelshow=$appObj->getModelNameByParam('modelshow');	
				$modelValue=$appObj->getModelNameByParam('modelvalue');			
				$deviceostype=strtolower($appObj->getModelNameByParam('ostype'));
				$data = $appObj->getTableAllData('DeviceInventory')->current();
				$viaServerIP = $data['deviceip'];
				$mirror_name=trim($appObj->file_read(DEST_PATH . FILE_MIRRORNAME));
				$maxCon_mirrorFile_data=$appObj->file_read(DEST_PATH . FILE_MIRROR_MAXCON);
				if(CHECK_FILE_DISPLAYCOUNT == 1){
					$displayCount_content = $appObj->file_read(DEST_PATH.FILE_DISPLAYCOUNT);
				}				
				//for via versa
				$getos = $appObj->getClientOS();
				if(strstr($getos, 'Chrome OS')) {
					$clientOS = 'ChromeOS';
				} else if(strstr($getos, 'Mob_Window')) {
					$clientOS = 'windowsMobile';
				} else {
					$clientOS = strtoupper(substr($getos, 0, 3));
				}
				
				//getting value to allow wifi or miracast
				$wifiMiracastFlag=$appObj->allowMiracastAndWifi(DEST_PATH.'network.json');
				//getting miracast value from network.json. Now Miracast will be read from json not from file
				$networkJsonData=$appObj->readJsonFile(DEST_PATH.'network.json');
				$supportMiracast=($networkJsonData['Miracast']!='')?trim($networkJsonData['Miracast']):0;
				//getting network data. getting wifi on/off info
				$sessionNetworkData=$session->offsetGet('networkData');					
				$check_wifi=$sessionNetworkData['check_wifi'];
				$check_wifi_OnOff=$sessionNetworkData['check_wifi_OnOff'];				
			}
			
			if(isset($linuxTimezoneArray)){
				foreach($linuxTimezoneArray as $timezone) {
					$linuxTimezoneData['option'][$timezone['tz_name']] = $timezone['tz_name'];
					//if($timezone['tz_active_status'] == 1) {
					$linuxTimezoneData['sel'] = 'UTC';
					//}
				}
			}
			//add check for via and vsm
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				$windowsTimezoneArray = $this->getTblTimezonesTable()->fetchAll(2);
			}else{
				if(GET_OS=='WIN'){
					$windowsTimezoneArray = $this->getTblTimezonesTable()->fetchAll(" ");
				}	
			}		
			foreach($windowsTimezoneArray as $timezone) {
				$windowsTimezoneData['option'][$timezone['tz_name']] = $timezone['tz_name'];
				//if($timezone['tz_active_status'] == 1) {
				$windowsTimezoneData['sel'] = '(UTC) Coordinated Universal Time';
				//}
			}
			
			
			//$timezonesArr=$this->getTblTimezonesTable()->fetchAll(1);
			
			$formData = array('langArr' =>$langArr,
			'displayLayoutArr' =>$displayLayoutArr,
			'dpiFileValue' =>$dpiFileValue,
			'sessionTimeOutArray'=>$sessionTimeOutArray,
			'sleepArr'=>$sleepArr,
			'linuxTimezoneData' =>$linuxTimezoneData,
			'windowsTimezoneData' =>$windowsTimezoneData,
			'audiolevelArr' =>$audiolevelArr,
			'audioOutputArr' =>$audioOutputArr,
			'password_length'=>4,
			'logout_time'=>1440,		
			);
			
			$form = new ViaConfigurationForm($formData);
			//add check for via and vsm
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				//0 type
				$gwayfeaturesDataZeroType =$this->getTblGatewayFeaturesTable()->fetchAll(0);
				$clientfeaturesDataZeroType =$this->getTblClientFeaturesTable()->fetchAll(0);
				$mobilefeaturesDataZeroType =$this->getTblMobileFeaturesTable()->fetchAll(0);
				
				//1 type											
				$gwayfeaturesDataOneType =$this->getTblGatewayFeaturesTable()->fetchAll(1);		
				$clientfeaturesDataOneType =$this->getTblClientFeaturesTable()->fetchAll(1);
				$mobilefeaturesDataOneType =$this->getTblMobileFeaturesTable()->fetchAll(1);	
				//print_r($mobilefeaturesDataOneType);	die;									
				//2 type											
				$gwayfeaturesDataTwoType =$this->getTblGatewayFeaturesTable()->fetchAll(2);		
				$clientfeaturesDataTwoType =$this->getTblClientFeaturesTable()->fetchAll(2);
				$mobilefeaturesDataTwoType =$this->getTblMobileFeaturesTable()->fetchAll(2);
														
				//3type				
				$clientfeaturesDataThreeType =$this->getTblClientFeaturesTable()->fetchAll(3);
				$mobilefeaturesDataThreeType =$this->getTblMobileFeaturesTable()->fetchAll(3);	
				//4 type											
				$gwayfeaturesDataFourType =$this->getTblGatewayFeaturesTable()->fetchAll(4);		
				$clientfeaturesDataFourType =$this->getTblClientFeaturesTable()->fetchAll(4);
				$mobilefeaturesDataFourType =$this->getTblMobileFeaturesTable()->fetchAll(4);
			}else{
				if($modellike==3){
					$clientfeaturesDataThreeType =$this->getTblClientFeaturesTable()->fetchAll(3);
					$mobilefeaturesDataThreeType =$this->getTblMobileFeaturesTable()->fetchAll(3);
				}elseif($modellike==0){
					$gwayfeaturesDataZeroType =$this->getTblGatewayFeaturesTable()->fetchAll(0);				
					$clientfeaturesDataZeroType =$this->getTblClientFeaturesTable()->fetchAll(0);				
					$mobilefeaturesDataZeroType =$this->getTblMobileFeaturesTable()->fetchAll(0);				
				}elseif($modellike==1){
					$gwayfeaturesDataOneType =$this->getTblGatewayFeaturesTable()->fetchAll(1);		
					$clientfeaturesDataOneType =$this->getTblClientFeaturesTable()->fetchAll(1);
					$mobilefeaturesDataOneType =$this->getTblMobileFeaturesTable()->fetchAll(1);					
				}elseif($modellike==2){
					$gwayfeaturesDataTwoType =$this->getTblGatewayFeaturesTable()->fetchAll(2);		
					$clientfeaturesDataTwoType =$this->getTblClientFeaturesTable()->fetchAll(2);
					$mobilefeaturesDataTwoType =$this->getTblMobileFeaturesTable()->fetchAll(2);				
				}elseif($modellike==4){
					$gwayfeaturesDataFourType =$this->getTblGatewayFeaturesTable()->fetchAll(4);		
					$clientfeaturesDataFourType =$this->getTblClientFeaturesTable()->fetchAll(4);
					$mobilefeaturesDataFourType =$this->getTblMobileFeaturesTable()->fetchAll(4);			
				}
			
			}
			//print_r($mobilefeaturesDataThreeType);	die;	
			//$gwayfeaturesData =$this->getTblGatewayFeaturesTable()->fetchAll();		
			//$clientfeaturesData =$this->getTblClientFeaturesTable()->fetchAll();
			//$mobilefeaturesData =$this->getTblMobileFeaturesTable()->fetchAll();	
			
		
 		//File sharing	
		$fileFormatFile = UPLOAD_PATH_INTERNAL.'auth_fileformat_'.$loginName.'.txt';
		if(file_exists($fileFormatFile)){
			$fileContent = file_get_contents($fileFormatFile);
			$fileDataArr = (array)json_decode($fileContent);
			$sel = 0;
			foreach ($fileDataArr as $key => $value) {
				if($value->ext_name != 'All'){
					if($value->status == 1){
						$selectedFileFormatArr[$key] = $value->ext_name;
					}
				}
				if($value->ext_name == 'All'){
					$selAll = $value->status;
					if($value->status == 0){
						$sel = 1;
					}else{
						$sel = 0;
					}
				}
				if($value->ext_name == 'All' || $value->ext_name == 'jpeg' || $value->ext_name == 'pdf' || $value->ext_name == 'png' || $value->ext_name == 'jpg'){
					continue;
				}else{
					$fileFormatArr[$key]['ext_name'] = $value->ext_name;
					$fileFormatArr[$key]['status'] = $value->status;
				}
			}
			if($sel ==1){
				$fileFormat = 'selected';
			}else{
				$fileFormat = 'all';
			}
		}else{
			$fileFormatData = $this->getAuthFileFormatTable()->fetchAllData();
			$fileFormat = 'all';
			$new_formatArr = array();
			foreach ($fileFormatData as $key => $value) {
				$new_formatArr[$key]['ext_name'] = $value['fileformat'];
				$new_formatArr[$key]['status'] = $value['formatstatus'];
				if($value['fileformat'] == 'All' || $value['fileformat'] == 'jpeg' || $value['fileformat'] == 'pdf' || $value['fileformat'] == 'png' || $value['fileformat'] == 'jpg'){
					continue;
				}else{
					$fileFormatArr[$key]['ext_name'] = $value['fileformat'];
					$fileFormatArr[$key]['status'] = $value['formatstatus'];
				}
				if($value['fileformat'] != 'All' && $value['formatstatus'] == 1){
					$selectedFileFormatArr[$key]['ext_name'] = $value['fileformat'];
					$selectedFileFormatArr[$key]['status'] = $value['formatstatus'];
				}
				if($value['fileformat'] == 'All'){
					$selAll = $value['formatstatus'];
				}
			}
			$fp = fopen($fileFormatFile, 'w');
			fwrite($fp, json_encode($new_formatArr));
			fclose($fp);
		}
		
		$resetSessionConfigStatus = $this->getAdvanceMoreFeaturesTable()->fetchProperty('ResetSession');
		//Get NTP data
		//$getNTPSql = $this->getTblNtpServerTable()->fetchAll();
		$ntpFile = BASE_PATH.'/public/uploads/ntp_'.$loginName.'.txt';
		if(file_exists($ntpFile)){
			$fileContent = file_get_contents($ntpFile);
			$ntpDataArr = (array)json_decode($fileContent);
		}

		if(CHECK_FILE_ASSOCIATE_FILE == 1){
			$get_whiteBoardAssociateFileContent=$appObj->file_read(DEST_PATH.FILE_ASSOCIATE_FILE);
		}else{
			$get_whiteBoardAssociateFileContent = '';
		}
		if(CHECK_FILE_BROWSE_ASSOCIATE==1){
			$get_browseAssociateFileContent=$appObj->file_read(DEST_PATH.FILE_BROWSE_ASSOCIATE);
		}else{
			$get_browseAssociateFileContent = '';
		}
		
		$getTemplateName=$appObj->getVIASettingsNextTemplateName();					
						
		return new ViewModel(array('form' => $form,'collageGwayfeaturesData'=>$gwayfeaturesDataZeroType,'collageClientfeaturesData'=>$clientfeaturesDataZeroType,'collageMobilefeaturesData'=>$mobilefeaturesDataZeroType,'connectGwayfeaturesData'=>$gwayfeaturesDataOneType,'connectClientfeaturesData'=>$clientfeaturesDataOneType,'connectMobilefeaturesData'=>$mobilefeaturesDataOneType,'campusGwayfeaturesData'=>$gwayfeaturesDataTwoType,'campusClientfeaturesData'=>$clientfeaturesDataTwoType,'campusMobilefeaturesData'=>$mobilefeaturesDataTwoType,'viagoClientfeaturesData'=>$clientfeaturesDataThreeType,'viagoMobilefeaturesData'=>$mobilefeaturesDataThreeType,'connectplusGwayfeaturesData'=>$gwayfeaturesDataFourType,'connectplusClientfeaturesData'=>$clientfeaturesDataFourType,'connectplusMobilefeaturesData'=>$mobilefeaturesDataFourType,'fileFormat' => $fileFormat, 'fileFormatArr' => $fileFormatArr, 'selAll' => $selAll, 'selectedFileFormatArr' => $selectedFileFormatArr,'ntpDataArr'=>$ntpDataArr,'custTempName'=>$getTemplateName,'viaModel'=>$viaModel,'mirror_name'=>$mirror_name,'maxCon_mirrorFile_data'=>$maxCon_mirrorFile_data,'displayCount_content'=>$displayCount_content,'deviceostype'=>$deviceostype,'viaServerIP'=>$viaServerIP,'modellike'=>$modellike,'modelshow'=>$modelshow,'get_whiteBoardAssociateFileContent' => $get_whiteBoardAssociateFileContent,'get_browseAssociateFileContent' => $get_browseAssociateFileContent,'clientOS'=>$clientOS,'supportMiracast'=>$supportMiracast,'wifiMiracastFlag'=>$wifiMiracastFlag,'check_wifi'=>$check_wifi,'check_wifi_OnOff'=>$check_wifi_OnOff,'modelValue'=>$modelValue));
        }
		//ajax call for get timezones
		public function getTimezonesAction(){
			$getTimezoneType=trim($_POST['getTimezoneType']);
			$timezoneArray = $this->getTblTimezonesTable()->fetchAll($getTimezoneType);
			$str='<div class="selectdiv"><select name="timezoneConfigBox" id="timezoneConfigBox" class="form-control m-b makeDisabled styl">';
			foreach($timezoneArray as $timezone) {
				$str.='<option value='.$timezone['tz_name'].'>'.$timezone['tz_name'].'</option>';
			}
			echo $str.='</select><label class="ddlabelCss">Set Time Zone</label></div>';			
			die;
		}
		
		
		//ajax call to save template
		public function saveTemplateAction(){
            $session = new Container('userinfo');
            $user_id = $session->offsetGet('usrid');
            $loginName = $session->offsetGet('LoginName');
			//get crsf value from session
			$session_crsf_token=$session->offsetGet('crsf_token');
			
			$appObj = new ApplicationController();
			$flag=trim($_POST['flag']);
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				$viaModel='';
				$modellike='';
				$model_type='';
				$modelValue='';
			}else{
				$viaModel=$appObj->getModelNameByParam('model');
				$modellike=$appObj->getModelNameByParam('modellike');
				$modelValue=$appObj->getModelNameByParam('modelvalue');
				$model_type=$appObj->get_model_type();
				//getting hostname from session
				$sessionNetworkData=$session->offsetGet('networkData');
				$get_hostname= !empty($sessionNetworkData['Lan1_Host'])?$sessionNetworkData['Lan1_Host']:$sessionNetworkData['wifi1_Host'];
				//get screen editor active template
				/*$getActivateTemplateQryData=$appObj->returnQueryData("SELECT template_name,json_name FROM `tbl_templates` WHERE status=1");				
				foreach($getActivateTemplateQryData as $activateTempArr) {					
					$get_activeTemplate = ($activateTempArr['json_name']!=NULL)?TEMPLATE_DIR_ZEND.$activateTempArr['json_name']:TEMPLATE_DIR_ZEND.$activateTempArr['template_name'].'.json';
					$get_response = file_get_contents($get_activeTemplate);
					//decrypt json
					$get_decryptResponse=$appObj->desDecrypt($get_response,POLL_ENCRYPTION_KEY);		
					$get_jsonArray=json_decode($get_decryptResponse, true);
					$get_dnsname=$get_jsonArray['roomname1']['customNameText'];
				}*/
				//Now we are getting dns name from roomnamevalueshow.txt and upgrading it into settings template
				if(file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)){
					$get_dnsname=trim(file_get_contents(DEST_PATH.READFILE_ROOMNAMEVALUESHOW));
				}
			}
			
			//$defaultFilesFoermatArr =$this->getAuthFileFormatTable()->fetchAll(1);	
			//$authFileStr=implode(',',$defaultFilesFoermatArr);
			$ntpJsonFile='ntp_'.$loginName.'.txt';
			$fileSharingJsonFile='auth_fileformat_'.$loginName.'.txt';
			if(file_exists(UPLOAD_PATH_INTERNAL.$ntpJsonFile)){
				$strJsonNTP=file_get_contents(UPLOAD_PATH_INTERNAL.$ntpJsonFile);			
				$arrayJsonNTP = (array)json_decode($strJsonNTP);		
				foreach ($arrayJsonNTP as $key=>$value){ 				
				 $arrayJsonNTP[$key] = (array) $value;
				}	
				$ntpArray=array();
				
				foreach ($arrayJsonNTP as $ntp_key=>$ntp_value){ 
					$ntpArray[]=array("ntp_name"=>$ntp_value['ntp_name'],"ntp_uuid"=>$ntp_value['ntp_uuid']);
				}
			}		
					
			//die();
			$fileSharing=trim($_POST['fileSharing']);
			if(file_exists(UPLOAD_PATH_INTERNAL.$fileSharingJsonFile)){
				$strJsonAuthFormats=file_get_contents(UPLOAD_PATH_INTERNAL.$fileSharingJsonFile);
				$arrayJsonAuthFormats = (array)json_decode($strJsonAuthFormats);
				foreach ($arrayJsonAuthFormats as $authFilekey=>$authFilevalue){ 				
					$arrayJsonAuthFile[$authFilekey] = (array) $authFilevalue;
				}
				$authFileArray=array();
				foreach ($arrayJsonAuthFile as $authfile_key=>$authfile_value){
					if($authfile_value['ext_name']=='jpeg' || $authfile_value['ext_name']=='pdf' || $authfile_value['ext_name']=='png' || $authfile_value['ext_name']=='jpg'){
						$authStatus = 1;
					}else{
						$authStatus=$authfile_value['status'];
					}
					$authFileArray[]=array("ext_name"=>$authfile_value['ext_name'],"status"=>"$authStatus");	
				}	
			}

			//check if auth_fileformat_'.$loginName.'.txt exist or auth_fileformat_'.$loginName.'.txt exist but data is blank
			if(PRODUCT_TYPE == "via" && empty($authFileArray)){
				$authFileArray = $appObj->addFileExtensionIfBlank();
			}
				
			$sysLog=(trim($_POST['sysLog'])!='')?trim($_POST['sysLog']):0;
			$energysaver=trim($_POST['energysaver']);
			$sleepTime=($energysaver==1)?trim($_POST['sleepTime']):"0";
			$quickClientAccess=(trim($_POST['quickClientAccess'])!='')?trim($_POST['quickClientAccess']):0;
			$activateDisableOnTop=(trim($_POST['activateDisableOnTop'])!='')?trim($_POST['activateDisableOnTop']):1;
			$apiCmd=trim($_POST['apiCmd']);
			$setLang=trim($_POST['setLang']);
			$broadcast=trim($_POST['broadcast']);
			$auto_broadcast=trim($_POST['auto_boradcast']);
			$boradcast_via_dataoversound=trim($_POST['boradcast_via_dataoversound']);
			$boradcast_via_bluetooth=trim($_POST['boradcast_via_bluetooth']);
			
			$mirroring=trim($_POST['mirroring']);
			$chrome=trim($_POST['chrome']);
			$runVia=trim($_POST['runVia']);
			$installVia=trim($_POST['installVia']);
			$miracast=trim($_POST['miracast']);
			$frequency=trim($_POST['frequency']);
			$activateDNDChkbox=trim($_POST['activateDNDChkbox']);
			$resetSession=trim($_POST['resetSession']);	
			$encoding=(trim($_POST['encoding'])==1)?'h264':'jpeg';
			$autoPowerOff=trim($_POST['autoPowerOff']);			
			$selhoursdd=trim($_POST['selhoursdd']);
			$selminsdd=trim($_POST['selminsdd']);
			$autoPowerOffTime=($autoPowerOff==1)?$selhoursdd.':'.$selminsdd:'00:00';
			
			$autoReboot=trim($_POST['autoReboot']);
			$selAutoRebootHoursList=trim($_POST['selAutoRebootHoursList']);
			$selAutoRebootMinsList=trim($_POST['selAutoRebootMinsList']);
			$autoRebootTime=($autoReboot==1)?$selAutoRebootHoursList.':'.$selAutoRebootMinsList:'00:00';
			
			$autoPowerOn=trim($_POST['autoPowerOn']);
			$selAutoPowerOnHoursList=trim($_POST['selAutoPowerOnHoursList']);
			$selAutoPowerOnMinsList=trim($_POST['selAutoPowerOnMinsList']);
			$autoPowerOnTime=($autoPowerOn==1)?$selAutoPowerOnHoursList.':'.$selAutoPowerOnMinsList:'00:00';
			
			$selDateFormatDD=trim($_POST['selDateFormatDD']);
			$timezoneConfigBox=trim($_POST['timezoneConfigBox']);
			$winTimezoneConfigBox=trim($_POST['winTimezoneConfigBox']);
			$hdmiInputNotStart=trim($_POST['hdmiInputNotStart']);
			$pipMode=trim($_POST['pipMode']);
			$activateHDMIChkbox=trim($_POST['activateHDMIChkbox']);
			$manualOnOff=trim($_POST['manualOnOff']);
			$clearCloud=trim($_POST['clearCloud']);
			$closeWhiteBoardBtn=trim($_POST['closeWhiteBoardBtn']);
			
			$setDynamicLayout=trim($_POST['setDynamicLayout']);
			$dynamicLayoutChkbox=trim($_POST['dynamicLayoutChkbox']);
			$dpiConfigBox=trim($_POST['dpiConfigBox']);
			$logoutTime=trim($_POST['logoutTime']);
			$getCaptcha=trim($_POST['getCaptcha']);
			$getAlplhanumric=trim($_POST['getAlplhanumric']);
			$getSpecialChar=trim($_POST['getSpecialChar']);
			$getCaptLetter=trim($_POST['getCaptLetter']);
			
			$minimumChar=trim($_POST['minimumChar']);
			$getBasicModeFlag=trim($_POST['getBasicModeFlag']);
			$transferRecording=trim($_POST['transferRecording']);
			$getRecording=trim($_POST['getRecording']);

			$proxyServerName=trim($_POST['proxyServerName']);
			$proxyServerName = str_replace(['http://', 'https://', 'http:/', 'https:/'], '', $proxyServerName); 

			$proxyPort=trim($_POST['proxyPort']);
			$proxyUserName=trim($_POST['proxyUserName']);
			$proxyPassword=trim($_POST['proxyPassword']);
			$host_config=trim($_POST['host_config']);
			$via_certificate=trim($_POST['via_certificate']);
			$certificateKey=trim($_POST['certificateKey']);
			$audioOutput=trim($_POST['audioOutput']);
			$audioLevel=trim($_POST['audioLevel']);
			
			$zoomVal=trim($_POST['zoomVal']);
			$bluejeansVal=trim($_POST['bluejeansVal']);
			$msTeamVal=trim($_POST['msTeamVal']);
			$TPCollabAppCloseVal=trim($_POST['TPCollabAppCloseVal']);
			$thirdpartyapp=trim($_POST['thirdpartyapp']);
			$hideViaAdmin=trim($_POST['viaAdmin']);
			$mediamode=trim($_POST['mediamode']);
			//presenattion changes
			$autoDND=trim($_POST['autoDND']);
			$hdmitovmd=trim($_POST['hdmitovmd']);
			$annotation=trim($_POST['annotation']);
			$publicAnnotation=trim($_POST['publicAnnotation']);
			$presentationFullScreen=trim($_POST['presentationFullScreen']);

			// code added to get auto disconnection data -- niraj gautam on 16Aug 2022
			$autoDisconnection=trim($_POST['autoDisconnection']);
			$autoDisconnectionDeviation=trim($_POST['autoDisconnectionDeviation']);
			$autoDisconnectionAttempts=trim($_POST['autoDisconnectionAttempts']);
			$autoDisconnectionAvgcount=trim($_POST['autoDisconnectionAvgcount']);
			// end code added to get auto disconnection data -- niraj gautam on 16Aug 2022

			$confercingMode=trim($_POST['confercingMode']);
			$showUsername=trim($_POST['showUsername']);
			$viaversa=trim($_POST['viaversa']);
			$activateHDMICameraChkbox=trim($_POST['activateHDMICameraChkbox']);
			
			$collageGwayfeaturesStr=trim(substr($_POST['collageGwayfeaturesStr'],0,-1));
			$collageClientfeaturesStr=trim(substr($_POST['collageClientfeaturesStr'],0,-1));
			$collageMobfeaturesStr=trim(substr($_POST['collageMobfeaturesStr'],0,-1));
			
			$connectGwayfeaturesStr=trim(substr($_POST['connectGwayfeaturesStr'],0,-1));
			$connectClientfeaturesStr=trim(substr($_POST['connectClientfeaturesStr'],0,-1));
			$connectMobfeaturesStr=trim(substr($_POST['connectMobfeaturesStr'],0,-1));
			
			$campusGwayfeaturesStr=trim(substr($_POST['campusGwayfeaturesStr'],0,-1));
			$campusClientfeaturesStr=trim(substr($_POST['campusClientfeaturesStr'],0,-1));			
			$campusMobfeaturesStr=trim(substr($_POST['campusMobfeaturesStr'],0,-1));
			
			$viagoClientfeaturesStr=trim(substr($_POST['viagoClientfeaturesStr'],0,-1));
			$viagoMobfeaturesStr=trim(substr($_POST['viagoMobfeaturesStr'],0,-1));
			
			$connectplusGwayfeaturesStr=trim(substr($_POST['connectplusGwayfeaturesStr'],0,-1));			
			$connectplusClintfeaturesStr=trim(substr($_POST['connectplusClintfeaturesStr'],0,-1));
			$connectplusMobfeaturesStr=trim(substr($_POST['connectplusMobfeaturesStr'],0,-1));
			//added by Ashu on 15Jun2023 for adding V9 tag for VIAGo2 if not found
			if($modellike==3 && $flag=='edit'){	
				if(!strstr($viagoClientfeaturesStr,'V9')){				
					$viagoClientfeaturesStr=$viagoClientfeaturesStr.'#V9$1';
				}
				if(!strstr($viagoMobfeaturesStr,'V9')){				
					$viagoMobfeaturesStr=$viagoMobfeaturesStr.'#V9$1';
				}
			}
			
			$moderatorString=trim($_POST['moderatorString']);
			$presentationMode=trim($_POST['collagePresentaionMode']);
			$moderator_type=trim($_POST['collageMode']);
			$collageParticipantConfChkbox=trim($_POST['collageParticipantConfChkbox']);
			$participantConfChkbox=trim($_POST['collageParticipantConfChkbox']);
			$wait_moderator=trim($_POST['collageDisableAllFeaturesChkbox']);
			$activateChatChkbox=trim($_POST['collageActivateChatChkbox']);
			$adDomain=trim($_POST['collageAdDomain']);
			$accountName=trim($_POST['collageAccName']);
			$group_ou=trim($_POST['collageOuGroupBased']);
			$moderatorValue=trim($_POST['collageAdModerator']);
			$participantValue=trim($_POST['collageAdParticipant']);			
			$viaAdminPassword=(trim($_POST['viaAdminPassword'])!='')?$appObj->securePassword(trim($_POST['viaAdminPassword'])):'';
			$viaBasicPassword=(trim($_POST['viaBasicPassword'])!='')?$appObj->securePassword(trim($_POST['viaBasicPassword'])):'';
			$templateName=htmlspecialchars(trim($_POST['templateName']));
			$historyFlag="Create";
			//changes for single code
			$mirrorName=htmlspecialchars(trim($_POST['mirrorName']));
			$maxNoOfMirrors=trim($_POST['maxNoOfMirrors']);
			$reserved_screen=trim($_POST['reserved_screen']);
			$via_roomname=trim($_POST['via_roomname']);
			// added by niraj
			$via_roomname_type = trim($_POST['via_roomname_type']);
			//end
			//miracast->inframode Changess
			$inframode=trim($_POST['inframode']);
			$crsf_tokenval=trim($_POST['crsf_tokenval']);
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			//getting new tempflag Req
			$newtempflagReq=trim($_POST['newtempflagReq']);
			if(PRODUCT=='via'){		
				//added by ashu on 1Feb22 for making auto_broadcast enabled if broadcast setting is active		
				if($modelValue==1 || $modelValue==2 || $modelValue==3 || $modelValue==4 || $modelValue==5 || $modelValue==6 || $modelValue==7 || $modelValue==10){
					$auto_broadcast=($broadcast==1)?"1":"0";
				}
			
			
				if(file_exists(DEST_PATH.FILE_ASSOCIATE_FILE)){
					$get_whiteBoardAssociateFileContent=$appObj->file_read(DEST_PATH.FILE_ASSOCIATE_FILE);
					$chk_whiteboard = 1;
					$whiteboard_content = $get_whiteBoardAssociateFileContent;
				}else{
					$chk_whiteboard = 0;
					$whiteboard_content = '';
				}
				if(file_exists(DEST_PATH.FILE_BROWSE_ASSOCIATE)){
					$get_browseAssociateFileContent=$appObj->file_read(DEST_PATH.FILE_BROWSE_ASSOCIATE);
					$chk_browser = 1;
					$browser_content = $get_browseAssociateFileContent;
				}else{
					$chk_browser = 0;
					$browser_content = '';
				}
			}
			$myFile = UPLOAD_DIR_ZEND."uploads/".TEMPLATE_DIR_CONFIG.$templateName.'.json';
			if($flag=='edit'){
				$historyFlag="Update";
				$intTemplateId=trim($_POST['id']);
				$encryptedTempId=trim($_POST['id']);
				$input=str_replace(' ','+',trim($encryptedTempId));
				$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
				$intTemplateId=$appObj->desDecrypt($input, KEY_SEED);				
				//check template exist or not
				$countTemplate=$appObj->returnQueryData("SELECT * FROM tbl_via_settings_templates WHERE template_name ILIKE '$templateName' AND id!=$intTemplateId");
				if(count($countTemplate)>0){
					die('templateexist');
				}
				
				//getting template info based on id
				$getTemplateData=$appObj->returnQueryData("SELECT template_name,template_path FROM tbl_via_settings_templates WHERE id=$intTemplateId");
				foreach($getTemplateData as $arrTemplateData){
					$templatePath=$arrTemplateData['template_path'];
					$settingTemplateName=$arrTemplateData['template_name'];
				}
				//$explodeTemplatePath=explode('/',$templatePath);
				//$dbTemplateName=$explodeTemplatePath[2];
				$myFile = UPLOAD_DIR_ZEND.$templatePath;				
				//if user not update previous password then updating with his previous pass
				$viaAdminPassword=(trim($_POST['viaAdminPassword'])=='......' || trim($_POST['viaAdminPassword'])=="")?trim($_POST['passAdminpass']):$appObj->securePassword(trim($_POST['viaAdminPassword']));
				
				//changes on 22July20
				// now if user not update password then updating with his previous pass also if pass is blank then blank pass will be sent in case of basic pass
				if(trim($_POST['viaBasicPassword'])=='......'){
					$viaBasicPassword=trim($_POST['passBasicModePass']);
				}elseif(trim($_POST['viaBasicPassword'])==''){
					$viaBasicPassword='';
				}else{
					$viaBasicPassword=$appObj->securePassword(trim($_POST['viaBasicPassword']));
				}
				//die($viaAdminPassword." and ".$viaBasicPassword);
				//single code changes 
				if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
					$getTempltInfoSql=$appObj->returnQueryData("SELECT B.DID,B.DeviceName,A.isGrpIdOrDeviceId,A.template_id,A.entryType,B.os_type FROM tbl_via_settings_templates_mapping A INNER JOIN DeviceInventory B ON A.isGrpIdOrDeviceId=B.DeviceGroupID WHERE A.template_id=$intTemplateId AND A.entryType=0");	
					$gatewayStrBygrp='';
					$gatewayStr='';
					if($getTempltInfoSql->count()>0){
						foreach($getTempltInfoSql as $arrayData){
							$gwayList.=$arrayData["DID"].',';
						}//end foreach loop
						$gatewayStrBygrp = rtrim($gwayList,",");
						if($gatewayStrBygrp!=''){
							$getGwayList=implode(',',array_unique(explode(',', $gatewayStrBygrp)));
							//now we are changing the query. Now configSettingStatus will be change for those records which value is not 2. fixed bug id 0013661 and 0013722
							$appObj->executeQueries("UPDATE tbl_sys_report SET configSettingStatus=0 WHERE did_fk IN ($getGwayList) AND configSettingStatus!=2");
							$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($getGwayList)");
						}
					}
				}	
			}
			if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"always_on_top"=>$activateDisableOnTop,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>array("status"=>$broadcast,"autobroadcast"=>$auto_broadcast,"dataoversound"=>$boradcast_via_dataoversound,"bluetooth"=>$boradcast_via_bluetooth),
				"thirdparty_app"=>$thirdpartyapp,"hide_viaAdmin"=>$hideViaAdmin,"versa_mode"=>$viaversa),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,"run_via"=>$runVia,"install_via"=>$installVia,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency,"inframode"=>$inframode),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode,"hdmi_to_vmd"=>$hdmitovmd,"auto_dnd"=>$autoDND,"vmd"=>array("annotation"=>$annotation,"public_annotation"=>$publicAnnotation),"always_full_scr"=>$presentationFullScreen, "confmod"=>$confercingMode,"show_user_name"=>$showUsername,"reserved_screen"=>$reserved_screen,"auto_disconnection" => array("status" => $autoDisconnection, "deviation" => $autoDisconnectionDeviation, "attempts" =>$autoDisconnectionAttempts, "avgcount" => $autoDisconnectionAvgcount)),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff,'hdmi_camera'=>$activateHDMICameraChkbox),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"gway_features"=>array('4'=>$connectplusGwayfeaturesStr,'2'=>$campusGwayfeaturesStr,'1'=>$connectGwayfeaturesStr,'0'=>$collageGwayfeaturesStr),
				"client_features"=>array('4'=>$connectplusClintfeaturesStr,'3'=>$viagoClientfeaturesStr,'2'=>$campusClientfeaturesStr,'1'=>$connectClientfeaturesStr,'0'=>$collageClientfeaturesStr),
				"mobile_features"=>array('4'=>$connectplusMobfeaturesStr,'3'=>$viagoMobfeaturesStr,'2'=>$campusMobfeaturesStr,'1'=>$connectMobfeaturesStr,'0'=>$collageMobfeaturesStr),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal)
				)
				);
			
			}elseif($modellike==0){	
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"always_on_top"=>$activateDisableOnTop,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>array("status"=>$broadcast,"autobroadcast"=>$auto_broadcast,"dataoversound"=>$boradcast_via_dataoversound,"bluetooth"=>$boradcast_via_bluetooth),
				"thirdparty_app"=>$thirdpartyapp,"hide_viaAdmin"=>$hideViaAdmin,"versa_mode"=>$viaversa,"via_roomname_type" => $via_roomname_type),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,"run_via"=>$runVia,"install_via"=>$installVia,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency,"inframode"=>$inframode),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode,"hdmi_to_vmd"=>$hdmitovmd,"auto_dnd"=>$autoDND,"vmd"=>array("annotation"=>$annotation,"public_annotation"=>$publicAnnotation),"always_full_scr"=>$presentationFullScreen,"confmod"=>$confercingMode,"show_user_name"=>$showUsername,"reserved_screen"=>$reserved_screen,"auto_disconnection" => array("status" => $autoDisconnection, "deviation" => $autoDisconnectionDeviation, "attempts" =>$autoDisconnectionAttempts, "avgcount" => $autoDisconnectionAvgcount)),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff,'hdmi_camera'=>$activateHDMICameraChkbox),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"assoc_software"=>array("assoc_whitboard"=>$chk_whiteboard,"whiteboard_content"=>$whiteboard_content,"assoc_browser"=>$chk_browser,"browser_content"=>$browser_content),
				"gway_features"=>(object)[0=>$collageGwayfeaturesStr],
				"client_features"=>(object)[0=>$collageClientfeaturesStr],
				"mobile_features"=>(object)[0=>$collageMobfeaturesStr],
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName,'hostname'=>$get_hostname,'dnsname'=>$via_roomname,'GroupID'=>'','groupName'=>''),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal),
				"business_hours"=>array("via_start_time"=>"09:00:00","via_end_time"=>"18:00:00","kds_start_time"=>"09:00:00","kds_end_time"=>"09:00:00")
				)
				);			
			}elseif($modellike==1){
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"always_on_top"=>$activateDisableOnTop,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>array("status"=>$broadcast,"autobroadcast"=>$auto_broadcast,"dataoversound"=>$boradcast_via_dataoversound,"bluetooth"=>$boradcast_via_bluetooth),
				"thirdparty_app"=>$thirdpartyapp,"hide_viaAdmin"=>$hideViaAdmin,"versa_mode"=>$viaversa,"via_roomname_type" => $via_roomname_type),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,"run_via"=>$runVia,"install_via"=>$installVia,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency,"inframode"=>$inframode),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode,"hdmi_to_vmd"=>$hdmitovmd,"auto_dnd"=>$autoDND,"vmd"=>array("annotation"=>$annotation,"public_annotation"=>$publicAnnotation),"always_full_scr"=>$presentationFullScreen,"confmod"=>$confercingMode,"show_user_name"=>$showUsername,"reserved_screen"=>$reserved_screen,"auto_disconnection" => array("status" => $autoDisconnection, "deviation" => $autoDisconnectionDeviation, "attempts" =>$autoDisconnectionAttempts, "avgcount" => $autoDisconnectionAvgcount)),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff,'hdmi_camera'=>$activateHDMICameraChkbox),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"assoc_software"=>array("assoc_whitboard"=>$chk_whiteboard,"whiteboard_content"=>$whiteboard_content,"assoc_browser"=>$chk_browser,"browser_content"=>$browser_content),
				"gway_features"=>array('1'=>$connectGwayfeaturesStr),
				"client_features"=>array('1'=>$connectClientfeaturesStr),
				"mobile_features"=>array('1'=>$connectMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName,'hostname'=>$get_hostname,'dnsname'=>$via_roomname,'GroupID'=>'','groupName'=>''),				
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal),
				"business_hours"=>array("via_start_time"=>"09:00:00","via_end_time"=>"18:00:00","kds_start_time"=>"09:00:00","kds_end_time"=>"09:00:00")
				)
				);				
			}elseif($modellike==2){
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"always_on_top"=>$activateDisableOnTop,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>array("status"=>$broadcast,"autobroadcast"=>$auto_broadcast,"dataoversound"=>$boradcast_via_dataoversound,"bluetooth"=>$boradcast_via_bluetooth),
				"thirdparty_app"=>$thirdpartyapp,"hide_viaAdmin"=>$hideViaAdmin,"versa_mode"=>$viaversa,"via_roomname_type" => $via_roomname_type),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,"run_via"=>$runVia,"install_via"=>$installVia,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency,"inframode"=>$inframode),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode,"hdmi_to_vmd"=>$hdmitovmd,"auto_dnd"=>$autoDND,"vmd"=>array("annotation"=>$annotation,"public_annotation"=>$publicAnnotation),"always_full_scr"=>$presentationFullScreen,"confmod"=>$confercingMode,"show_user_name"=>$showUsername,"reserved_screen"=>$reserved_screen,"auto_disconnection" => array("status" => $autoDisconnection, "deviation" => $autoDisconnectionDeviation, "attempts" =>$autoDisconnectionAttempts, "avgcount" => $autoDisconnectionAvgcount)),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff,'hdmi_camera'=>$activateHDMICameraChkbox),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),
				"assoc_software"=>array("assoc_whitboard"=>$chk_whiteboard,"whiteboard_content"=>$whiteboard_content,"assoc_browser"=>$chk_browser,"browser_content"=>$browser_content),
				"gway_features"=>array('2'=>$campusGwayfeaturesStr),
				"client_features"=>array('2'=>$campusClientfeaturesStr),
				"mobile_features"=>array('2'=>$campusMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName,'hostname'=>$get_hostname,'dnsname'=>$via_roomname,'GroupID'=>'','groupName'=>''),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal),
				"business_hours"=>array("via_start_time"=>"09:00:00","via_end_time"=>"18:00:00","kds_start_time"=>"09:00:00","kds_end_time"=>"09:00:00")
				)
				);				
			}elseif($modellike==3 || $modellike==5){
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"always_on_top"=>$activateDisableOnTop,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>array("status"=>$broadcast,"autobroadcast"=>$auto_broadcast,"dataoversound"=>$boradcast_via_dataoversound,"bluetooth"=>$boradcast_via_bluetooth),
				"thirdparty_app"=>$thirdpartyapp,"hide_viaAdmin"=>$hideViaAdmin,"versa_mode"=>$viaversa,"via_roomname_type" => $via_roomname_type),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,"run_via"=>$runVia,"install_via"=>$installVia,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency,"inframode"=>$inframode),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode,"hdmi_to_vmd"=>$hdmitovmd,"auto_dnd"=>$autoDND,"vmd"=>array("annotation"=>$annotation,"public_annotation"=>$publicAnnotation),"always_full_scr"=>$presentationFullScreen,"confmod"=>$confercingMode,"show_user_name"=>$showUsername,"reserved_screen"=>$reserved_screen,"auto_disconnection" => array("status" => $autoDisconnection, "deviation" => $autoDisconnectionDeviation, "attempts" =>$autoDisconnectionAttempts, "avgcount" => $autoDisconnectionAvgcount)),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff,'hdmi_camera'=>$activateHDMICameraChkbox),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"client_features"=>array('3'=>$viagoClientfeaturesStr),
				"mobile_features"=>array('3'=>$viagoMobfeaturesStr),
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName,'hostname'=>$get_hostname,'dnsname'=>$via_roomname,'GroupID'=>'','groupName'=>''),
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal),
				"business_hours"=>array("via_start_time"=>"09:00:00","via_end_time"=>"18:00:00","kds_start_time"=>"09:00:00","kds_end_time"=>"09:00:00")
				)
				);				
			}elseif($modellike==4){
				$arr =array(
				"VIA_CONFIG_TEMPLATE"=>array(
				"via_settings"=>array(
				"system"=>array(
				"system_logs"=>$sysLog,
				"energy_saver"=>array(
				"status"=>$energysaver,"sleep_time"=>$sleepTime),"quick_client_access"=>$quickClientAccess,"always_on_top"=>$activateDisableOnTop,"api_command"=>$apiCmd,'language'=>$setLang,"via_broadcast"=>array("status"=>$broadcast,"autobroadcast"=>$auto_broadcast,"dataoversound"=>$boradcast_via_dataoversound,"bluetooth"=>$boradcast_via_bluetooth),
				"thirdparty_app"=>$thirdpartyapp,"hide_viaAdmin"=>$hideViaAdmin,"versa_mode"=>$viaversa,"via_roomname_type" => $via_roomname_type),		 			
				"presentation"=>array("ios_mirroring"=>array("status"=>$mirroring),
				"chrome"=>$chrome,"run_via"=>$runVia,"install_via"=>$installVia,
				"miracast"=>array("status"=>$miracast,"band"=>$frequency,"inframode"=>$inframode),
				"dnd"=>$activateDNDChkbox,
				"reset_session"=>$resetSession,
				"encoding"=>$encoding,"mediamode"=>$mediamode,"hdmi_to_vmd"=>$hdmitovmd,"auto_dnd"=>$autoDND,"vmd"=>array("annotation"=>$annotation,"public_annotation"=>$publicAnnotation),"always_full_scr"=>$presentationFullScreen, "confmod"=>$confercingMode,"show_user_name"=>$showUsername,"reserved_screen"=>$reserved_screen,"auto_disconnection" => array("status" => $autoDisconnection, "deviation" => $autoDisconnectionDeviation, "attempts" =>$autoDisconnectionAttempts, "avgcount" => $autoDisconnectionAvgcount)),
				"power"=>array("power_off_status"=>$autoPowerOff,"power_off_time"=>$autoPowerOffTime,"reboot_status"=>$autoReboot,"reboot_time"=>$autoRebootTime,"power_on_status"=>$autoPowerOn,"power_on_time"=>$autoPowerOnTime),
				"date_time"=>array("date_time_format"=>$selDateFormatDD,"linux_timezone"=>$timezoneConfigBox,"win_timezone"=>$winTimezoneConfigBox),
				"hdmi_settings"=>array("do_not_start_startup"=>$hdmiInputNotStart,"pip_mode"=>$pipMode,'auto_switch'=>$activateHDMIChkbox,'manual_on_off'=>$manualOnOff,'hdmi_camera'=>$activateHDMICameraChkbox),            "end_of_meeting"=>array("clean_the_cloud"=>$clearCloud,"option"=>$closeWhiteBoardBtn),			
				"file_sharing_settings"=>array("extensions"=>$authFileArray),
				'moderator_mode'=>array("status"=>$presentationMode,"config"=>array("moderator_type"=>$moderator_type,"chat"=>$activateChatChkbox,"participant_permission"=>$participantConfChkbox,"wait_moderator"=>$wait_moderator,"active_dir"=>array("domain"=>$adDomain,"account_type"=>$accountName,"group_ou"=>$group_ou,"moderator"=>$moderatorValue,"participant"=>$participantValue) ) ),
				"display"=>array("layout"=>$setDynamicLayout,"auto_hide"=>$dynamicLayoutChkbox,"user_interface_scaling"=>$dpiConfigBox),			
				"audio"=>array("output_device"=>$audioOutput,"level"=>$audioLevel),			
				"security"=>array("webadmin_session_timeout"=>$logoutTime,"captcha"=>$getCaptcha,"password_policy"=>array("alphanumeric"=>$getAlplhanumric,"special_char"=>$getSpecialChar,"one_capital"=>$getCaptLetter,"password_length"=>$minimumChar,"basic_mode"=>$getBasicModeFlag),"via_admin_pass"=>$viaAdminPassword,"via_basic_pass"=>$viaBasicPassword),	
				"certificate"=>array("certificate_data"=>$via_certificate,"key_data"=>$certificateKey),
									
				"NTP"=>$ntpArray,
				"host_config"=>$host_config,
				"recording"=>array("status"=>$getRecording,"option"=>$transferRecording),
				"proxy_server"=>array("server_address"=>$proxyServerName,"port_number"=>$proxyPort,"user_name"=>$proxyUserName,"password"=>$proxyPassword)
				),	
				"assoc_software"=>array("assoc_whitboard"=>$chk_whiteboard,"whiteboard_content"=>$whiteboard_content,"assoc_browser"=>$chk_browser,"browser_content"=>$browser_content),
				"gway_features"=>array('4'=>$connectplusGwayfeaturesStr),
				"client_features"=>array('4'=>$connectplusClintfeaturesStr),
				"mobile_features"=>array('4'=>$connectplusMobfeaturesStr),	
				"via_details"=>array("airplay_number"=>$maxNoOfMirrors,"airplayname"=>$mirrorName,'hostname'=>$get_hostname,'dnsname'=>$via_roomname,'GroupID'=>'','groupName'=>''),							
				"thirdparty"=>array("zoom"=>$zoomVal,"teams"=>$msTeamVal,"bluejeans"=>$bluejeansVal,"closeall"=>$TPCollabAppCloseVal),
				"business_hours"=>array("via_start_time"=>"09:00:00","via_end_time"=>"18:00:00","kds_start_time"=>"09:00:00","kds_end_time"=>"09:00:00")
				)
				);				
			}
			
			// echo"<pre>";print_r($arr);echo"<br>";die;
			//JSON_FORCE_OBJECT is sued to set numeric key 
			/*if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
				$encodedData = json_encode($arr,true);				
			}else{
				$encodedData = json_encode($arr,JSON_FORCE_OBJECT);		
			}*/
			$encodedData = json_encode($arr,true);	
			//encrypt json data		
			$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRYPTION_KEY);
			//file_put_contents($myFile.'decrypt.json', $encodedData);
			
			/*if($newtempflagReq==1 && PRODUCT=='via' && $flag=='edit'){
				$myFile='';
				$newReqTemplateName='template_'.rand(10000,100000);
				$newReqTeplaytePath='uploads/config_templates/'.$newReqTemplateName.'.json';
				$dataArr=array('template_name'=>$newReqTemplateName,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>$newReqTeplaytePath,'model_type'=>PRODUCT_MODEL_TYPE,'modifydatetime'=>date('Y-m-d H:i:s'));									
				$last_insert_id=$this->getViaSettingsTemplatesTable()->insertData($dataArr);
				
				$newupdateTemplateName='template'.$last_insert_id;
				$newUpdatedTemplatePath='uploads/config_templates/settings_'.$last_insert_id.'.json';
				$newDataArr=array('template_name'=>$newupdateTemplateName,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>$newUpdatedTemplatePath,'modifydatetime'=>date('Y-m-d H:i:s'));
				$this->getViaSettingsTemplatesTable()->updateTableData($newDataArr,$last_insert_id);
				
				$lastUqueryData=$appObj->returnQueryData("SELECT template_name FROM tbl_via_settings_templates WHERE id=$last_insert_id");
				$lastQryResult=$lastUqueryData->current();
				$myFile=UPLOAD_DIR_ZEND.$newUpdatedTemplatePath;
				//copy($sourceSettingFile, UPLOAD_DIR_ZEND.$newUpdatedTemplatePath);								
				
			}*/		

			
			if(file_put_contents($myFile, $encryptedJson)) {				
				if($flag=='edit'){
					    if(PRODUCT_TYPE=='via'){
							$queryData=$appObj->returnQueryData("SELECT status FROM tbl_via_settings_templates WHERE id=$intTemplateId");
							$result=$queryData->current();
							$status=$result['status'];
							if ($status==1) {
                                $dataArr=array('template_name'=>$templateName,'modifydatetime'=>date('Y-m-d H:i:s'),'status'=>2);
                            }else{
								$dataArr=array('template_name'=>$templateName,'modifydatetime'=>date('Y-m-d H:i:s'));	
							}
						}else{
							$dataArr=array('template_name'=>$templateName,'modifydatetime'=>date('Y-m-d H:i:s'));	
						}
						$this->getViaSettingsTemplatesTable()->updateTableData($dataArr,$intTemplateId);
						if(PRODUCT_TYPE=="via"){
							//copy in config folder if update active template
							$getActiveTemplateSql = $appObj->returnQueryData("SELECT status,template_path FROM tbl_via_settings_templates WHERE id=$intTemplateId");
							$templateStatus=0;
							foreach($getActiveTemplateSql as $activeTemplateData){						
								$templateStatus = $activeTemplateData['status'];
								$templatepath = $activeTemplateData['template_path'];
							}
							$sourceSettingFile = UPLOAD_DIR_ZEND.$activeTemplateData['template_path'];
							$settingsFile = DEST_PATH.'via_settings.json';
							//Modified by ashu on 11May23. Now if user is active and device in use then thoud shoud not work
							if($templateStatus==1 && $newtempflagReq!=1){
								copy($sourceSettingFile, $settingsFile);
							}
							
						}						
						echo 'success';					
				}else{
					$dataArr=array('template_name'=>$templateName,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>'uploads/'.TEMPLATE_DIR_CONFIG,'modifydatetime'=>date('Y-m-d H:i:s'),'model_type'=>PRODUCT_MODEL_TYPE);
					$whereArr=array('template_name'=>$templateName);
					$checkCount=$this->getViaSettingsTemplatesTable()->checkTemplate($whereArr);
						if($checkCount==0)	{		
							$last_insert_id=$this->getViaSettingsTemplatesTable()->insertData($dataArr);
							$finalTemplateName="uploads/".TEMPLATE_DIR_CONFIG.'settings_'.$last_insert_id.'.json';				
							rename($myFile ,UPLOAD_DIR_ZEND.$finalTemplateName);
							$dataArr=array("template_path"=>"$finalTemplateName");
							$this->getViaSettingsTemplatesTable()->updateTableData($dataArr,$last_insert_id);	
							//echo 'success#'.$appObj->desEncrypt($templateName, KEY_SEED).'#'.$last_insert_id;
							echo 'success#'.$appObj->desEncrypt($last_insert_id, KEY_SEED);					
						}
						else{
							$dataArr=array('template_name'=>$templateName,'modifydatetime'=>date('Y-m-d H:i:s'));						
							$this->getViaSettingsTemplatesTable()->updateTableData($dataArr,$intTemplateId);
						}
					}
				//manage log
                if (PRODUCT=='via') {
                    $appObj->ActivityLog($historyFlag, STR_CONFIG_TEMPLATE.' : '.$templateName);
                }else{
					if($historyFlag=='Create')
					$historyFlag=3;
					else{
						$historyFlag=4;
					}
					$appObj->ActivityLogVSM($historyFlag, STR_CONFIG_TEMPLATE.' : '.$templateName,6);
				}			
			}
			else{ 
			   echo "error";
			}			
			die;
		}
		
		//ajax call to save ntp
		public function saveNTPServerSettingAction(){
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$session = new Container('userinfo');
				$loginName = $session->offsetGet('LoginName');
				$appObj = new ApplicationController();
				$ntpServer = htmlspecialchars(trim($request->getPost('ntpServer')));
				$currentime=time();
				$randStringNtpQuid=mt_rand(10000, 9999999)."".rand(10,999)."".time();
				$ntpFile = UPLOAD_PATH_INTERNAL.'ntp_'.$loginName.'.txt';
				$ntpArr = array('ntp_name'=>$ntpServer, 'ntp_name'=>$ntpServer, 'status'=>1, 'ntp_uuid'=>$randStringNtpQuid);
				if(file_exists($ntpFile)){
					$fileContent = file_get_contents($ntpFile);
					$ntpDataArr = (array)json_decode($fileContent);
					$exist = 0;
					if(count($ntpDataArr)>0){
						foreach ($ntpDataArr as $key => $value) {
							if($value->ntp_name == $ntpServer){
								$exist = 1;
								break;
							}
						}
					}
					if($exist == 1){
						echo"exist";die;
					}else{
						$new_ntpData[] = $ntpArr;
						array_push($ntpDataArr, ...$new_ntpData);
						$fp = fopen($ntpFile, 'w');
						fwrite($fp, json_encode($ntpDataArr));
						fclose($fp);
					}
				}else{
					$ntpEnc = json_encode(array($ntpArr));
					$fp = fopen($ntpFile, 'w');
					fwrite($fp, $ntpEnc);
					fclose($fp);
				}
				$fileContent = file_get_contents($ntpFile);
				$ntpDataArr = (array)json_decode($fileContent);
				echo '<table class="table table-responsive m-t b-light">
						<thead>
						<tr>
							<th>'.STR_NTP_SERVER_NAME.'</th>
							<th>'.STR_EDIT.'</th>
							<th class="text-right">'.STR_DELETE.'</th>
						</tr>
						</thead>
						<tbody>';
				if(count($ntpDataArr) > 0){
						foreach($ntpDataArr as $val){
							echo '<tr>
							<td>'.$val->ntp_name.'</td>						
							<td><span class="via-hover-icon"><img src="'.PUBLIC_URL.'/img/via/icon-edit.svg" class="pointer display-block"><img src="'.PUBLIC_URL.'/img/via/icon-edit-hover.svg" class="pointer editNtpServer display-none" rev="'. $val->ntp_name.'" rel="'.$val->ntp_uuid.'"></span></td>
							<td class="text-right"><span class="via-hover-icon"><img src="'. PUBLIC_URL.'/img/via/icon-delete.svg" class="pointer display-block"><img src="'. PUBLIC_URL.'/img/via/icon-delete-hover.svg" class="pointer delNtpServer display-none" rev="0#'.$val->ntp_name.'"></span></td>
							</tr>';
						}
				}else{
					echo '<tr><td colspan="3" class="text-center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
				}
				echo '<tbody></table>';die;	
			}
		}

		public function updateNTPServerSettingAction(){
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$session = new Container('userinfo');
				$loginName = $session->offsetGet('LoginName');
				$appObj = new ApplicationController();
				$ntpServer = htmlspecialchars(trim($request->getPost('ntpServer')));
				$ntp_uuid = trim($request->getPost('ntp_uuid'));
				//getting new uuid when update ntp
				$currentime=time();
				$new_ntp_uuid=mt_rand(10000, 9999999)."".rand(10,999)."".time();
				
				$ntpFile = UPLOAD_PATH_INTERNAL.'ntp_'.$loginName.'.txt';
				$fileContent = file_get_contents($ntpFile);
				$ntpDataArr = (array)json_decode($fileContent);
				$exist = 0;
				if(count($ntpDataArr)>0){
					foreach ($ntpDataArr as $key => $value) {
						if($value->ntp_name == $ntpServer){
							$exist = 1;
							break;
						}
					}
				}
				if($exist == 1){
					echo"exist";die;
				}
				$new_ntpDataArr = array();
				foreach ($ntpDataArr as $key => $value) {
					if($value->ntp_uuid == $ntp_uuid){
						$value->ntp_name = $ntpServer;
						//update uuid when update ntp
						$value->ntp_uuid = $new_ntp_uuid;
					}
				}
			 	$new_ntpDataArr = json_encode($ntpDataArr);
				$fp = fopen($ntpFile, 'w');
				fwrite($fp, $new_ntpDataArr);
				fclose($fp);
				$fileContent = file_get_contents($ntpFile);
				$ntpDataArr = (array)json_decode($fileContent);
				
				echo '<table class="table table-responsive m-t b-light">
						<thead>
						<tr>
							<th>'.STR_NTP_SERVER_NAME.'</th>
							<th>'.STR_EDIT.'</th>
							<th class="text-right">'.STR_DELETE.'</th>
						</tr></thead> <tbody>';
				if(count($ntpDataArr) > 0){
					foreach($ntpDataArr as $val){
						echo '<tr>
						<td>'.$val->ntp_name.'</td>						
						<td><span class="via-hover-icon"><img src="'.PUBLIC_URL.'/img/via/icon-edit.svg" class="pointer display-block"><img src="'.PUBLIC_URL.'/img/via/icon-edit-hover.svg" class="pointer editNtpServer display-none" rev="'. $val->ntp_name.'" rel="'.$val->ntp_uuid.'"></span></td>
						<td class="text-right"><span class="via-hover-icon"><img src="'. PUBLIC_URL.'/img/via/icon-delete.svg" class="pointer display-block"><img src="'. PUBLIC_URL.'/img/via/icon-delete-hover.svg" class="pointer delNtpServer display-none" rev="0#'.$val->ntp_name.'"></span></td>
						</tr>';
					}
				}else{
					echo '<tr><td colspan="3" class="text-center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
				}
			echo '</tbody></table>';die;
			}
		}

		public function delNTPServerAction(){
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$session = new Container('userinfo');
				$loginName = $session->offsetGet('LoginName');
				$appObj = new ApplicationController();
				$ntpServer = trim($request->getPost('ntpname'));
				$getOptValue = trim($request->getPost('getOptValue'));
				$ntpFile = UPLOAD_PATH_INTERNAL.'ntp_'.$loginName.'.txt';
				if($getOptValue==0){
					$fileContent = file_get_contents($ntpFile);
					$ntpDataArr = (array)json_decode($fileContent);
					$new_ntpDataArr = array();
					foreach ($ntpDataArr as $key => $value) {
						if($value->ntp_name == $ntpServer){
							unset($ntpDataArr[$key]);
						}
					}
					$new_ntpDataArr = json_encode($ntpDataArr);
					$fp = fopen($ntpFile, 'w');
					fwrite($fp, $new_ntpDataArr);
					fclose($fp);

					$fileContent = file_get_contents($ntpFile);
					$ntpDataArr = (array)json_decode($fileContent);
					echo '<table class="table table-responsive m-t b-light">
							<thead>
							<tr>
								<th>'.STR_NTP_SERVER_NAME.'</th>
								<th>'.STR_EDIT.'</th>
								<th class="text-right">'.STR_DELETE.'</th>
							</tr></thead><tbody>';
					if(count($ntpDataArr) > 0){
						foreach($ntpDataArr as $val){
							echo '<tr>
							<td>'.$val->ntp_name.'</td>						
							<td><span class="via-hover-icon"><img src="'.PUBLIC_URL.'/img/via/icon-edit.svg" class="pointer display-block"><img src="'.PUBLIC_URL.'/img/via/icon-edit-hover.svg" class="pointer editNtpServer display-none" rev="'. $val->ntp_name.'" rel="'.$val->ntp_uuid.'"></span></td>
							<td class="text-right"><span class="via-hover-icon"><img src="'. PUBLIC_URL.'/img/via/icon-delete.svg" class="pointer display-block"><img src="'. PUBLIC_URL.'/img/via/icon-delete-hover.svg" class="pointer delNtpServer display-none" rev="0#'.$val->ntp_name.'"></span></td>
							</tr>';
						}
					}else{
						echo '<tr><td colspan="3" class="text-center">'.MSG_NO_RECORD_FOUND.'</td></tr>';
					}
				echo '</tbody></table>';die;
				}
			}
		}

		//Apply All file Ajax - Added by Ranjan
		public function applyDefaultFileTypeConfigAction() {
			$session = new Container('userinfo');
			$loginName = $session->offsetGet('LoginName');
			$hostname = DEFAULT_SERVER_IP;
			$fileFormatFile = UPLOAD_PATH_INTERNAL.'auth_fileformat_'.$loginName.'.txt';
			$fileContent = file_get_contents($fileFormatFile);
			$fileDataArr = (array)json_decode($fileContent);
			foreach ($fileDataArr as $key => $value) {
				$fileDataArr[$key]->status = 1;
			}
			
			$fp = fopen($fileFormatFile, 'w');
			fwrite($fp, json_encode($fileDataArr));
			fclose($fp);

			$fileContent = file_get_contents($fileFormatFile);
			$fileDataArr = (array)json_decode($fileContent);
			foreach ($fileDataArr as $key => $value) {
				if($value->ext_name == 'All' || $value->ext_name == 'jpeg' || $value->ext_name == 'pdf' || $value->ext_name == 'png' || $value->ext_name == 'jpg'){
					continue;
				}else{
					$fileFormatArr[$key]['ext_name'] = $value->ext_name;
					$fileFormatArr[$key]['status'] = $value->status;
				}
			}
			foreach($fileFormatArr as $val){ 
				$files[] = $val['ext_name'];
			}
			echo implode(',',$files);die;
		}
	
		//Apply Selected file Ajax - Added by Ranjan
		public function applySelectedFileTypeConfigAction() {
			$session = new Container('userinfo');
			$loginName = $session->offsetGet('LoginName');
			$hostname = DEFAULT_SERVER_IP;
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$textareaValues = trim($request->getPost('textareaValues'));
				$fileFormatFile = UPLOAD_PATH_INTERNAL.'auth_fileformat_'.$loginName.'.txt';
				$fileContent = file_get_contents($fileFormatFile);
				$fileDataArr = (array)json_decode($fileContent);
				foreach ($fileDataArr as $key => $value) {
					$fileDataArr[$key]->status = 0;
				}
				$textareaValuesArr = explode(',', $textareaValues);
				$customFileString = '';

				foreach($textareaValuesArr as $fileValues) {
					$customFileString .= "'" . $fileValues . "'" . ',';
				}
				$customFileString = substr($customFileString, 0, - 1);
				foreach ($fileDataArr as $key => $value) {
					foreach ($textareaValuesArr as $k => $val) {
						if($value->ext_name == $val || ($value->ext_name == 'jpeg' || $value->ext_name == 'pdf' || $value->ext_name == 'png' || $value->ext_name == 'jpg')){
							$fileDataArr[$key]->status = 1;
						}
					}
				}
				$fp = fopen($fileFormatFile, 'w');
				fwrite($fp, json_encode($fileDataArr));
				fclose($fp);
				echo 'success';die;
			}
		}
		//Add custom file Ajax - Added by Ranjan
		public function addCustomFileTypesAction() {
			$session = new Container('userinfo');
			$loginName = $session->offsetGet('LoginName');
			$hostname = DEFAULT_SERVER_IP;
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$chkBoxVal = trim($request->getPost('chkBoxVal'));
                $textareaValues = htmlspecialchars(trim($request->getPost('textareaValues')));	
				if($chkBoxVal == 1) {
					$existValuesArr = array();
					$textareaValuesArr = array_unique(explode(',', $textareaValues));
					//Added by ashu on 5Jun23 for removing blank values
					$textareaValuesArr = array_filter($textareaValuesArr, 'strlen');				
					
					// get existing filetype list
					$fileFormatFile = UPLOAD_PATH_INTERNAL.'auth_fileformat_'.$loginName.'.txt';
					$fileContent = file_get_contents($fileFormatFile);
					$fileDataArr = (array)json_decode($fileContent);
					foreach ($fileDataArr as $key => $value) {
						foreach($textareaValuesArr as $fileValues) {
							if($fileValues == $value->ext_name){
								$existFileStr .= $fileValues . ',';
							}
						}
					}
					
					$textareaValuesArr = explode(',', $textareaValues);
					//Added by ashu on 5Jun23 for removing blank values
					$textareaValuesArr = array_filter($textareaValuesArr, 'strlen');
					$customFileString = '';
					foreach($textareaValuesArr as $fileValues) {
						$customFileString .= "'" . $fileValues . "'" . ',';
					}
					if($existFileStr != '') {
						//echo rtrim($existFileStr, ",");
						echo 'exist';die;
					}else{
						foreach($textareaValuesArr as $fileValues) {
							$new_extArray = array('ext_name' => $fileValues, 'status' => 0);
						}
					}
					array_push($fileDataArr, (object)$new_extArray);
					$fp = fopen($fileFormatFile, 'w');
					fwrite($fp, json_encode($fileDataArr));
					fclose($fp);
					foreach($textareaValuesArr as $fileValues) {
						echo '<div class="col-lg-3" style="border:1px solid;border-radius: 25px;border-color:#52555d;">
						<div class="no-padder" id="chk_'.$fileValues.'"><input type="checkbox" name="fileType" id="'.$fileValues.'" value="'.$fileValues.'" rev="userDefined" class="fileTypeChkboxCss" checked=""><label for="'.$fileValues.'"><span style="vertical-align:top;"></span>'.$fileValues.'</label><span class="note pointer userDefined" rev="'.$fileValues.'"><a href="#" class="active" data-toggle="class">&nbsp;<i class="fa fa-times text-dark"></i></a></span></div>
						</div>';
					}
					die;
				}
			}
		}
		//Delete custom file Ajax - Added by Ranjan
		public function deleteCustomFileTypesAction() {
			$session = new Container('userinfo');
			$loginName = $session->offsetGet('LoginName');
			$hostname = DEFAULT_SERVER_IP;
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				echo $chkBoxVal = trim($request->getPost('chkBoxId'));
				$this->getAuthFileFormatTable()->deleteFileFormat(array('fileformat' => $chkBoxVal));
				$fileFormatFile = UPLOAD_PATH_INTERNAL.'auth_fileformat_'.$loginName.'.txt';
					$fileContent = file_get_contents($fileFormatFile);
					$fileDataArr = (array)json_decode($fileContent);
					foreach ($fileDataArr as $key => $value) {
						if($value->ext_name == $chkBoxVal){
							unset($fileDataArr[$key]);
						}
					}
					$fp = fopen($fileFormatFile, 'w');
					fwrite($fp, json_encode($fileDataArr));
					fclose($fp);
				die;
			}
		}
		//Api command setting Ajax - Added by Ranjan
		public function applyApiCmdAction() {
			$session = new Container('userinfo');
			$loginName = $session->offsetGet('LoginName');
			$appObj = new ApplicationController();
			$hostname = DEFAULT_SERVER_IP;
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$getApiCmdBtnval = trim($request->getPost('getApiCmdBtnval'));
				$apiCmdData = array('feature5' =>$getApiCmdBtnval,'last_updated' => date("Y-m-d h:i:s"));
				$this->getAdvanceConfigurationTable()->updateFeatures($apiCmdData);
				$setLogMode =($getApiCmdBtnval == 1)? 'Activated Secure Mode by' : 'Activated Non Secure Mode by';
				if(PRODUCT=='via'){
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', $setLogMode, $hostname);
				}else{
					$setActivity = $appObj->ActivityLogVSM(7, $setLogMode,6);
				}
				echo 'success';
				die;
			}
		}
		

	 /*****
	 *	@Function Name: checkTemplateNameAjaxAction
	 *  @description  : ajax call to check template name
	 *	@Author		  : Ashu
	 *  @Date         : 13-june-2020
	 *****/	
	public function checkTemplateNameAjaxAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');		
		if($session->offsetGet('LoginName')==''){
			echo 'sessionout';
			exit;
		}	
		
		$custTempName = trim($_POST['custTempName']);
		// added for security reason
		$custTempName = htmlspecialchars($custTempName);
		$session->offsetSet('viaSettingsTemplateName',$custTempName);		
		$selQry =$appObj->getTableAllData("tbl_via_settings_templates WHERE template_name ILIKE '".$custTempName."'");
		if(count($selQry)==0){
			echo 'ok';exit;
		}else{
			echo"exists";
		}	
		die;
	}
	
        public function editTemplateAction(){
            $session = new Container('userinfo');
            $user_id = $session->offsetGet('usrid');
            $loginName = $session->offsetGet('LoginName');
            $appObj = new ApplicationController();
			//single code changes
			$stream_option = 0;
			$stream_url1 = '';
			$stream_url2 = '';
			$viaModel="";
			$modellike="";
			$modelshow='';
			$modelValue='';
			$deviceostype="";
			$viaServerIP='';
			$clientOS='';
			$wifiMiracastFlag='';
			$supportMiracast='';
			$displayCount_content = '';	
			$getTemplateStatus='';		
			if(PRODUCT=="via"){
				$viaModel=$appObj->getModelNameByParam('model');
				$modellike=$appObj->getModelNameByParam('modellike');
				$modelshow=$appObj->getModelNameByParam('modelshow');
				$modelValue=$appObj->getModelNameByParam('modelvalue');
				
				$deviceostype=strtolower($appObj->getModelNameByParam('ostype'));
				$data = $appObj->getTableAllData('DeviceInventory')->current();
				$viaServerIP = $data['deviceip'];
				$getos = $appObj->getClientOS();
				if(strstr($getos, 'Chrome OS')) {
					$clientOS = 'ChromeOS';
				} else if(strstr($getos, 'Mob_Window')) {
					$clientOS = 'windowsMobile';
				} else {
					$clientOS = strtoupper(substr($getos, 0, 3));
				}
				//getting value to allow wifi or miracast
				$wifiMiracastFlag=$appObj->allowMiracastAndWifi(DEST_PATH.'network.json');
				//getting miracast value from network.json. Now Miracast will be read from json not from file
				$networkJsonData=$appObj->readJsonFile(DEST_PATH.'network.json');
				$supportMiracast=($networkJsonData['Miracast']!='')?trim($networkJsonData['Miracast']):0;
				//getting network data. getting wifi on/off info
				$sessionNetworkData=$session->offsetGet('networkData');					
				$check_wifi=$sessionNetworkData['check_wifi'];
				$check_wifi_OnOff=$sessionNetworkData['check_wifi_OnOff'];				
				
				// added by niraj
				if(CHECK_FILE_DISPLAYCOUNT == 1){
					$displayCount_content = $appObj->file_read(DEST_PATH.FILE_DISPLAYCOUNT);
				}
				$streamArr = $this->getStreamingSettingsTable()->fetchAll();
				if(count($streamArr)> 0) {		
					foreach($streamArr as $stream) {
						$stream_option =($stream->status == '')? 0 : $stream->status;
						$stream_url1 = $stream->display_url_1;
						$stream_url2 = $stream->display_url_2;
					}
				}	
				$tebName=htmlspecialchars(trim($this->params()->fromQuery('tab')));
			}
			$templateDataArr=array();
			//using template id and getting template name
			$encryptedTempId=trim($this->params()->fromQuery('id'));
			$templateAction=trim($this->params()->fromQuery('action'));
			$templateAction = htmlspecialchars($templateAction);
			$templateAction = ($templateAction=='')?'edit':$templateAction;
			$templateActionName=trim($this->params()->fromQuery('name'));
			$templateActionName=($templateActionName=='')?'edit':$templateActionName;
			$input=str_replace(' ','+',trim($encryptedTempId));
			$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
			$intTemplateId=$appObj->desDecrypt($input, KEY_SEED);
			//Security changes added by ashu on 31/03/22. Allow only numeric value 
			if(!is_numeric($intTemplateId) || $intTemplateId <= 0 ){
				echo "Id is not valid";die;
			}	
			if(PRODUCT=="via"){
				//getting template status on VIA
				$getVIATemplateStatus=$appObj->returnQueryData("SELECT status FROM tbl_via_settings_templates WHERE id=$intTemplateId");
				foreach($getVIATemplateStatus as $arrTemplateStatus){					
					$getTemplateStatus=$arrTemplateStatus['status'];
				}
			}		
			
							
			//$getTemplateData=$appObj->returnQueryData("SELECT CAST(CONVERT(template_name USING utf8) AS binary) as template_name ,template_path FROM tbl_via_settings_templates WHERE id=$intTemplateId");
			$getTemplateData=$appObj->returnQueryData("SELECT template_name ,template_path FROM tbl_via_settings_templates WHERE id=$intTemplateId");
			foreach($getTemplateData as $arrTemplateData){
				$templatePath=$arrTemplateData['template_path'];
				$settingTemplateName=$arrTemplateData['template_name'];
			}
			$explodeTemplatePath=explode('/',$templatePath);
			$dbTemplateName=$explodeTemplatePath[2];
			//die;
			
			/*$encryptedTempName=trim($this->params()->fromQuery('id'));
			$input=str_replace(' ','+',$encryptedTempName);
			$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
			$templateName=$appObj->desDecrypt($input, KEY_SEED).'.json';
			*/
			
			$url = UPLOAD_DIR_ZEND.$templatePath;
			$response=file_get_contents($url);	
			//decrypt json					
			$decryptResponse=$appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
			//end		
			if($decryptResponse!=''){
				$jsonArray=json_decode($decryptResponse, true);
				//echo "<pre>";print_r($jsonArray);
			}
			$ntpArr=array();
			$collage_gwayFeaturesArr=array();
			$collage_clientFeaturesArr=array();
			$collage_mobFeaturesArr=array();
			
			$connect_gwayFeaturesArr=array();
			$connect_clientFeaturesArr=array();
			$connect_mobFeaturesArr=array();
			
			$campus_gwayFeaturesArr=array();
			$campus_clientFeaturesArr=array();
			$campus_mobFeaturesArr=array();
			
			$viago_clientFeaturesArr=array();
			$viago_mobFeaturesArr=array();

			$connectplus_gwayFeaturesArr=array();
			$connectplus_clientFeaturesArr=array();
			$connectplus_mobFeaturesArr=array();			
			foreach($jsonArray as $rootkey => $rootValue){
				//echo "<br>".$rootkey;
				//echo "<pre>";print_r($rootValue);
				foreach($rootValue as $subrootKey=>$subrootVal){
					//echo "<br>".$subrootKey;
					//echo "<pre>";print_r($subrootVal);
					if($subrootKey=='via_settings'){
						//echo "<br>".$subrootKey;
						//echo "<pre>";print_r($subrootVal);
						
						foreach($subrootVal as $subsubrootKey=>$subsubrootVal){							
							$subsubrootKey=strtolower($subsubrootKey);
							//processed system array
							if($subsubrootKey=='system'){
								//echo "<br>".$subsubrootKey;
								//echo "<pre>";print_r($subsubrootVal);								
								$system_logs=$subsubrootVal['system_logs'];								
								//energy_saver array
								//echo "<pre>";print_r($subsubrootVal['energy_saver']);			
								
								/*foreach($subsubrootVal['energy_saver'] as $energy_saverKey=>$energy_saverVal){									
									if($energy_saverKey=='status'){
										$energy_saver_status=$energy_saverVal;
									}
									if($energy_saverKey=='sleep_time'){
										$energy_saver_sleep_time=$energy_saverVal;
									}
								}//end of energy_saver array
								*/
								$energy_saver_sleep_time=$subsubrootVal['energy_saver']['sleep_time'];
								$quick_client_access=$subsubrootVal['quick_client_access'];
								$always_on_top=(isset($subsubrootVal['always_on_top']))?$subsubrootVal['always_on_top']:1;
								$api_command=$subsubrootVal['api_command'];
								$language=$subsubrootVal['language'];
								//$via_broadcast=$subsubrootVal['via_broadcast'];
								$via_broadcast=$subsubrootVal['via_broadcast']['status'];
								
								//store in array
								$templateDataArr['system_logs']=$subsubrootVal['system_logs'];
								$templateDataArr['energy_saver_status']=$subsubrootVal['energy_saver']['status'];
								$templateDataArr['energy_saver_sleep_time']=$subsubrootVal['energy_saver']['sleep_time'];
								$templateDataArr['quick_client_access']=$subsubrootVal['quick_client_access'];
								$templateDataArr['always_on_top']=$always_on_top;
								$templateDataArr['api_command']=$subsubrootVal['api_command'];
								$templateDataArr['language']=$subsubrootVal['language'];
								//$templateDataArr['via_broadcast']=$subsubrootVal['via_broadcast'];
								//$templateDataArr['via_broadcast']=$subsubrootVal['via_broadcast']['status'];
								if( isset( $subsubrootVal['via_broadcast']['status'] ) ){
									$templateDataArr['via_broadcast']=$subsubrootVal['via_broadcast']['status'];
								}else{
									$templateDataArr['via_broadcast']=$subsubrootVal['via_broadcast'];
								}
								
								
								$templateDataArr['thirdpartyapp']=$subsubrootVal['thirdparty_app'];
								$templateDataArr['viaAdmin']=$subsubrootVal['hide_viaAdmin'];
								$templateDataArr['versa_mode']=$subsubrootVal['versa_mode'];
								
								//$templateDataArr['autobroadcast']=$subsubrootVal['via_broadcast']['autobroadcast'];
								if( isset( $subsubrootVal['via_broadcast']['autobroadcast'] ) ){
									$templateDataArr['autobroadcast']=$subsubrootVal['via_broadcast']['autobroadcast'];
								}else{
									$templateDataArr['autobroadcast']=($subsubrootVal['via_broadcast']==1)?1:0;
								}
								
								$templateDataArr['dataoversound']=$subsubrootVal['via_broadcast']['dataoversound'];
								//$templateDataArr['bluetooth']=$subsubrootVal['via_broadcast']['bluetooth'];
								if( isset( $subsubrootVal['via_broadcast']['bluetooth'] ) ){
									$templateDataArr['bluetooth']=$subsubrootVal['via_broadcast']['bluetooth'];
								}else{
									$templateDataArr['bluetooth']=0;
								}

								// added by niraj
								if(isset($subsubrootVal['via_roomname_type'])) {
									$templateDataArr['via_roomname_type'] = $subsubrootVal['via_roomname_type'];
								}else{
									$templateDataArr['via_roomname_type'] = file_exists(DEST_PATH.READFILE_ROOMNAMEVALUESHOW)?1:2;

								}
								// end added by niraj


							}//end system array
							
							//processed presentaion array
							if($subsubrootKey=='presentation'){														
								//getting iOS mirroring value
								/*foreach($subsubrootVal['ios_mirroring'] as $ios_mirroringKey=>$ios_mirroringVal){	
									$ios_mirroring=$ios_mirroringVal['ios_mirroring'];
								}*/
								$ios_mirroring=$subsubrootVal['ios_mirroring']['status'];
								$chromeValue=$subsubrootVal['chrome'];
								//getting iOS mirroring value
								/*foreach($subsubrootVal['miracast'] as $miracastgKey=>$miracastVal){	
									if($miracastgKey=='status'){
										$miracast_status=$miracastVal;
									}
									if($miracastgKey=='band'){
										$miracast_bnad=$miracastVal;
									}
									
								}*/
								$dnd=$subsubrootVal['dnd'];
								$reset_session=$subsubrootVal['reset_session'];
								$encoding=$subsubrootVal['encoding'];
								
								$templateDataArr['ios_mirroring']=$ios_mirroring;
								$templateDataArr['chromeValue']=$chromeValue;
								
								if( isset( $subsubrootVal['run_via'] ) ){
									$templateDataArr['run_via_value']=$subsubrootVal['run_via'];
								}else{
									$templateDataArr['run_via_value']=1;
								}
								
								if( isset( $subsubrootVal['install_via'] ) ){
									$templateDataArr['install_via_value']=$subsubrootVal['install_via'];
								}else{
									$templateDataArr['install_via_value']=1;
								}
								$templateDataArr['miracast_status']=$subsubrootVal['miracast']['status'];//$miracast_status;
								$templateDataArr['miracast_bnad']=$subsubrootVal['miracast']['band'];//$miracast_bnad;
								$templateDataArr['dnd']=$dnd;
								$templateDataArr['reset_session']=$reset_session;
								$templateDataArr['encoding']=$encoding;
								$templateDataArr['mediamode']=$subsubrootVal['mediamode'];
								//presetation changes
								$templateDataArr['autoDND']=$subsubrootVal['auto_dnd'];
								$templateDataArr['hdmitovmd']=$subsubrootVal['hdmi_to_vmd'];
								$templateDataArr['annotation']=$subsubrootVal['vmd']['annotation'];
								$templateDataArr['publicAnnotation']=$subsubrootVal['vmd']['public_annotation'];
								$templateDataArr['presentationFullScreen']=$subsubrootVal['always_full_scr'];	

								// code added to set auto disconnection data in array for display -- niraj gautam on 16Aug 2022
								$templateDataArr['autoDisconnection'] = $subsubrootVal['auto_disconnection']['status'];
								$templateDataArr['autoDisconnectionDeviation']= $subsubrootVal['auto_disconnection']['deviation'];	
								$templateDataArr['autoDisconnectionAttempts']=$subsubrootVal['auto_disconnection']['attempts'];	
								$templateDataArr['autoDisconnectionAvgcount']=$subsubrootVal['auto_disconnection']['avgcount'];		
								// end code added to set auto disconnection data in array for display -- niraj gautam on 16Aug 2022

								$templateDataArr['confercingMode']=$subsubrootVal['confmod'];
								$templateDataArr['show_user_name']=$subsubrootVal['show_user_name'];
								$templateDataArr['reserved_screen']=$subsubrootVal['reserved_screen'];
								$templateDataArr['inframode']=$subsubrootVal['miracast']['inframode'];		
													
							}//end presentaion array
							
							//processed power array
							if($subsubrootKey=='power'){
								$power_Off_Status=trim($subsubrootVal['power_off_status']);								
								$power_off_time=$subsubrootVal['power_off_time'];
								$power_Reboot_Status=trim($subsubrootVal['reboot_status']);
								$power_reboot=$subsubrootVal['reboot_time'];
								$power_On_Status=trim($subsubrootVal['power_on_status']);
								$power_on=$subsubrootVal['power_on_time'];	
								
								$explodePowerOffArr=explode(":",$power_off_time);
								$power_off_Hours=$explodePowerOffArr[0];
								$power_off_Mints=$explodePowerOffArr[1];								
								
								$explodePowerRebootArr=explode(":",$power_reboot);
								$power_Reboot_Hours=$explodePowerRebootArr[0];
								$power_Reboot_Mints=$explodePowerRebootArr[1];								

								$explodePowerOnArr=explode(":",$power_on);
								$power_on_Hours=$explodePowerOnArr[0];
								$power_on_Mints=$explodePowerOnArr[1];
								
								
								//storing power elemnts in array
								$templateDataArr['power_Off_Status']=$power_Off_Status;
								$templateDataArr['power_Reboot_Status']=$power_Reboot_Status;
								$templateDataArr['power_On_Status']=$power_On_Status;	
							}//end power
							
							//processed date_time array
							if($subsubrootKey=='date_time'){															
								$date_time_format=$subsubrootVal['date_time_format'];
								$linux_timezone=$subsubrootVal['linux_timezone'];
								$win_timezone=$subsubrootVal['win_timezone'];
										
							}//end date_time
							
							//processed hdmi_settings array
							if($subsubrootKey=='hdmi_settings'){								
								$do_not_start_startup=$subsubrootVal['do_not_start_startup'];
								$pip_mode=$subsubrootVal['pip_mode'];
								$auto_switch=$subsubrootVal['auto_switch'];
								$manual_on_off=$subsubrootVal['manual_on_off'];	
								$hdmi_camera=$subsubrootVal['hdmi_camera'];		
								//storing HDMI elemnts in array
								$templateDataArr['do_not_start_startup']=$do_not_start_startup;
								$templateDataArr['pip_mode']=$pip_mode;
								$templateDataArr['auto_switch']=$auto_switch;	
								$templateDataArr['manual_on_off']=$manual_on_off;
								$templateDataArr['hdmi_camera']=$hdmi_camera;
								
							}//end hdmi_settings
							
							//processed end_of_meeting array
							if($subsubrootKey=='end_of_meeting'){															
								$clean_the_cloud=$subsubrootVal['clean_the_cloud'];
								$clean_the_cloud_option=$subsubrootVal['option'];	
								$templateDataArr['clean_the_cloud']=$clean_the_cloud;
								$templateDataArr['clean_the_cloud_option']=$clean_the_cloud_option;
																	
							}//end end_of_meeting
							
							
							//processed file_sharing_settings array
							if($subsubrootKey=='file_sharing_settings'){								
								$extensions=$subsubrootVal['extensions'];
								//getting file sharing radio button value using foreach
								foreach($extensions as $extName=>$extValue){
									//echo "<br>".$extValue['ext_name'];
									if($extValue['ext_name']=='All'){
										$fileSharingStatus=$extValue['status'];
									}
								}
								//storing file format data in array
								$templateDataArr['fileSharingStatus']=$fileSharingStatus;
								$templateDataArr['extensions']=$extensions;									
							}//end file_sharing_settings


							//processed moderator_mode array
							if($subsubrootKey=='moderator_mode'){								
								$moderator_status=$subsubrootVal['status'];
								//echo "<pre>";print_r($subsubrootVal['config']);									
								$moderator_type=$subsubrootVal['config']['moderator_type'];
								$moderator_chat=$subsubrootVal['config']['chat'];
								$moderator_participant_permission=$subsubrootVal['config']['participant_permission'];
								$moderator_wait_moderator=$subsubrootVal['config']['wait_moderator'];
								
								//print_r($subsubrootVal['config']['active_dir']);	
								$moderator_domain=$subsubrootVal['config']['active_dir']['domain'];
								$moderator_account_type=$subsubrootVal['config']['active_dir']['account_type'];
								$moderator_group_ou=$subsubrootVal['config']['active_dir']['group_ou'];								
								$moderator_moderator=$subsubrootVal['config']['active_dir']['moderator'];
								$moderator_participant=$subsubrootVal['config']['active_dir']['participant'];
								
								//storing moderator_mode data in array
								$templateDataArr['moderator_status']=$moderator_status;
								$templateDataArr['moderator_type']=$moderator_type;
								$templateDataArr['moderator_chat']=$moderator_chat;
								$templateDataArr['moderator_participant_permission']=$moderator_participant_permission;
								$templateDataArr['moderator_wait_moderator']=$moderator_wait_moderator;
								$templateDataArr['moderator_domain']=$moderator_domain;
								$templateDataArr['moderator_account_type']=$moderator_account_type;
								$templateDataArr['moderator_group_ou']=$moderator_group_ou;
								$templateDataArr['moderator_moderator']=$moderator_moderator;
								$templateDataArr['moderator_participant']=$moderator_participant;
								
								
							}//end moderator_mode

							//processed display array
							if($subsubrootKey=='display'){
								//echo "<pre>";print_r($subsubrootVal);								
								$display_layout=$subsubrootVal['layout'];
								$display_auto_hide=$subsubrootVal['auto_hide'];	
								$user_interface_scaling=$subsubrootVal['user_interface_scaling'];
								
								//storing display data in array																
								$templateDataArr['auto_hide']=$display_auto_hide;								
							}//end display
							
							//processed audio array
							if($subsubrootKey=='audio'){
								$audioOutput=$subsubrootVal['output_device'];
								$audioLevel=$subsubrootVal['level'];	
							
							}

							//processed security array
							if($subsubrootKey=='security'){															
								$webadmin_session_timeout=$subsubrootVal['webadmin_session_timeout'];
								$captcha=$subsubrootVal['captcha'];	
								$alphanumeric=$subsubrootVal['password_policy']['alphanumeric'];	
								$special_char=$subsubrootVal['password_policy']['special_char'];
								$one_capital=$subsubrootVal['password_policy']['one_capital'];
								$password_length=$subsubrootVal['password_policy']['password_length'];
								$basic_mode=$subsubrootVal['password_policy']['basic_mode'];
								$via_admin_pass=$subsubrootVal['via_admin_pass'];
								$via_basic_pass=$subsubrootVal['via_basic_pass'];
								
								//storing security data in array																
								$templateDataArr['webadmin_session_timeout']=$webadmin_session_timeout;	
								$templateDataArr['captcha']=$captcha;	
								$templateDataArr['alphanumeric']=$alphanumeric;	
								$templateDataArr['special_char']=$special_char;							
								$templateDataArr['one_capital']=$one_capital;	
								$templateDataArr['password_length']=$password_length;	
								$templateDataArr['basic_mode']=$basic_mode;	
								$templateDataArr['via_admin_pass']=$via_admin_pass;	
								$templateDataArr['via_basic_pass']=$via_basic_pass;																	
							}//end security
							
							//processed security array
							//$via_admin_pass=@$subsubrootVal['via_admin_pass'];
							//$via_basic_pass=@$subsubrootVal['via_basic_pass'];
							

							//processed certificate array
							if($subsubrootKey=='certificate'){
								$certificate_data=$subsubrootVal['certificate_data'];
								$key_data=$subsubrootVal['key_data'];	
								//Storing certificate data
								$templateDataArr['certificate_data']=$certificate_data;	
								$templateDataArr['key_data']=$key_data;	
														
							}
							
							if($subsubrootKey=='ntp'){								
								$ntpArr=$subrootVal['NTP'];
							}
							
							if($subsubrootKey=='host_config'){								
								$host_config=$subsubrootVal;
								$templateDataArr['via_host_config']=$host_config;
							}
							
							
							//echo $host_config=$subsubrootVal['host_config'];
							//
							
							//processed recording array
							if($subsubrootKey=='recording'){	
								$recording_status=$subrootVal['recording']['status'];
								$recording_location=$subrootVal['recording']['option'];	
								//storing recording 
								$templateDataArr['recording_status']=$recording_status;	
								$templateDataArr['recording_location']=$recording_location;										
								/*foreach($subrootVal['recording'] as $recordingKey=>$recordingVal){								
									if($recordingKey=='status'){
										$recording_status=$recordingVal;
									}
									if($recordingKey=='option'){
										$recording_location=$recordingVal;
									}											
									
								}*/	
							}//end recording
							
							//proxy server
							if($subsubrootKey=='proxy_server'){
								 $server_address=$subrootVal['proxy_server']['server_address'];
								 $port_number=$subrootVal['proxy_server']['port_number'];
								 $user_name=$subrootVal['proxy_server']['user_name'];
								 $password=$subrootVal['proxy_server']['password'];
								//storing Proxy server 
								$templateDataArr['server_address']=$server_address;	
								$templateDataArr['port_number']=$port_number;		
								$templateDataArr['port_user_name']=$user_name;	
								$templateDataArr['port_password']=$password;									
								 
								 
							}

							
						}
				
					}//end of via settings
					
					//Gateway Features
					if($subrootKey=='gway_features'){
						//echo "<pre>";print_r($subrootVal);	
						$collage_GwayFeatures=trim($subrootVal['0']);	
						$connect_GwayFeatures=trim($subrootVal['1']);
						$campus_GwayFeatures=trim($subrootVal['2']);
						$connectplus_GwayFeatures=trim($subrootVal['4']);		
					}//end //Gateway Features
					
					//client Features
					if($subrootKey=='client_features'){
						//echo "<pre>";print_r($subrootVal);
						$collage_ClientFeatures=trim($subrootVal['0']);	
						$connect_ClientFeatures=trim($subrootVal['1']);
						$campus_ClientFeatures=trim($subrootVal['2']);
						$viago_ClientFeatures=trim($subrootVal['3']);
						$connectplus_ClientFeatures=trim($subrootVal['4']);					
					}//end client features
					
					//Mobile Features
					if($subrootKey=='mobile_features'){
						$collage_MobFeatures=trim($subrootVal['0']);	
						$connect_MobFeatures=trim($subrootVal['1']);
						$campus_MobFeatures=trim($subrootVal['2']);
						$viago_MobFeatures=trim($subrootVal['3']);
						$connectplus_MobFeatures=trim($subrootVal['4']);					
					
					}//end mobile features
					
					if($subrootKey=='via_details'){					
						$templateDataArr['airplay_number']=$subrootVal['airplay_number'];
						$templateDataArr['airplayname']=$subrootVal['airplayname'];
						$templateDataArr['via_roomname']=$subrootVal['dnsname'];						
					}
					
					if($subrootKey=='thirdparty'){
						$templateDataArr['zoom']=$subrootVal['zoom'];
						$templateDataArr['teams']=$subrootVal['teams'];
						$templateDataArr['bluejeans']=$subrootVal['bluejeans'];
						$templateDataArr['closeall']=$subrootVal['closeall'];
					}
					
				}
			
			}
						
			//echo $collage_GwayFeatures;
			//B3$1#B18$1#B19$1#B20$1#B6$1#B2$1#B11$1#B13$1#B26$1#B23$1#B22$1#B21$1 
			$collage_gwayFeaturesArr=explode("#",$collage_GwayFeatures);
			$collage_clientFeaturesArr=explode("#",$collage_ClientFeatures);
			$collage_mobFeaturesArr=explode("#",$collage_MobFeatures);
			
			$connect_gwayFeaturesArr=explode("#",$connect_GwayFeatures);
			$connect_clientFeaturesArr=explode("#",$connect_ClientFeatures);
			$connect_mobFeaturesArr=explode("#",$connect_MobFeatures);
		
			$campus_gwayFeaturesArr=explode("#",$campus_GwayFeatures);
			$campus_clientFeaturesArr=explode("#",$campus_ClientFeatures);
			$campus_mobFeaturesArr=explode("#",$campus_MobFeatures);

			$viago_clientFeaturesArr=explode("#",$viago_ClientFeatures);
			$viago_mobFeaturesArr=explode("#",$viago_MobFeatures);
		
			$connectplus_gwayFeaturesArr=explode("#",$connectplus_GwayFeatures);
			$connectplus_clientFeaturesArr=explode("#",$connectplus_ClientFeatures);
			$connectplus_mobFeaturesArr=explode("#",$connectplus_MobFeatures);
			
			
			$langArr['option']=array('zh'=>'Chinese','en'=>"English",'de'=>"German",'ja'=>'Japanese','pl'=>'Polish','ru'=>"Russian",'es'=>'Spanish','fr'=>'French','pt'=>'Portuguese','zh-TW'=>'Traditional chinese');
			//3.3 bug fixing. make drop down as multilingual
			$displayLayoutArr['option'] = array(STR_DYNAMIC_LAYOUT_VIEW,STR_LEFT_THUMBNAIL_VIEW,STR_RIGHT_THUMBNAIL_VIEW,STR_BOTTOM_THUMBNAIL_VIEW,STR_FREE_FLOW);				
			$displayLayoutArr['sel'] = $display_layout;
			$dpiFileValue=$user_interface_scaling;
			$langArr['sel'] = $language;
			//$sessionTimeOutArray['option']=array('10'=>'10 Minute','20'=>'20 Minute','30'=>'30 Minute','60'=>'1 Hour','120'=>'2 Hours','360'=>'6 Hours','1440'=>'24 Hours');
			$sessionTimeOutArray['option'] = array('10'=>'10 Minute','20'=>'20 Minute','30'=>'30 Minute','60'=>'1 Hour','120'=>'2 Hours','360'=>'6 Hours','1440'=>'24 Hours');
			$sessionTimeOutArray['sel'] = 1440;
			$sleepArr['option']=array('5'=>5,'10'=>10,'30'=>30,'60'=>60,'120'=>120);			
			$sleepArr['sel'] = $energy_saver_sleep_time;
			$audiolevelArr['option']=array('10'=>'10%','20'=>'20%','30'=>'30%','40'=>'40%','50'=>'50%','60'=>'60%','70'=>'70%','80'=>'80%','90'=>'90%','100'=>'100%');			
			$audiolevelArr['sel'] = $audioLevel;
			
			$audioOutputArr['option']=array('Analog Output'=>'Analog Output','HDMI'=>'HDMI','Display Port'=>'Display Port','USB'=>'USB');			
			$audioOutputArr['sel'] = $audioOutput;
			
			
			$linuxTimezoneArray = $this->getTblTimezonesTable()->fetchAll(1);	
			foreach($linuxTimezoneArray as $timezone) {
				$linuxTimezoneData['option'][$timezone['tz_name']] = $timezone['tz_name'];
				//if($timezone['tz_active_status'] == 1) {
				$linuxTimezoneData['sel'] = $linux_timezone;//'Asia/Kolkata';
				//}
			}

			$windowsTimezoneArray = $this->getTblTimezonesTable()->fetchAll(2);	
			foreach($windowsTimezoneArray as $timezone) {
				$windowsTimezoneData['option'][$timezone['tz_name']] = $timezone['tz_name'];
				//if($timezone['tz_active_status'] == 1) {
				$windowsTimezoneData['sel'] = $win_timezone;//'(UTC+05:30) Chennai, Kolkata, Mumbai, New Delhi';
				//}
			}
			
			//recreating NTP file when edit the template 						
			$ntpData = json_encode($ntpArr);	
			//$ntpFile = UPLOAD_DIR_ZEND."uploads/".'ntp_'.$loginName.'.txt';
			//$ntpFile = UPLOAD_DIR_ZEND."uploads/".'ntp_'.$loginName.'.txt';	
			$ntpFile = UPLOAD_PATH_INTERNAL.'ntp_'.$loginName.'.txt';
			file_put_contents($ntpFile, $ntpData);

			//recreating extension file when edit the template 						
			$extensionData = json_encode($extensions);	
			//$fileFormatFile = UPLOAD_DIR_ZEND."uploads/".'auth_fileformat_'.$loginName.'.txt';	
			$fileFormatFile = UPLOAD_PATH_INTERNAL.'auth_fileformat_'.$loginName.'.txt';
			file_put_contents($fileFormatFile, $extensionData);
			
			
			//$timezonesArr=$this->getTblTimezonesTable()->fetchAll(1);
			
			$formData = array('langArr' =>$langArr,
			'displayLayoutArr' =>$displayLayoutArr,
			'dpiFileValue' =>$dpiFileValue,
			'sessionTimeOutArray'=>$sessionTimeOutArray,
			'sleepArr'=>$sleepArr,
			'linuxTimezoneData' =>$linuxTimezoneData,
			'windowsTimezoneData' =>$windowsTimezoneData,
			'power_off_Hours' =>$power_off_Hours,
			'power_off_Mints' =>$power_off_Mints,
			'power_Reboot_Hours' =>$power_Reboot_Hours,
			'power_Reboot_Mints' =>$power_Reboot_Mints,
			'power_on_Hours' =>$power_on_Hours,
			'power_on_Mints' =>$power_on_Mints,
			'date_time_format'=>$date_time_format,
			'display_layout'=>$display_layout,
			'date_time_format'=>$date_time_format,
			'password_length'=>$password_length,
			'logout_time'=>$webadmin_session_timeout,
			'audiolevelArr' =>$audiolevelArr,
			'audioOutputArr' =>$audioOutputArr,	
			);
			
			$form = new ViaConfigurationForm($formData);
			
			
		
 		//File sharing	
		//$fileFormatFile = BASE_PATH.'/public/uploads/auth_fileformat_'.$loginName.'.txt';
		if(file_exists($fileFormatFile)){
			$fileContent = file_get_contents($fileFormatFile);
			$fileDataArr = (array)json_decode($fileContent);
			$sel = 0;
			$selectedFileFormatArr=array();
			foreach ($fileDataArr as $key => $value) {
				if($value->ext_name != 'All' && $value->ext_name != 'jpeg' && $value->ext_name != 'pdf' && $value->ext_name != 'png' && $value->ext_name != 'jpg'){
					if($value->status == 1){					
						$selectedFileFormatArr[] = $value->ext_name;
					}
				}
				if($value->ext_name == 'All'){
					$selAll = $value->ext_name;
					if($value->status == 0){
						$sel = 1;
					}else{
						$sel = 0;
					}
				}
				if($value->ext_name == 'All' || $value->ext_name == 'jpeg' || $value->ext_name == 'pdf' || $value->ext_name == 'png' || $value->ext_name == 'jpg'){
					continue;
				}else{
					$fileFormatArr[$key]['ext_name'] = $value->ext_name;
					$fileFormatArr[$key]['status'] = $value->status;
				}
			}
			if($sel ==1){
				$fileFormat = 'selected';
			}else{
				$fileFormat = 'all';
			}
		}		
		$resetSessionConfigStatus = $this->getAdvanceMoreFeaturesTable()->fetchProperty('ResetSession');		
		//Get NTP data		
		//$ntpFile = BASE_PATH.'/public/uploads/ntp_'.$loginName.'.txt';
		if(file_exists($ntpFile)){
			$fileContent = file_get_contents($ntpFile);
			$ntpDataArr = (array)json_decode($fileContent);
		}
			
		$getTemplateName=$appObj->getVIASettingsNextTemplateName();	
		if(CHECK_FILE_ASSOCIATE_FILE == 1){
			$get_whiteBoardAssociateFileContent=$appObj->file_read(DEST_PATH.FILE_ASSOCIATE_FILE);
		}else{
			$get_whiteBoardAssociateFileContent = '';
		}
		if(CHECK_FILE_BROWSE_ASSOCIATE==1){
			$get_browseAssociateFileContent=$appObj->file_read(DEST_PATH.FILE_BROWSE_ASSOCIATE);
		}else{
			$get_browseAssociateFileContent = '';
		}
		return new ViewModel(array('form' => $form,'fileFormat' => $fileFormat, 'fileFormatArr' => $fileFormatArr, 'selAll' => $selAll, 'selectedFileFormatArr' => $selectedFileFormatArr,'ntpDataArr'=>$ntpDataArr,'custTempName'=>$getTemplateName,'templateDataArr'=>$templateDataArr,'ntpArr'=>$ntpArr,'collageGwayfeaturesData'=>$collage_gwayFeaturesArr,'collageClientfeaturesData'=>$collage_clientFeaturesArr,'collageMobilefeaturesData'=>$collage_mobFeaturesArr,'connectGwayfeaturesData'=>$connect_gwayFeaturesArr,'connectClientfeaturesData'=>$connect_clientFeaturesArr,'connectMobilefeaturesData'=>$connect_mobFeaturesArr,'campusGwayfeaturesData'=>$campus_gwayFeaturesArr,'campusClientfeaturesData'=>$campus_clientFeaturesArr,'campusMobilefeaturesData'=>$campus_mobFeaturesArr,'viagoClientfeaturesData'=>$viago_clientFeaturesArr,'viagoMobilefeaturesData'=>$viago_mobFeaturesArr,'connectplusGwayfeaturesData'=>$connectplus_gwayFeaturesArr,'connectplusClientfeaturesData'=>$connectplus_clientFeaturesArr,'connectplusMobilefeaturesData'=>$connectplus_mobFeaturesArr,'encryptedTempName'=>$encryptedTempName,'settingTemplateName'=>$settingTemplateName,'intTemplateId'=>$appObj->desEncrypt($intTemplateId, KEY_SEED),'templateAction'=>$templateAction,'viaModel'=>$viaModel,'stream_option'=>$stream_option,'stream_url1'=>$stream_url1,'stream_url2'=>$stream_url2,'deviceostype'=>$deviceostype,'viaServerIP'=>$viaServerIP,'modellike'=>$modellike,'modelshow'=>$modelshow,'get_whiteBoardAssociateFileContent' => $get_whiteBoardAssociateFileContent,'get_browseAssociateFileContent' => $get_browseAssociateFileContent,'clientOS'=>$clientOS,'supportMiracast'=>$supportMiracast,'wifiMiracastFlag'=>$wifiMiracastFlag,'check_wifi'=>$check_wifi,'check_wifi_OnOff'=>$check_wifi_OnOff,'modelValue'=>$modelValue,'templateActionName'=>$templateActionName, 'displayCount_content' => $displayCount_content, 'getTemplateStatus'=>$getTemplateStatus, 'tebName'=>$tebName));			
		}
		
		//ajax call	
		public function getLayoutDataAction(){
			$request = $this->getRequest();
			if($request->isXmlHttpRequest()) {
				$appObj = new ApplicationController();
				$tempid=trim($request->getPost('tempid'));
				$model_type=trim($request->getPost('model_type'));
				$grp_qry = $appObj->returnQueryData("SELECT DISTINCT isGrpIdOrDeviceId FROM tbl_via_settings_templates_mapping WHERE template_id=$tempid AND entryType=0 AND model_type=$model_type");
				if($grp_qry->count()>0){
					$grpArr = array();
					foreach($grp_qry as $grp){
						$grpArr[]= $grp['isGrpIdOrDeviceId'];
					}
					echo json_encode($grpArr);die;
				}
				echo "nodata";die;
			}
		}
		
	public function setTemplateAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$tempid=trim($request->getPost('tempid'));
			$model_type=trim($request->getPost('model_type'));
			$grpIdStr=trim($request->getPost('grpId'));
			$grpIdArr = explode(',',$grpIdStr);	
			//create default entry for unchecked grps	
			$uncheckedGrpIdStr=trim($request->getPost('uncheckedGrpIds'));
			$uncheckedGrpIdArr = explode(',',$uncheckedGrpIdStr);
			
			//Check for VSM and Gateway version check
			$statusVersion = $appObj->checkGatewayAndVSMVerion($grpIdStr);			
			if($statusVersion == 1){
				echo 2; die;
			}
			
			$appObj->executeQueries("DELETE FROM tbl_via_settings_templates_mapping WHERE template_id=$tempid AND entryType=0 AND model_type=$model_type AND isGrpIdOrDeviceId NOT IN ($grpIdStr)");
			foreach($grpIdArr as $grp){
				$os_qry = $appObj->returnQueryData("SELECT * FROM  tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$grp AND entryType=0 AND model_type=$model_type");		
				if($os_qry->count()==0){
						$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping (template_id,isGrpIdOrDeviceId,entryType,modifydatetime,model_type) VALUES($tempid,$grp,0,NOW(),$model_type)");
					}else{
						$appObj->executeQueries("UPDATE tbl_via_settings_templates_mapping SET template_id=$tempid, isGrpIdOrDeviceId=$grp, modifydatetime=NOW() WHERE isGrpIdOrDeviceId=$grp AND entryType=0 AND model_type=$model_type");
					}	
			}
			
			//create default entry for unchecked grps	
			if($uncheckedGrpIdStr!=''){
				foreach($uncheckedGrpIdArr as $uncheckedGrpId){
					$checkUncheckGrpQry = $appObj->returnQueryData("SELECT * FROM  tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$uncheckedGrpId AND entryType=0 AND model_type=$model_type");
					if($checkUncheckGrpQry->count()==0){
							$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping (template_id,isGrpIdOrDeviceId,entryType,modifydatetime,model_type) VALUES(1,$uncheckedGrpId,0,'".date('Y-m-d H:i:s')."',$model_type)");
					
					}
				}
			}	
			
			//updating tbl_sys_report
			$gatewayIdArray = $this->getDeviceInventoryTable()->getDIDFromGroupId($grpIdStr);
			foreach ($gatewayIdArray as $key => $value) {
				$getGwayList .=$value['DID'].",";
			}
			 $gwayList=rtrim($getGwayList,",");
			 if($gwayList!=''){
				$appObj->executeQueries("UPDATE tbl_sys_report SET configSettingStatus=0 WHERE did_fk IN ($gwayList) AND configSettingStatus=1");
				$appObj->executeQueries("UPDATE DeviceInventory SET global_sync_status=0 WHERE DID IN($gwayList)");
			 }
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);			
			echo "1";die;
		}
	}
	
	//ajax call to create duplicate template
	public function createDuplicateTemplateAction(){
		$session = new Container('userinfo');		
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$appObj = new ApplicationController();
		$request = $this->getRequest();
		$tempname=trim($request->getPost('tempname'));
		$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		$encryptedTempId=trim($tempname);
		$input=str_replace(' ','+',$encryptedTempId);
		$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
		$tempname=$appObj->desDecrypt($input, KEY_SEED);
		$whereArr = array('template_name' => $tempname);
		$sourceTemplateSql = $this->getViaSettingsTemplatesTable()->getTemplate($whereArr)->current();
		$sourceTemplateFile = UPLOAD_DIR_ZEND.$sourceTemplateSql->template_path;
		/*$qryData=$appObj->returnQueryData("SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '".DB_NAME."' AND TABLE_NAME= 'tbl_via_settings_templates'")->current();		
		$tblAutoIncreamentNo=$qryData['AUTO_INCREMENT'];*/
		
		/*$qryData=$appObj->returnQueryData("SELECT nextval('tbl_via_settings_templates_id_seq') as auto_increment")->current();  
		$tblAutoIncreamentNo=$qryData['auto_increment'];*/

		$templateName = $appObj->getCopiedName($tempname);
		//$templatePath = 'uploads/'.TEMPLATE_DIR_CONFIG.'settings_'.$tblAutoIncreamentNo.'.json';
		$dataArr=array('template_name'=>$templateName,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>'','model_type'=>PRODUCT_MODEL_TYPE,'modifydatetime'=>date('Y-m-d H:i:s'));		
		$lastInsrtedId =  $this->getViaSettingsTemplatesTable()->insertData($dataArr);
		
		/*---- update template path after insert ---- */
		$templatePath = 'uploads/'.TEMPLATE_DIR_CONFIG.'settings_'.$lastInsrtedId.'.json';
		$this->getViaSettingsTemplatesTable()->updateTableData(array('template_path'=>$templatePath), $lastInsrtedId);
		/*---- end update template path after insert ---- */

		$copiedTemplateFile = UPLOAD_DIR_ZEND.$templatePath;	
		copy($sourceTemplateFile,$copiedTemplateFile);	
		die;			
	}
	//sending command when exit in edit mode	
	public function exitTemplateAction(){
		$session = new Container('userinfo');
		if(PRODUCT_TYPE=="vsm" || PRODUCT_TYPE=="c8hq"){
			//Rabbit MQ Code
			$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->rabbitWebProducerAction($cmdJson);
		}else{
			$appObj = new ApplicationController();
			//modified code by ashu on 30Dec22 for getting model like
			$modellike=$appObj->getModelNameByParam('modellike');
			
			$getMacAddr=strrev(file_get_contents(DEST_PATH.FILE_MAC_ADDRESS));		
			$encryptedTempId=trim($_POST['id']);
			$input=str_replace(' ','+',trim($encryptedTempId));
			$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
			$intTemplateId=$appObj->desDecrypt($input, KEY_SEED);	
			//active template
			$appObj->executeQueries("UPDATE tbl_via_settings_templates SET status = CAST((id = $intTemplateId) AS INTEGER)");
			$getActiveTemplateSql = $appObj->returnQueryData("SELECT status,template_path FROM tbl_via_settings_templates WHERE id=$intTemplateId");
			$templateStatus=0;
			foreach($getActiveTemplateSql as $activeTemplateData){						
				$templateStatus = $activeTemplateData['status'];
				$templatepath = $activeTemplateData['template_path'];				
			}
			if($templateStatus==1){
				//copy active template inside config
				$sourceSettingFile = UPLOAD_DIR_ZEND.$templatepath;
				$settingsFile = DEST_PATH.'via_settings.json';
				
				//modified by ashu on 20DEc22 for Updating dns name/roomname in active tyemplate
					$sourceFile_content=file_get_contents($sourceSettingFile);		
					//decrypt json					
					$decryptSourceFile = $appObj->desDecrypt($sourceFile_content,POLL_ENCRPTION_KEY);
					$jsonArrayy=json_decode($decryptSourceFile, true);
					$get_dnsName=$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details']['dnsname'];
					$get_autoDnd=$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_dnd'];
					
					$via_details_arr = $jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'];	            
					//added by ashu on 14Dec22. getting ssid or hostname for dns name								
					$sessionNetworkData=$session->offsetGet('networkData');	
					if($get_dnsName=="" || $get_autoDnd==1){		
						if($get_dnsName==""){			
							/*$get_roomname=(strtolower($sessionNetworkData['mode'])=="ap")?"VIA_".trim($sessionNetworkData['SSID']):(file_exists(DEST_PATH . READFILE_ROOMNAMEVALUESHOW)?trim(file_get_contents(DEST_PATH . READFILE_ROOMNAMEVALUESHOW)):$sessionNetworkData['Lan1_Host']);
							$via_details_arr['dnsname']=$get_roomname;					
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'] = $via_details_arr;*/
							// code changes by niraj
							$arrRnameData = $appObj->getRoomNameWithType($sessionNetworkData);
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details']['dnsname'] = $arrRnameData['roomname'];
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = $arrRnameData['via_roomname_type'];
						}
						if(isset($jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_dnd'])){
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_dnd']="0";
						}
						//fix file extension issue.
						if($modellike==0){
							$get_gwayFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features'];								
							$gwayFeaturesKeyArr=array_keys($get_gwayFeatures);
							$gwayFeaturesValArr=$get_gwayFeatures[0];
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features']=(object)[0=>$gwayFeaturesValArr];
							
							$get_clientFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features'];							
							$clientFeaturesKeyArr=array_keys($get_clientFeatures);
							$clientFeatureskey=$clientFeaturesKeyArr[0];
							$clientFeaturesValArr=$get_clientFeatures[0];						
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=(object)[0=>$clientFeaturesValArr];
		
							$get_mobFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features'];								
							$mobFeaturesKeyArr=array_keys($get_mobFeatures);
							$mobFeaturesValArr=$mobFeaturesKeyArr[0];
							$mobFeaturesValArr=$get_mobFeatures[0];
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=(object)[0=>$mobFeaturesValArr];					
						}						
						
						//Encrypt to json				
						$encodedData = json_encode($jsonArrayy,true);	
						$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);										
						file_put_contents($sourceSettingFile, $encryptedJson);						
					}
				//end Updating dns name/roomname in active tyemplate
				
				copy($sourceSettingFile, $settingsFile);
				//added on 20July2021 for sending msteamsoff command before publish the template
				$modellike=$appObj->getModelNameByParam('modellike');
				if($modellike==4){
					$read_contents=file_get_contents($settingsFile);
					$decrypt_read_contents = $appObj->desDecrypt($read_contents,POLL_ENCRPTION_KEY);
					$content_jsonArray=json_decode($decrypt_read_contents, true);				
					if($content_jsonArray['VIA_CONFIG_TEMPLATE']['thirdparty']['teams']==0){
						$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
						$actioncmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>msteamsoff</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
						$appObj->sendMsgToAPIserver($logincmd,$actioncmd);
					}
				}
				//Rabbit MQ Code
				$cmdArr=array("cmd"=>"set_local_settings","sender"=>"web-vsm");
				$cmdJson=json_encode($cmdArr);
				$producerObject=new WebProducerController();
				$producerObject->sentRabbitCmdWebProducerAction($cmdJson,array('exchange_name'=>'apiclient','bindingKey'=>$getMacAddr));
							
			}
		
		}	
		die;
	}
	
	//VIA Setting Advance configuration Ajax - Added by Ranjan
	public function advancedConfigurationAction() {
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$selChkBoxName = trim($request->getPost('chkBoxName'));
			$chkBoxVal = trim($request->getPost('chkBoxVal'));
			//Fix security issue if anyone post query
			if(strstr($selChkBoxName,'select')){
				die('Access denied');
			}			
			if(strstr($chkBoxVal,'select')){
				die('Access denied');
			}			

			
			$AppObject = new ApplicationController();
			
			
			if($selChkBoxName == 'audioConfigBox') {
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetAudioDevice</Cmd><P1>$chkBoxVal</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$return = $AppObject->returnSocketData($logincmd, $actionCmd);
				$explode = explode("|", $return);
				$strValue = $explode[1];
				if($strValue == 1) {

					//start added by niraj for get realtime audio info
					$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$audioOutput_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetAudioDevice</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$returnResult = $AppObject->getDataFromAPIServer($logincmd, $audioOutput_cmd);					
					$returnResultArray = explode('|', $returnResult);
					if($returnResult!='' && $returnResultArray[1]!=""){
						file_put_contents(DEST_PATH.'web_audio_output_data.txt', $returnResult);
					}
					//end added by niraj for get realtime audio info
					
					echo 'successAndReboot';
				} else {
					echo 'unsuccess';
				}
				
				if(PRODUCT=='via'){
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_AUDIO_CONFIGBY, $hostname);
				}else{
					$setActivity = $AppObject->ActivityLogVSM(7,MSG_SET_AUDIO_CONFIGBY,6);
				}
				
				//echo 'successAndReboot';
				die;
			}
			//set audio Input device
			if($selChkBoxName == 'audioInConfigBox') {
				$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetAudioInputDevice</Cmd><P1>$chkBoxVal</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
				$return = $AppObject->returnSocketData($logincmd, $actionCmd);
				$explode = explode("|", $return);
				$strValue = $explode[1];
				if($strValue == 1) {

					//start added by niraj for get realtime audio info
					$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$audioInput_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetAudioInputDevice</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$returnResultAudioInput = $AppObject->getDataFromAPIServer($logincmd, $audioInput_cmd);
					$audioInputArray = explode('|', $returnResultAudioInput);								
					if($returnResultAudioInput!='' && $audioInputArray[1]!=''){
						file_put_contents(DEST_PATH.'web_audio_input_data.txt', $returnResultAudioInput);
					}
					//end added by niraj for get realtime audio info

					echo 'successAndReboot';
				} else {
					echo 'unsuccess';
				}
				if(PRODUCT=='via'){
				$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_AUDIO_IN_CONFIGBY, $hostname);
				}else{
					$AppObject->ActivityLogVSM(7,MSG_SET_AUDIO_IN_CONFIGBY,6);
				}
				//echo 'successAndReboot';
				die;
			}
			//Streaming Configuration. added for 2.2 and updated on 19May2017
			if($selChkBoxName == 'setStramingConfiguration') {
				$url1 = trim($_POST['url1']);
				$url2 = trim($_POST['url2']);
				if($chkBoxVal == 1) {
					$countStreamingRows = $this->getStreamingSettingsTable()->countRows();
					$stramingData = array('display_url_1' =>$url1,'display_url_2' =>$url2,'status' =>$chkBoxVal);					
					if($countStreamingRows > 0) {
						$this->getStreamingSettingsTable()->updateStreaming($stramingData);
					} else {
						$this->getStreamingSettingsTable()->insertStreaming($stramingData);
					}
				} else {
					$stramingStatusData = array('status' =>$chkBoxVal);
					$this->getStreamingSettingsTable()->updateStreaming($stramingStatusData);
					// added on 17May2017 for sending command to api server in case of streaming off
					$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$actionCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>ForceStopStream</Cmd><P1>$loginName</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$AppObject->sendMsgToAPIserver($logincmd, $actionCmd);
				}
				if(PRODUCT=='via'){
					$setActivity = $this->getActivityLogMasterTable()->setActivity($loginName, 'Activate', MSG_SET_STREAMINGBY, $hostname);
				}else{
					$AppObject->ActivityLogVSM(7,MSG_SET_STREAMINGBY,6);
				}
				//echo 'successAndReboot';
				die;
			}
		}
	}	
	// ajax call to get audio input/output on via side
	public function getAudioInputOutputAction(){

		//remove these file if request come fro new status
		$request = $this->getRequest();
		if($request->getPost('mode') == 'cmd'){
			if(file_exists(DEST_PATH.'web_audio_input_data.txt')){
				unlink(DEST_PATH.'web_audio_input_data.txt');
			}
			if(file_exists(DEST_PATH.'web_audio_output_data.txt')){
				unlink(DEST_PATH.'web_audio_output_data.txt');
			}
		}

		//audio config change . Now commands will be same for window/Linux. output 'GetAudioDevice|1|HDMI#USB|USB'; it means HDMI and USB will be show in dropdown and USB will be selected 
		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$audioOutput_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetAudioDevice</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$audioInput_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetAudioInputDevice</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		
		/* **********************audio Input code  ******************* */
		$appObj = new ApplicationController();

		//this check added for get audio info from file or cmd
		if(file_exists(DEST_PATH.'web_audio_input_data.txt') && filesize(DEST_PATH.'web_audio_input_data.txt') != 0){
			$returnResultAudioInput = file_get_contents(DEST_PATH.'web_audio_input_data.txt');
		}else{
			$returnResultAudioInput = $appObj->getDataFromAPIServer($logincmd, $audioInput_cmd);
			file_put_contents(DEST_PATH.'web_audio_input_data.txt', $returnResultAudioInput);
		}

		//$returnResultAudioInput = $appObj->showNetworkInfo($logincmd, $audioInput_cmd);

		//checking command output
		$audioInputArray = explode('|', $returnResultAudioInput);			
		if($returnResultAudioInput!='' && $audioInputArray[1]!=''){	
			//$audioInputArray = explode('|', $returnResultAudioInput);
			$audioInputString='';
			foreach($audioInputArray as $audioInkey=>$audioInval){
				//echo '<br>'.$k.'. and '.$val;
				if($audioInkey==1){
					//for drop down					
					$audioInputString.=$audioInputArray[$audioInkey];
				}
				if($audioInkey==2){
					//showing selected option	
					$selectedAudioInput=$audioInputArray[$audioInkey];
				}
				
			}//end of foreach
			if(strstr($audioInputString,'#')){
				$audioInputConfigNumericArray=explode('#',$audioInputString);
			}else{
				$audioInputConfigNumericArray=array($audioInputString);
			}				
			//change numeric array to associative array				
			foreach($audioInputConfigNumericArray as $myInval){
				$audioInputConfigArray[$myInval]=$myInval;
			}				
			$audioInputConfig=$selectedAudioInput;
		}
		/***************** audio Input code end ******************* */

		/* ****************audio Output code  ********************* */

		//this check added for get audio info from file or cmd
		if(file_exists(DEST_PATH.'web_audio_output_data.txt') && filesize(DEST_PATH.'web_audio_output_data.txt') != 0){
			$returnResult = file_get_contents(DEST_PATH.'web_audio_output_data.txt');
		}else{
			$returnResult = $appObj->getDataFromAPIServer($logincmd, $audioOutput_cmd);
			file_put_contents(DEST_PATH.'web_audio_output_data.txt', $returnResult);
		}

		//$returnResult = $appObj->showNetworkInfo($logincmd, $audioOutput_cmd);

		//checking command output
		$returnResultArray = explode('|', $returnResult);
		if($returnResult!='' && $returnResultArray[1]!=""){
			$audioOutputString='';
			foreach($returnResultArray as $audiokey=>$audioval){
				//echo '<br>'.$k.'. and '.$val;
				if($audiokey==1){
					//for drop down					
					$audioOutputString.=$returnResultArray[$audiokey];
				}
				if($audiokey==2){
					//showing selected option					
					$selectedAudioOutput=$returnResultArray[$audiokey];
				}
				
			}			
			
			if(strstr($audioOutputString,'#')){
				$audioConfigNumericArray=explode('#',$audioOutputString);
			}else{
				$audioConfigNumericArray=array($audioOutputString);
			}
			//change numeric array to associative array
			foreach($audioConfigNumericArray as $myval){
				$audioConfigArray[$myval]=$myval;
			}				
			$audioConfig=$selectedAudioOutput;
			//end	
		}

		if(isset($audioConfigArray)){
            $audioConfigArr['option'] = $audioConfigArray;
        }else{
            $audioConfigArr['option'][] = MSG_NO_RECORD;
        }
		
		//Audio Input Code
        if(isset($audioInputConfigArray)){
            $audioInputConfigArr['option'] = $audioInputConfigArray;
        }else{
            $audioInputConfigArr['option'][] = MSG_NO_RECORD;
        }

		$audioConfigArr['sel'] = $audioConfig;
		$audioInputConfigArr['sel'] = $audioInputConfig;
		$audioArr = array('inputOpt' => $audioInputConfigArr['option'], 'inputVal' => $audioInputConfig, 'outputOpt' => $audioConfigArr['option'], 'outputVal' => $audioConfig);
		echo json_encode($audioArr);die;
	}

	public function publishSettingsAction(){
		$session = new Container('userinfo');		
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$modellike=$appObj->getModelNameByParam('modellike');
			$tempid = trim($request->getPost('tmpId'));
			$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
			//Security changes added by ashu on 31/03/22. Allow only numeric value 
			if(!is_numeric($tempid) || $tempid <= 0 ){
				echo "Id is not valid";die;
			}		
			
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			
			$templateSql = $appObj->returnQueryData("SELECT id,template_name,template_path FROM tbl_via_settings_templates WHERE id=$tempid");
			foreach($templateSql as $settings){
				$templateid = $settings['id'];
				$templatename = $settings['template_name'];
				$templatepath = $settings['template_path'];
			}
			$sourceSettingFile = UPLOAD_DIR_ZEND.trim($settings['template_path']);
			
			//Added on 28Jan2022 by ashu. We are updating broadcast json in old template when publish. We are checking autobroadcast tag to identify its old template or new.			
				$sourceFile_content=file_get_contents($sourceSettingFile);		
				//decrypt json					
				$decryptSourceFile = $appObj->desDecrypt($sourceFile_content,POLL_ENCRPTION_KEY);
				$jsonArrayy=json_decode($decryptSourceFile, true);
				//getting DNS Name from template
				$get_dnsName=$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details']['dnsname'];
				$get_autoDnd=$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_dnd'];

				//checking if autobroadcast tag is present in json. if  autobroadcast tag not present 
				if(!isset($jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_broadcast']['autobroadcast'])){				
					$broadcastValue=$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_broadcast'];
					$systemArr = $jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system'];		
					if($broadcastValue==1){								
						$systemArr['via_broadcast'] = array('status'=>1,"autobroadcast"=>1,"dataoversound"=>0,"bluetooth"=>0);											
					}else{
						$systemArr['via_broadcast'] = array('status'=>0,"autobroadcast"=>0,"dataoversound"=>0,"bluetooth"=>0);
					}
					
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system'] = $systemArr;
					//Encrypt to json				
					$encodedData = json_encode($jsonArrayy,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);				
					file_put_contents($sourceSettingFile, $encryptedJson);
					//end
					
				}				
				
				//End update broadcast json in old template when publish 
				//update auto_disconnection json in old template when publish
				
				if(!isset($jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_disconnection']['status'])){
					$presentationArr = $jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation'];	
					$presentationArr['auto_disconnection'] = array('status'=>1,"deviation"=>15,"attempts"=>3,"avgcount"=>10);
					//Upgrade ResetSession
					$presentationArr['reset_session'] = "0";	
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation'] = $presentationArr;
					//upgrade VMD to 1
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=str_replace('#B9$0','#B9$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']);
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=str_replace('#B9$0','#B9$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']);
					
					//Encrypt to json				
					$encodedData = json_encode($jsonArrayy,true);
					//echo"<pre>";print_r($encodedData);	die;
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);				
					file_put_contents($sourceSettingFile, $encryptedJson);
					//end				
				}//End update auto_disconnection json in old template when publish
			
				/*if(!isset($jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['run_via'])){
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['run_via']=1;
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['install_via']=1;
					//Encrypt to json				
					$encodedData = json_encode($jsonArrayy,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);				
					file_put_contents($sourceSettingFile, $encryptedJson);
					//end
				}*/
				if($modellike==3){
					//Updating B9 in connect2 Client Features
					$get_Go2_ClientFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features'];
					$getGo2_clientFeatures=$get_Go2_ClientFeatures[3];				
					//if V9 not exists in Go2 client features
					if(!strstr($getGo2_clientFeatures,'V9')){
						$explode_Go2_clientFeatures=explode("#",$getGo2_clientFeatures);
						$arr_last_element_Go2clientFeatures=end($explode_Go2_clientFeatures);
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=str_replace($arr_last_element_Go2clientFeatures,$arr_last_element_Go2clientFeatures.'#V9$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']);
						
					}
					

					//Updating B9 in connect2 Mobile Features
					$get_Go2_MobFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features'];
					$getGo2_MobFeatures=$get_Go2_MobFeatures[3];				
					//if V9 not exists in Go2 Mobile features
					if(!strstr($getGo2_MobFeatures,'V9')){
						$explode_Go2_MobFeatures=explode("#",$getGo2_MobFeatures);
						$arr_last_element_Go2MobFeatures=end($explode_Go2_MobFeatures);
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=str_replace($arr_last_element_Go2MobFeatures,$arr_last_element_Go2MobFeatures.'#V9$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']);
						
					}
					
					
					
					//Encrypt to json				
					$encodedData = json_encode($jsonArrayy,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);								
					file_put_contents($sourceSettingFile, $encryptedJson);
					//end
					
				
				}

				if($modellike==4){
					//Updating V20 in connect2 Gateway Features
					$get_gwayFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features'];
					$getConnect2_gwayFeatures=$get_gwayFeatures[4];				
					//if B20 not exists in connect2 gateway features
					if(!strstr($getConnect2_gwayFeatures,'V20')){
						$explode_Connect2_gwayFeatures=explode("#",$getConnect2_gwayFeatures);
						$arr_last_element_gwayFeatures=end($explode_Connect2_gwayFeatures);
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features']=str_replace($arr_last_element_gwayFeatures,$arr_last_element_gwayFeatures.'#V20$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features']);
						
					}				
					
					//Updating V20 in connect2 Client Features
					$get_clientFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features'];
					$getConnect2_clientFeatures=$get_clientFeatures[4];				
					//if V20 not exists in connect2 client features
					if(!strstr($getConnect2_clientFeatures,'V20')){
						$explode_Connect2_clientFeatures=explode("#",$getConnect2_clientFeatures);
						$arr_last_element_clientFeatures=end($explode_Connect2_clientFeatures);
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=str_replace($arr_last_element_clientFeatures,$arr_last_element_clientFeatures.'#V20$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']);
						
					}
					
				
					//Updating B20 in connect2 Mobile Features
					$get_mobFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features'];
					$getConnect2_mobFeatures=$get_mobFeatures[4];
					
					//echo "<pre>";print_r($getConnect2_mobFeatures);
					//echo "<br>";
					//if V20 not exists in connect2 mobile features
					if(!strstr($getConnect2_mobFeatures,'V20')){
						$explode_Connect2_mobFeatures=explode("#",$getConnect2_mobFeatures);
						$arr_last_element_mobFeatures=end($explode_Connect2_mobFeatures);
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=str_replace($arr_last_element_mobFeatures,$arr_last_element_mobFeatures.'#V20$1',$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']);
						
					}
					//die($sourceSettingFile);
					//Encrypt to json				
					$encodedData = json_encode($jsonArrayy,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);								
					file_put_contents($sourceSettingFile, $encryptedJson);
					//end
					//die('success'.$sourceSettingFile);
				
				}


				//check if file_sharing_settings => extensions exist but data is blank
				if(PRODUCT_TYPE == "via" && empty($jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['file_sharing_settings']['extensions'])){
					$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['file_sharing_settings']['extensions'] = $appObj->addFileExtensionIfBlank();
					$encodedData = json_encode($jsonArrayy,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);								
					file_put_contents($sourceSettingFile, $encryptedJson);
				}

				//updating dns name in active template
				if($get_dnsName=="" || $get_autoDnd==1){				
					//$via_details_arr = $jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details'];	            
					//added by ashu on 14Dec22. getting ssid or hostname for dns name
					//$get_roomname='';	
					if($get_dnsName==""){				
						$sessionNetworkData=$session->offsetGet('networkData');						
						/*$get_roomname=(strtolower($sessionNetworkData['mode'])=="ap")?"VIA_".trim($sessionNetworkData['SSID']):(file_exists(DEST_PATH . READFILE_ROOMNAMEVALUESHOW)?trim(file_get_contents(DEST_PATH . READFILE_ROOMNAMEVALUESHOW)):$sessionNetworkData['Lan1_Host']);
						//$via_details_arr['dnsname']=$get_roomname;
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details']['dnsname'] = $get_roomname;*/
						// code changes by niraj
						if($templatename == "default"){ // for default template
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details']['dnsname'] = !empty($sessionNetworkData['Lan1_Host'])?$sessionNetworkData['Lan1_Host']:$sessionNetworkData['wifi1_Host'];
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = "2";
						}else{
							$arrRnameData = $appObj->getRoomNameWithType($sessionNetworkData);					
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_details']['dnsname'] = $arrRnameData['roomname'];
							$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['system']['via_roomname_type'] = $arrRnameData['via_roomname_type'];
						}
					}
					//Auto DND will be off when old setting publish.
					if(isset($jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_dnd'])){
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['via_settings']['presentation']['auto_dnd']="0";
					}

					if($modellike==0){
						$get_gwayFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features'];								
						$gwayFeaturesKeyArr=array_keys($get_gwayFeatures);
						$gwayFeaturesValArr=$get_gwayFeatures[0];
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['gway_features']=(object)[0=>$gwayFeaturesValArr];
						
						$get_clientFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features'];							
						$clientFeaturesKeyArr=array_keys($get_clientFeatures);
						$clientFeatureskey=$clientFeaturesKeyArr[0];
						$clientFeaturesValArr=$get_clientFeatures[0];						
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['client_features']=(object)[0=>$clientFeaturesValArr];
	
						$get_mobFeatures=$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features'];								
						$mobFeaturesKeyArr=array_keys($get_mobFeatures);
						$mobFeaturesValArr=$mobFeaturesKeyArr[0];
						$mobFeaturesValArr=$get_mobFeatures[0];
						$jsonArrayy['VIA_CONFIG_TEMPLATE']['mobile_features']=(object)[0=>$mobFeaturesValArr];					
					}
					
										
					//Encrypt to json				
					$encodedData = json_encode($jsonArrayy,true);	
					$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);										
					file_put_contents($sourceSettingFile, $encryptedJson);
					//end
				}
				
				
								
			$settingsFile = DEST_PATH.'via_settings.json';
			if(file_exists($settingsFile)){
				unlink($settingsFile);
			}
			copy($sourceSettingFile, $settingsFile);
			$appObj->executeQueries("UPDATE tbl_via_settings_templates SET status = CAST((id = $tempid) AS INTEGER)");
			//added on 20July2021 for sending msteamsoff command before publish the template			
			if($modellike==4){
				//3.2.3 change. added by ashu on 16Niov21 for modifying Teams nad Zoom in via_settings.json
				$settingFile_content=file_get_contents($settingsFile);	
				//decrypt json					
				$decryptSettingFile = $appObj->desDecrypt($settingFile_content,POLL_ENCRPTION_KEY);
				$jsonArray=json_decode($decryptSettingFile, true);
				
				
				
				//update thirdparty Array. now zoom and teams will be off 
				$thirdpartyArr = $jsonArray['VIA_CONFIG_TEMPLATE']['thirdparty'];
				$thirdpartyArr['zoom'] = 0;	
				$thirdpartyArr['teams'] = 0;
				$thirdpartyArr['closeall'] = 0;
					
				$jsonArray['VIA_CONFIG_TEMPLATE']['thirdparty'] = $thirdpartyArr;
				//Encrypt to json				
				$encodedData = json_encode($jsonArray,true);	
				$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);				
				file_put_contents($settingsFile, $encryptedJson);
				//end
			
			
				$read_contents=file_get_contents($settingsFile);
				$decrypt_read_contents = $appObj->desDecrypt($read_contents,POLL_ENCRPTION_KEY);
				$content_jsonArray=json_decode($decrypt_read_contents, true);				
				if($content_jsonArray['VIA_CONFIG_TEMPLATE']['thirdparty']['teams']==0){
					$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$actioncmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>msteamsoff</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$appObj->sendMsgToAPIserver($logincmd,$actioncmd);
				}
			}
			
						
			//Rabbit MQ Code
			$getMacAddr=strrev(file_get_contents(DEST_PATH.FILE_MAC_ADDRESS));
			$cmdArr=array("cmd"=>"set_local_settings","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject=new WebProducerController();
			$producerObject->sentRabbitCmdWebProducerAction($cmdJson,array('exchange_name'=>'apiclient','bindingKey'=>$getMacAddr));
			die;
		}
	}
	
	public function resetSoftwareFeaturesAction(){
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname=DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()){
			$resetFlag = trim($request->getPost('resetFlag'));
			if($resetFlag==3){
				$icon = trim($request->getPost('iconname'));
				if($icon=='Whiteboard'){
					$file=DEST_PATH.FILE_ASSOCIATE_FILE;
				}
				if($icon=='browser'){
					$file=DEST_PATH.FILE_BROWSE_ASSOCIATE;
				}				
				if(file_exists($file)){
					unlink($file);
				}
				echo"success";exit;
			}
		} 
	}
	
	public function browseSystemFilesAction(){
		$this->layout('layout/template');
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		if(isset($_GET['icon'])) $icon=$_GET['icon'];
		if($icon=='Whiteboard'){
			$selFile=DEST_PATH.FILE_ASSOCIATE_FILE;
		}
		if($icon=='browser'){
			$selFile=DEST_PATH.FILE_BROWSE_ASSOCIATE;
		}
		return new ViewModel(array(
			'icon' => $icon,
			'selFile' => $selFile,
			'loginName' => $loginName
		));
	}
	
	public function writeBrowseFilePathAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$browseFilepath = trim($request->getPost('associateFileName'));
			$radioBtnVal = trim($request->getPost('radioBtnVal'));
			$myfile = fopen($browseFilepath, 'w') or die("can't open file");
			$content = $radioBtnVal;	
			$confWrite= fwrite($myfile, $content);
			echo 'success';	die;
		}
	}

	 /*****
		 *	@Function Name: testProxyServerAction
		 *  @description  : test proxy server url
		 *	@Author		  : Vineet
		 *  @Date         : 24-feb-2021
		 *****/
	public function testProxyServerAction(){
		$request = $this->getRequest();
		$appObj = new ApplicationController();
        if ($request->isXmlHttpRequest()) {
            $proxyServerName=trim($_POST['proxyServerName']);
            $proxyPort=trim($_POST['proxyPort']);
            $proxyUserName=trim($_POST['proxyUserName']);
            $proxyPassword=trim($_POST['proxyPassword']);
            $proxyUrl=trim($_POST['proxyUrl']);
			$response='';
            if ($proxyServerName!='' && $proxyPort!="") {
				if (filter_var($proxyServerName, FILTER_VALIDATE_IP) || filter_var($proxyServerName, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
                	$response=$appObj->webserviceToValidateProxy($proxyServerName, $proxyPort, $proxyUserName, $proxyPassword, $proxyUrl);
				}else{
					echo 'failed'; die;
				}
			} 
			
			if($response==200){
			 	echo "success";
			}else{
			 	echo "failed"; 
			}
			die;
            
        }
	}

	/*****
	 *	@Function Name: exporttemplatesAction
	*  @description  : export selected templates
	*	@Author		  : Vineet
	*  @Date         : 05-march-2021
	*****/
	public function exporttemplatesAction(){
		if(isset($_POST['exportTempBtn'])){
			$filesArr=$_POST['exportTempChkbox'];		
			$zip = new ZipArchive();	
            $zip_name = 'Template_'.date('Y-M-d').".settings";
            if($zip->open($zip_name, ZIPARCHIVE::CREATE)!==TRUE){
				$error .=  "* Sorry screen creation failed at this time<br/>";
            }
            foreach($filesArr as $file){
					$templateJson=$file;
					$fileWithoutExt = pathinfo($templateJson, PATHINFO_FILENAME);
					 $basepathJson= UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG;
					 $realBaseJson = realpath($basepathJson);
					 $realUserPathJson = realpath($templateJson);
					 if ($realUserPathJson === false || strpos($realUserPathJson, $realBaseJson) !== 0) {
					 	echo "Path is not correct";die;
					}
					//End
                    $zip->addFile($templateJson,basename($templateJson));
            }
            $zip->close();
		    if(file_exists($zip_name)){
				ob_end_clean();
				header('Content-type: application/zip');
				header('Content-Disposition: attachment; filename="'.$zip_name.'"');
				header("Content-Length:".filesize($zip_name));
				readfile($zip_name);
				unlink($zip_name);
			}			
			die;
		}
	}

	/*****
	 *	@Function Name: exporttemplatesAction
	*  @description  : import selected templates
	*	@Author		  : Vineet
	*  @Date         : 08-march-2021
	*****/
	public function importTemplateAction(){
		$appObj = new ApplicationController();
		$session = new Container('userinfo');				
		$name=$session->offsetGet('LoginName');		
        $filename=$_FILES['zipUploadFile']['name'];
        $tmp_Path = $_FILES['zipUploadFile']['tmp_name'];
		$modellike=$appObj->getModelNameByParam('modellike');
		if(isset($filename)){
			$dirForDb="uploads/";
			$dir =BASE_PATH.'/public/'.IMG_DIR;
            $extracted_path=$dir.'extractTemplates/';
            $target_Path = $dir.$filename;
            move_uploaded_file($tmp_Path, $target_Path);
            $zip = new ZipArchive();
            $response=$zip->open($target_Path);
			if ($response === TRUE){
                $zip->extractTo($extracted_path);
                $zip->close();
                unlink($target_Path);	
				 foreach (glob("$extracted_path*.{json}", GLOB_BRACE) as $file) {
					// $baseName=basename($file);
					// $fileName=explode('_', $baseName);
					// if($fileName[0]!='settings'){
					//  continue;
					// }
                    $fileInfo = pathinfo($file);
                    $ext=$fileInfo['extension'];
                    $fileWithoutExt=$fileInfo['filename'];
					/*$qryData=$appObj->returnQueryData("SELECT `AUTO_INCREMENT` FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = '".DB_NAME."' AND TABLE_NAME= 'tbl_via_settings_templates'")->current();		
					$tblAutoIncreamentNo=$qryData['AUTO_INCREMENT'];*/
					/*$qryData=$appObj->returnQueryData("SELECT nextval('tbl_via_settings_templates_id_seq') as auto_increment")->current();  
					$tblAutoIncreamentNo=$qryData['auto_increment'];*/

					//for generate unque random name
					$uniqueFileName = md5(uniqid(mt_rand(), true));

					$fileWithoutExtNew='settings_'.$uniqueFileName.'.json';
					//$fileWithoutExtNew=$this->getUniqueName($fileWithoutExt);
					$jsonTemplate = $extracted_path.$fileWithoutExt.'.json';
					if(file_exists($jsonTemplate)){
						$templateJson=UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.$fileWithoutExtNew;
						$templatePath='uploads/'.TEMPLATE_DIR_CONFIG.$fileWithoutExtNew;
                        //$template_name='template'.$tblAutoIncreamentNo;
						$template_name=$appObj->getVIASettingsNextTemplateName();
                        rename("$extracted_path"."$fileWithoutExt.json", $templateJson);
							if($modellike==3){
							$jsonContent=file_get_contents($templateJson) or die("Error: Cannot create json object");
							
							//decrypt json					
							$decryptSourceFile = $appObj->desDecrypt($jsonContent,POLL_ENCRPTION_KEY);
							$jsonFileArray=json_decode($decryptSourceFile, true);

							//if V9 not exists in Go2 client features
							$get_Go2_ClientFeatures=$jsonFileArray['VIA_CONFIG_TEMPLATE']['client_features'];
							$getGo2_clientFeatures=$get_Go2_ClientFeatures[3];	
							if(!strstr($getGo2_clientFeatures,'V9')){
								$explode_Go2_clientFeatures=explode("#",$getGo2_clientFeatures);
								$arr_last_element_Go2clientFeatures=end($explode_Go2_clientFeatures);
								$jsonFileArray['VIA_CONFIG_TEMPLATE']['client_features']=str_replace($arr_last_element_Go2clientFeatures,$arr_last_element_Go2clientFeatures.'#V9$1',$jsonFileArray['VIA_CONFIG_TEMPLATE']['client_features']);	
							}

							//if V9 not exists in Go2 Mobile features
							$get_Go2_MobFeatures=$jsonFileArray['VIA_CONFIG_TEMPLATE']['mobile_features'];
							$getGo2_MobFeatures=$get_Go2_MobFeatures[3];		
							if(!strstr($getGo2_MobFeatures,'V9')){
								$explode_Go2_MobFeatures=explode("#",$getGo2_MobFeatures);
								$arr_last_element_Go2MobFeatures=end($explode_Go2_MobFeatures);
								$jsonFileArray['VIA_CONFIG_TEMPLATE']['mobile_features']=str_replace($arr_last_element_Go2MobFeatures,$arr_last_element_Go2MobFeatures.'#V9$1',$jsonFileArray['VIA_CONFIG_TEMPLATE']['mobile_features']);
								
							}

							//Encrypt to json				
							$encodedData = json_encode($jsonFileArray,JSON_FORCE_OBJECT);	
							$encryptedJson = $appObj->desEncrypt($encodedData,POLL_ENCRPTION_KEY);										
							file_put_contents($templateJson, $encryptedJson);	
						}
                    }
					$dataArr=array('template_name'=>$template_name,'created_at'=>date('Y-m-d H:i:s'),'template_path'=>$templatePath,'model_type'=>PRODUCT_MODEL_TYPE,'modifydatetime'=>date('Y-m-d H:i:s'));		
					$lastInsrtedId = $this->getViaSettingsTemplatesTable()->insertData($dataArr);

					/*---- update template path after insert ---- */
					if(file_exists($templateJson)){
						$templateJsonUpdate = UPLOAD_DIR_ZEND.'uploads/'.TEMPLATE_DIR_CONFIG.'settings_'.$lastInsrtedId.'.json';
						$templatePathUpdate = 'uploads/'.TEMPLATE_DIR_CONFIG.'settings_'.$lastInsrtedId.'.json';
						rename($templateJson, $templateJsonUpdate);
						$this->getViaSettingsTemplatesTable()->updateTableData(array('template_path'=>$templatePathUpdate), $lastInsrtedId);
					}
					/*---- end update template path after insert ---- */

				}//end of foreach
			}else{
                $msg='';
                switch($response) {
                    case ZipArchive::ER_NOZIP:
                        $msg = 'not a screen archive';break;
                    case ZipArchive::ER_INCONS :
                        $msg = 'consistency check failed';break;
                    case ZipArchive::ER_CRC :
                        $msg = 'checksum failed';break;
                    case ZipArchive::ER_OPEN:
                        $msg = 'unable to open file';break;
                    default:
                        $msg = 'error ' . $response;
                }
                if($msg!=''){
                    echo $msg;die;
                }
            }die;
		}
		die;
    }
	 /*****
		 *	@Function Name: deltemplatedesignrAjaxAction
		 *  @description  :	delete selected template
		 *	@Author		  : vineet
		 *  @Date         : 9-march-2021
		 *****/
	public function deltemplatedesignrAjaxAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$name = $session->offsetGet('LoginName');
			//get crsf value from session
			$session_crsf_token=$session->offsetGet('crsf_token');
			
			$tmpId=trim($request->getPost('tmpId'));
			$crsf_tokenval=trim($request->getPost('crsf_tokenval'));
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}		
			
			$queryArr=$appObj->returnQueryData("SELECT * FROM tbl_via_settings_templates WHERE id IN ($tmpId)");
			foreach($queryArr as $queryData){
				$template_name=$queryData['template_name'];	
				$templateArr = explode('/', $queryData['template_path']);
				$templateJson = $templateArr[2];			
				$templateNamejson=($queryData['template_path']!='')? UPLOAD_DIR_ZEND."uploads/".TEMPLATE_DIR_CONFIG.$templateJson:$template_name.'.json';
				if(file_exists($templateNamejson)){
					unlink($templateNamejson);
				}
			}
			$appObj->executeQueries("DELETE FROM tbl_via_settings_templates WHERE id IN ($tmpId)");
			if(PRODUCT=='via'){
			$appObj->ActivityLog('Delete',STR_CONFIG_TEMPLATE.' : '.$template_name);
			}else{
				$appObj->ActivityLogVSM(5,STR_CONFIG_TEMPLATE.' : '.$template_name,6);
			}
			die;
		}		
	}
	
	public function showLayoutDetailsAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
			$tempid = str_replace(' ','+',trim($request->getPost('tempid')));
			$counter=0;
			$grpArray=array();
			$sql=$appObj->returnQueryData("SELECT A.isGrpIdOrDeviceId,A.template_id,A.entryType FROM tbl_via_settings_templates_mapping A INNER JOIN DeviceGroup B ON A.isGrpIdOrDeviceId = B.DeviceGroupID WHERE A.template_id=$tempid");
			if($sql->count() >0){  
				foreach($sql as $row){
					$counter++;
					$grpArray[] = $row['isGrpIdOrDeviceId'];
					$layout = $this->getViaSettingsTemplatesTable()->getData(array('id'=>$tempid))->current();
					if($row['entryType']==0){
						$seGrpQry=$appObj->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroupID=".$row['isGrpIdOrDeviceId']);
						$deviceOrGrpName='';
						if($seGrpQry->count()>0){
							$resultRow=$seGrpQry->current();
							$deviceOrGrpName=$resultRow['DeviceGroup'];
						}
					}
				}
			}
			
			$grpArray = array_unique($grpArray);
			if(count($grpArray)>0){
				$response .= '<div style="height:30px; color:#000000"><h4>Location Information</h4></div><table  class="table teble-responsive"> 
				<th align="left">'.STR_LOCATION_NAME.'&nbsp;</th>';
				foreach($grpArray as $grpId=>$val){
						$seGrpQry=$appObj->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroupID=".$val);
						$GrpName='';
						if($seGrpQry->count()>0){
							$resultRow=$seGrpQry->current();
							$GrpName=$resultRow['DeviceGroup'];
						}
						$response .= '<tr>					
							<td>'.$GrpName.'</td>';
				}//end of foreach
				$response .= '</table>';
			}
			
			if(count($grpArray)==0){
				$response .= '<table  class="table table-responsive">	
				<th  width="100%" align="left">'.STR_LOCATION_NAME.'&nbsp;</th>  
				<tr><td align="center">'.MSG_NO_RECORD_FOUND.'</td></tr>
			</table>';
			}
			$response .= '<hr class="devider m-t-n-md">';
			echo $response;die;
		}
	}	

 		/*****
		 *	@Function Name: checkFileCount
		 *  @description  :	get patcount file status
		 *	@Author		  : vineet
		 *  @Date         : 25-march-2021
		 *****/
	public function checkFileCountAction(){
		$request = $this->getRequest();
        if ($request->isXmlHttpRequest()) {
			$status=file_exists(DEST_PATH.FILE_PATCOUNT) || file_exists(DEST_PATH.FILE_CAPTURECARD_RUNNING)?1:0;
			echo $status;
			die;
        }
	}

		 /*****
		 *	@Function Name: getViaSettingsTemplatesTable
		 *  @description  : get viasetting table
		 *	@Author		  : Ashu
		 *  @Date         : 22-april-2020
		 *****/
		public function getViaSettingsTemplatesTable() {
			if (!$this->TblViaSettingsTemplatesTable) {	
				$sm = $this->getServiceLocator();		
				$this->TblViaSettingsTemplatesTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesTable');
			}
			return $this->TblViaSettingsTemplatesTable;
		}
		
		 /*****
		 *	@Function Name: getTblGatewayFeaturesTable
		 *  @description  : get gateway features
		 *	@Author		  : Ashu
		 *  @Date         : 28-may-2020
		 *****/
		
        public function getTblGatewayFeaturesTable(){
            if (!$this->TblGatewayFeaturesTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblGatewayFeaturesTable = $sm->get('Webapp\Model\TblGatewayFeaturesTable');
            }
            return $this->TblGatewayFeaturesTable;
        }
		
		 /*****
		 *	@Function Name: getTblClientFeaturesTable
		 *  @description  : get client features
		 *	@Author		  : Ashu
		 *  @Date         : 28-may-2020
		 *****/		
		public function getTblClientFeaturesTable() {
			if(!$this->TblClientsFeaturesTable) {
				$sm = $this->getServiceLocator();
				$this->TblClientsFeaturesTable = $sm->get('Webapp\Model\TblClientsFeaturesTable');
			}
			return $this->TblClientsFeaturesTable;
		}
		
		 /*****
		 *	@Function Name: getTblMobileFeaturesTable
		 *  @description  : get mobile features
		 *	@Author		  : Ashu
		 *  @Date         : 28-may-2020
		 *****/		
		public function getTblMobileFeaturesTable() {
			if(!$this->TblMobileFeaturesTable) {
				$sm = $this->getServiceLocator();
				$this->TblMobileFeaturesTable = $sm->get('Webapp\Model\TblMobileFeaturesTable');
			}
			return $this->TblMobileFeaturesTable;
		}
		
		 /*****
		 *	@Function Name: getTblMobileFeaturesLinuxTable
		 *  @description  : get mobile features
		 *	@Author		  : Ashu
		 *  @Date         : 28-may-2020
		 *****/		
		public function getTblMobileFeaturesLinuxTable() {
			if(!$this->TblMobileFeaturesLinuxTable) {
				$sm = $this->getServiceLocator();
				$this->TblMobileFeaturesLinuxTable = $sm->get('Webapp\Model\TblMobileFeaturesLinuxTable');
			}
			return $this->TblMobileFeaturesLinuxTable;
		}
		
		
		 /*****
		 *	@Function Name: getTblNtpServerTable
		 *  @description  : get NTP data
		 *	@Author		  : Ashu
		 *  @Date         : 28-may-2020
		 *****/		
		public function getTblNtpServerTable() {
			if(!$this->TblNtpServerTable) {
				$sm = $this->getServiceLocator();
				$this->TblNtpServerTable = $sm->get('Webapp\Model\TblNtpServerTable');
			}
			return $this->TblNtpServerTable;
		}
		
		 /*****
		 *	@Function Name: getTblTimezonesTable
		 *  @description  : get timezones
		 *	@Author		  : Ashu
		 *  @Date         : 28-may-2020
		 *****/		
        public function getTblTimezonesTable(){
            if (!$this->TblTimezonesTable) {	
                $sm = $this->getServiceLocator();		
                $this->TblTimezonesTable = $sm->get('Webapp\Model\TblTimezonesTable');
            }
            return $this->TblTimezonesTable;
        }

		 /*****
		 *	@Function Name: getAuthFileFormatTable
		 *  @description  : get `AuthFileFormatTable` table
		 *	@Author		  : Ashu
		 *  @Date         : 19-June-2020
		 *****/	
		public function getAuthFileFormatTable() {
			if(!$this->TblAuthFileFormatTable) {
				$sm = $this->getServiceLocator();
				$this->TblAuthFileFormatTable = $sm->get('Webapp\Model\TblAuthFileFormatTable');
			}
			return $this->TblAuthFileFormatTable;
		}
		
		 /*****
		 *	@Function Name: getAdvanceMoreFeaturesTable
		 *  @description  : get `AdvanceMoreFeaturesTable` table
		 *	@Author		  : Ashu
		 *  @Date         : 19-June-2020
		 *****/			
		public function getAdvanceMoreFeaturesTable() {
			if(!$this->TblAdvanceMoreFeaturesTable) {
				$sm = $this->getServiceLocator();
				$this->TblAdvanceMoreFeaturesTable = $sm->get('Webapp\Model\TblAdvanceMoreFeaturesTable');
			}
			return $this->TblAdvanceMoreFeaturesTable;
		}
		
		 /*****
		 *	@Function Name: getActivityLogMasterTable
		 *  @description  : get `ActivityLogMasterTable` table
		 *	@Author		  : Ashu
		 *  @Date         : 19-June-2020
		 *****/	
		public function getActivityLogMasterTable() {
			if(!$this->TblActivityLogMasterTable) {
				$sm = $this->getServiceLocator();
				$this->TblActivityLogMasterTable = $sm->get('Webapp\Model\TblActivityLogMasterTable');
			}
			return $this->TblActivityLogMasterTable;
		}
		
		 /*****
		 *	@Function Name: getDeviceInventoryTable
		 *  @description  : get `DeviceInventory` table
		 *	@Author		  : Ashu
		 *  @Date         : 19-June-2020
		 *****/	
		public function getDeviceInventoryTable() {
			if(!$this->TblDeviceInventoryTable) {
				$sm = $this->getServiceLocator();
				$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
			}
			return $this->TblDeviceInventoryTable;
		}
		
		 /*****
		 *	@Function Name: getDevicegroupTable
		 *  @description  : get `devicegroup` table
		 *	@Author		  : Ashu
		 *  @Date         : 19-June-2020
		 *****/		
		public function getDevicegroupTable() {
			if(!$this->TblDevicegroupTable) {
				$sm = $this->getServiceLocator();
				$this->TblDevicegroupTable = $sm->get('Webapp\Model\TblDevicegroupTable');
			}
			return $this->TblDevicegroupTable;
		}
		
		 /*****
		 *	@Function Name: getViaSettingsTemplatesSyncTable
		 *  @description  : get `tbl_via_settings_templates_sync` table
		 *	@Author		  : Ashu
		 *  @Date         : 19-June-2020
		 *****/
		public function getViaSettingsTemplatesMappingTable() {
			if (!$this->TblViaSettingsTemplatesMappingTable) {	
				$sm = $this->getServiceLocator();		
				$this->TblViaSettingsTemplatesMappingTable = $sm->get('Webapp\Model\TblViaSettingsTemplatesMappingTable');
				
			}
			return $this->TblViaSettingsTemplatesMappingTable;
		}
		
		public function getStreamingSettingsTable() {
			if(!$this->TblStreamingSettingsTable) {
				$sm = $this->getServiceLocator();
				$this->TblStreamingSettingsTable = $sm->get('Webapp\Model\TblStreamingSettingsTable');
			}
			return $this->TblStreamingSettingsTable;
		}
		
		

}