<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Form\SmtpConfigurationForm;
use Webapp\Controller\ApplicationController;

class SmtpController extends AbstractActionController {

    public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

    public function smtpConfigurationAction(){
        $appObj = new ApplicationController();
        $key=POLL_ENCRYPTION_KEY;
        $query="SELECT mailer_name,mailer_host,mailer_port,mailer_auth,mailer_username, AES_DECRYPT(mailer_password,'$key') as mailer_password,mailer_ssl,from_mail_id FROM tbl_smtp_configuration ORDER BY id DESC LIMIT 1";
        $queryResult = $appObj->returnQueryData($query);
        
        $rowsCount=$queryResult->count();
        if($rowsCount>0){
           foreach($queryResult as $data){
            $auth=$data['mailer_auth'];
           
            $mailerName=$data['mailer_name'];
			$host=$data['mailer_host'];
			$port=$data['mailer_port'];
			$auth=($data['mailer_auth']=='on')?1:0;
			$username=$data['mailer_username'];
			$password=$data['mailer_password'];
			$ssl=($data['mailer_ssl']=='on')?1:0;
			$fromMail=$data['from_mail_id'];
           }
        }else{
            $mode='add';
        }
        $form=new SmtpConfigurationForm();
        $form->setData(array('search' => $value,
        'mailerName'=>$mailerName,
        'mailerHost'=>$host,
        'mailerPort'=>$port,
        'mailerAuth'=>$auth,
        'mailerUserName'=>$username,
        'mailerPassword'=>$password,
        'mailerSSL'=>$ssl,
        'mailerFromMail'=>$fromMail,
    
        ));
        return new ViewModel(array('form'=>$form,'data'=>$queryResult,'mode'=>$mode));
    }


    public function addSmtpConfigAction(){
        $appObj = new ApplicationController();
        $poll_encryption_key=POLL_ENCRYPTION_KEY;
        if(isset($_POST)){
            $mailerName = htmlspecialchars(trim($_POST['mailerName']));
            $mailerHost = htmlspecialchars(trim($_POST['mailerHost']));
            $mailerPort = htmlspecialchars(trim($_POST['mailerPort']));
            $mailerAuth = htmlspecialchars(trim($_POST['mailerAuth']));
            $mailerUsername = htmlspecialchars(trim($_POST['mailerUserName']));
            $mailerPassword = htmlspecialchars(trim($_POST['mailerPassword']));
            $mailerSSL = htmlspecialchars(trim($_POST['mailerSSL']));
            $fromMail = htmlspecialchars(trim($_POST['mailerFromMail']));
            $mailerAuth=($mailerAuth==1)?'on':'';
            $mailerSSL=($mailerSSL==1)?'on':'';
           
           if($mailerHost!="" && $mailerPort!=""){
            $queryResult = $appObj->returnQueryData("Select id from tbl_smtp_configuration");
            if($queryResult->count()>0){
           
				$str=$appObj->executeQueries("UPDATE tbl_smtp_configuration  SET mailer_name='$mailerName' ,mailer_host='$mailerHost' ,mailer_port='$mailerPort',mailer_auth='$mailerAuth' ,mailer_username='$mailerUsername' ,mailer_password=AES_ENCRYPT('$mailerPassword','$poll_encryption_key'),mailer_ssl ='$mailerSSL',from_mail_id='$fromMail'");
                echo "update";die();
			}else{
				$str=$appObj->executeQueries("INSERT INTO tbl_smtp_configuration  SET mailer_name='$mailerName' ,mailer_host='$mailerHost' ,mailer_port='$mailerPort',mailer_auth='$mailerAuth' ,mailer_username='$mailerUsername' ,mailer_password=AES_ENCRYPT('$mailerPassword','$poll_encryption_key'),mailer_ssl ='$mailerSSL',from_mail_id='$fromMail'");
                echo "success";die();
			}
        }else{
			echo "empty";die(); 
		 }	
    }else{
	    echo "Bad request";die();	
    }
} 
        /*****
	 *	@Function Name: resetSmtpConfigAction
	 *  @description  : clear smtp table
	 *	@Author		  : Vineet
	 *  @Date         : 29-april-2020
	 *****/
    public function resetSmtpConfigAction(){
        $appObj = new ApplicationController();
        $appObj->returnQueryData("truncate tbl_smtp_configuration");
	    echo "success";die();
    }


        /*****
	 *	@Function Name: sendTestMail
	 *  @description  : send mail to test
	 *	@Author		  : Vineet
	 *  @Date         : 29-april-2020
	 *****/
    public function sendTestMailAction(){
        // $appObj = new ApplicationController();
        // $logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
        // $actionCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>TestMail</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
        // echo $appObj->sendMsgToAPIserverForTestMail($logincmd,$actionCmd);
        
        //Rabbitmq command
        $cmdArr=array("cmd"=>"test_mail","sender"=>"web-vsm");
        $cmdJson=json_encode($cmdArr);
        $producerObject=new WebProducerController();
        $producerObject->sentRabbitCmdWebProducerAction($cmdJson, array('exchange_name'=>'vsmserver','bindingKey'=>'vsmalert'));
        die();
    }

    
}