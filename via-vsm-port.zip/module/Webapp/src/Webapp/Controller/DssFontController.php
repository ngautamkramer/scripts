<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;
use Webapp\Controller\WebProducerController;
use Webapp\TtfInfo\TtfInfo;

class DssFontController extends AbstractActionController {	
	protected $wifiSecurityFilekey = "1324587099345678";	
	protected $logincmd = "<P>
		<UN>websetting</UN>
		<Pwd></Pwd>
		<Cmd>Login</Cmd>
		<P1></P1>
		<P2></P2>
		<P3></P3>
		<P4></P4>
		<P5></P5>
		<P6></P6>
		<P7></P7>
		<P8></P8>
		<P9></P9>
		<P10></P10>
	</P>";
	protected $actionCmd = "<P>
		<UN>websetting</UN>
		<Pwd></Pwd>
		<Cmd>fontCheck</Cmd>
		<P1></P1>
		<P2></P2>
		<P3></P3>
		<P4></P4>
		<P5></P5>
		<P6></P6>
		<P7></P7>
		<P8></P8>
		<P9></P9>
		<P10></P10>
	</P>";	
	public function getDssFontInfoTable() {
		if(!$this->TblDssFontInfoTable) {
			$sm = $this->getServiceLocator();
			$this->TblDssFontInfoTable = $sm->get('Webapp\Model\TblDssFontInfoTable');
		}
		return $this->TblDssFontInfoTable;
	}

	public function getSessionCheckTable() {
		if(!$this->TblSessionCheckTable) {
			$sm = $this->getServiceLocator();
			$this->TblSessionCheckTable = $sm->get('Webapp\Model\TblSessionCheckTable');
		}
		return $this->TblSessionCheckTable;
	}

	public function getSettingTable() {
		if(!$this->TblSettingsTable) {
            $sm = $this->getServiceLocator();
            $this->TblSettingsTable = $sm->get('Webapp\Model\TblSettingsTable');
        }
        return $this->TblSettingsTable;
	}

	public function fontInfoAction() {				
		$dssFontInfoData = $this->getDssFontInfoTable();
		$dssUploadedFonts = $dssFontInfoData->getUploadedDssFonts();
		$viewData = array("dssUploadedFonts" => $dssUploadedFonts);		
		$viewmodel = new ViewModel($viewData);
		return $viewmodel;
	}

	// upload font functionality starts
	function uploadDssFontFileAction() {
		$session = new Container('userinfo');		
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
	
		$flag = 0;
		$fontExistArray = array();
		$supportedFontArray = array('arial', 'arial black', 'calibri',
			'calibri light italic',	'italic', 'bold italic', 'bold', 
			'regular', 'black', 'black italic', 'light', 'light italic', 'normal'
		);
		$counter = 0;		
		$postData = $this->getRequest()->getPost()->toArray();	
		$uploadFontStatus = array();
		$uploadFontStatus["upload"] = array();
		$uploadFontStatus["update"] = array();
		$uploadFontStatus["exists"] = array();
		$uploadFontStatus["invalid"] = array();		
		$uploadFontStatus["total"] = count($_FILES);
		$uploadFontStatus["flag"] = 0;
		$crsf_tokenval=$postData['crsf_tokenval'];
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		if($postData['fileFlag'] == 'newDssFontFile') {
			foreach($_FILES as $fontKey => $fontValue) {	

				/* check for invalid font format */
				$fontFileArr = explode(".", $fontValue['name']);		
				$fontExt = strtolower(end($fontFileArr));
				if($fontExt != 'ttf'){
					$uploadFontStatus["invalid"][] = $fontValue["name"];
					$uploadFontStatus["flag"] = 4;	// font format issue
					break;
				}
				/* check for invalid font format */

				$counter++;
				$flag = '';
				$fontItalic = 0;	
				$fontBoldItalic = 0;
				$fontBold = 0;
				$fontNormal = 0;
				$fontBlack = 0;
				$fontBlackItalic = 0;
				$fontLight = 0;
				$fontLightItalic = 0;
				$fontTypeArr = array();								
				move_uploaded_file($fontValue["tmp_name"], FONT_UPLOAD_PATH.$fontValue["name"]);
				chmod(FONT_UPLOAD_PATH.$fontValue["name"], 0755);
				
				if(file_exists(FONT_UPLOAD_PATH.$fontValue["name"])) {							
					$ttfInfo = new TtfInfo; 
					$ttfInfo->setFontFile(FONT_UPLOAD_PATH.$fontValue["name"]); 
					$uploadedFontInfo = $ttfInfo->getFontInfo();
					if($uploadedFontInfo != '' && in_array(strtolower($uploadedFontInfo[2]), $supportedFontArray)) {
						$uploadedFontName = $uploadedFontInfo[1];
						$uploadedFontType = $uploadedFontInfo[2];					
						$newFontName= $uploadedFontName.'.ttf';						
						// $newFontName = strtolower(str_replace(' ','',$newFontName));			
						rename(FONT_UPLOAD_PATH.$fontValue["name"], FONT_UPLOAD_PATH.$newFontName);
						$checkDuplicate = $this->getDssFontInfoTable()->checkIsFontDuplicate($uploadedFontName);
						if($checkDuplicate->count() > 0) {
							$uploadFontStatus["flag"] = 3;
							//echo json_encode($uploadFontStatus);exit;
							$fontExistArray[] = $uploadedFontName;	
							$uploadFontStatus["exists"][] = $fontValue["name"];
							continue;
						}
						$md5Hash = md5_file(FONT_UPLOAD_PATH.$newFontName);
						$fileSize = filesize(FONT_UPLOAD_PATH.$newFontName);
						if(strtolower($uploadedFontName) == 'arial black') {
							$uploadedFontName = 'Arial';
							$fontBlack = 1;
						} else if(strtolower($uploadedFontName) == 'calibri light') {
							$uploadedFontName = 'Calibri';
							$fontLight = 1;
						} else if(strtolower($uploadedFontName) == 'calibri light italic') {
							$uploadedFontName = 'Calibri';
							$fontLightItalic = 1;
						}

						if(strtolower($uploadedFontType) == 'italic') {
							$updateFontDataPrimary = array("fontitalic" => 1);	
							$fontItalic = 1;
						} else if(strtolower($uploadedFontType) == 'bold italic') {
							$updateFontDataPrimary = array("fontbolditalic" => 1);	
							$fontBoldItalic = 1;
						} else if(strtolower($uploadedFontType) == 'bold') {
							$updateFontDataPrimary = array("fontbold" => 1);	
							$fontBold = 1;
						} else if(strtolower($uploadedFontType) == 'regular' || strtolower($uploadedFontType) == 'normal') {
							$updateFontDataPrimary = array("fontnormal" => 1);	
							$fontNormal = 1;
						} else if(strtolower($uploadedFontType) == 'black') {
							$updateFontDataPrimary = array("fontblack" => 1);
							$fontBlack = 1;
						} else if(strtolower($uploadedFontType) == 'black italic') {
							$updateFontDataPrimary = array("fontblackitalic" => 1);
							$fontBlackItalic = 1;
						} else if(strtolower($uploadedFontType) == 'light') {
							$updateFontDataPrimary = array("fontlight" => 1);
							$fontLight = 1;
						} else if(strtolower($uploadedFontType) == 'light italic') {
							$updateFontDataPrimary = array("fontlightitalic" => 1);	
							$fontLightItalic=1;
						}
						
						$randStringFontId = mt_rand(10000, 9999999) ."". rand(10,999) ."". time();								
						$dssFontMatchResultSet = $this->getDssFontInfoTable()->getDssFontIdByFontName($uploadedFontName);
						if($dssFontMatchResultSet->count() > 0) {
			                foreach($dssFontMatchResultSet as $matchFontInfo) {
			                    $dssFontId =  $matchFontInfo->fontid;
			                }
						}	
						$fontStatus = PRODUCT == 'via' ? 0 : 1;						
						if($dssFontMatchResultSet->count() == 0) {
							$insertData = array(
								"fontname" => $uploadedFontName, "fontitalic" => $fontItalic, 
								"fontbolditalic" => $fontBoldItalic, "fontbold" => $fontBold, 
								"fontnormal" => $fontNormal, "fontblack" => $fontBlack,
								"fontblackitalic" => $fontBlackItalic, "fontlight" => $fontLight, 
								"fontlightitalic" => $fontLightItalic,"fontstatus" => $fontStatus, 
								"fontfilename" => $newFontName, "modifydate" => date("Y-m-d H:i:s"),
								"fontuuid" => $randStringFontId, "fontchecksum" => $md5Hash, "fontsize" => $fileSize
							);
							$this->getDssFontInfoTable()->inserDataForDssFont($insertData);	
							$uploadFontStatus["upload"][] = $fontValue["name"];
							$uploadFontStatus["flag"]= 1;	// uploaded						
						} else {
							if($dssFontId > 12) {

								$updateFontDataSecondary = array("fontstatus" => $fontStatus, "fontuuid" => $randStringFontId, 
									"fontchecksum" => $md5Hash, "fontsize" => $fileSize
								);
								$updateFontDataFull = array_merge($updateFontDataPrimary, $updateFontDataSecondary);
								$updateFontDataWhere = array("fontname" => $uploadedFontName);
								$this->getDssFontInfoTable()->updateDssFonts($updateFontDataFull, $updateFontDataWhere);
								$uploadFontStatus["update"][] = $fontValue["name"];
								$uploadFontStatus["flag"] = 2;	// updated			
							} else {															
								$fontExistArray[] = $uploadedFontName;	
								$uploadFontStatus["exists"][] = $fontValue["name"];							
								$uploadFontStatus["flag"] = 3;	// font already exists			
								unlink(FONT_UPLOAD_PATH.$newFontName);
							}
						}
					}
				} else {
					unlink(FONT_UPLOAD_PATH.$fontValue["name"]);
					$uploadFontStatus["invalid"][] = $fontValue["name"];
					$uploadFontStatus["flag"] = 4;	// font format issue
				}
			}			

			if( count($uploadFontStatus["upload"]) > 0 ) {
				$appObj = new ApplicationController();				
				$appObj->sendMsgToAPIserver($this->logincmd, $this->actionCmd);	
			}
			// if($counter == 1) {
			// 	$uploadFontStatus["flag"] = $flag;
			// }
			echo json_encode($uploadFontStatus);exit;		
		}	
	}
	// upload font functionality ends

	// delete font functionality starts
	public function deleteDssFontAction() {	
		$session = new Container('userinfo');		
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
		
		$fontId = $this->getRequest()->getPost('fontId');
		$crsf_tokenval = $this->getRequest()->getPost('crsf_tokenval');
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
				
		//Security changes added by ashu on 31/03/22. Allow only numeric value 
		if(!is_numeric($fontId) || $fontId <= 0 ){
			echo "Id is not valid";die;
		}		
		
		$dssFontInfoData = $this->getDssFontInfoTable();
		$checkAssociation = $dssFontInfoData->checkFontAssociation($fontId);
		foreach($checkAssociation as $checkAssociationResultSet) {
			$resultSetJson = json_encode($checkAssociationResultSet); 
			$resultSet = json_decode($resultSetJson, true);
		}	
		if(count((array)$resultSet) == 0 ) {
			$updateDeleteFontData = array("fontstatus" => 2);		 
			$updateFontDataWhere = array("fontid" => $fontId);
			$dssFontInfoData->updateDssFontsAndSendMsgToApi($updateDeleteFontData, $updateFontDataWhere, $this->logincmd, $this->actionCmd);
			echo true;	
			die();
		}	
	}	

	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');
		$appObj = new ApplicationController();
		if(empty($user)) {
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		} else {
			if(PRODUCT=='via' || PRODUCT=='kds'){
				$getSettingObj = $appObj->getComplexPasswordSettings();
				$getSettingData = $getSettingObj->webadmin_session_timeout;
			}else{
				$settingTable = $this->getSettingTable();
				$dataSessionSetting = $settingTable->getSessionCheckData();
				foreach($dataSessionSetting as $contentDetailResultSet) {
					$resultSetJson = json_encode($contentDetailResultSet); 
					$resultSet = json_decode($resultSetJson, true);
					$getSettingData = $resultSet['logoutTIme'];
				}
			}
			$sessionTimeOut = ($getSettingData > 0) ? $getSettingData : 10;
			$dataSendSessionCheck = array("sessionTimeOut" => $sessionTimeOut, "sessionLoginName" => $session->offsetGet('LoginName'));
			$sessionCheckTable = $this->getSessionCheckTable();
			$dataSessionCheck = $sessionCheckTable->getSessionCheckData($dataSendSessionCheck);
			
			if(count($dataSessionCheck) > 0) {
				$dataSendUpdateSessionCheck = array("sessionLoginName" => $session->offsetGet('LoginName'));
				$sessionCheckTable->updateSessionCheckData($dataSendUpdateSessionCheck);
			} else {
				return $this->redirect()->toRoute('index', array('action' => 'logout'));
			}
		}
		return parent::onDispatch($e);
	}
}