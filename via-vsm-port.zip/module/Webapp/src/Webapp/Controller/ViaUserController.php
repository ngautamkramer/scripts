<?php

namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\AdduserForm;
use Webapp\Form\ChangePasswordForm;
//for session
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;

use Webapp\Controller\ApplicationController;
use Webapp\Validator\ServicesValidator;

class ViaUserController extends AbstractActionController
{
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userId='".$session->offsetGet('LoginName')."' AND sessionId='".session_id()."' AND extract(epoch FROM NOW())- dateTime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userId='".$session->offsetGet('LoginName')."', sessionId='".session_id()."', dateTime=extract(epoch FROM NOW()) WHERE userId='".$session->offsetGet('LoginName')."' AND sessionId='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{
			//Check for session timeout #added by niraj on 31, janm  2024
			$appObj->checkURLRequestsIfSessionTimeout($_SERVER['REQUEST_URI']);					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}



	public function userListAction(){
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$appObj=new ApplicationController();
		//for edit user
		$mode='';
		$id = $this->params()->fromRoute('id');
		$getUserData="";
		$userPermissionArr="";
		if ($id!='') {
			$mode='editmode';
			$getUserData=$this->getAppuserListTable()->getUserDataById($id);
			 $getUserPermissions=$this->getAppUserGroupsTable()->fetchUserPermissionsById($id);			
			 $userPermissionArr=array();
			 foreach($getUserPermissions as $key=>$val){
			 	$userPermissionArr[]=$val->appgroupid;
			 }
		}
		
		$form = new AdduserForm();
		//load add user form
		$result = $appObj->getComplexPasswordSettings();
		$securitySetting = $result->password_policy;
		$specialCharVal = $securitySetting->special_char;
		$alphanumericVal = $securitySetting->alphanumeric;
		$capitalLtrVal = $securitySetting->one_capital;
		$minCharVal = $securitySetting->password_length;
		$basicModeVal = $securitySetting->basic_mode;
		
		$form->setData(array('specialCharVal' => $specialCharVal, 'alphanumericVal' => $alphanumericVal, 'capitalLtrVal' => $capitalLtrVal, 'minCharVal' => $minCharVal, 'basicModeVal' => $basicModeVal));
		// end add form 
		
		$modelOSType =strtolower($appObj->getModelNameByParam('ostype'));
		$getViaModel=strtolower($appObj->getModelNameByParam('model'));
		$vsmIpArr = $appObj->getTableAllData('DeviceInventory')->current();
		$viaServerIP = $vsmIpArr['deviceip'];
		$vsmIpDssArr = $appObj->getTableAllData('tbl_hq_more_configuration')->current();
		$dssSettingVal=$vsmIpDssArr['featurestatus2'];
		$licened=$appObj->checkLicenseInfo();
		$data=$this->getAppuserListTable()->fetchAllViaUsers();	
		$data->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
		$data->setItemCountPerPage(10);	
		
		//get moderator mode status
		$settingsUrl = DEST_PATH.'via_settings.json';
		$response = file_get_contents($settingsUrl);
		//decrypt json
		$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
		$templateSettings = json_decode($decryptResponse);
		$file_chkPresentationMode=$templateSettings->VIA_CONFIG_TEMPLATE->via_settings->moderator_mode->status;

		return new ViewModel(array(
			'data' => $data,
			'form' => $form,			
			'mode'=>$mode,
			'userPermissionArr'=>$userPermissionArr, 
			'modelOSType'=>$modelOSType,
			'getViaModel'=>$getViaModel,
			'viaServerIP'=>$viaServerIP,
			'dssSettingVal'=>$dssSettingVal,
			'licened'=>$licened,
			'file_chkPresentationMode'=>$file_chkPresentationMode      
			
		));
						
	}
	
	/*****
	 *	@Class Name			: delUsersAction
	 *  @description	    : Using for delete users                     
	 *	@Author			    : Ashu
	 *  @Date               : 17-December-2019
	 *****/ 
	
	 public function delUserAction(){
	 	$appObj=new ApplicationController();
		$session = new Container('userinfo');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
		//echo $userid = $this->params()->fromRoute('id');
		$encryptedUserid =trim($this->params()->fromQuery('id'));
		$crsf_tokenval=trim($this->params()->fromQuery('crsftoken'));
		//decrypt userid
		$input=str_replace(' ','+',trim($encryptedUserid));
		$input=htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
		$userid=$appObj->desDecrypt($input, KEY_SEED);
		
		//Validate CSRF attack
		if($session_crsf_token!=$crsf_tokenval){
			die('Invalid request');
		}		
		
		//Security changes added by ashu on 31/03/22. Allow only numeric value 
		if(!is_numeric($userid) || $userid <= 0 ){
			echo "Id is not valid";die;
		}		
		
		$deldata=$this->getAppuserListTable()->deleteUser($userid);
		$delPermissiondata=$this->getAppUserGroupsTable()->deleteUserPermission($userid);
		$this->flashMessenger()->addMessage('User deleted successfully');
		//manage log			
		$appObj->ActivityLog('Delete',STR_USERMAME.' '.MSG_USER_DELETED);	
			
		return $this->redirect()->toRoute('viauser');
	}
	
	/*****
	 *	@Class Name			: addUserAction
	 *  @description	    : Using for adding users                    
	 *	@Author			    : Ashu
	 *  @Date               : 17-December-2019
	 *****/ 	
	
	public function addUserAction(){
		$appObj=new ApplicationController();
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('LoginName');
		$utype = $session->offsetGet('utype');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
		if($utype == 1){
		    $form = new AdduserForm();		
			if ($this->getRequest()->isPost()) {
				$postData = $this->getRequest()->getPost()->toArray();			
				$username=trim($postData['txtUserId']);
				$password=trim($postData['txtPassword']);
				$conf_password=trim($postData['txtConfirmPassword']);
				$mode=trim($postData['usermode']);
				$crsf_tokenval=trim($postData['crsf_tokenval']);
				//Validate CSRF attack
				if($session_crsf_token!=$crsf_tokenval){
					die('Invalid request');
				}
				
				$getComplexResponse=$this->checkComplexPassRuleAction($password,$mode);	
				if($getComplexResponse !=""){
					echo $getComplexResponse;die;
				}
				
				//print_r($postData);
				if($mode=='editmode'){
					$userid=trim($postData['userid']);
					$userid=str_replace(' ','+',trim($userid));
					$userid=htmlspecialchars($userid, ENT_QUOTES, 'UTF-8');
					$userid = $appObj->desDecrypt($userid, KEY_SEED);
					if(!is_numeric($userid)){
						die('Id is not numeric');
					}
					//die('edit mode');
					if ($password && $userid) {
						$this->getAppuserListTable()->updateUser($userid, $password);
					}
					$this->getAppUserGroupsTable()->deleteUserPermission($userid);
					$this->getAppUserGroupsTable()->saveUserPermission($postData,$userid,$sessionLoginName);
					//manage log			
					$appObj->ActivityLog('Update',STR_USERMAME.' '.MSG_USER_UPDATED);	
					
					die('updatesuccess');
				
				}else{
					$checkuser=$this->checkUserAction($username);	
					if( strlen($username) < 4 && $session->offsetGet('lang')=='eng') {
						die('length_error');
					}else if(preg_match('/[^a-z_.\-0-9]/i', $username) && $session->offsetGet('lang')=='eng'){
						die('format_error');
					}else if(str_contains($username, "'") == true || str_contains($username, '\\') == true){
						// check if username contains ' \ for all languages
						die('format_error');
					}else if($password!=$conf_password){
						die('password_not_match_error');
					}else if($checkuser=='exist'){
						die('exist');
					}else{				
						$lastInsertId= $this->getAppuserListTable()->saveUser($postData,$sessionLoginName);				
						$this->getAppUserGroupsTable()->saveUserPermission($postData,$lastInsertId,$sessionLoginName);
						//manage log			
						$appObj->ActivityLog('Create',STR_USERMAME.' '.MSG_USER_CREATE);	
						die('success');
					}
				
				}
			
			}	
		}
	
	}

	/*****
	 *	@Class Name			: getUserdataAction
	 *  @description	    : Using for getting user data when edit                  
	 *	@Author			    : Ashu
	 *  @Date               : 17-December-2019
	 *****/ 	
	
	//getting user data by id
	public function getUserdataAction(){
		$session = new Container('userinfo');
		$sessionLoginName = $session->offsetGet('LoginName');
		$utype = $session->offsetGet('utype');
		//get crsf value from session
		$session_crsf_token=$session->offsetGet('crsf_token');
		$appObj = new ApplicationController();

		//print_r($_POST);
		if ($this->getRequest()->isPost()) {
			$postData = $this->getRequest()->getPost()->toArray();	
			$id=trim($postData['id']);
			$id=str_replace(' ','+',trim($id));
			$id=htmlspecialchars($id, ENT_QUOTES, 'UTF-8');
			$id = $appObj->desDecrypt($id, KEY_SEED);
			if(!is_numeric($id)){
				die('Id is not numeric');
			}
			$crsf_tokenval=trim($postData['crsf_tokenval']);
			//Validate CSRF attack
			if($session_crsf_token!=$crsf_tokenval){
				die('Invalid request');
			}
			
			//Security changes added by ashu on 28/03/22. Allow only numeric value 
			if(!is_numeric($id) || $id <= 0 ){
				echo "Id is not valid";die;
			}		
			
			$getUserData=$this->getAppuserListTable()->getUserDataById($id);
			 $getUserPermissions=$this->getAppUserGroupsTable()->fetchUserPermissionsById($id);			
			 $userPermissionArr=array();
			 foreach($getUserPermissions as $key=>$val){
			 	$userPermissionArr[]=$val->appgroupid;
			 }
	 		$apploginname=($getUserData->apploginname!='')?$getUserData->apploginname:'';
			$userPermissionsStr=implode(',',$userPermissionArr);
			$role='';
			if(in_array(1,$userPermissionArr)){
				$role.=$apploginname."#"."1";
			}else{
				$role.=$apploginname.'#'.$userPermissionsStr;
			}
			echo $role;
			die;
			
		}
	
	}
	
	/*****
	 *	@Class Name			: checkUserAction
	 *  @description	    : Using for checking exist user          
	 *	@Author			    : Ashu
	 *  @Date               : 17-December-2019
	 *****/ 	
	
	public function checkUserAction($apploginname)
	{		
        $usrdata=$this->getAppuserListTable()->checkUser($apploginname);
        $userCount = $usrdata->count();
	 	return $userCount==0?'notexist':'exist';die;	
            }
            
        public function checkUserAvailabilityAction()
	{		
            $request = $this->getRequest();
            if($request->isXmlHttpRequest()) {
                $apploginname = trim($request->getPost('uname'));
                $usrdata=$this->getAppuserListTable()->checkUser($apploginname);
                $userCount = $usrdata->count();
                $result = $userCount==0?'notexist':'exist';
                echo $result;die;
            }
	}
	

	/*****
	 *	@Class Name			: serverActivityAction
	 *  @description	    : Using for reboot and shutdown         
	 *	@Author			    : Ashu
	 *  @Date               : 17-December-2019
	 *****/ 	 
	public function serverActivityAction(){
		$appObj=new ApplicationController();
		$flag=trim($_POST['flag']);
		$input=($flag=='reboot')?'reboot':'shutdown';
		$res=$appObj->reboot_powerOff_Server($input); 
		if($res==1){
			echo ucfirst($input);//'Reboot';
		}	
		die;
	}

        public function updateSessionAction(){
            $appObj=new ApplicationController();
            $connection = $appObj->getConnection();
            //$connection->execute("SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'");
            $session = new Container('userinfo');
            $loginName = $session->offsetGet('LoginName');
            $sessionId = $session->getManager()->getId();
            if(isset($loginName)){
                $getSettingRow=$appObj->getTableAllData('tbl_session_settings')->current();
                $getSettingData=$getSettingRow['sessionTimeOut'];
                $sessionQry=$connection->execute("SELECT * FROM tbl_session_check WHERE userId='".$loginName."' AND sessionId='".$sessionId."' AND extract(epoch FROM NOW())- dateTime < $getSettingData*60");		
                if($sessionQry->count()>0){
                    $connection->execute("UPDATE tbl_session_check SET userId='".$loginName."', sessionId='".$sessionId."', dateTime=extract(epoch FROM NOW()) WHERE userId='".$loginName."' AND sessionId='".$sessionId."'");
                    die;
                }else{
                    $connection->execute("DELETE FROM tbl_session_check WHERE userId='".$loginName."' AND sessionId='".$sessionId."'");
                    $loginName='';			
                    return $this->redirect()->toRoute('index', array('action' => 'logout'));
                }
            }
        }


	public function getAppuserListTable() {
		if (!$this->TblAppuserListTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblAppuserListTable = $sm->get('Webapp\Model\TblAppuserListTable');
			
		}
		return $this->TblAppuserListTable;
	}
	 
	public function getAppUserGroupsTable() {
		if (!$this->TblAppUserGroupsTable) {	
			$sm = $this->getServiceLocator();		
			$this->TblAppUserGroupsTable = $sm->get('Webapp\Model\TblAppUserGroupsTable');
			
		}
		return $this->TblAppUserGroupsTable;
	}
	
	public function changePasswordAction(){
		$appObj = new ApplicationController();
		$form = new ChangePasswordForm();
		$result = $this->getComplexPasswordTable()->fetchComplexPassword();
		foreach($result as $val) {
			//$specialCharVal = $val->specialchar;
			//$alphanumericVal = $val->alphanumeric;
			//$capitalLtrVal = $val->capitalltr;
			//$minCharVal = $val->minimumchar;
			$checkOldPassVal = $val->checkoldpass;
		}
		$result = $appObj->getComplexPasswordSettings();
		$securitySetting = $result->password_policy;
		$specialCharVal = $securitySetting->special_char;
		$alphanumericVal = $securitySetting->alphanumeric;
		$capitalLtrVal = $securitySetting->one_capital;
		$minCharVal = $securitySetting->password_length;
		$basicModeVal = $securitySetting->basic_mode;
		//$checkOldPassVal = $val->checkoldpass;

		$form->setData(array('specialCharVal' => $specialCharVal, 'alphanumericVal' => $alphanumericVal, 'capitalLtrVal' => $capitalLtrVal, 'minCharVal' => $minCharVal, 'checkOldPassVal' => $checkOldPassVal));

		return new ViewModel(array(
			'form' => $form,
		));
	}
	
	public function changePasswordFileAction(){
	$appObj=new ApplicationController();
	$session = new Container('userinfo');
	$name = $session->offsetGet('LoginName');
	$request = $this->getRequest();
	if($request->isXmlHttpRequest()) {	
		$strusrName =  trim($request->getPost('uname'));
		$oldpasswd  =  trim($request->getPost('oldpasswd'));
		$newpasswd  =  trim($request->getPost('newpasswd'));
		//$userid  =  trim($request->getPost('userid'));
		$txtRemarks="Added By ".$name;
		$hostname = DEFAULT_SERVER_IP;
		
		if($name==$strusrName){
		    $cond = array('apploginname'=>$strusrName,'password'=>$appObj->securePassword($oldpasswd));
		    $qry = $this->getAppuserListTable()->checkUserByNameAndPass($cond);
		    if($qry==0){
			echo"wrong";die;
		    }else{
		    $this->getAppuserListTable()->updateUserByName($strusrName,$newpasswd);
		    $appObj->ActivityLog('Change Password','Change password for '.STR_USERMAME);
		    $session->getManager()->destroy();
		    echo"success";die;
		    }
		}
	}
	die;	
	}
	
	//Check the complex password validation
	public function checkComplexPassRuleAction($password,$mode)
	{
	    $appObj=new ApplicationController();
        $connection = $appObj->getConnection();
		
		$result = $appObj->getComplexPasswordSettings();
		$rowData = (array)$result->password_policy;
		$error = '';
		if($mode !='editmode'){
			if($password == ""){
				$error = "Enter the password"; 
			}
		}
		
		if($password){
			if($rowData['alphanumeric'] == 1 && $rowData['special_char']!=1){ 
				if ( ctype_alnum($password)){
					$error = ''; 
				}else{
					$error = "Enter alphanumeric!"; 
				} 
			}
			if($rowData['special_char'] == 1 ){
				if ( ctype_alnum($password)){
					$error = 'Enter at least one special character!'; 
				}else{
					$error = ''; 
				} 
			}
			if (strlen($password) < $rowData['minimumchar']){
				$error = 'Password should not be less than '.$rowData['minimumchar'];				
			}
		}
		return $error;	
    }

	public function getComplexPasswordTable() {
		if(!$this->TblComplexPasswordTable) {
			$sm = $this->getServiceLocator();
			$this->TblComplexPasswordTable = $sm->get('Webapp\Model\TblComplexPasswordTable');
		}
		return $this->TblComplexPasswordTable;
	}

	/*****
	 *	@Class Name			: serverResetAction
	 *  @description	    : set server reset   
	 *	@Author			    : vineet
	 *  @Date               : 16-09-2020
	 *****/
	public function serverResetAction(){
		$session = new Container('userinfo');
		$loginName = $session->offsetGet('LoginName');
		$hostname = DEFAULT_SERVER_IP;
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$flag = trim($request->getPost('flag'));
			$ip = trim($request->getPost('ip'));
			$port = trim($request->getPost('port'));
			if($flag=='resetnow'){ 
				$input='resetnow';
			}
			$AppObj = new ApplicationController();
			$res=$AppObj->reboot_powerOff_Server($input);
				if($res==1){
					echo 'Reboot';die;
			}else{
				echo 'Error';die;
			}
		}
	}
	 
}
