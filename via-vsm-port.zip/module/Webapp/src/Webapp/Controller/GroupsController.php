<?php
namespace Webapp\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
use Zend\View\Model\ViewModel;
use Webapp\Form\GroupsForm;
use Zend\Validator\File\Size;
use Zend\Validator\File\Extension;
use Zend\Validator\File\Rename;
use Zend\File\Transfer\Adapter\Http;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\WebProducerController;

class GroupsController extends AbstractActionController
{
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$tblSessionTimeOutDataArr=$appObj->returnQueryData("SELECT logoutTime FROM settings ORDER BY id DESC LIMIT 1");
		foreach($tblSessionTimeOutDataArr as $sessiondata){
			$getSettingData=$sessiondata['logoutTime'];
		}
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if($tblSessionCheckdataArr->count()>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session['LoginName']."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session['LoginName']."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}
        
    public function groupListAction(){
		if(PRODUCT=='kds'){
			die('Access denied.');
		}
		$session = new Container('userinfo');
		$user_id = $session->offsetGet('usrid');
		$form = new GroupsForm();
		$request = $this->getRequest();
		$appObj = new ApplicationController();
		if($request->isPost()){
			$group = htmlspecialchars(trim($request->getPost('grpSearchBox')));
			$form->setData($request->getPost());
			//if($form->isValid()){}
			//$dataPost = $form->getData();
			//$group = trim($dataPost['grpSearchBox']);
		}
		//$qry1=$appObj->returnQueryData("SELECT * FROM devicegroup");
		$result = $this->getDevicegroupTable()->fetchAll();
		
		$arrayCategories = array();
		foreach($result as $row){
			$arrayCategories[$row->DeviceGroupID] = array("grp_id" => $row->DeviceGroupID, "parent_id" => $row->DeviceMasterID, "name" =>$row->DeviceGroup, "level" =>$appObj->getDepth($row->DeviceGroupID));   
		}
		$user_grp_arr=array();
		if($user_id !=1){
			$deviceGroup = $this->getDevicegroupTable()->getGroupWithPermission($user_id);
		}
		$result = $this->getDevicegroupTable()->fetchGroupList($user_id, $group);
		$grpArr = array('DeviceGroupID'=>$val);
		$mysql_grp = $this->getDevicegroupTable()->getGroup($grpArr);
		//$form->setData(array('search' => $search));
		$result['data']->setCurrentPageNumber((int) $this->params()->fromQuery('page', 1));
        $result['data']->setItemCountPerPage(50);
		return new ViewModel(array(
			'groupList' => $result['data'],
			'form' => $form,
			'count'=>$result['count'],
			'arrayCategories'=>$arrayCategories,
			'deviceGroup'=>$deviceGroup,
		));
	}
	
	public function getGroupDataAction(){
		$request = $this->getRequest();
		if($request->isPost()){
			$groupId = trim($request->getPost('grpId'));
			$grpArr = array('DeviceGroupID'=>$groupId);
			$grpData = $this->getDevicegroupTable()->getGroup($grpArr)->current();
			echo json_encode($grpData);die;
		}
	}
	
	public function addEditGroupAction(){
		$request = $this->getRequest();
		if($request->isXmlHttpRequest()) {
			$appObj = new ApplicationController();
			$session = new Container('userinfo');
            $user_id = $session->offsetGet('usrid');
			$name = $session->offsetGet('LoginName');	
			$grpName = htmlspecialchars(trim($request->getPost('grpName')));
			$grpRemarks = htmlspecialchars(trim($request->getPost('grpRemarks')));
			$flag = trim($request->getPost('flag'));
			$hostname=$_SERVER['REMOTE_ADDR'];
			$parentGrp = trim($request->getPost('parentGrp'));
			$grpID = trim($request->getPost('grpID'));
			if($grpName=='none' || $grpName=='None' || $grpName=='NONE' ){
				 echo "NotNone";die;
			}else{
				$depth=$appObj->getDepth($parentGrp);   // get the depth of parent group 
				if($flag=='add'){	
					if($depth <= 4){
						$grpNameArr = array('DeviceGroup' => $grpName);
						$recount = $this->getDevicegroupTable()->getGroup($grpNameArr)->count();
						if($recount==0){
							$grpNameArr = array('DeviceMasterID'=>$parentGrp,'DeviceGroup'=>$grpName,'Comments'=>$grpRemarks);
							$lastpicid = $this->getDevicegroupTable()->insertGroup($grpNameArr);	
							$appObj->ActivityLogVSM(3,STR_GROUP.' '.$grpName.' '.MSG_USER_CREATE,2);
							//Inherit the parent group properties (2-APR-2018)
							// 1- insert the data into gateway_customize_homepage_mapping 
							if($parentGrp !=0){
								$where = array('isGrpIdOrDeviceId'=>$parentGrp,'entryType'=>0);
								//Added the conditions for get the user permission of parent group(Added 22-Aug-2018)
								$getUsersResponse = $appObj->returnQueryData("SELECT DISTINCT user_id_fk FROM tbl_user_access WHERE group_id_fk=$parentGrp AND user_id_fk !=1");
								if($getUsersResponse->count() > 0 ){
									$getMenusResponse = $appObj->returnQueryData("SELECT DISTINCT menu_id_fk,module_id_fk FROM tbl_user_access WHERE group_id_fk=$parentGrp AND user_id_fk !=1");
									$sql_query="INSERT INTO tbl_user_access(module_id_fk,menu_id_fk,access_id_fk,user_id_fk,group_id_fk)values ";
									$value_array=array();
									$resDataFinal=array();
									foreach($getMenusResponse as $fetchMenu){
										$resData['module_id_fk'] = $fetchMenu['module_id_fk'];
										$resData['menu_id_fk'] = $fetchMenu['menu_id_fk'];
										$resDataFinal[] = $resData;
									}	
									foreach($getUsersResponse as $fetch){
										$usrId=$fetch['user_id_fk'];
										foreach($resDataFinal as $resVal){
											$module_id=$resVal['module_id_fk'];
											$menu_id=$resVal['menu_id_fk'];
											$value_array[] = "('$module_id', '$menu_id', 0, '$usrId', '$lastpicid')";	
										}
									} 
									$sql_query .= implode(',', $value_array);
									$appObj->executeQueries($sql_query);
								}
								
								$checkIsExist = $this->getGatewayCustomizeHomepageMappingTable()->getData($where);
								if($checkIsExist->count() > 0){ 
									$sql_query="INSERT INTO gateway_customize_homepage_mapping(FrameID,ScreenTemplateID,FrameName,FrameHeight,FrameWidth,FrameLeft,FrameTop,AspectRatio,UserName,hostname,isGrpIdOrDeviceId,entryType,os_type)values ";
									$value_array=array();
									foreach($checkIsExist as $homePageData){
										  $FrameID = $homePageData['FrameID'];
										  $ScreenTemplateID = $homePageData['ScreenTemplateID'];
										  $FrameName = $homePageData['FrameName'];
										  $FrameHeight = $homePageData['FrameHeight'];
										  $FrameWidth = $homePageData['FrameWidth'];
										  $FrameLeft = $homePageData['FrameLeft'];
										  $FrameTop = $homePageData['FrameTop'];
										  $AspectRatio = $homePageData['AspectRatio'];
										  $UserName = $homePageData['UserName'];
										  $hostname = $homePageData['hostname'];
										  $isGrpIdOrDeviceId = $lastpicid;
										  $entryType = $homePageData['entryType'];
										  $os_type = $homePageData['os_type'];
										  $value_array[] = "('$FrameID', '$ScreenTemplateID', '$FrameName', '$FrameHeight', '$FrameWidth','$FrameLeft','$FrameTop','$AspectRatio','$UserName','$hostname','$isGrpIdOrDeviceId','$entryType','$os_type')";  
									}
									$sql_query .= implode(',', $value_array);
									$appObj->executeQueries($sql_query);
								} 
								// 2- insert the data into tbl_adsettings_mapping 
								$checkAdSettingExist=$appObj->returnQueryData("SELECT * from tbl_adsettings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($checkAdSettingExist->count() > 0){
									$sql_query2="INSERT INTO tbl_adsettings_mapping(activate_presentation_mode,authentication_mode,active_dir_domain,is_GroupOu_based,moderator,participant,os_type,isGrpIdOrDeviceId,entryType)values ";
									$value_array2=array();
									foreach($checkAdSettingExist as $adSettingData){
										$activate_presentation_mode = $adSettingData['activate_presentation_mode'];
										$authentication_mode = $adSettingData['authentication_mode'];
										$active_dir_domain = $adSettingData['active_dir_domain'];
										$is_GroupOu_based = $adSettingData['is_GroupOu_based'];
										$moderator = $adSettingData['moderator'];
										$participant = $adSettingData['participant'];
										$isGrpIdOrDeviceId = $lastpicid;
										$entryType = $adSettingData['entryType'];
										$os_type = $adSettingData['os_type'];
										$value_array2[] = "('$activate_presentation_mode', '$authentication_mode', '$active_dir_domain', '$is_GroupOu_based', '$moderator','$participant','$os_type','$isGrpIdOrDeviceId','$entryType')";  
									}
									$sql_query2 .= implode(',', $value_array2);
									$appObj->executeQueries($sql_query2);
								}
								// 3- insert the data into tbl_advance_configuration_mapping 
								$advaceSettingExist = $this->getAdvanceConfigurationMappingTable()->getData($where);
								if($advaceSettingExist->count() > 0){
									$sql_query3="INSERT INTO tbl_advance_configuration_mapping(feature1,feature2,feature3,feature4,feature5,feature6,feature7,feature8,feature9,feature10,last_updated,isGrpIdOrDeviceId,entryType,field1,field2,os_type,timezone_name)values ";
									$value_array3=array();
									foreach($advaceSettingExist as $advaceSettingData){
										$feature1 = $advaceSettingData['feature1'];
										$feature2 = $advaceSettingData['feature2'];
										$feature3 = $advaceSettingData['feature3'];
										$feature4 = $advaceSettingData['feature4'];
										$feature5 = $advaceSettingData['feature5'];
										$feature6 = $advaceSettingData['feature6'];
										$feature7 = $advaceSettingData['feature7'];
										$feature8 = $advaceSettingData['feature8'];
										$feature9 = $advaceSettingData['feature9'];
										$feature10 = $advaceSettingData['feature10'];
										$last_updated=$advaceSettingData['last_updated'];
										if($advaceSettingData['field1'] == ""){
											$field1 = 0;
										}else{
											$field1 = $advaceSettingData['field1'];
										}
										$field2 = $advaceSettingData['field2'];
										$timezone_name = $advaceSettingData['timezone_name'];
										$isGrpIdOrDeviceId = $lastpicid;
										$entryType = $advaceSettingData['entryType'];
										$os_type = $advaceSettingData['os_type'];
										$value_array3[] = "('$feature1', '$feature2', '$feature3', '$feature4','$feature5','$feature6','$feature7','$feature8','$feature9','$feature10','$last_updated','$isGrpIdOrDeviceId','$entryType','$field1','$field2','$os_type','$timezone_name')";  
									}
									$sql_query3 .= implode(',', $value_array3);
									$appObj->executeQueries($sql_query3);
								}
								// 4- insert the data into tbl_Auth_FileFormat_mapping 
								$authFileExist = $appObj->returnQueryData("SELECT * from tbl_Auth_FileFormat_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($authFileExist->count() > 0){
									$sql_query4="INSERT INTO tbl_Auth_FileFormat_mapping(FileFormat,isGrpIdOrDeviceId,entryType,os_type,field1,field2)values ";
									$value_array4=array();
									foreach($authFileExist as $authFileData){
										$FileFormat=$authFileData['FileFormat'];
										$field1=$authFileData['field1'];
										if($authFileData['field2']==""){
											$field2=0;  
										}else{
										   $field2=$authFileData['field2'];
										}
										$isGrpIdOrDeviceId=$lastpicid;
										$entryType=$authFileData['entryType'];
										$os_type=$authFileData['os_type'];
										$value_array4[] = "('$FileFormat', '$isGrpIdOrDeviceId', '$entryType', '$os_type', '$field1','$field2')";  
									}
									$sql_query4 .= implode(',', $value_array4);
									$appObj->executeQueries($sql_query4);
								}
								// 5- insert the data into tbl_clients_features_mapping 
								$clientFeatureExist=$appObj->returnQueryData("SELECT * from tbl_clients_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($clientFeatureExist->count() > 0){
									$sql_query5="INSERT INTO tbl_clients_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
									$value_array5=array();
									foreach($clientFeatureExist as $clientFeatureData){
										  $feature_hash=$clientFeatureData['feature_hash'];
										  if($clientFeatureData['field1'] == ""){
											  $field1=0;
										  }else{
											  $field1 = $clientFeatureData['field1'];  
										  }
										  $field2 = $clientFeatureData['field2'];
										  $isGrpIdOrDeviceId = $lastpicid;
										  $entryType = $clientFeatureData['entryType'];
										  $os_type = $clientFeatureData['os_type'];
										  $value_array5[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
									}
									$sql_query5 .= implode(',', $value_array5);
									$appObj->executeQueries($sql_query5);
								}
							
								// 6- insert the data into tbl_configuration_mapping 
								$configurationExist=$appObj->returnQueryData("SELECT * from tbl_configuration_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($configurationExist->count() > 0){
									$sql_query6="INSERT INTO tbl_configuration_mapping(activate_RoomName,show_RoomName_Color,activate_RoomCode,show_RoomCode_Color,activate_ShowOnWallpaper,activate_RefreshTime,activate_DateTime,show_DateTime_Wallp_Color,activate_RoomName_SecondDisplay,activate_PowerOffTiming,show_PowerOffTiming, 	hdmi_input_not_start,activatePIPMode,activateSystemLog,activateMediaMode,activateQuickClientAccess,activateEnergySaver,language,mirrorMaxCon,mirrorName,activateDND,activateChat,activateDynamicLayout,24HoursFormat,setDisplayLayout,tpshortcut,disableontop,os_type,qrcode,qrbypass,qrtop, 	isGrpIdOrDeviceId,entryType,activate_autoRebootTiming,show_autoRebootTiming)values ";
									$value_array6=array();
									foreach($configurationExist as $configurationData){
										  $activate_RoomName = $configurationData['activate_RoomName'];
										  $show_RoomName_Color = $configurationData['show_RoomName_Color'];
										  $activate_RoomCode = $configurationData['activate_RoomCode'];
										  $show_RoomCode_Color = $configurationData['show_RoomCode_Color'];
										  $activate_ShowOnWallpaper = $configurationData['activate_ShowOnWallpaper'];
										  $activate_RefreshTime = $configurationData['activate_RefreshTime'];
										  $activate_DateTime = $configurationData['activate_DateTime'];
										  $show_DateTime_Wallp_Color = $configurationData['show_DateTime_Wallp_Color'];
										  $activate_RoomName_SecondDisplay = $configurationData['activate_RoomName_SecondDisplay'];
										  $activate_PowerOffTiming = $configurationData['activate_PowerOffTiming'];
										  $show_PowerOffTiming = $configurationData['show_PowerOffTiming'];
										  $hdmi_input_not_start = $configurationData['hdmi_input_not_start'];
										  $activatePIPMode = $configurationData['activatePIPMode'];
										  $activateSystemLog = $configurationData['activateSystemLog'];
										  $activateMediaMode = $configurationData['activateMediaMode'];
										  $activateQuickClientAccess = $configurationData['activateQuickClientAccess'];
										  $activateEnergySaver = $configurationData['activateEnergySaver'];
										  $language = $configurationData['language'];
										  $mirrorMaxCon = $configurationData['mirrorMaxCon'];
										  $mirrorName = $configurationData['mirrorName'];
										  $activateDND = $configurationData['activateDND'];
										  $activateChat = $configurationData['activateChat'];
										  $activateDynamicLayout = $configurationData['activateDynamicLayout'];
										  $HoursFormat = $configurationData['24HoursFormat'];
										  $setDisplayLayout = $configurationData['setDisplayLayout'];
										  $tpshortcut = $configurationData['tpshortcut'];
										  $disableontop = $configurationData['disableontop'];
										  $os_type = $configurationData['os_type'];
										  $qrcode = $configurationData['qrcode'];
										  $qrbypass = $configurationData['qrbypass'];
										  $qrtop = $configurationData['qrtop'];
										  $entryType = $configurationData['entryType'];
										  $activate_autoRebootTiming = $configurationData['activate_autoRebootTiming'];
										  $show_autoRebootTiming = $configurationData['show_autoRebootTiming'];
										  $isGrpIdOrDeviceId = $lastpicid;
										  $value_array6[] = "('$activate_RoomName', '$show_RoomName_Color', '$activate_RoomCode', '$show_RoomCode_Color', '$activate_ShowOnWallpaper','$activate_RefreshTime','$activate_DateTime','$show_DateTime_Wallp_Color','$activate_RoomName_SecondDisplay','$activate_PowerOffTiming','$show_PowerOffTiming','$hdmi_input_not_start','$activatePIPMode','$activateSystemLog','$activateMediaMode','$activateQuickClientAccess','$activateEnergySaver','$language','$mirrorMaxCon','$mirrorName','$activateDND','$activateChat','$activateDynamicLayout','$HoursFormat','$setDisplayLayout','$tpshortcut','$disableontop','$os_type','$qrcode','$qrbypass','$qrtop','$isGrpIdOrDeviceId','$entryType','$activate_autoRebootTiming','$show_autoRebootTiming')";  
									}
									$sql_query6 .= implode(',', $value_array6);
									$appObj->executeQueries($sql_query6);
								}
								// 7- insert the data into tbl_display_settings_mapping 
								$displaySettingExist=$appObj->returnQueryData("SELECT * from tbl_display_settings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($displaySettingExist->count() > 0){
									$sql_query7="INSERT INTO tbl_display_settings_mapping(activate_RoomName,show_RoomName_Color,activate_RoomCode,show_RoomCode_Color,activate_ShowOnWallpaper,activate_RefreshTime,activate_DateTime,show_DateTime_Wallp_Color,activate_RoomName_SecondDisplay,24HoursFormat,mirrorMaxCon,mirrorName,activateDynamicLayout,qrcode,qrbypass,qrtop,activateRoomOverlay,RoomOverlayValue,os_type,isGrpIdOrDeviceId,entryType,field1,field2,field3,field4,field5,field6,field7,field8,field9)values ";
									$value_array7=array();
									foreach($displaySettingExist as $displaySettingData){
										  $activate_RoomName = $displaySettingData['activate_RoomName'];
										  $show_RoomName_Color = $displaySettingData['show_RoomName_Color'];
										  $activate_RoomCode = $displaySettingData['activate_RoomCode'];
										  $show_RoomCode_Color = $displaySettingData['show_RoomCode_Color'];
										  $activate_ShowOnWallpaper = $displaySettingData['activate_ShowOnWallpaper'];
										  $activate_RefreshTime = $displaySettingData['activate_RefreshTime'];
										  $activate_DateTime = $displaySettingData['activate_DateTime'];
										  $show_DateTime_Wallp_Color = $displaySettingData['show_DateTime_Wallp_Color'];
										  $activate_RoomName_SecondDisplay = $displaySettingData['activate_RoomName_SecondDisplay'];
										  $HoursFormat = $displaySettingData['24HoursFormat'];
										  $mirrorMaxCon = $displaySettingData['mirrorMaxCon'];
										  $mirrorName = $displaySettingData['mirrorName'];
										  $activateDynamicLayout = $displaySettingData['activateDynamicLayout'];
										  $qrcode = $displaySettingData['qrcode'];
										  $qrbypass = $displaySettingData['qrbypass'];
										  $qrtop = $displaySettingData['qrtop'];
										  $activateRoomOverlay = $displaySettingData['activateRoomOverlay'];
										  $RoomOverlayValue = $displaySettingData['RoomOverlayValue'];
										  $os_type = $displaySettingData['os_type'];
										  $entryType = $displaySettingData['entryType'];
										  $field1 = $displaySettingData['field1'];
										  $field2 = $displaySettingData['field2'];
										  $field3 = $displaySettingData['field3'];
										  $field4 = $displaySettingData['field4'];
										  $field5 = $displaySettingData['field5'];
										  if($displaySettingData['field6']==""){
											  $field6=0;
										  }else{
											  $field6=$displaySettingData['field6'];
										  }
										  if($displaySettingData['field7']==""){
											  $field7=0;
										  }else{
											  $field7=$displaySettingData['field7'];
										  }
										  if($displaySettingData['field8']==""){
											  $field8=0;
										  }else{
											  $field8=$displaySettingData['field8'];
										  }
										  if($displaySettingData['field9']==""){
											   $field9=0;
										  }else{
											   $field9=$displaySettingData['field9'];
										  }
										  $isGrpIdOrDeviceId=$lastpicid;
										  $value_array7[] = "('$activate_RoomName', '$show_RoomName_Color', '$activate_RoomCode', '$show_RoomCode_Color', '$activate_ShowOnWallpaper','$activate_RefreshTime','$activate_DateTime','$show_DateTime_Wallp_Color','$activate_RoomName_SecondDisplay','$HoursFormat','$mirrorMaxCon','$mirrorName','$activateDynamicLayout','$qrcode','$qrbypass','$qrtop','$activateRoomOverlay','$RoomOverlayValue','$os_type','$isGrpIdOrDeviceId','$entryType','$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9')";  
									}
									$sql_query7 .= implode(',', $value_array7);
									$appObj->executeQueries($sql_query7);
								}
							
								// 8- insert the data into tbl_gateway_features_mapping 
								$gatewayFeatureExist=$appObj->returnQueryData("SELECT * from tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($gatewayFeatureExist->count() > 0){
									$sql_query8="INSERT INTO tbl_gateway_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
									$value_array8=array();
									foreach($gatewayFeatureExist as $gatewayFeatureData){
										  $feature_hash=$gatewayFeatureData['feature_hash'];
										  if($gatewayFeatureData['field1']==""){
											  $field1=0;
										  }else{
											  $field1=$gatewayFeatureData['field1'];  
										  }
										  $field2=$gatewayFeatureData['field2'];
										  $isGrpIdOrDeviceId=$lastpicid;
										  $entryType=$gatewayFeatureData['entryType'];
										  $os_type=$gatewayFeatureData['os_type'];
										  $value_array8[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
									}
									$sql_query8 .= implode(',', $value_array8);
									$appObj->executeQueries($sql_query8);
								}
							
								// 9- insert the data into tbl_mobile_features_mapping 
								$mobileFeatureExist=$appObj->returnQueryData("SELECT * from tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($mobileFeatureExist->count() > 0){
									$sql_query9="INSERT INTO tbl_mobile_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
									$value_array9=array();
									foreach($mobileFeatureExist as $mobileFeatureData){
										  $feature_hash=$mobileFeatureData['feature_hash'];
										  if($mobileFeatureData['field1']==""){
											   $field1=0;
										  }else{
											   $field1=$mobileFeatureData['field1'];
										  }
										  $field2=$mobileFeatureData['field2'];
										  $isGrpIdOrDeviceId=$lastpicid;
										  $entryType=$mobileFeatureData['entryType'];
										  $os_type=$mobileFeatureData['os_type'];
										  $value_array9[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
									}
									$sql_query9 .= implode(',', $value_array9);
									$appObj->executeQueries($sql_query9);
								}
								
								// 10- insert the data into tbl_recording_transfer_mapping 
								$recordingTransferExist=$appObj->returnQueryData("SELECT * from tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($recordingTransferExist->count() > 0){
									$sql_query10="INSERT INTO tbl_recording_transfer_mapping(transfer_option,isGrpIdOrDeviceId,entryType,os_type,field1,field2,field3)values ";
									$value_array10=array();
									foreach($recordingTransferExist as $recordingTransferData){
										  $transfer_option=$recordingTransferData['transfer_option'];
										  $entryType=$recordingTransferData['entryType'];
										  $os_type=$recordingTransferData['os_type'];
										  if($recordingTransferData['field1']==""){
											  $field1=0;
										  }else{
											  $field1=$recordingTransferData['field1'];  
										  }
										  $field2=$recordingTransferData['field2'];
										  $field3=$recordingTransferData['field3'];
										  $isGrpIdOrDeviceId=$lastpicid;
										  
										  $value_array10[] = "('$transfer_option','$isGrpIdOrDeviceId','$entryType', '$os_type', '$field1', '$field2','$field3')";  
									}
									$sql_query10 .= implode(',', $value_array10);
									$appObj->executeQueries($sql_query10);
								}
							
								// 11- insert the data into tbl_streaming_settings_mapping 
								$streamingExist=$appObj->returnQueryData("SELECT * from tbl_streaming_settings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($streamingExist->count() > 0){
									$sql_query11="INSERT INTO tbl_streaming_settings_mapping(status,display_url_1,display_url_2,entryType,isGrpIdOrDeviceId,os_type,reserve1,reserve2,reserve3,reserve4)values ";
									$value_array11=array();
									foreach($streamingExist as $streamingData){
										  $status=$streamingData['status'];
										  $display_url_1=$streamingData['display_url_1'];
										  $display_url_2=$streamingData['stadisplay_url_2tus'];
										  $entryType=$streamingData['entryType'];
										  $os_type=$streamingData['os_type'];
										  if($streamingData['reserve1']==""){
											   $reserve1=0;
										  }else{
											   $reserve1=$streamingData['reserve1'];
										  }
										  if($streamingData['reserve2']==""){
												 $reserve2=0;
										  }else{
												$reserve2=$streamingData['reserve2'];  
										  }
										  $reserve3=$streamingData['reserve3'];
										  $reserve4=$streamingData['reserve4'];
										  $isGrpIdOrDeviceId=$lastpicid; 
										  $value_array11[] = "('$status','$display_url_1','$display_url_2', '$entryType', '$isGrpIdOrDeviceId', '$os_type','$reserve1','$reserve2','$reserve3','$reserve4')";  
									}
									$sql_query11 .= implode(',', $value_array11);
									$appObj->executeQueries($sql_query11);
								}
								// 12- insert the data into tbl_wallpaper_mapping 
								$wallpaperExist=$appObj->returnQueryData("SELECT * from tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($wallpaperExist->count() > 0){
									$sql_query12="INSERT INTO tbl_wallpaper_mapping(wallp_name,wallp_created_by,wallp_is_active,isGrpIdOrDeviceId,entryType,field1,field2)values ";
									$value_array12=array();
									foreach($wallpaperExist as $wallpaperData){
										  $wallp_name=$wallpaperData['wallp_name'];
										  $wallp_created_by=$wallpaperData['wallp_created_by'];
										  $wallp_is_active=$wallpaperData['wallp_is_active'];
										  $entryType=$wallpaperData['entryType'];
										  $field1=$wallpaperData['field1'];
										  $field2=$wallpaperData['field2'];
										  $isGrpIdOrDeviceId=$lastpicid; 
										  $value_array12[] = "('$wallp_name','$wallp_created_by','$wallp_is_active', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
									}
									$sql_query12 .= implode(',', $value_array12);
									$appObj->executeQueries($sql_query12);
								} 
								//13- insert the data into tbl_datetime_format_mapping (Added 23-Aug-2018)
								$datetimeFormat=$appObj->returnQueryData("SELECT * from tbl_datetime_format_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($datetimeFormat->count() > 0){
									$sql_query13="INSERT INTO tbl_datetime_format_mapping(date_format,time_format,show_am_pm,os_type,isGrpIdOrDeviceId,entryType)values ";
									$value_array13=array();
									foreach($datetimeFormat as $datetimeFormatData){
										$date_format=$datetimeFormatData['date_format'];
										$time_format=$datetimeFormatData['time_format'];
										$show_am_pm=$datetimeFormatData['show_am_pm'];
										$isGrpIdOrDeviceId=$lastpicid;
										$entryType=$datetimeFormatData['entryType'];
										$os_type=$datetimeFormatData['os_type'];
										$value_array13[] = "('$date_format', '$time_format', '$show_am_pm', '$isGrpIdOrDeviceId', '$entryType','$os_type')";  
									}
									$sql_query13 .= implode(',', $value_array13);
									$appObj->executeQueries($sql_query13);
								}
									
								//14- insert the data into tbl_advance_more_features_mapping(Added 23-Aug-2018)
								$advanceMoreFeature=$appObj->returnQueryData("SELECT * from tbl_advance_more_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($advanceMoreFeature->count() > 0){
									$sql_query14="INSERT INTO tbl_advance_more_features_mapping(property_name,ivalue,strvalue,modifydatetime,entryType,isGrpIdOrDeviceId,os_type)values ";
									$value_array14=array();
									foreach($advanceMoreFeature as $advanceMoreFeatureData){
										  $property_name=$advanceMoreFeatureData['property_name'];
										  $ivalue=$advanceMoreFeatureData['ivalue'];
										  $strvalue=$advanceMoreFeatureData['strvalue'];
										  $modifydatetime=$advanceMoreFeatureData['modifydatetime'];
										  $isGrpIdOrDeviceId=$lastpicid;
										  $entryType=$advanceMoreFeatureData['entryType'];
										  $os_type=$advanceMoreFeatureData['os_type'];
										  $value_array14[] = "('$property_name', '$ivalue', '$strvalue', '$modifydatetime', '$isGrpIdOrDeviceId','$entryType','$os_type')";  
									}
									$sql_query14 .= implode(',', $value_array14);
									$appObj->executeQueries($sql_query14);
								}
									
								//15- Insert for template designer(11-Oct-2019)
								$templateSetting=$appObj->returnQueryData("SELECT * from tbl_templates_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($templateSetting->count() > 0){
									$sql_query15="INSERT INTO tbl_templates_mapping(template_id,wallpaper_name,isGrpIdOrDeviceId,entryType,model_type)values ";
									$value_array15=array();
									foreach($templateSetting as $templateSettingData){
										  $template_id=$templateSettingData['template_id'];
										  $wallpaper_name=$templateSettingData['wallpaper_name'];
										  $isGrpIdOrDeviceId=$lastpicid;
										  $entryType=$templateSettingData['entryType'];
										  $value_array15[] = "('$template_id', '$wallpaper_name','$isGrpIdOrDeviceId','$entryType',0)";  
									}
									$sql_query15 .= implode(',', $value_array15);
									$appObj->executeQueries($sql_query15);
								}else{
									$appObj->executeQueries("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$lastpicid,0,0)");
								}
								//16- Insert for viasetting template (04 July 2020)
								$viatemplateSetting=$appObj->returnQueryData("SELECT * from tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
								if($viatemplateSetting->count() > 0){
									$sql_query16="INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values ";
									$value_array16=array();
									foreach($viatemplateSetting as $viatemplateSettingData){
										  $template_id=$viatemplateSettingData['template_id'];
										  $isGrpIdOrDeviceId=$lastpicid;
										  $entryType=$viatemplateSettingData['entryType'];
										  $value_array16[] = "('$template_id', '$isGrpIdOrDeviceId','$entryType',0)";  
									}
									$sql_query16 .= implode(',', $value_array16);
									$appObj->executeQueries($sql_query16);
								}else{
									$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type,modifydatetime)values (1,$lastpicid,0,0,'".date('Y-m-d H:i:s')."')");
								}
							}else{
								$appObj->executeQueries("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$lastpicid,0,0)");
								$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type,modifydatetime)values (1,$lastpicid,0,0,'".date('Y-m-d H:i:s')."')");
							}
							echo "success";die;
						}else{
							echo"Exists";die;
						}
					}else{
						echo "NotAllowed";die;
					}
				}
				if($flag=='edit'){
					if($depth <= 4){// check the parent group depth(level)
						$res2  = $appObj->returnQueryData("SELECT DISTINCT(GetChildTree($grpID)) as child FROM devicegroup");
						if($res2->count() > 0){
							foreach($res2 as $data){
								$childArray[]=$data; 
							}
						}
						$cArray=$childArray[0]['child'];
						$newArr=explode(',',$cArray);
						array_push($newArr,$grpID);
						if(in_array($parentGrp,$newArr)){
							echo "NotMoveInChild";die;
						}else{
							// get the current group name.
							$grpArr = array('DeviceGroupID'=>$grpID);
							$qryResult = $this->getDevicegroupTable()->getGroup($grpArr)->current();
							$oldName = $qryResult->DeviceGroup;
							// get the group count based on group name.
							//$existGroupName = $appObj->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroup='".$grpName."'");	
							$grpArr = array('DeviceGroup'=>$grpName);
							$existGroupName = $this->getDevicegroupTable()->getGroup($grpArr);
							$existsCountRows = $existGroupName->count();
							// check the current group name and existing group count.
							if($existsCountRows == 0 || $oldName == $grpName){
								$grpArr = array('DeviceGroup'=>$grpName,'DeviceMasterID'=>$parentGrp);
								//$selQry = "SELECT * FROM devicegroup WHERE DeviceGroup='".$grpName."' AND DeviceMasterID=$parentGrp";
								$qryResult = $this->getDevicegroupTable()->getGroup($grpArr);
								$recount=$qryResult->count();
								if($recount==0){
									$str3=$appObj->executeQueries("UPDATE devicegroup SET DeviceGroup='$grpName',Comments='$grpRemarks',DeviceMasterID=$parentGrp WHERE DeviceGroupID=$grpID");
									//$lastpicid=mysql_insert_id();
									//Inherit the parent group properties (2-APR-2018)
									// 1- insert the data into gateway_customize_homepage_mapping 
									if($parentGrp !=0){
									   //Delete the existing data
										$where = array('isGrpIdOrDeviceId'=>$parentGrp,'entryType'=>0);
										$this->getGatewayCustomizeHomepageMappingTable()->deleteData($where);
										$this->getAdvanceConfigurationMappingTable()->deleteData($where);
										$appObj->executeQueries("DELETE FROM tbl_adsettings_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_Auth_FileFormat_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_clients_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_configuration_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_display_settings_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_streaming_settings_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_advance_more_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_datetime_format_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										$appObj->executeQueries("DELETE FROM tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
									
										//Delete the existing entry
										$appObj->executeQueries("DELETE FROM tbl_user_access WHERE group_id_fk=$grpID");
										//Added the conditions for get the user permission of parent group(Added 22-Aug-2018)
										$getUsersResponse=$appObj->returnQueryData("SELECT DISTINCT user_id_fk FROM tbl_user_access WHERE group_id_fk=$parentGrp AND user_id_fk !=1");
										if($getUsersResponse->count() > 0 ){
											$getMenusResponse=$appObj->returnQueryData("SELECT DISTINCT menu_id_fk,module_id_fk FROM tbl_user_access WHERE group_id_fk=$parentGrp AND user_id_fk !=1");
											$sql_query="INSERT INTO tbl_user_access(module_id_fk,menu_id_fk,access_id_fk,user_id_fk,group_id_fk)values ";
											 $value_array=array();
											 $resDataFinal=array();
											 foreach($getMenusResponse as $fetchMenu){
													$resData['module_id_fk']=$fetchMenu['module_id_fk'];
													$resData['menu_id_fk']=$fetchMenu['menu_id_fk'];
													$resDataFinal[]=$resData;
											 }	
											 foreach($getUsersResponse as $fetch){
												$usrId=$fetch['user_id_fk'];
												foreach($resDataFinal as $resVal){
													 $module_id=$resVal['module_id_fk'];
													 $menu_id=$resVal['menu_id_fk'];
													 $value_array[] = "('$module_id', '$menu_id', 0, '$usrId', '$grpID')";	
												}
											} 
											 $sql_query .= implode(',', $value_array);
											 $appObj->executeQueries($sql_query);
										}
										//end
										
										$checkIsExist = $this->getGatewayCustomizeHomepageMappingTable()->getData($where);
										if($checkIsExist->count() > 0){ 
											$sql_query="INSERT INTO gateway_customize_homepage_mapping(FrameID,ScreenTemplateID,FrameName,FrameHeight,FrameWidth,FrameLeft,FrameTop,AspectRatio,UserName,hostname,isGrpIdOrDeviceId,entryType,os_type)values ";
											$value_array=array();
											foreach($checkIsExist as $homePageData){
												  $FrameID=$homePageData['FrameID'];
												  $ScreenTemplateID=$homePageData['ScreenTemplateID'];
												  $FrameName=$homePageData['FrameName'];
												  $FrameHeight=$homePageData['FrameHeight'];
												  $FrameWidth=$homePageData['FrameWidth'];
												  $FrameLeft=$homePageData['FrameLeft'];
												  $FrameTop=$homePageData['FrameTop'];
												  $AspectRatio=$homePageData['AspectRatio'];
												  $UserName=$homePageData['UserName'];
												  $hostname=$homePageData['hostname'];
												  $isGrpIdOrDeviceId=$grpID;
												  $entryType=$homePageData['entryType'];
												  $os_type=$homePageData['os_type'];
												  $value_array[] = "('$FrameID', '$ScreenTemplateID', '$FrameName', '$FrameHeight', '$FrameWidth','$FrameLeft','$FrameTop','$AspectRatio','$UserName','$hostname','$isGrpIdOrDeviceId','$entryType','$os_type')";  
											}
											$sql_query .= implode(',', $value_array);
											$appObj->executeQueries($sql_query);
										} 
									//2- insert the data into tbl_adsettings_mapping 
									$checkAdSettingExist=$appObj->returnQueryData("SELECT * from tbl_adsettings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($checkAdSettingExist->count() > 0){
										$sql_query2="INSERT INTO tbl_adsettings_mapping(activate_presentation_mode,authentication_mode,active_dir_domain,is_GroupOu_based,moderator,participant,os_type,isGrpIdOrDeviceId,entryType)values ";
										$value_array2=array();
										foreach($checkAdSettingExist as $adSettingData){
											  $activate_presentation_mode=$adSettingData['activate_presentation_mode'];
											  $authentication_mode=$adSettingData['authentication_mode'];
											  $active_dir_domain=$adSettingData['active_dir_domain'];
											  $is_GroupOu_based=$adSettingData['is_GroupOu_based'];
											  $moderator=$adSettingData['moderator'];
											  $participant=$adSettingData['participant'];
											  $isGrpIdOrDeviceId=$grpID;
											  $entryType=$adSettingData['entryType'];
											  $os_type=$adSettingData['os_type'];
											  $value_array2[] = "('$activate_presentation_mode', '$authentication_mode', '$active_dir_domain', '$is_GroupOu_based', '$moderator','$participant','$os_type','$isGrpIdOrDeviceId','$entryType')";  
										}
										$sql_query2 .= implode(',', $value_array2);
										$appObj->executeQueries($sql_query2);
									}
									// 3- insert the data into tbl_advance_configuration_mapping 
									$advaceSettingExist = $this->getAdvanceConfigurationMappingTable()->getData($where);
									if($advaceSettingExist->count() > 0){
										$sql_query3="INSERT INTO tbl_advance_configuration_mapping(feature1,feature2,feature3,feature4,feature5,feature6,feature7,feature8,feature9,feature10,last_updated,isGrpIdOrDeviceId,entryType,field1,field2,os_type,timezone_name)values ";
										$value_array3=array();
										foreach($advaceSettingExist as $advaceSettingData){
											  $feature1=$advaceSettingData['feature1'];
											  $feature2=$advaceSettingData['feature2'];
											  $feature3=$advaceSettingData['feature3'];
											  $feature4=$advaceSettingData['feature4'];
											  $feature5=$advaceSettingData['feature5'];
											  $feature6=$advaceSettingData['feature6'];
											  $feature7=$advaceSettingData['feature7'];
											  $feature8=$advaceSettingData['feature8'];
											  $feature9=$advaceSettingData['feature9'];
											  $feature10=$advaceSettingData['feature10'];
											  $last_updated=$advaceSettingData['last_updated'];
											  if($advaceSettingData['field1']==""){
												  $field1=0;
											  }else{
												  $field1=$advaceSettingData['field1'];
											  }
											  $field2=$advaceSettingData['field2'];
											  $timezone_name=$advaceSettingData['timezone_name'];
											  $isGrpIdOrDeviceId=$grpID;
											  $entryType=$advaceSettingData['entryType'];
											  $os_type=$advaceSettingData['os_type'];
											  $value_array3[] = "('$feature1', '$feature2', '$feature3', '$feature4','$feature5','$feature6','$feature7','$feature8','$feature9','$feature10','$last_updated','$isGrpIdOrDeviceId','$entryType','$field1','$field2','$os_type','$timezone_name')";  
										}
										$sql_query3 .= implode(',', $value_array3);
										$appObj->executeQueries($sql_query3);
									}
									// 4- insert the data into tbl_Auth_FileFormat_mapping 
									$authFileExist=$appObj->returnQueryData("SELECT * from tbl_Auth_FileFormat_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($authFileExist->count() > 0){
										$sql_query4="INSERT INTO tbl_Auth_FileFormat_mapping(FileFormat,isGrpIdOrDeviceId,entryType,os_type,field1,field2)values ";
										$value_array4=array();
										foreach($authFileExist as $authFileData){
											  $FileFormat=$authFileData['FileFormat'];
											  $field1=$authFileData['field1'];
											  if($authFileData['field2']==""){
												 $field2=0;  
											  }else{
												   $field2=$authFileData['field2'];
											  }
											  $isGrpIdOrDeviceId=$grpID;
											  $entryType=$authFileData['entryType'];
											  $os_type=$authFileData['os_type'];
											  $value_array4[] = "('$FileFormat', '$isGrpIdOrDeviceId', '$entryType', '$os_type', '$field1','$field2')";  
										}
										$sql_query4 .= implode(',', $value_array4);
										$appObj->executeQueries($sql_query4);
									}
									// 5- insert the data into tbl_clients_features_mapping 
									$clientFeatureExist=$appObj->returnQueryData("SELECT * from tbl_clients_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($clientFeatureExist->count() > 0){
										$sql_query5="INSERT INTO tbl_clients_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
										$value_array5=array();
										foreach($clientFeatureExist as $clientFeatureData){
											  $feature_hash=$clientFeatureData['feature_hash'];
											  if($clientFeatureData['field1']==""){
												  $field1=0;
											  }else{
												  $field1=$clientFeatureData['field1'];  
											  }
											  $field2=$clientFeatureData['field2'];
											  $isGrpIdOrDeviceId=$grpID;
											  $entryType=$clientFeatureData['entryType'];
											  $os_type=$clientFeatureData['os_type'];
											  $value_array5[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
										}
										$sql_query5 .= implode(',', $value_array5);
										$appObj->executeQueries($sql_query5);
									}
									
									// 6- insert the data into tbl_configuration_mapping 
									$configurationExist=$appObj->returnQueryData("SELECT * from tbl_configuration_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($configurationExist->count() > 0){
										$sql_query6="INSERT INTO tbl_configuration_mapping(activate_RoomName,show_RoomName_Color,activate_RoomCode,show_RoomCode_Color,activate_ShowOnWallpaper,activate_RefreshTime,activate_DateTime,show_DateTime_Wallp_Color,activate_RoomName_SecondDisplay,activate_PowerOffTiming,show_PowerOffTiming, 	hdmi_input_not_start,activatePIPMode,activateSystemLog,activateMediaMode,activateQuickClientAccess,activateEnergySaver,language,mirrorMaxCon,mirrorName,activateDND,activateChat,activateDynamicLayout,24HoursFormat,setDisplayLayout,tpshortcut,disableontop,os_type,qrcode,qrbypass,qrtop, 	isGrpIdOrDeviceId,entryType,activate_autoRebootTiming,show_autoRebootTiming)values ";
										$value_array6=array();
										foreach($configurationExist as $configurationData){
											  $activate_RoomName=$configurationData['activate_RoomName'];
											  $show_RoomName_Color=$configurationData['show_RoomName_Color'];
											  $activate_RoomCode=$configurationData['activate_RoomCode'];
											  $show_RoomCode_Color=$configurationData['show_RoomCode_Color'];
											  $activate_ShowOnWallpaper=$configurationData['activate_ShowOnWallpaper'];
											  $activate_RefreshTime=$configurationData['activate_RefreshTime'];
											  $activate_DateTime=$configurationData['activate_DateTime'];
											  $show_DateTime_Wallp_Color=$configurationData['show_DateTime_Wallp_Color'];
											  $activate_RoomName_SecondDisplay=$configurationData['activate_RoomName_SecondDisplay'];
											  $activate_PowerOffTiming=$configurationData['activate_PowerOffTiming'];
											  $show_PowerOffTiming=$configurationData['show_PowerOffTiming'];
											  $hdmi_input_not_start=$configurationData['hdmi_input_not_start'];
											  $activatePIPMode=$configurationData['activatePIPMode'];
											  $activateSystemLog=$configurationData['activateSystemLog'];
											  $activateMediaMode=$configurationData['activateMediaMode'];
											  $activateQuickClientAccess=$configurationData['activateQuickClientAccess'];
											  $activateEnergySaver=$configurationData['activateEnergySaver'];
											  $language=$configurationData['language'];
											  $mirrorMaxCon=$configurationData['mirrorMaxCon'];
											  $mirrorName=$configurationData['mirrorName'];
											  $activateDND=$configurationData['activateDND'];
											  $activateChat=$configurationData['activateChat'];
											  $activateDynamicLayout=$configurationData['activateDynamicLayout'];
											  $HoursFormat=$configurationData['24HoursFormat'];
											  $setDisplayLayout=$configurationData['setDisplayLayout'];
											  $tpshortcut=$configurationData['tpshortcut'];
											  $disableontop=$configurationData['disableontop'];
											  $os_type=$configurationData['os_type'];
											  $qrcode=$configurationData['qrcode'];
											  $qrbypass=$configurationData['qrbypass'];
											  $qrtop=$configurationData['qrtop'];
											  $entryType=$configurationData['entryType'];
											  $activate_autoRebootTiming=$configurationData['activate_autoRebootTiming'];
											  $show_autoRebootTiming=$configurationData['show_autoRebootTiming'];
											  $isGrpIdOrDeviceId=$grpID;
											  $value_array6[] = "('$activate_RoomName', '$show_RoomName_Color', '$activate_RoomCode', '$show_RoomCode_Color', '$activate_ShowOnWallpaper','$activate_RefreshTime','$activate_DateTime','$show_DateTime_Wallp_Color','$activate_RoomName_SecondDisplay','$activate_PowerOffTiming','$show_PowerOffTiming','$hdmi_input_not_start','$activatePIPMode','$activateSystemLog','$activateMediaMode','$activateQuickClientAccess','$activateEnergySaver','$language','$mirrorMaxCon','$mirrorName','$activateDND','$activateChat','$activateDynamicLayout','$HoursFormat','$setDisplayLayout','$tpshortcut','$disableontop','$os_type','$qrcode','$qrbypass','$qrtop','$isGrpIdOrDeviceId','$entryType','$activate_autoRebootTiming','$show_autoRebootTiming')";  
										}
										$sql_query6 .= implode(',', $value_array6);
										$appObj->executeQueries($sql_query6);
									}
									// 7- insert the data into tbl_display_settings_mapping 
									$displaySettingExist=$appObj->returnQueryData("SELECT * from tbl_display_settings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($displaySettingExist->count() > 0){
										$sql_query7="INSERT INTO tbl_display_settings_mapping(activate_RoomName,show_RoomName_Color,activate_RoomCode,show_RoomCode_Color,activate_ShowOnWallpaper,activate_RefreshTime,activate_DateTime,show_DateTime_Wallp_Color,activate_RoomName_SecondDisplay,24HoursFormat,mirrorMaxCon,mirrorName,activateDynamicLayout,qrcode,qrbypass,qrtop,activateRoomOverlay,RoomOverlayValue,os_type,isGrpIdOrDeviceId,entryType,field1,field2,field3,field4,field5,field6,field7,field8,field9)values ";
										$value_array7=array();
										foreach($displaySettingExist as $displaySettingData){
											  $activate_RoomName=$displaySettingData['activate_RoomName'];
											  $show_RoomName_Color=$displaySettingData['show_RoomName_Color'];
											  $activate_RoomCode=$displaySettingData['activate_RoomCode'];
											  $show_RoomCode_Color=$displaySettingData['show_RoomCode_Color'];
											  $activate_ShowOnWallpaper=$displaySettingData['activate_ShowOnWallpaper'];
											  $activate_RefreshTime=$displaySettingData['activate_RefreshTime'];
											  $activate_DateTime=$displaySettingData['activate_DateTime'];
											  $show_DateTime_Wallp_Color=$displaySettingData['show_DateTime_Wallp_Color'];
											  $activate_RoomName_SecondDisplay=$displaySettingData['activate_RoomName_SecondDisplay'];
											  $HoursFormat=$displaySettingData['24HoursFormat'];
											  $mirrorMaxCon=$displaySettingData['mirrorMaxCon'];
											  $mirrorName=$displaySettingData['mirrorName'];
											  $activateDynamicLayout=$displaySettingData['activateDynamicLayout'];
											  $qrcode=$displaySettingData['qrcode'];
											  $qrbypass=$displaySettingData['qrbypass'];
											  $qrtop=$displaySettingData['qrtop'];
											  $activateRoomOverlay=$displaySettingData['activateRoomOverlay'];
											  $RoomOverlayValue=$displaySettingData['RoomOverlayValue'];
											  $os_type=$displaySettingData['os_type'];
											  $entryType=$displaySettingData['entryType'];
											  $field1=$displaySettingData['field1'];
											  $field2=$displaySettingData['field2'];
											  $field3=$displaySettingData['field3'];
											  $field4=$displaySettingData['field4'];
											  $field5=$displaySettingData['field5'];
											  if($displaySettingData['field6']==""){
												  $field6=0;
											  }else{
												  $field6=$displaySettingData['field6'];
											  }
											  if($displaySettingData['field7']==""){
												  $field7=0;
											  }else{
												  $field7=$displaySettingData['field7'];
											  }
											  if($displaySettingData['field8']==""){
												  $field8=0;
											  }else{
												  $field8=$displaySettingData['field8'];
											  }
											  if($displaySettingData['field9']==""){
												   $field9=0;
											  }else{
												   $field9=$displaySettingData['field9'];
											  }
											  $isGrpIdOrDeviceId=$grpID;
											  $value_array7[] = "('$activate_RoomName', '$show_RoomName_Color', '$activate_RoomCode', '$show_RoomCode_Color', '$activate_ShowOnWallpaper','$activate_RefreshTime','$activate_DateTime','$show_DateTime_Wallp_Color','$activate_RoomName_SecondDisplay','$HoursFormat','$mirrorMaxCon','$mirrorName','$activateDynamicLayout','$qrcode','$qrbypass','$qrtop','$activateRoomOverlay','$RoomOverlayValue','$os_type','$isGrpIdOrDeviceId','$entryType','$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9')";  
										}
										$sql_query7 .= implode(',', $value_array7);
										$appObj->executeQueries($sql_query7);
									}
									
									// 8- insert the data into tbl_gateway_features_mapping 
									$gatewayFeatureExist=$appObj->returnQueryData("SELECT * from tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($gatewayFeatureExist->count() > 0){
										$sql_query8="INSERT INTO tbl_gateway_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
										$value_array8=array();
										foreach($gatewayFeatureExist as $gatewayFeatureData){
											  $feature_hash=$gatewayFeatureData['feature_hash'];
											  if($gatewayFeatureData['field1']==""){
												  $field1=0;
											  }else{
												  $field1=$gatewayFeatureData['field1'];  
											  }
											  $field2=$gatewayFeatureData['field2'];
											  $isGrpIdOrDeviceId=$grpID;
											  $entryType=$gatewayFeatureData['entryType'];
											  $os_type=$gatewayFeatureData['os_type'];
											  $value_array8[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
										}
										$sql_query8 .= implode(',', $value_array8);
										$appObj->executeQueries($sql_query8);
									}
									
									// 9- insert the data into tbl_mobile_features_mapping 
									$mobileFeatureExist=$appObj->returnQueryData("SELECT * from tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($mobileFeatureExist->count() > 0){
										$sql_query9="INSERT INTO tbl_mobile_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
										$value_array9=array();
										foreach($mobileFeatureExist as $mobileFeatureData){
											  $feature_hash=$mobileFeatureData['feature_hash'];
											  if($mobileFeatureData['field1']==""){
												   $field1=0;
											  }else{
												   $field1=$mobileFeatureData['field1'];
											  }
											  $field2=$mobileFeatureData['field2'];
											  $isGrpIdOrDeviceId=$grpID;
											  $entryType=$mobileFeatureData['entryType'];
											  $os_type=$mobileFeatureData['os_type'];
											  $value_array9[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
										}
										$sql_query9 .= implode(',', $value_array9);
										$appObj->executeQueries($sql_query9);
									}
									
									// 10- insert the data into tbl_recording_transfer_mapping 
									$recordingTransferExist=$appObj->returnQueryData("SELECT * from tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($recordingTransferExist->count() > 0){
										$sql_query10="INSERT INTO tbl_recording_transfer_mapping(transfer_option,isGrpIdOrDeviceId,entryType,os_type,field1,field2,field3)values ";
										$value_array10=array();
										foreach($recordingTransferExist as $recordingTransferData){
											  $transfer_option=$recordingTransferData['transfer_option'];
											  $entryType=$recordingTransferData['entryType'];
											  $os_type=$recordingTransferData['os_type'];
											  if($recordingTransferData['field1']==""){
												  $field1=0;
											  }else{
												  $field1=$recordingTransferData['field1'];  
											  }
											  $field2=$recordingTransferData['field2'];
											  $field3=$recordingTransferData['field3'];
											  $isGrpIdOrDeviceId=$grpID;
											  
											  $value_array10[] = "('$transfer_option','$isGrpIdOrDeviceId','$entryType', '$os_type', '$field1', '$field2','$field3')";  
										}
										$sql_query10 .= implode(',', $value_array10);
										$appObj->executeQueries($sql_query10);
									}
									
									// 11- insert the data into tbl_streaming_settings_mapping 
									$streamingExist=$appObj->returnQueryData("SELECT * from tbl_streaming_settings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($streamingExist->count() > 0){
										$sql_query11="INSERT INTO tbl_streaming_settings_mapping(status,display_url_1,display_url_2,entryType,isGrpIdOrDeviceId,os_type,reserve1,reserve2,reserve3,reserve4)values ";
										$value_array11=array();
										foreach($streamingExist as $streamingData){
											  $status=$streamingData['status'];
											  $display_url_1=$streamingData['display_url_1'];
											  $display_url_2=$streamingData['stadisplay_url_2tus'];
											  $entryType=$streamingData['entryType'];
											  $os_type=$streamingData['os_type'];
											  if($streamingData['reserve1']==""){
												   $reserve1=0;
											  }else{
												   $reserve1=$streamingData['reserve1'];
											  }
											  if($streamingData['reserve2']==""){
													 $reserve2=0;
											  }else{
													$reserve2=$streamingData['reserve2'];  
											  }
											  $reserve3=$streamingData['reserve3'];
											  $reserve4=$streamingData['reserve4'];
											  $isGrpIdOrDeviceId=$grpID; 
											  $value_array11[] = "('$status','$display_url_1','$display_url_2', '$entryType', '$isGrpIdOrDeviceId', '$os_type','$reserve1','$reserve2','$reserve3','$reserve4')";  
										}
										$sql_query11 .= implode(',', $value_array11);
										$appObj->executeQueries($sql_query11);
									}
									// 12- insert the data into tbl_wallpaper_mapping 
									$wallpaperExist=$appObj->returnQueryData("SELECT * from tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
									if($wallpaperExist->count() > 0){
										$sql_query12="INSERT INTO tbl_wallpaper_mapping(wallp_name,wallp_created_by,wallp_is_active,isGrpIdOrDeviceId,entryType,field1,field2)values ";
										$value_array12=array();
										foreach($wallpaperExist as $wallpaperData){
											  $wallp_name=$wallpaperData['wallp_name'];
											  $wallp_created_by=$wallpaperData['wallp_created_by'];
											  $wallp_is_active=$wallpaperData['wallp_is_active'];
											  $entryType=$wallpaperData['entryType'];
											  $field1=$wallpaperData['field1'];
											  $field2=$wallpaperData['field2'];
											  $isGrpIdOrDeviceId=$grpID; 
											  $value_array12[] = "('$wallp_name','$wallp_created_by','$wallp_is_active', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
										}
										$sql_query12 .= implode(',', $value_array12);
										$appObj->executeQueries($sql_query12);
									  } 
									  //13- insert the data into tbl_datetime_format_mapping (Added 23-Aug-2018)
										$datetimeFormat=$appObj->returnQueryData("SELECT * from tbl_datetime_format_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
										if($datetimeFormat->count() > 0){
											$sql_query13="INSERT INTO tbl_datetime_format_mapping(date_format,time_format,show_am_pm,os_type,isGrpIdOrDeviceId,entryType)values ";
											$value_array13=array();
											foreach($datetimeFormat as $datetimeFormatData){
												  $date_format=$datetimeFormatData['date_format'];
												  $time_format=$datetimeFormatData['time_format'];
												  $show_am_pm=$datetimeFormatData['show_am_pm'];
												  $isGrpIdOrDeviceId=$grpID;
												  $entryType=$datetimeFormatData['entryType'];
												  $os_type=$datetimeFormatData['os_type'];
												  $value_array13[] = "('$date_format', '$time_format', '$show_am_pm', '$isGrpIdOrDeviceId', '$entryType','$os_type')";  
											}
											$sql_query13 .= implode(',', $value_array13);
											$appObj->executeQueries($sql_query13);
										}
										
										//14- insert the data into tbl_advance_more_features_mapping(Added 23-Aug-2018)
										$advanceMoreFeature=$appObj->returnQueryData("SELECT * from tbl_advance_more_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
										if($advanceMoreFeature->count() > 0){
											$sql_query14="INSERT INTO tbl_advance_more_features_mapping(property_name,ivalue,strvalue,modifydatetime,entryType,isGrpIdOrDeviceId,os_type)values ";
											$value_array14=array();
											foreach($advanceMoreFeature as $advanceMoreFeatureData){
												  $property_name=$advanceMoreFeatureData['property_name'];
												  $ivalue=$advanceMoreFeatureData['ivalue'];
												  $strvalue=$advanceMoreFeatureData['strvalue'];
												  $modifydatetime=$advanceMoreFeatureData['modifydatetime'];
												  $isGrpIdOrDeviceId=$grpID;
												  $entryType=$advanceMoreFeatureData['entryType'];
												  $os_type=$advanceMoreFeatureData['os_type'];
												  $value_array14[] = "('$property_name', '$ivalue', '$strvalue', '$modifydatetime', '$isGrpIdOrDeviceId','$entryType','$os_type')";  
											}
											$sql_query14 .= implode(',', $value_array14);
											$appObj->executeQueries($sql_query14);
										}
										
										//15- Insert for template designer(11-Oct-2019)
										$templateSetting=$appObj->returnQueryData("SELECT * from tbl_templates_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
										if($templateSetting->count() > 0){
											$sql_query15="INSERT INTO tbl_templates_mapping(template_id,wallpaper_name,isGrpIdOrDeviceId,entryType,model_type,modifydatetime)values ";
											$value_array15=array();
											foreach($templateSetting as $templateSettingData){
												  $template_id=$templateSettingData['template_id'];
												  $wallpaper_name=$templateSettingData['wallpaper_name'];
												  $isGrpIdOrDeviceId=$grpID;
												  $entryType=$templateSettingData['entryType'];
												  $value_array15[] = "('$template_id', '$wallpaper_name','$isGrpIdOrDeviceId','$entryType',0,'".date('Y-m-d H:i:s')."')";  
											}
											$sql_query15 .= implode(',', $value_array15);
											$appObj->executeQueries($sql_query15);
										}else{
											$appObj->executeQueries("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type,modifydatetime)values (1,$grpID,0,0,'".date('Y-m-d H:i:s')."')");
										}
										//16- Insert for viasetting template (04 July 2020)
										$viatemplateSetting=$appObj->returnQueryData("SELECT * from tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
										if($viatemplateSetting->count() > 0){
											$sql_query16="INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type,modifydatetime)values ";
											$value_array16=array();
											foreach($viatemplateSetting as $viatemplateSettingData){
												  $template_id=$viatemplateSettingData['template_id'];
												  $isGrpIdOrDeviceId=$grpID;
												  $entryType=$viatemplateSettingData['entryType'];
												  $value_array16[] = "('$template_id', '$isGrpIdOrDeviceId','$entryType',0,'".date('Y-m-d H:i:s')."')";  
											}
											$sql_query16 .= implode(',', $value_array16);
											$appObj->executeQueries($sql_query16);
										}else{
											$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,modifydatetime)values (1,$grpID,0,0,'".date('Y-m-d H:i:s')."')");
										}
										  
									  //update the tbl_sys_report table(4-Apr-2018)
										$grpResult=$appObj->returnQueryData("select DID from DeviceInventory WHERE DeviceGroupID=$grpID");
										if($grpResult->count() > 0){
											foreach($grpResult as $rowData){
											   $gwayIdList.=$rowData['DID'].",";
											 }
											$newGwayList=rtrim($gwayIdList,",");
											$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0,clientFeaturesStatus=0,configSettingStatus=0,dateTimeSettingStatus=0,authSettingStatus=0,mobileFeaturesStatus=0 WHERE did_fk IN ($newGwayList)");
											$appObj->executeQueries("UPDATE tbl_advance_sys_report SET advanceConfigStatus=0 WHERE did_fk IN ($newGwayList)");
										}
									}else{
										$tempSql = $appObj->returnQueryData("SELECT * from tbl_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										if($tempSql->count() == 0){
											$appObj->executeQueries("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$grpID,0,0)");
										}
										$settingSql = $appObj->returnQueryData("SELECT * from tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
										if($settingSql->count() == 0){
											$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$grpID,0,0)");
										}
									}
									$appObj->ActivityLogVSM(4,STR_GROUP.' '.$grpName.' '.MSG_USER_UPDATED,2);
									echo "update";die;	
								}elseif($recount==1){
									$myselQry = $appObj->returnQueryData("SELECT DeviceGroup FROM devicegroup WHERE DeviceGroupID=$grpID"); 
									$data=$myselQry->current();
									$dbGrpName=	$data['DeviceGroup'];
									if($dbGrpName==$grpName){
										//echo"own";
										$str5=$appObj->executeQueries("UPDATE devicegroup SET DeviceGroup='$grpName',Comments='$grpRemarks' WHERE DeviceGroupID=$grpID");	
							
							
								//Inherit the parent group properties (2-APR-2018)
	 
										// 1- insert the data into gateway_customize_homepage_mapping 
										if($parentGrp !=0){
											//Delete the existing data
											 $appObj->executeQueries("DELETE FROM gateway_customize_homepage_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_adsettings_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_advance_configuration_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_Auth_FileFormat_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_clients_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_configuration_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_display_settings_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_streaming_settings_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											  //Added 23-Aug-2018
											 $appObj->executeQueries("DELETE FROM tbl_advance_more_features_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											 $appObj->executeQueries("DELETE FROM tbl_datetime_format_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											
											//Delete the existing entry
											$appObj->executeQueries("DELETE FROM tbl_user_access WHERE group_id_fk=$grpID");
											//Added the conditions for get the user permission of parent group(Added 22-Aug-2018)
											$getUsersResponse=$appObj->returnQueryData("SELECT DISTINCT user_id_fk FROM tbl_user_access WHERE group_id_fk=$parentGrp AND user_id_fk !=1");
											if($getUsersResponse->count() > 0 ){
												$getMenusResponse=$appObj->returnQueryData("SELECT DISTINCT menu_id_fk,module_id_fk FROM tbl_user_access WHERE group_id_fk=$parentGrp AND user_id_fk !=1");
												
												 $sql_query="INSERT INTO tbl_user_access(module_id_fk,menu_id_fk,access_id_fk,user_id_fk,group_id_fk)values ";
												 $value_array=array();
												 $resDataFinal=array();
												 foreach($getMenusResponse as $fetchMenu){
														$resData['module_id_fk']=$fetchMenu['module_id_fk'];
														$resData['menu_id_fk']=$fetchMenu['menu_id_fk'];
														$resDataFinal[]=$resData;
												 }	
												 foreach($getUsersResponse as $fetch){
													$usrId=$fetch['user_id_fk'];
													foreach($resDataFinal as $resVal){
														 $module_id=$resVal['module_id_fk'];
														 $menu_id=$resVal['menu_id_fk'];
														 $value_array[] = "('$module_id', '$menu_id', 0, '$usrId', '$grpID')";	
													}
												} 
												 $sql_query .= implode(',', $value_array);
												 $appObj->executeQueries($sql_query);
											}
											//end
											
											$checkIsExist=$appObj->returnQueryData("SELECT * from gateway_customize_homepage_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($checkIsExist->count() > 0){ 
												$sql_query="INSERT INTO gateway_customize_homepage_mapping(FrameID,ScreenTemplateID,FrameName,FrameHeight,FrameWidth,FrameLeft,FrameTop,AspectRatio,UserName,hostname,isGrpIdOrDeviceId,entryType,os_type)values ";
												$value_array=array();
												foreach($checkIsExist as $homePageData){
													  $FrameID=$homePageData['FrameID'];
													  $ScreenTemplateID=$homePageData['ScreenTemplateID'];
													  $FrameName=$homePageData['FrameName'];
													  $FrameHeight=$homePageData['FrameHeight'];
													  $FrameWidth=$homePageData['FrameWidth'];
													  $FrameLeft=$homePageData['FrameLeft'];
													  $FrameTop=$homePageData['FrameTop'];
													  $AspectRatio=$homePageData['AspectRatio'];
													  $UserName=$homePageData['UserName'];
													  $hostname=$homePageData['hostname'];
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$homePageData['entryType'];
													  $os_type=$homePageData['os_type'];
													  $value_array[] = "('$FrameID', '$ScreenTemplateID', '$FrameName', '$FrameHeight', '$FrameWidth','$FrameLeft','$FrameTop','$AspectRatio','$UserName','$hostname','$isGrpIdOrDeviceId','$entryType','$os_type')";  
												}
												$sql_query .= implode(',', $value_array);
												$appObj->executeQueries($sql_query);
											} 
											// 2- insert the data into tbl_adsettings_mapping 
											$checkAdSettingExist=$appObj->returnQueryData("SELECT * from tbl_adsettings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($checkAdSettingExist->count() > 0){
												$sql_query2="INSERT INTO tbl_adsettings_mapping(activate_presentation_mode,authentication_mode,active_dir_domain,is_GroupOu_based,moderator,participant,os_type,isGrpIdOrDeviceId,entryType)values ";
												$value_array2=array();
												foreach($checkAdSettingExist as $adSettingData){
													  $activate_presentation_mode=$adSettingData['activate_presentation_mode'];
													  $authentication_mode=$adSettingData['authentication_mode'];
													  $active_dir_domain=$adSettingData['active_dir_domain'];
													  $is_GroupOu_based=$adSettingData['is_GroupOu_based'];
													  $moderator=$adSettingData['moderator'];
													  $participant=$adSettingData['participant'];
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$adSettingData['entryType'];
													  $os_type=$adSettingData['os_type'];
													  $value_array2[] = "('$activate_presentation_mode', '$authentication_mode', '$active_dir_domain', '$is_GroupOu_based', '$moderator','$participant','$os_type','$isGrpIdOrDeviceId','$entryType')";  
												}
												$sql_query2 .= implode(',', $value_array2);
												$appObj->executeQueries($sql_query2);
											}
											// 3- insert the data into tbl_advance_configuration_mapping 
											$advaceSettingExist=$appObj->returnQueryData("SELECT * from tbl_advance_configuration_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($advaceSettingExist->count() > 0){
												$sql_query3="INSERT INTO tbl_advance_configuration_mapping(feature1,feature2,feature3,feature4,feature5,feature6,feature7,feature8,feature9,feature10,last_updated,isGrpIdOrDeviceId,entryType,field1,field2,os_type,timezone_name)values ";
												$value_array3=array();
												foreach($advaceSettingExist as $advaceSettingData){
													  $feature1=$advaceSettingData['feature1'];
													  $feature2=$advaceSettingData['feature2'];
													  $feature3=$advaceSettingData['feature3'];
													  $feature4=$advaceSettingData['feature4'];
													  $feature5=$advaceSettingData['feature5'];
													  $feature6=$advaceSettingData['feature6'];
													  $feature7=$advaceSettingData['feature7'];
													  $feature8=$advaceSettingData['feature8'];
													  $feature9=$advaceSettingData['feature9'];
													  $feature10=$advaceSettingData['feature10'];
													  $last_updated=$advaceSettingData['last_updated'];
													  if($advaceSettingData['field1']==""){
														  $field1=0;
													  }else{
														  $field1=$advaceSettingData['field1'];
													  }
													  $field2=$advaceSettingData['field2'];
													  $timezone_name=$advaceSettingData['timezone_name'];
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$advaceSettingData['entryType'];
													  $os_type=$advaceSettingData['os_type'];
													  $value_array3[] = "('$feature1', '$feature2', '$feature3', '$feature4','$feature5','$feature6','$feature7','$feature8','$feature9','$feature10','$last_updated','$isGrpIdOrDeviceId','$entryType','$field1','$field2','$os_type','$timezone_name')";  
												}
												$sql_query3 .= implode(',', $value_array3);
												$appObj->executeQueries($sql_query3);
											}
											// 4- insert the data into tbl_Auth_FileFormat_mapping 
											$authFileExist=$appObj->returnQueryData("SELECT * from tbl_Auth_FileFormat_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($authFileExist->count() > 0){
												$sql_query4="INSERT INTO tbl_Auth_FileFormat_mapping(FileFormat,isGrpIdOrDeviceId,entryType,os_type,field1,field2)values ";
												$value_array4=array();
												foreach($authFileExist as $authFileData){
													  $FileFormat=$authFileData['FileFormat'];
													  $field1=$authFileData['field1'];
													  if($authFileData['field2']==""){
														 $field2=0;  
													  }else{
														   $field2=$authFileData['field2'];
													  }
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$authFileData['entryType'];
													  $os_type=$authFileData['os_type'];
													  $value_array4[] = "('$FileFormat', '$isGrpIdOrDeviceId', '$entryType', '$os_type', '$field1','$field2')";  
												}
												$sql_query4 .= implode(',', $value_array4);
												$appObj->executeQueries($sql_query4);
											}
											// 5- insert the data into tbl_clients_features_mapping 
											$clientFeatureExist=$appObj->returnQueryData("SELECT * from tbl_clients_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($clientFeatureExist->count() > 0){
												$sql_query5="INSERT INTO tbl_clients_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
												$value_array5=array();
												foreach($clientFeatureExist as $clientFeatureData){
													  $feature_hash=$clientFeatureData['feature_hash'];
													  if($clientFeatureData['field1']==""){
														  $field1=0;
													  }else{
														  $field1=$clientFeatureData['field1'];  
													  }
													  $field2=$clientFeatureData['field2'];
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$clientFeatureData['entryType'];
													  $os_type=$clientFeatureData['os_type'];
													  $value_array5[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
												}
												$sql_query5 .= implode(',', $value_array5);
												$appObj->executeQueries($sql_query5);
											}
										
											// 6- insert the data into tbl_configuration_mapping 
											$configurationExist=$appObj->returnQueryData("SELECT * from tbl_configuration_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($configurationExist->count() > 0){
												$sql_query6="INSERT INTO tbl_configuration_mapping(activate_RoomName,show_RoomName_Color,activate_RoomCode,show_RoomCode_Color,activate_ShowOnWallpaper,activate_RefreshTime,activate_DateTime,show_DateTime_Wallp_Color,activate_RoomName_SecondDisplay,activate_PowerOffTiming,show_PowerOffTiming, 	hdmi_input_not_start,activatePIPMode,activateSystemLog,activateMediaMode,activateQuickClientAccess,activateEnergySaver,language,mirrorMaxCon,mirrorName,activateDND,activateChat,activateDynamicLayout,24HoursFormat,setDisplayLayout,tpshortcut,disableontop,os_type,qrcode,qrbypass,qrtop, 	isGrpIdOrDeviceId,entryType,activate_autoRebootTiming,show_autoRebootTiming)values ";
												$value_array6=array();
												foreach($configurationExist as $configurationData){
													  $activate_RoomName=$configurationData['activate_RoomName'];
													  $show_RoomName_Color=$configurationData['show_RoomName_Color'];
													  $activate_RoomCode=$configurationData['activate_RoomCode'];
													  $show_RoomCode_Color=$configurationData['show_RoomCode_Color'];
													  $activate_ShowOnWallpaper=$configurationData['activate_ShowOnWallpaper'];
													  $activate_RefreshTime=$configurationData['activate_RefreshTime'];
													  $activate_DateTime=$configurationData['activate_DateTime'];
													  $show_DateTime_Wallp_Color=$configurationData['show_DateTime_Wallp_Color'];
													  $activate_RoomName_SecondDisplay=$configurationData['activate_RoomName_SecondDisplay'];
													  $activate_PowerOffTiming=$configurationData['activate_PowerOffTiming'];
													  $show_PowerOffTiming=$configurationData['show_PowerOffTiming'];
													  $hdmi_input_not_start=$configurationData['hdmi_input_not_start'];
													  $activatePIPMode=$configurationData['activatePIPMode'];
													  $activateSystemLog=$configurationData['activateSystemLog'];
													  $activateMediaMode=$configurationData['activateMediaMode'];
													  $activateQuickClientAccess=$configurationData['activateQuickClientAccess'];
													  $activateEnergySaver=$configurationData['activateEnergySaver'];
													  $language=$configurationData['language'];
													  $mirrorMaxCon=$configurationData['mirrorMaxCon'];
													  $mirrorName=$configurationData['mirrorName'];
													  $activateDND=$configurationData['activateDND'];
													  $activateChat=$configurationData['activateChat'];
													  $activateDynamicLayout=$configurationData['activateDynamicLayout'];
													  $HoursFormat=$configurationData['24HoursFormat'];
													  $setDisplayLayout=$configurationData['setDisplayLayout'];
													  $tpshortcut=$configurationData['tpshortcut'];
													  $disableontop=$configurationData['disableontop'];
													  $os_type=$configurationData['os_type'];
													  $qrcode=$configurationData['qrcode'];
													  $qrbypass=$configurationData['qrbypass'];
													  $qrtop=$configurationData['qrtop'];
													  $entryType=$configurationData['entryType'];
													  $activate_autoRebootTiming=$configurationData['activate_autoRebootTiming'];
													  $show_autoRebootTiming=$configurationData['show_autoRebootTiming'];
													  $isGrpIdOrDeviceId=$grpID;
													  $value_array6[] = "('$activate_RoomName', '$show_RoomName_Color', '$activate_RoomCode', '$show_RoomCode_Color', '$activate_ShowOnWallpaper','$activate_RefreshTime','$activate_DateTime','$show_DateTime_Wallp_Color','$activate_RoomName_SecondDisplay','$activate_PowerOffTiming','$show_PowerOffTiming','$hdmi_input_not_start','$activatePIPMode','$activateSystemLog','$activateMediaMode','$activateQuickClientAccess','$activateEnergySaver','$language','$mirrorMaxCon','$mirrorName','$activateDND','$activateChat','$activateDynamicLayout','$HoursFormat','$setDisplayLayout','$tpshortcut','$disableontop','$os_type','$qrcode','$qrbypass','$qrtop','$isGrpIdOrDeviceId','$entryType','$activate_autoRebootTiming','$show_autoRebootTiming')";  
												}
												$sql_query6 .= implode(',', $value_array6);
												$appObj->executeQueries($sql_query6);
											}
											// 7- insert the data into tbl_display_settings_mapping 
											$displaySettingExist=$appObj->returnQueryData("SELECT * from tbl_display_settings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($displaySettingExist->count() > 0){
												$sql_query7="INSERT INTO tbl_display_settings_mapping(activate_RoomName,show_RoomName_Color,activate_RoomCode,show_RoomCode_Color,activate_ShowOnWallpaper,activate_RefreshTime,activate_DateTime,show_DateTime_Wallp_Color,activate_RoomName_SecondDisplay,24HoursFormat,mirrorMaxCon,mirrorName,activateDynamicLayout,qrcode,qrbypass,qrtop,activateRoomOverlay,RoomOverlayValue,os_type,isGrpIdOrDeviceId,entryType,field1,field2,field3,field4,field5,field6,field7,field8,field9)values ";
												$value_array7=array();
												foreach($displaySettingExist as $displaySettingData){
													  $activate_RoomName=$displaySettingData['activate_RoomName'];
													  $show_RoomName_Color=$displaySettingData['show_RoomName_Color'];
													  $activate_RoomCode=$displaySettingData['activate_RoomCode'];
													  $show_RoomCode_Color=$displaySettingData['show_RoomCode_Color'];
													  $activate_ShowOnWallpaper=$displaySettingData['activate_ShowOnWallpaper'];
													  $activate_RefreshTime=$displaySettingData['activate_RefreshTime'];
													  $activate_DateTime=$displaySettingData['activate_DateTime'];
													  $show_DateTime_Wallp_Color=$displaySettingData['show_DateTime_Wallp_Color'];
													  $activate_RoomName_SecondDisplay=$displaySettingData['activate_RoomName_SecondDisplay'];
													  $HoursFormat=$displaySettingData['24HoursFormat'];
													  $mirrorMaxCon=$displaySettingData['mirrorMaxCon'];
													  $mirrorName=$displaySettingData['mirrorName'];
													  $activateDynamicLayout=$displaySettingData['activateDynamicLayout'];
													  $qrcode=$displaySettingData['qrcode'];
													  $qrbypass=$displaySettingData['qrbypass'];
													  $qrtop=$displaySettingData['qrtop'];
													  $activateRoomOverlay=$displaySettingData['activateRoomOverlay'];
													  $RoomOverlayValue=$displaySettingData['RoomOverlayValue'];
													  $os_type=$displaySettingData['os_type'];
													  $entryType=$displaySettingData['entryType'];
													  $field1=$displaySettingData['field1'];
													  $field2=$displaySettingData['field2'];
													  $field3=$displaySettingData['field3'];
													  $field4=$displaySettingData['field4'];
													  $field5=$displaySettingData['field5'];
													  if($displaySettingData['field6']==""){
														  $field6=0;
													  }else{
														  $field6=$displaySettingData['field6'];
													  }
													  if($displaySettingData['field7']==""){
														  $field7=0;
													  }else{
														  $field7=$displaySettingData['field7'];
													  }
													  if($displaySettingData['field8']==""){
														  $field8=0;
													  }else{
														  $field8=$displaySettingData['field8'];
													  }
													  if($displaySettingData['field9']==""){
														   $field9=0;
													  }else{
														   $field9=$displaySettingData['field9'];
													  }
													  $isGrpIdOrDeviceId=$grpID;
													  $value_array7[] = "('$activate_RoomName', '$show_RoomName_Color', '$activate_RoomCode', '$show_RoomCode_Color', '$activate_ShowOnWallpaper','$activate_RefreshTime','$activate_DateTime','$show_DateTime_Wallp_Color','$activate_RoomName_SecondDisplay','$HoursFormat','$mirrorMaxCon','$mirrorName','$activateDynamicLayout','$qrcode','$qrbypass','$qrtop','$activateRoomOverlay','$RoomOverlayValue','$os_type','$isGrpIdOrDeviceId','$entryType','$field1','$field2','$field3','$field4','$field5','$field6','$field7','$field8','$field9')";  
												}
												$sql_query7 .= implode(',', $value_array7);
												$appObj->executeQueries($sql_query7);
											}
										
											// 8- insert the data into tbl_gateway_features_mapping 
											$gatewayFeatureExist=$appObj->returnQueryData("SELECT * from tbl_gateway_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($gatewayFeatureExist->count() > 0){
												$sql_query8="INSERT INTO tbl_gateway_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
												$value_array8=array();
												foreach($gatewayFeatureExist as $gatewayFeatureData){
													  $feature_hash=$gatewayFeatureData['feature_hash'];
													  if($gatewayFeatureData['field1']==""){
														  $field1=0;
													  }else{
														  $field1=$gatewayFeatureData['field1'];  
													  }
													  $field2=$gatewayFeatureData['field2'];
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$gatewayFeatureData['entryType'];
													  $os_type=$gatewayFeatureData['os_type'];
													  $value_array8[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
												}
												$sql_query8 .= implode(',', $value_array8);
												$appObj->executeQueries($sql_query8);
											}
										
											// 9- insert the data into tbl_mobile_features_mapping 
											$mobileFeatureExist=$appObj->returnQueryData("SELECT * from tbl_mobile_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($mobileFeatureExist->count() > 0){
												$sql_query9="INSERT INTO tbl_mobile_features_mapping(feature_hash,os_type,isGrpIdOrDeviceId,entryType,field1,field2)values ";
												$value_array9=array();
												foreach($mobileFeatureExist as $mobileFeatureData){
													  $feature_hash=$mobileFeatureData['feature_hash'];
													  if($mobileFeatureData['field1']==""){
														   $field1=0;
													  }else{
														   $field1=$mobileFeatureData['field1'];
													  }
													  $field2=$mobileFeatureData['field2'];
													  $isGrpIdOrDeviceId=$grpID;
													  $entryType=$mobileFeatureData['entryType'];
													  $os_type=$mobileFeatureData['os_type'];
													  $value_array9[] = "('$feature_hash', '$os_type', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
												}
												$sql_query9 .= implode(',', $value_array9);
												$appObj->executeQueries($sql_query9);
											}
											
											// 10- insert the data into tbl_recording_transfer_mapping 
											$recordingTransferExist=$appObj->returnQueryData("SELECT * from tbl_recording_transfer_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($recordingTransferExist->count() > 0){
												$sql_query10="INSERT INTO tbl_recording_transfer_mapping(transfer_option,isGrpIdOrDeviceId,entryType,os_type,field1,field2,field3)values ";
												$value_array10=array();
												foreach($recordingTransferExist as $recordingTransferData){
													  $transfer_option=$recordingTransferData['transfer_option'];
													  $entryType=$recordingTransferData['entryType'];
													  $os_type=$recordingTransferData['os_type'];
													  if($recordingTransferData['field1']==""){
														  $field1=0;
													  }else{
														  $field1=$recordingTransferData['field1'];  
													  }
													  $field2=$recordingTransferData['field2'];
													  $field3=$recordingTransferData['field3'];
													  $isGrpIdOrDeviceId=$grpID;
													  $value_array10[] = "('$transfer_option','$isGrpIdOrDeviceId','$entryType', '$os_type', '$field1', '$field2','$field3')";  
												}
												$sql_query10 .= implode(',', $value_array10);
												$appObj->executeQueries($sql_query10);
											}
											
											// 11- insert the data into tbl_streaming_settings_mapping 
											$streamingExist=$appObj->returnQueryData("SELECT * from tbl_streaming_settings_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($streamingExist->count() > 0){
												$sql_query11="INSERT INTO tbl_streaming_settings_mapping(status,display_url_1,display_url_2,entryType,isGrpIdOrDeviceId,os_type,reserve1,reserve2,reserve3,reserve4)values ";
												$value_array11=array();
												foreach($streamingExist as $streamingData){
													  $status=$streamingData['status'];
													  $display_url_1=$streamingData['display_url_1'];
													  $display_url_2=$streamingData['stadisplay_url_2tus'];
													  $entryType=$streamingData['entryType'];
													  $os_type=$streamingData['os_type'];
													  if($streamingData['reserve1']==""){
														   $reserve1=0;
													  }else{
														   $reserve1=$streamingData['reserve1'];
													  }
													  if($streamingData['reserve2']==""){
															 $reserve2=0;
													  }else{
															$reserve2=$streamingData['reserve2'];  
													  }
													  $reserve3=$streamingData['reserve3'];
													  $reserve4=$streamingData['reserve4'];
													  $isGrpIdOrDeviceId=$grpID; 
													  $value_array11[] = "('$status','$display_url_1','$display_url_2', '$entryType', '$isGrpIdOrDeviceId', '$os_type','$reserve1','$reserve2','$reserve3','$reserve4')";  
												}
												$sql_query11 .= implode(',', $value_array11);
												$appObj->executeQueries($sql_query11);
											}
											// 12- insert the data into tbl_wallpaper_mapping 
											$wallpaperExist=$appObj->returnQueryData("SELECT * from tbl_wallpaper_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
											if($wallpaperExist->count() > 0){
												$sql_query12="INSERT INTO tbl_wallpaper_mapping(wallp_name,wallp_created_by,wallp_is_active,isGrpIdOrDeviceId,entryType,field1,field2)values ";
												$value_array12=array();
												foreach($wallpaperExist as $wallpaperData){
													  $wallp_name=$wallpaperData['wallp_name'];
													  $wallp_created_by=$wallpaperData['wallp_created_by'];
													  $wallp_is_active=$wallpaperData['wallp_is_active'];
													  $entryType=$wallpaperData['entryType'];
													  $field1=$wallpaperData['field1'];
													  $field2=$wallpaperData['field2'];
													  $isGrpIdOrDeviceId=$grpID; 
													  $value_array12[] = "('$wallp_name','$wallp_created_by','$wallp_is_active', '$isGrpIdOrDeviceId', '$entryType', '$field1','$field2')";  
												}
												$sql_query12 .= implode(',', $value_array12);
												$appObj->executeQueries($sql_query12);
											  }
											  //13- insert the data into tbl_datetime_format_mapping (Added 23-Aug-2018)
												$datetimeFormat=$appObj->returnQueryData("SELECT * from tbl_datetime_format_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
												if($datetimeFormat->count() > 0){
													$sql_query13="INSERT INTO tbl_datetime_format_mapping(date_format,time_format,show_am_pm,os_type,isGrpIdOrDeviceId,entryType)values ";
													$value_array13=array();
													foreach($datetimeFormat as $datetimeFormatData){
														  $date_format=$datetimeFormatData['date_format'];
														  $time_format=$datetimeFormatData['time_format'];
														  $show_am_pm=$datetimeFormatData['show_am_pm'];
														  $isGrpIdOrDeviceId=$grpID;
														  $entryType=$datetimeFormatData['entryType'];
														  $os_type=$datetimeFormatData['os_type'];
														  $value_array13[] = "('$date_format', '$time_format', '$show_am_pm', '$isGrpIdOrDeviceId', '$entryType','$os_type')";  
													}
													$sql_query13 .= implode(',', $value_array13);
													$appObj->executeQueries($sql_query13);
												}
												
												//14- insert the data into tbl_advance_more_features_mapping(Added 23-Aug-2018)
												$advanceMoreFeature=$appObj->returnQueryData("SELECT * from tbl_advance_more_features_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
												if($advanceMoreFeature->count() > 0){
													$sql_query14="INSERT INTO tbl_advance_more_features_mapping(property_name,ivalue,strvalue,modifydatetime,entryType,isGrpIdOrDeviceId,os_type)values ";
													$value_array14=array();
													foreach($advanceMoreFeature as $advanceMoreFeatureData){
														  $property_name=$advanceMoreFeatureData['property_name'];
														  $ivalue=$advanceMoreFeatureData['ivalue'];
														  $strvalue=$advanceMoreFeatureData['strvalue'];
														  $modifydatetime=$advanceMoreFeatureData['modifydatetime'];
														  $isGrpIdOrDeviceId=$grpID;
														  $entryType=$advanceMoreFeatureData['entryType'];
														  $os_type=$advanceMoreFeatureData['os_type'];
														  $value_array14[] = "('$property_name', '$ivalue', '$strvalue', '$modifydatetime', '$isGrpIdOrDeviceId','$entryType','$os_type')";  
													}
													$sql_query14 .= implode(',', $value_array14);
													$appObj->executeQueries($sql_query14);
												}
												//15- Insert for template designer(11-Oct-2019)
												$templateSetting=$appObj->returnQueryData("SELECT * from tbl_templates_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
												if($templateSetting->count() > 0){
													$sql_query15="INSERT INTO tbl_templates_mapping(template_id,wallpaper_name,isGrpIdOrDeviceId,entryType,model_type)values ";
													$value_array15=array();
													foreach($templateSetting as $templateSettingData){
														  $template_id=$templateSettingData['template_id'];
														  $wallpaper_name=$templateSettingData['wallpaper_name'];
														  $isGrpIdOrDeviceId=$grpID;
														  $entryType=$templateSettingData['entryType'];
														  $value_array15[] = "('$template_id', '$wallpaper_name','$isGrpIdOrDeviceId','$entryType',0)";  
													}
													$sql_query15 .= implode(',', $value_array15);
													$appObj->executeQueries($sql_query15);
												}else{
													$appObj->executeQueries("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$grpID,0,0)");
												}
												//16- Insert for viasetting template (04 July 2020)
												$viatemplateSetting=$appObj->returnQueryData("SELECT * from tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$parentGrp AND entryType=0");
												if($viatemplateSetting->count() > 0){
													$sql_query16="INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values ";
													$value_array16=array();
													foreach($viatemplateSetting as $viatemplateSettingData){
														  $template_id=$viatemplateSettingData['template_id'];
														  $isGrpIdOrDeviceId=$grpID;
														  $entryType=$viatemplateSettingData['entryType'];
														  $value_array16[] = "('$template_id', '$isGrpIdOrDeviceId','$entryType',0)";  
													}
													$sql_query16 .= implode(',', $value_array16);
													$appObj->executeQueries($sql_query16);
												}else{
													$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$grpID,0,0)");
												}
											
											   //update the tbl_sys_report table(4-Apr-2018)
												$grpResult=$appObj->returnQueryData("select DID from DeviceInventory WHERE DeviceGroupID=$grpID");
												if($grpResult->count() > 0){
													foreach($grpResult as $rowData){
														   $gwayIdList.=$rowData['DID'].",";
													 }
													$newGwayList=rtrim($gwayIdList,",");
													$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0,clientFeaturesStatus=0, 	configSettingStatus=0,dateTimeSettingStatus=0,authSettingStatus=0,mobileFeaturesStatus=0 WHERE did_fk IN ($newGwayList)");
													$appObj->executeQueries("UPDATE tbl_advance_sys_report SET advanceConfigStatus=0 WHERE did_fk IN ($newGwayList)");  
												}
										}else{
											$tempSql = $appObj->returnQueryData("SELECT * from tbl_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											if($tempSql->count() == 0){
												$appObj->executeQueries("INSERT INTO tbl_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$grpID,0,0)");
											}
											$settingSql = $appObj->returnQueryData("SELECT * from tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId=$grpID AND entryType=0");
											if($settingSql->count() == 0){
												$appObj->executeQueries("INSERT INTO tbl_via_settings_templates_mapping(template_id,isGrpIdOrDeviceId,entryType,model_type)values (1,$grpID,0,0)");
											}
										}
										$appObj->ActivityLogVSM(4,STR_GROUP.' '.$grpName.' '.MSG_USER_UPDATED,2);
										echo "update";die;
									}else{
										echo"Exists";die;
									}			
								}else{
									echo"Exists";die;
								}		
							}else{
									echo"Already Exists";die;  // if group already exists.
							}	
						}
					}else{
						 echo "NotAllowed";die;
					}
				}	
			}
		}
	}

	public function deleteGroupAction(){
		$groupid = $this->getRequest()->getPost('GroupId');
		$appObj = new ApplicationController();
		//$groupIDStr = trim($request->getPost('checkedBox'));
		//$groupIdArr=explode(",",$groupIDStr);
		//foreach($groupIdArr as $key=>$val){
			//get the all child 
			$res2 = $appObj->returnQueryData("SELECT DISTINCT(GetChildTree($groupid)) as child FROM devicegroup");
			$countRows = $res2->count();	
			if($countRows > 0){
				foreach($res2 as $data){
					$childArray[]=$data; 
				}
				$newChildArr=$childArray[0]['child'];
				if($newChildArr==""){
					$arr=$newChildArr;
				}else{
					$arr=",".$newChildArr;
				}
			}
			// get the current and all respective child group list.
			$delArrList=$groupid.$arr;
			
			// query for log table
			$grpArr = array('DeviceGroupID'=>$groupid);
			$mysql_grp = $this->getDevicegroupTable()->getGroup($grpArr);
			$grp_sql_arr=$mysql_grp->current();
			$getDel_grpname=$grp_sql_arr->DeviceGroup;
			//delete the current group and respective child group.
			$where = "DeviceGroupID IN ($delArrList)";
			$this->getDevicegroupTable()->deleteGroup($where);
			//delete set template
			$appObj->executeQueries("DELETE FROM tbl_templates_mapping WHERE isGrpIdOrDeviceId IN ($delArrList)");
			//delete set settings template
			$appObj->executeQueries("DELETE FROM tbl_via_settings_templates_mapping WHERE isGrpIdOrDeviceId IN ($delArrList)");
			
			$countRecords = $this->getDeviceInventoryTable()->getData(array('DeviceGroupID' => $groupid));
			//delete the group details from tbl_use_access table(1-Feb-2018)
			$appObj->executeQueries("DELETE FROM tbl_user_access WHERE group_id_fk IN ($delArrList)");
			if($countRecords->count()>0){
				$sqlQry = $this->getDeviceInventoryTable()->getData(array('DeviceGroupID' => $groupid));
				foreach($sqlQry as $rowData){
					$intDeviceID=$rowData['DID'];
					$this->getDeviceInventoryTable()->deleteDeviceInventory("DeviceGroupID IN ($delArrList)");
				}	
			}
			$appObj->ActivityLogVSM(5,"Group $getDel_grpname deleted",2);
		//}
		echo '1'; die;	
	}

	public function pushGroupSettingsAction(){
		$request = $this->getRequest();
        if($request->isXmlHttpRequest()) {
        	$appObj = new ApplicationController();
            $grpId = trim($request->getPost('grpId'));
            $didStr = '';
            $didRow = $this->getDeviceInventoryTable()->getDIDFromGroupId($grpId);
            foreach ($didRow as $key => $did) {
            	$didStr .= $did['DID'].',';
            }
            $didStr = rtrim($didStr,',');
            if($didStr!=''){
            	//push sync for gateways associated with group
				$appObj->executeQueries("UPDATE tbl_sys_report SET wallpaper_status=0,configSettingStatus=0 WHERE did_fk IN ($didStr)");
	            $appObj->executeQueries("UPDATE tbl_advance_sys_report SET advanceConfigStatus=0,Last_Updated_Time=NOW() WHERE did_fk IN ($didStr)");
	            $appObj->executeQueries("UPDATE  tbl_gway_cal_relation SET sync_status=0 WHERE device_id IN ($didStr)");
	            $this->getDeviceInventoryTable()->updateWhere(array('global_sync_status'=>0),array("DID IN ($didStr)"));
            }
            
			$producerObject = new WebProducerController();
            //push wallpaper
			$cmdArr=array("cmd"=>"push_wallpaper","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject->rabbitWebProducerAction($cmdJson);
			
			//push settings
			$cmdArr=array("cmd"=>"push_settings","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject->rabbitWebProducerAction($cmdJson);
			
			//push calendar
			$cmdArr=array("cmd"=>"push_calender","sender"=>"web-vsm");
			$cmdJson=json_encode($cmdArr);
			$producerObject->rabbitWebProducerAction($cmdJson);
            die;
        }
	}
	
	public function getDevicegroupTable() {
		if(!$this->TblDevicegroupTable) {
			$sm = $this->getServiceLocator();
			$this->TblDevicegroupTable = $sm->get('Webapp\Model\TblDevicegroupTable');
		}
		return $this->TblDevicegroupTable;
	}
	
	public function getDeviceInventoryTable() {
		if(!$this->TblDeviceInventoryTable) {
			$sm = $this->getServiceLocator();
			$this->TblDeviceInventoryTable = $sm->get('Webapp\Model\TblDeviceInventoryTable');
		}
		return $this->TblDeviceInventoryTable;
	}
	
	public function getAdvanceConfigurationMappingTable() {
		if(!$this->TblAdvanceConfigurationMappingTable) {
			$sm = $this->getServiceLocator();
			$this->TblAdvanceConfigurationMappingTable = $sm->get('Webapp\Model\TblAdvanceConfigurationMappingTable');
		}
		return $this->TblAdvanceConfigurationMappingTable;
	}
	
	public function getGatewayCustomizeHomepageMappingTable(){
		if(!$this->TblGatewayCustomizeHomepageMappingTable) {
			$sm = $this->getServiceLocator();
			$this->TblGatewayCustomizeHomepageMappingTable = $sm->get('Webapp\Model\TblGatewayCustomizeHomepageMappingTable');
		}
		return $this->TblGatewayCustomizeHomepageMappingTable;
	}
}
