<?php
namespace Webapp\Controller;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Webapp\Form\NetworksettingsForm;
use Webapp\Form\ViaConfigurationForm;
use Zend\Session\Container;
use Zend\Mvc\MvcEvent;
//use Webapp\Model\UserTable;
//use Webapp\Model\adduser;
use Webapp\Form\SourceSwitchForm;
use Webapp\Form\ModeratorModeForm;
use Zend\View\Model\JsonModel;
use Zend\Mvc\Plugin\FlashMessenger;
use Webapp\Controller\ApplicationController;
use Webapp\Controller\ServicesController;

class NetworksettingsController extends AbstractActionController {
	/*****
	 *	@Function Name		: onDispatch
	 *  @description	    : It works as construct. It will be called first.check if user is
	 *                        logged in otherwise redirect to login page
	 *****/
	//checking session
	public function onDispatch(MvcEvent $e) 
	{
		$session = new Container('userinfo');
		$user = $session->offsetGet('LoginName');	
		//check session code
		$appObj = new ApplicationController();
		//getting sessionTimeOut value. bydefault value is 10
		$getSettingObj = $appObj->getComplexPasswordSettings();
		$getSettingData = $getSettingObj->webadmin_session_timeout;
		$getSettingData=($getSettingData>0)?$getSettingData:10;	
		//now getting session time out based on query and compare	
		$qry2="SELECT * FROM tbl_session_check WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."' AND extract(epoch FROM NOW())- datetime < $getSettingData*60";
		$tblSessionCheckdataArr=$appObj->returnQueryData($qry2);		
		if(count($tblSessionCheckdataArr)>0){
			$updSession="UPDATE tbl_session_check SET userid='".$session->offsetGet('LoginName')."', sessionid='".session_id()."', datetime=extract(epoch FROM NOW()) WHERE userid='".$session->offsetGet('LoginName')."' AND sessionid='".session_id()."'";
			$appObj->executeQueries($updSession);
		}else{					
			return $this->redirect()->toRoute('index', array('action' => 'logout'));
		}
		//end check session code		
			
		if(empty($user)) {
			// redirect if not
			return $this->redirect()->toRoute('index',array('action' => 'index'));
		}
		return parent::onDispatch($e);
	}

	public function shownetworkSettingsAction() {

		// check for security SQL injection
		if(isset($_GET['settingFlag']) && !empty($_GET['settingFlag'])){
			if(strstr(strtolower($_GET['settingFlag']),'select') || strstr(strtolower($_GET['settingFlag']),'and') || strstr(strtolower($_GET['settingFlag']),'or')){
				die('Invalid request');
			}
		}
		

		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');
		//echo "<pre>";print_r($sessionNetworkData);
		$error = '';
		$appObj = new ApplicationController();
		$model = $appObj->getModelName();
		// get vsm configure setting
		$vsmConfigValue = $appObj->getTableAllData('tbl_hq_configuration')->current();
		$vsmSettingValue = $vsmConfigValue['hq_configsetting'];

		//getting miracast value from network.json. Now Miracast will be read from json not from file
		$networkJsonData=$appObj->readJsonFile(DEST_PATH.'network.json');
		//getting miracast value from json		
		/*$settingsUrl = DEST_PATH.'via_settings.json';
		$response = file_get_contents($settingsUrl);	
		//decrypt json
		$decryptResponse = $appObj->desDecrypt($response,POLL_ENCRYPTION_KEY);
		$templateSettings = json_decode($decryptResponse);
		$advanceConfig = $templateSettings->VIA_CONFIG_TEMPLATE->via_settings->presentation;		
		$miracastConfigStatus =($advanceConfig->miracast->status == '')? 0 : $advanceConfig->miracast->status;*/

		$miracastConfigStatus = CHECK_FILE_MIRACAST;
		//getting value to allow wifi or miracast
		$wifiMiracastFlag=$appObj->allowMiracastAndWifi(DEST_PATH.'network.json');
		
		

		$deviceInventoryData = $appObj->getTableAllData('DeviceInventory');
		foreach($deviceInventoryData as $deviceInventoryVal) {
			//echo $gwayMacAddr=$deviceInventoryVal['MacAddress'];
			$viaServerIP = $deviceInventoryVal['deviceip'];
		}
		//print_r($deviceInventoryData);
		$gwayMacAddr = $appObj->getMacAddress();
		$networkform = new NetworksettingsForm();
		//form post code
		
		if($this->getRequest()->isPost()) {
			$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
			$postData = $this->getRequest()->getPost()->toArray();
			//echo 'hi';		
			//echo "<pre>";print_r($postData);
			//die;
			$networkOption = $postData['nwSet'];
			$gwayHostname = htmlspecialchars($postData['gwayHostname']);
			$ipval = htmlspecialchars(trim($postData['gwayip']));
			$subnetmask = htmlspecialchars(trim($postData['subnetmask']));
			$defgateway = htmlspecialchars(trim($postData['defgateway']));
			$dns1 = htmlspecialchars(trim($postData['dns1']));
			$activeInterface = $postData['dualNetworkDD'];
			//Update hostname in settings json if hostname updated
			//getting hostname from session
			$get_hostname_from_session=$sessionNetworkData['Lan1_Host'];			
			if($get_hostname_from_session!=$gwayHostname){
				$appObj->upgradeViaActiveJson('hostname',$gwayHostname);
			} 
			//end
			
			
			list($activeInterfaceName, $explodeActiveInterfaceVal)= explode('~', $activeInterface);			
			//for linux	
			if(GET_OS == 'LIN') {
				//linux dhcp case
				if($networkOption == 'dhcp') {
					$linuxSetHostnameCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>HostName</Cmd><P1>$gwayHostname</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$linuxDhcpCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>setDHCP</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					if(PRODUCT_TYPE == 'via') {						
						$appObj->applyNetwotkSettingsLinuxDHCP($logincmd, $linuxSetHostnameCmd, $linuxDhcpCmd);
						header("location:rebootme.php?ip=$ipval&newsetup=dhcp");
						exit;
					}
					if(PRODUCT_TYPE == 'collab8') {						
						$appObj->applyNetwotkSettingsLinuxDHCP($logincmd, $linuxSetHostnameCmd, $linuxDhcpCmd);
						header("location:rebootme.php?ip=$ipval&newsetup=dhcp");
						exit;
					}
				}
				//linux static case
				if($networkOption == 'static') {
					$linuxStaticCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>setStatic</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$IpSetting_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>IpSetting</Cmd><P1>$ipval</P1><P2>$subnetmask</P2><P3>$defgateway</P3><P4>$dns1</P4><P5>$gwayHostname</P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$result = $appObj->applyNetwotkSettingsLinuxStatic($logincmd, $IpSetting_cmd, $linuxStaticCmd, $ipval, $subnetmask, $defgateway, $dns1, $gwayHostname, $explodeActiveInterfaceVal);
					if($result == 1) {
						//$logqry=mysql_query("insert into ActivityLogMaster(UserID,ActionTaken,ActivityDate,remarks,HostName) values('$name','Apply',now(),'$logMsgApplyNetSettings $name','$hostname')") or die('error_ns1');
						header("location:rebootme.php?ip=$ipval&newsetup=0");
						exit;
					}
					if($result === 0) {
						echo "<script language='javascript'>alert('No Connection');</script>";
					}
				}
			} else {
				//for windows
				$tagP7Value = 1;
				$gwayLanMacAddrs=$sessionNetworkData['Lan1_Mac'];				
				if($activeInterfaceName == 'LAN1') {
					$tagP7Value = 1;
					$gwayLanMacAddrs=$sessionNetworkData['Lan1_Mac'];
				}
				if($activeInterfaceName == 'LAN2') {
					$tagP7Value = 2;
					$gwayLanMacAddrs=$sessionNetworkData['Lan2_Mac'];
				}
				//die($gwayLanMacAddrs);
				//windows dhcp case
				if($networkOption == 'dhcp') {
					$windowsSetHostnameCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>HostName</Cmd><P1>$gwayHostname</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$windowsDhcpCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>setDHCP</Cmd><P1>$gwayLanMacAddrs</P1><P2>$tagP7Value</P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					if(PRODUCT_TYPE == 'via') {						
						$appObj->applyNetwotkSettingsLinuxDHCP($logincmd, $windowsSetHostnameCmd, $windowsDhcpCmd);
						header("location:rebootme.php?ip=$ipval&newsetup=dhcp");
						exit;
					}
					if(PRODUCT_TYPE == 'collab8') {
						$appObj->applyNetwotkSettingsLinuxDHCP($logincmd, $windowsSetHostnameCmd, $windowsDhcpCmd);
						header("location:rebootme.php?ip=$ipval&newsetup=dhcp");
						exit;
						
					}
				}
				//windows static case
				if($networkOption == 'static') {
					$linuxStaticCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>setStatic</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
					$IpSetting_cmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>IpSetting</Cmd><P1>$ipval</P1><P2>$subnetmask</P2><P3>$defgateway</P3><P4>$dns1</P4><P5>$gwayHostname</P5><P6>$gwayLanMacAddrs</P6><P7>$tagP7Value</P7><P8></P8><P9></P9><P10></P10></P>";
					$result = $appObj->applyNetwotkSettingsLinuxStatic($logincmd, $IpSetting_cmd, $linuxStaticCmd);
					if($result == 1) {
						//$logqry=mysql_query("insert into ActivityLogMaster(UserID,ActionTaken,ActivityDate,remarks,hostname) values('$name','Apply',now(),'$logMsgApplyNetSettings $name','$hostname')") or die('error_ns1');
						header("location:rebootme.php?ip=$ipval&newsetup=0");
						exit;
					}
					if($result === 0) {
						echo "<script language='javascript'>alert('No Connection');</script>";
					}
				}
			}
			//for windows
		} 
		
		//wifi code		
		//if($sessionNetworkData['check_wifi'] == 1) {
		//$getMode =($sessionNetworkData['mode']== 'client')? 'clientMode' : 'apMode';

		$getMode = '';
		if(strtolower($sessionNetworkData['mode']) == 'client'){
			$getMode = "clientMode";
		}else if(strtolower($sessionNetworkData['mode']) == 'wd'){
			$getMode = "wdMode";
		}else{
			$getMode = "apMode";
		}

		//}
		$getLastNetwork =(file_exists(LIN_WIFI_PATH . 'CMssid.txt'))? 'Last Selected Network SSID:' . $appObj->file_read(LIN_WIFI_PATH . 
																														 'CMssid.txt'): 'Last Selected Network SSID:' . 'None';
		//get active template name
		$getActiveTemplateSql = $appObj->returnQueryData("SELECT template_name FROM tbl_via_settings_templates WHERE status=1");
		foreach($getActiveTemplateSql as $activeTemplateData){						
			$activeTemplateName = strtolower($activeTemplateData['template_name']);
		}
		
		//end wifi code
		return new ViewModel(array('error' => $error, 'form' => $networkform, 'model' => $model, 'viaServerIP' => $viaServerIP, 'getlanMacAddr' => $gwayMacAddr, 'initialResultValues' => $initialResultValues, 'getMode' => $getMode, 'getLastNetwork' => $getLastNetwork,'miracastConfigStatus'=>$miracastConfigStatus,'wifiMiracastFlag'=>$wifiMiracastFlag,'vsmSettingValue'=>$vsmSettingValue,'activeTemplateName'=>$activeTemplateName));
		//$this->layout('layout/login');		
	}
	//Ajax Call for fetching static/dhcp data
	public function showDualnetworkAction() {	
		$appObj = new ApplicationController();
		$deviceInventoryData = $appObj->getTableAllData('DeviceInventory');

		foreach($deviceInventoryData as $deviceInventoryVal) {
			$viaServerIP = $deviceInventoryVal['deviceip'];
		}
		$ddvalue = trim($_POST['ddvalue']);
		$radioBtnOption = $_POST['radioBtnOption'];
		$ddName = trim($_POST['ddName']);
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');
		if(strtolower($ddName)=='lan1'){
			$ipaddr=$sessionNetworkData['Lan1_IP'];
			$subnetmask=$sessionNetworkData['Lan1_Sub'];
			$defgateway=$sessionNetworkData['Lan1_Gatway'];
			$dns1=$sessionNetworkData['Lan1_Dns'];		
			$hostname=$sessionNetworkData['Lan1_Host'];
			$check_dhcpFile=$sessionNetworkData['Lan1_Dhcp'];
		}else if(strtolower($ddName)=='lan2'){
			$ipaddr=$sessionNetworkData['Lan2_IP'];
			$subnetmask=$sessionNetworkData['Lan2_Sub'];
			$defgateway=$sessionNetworkData['Lan2_Gatway'];
			$dns1=$sessionNetworkData['Lan2_Dns'];		
			$hostname=$sessionNetworkData['Lan2_Host'];
			$check_dhcpFile=$sessionNetworkData['Lan2_Dhcp'];	
		}else if(strtolower($ddName)=='wifi'){
			$ipaddr=$sessionNetworkData['wifi1_IP'];
			$subnetmask=$sessionNetworkData['wifi1_Sub'];
			$defgateway=$sessionNetworkData['wifi1_Gatway'];
			$dns1=$sessionNetworkData['wifi1_Dns'];		
			$hostname=$sessionNetworkData['wifi1_Host'];		
		}
		
		$str = "";
		if($radioBtnOption == 'static' || $radioBtnOption == 'dhcp') {
			$readOnlyInput =($viaServerIP != '')? "readonly" : '';
			$disabledInput =($ddName == "Wifi")? "disabled" : '';
			$dhcpDisabled =($check_dhcpFile == 1)? "disabled" : '';
			$str .= '<input type="hidden" name="staticdhcpOpt" id="staticdhcpOpt" value="' . $check_dhcpFile . '" />';
			$str .= '<table cellspacing="0" border="0" width="734px" cellpadding="0">';
			$str .= '<tr>';
			$str .= '<td class="netsettinglabel3" width="250px" style="padding-left:11px">&nbsp;';
			$str .= '<fieldset class="form-group">';
			$str .= '<input name="gwayHostname" type="text" id="gwayHostname" class="form-control styl"  value="' . $hostname . '" ' . $readOnlyInput . ' ' . $disabledInput . '><label for="gwayHostname" class="animate-lbl activeCss">Hostname</label>';
			$str .= '</fieldset>';
			$str .= '</td>';
			$str .= '<td width="200px"><span id="err1" class="redmsg"></span></td>';
			$str .= '</tr>';
			$str .= '<tr>';
			$str .= '<td class="netsettinglabel3" width="250px" style="padding-left:11px">&nbsp;';
			$str .= '<fieldset class="form-group">';
			$str .= '<input name="gwayip" type="text" id="gwayip" class="form-control styl"  value="' . $ipaddr . '" ' . $dhcpDisabled . ' ' . $disabledInput . '><label for="gwayip" class="animate-lbl activeCss">Gateway IP</label>';
			$str .= '</fieldset>';
			$str .= '</td>';
			$str .= '<td width="200px"><span id="err2" class="redmsg"></span></td>';
			$str .= '</tr>';
			$str .= '<tr>';
			$str .= '<td class="netsettinglabel3" width="250px" style="padding-left:11px">&nbsp;';
			$str .= '<fieldset class="form-group">';
			$str .= '<input name="subnetmask" type="text" id="subnetmask" class="form-control styl"  value="' . $subnetmask . '" ' . $dhcpDisabled . ' ' . $disabledInput . '><label for="subnetmask" class="animate-lbl activeCss">subnetmask</label>';
			$str .= '</fieldset>';
			$str .= '</td>';
			$str .= '<td width="200px"><span id="err3" class="redmsg"></span></td>';
			$str .= '</tr>';
			$str .= '<tr>';
			$str .= '<td class="netsettinglabel3" width="250px" style="padding-left:11px">&nbsp;';
			$str .= '<fieldset class="form-group">';
			$str .= '<input name="defgateway" type="text" id="defgateway" class="form-control styl"  value="' . $defgateway . '" ' . $dhcpDisabled . ' ' . $disabledInput . '><label for="defgateway" class="animate-lbl activeCss">Default Gateway</label>';
			$str .= '</fieldset>';
			$str .= '</td>';
			$str .= '<td width="200px"><span id="err4" class="redmsg"></span></td>';
			$str .= '</tr>';
			$str .= '<tr>';
			$str .= '<td class="netsettinglabel3" width="250px" style="padding-left:11px">&nbsp;';
			$str .= '<fieldset class="form-group">';
			$str .= '<input name="dns1" type="text" id="dns1" class="form-control styl"  value="' . $dns1 . '" ' . $dhcpDisabled . ' ' . $disabledInput . '><label for="dns1" class="animate-lbl activeCss">DNS Server</label>';
			$str .= '</fieldset>';
			$str .= '</td>';
			$str .= '<td width="200px"><span id="err5" class="redmsg"></span></td>';
			$str .= '</tr>';
			$str .= '<tr>';
			$str .= '<td colspan=2 align="center"><input type="submit" name="apply" value="Apply" id="apply" class="btn btn-viablue" ' . $disabledInput . '/> </td> ';
			$str .= '</tr>';
			$str .= '</table>';
			echo $str;
		}
		die;
	}
	//Ajax Call for fetching ap mode data 
	public function showWifisettingsapmodeAction() {
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');	
		$appObj = new ApplicationController();		
		//showing changeel based on network.json
		if(file_exists(DEST_PATH.'network.json')){
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			$bandFlag=strtolower($arrayNetworkJson['Band']);//'single';
			$channel2_4_Array=$arrayNetworkJson['Band_Channel_2.4'];			
			if($arrayNetworkJson['Band_Channel_2.4']!='' && $arrayNetworkJson['Band_Channel_5']!=''){
				//$bandFlag='dual';				
				$channel_5_Array=$arrayNetworkJson['Band_Channel_5'];
			}	
						
		}
		/*$read_apmodeSSIDFile='';
		$read_apmodeWifiPassFile='';			
		if(strtolower($sessionNetworkData['mode'])=='ap'){
			$read_apmodeSSIDFile = $sessionNetworkData['SSID'];
			$read_apmodeWifiPassFile = $appObj->file_read(LIN_WIFI_PATH.FILE_AP_KEY);
		}	
		$read_apmodeChannelFile = ($sessionNetworkData['Channel']!='')?$sessionNetworkData['Channel']:1;
		$checkInternetFile =($sessionNetworkData['EnableInternet']==1)?'checked':'';//CHECK_ENABLE_INTERNET;
		$checkStandAloneFile =($sessionNetworkData['Standalone']==1)?'checked':'';//CHECK_APMODE_READ_STANDALONE;*/

		$read_apmodeSSIDFile = file_exists(LIN_WIFI_PATH.FILE_APMODE_SSID) ? $appObj->file_read(LIN_WIFI_PATH.FILE_APMODE_SSID) : '';
		$read_apmodeWifiPassFile = file_exists(LIN_WIFI_PATH.FILE_AP_KEY) ? $appObj->file_read(LIN_WIFI_PATH.FILE_AP_KEY) : '';
		$read_apmodeChannelFile = file_exists(LIN_WIFI_PATH.FILE_APMODE_CHANNEL) ? $appObj->file_read(LIN_WIFI_PATH.FILE_APMODE_CHANNEL):1;
		$checkInternetFile =  CHECK_ENABLE_INTERNET == 1 ? 'checked':'';
		$checkStandAloneFile = CHECK_APMODE_READ_STANDALONE == 1 ? 'checked':'';

		$checkGuestMode =($sessionNetworkData['Guestmode']==1)?'checked':'';//CHECK_APMODE_GUESTMODE;
		$modelValue =$appObj->getModelNameByParam('modelvalue');
		$checkIPIsolationFile =(file_exists(LIN_WIFI_PATH . 'apisolate.txt'))?'checked':'';
			
		//check wifiquickconnect.txt file exit or not
		$check_viaapmode = $appObj->checkQuickWifiConnectStatus();

		//return actual SSID name
		if(substr($read_apmodeSSIDFile, 0, 4) == "VIA_"){
			$strSSID = preg_replace('/VIA_/', '', $read_apmodeSSIDFile, 1); //replace the sirdt match only
			$strSSIDArr = explode("..", $strSSID);
			$read_apmodeSSIDFile = isset($strSSIDArr[0]) && !empty($strSSIDArr[0]) ? $strSSIDArr[0] : $strSSID;
		}

		$ddbox = '<option '.$defsel.' value="">Select</option>';
		if($read_apmodeChannelFile>11){
			for($m = 0;	$m <=count($channel_5_Array);$m ++ ) {
				$sel1 = '';
				//if($k == $read_apmodeChannelFile)
				if($channel_5_Array[$m] == $read_apmodeChannelFile)
					$sel1 = 'selected';
				if($channel_5_Array[$m]!=''){	
				$ddbox .= '<option ' . $sel1 . ' value=' . $channel_5_Array[$m] . '>' . $channel_5_Array[$m] . '</option>';
				}
			}		
		
		}else{
			for($k = 0;	$k <=count($channel2_4_Array);$k ++ ) {
				$sel1 = '';
				//if($k == $read_apmodeChannelFile)
				if($channel2_4_Array[$k] == $read_apmodeChannelFile)
					$sel1 = 'selected';
				if($channel2_4_Array[$k]!=''){	
				$ddbox .= '<option ' . $sel1 . ' value=' . $channel2_4_Array[$k] . '>' . $channel2_4_Array[$k] . '</option>';
				}
			}		
		}

		
		$str = '';
		$str .= '<form name="apModeFrm" id="apModeFrm" method="post">';
		$str .= '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="padding-left:28px";>';
		
		$str .= '<tr height="30px">';
		$str .= '<td width="100%" align="left" colspan=2><table width="100%"><tr height="60px"><td width="100%" colspan="2" class="m-l-md"><div style="width:400px" class="d-flex"><span style="padding-left:0px"><input type="radio" '.($check_viaapmode == 0 ? "checked" : "").' name="wifiQuickConnectType" id="legacy" value="0" class="radio3"><label for="legacy" class="d-flex-g-10"><span class="text-dark pointer">'.LEGACY_MODE.'</span></label></span><span style="padding-left:30px"><input type="radio" '.($check_viaapmode == 1 ? "checked" : "").' name="wifiQuickConnectType" id="wifiQuick" value="1" class="radio3"><label for="wifiQuick" class="d-flex-g-10"><span class="text-dark pointer">'.WIFI_QUICK_CONNECT.'</span></label></span></div></td></tr></tr><tr class="ssidNameTr"> <td width="13%" '.($check_viaapmode == 0 ? "style='display:none'" : "").'><fieldset class="form-group m-t m-b-lg"><input type="text" name="vialebel" id="vialebel" value="VIA__" class="form-control styl" disabled="disabled"/><label for="vialebel" class="animate-lbl activeCss"></label></fieldset></td> &nbsp;&nbsp;<td '.($check_viaapmode == 0 ? "width='100%' style='padding-left:0px;'" : "width='87%' style='padding-left:5px;'").' style="padding-left:5px;"><fieldset class="form-group m-t m-b-lg"><input type="text" name="apModeSSID" id="apModeSSID" value="' . $read_apmodeSSIDFile . '"" class="form-control styl" '.($check_viaapmode == 1 ? "maxlength='10'" : "maxlength='20'").' /><label for="apModeSSID" class="animate-lbl activeCss">' . STR_SSID . '*</label></fieldset></td></tr></table></td>';
		$str .= '</tr>';
		$str .= '<tr height="20px">';
		$str .= '<td width="100%" colspan=2>';
		//$str .= '<div>';
		//$str .= '<fieldset class="form-group"><input type="password" name="apModePass" id="apModePass" value="' . $read_apmodeWifiPassFile . '" class="roundbox" style="width:350px"/><label for="apModeSSID" class="animate-lbl">' . STR_PASWORD . '</label></fieldset>';	
		//$str .= '<div id="showPasswordToggleApMode" style="margin-top:2px; padding-left:50px"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div>';	
		$str .= ' <div class="form-group m-b-md"><div class="input-group" style="width:100%;"><fieldset class="form-group m-b-none"><input type="password" name="apModePass" id="apModePass" value="' . $read_apmodeWifiPassFile . '" class="form-control styl" '.($check_viaapmode == 1 ? "maxlength='8'" : "maxlength='50'").'/><label for="apModePass" class="animate-lbl activeCss">' . STR_PASWORD . '*</label></fieldset><div id="showPasswordToggleApMode" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div></div>';
		//$str .= '</div>';
		
		$str .= '</td>';
		$str .= '</tr>';
		$str .= '<tr height="20px"><td width="100%" colspan=2><div style="font-size: 12px">'.($check_viaapmode == 1 ? "<span class='ssidnote' style='font-style: italic;'><span>".MSG_SSID_4_10_LONG.". ".MSG_PASS_8_CHARACTER_LONG.".</span></span>" : "<span class='ssidnote' style='font-style: italic;'><span>".MSG_SSID_4_20_LONG.". ".LEGACY_PASS_TEXT.".</span></span>").'</p></div></td></tr>';
		if(GET_OS == 'LIN') {
			if($bandFlag=='dual'){
				$channel24Checked='';
				$channel5Checked='';	
				if($read_apmodeChannelFile>11){
					$channel5Checked='checked';
				}else{
					$channel24Checked='checked';
				}		
				$str.='<tr height="60px"><td width="100%" colspan=2 class="m-l-md">	
				<div class="d-flex">
					<span style="padding-left:0px">
					<input type="radio" name="channels" id="channels_2_4" value="24" class="radio3 bandRadioCss" '.$channel24Checked.'>
					<label for="channels_2_4" class="d-flex-g-10"><span class="text-dark">2.4 GHz Channels</span></label>
					</span>
					<span style="padding-left:30px">
					<input type="radio" name="channels" id="channels_5" value="5" class="radio3 bandRadioCss" '.$channel5Checked.'>
					<label for="channels_5" class="d-flex-g-10"><span class="text-dark">5 GHz Channels</span></label>
					</span>		
				</div>	
				
				</td></tr>';	  
			}		
		
		
		
			$str .= '<tr height="30px">';
			$str .= '<td width="100%" colspan=2>';
			/*$str .= '<div style="float:left;" class="selectdiv"><label for="apModeChannelList" class="ddlabelCss">' . STR_CHANNELS . '</label><select name="apModeChannelList" id="apModeChannelList" class="roundbox form-control m-b styl">';
			$str .= $ddbox;
			$str .= '</select></div>';
			*/
$str .= '<div class="selectdiv" id="bandboxDiv"> <select name="apModeChannelList" id="apModeChannelList" class="form-control m-b styl">'.$ddbox.'</select><label class="ddlabelCss">' . STR_CHANNELS . '</label></div>	';	
			
			if($modelValue == 11 || $modelValue == 12 || $modelValue == 14 || $modelValue == 15){
			$str .= '<tr>';			
			$str .= '<td width="100%" colspan="2"><div class="row m-b-xs" style="width:400px"><input type="checkbox" name="IPIsolation" id="IPIsolation" ' . $checkIPIsolationFile . ' class="toggleClass"/><label for="IPIsolation"><span></span></label><span>' . IP_ISOLATION . '</span></div></td>';
			$str .= '</tr>';	
			}
			
			if(trim($arrayNetworkJson['Internet'])==1){
			$str .= '</tr>';
			$str .= '<tr height="">';			
			$str .= '<td width="50%"><div class="row m-b-xs" style="width:400px"><input type="checkbox" name="enableInternet" id="enableInternet" ' . $checkInternetFile . ' class="toggleClass"/><label for="enableInternet"><span></span></label><span>' . STR_ENABLE_INSERNET . '</span>&nbsp;<span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="' . TOOLTIP_ENABLE_INSERNET . '" style="font-size:14px; font-weight:bold; cursor:pointer;"><img src="' . PUBLIC_URL. '/img/via/comment.svg" class="commentInputCss"></span></div></td>';
			$str .= '</tr>';
			}
			
			if(trim($arrayNetworkJson['Standalone'])==1){
			$str .= '<tr>';
			$str .= '<td width="100%" colspan="2"><div class="row m-b-xs" style="width:400px"><input type="checkbox" name="standAloneWifi" id="standAloneWifi" ' . $checkStandAloneFile . ' class="toggleClass"/><label for="standAloneWifi"><span></span></label><span>' . STR_ACTIVATE_STANDALONE_WIFI . '</span>&nbsp;<span  data-toggle="tooltip" data-placement="bottom" title="" data-original-title="' . TOOLTIP_STAND_ALONE . '" style="font-size:14px; font-weight:bold; cursor:pointer;"><img src="' . PUBLIC_URL. '/img/via/comment.svg" class="commentInputCss"></span></div></td>';			
			$str .= '</tr>';
			}
			
			/*if(trim($arrayNetworkJson['Guestmode'])==1){
			$str .= '<tr>';
			$str .= '<td width="100%" colspan="2"><div class="row"><input type="checkbox" name="enableGuestMode" id="enableGuestMode" ' . $checkGuestMode . ' class="toggleClass"/><label for="enableGuestMode"><span></span></label><span>' . STR_ENABLE_GUEST_MODE . '</span>&nbsp;(<span  data-toggle="tooltip" data-placement="bottom" title="" data-original-title="' . STR_ENABLE_GUEST_MODE_HELP_TEXT . '" style="font-size:14px; font-weight:bold; cursor:pointer; color:#000000">&nbsp;?&nbsp;</span>)</div>';
			$str .= '</td>';
			$str .= '</tr>';
			}*/
		}
		$str .= '<tr height="40px">';
		$str .= '<td width="100%" align="left" colspan=2><div><button type="button" name="apModeApply" id="apModeApply" class="btn btn-viablue makeDisabled pull-right">' . APPLY_BTN . '</button></div></td>';
		$str .= '</tr>';
		$str .= '</table>';
		$str .= '</form>';
		echo $str;
		die();
	}
	//Ajax Call for apply ap mode data
	public function applyWifisettingapmodeAction() {
		$appObj = new ApplicationController();
		$serviceObj = new ServicesController();	
		$ssid = htmlspecialchars(trim($_POST['ssid']));
		$ssidUpdate = (trim($_POST['ssidUpdate'])=='no')?'0':'1';
		$getwifiQuick = trim($_POST['getwifiQuick']);
		//allow password as blank.	
		$security =(trim(base64_decode($_POST['security']))!= 'w0wb1a')? trim($_POST['security']): '';
		$channel = trim($_POST['channel']);
		$enableInternet = trim($_POST['enableInternet']);
		$standAlonevalue = trim($_POST['standAlonevalue']);
		$getGuestModeChkBoxVal = trim($_POST['getGuestModeChkBoxVal']);
		$IPIsolationvalue = trim($_POST['IPIsolationvalue']);
		if($standAlonevalue == 0) {
			unlink(LIN_WIFI_PATH . 
				   FILE_APMODE_READ_STANDALONE);
		} else {
			$fileName = LIN_WIFI_PATH . FILE_APMODE_READ_STANDALONE;
			$myfile = fopen($fileName, 'w')or die("can't open file");
			$confWrite = fwrite($myfile, $standAlonevalue);
			fclose($myfile);
		}
		if($IPIsolationvalue == 0){
			unlink(LIN_WIFI_PATH . 'apisolate.txt');
		}else{
			$fileName = LIN_WIFI_PATH . 'apisolate.txt';
			$myfile = fopen($fileName, 'w')or die("can't open file");
			//$confWrite = fwrite($myfile, $IPIsolationvalue);
			fclose($myfile);
		}
		
		//Create wifi file - Added by niraj 7 july,2024
		$this->createWifiFile();

		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$appModeApplyMode = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetSSID</Cmd><P1>$ssid</P1><P2>$security</P2><P3>$channel</P3><P4>$enableInternet</P4><P5>$getGuestModeChkBoxVal</P5><P6>$getwifiQuick</P6><P7>$ssidUpdate</P7><P8></P8><P9></P9><P10></P10></P>";
		echo $return = trim($appObj->showNetworkInfo($logincmd, $appModeApplyMode));
		die;
	}
	
	//Ajax Call for fetching client mode data
	public function showWifisettingscmodeAction() {
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');	
		$appObj = new ApplicationController();
		//showing changeel based on network.json
		if(file_exists(DEST_PATH.'network.json')){
			//getting data from network.json	
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			$showHiddenNetwork=$arrayNetworkJson['Hidden'];			
			$showDualNetworkLin=$arrayNetworkJson['DualNetworkWifi'];
			$showDualNetworkWin=$arrayNetworkJson['DualNetworkLAN'];						
		}		
	
		
		$chkDualNw =(trim(CHECK_DUAL_NETWORK) == 1)? 'checked' : 0;
		// added by ashu on 23Jan17
		setcookie('current_network', $sessionNetworkData['SSID'], time()+(86400 * 30), "/");
		//Added by ashu on 24jan2017. for showing networj message
		//$shownetworkMsg ='Last Selected Network SSID: ' . $sessionNetworkData['SSID'];		
		$shownetworkMsg=($sessionNetworkData['SSID']!='')?'Last Selected Network SSID: ' . $sessionNetworkData['SSID']:'No Network is Selected';
		//$networkMsg =(strstr($currentNwInfo, 'Error'))? 'No Network is Selected' : $shownetworkMsg;
		$cmodeStr = '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="padding-left:28px">';
		//$cmodeStr .= '<tr height="20px"><td class="style14" colspan="2"><div id="networkMsgSpan" style="color:#c40f39">' . $networkMsg . '</div></td></tr>';
		$cmodeStr .= '<tr height="20px"><td class="style14" style="padding-left:20px;" colspan="2"><div id="searchNw" style="display:block;"></div></td></tr>';
		$cmodeStr .= '<tr height="200px"><td valign="top" width="100%" align="left">';
		// added for hidden network
		if(CHECK_HIDDEN_NETWORK == 1 &&  $sessionNetworkData['mode']== 'client') {
			$cmodeHiddenNetworkDiv1Block = 'none';
			$cmodeInfoDivStatus = 'none';
			$cmodeHiddenNetworkDiv2Block = 'block';
			$showHiddenSSID=($sessionNetworkData['SSID']!='')?$sessionNetworkData['SSID']:'';
		} else {
			$cmodeHiddenNetworkDiv1Block = 'block';
			$cmodeInfoDivStatus = 'block';
			$cmodeHiddenNetworkDiv2Block = 'none';
		}
		$checkHiddenNw =(trim(CHECK_HIDDEN_NETWORK) == 1)? 'checked' : '';
		$cmodeStr .= '<div id="cmodeHiddenNetworkDiv1" style="display:' . $cmodeHiddenNetworkDiv1Block . '">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
		if($sessionNetworkData['mode']== 'client'){
			$cmodeStr .= '<tr height="40px"><td width="100%"><div id="networkMsgSpan" class="text-danger" style="margin-top:10px;">' . $shownetworkMsg . '</div></td></tr>';
		}
		$cmodeStr .= '<tr height="40px"><td width="100%"><span id="refreshList" class="pointer"><i class="fa fa-refresh" style="font-size:16px;"></i>&nbsp;&nbsp;'.STR_WIFI_SCAN.'</span></td></tr>';
		/*if($showHiddenNetwork==1){
		$cmodeStr .= '<tr>';
		$cmodeStr .= '<td width="100%"><span id="hiddennetworkSpan"><input type="checkbox" name="hiddennetworkChkbox" id="hiddennetworkChkbox" ' . $checkHiddenNw . ' class="hidenChkBox"/><label for="hiddennetworkChkbox" class="style14 m-r-sm m-l-n pointer" ><span></span>' . STR_HIDDEN_NETWORK . '</label> </span>  </td>';
		$cmodeStr .= '</tr>';
		}
		
		if(GET_OS == 'LIN') {
			if($showDualNetworkLin==1){
			$cmodeStr .= '<tr height="40px">';
			$cmodeStr .= '<td width="100%"><input type="checkbox" name="enableDualNetworkChkboxLinux" id="enableDualNetworkChkboxLinux" value="' . CHECK_DUAL_NETWORK . '" ' . $chkDualNw . '/><label for="enableDualNetworkChkboxLinux" class="style14 m-l-n"><span></span></label>'.STR_ENABLE_DUAL_NETWORK.'</td>';
			$cmodeStr .= '</tr>';
			}
		}*/
		$cmodeStr .= '<tr height="40px">';
		$cmodeStr .= '<td align="left" width="100%" colspan=2>';
		//$cmodeStr .= '<div class="form-group m-b-xs m-t"><button type="button" name="applyNetworkSettings" id="applyNetworkSettings" class="btn btn-viablue pull-right makeDisabled">' . APPLY_BTN . '</button></div></td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		//end first part
		$cmodeStr .= '<div id="cmodeHiddenNetworkDiv2" style="display:' . $cmodeHiddenNetworkDiv2Block . '">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
		$cmodeStr .= '<tr height="30px">';
		//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_NETWORK.'</td>';
		$cmodeStr .= '<td width="100%" colspan=2>';
		$cmodeStr .= '<div><fieldset class="form-group"><input type="text"  name="hiddenNetworkName" id="hiddenNetworkName" value="'.$showHiddenSSID.'" class="form-control styl"><label for="hiddenNetworkName" class="animate-lbl activeCss">' . STR_NETWORK . '</label></fieldset>	</div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '<tr height="30px">';
		$cmodeStr .= '<td width="100%" colspan=2><span id="hiddennetworkSpan"><input  class="hidenChkBox" type="checkbox" name="hiddennetworkChkbox" id="hiddennetworkChkbox" ' . $checkHiddenNw . ' /><label for="hiddennetworkChkbox" class="style14 m-l-n"><span></span>' . STR_HIDDEN_NETWORK . '</label> </span></td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '<tr height="60px" id="showUnameField"><td width="100%" colspan=2><fieldset class="form-group m-b-lg m-t"><input type="text"  name="hiddenUname" id="uname" value="" class="form-control styl" placeholder="Optional"><label for="hiddenUname" class="animate-lbl activeCss">' . STR_USERMAME . '</label></fieldset></td></tr>';
		
		$cmodeStr .= '<tr height="40px" id="showPasswordField"><td width="100%" colspan=2><div><div class="form-group m-b-md m-t-sm"><div class="input-group" style="width:100%;"><fieldset class="form-group m-b-none"><input type="password"  name="hiddenPassword" id="hiddenPassword" value="" class="form-control styl"> <label for="hiddenPassword" class="animate-lbl activeCss">' . STR_PASSWORD . '</label></fieldset><div id="hiddennnetworkToggle" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div></div></div>&nbsp;&nbsp;</td></tr>';
		if(GET_OS == 'LIN') {
			$cmodeStr .= '<tr height="80px"><td width="100%" class="style14" colspan="2"><input type="checkbox" name="enableDualNetworkHiddenBoxLinux" id="enableDualNetworkHiddenBoxLinux" value="' . CHECK_DUAL_NETWORK . '"  ' . $chkDualNw . '/><label for="enableDualNetworkHiddenBoxLinux" class="style14 m-r-sm m-l-n"><span></span></label>&nbsp;' . STR_ENABLE_DUAL_NETWORK . '</td></tr>';
		}
		$cmodeStr .= '<tr><td>&nbsp;</td></tr>';
		$cmodeStr .= '<tr height="40px"><td align="left" width="300px" colspan=2><div class="form-group m-b-xs"><button type="button" name="applyHiddenNetworkSettings" id="applyHiddenNetworkSettings" class="btn btn-viablue pull-right">' . APPLY_BTN . '</button></div> </td></tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '<div style="padding-left:28px;"><div style="display:' . $cmodeInfoDivStatus . '" class="sepraterDiv"></div></div>';
		$cmodeStr .= '<div style="width:100%; display:' . $cmodeInfoDivStatus . ';" id="cmodeInfoDiv">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" height="80px" width="100%" id="showNetworkInfoTbl" style="padding-left:28px">';
		if(is_array($explodeCurrentNetworkInfo) && count($explodeCurrentNetworkInfo)> 0) {
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14" colspan="2"><strong>Network Info</strong></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14"><span>SSID</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[0] . '</span></td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14"><span>Channel</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[1] . '</span></td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14">Signal</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[3] . '</td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14">Security</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[4] . '</td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
		}
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		echo $cmodeStr;
		die();
	}	
	
	
	//Ajax Call for fetching client mode data
	public function showWifisettingscmoderefreshAction() {
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');		
		$appObj = new ApplicationController();
		//showing changeel based on network.json
		if(file_exists(DEST_PATH.'network.json')){
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			$showHiddenNetwork=$arrayNetworkJson['Hidden'];			
			$showDualNetworkLin=$arrayNetworkJson['DualNetworkWifi'];
			$showDualNetworkWin=$arrayNetworkJson['DualNetworkLAN'];						
		}		
			
		
		//$chkDualNw =($check_dualNetworkFile == 1)? 'checked' : 0;
		$chkDualNw =(trim(CHECK_DUAL_NETWORK) == 1)? 'checked' : 0;
		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$getListCmd = '<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetNetworkList</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>';
		$currentNwCmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>CurrentWLAN</Cmd><P1>Get</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		// get Current network info
		$currentNwInfo = $appObj->showNetworkInfo($logincmd, $currentNwCmd);
		$checkCurentNetwork = '';
		if(!strstr($currentNwInfo, 'Error')) {
			$currentNwInfoArr = explode('|', $currentNwInfo);
			$checkCurentNetwork = trim($currentNwInfoArr[2]);
		}
		// added by ashu on 23Jan17
		setcookie('current_network', $currentNwInfo, time()+(86400 * 30), "/");
		// 86400 = 1 day	
		// get network listing
		$cmdOutput = $appObj->showNetworkInfo($logincmd, $getListCmd);
		// added by ashu on 23Jan17
		// setcookie('current_network_list', $cmdOutput, time()+(86400 * 30), "/");

		/* code added by niraj to store data in file instead of cokie ## 06/02/2023 */
		if (!empty($session->offsetGet('LoginName'))) {
			$networkListFilePath = BASE_PATH . "/public/uploads/networklist_" . $session->offsetGet('LoginName') . ".txt";
			file_put_contents($networkListFilePath, $cmdOutput);
		}
		/* end code added by niraj to store data in file instead of cokie ## 06/02/2023 */

		// 86400 = 1 day	
		$netwirkInfoArr = explode('|', $cmdOutput);
		$networkArrList = array();
		$currentNwBasicInfoStr = '';
		$strtest = '';
		
		//now getting json as a response from GetNetworkList command
		$returnResultArray = json_decode($cmdOutput);	
		foreach($returnResultArray->WifiList as $returnKey=>$returnVal){
			$networkArrList[$returnKey]=trim($returnVal->SSID);			
		}
		//getting network details
		foreach($networkArrList as $getNetworkKey=>$getNetwrokValue){
			if($getNetwrokValue==$checkCurentNetwork){
				$currentNwBasicInfoStr.=$returnResultArray->WifiList[$getNetworkKey]->SSID.'#'.$returnResultArray->WifiList[$getNetworkKey]->ChannelCount."#".$returnResultArray->WifiList[$getNetworkKey]->Rate.'#'.$returnResultArray->WifiList[$getNetworkKey]->SignalStrength."#".$returnResultArray->WifiList[$getNetworkKey]->SecurityType;
			}
		}
			
		
		
		
		/*for($i = 0;
		$i < count ($netwirkInfoArr );
		$i ++ ) {
			if($i != 0) {
				$explodeNetwork = explode('#', $netwirkInfoArr[$i]);
				//$networkArrList[] = $explodeNetwork[0];
				$strtest .= $explodeNetwork[0] . ',';
				// Matched with current network and get details of that network
				if(in_array($checkCurentNetwork, $explodeNetwork)) {
					$currentNwBasicInfoStr = $netwirkInfoArr[$i];
					//$currentNwBasicInfoArr[]='';
				}
			}
		}*/
		
		
		/*if($currentNwBasicInfoStr == '') {
			$currentNwBasicInfoStr = $netwirkInfoArr[1];
		}*/
		$explodeCurrentNetworkInfo = explode('#', $currentNwBasicInfoStr);
		//Added by ashu on 24jan2017. for showing networj message
		$shownetworkMsg =(in_array($checkCurentNetwork, $networkArrList))? 'Current SSID: ' . $checkCurentNetwork : 'Last Selected Network SSID: ' . $checkCurentNetwork;
		$networkMsg =(strstr($currentNwInfo, 'Error'))? 'No Network is Selected' : $shownetworkMsg;
		$cmodeStr = '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="padding-left:28px">';
		//$cmodeStr .= '<tr height="30px">&nbsp;';		
		//$cmodeStr .= '</tr>';
		$cmodeStr .= '<tr height="20px"><td class="style14" colspan="2"><div id="networkMsgSpan" class="text-danger" style="margin-top:10px;"> ' . $networkMsg . '</div></td></tr>';
		$cmodeStr .= '<tr height="20px"><td class="style14" style="padding-left:20px;" colspan="2"><div id="searchNw" style="display:block;"></div></td></tr>';
		$cmodeStr .= '<tr height="200px"><td valign="top" width="100%" align="left">';
		// added for hidden network
		//remove hidden checkbox functionality when user unchecked .fixed bug id 0011917. unchecking it 
		/*if(CHECK_HIDDEN_NETWORK == 1) {
			$cmodeHiddenNetworkDiv1Block = 'none';
			$cmodeInfoDivStatus = 'none';
			$cmodeHiddenNetworkDiv2Block = 'block';
			$showHiddenSSID=($sessionNetworkData['SSID']!='')?$sessionNetworkData['SSID']:'';
		} else {
		*/
			$cmodeHiddenNetworkDiv1Block = 'block';
			$cmodeInfoDivStatus = 'block';
			$cmodeHiddenNetworkDiv2Block = 'none';
		//}
		//echo  $cmodeHiddenNetworkDiv1Block.' and '.$cmodeInfoDivStatus.' and '.$cmodeHiddenNetworkDiv2Block;
		//added on 2May2019 for making array values unique.
		$networkArrList = array_unique($networkArrList);
		$networkListDD = '<option value="">Select</option>';
		$checkCurentNetwork='';
		if($sessionNetworkData['mode']== 'client'){
			$checkCurentNetwork=$sessionNetworkData['SSID'];	
		}
		foreach($networkArrList as $val) {
			$sel = '';
			if($val == $checkCurentNetwork)
				$sel = 'selected';
			$networkListDD .= '<option value="'. $val.'"  ' . $sel . '>' . $val . '</option>';
		}
		//fixed bug id 0011917. unchecking it 
		$checkHiddenNw ='';//(CHECK_HIDDEN_NETWORK == 1)? 'checked' : '';
		$cmodeStr .= '<div id="cmodeHiddenNetworkDiv1" style="display:' . $cmodeHiddenNetworkDiv1Block . '">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
		$cmodeStr .= '<tr>';
		$cmodeStr .= '<td width="100%" id="showNetworkList">';
		$cmodeStr .= '<div class="selectdiv"> <select name="networkList" id="networkList" class="form-control m-b styl">' . $networkListDD . '</select><label class="ddlabelCss">' . STR_AVAIL_NETWORK . '</label></div>';
		//$cmodeStr.='<div style="margin-top:2px; padding-left:60px"><span id="refreshList">&nbsp;&nbsp;<img src="'.PUBLIC_URL.'/img/refresh.png" class="pointer"/></span></div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '<tr height="20px">';
		$cmodeStr .= '<td width="100%"><span id="refreshList" class="pointer"><i class="fa fa-refresh" style="font-size:16px;"></i>&nbsp;&nbsp;'.STR_WIFI_SCAN.'</span></td>';
		$cmodeStr .= '</tr>';
		
		if($showHiddenNetwork==1){
		$cmodeStr .= '<tr height="40px">';
		$cmodeStr .= '<td width="100%"><span id="hiddennetworkSpan"><input type="checkbox" name="hiddennetworkChkbox" id="hiddennetworkChkbox" ' . $checkHiddenNw . ' class="hidenChkBox"/><label for="hiddennetworkChkbox" class="style14 m-r-sm m-l-n pointer" ><span></span>' . STR_HIDDEN_NETWORK . '</label> </span>  </td>';
		$cmodeStr .= '</tr>';
		}
		if($explodeCurrentNetworkInfo[4] != '') {
			if(strstr($explodeCurrentNetworkInfo[4], '802.1X')) {
				$cmodeStr .= '<tr height="40px">';
				$cmodeStr .= '<td width="100%"><span id="checkbox_8021x_Span"><input type="checkbox" name="checkbox_8021x" id="checkbox_8021x" class="checkbox_8021x_css"/><label for="checkbox_8021x" class="style14 m-r-sm m-l-n pointer" ><span></span>'.NETWRK_802_1x_Txt.'</label> </span>  </td>';
				$cmodeStr .= '</tr>';
			
				$cmodeStr .= '<tr height="60px" id="showUnameField">';				
				$cmodeStr .= '<td width="100%" colspan=2><fieldset class="form-group"><input type="text"  name="uname" id="uname" value="" class="form-control styl" style="width:350px" maxlength="50"><label for="uname" class="animate-lbl activeCss 8021x_identity">' . STR_USERMAME . '</label></fieldset></td>';
				$cmodeStr .= '</tr>';
			}
			
			//added on 24Feb2021 for 802.1x implementation
			$cmodeStr .= '<form method="POST" name="upload8021xFrm" action="upload8021xCertificate" enctype="multipart/form-data" id="upload8021xFrm"><tr height="50px" id="showAuthorityFileField" style="display:none">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2><div class="row hide_802_settings_css"><div class="col-md-6"><label class="custom-upload"><input type="file" name="authorityFile" id="authorityFile" class="pointer" multiple="multiple" accept=".pem">'.NETWRK_802_1x_USR_CERT_FILE2.'</div><div class="col-md-6"> <span class="text-dark align-middle" id="showAuthorityFileName"></span> </div></div></td>';
			$cmodeStr .= '</tr>';
			
			$cmodeStr .= '<tr height="70px" id="showPasswordField">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_PASSWORD.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2>';
			//$cmodeStr .= '<div style="float:left;">';
			$cmodeStr .= '<div class="form-group m-b-xs"><div class="input-group" style="width:100%;"><fieldset class="form-group" style="margin-bottom: 0px;"><input type="password"  name="networkPassword" id="networkPassword" value="" class="form-control styl" maxlength="50"><label for="networkPassword" class="animate-lbl activeCss 8021x_pass">' . STR_PASSWORD . '</label></fieldset><div id="showPasswordToggle" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div>';
			//$cmodeStr .= '</div>&nbsp;&nbsp;<div id="showPasswordToggle" style="margin-top:-15px; padding-left:30px"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div>';
			
			$cmodeStr .= '</td>';
			$cmodeStr .= '</tr>';
		
			$cmodeStr .= '<tr height="50px" id="showUserCertificateField" style="display:none">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2><div class="row hide_802_settings_css"><div class="col-md-6"><label class="custom-upload"><input type="file" name="userCertificateFile" id="userCertificateFile" class="pointer" multiple="multiple" accept=".pem">'.NETWRK_802_1x_USR_CERT_FILE1.'</div><div class="col-md-6"> <span class="text-dark align-middle" id="showUserCertificateFileName"></span> </div></div></td>';
			$cmodeStr .= '</tr>';
		
			$cmodeStr .= '<tr height="50px" id="showClientKeyFileField" style="display:none">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2><div class="row hide_802_settings_css"><div class="col-md-6"><label class="custom-upload"><input type="file" name="clientKeyFile" id="clientKeyFile" class="pointer" multiple="multiple" accept=".key">'.NETWRK_802_1x_USR_CERT_FILE3.'</div><div class="col-md-6"> <span class="text-dark align-middle" id="showClientKeyFileName"></span> </div></div></td>';
			$cmodeStr .= '</tr></form>';
			
		}
		if(GET_OS == 'LIN') {
			if($showDualNetworkLin==1){
			$cmodeStr .= '<tr height="40px">';
			$cmodeStr .= '<td width="100%" class="style14" colspan="2"><input type="checkbox" name="enableDualNetworkChkboxLinux" id="enableDualNetworkChkboxLinux" value="' . CHECK_DUAL_NETWORK . '" ' . $chkDualNw . '/><label for="enableDualNetworkChkboxLinux" class="style14 m-l-n"><span></span></label>' . STR_ENABLE_DUAL_NETWORK . '</td>';
			$cmodeStr .= '</tr>';
			}
		}
		$cmodeStr .= '<tr height="40px">';
		$cmodeStr .= '<td align="left" width="100%" colspan=2 class="net-bt-15">';
		$cmodeStr .= '<div class="form-group m-b-xs m-t"><button type="button" name="applyNetworkSettings" id="applyNetworkSettings" class="btn btn-viablue pull-right makeDisabled">' . APPLY_BTN . '</button></div></td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		//end first part
		$cmodeStr .= '<div id="cmodeHiddenNetworkDiv2" style="display:' . $cmodeHiddenNetworkDiv2Block . '">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
		$cmodeStr .= '<tr height="30px">';
		//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_NETWORK.'</td>';
		$cmodeStr .= '<td width="100%" colspan=2>';
		$cmodeStr .= '<div><fieldset class="form-group"><input type="text"  name="hiddenNetworkName" id="hiddenNetworkName" value="" class="form-control styl"><label for="hiddenNetworkName" class="animate-lbl activeCss">' . STR_NETWORK . '</label></fieldset>	</div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '<tr height="30px">';
		$cmodeStr .= '<td width="100%" colspan=2><span id="hiddennetworkSpan"><input  class="hidenChkBox" type="checkbox" name="hiddennetworkChkbox" id="hiddennetworkChkbox" ' . $checkHiddenNw . ' /><label for="hiddennetworkChkbox" class="style14 m-l-n"><span></span>' . STR_HIDDEN_NETWORK . '</label> </span></td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '<tr height="60px" id="showUnameField"><td width="100%" colspan=2><fieldset class="form-group m-b-lg m-t"><input type="text"  name="hiddenUname" id="uname" value="" class="form-control styl" placeholder="Optional" maxlength="50"><label for="hiddenUname" class="animate-lbl activeCss">' . STR_USERMAME . '</label></fieldset></td></tr>';
		
		$cmodeStr .= '<tr height="40px" id="showPasswordField"><td width="100%" colspan=2><div><div class="form-group m-b-md m-t-sm"><div class="input-group" style="width:100%;"><fieldset class="form-group m-b-none"><input type="password"  name="hiddenPassword" id="hiddenPassword" value="" class="form-control styl" maxlength="50"> <label for="hiddenPassword" class="animate-lbl activeCss">' . STR_PASSWORD . '</label></fieldset><div id="hiddennnetworkToggle" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div></div></div>&nbsp;&nbsp;</td></tr>';
		if(GET_OS == 'LIN') {
			$cmodeStr .= '<tr height="80px"><td width="100%" class="style14" colspan="2"><input type="checkbox" name="enableDualNetworkHiddenBoxLinux" id="enableDualNetworkHiddenBoxLinux" value="' . CHECK_DUAL_NETWORK . '"  ' . $chkDualNw . '/><label for="enableDualNetworkHiddenBoxLinux" class="style14 m-r-sm m-l-n"><span></span></label>&nbsp;' . STR_ENABLE_DUAL_NETWORK . '</td></tr>';
		}
		$cmodeStr .= '<tr><td>&nbsp;</td></tr>';
		$cmodeStr .= '<tr height="40px"><td align="left" width="300px" colspan=2><div class="form-group m-b-xs"><button type="button" name="applyHiddenNetworkSettings" id="applyHiddenNetworkSettings" class="btn btn-viablue pull-right">' . APPLY_BTN . '</button></div> </td></tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '<div style="padding-left:28px;"><div style="display:' . $cmodeInfoDivStatus . '" class="sepraterDiv"></div></div>';
		$cmodeStr .= '<div style="width:100%; display:' . $cmodeInfoDivStatus . ';" id="cmodeInfoDiv">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" height="80px" width="100%" id="showNetworkInfoTbl" style="padding-left:28px">';
		
	if($sessionNetworkData['mode']== 'client' && $sessionNetworkData['SSID']!=''){
		if(count($explodeCurrentNetworkInfo)> 0) {
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14" colspan="2"><strong>Network Info</strong></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14"><span>SSID</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[0] . '</span></td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14"><span>Channel</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[1] . '</span></td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14">Signal</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[3] . '</td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14">Security</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[4] . '</td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
		}
	}	
		
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		echo $cmodeStr;
		die();
	}
	//Ajax Call for apply client mode data
	public function applyWifiSettingcmodeAction() {
		$appObj = new ApplicationController();
		$ssid = trim($_POST['ssid']);
		$security =(trim($_POST['security'])== '' || trim($_POST['security'])== 'undefined')? '' : trim($_POST['security']);
		$username =(trim($_POST['uname'])== '' || trim($_POST['uname'])== 'undefined')? '' : trim($_POST['uname']);
		$checkbox_8021x = trim($_POST['checkbox_8021x']);
		
		//now file will be created when apply. not on checkbox checkd/unchecked
		$hiddenNetworkChkboxVal = trim($_POST['hiddenNetworkChkboxVal']);
		$fileName = LIN_WIFI_PATH . FILE_HIDDEN_NETWORK;
		if($hiddenNetworkChkboxVal == 1) {
			$myfile = fopen($fileName, 'w')or die("can't open file");
			$confWrite = fwrite($myfile, $hiddenNetworkChkboxVal);			
		} else {
			unlink($fileName);			
		}
		//end
		
		if($username == 'false') {
			$username = '';
		}

		//Create wifi file - Added by niraj 7 july,2024
		$this->createWifiFile();

		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$clientMode = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>CurrentWLAN</Cmd><P1>Set</P1><P2>$ssid</P2><P3>$security</P3><P4>$username</P4><P5>$checkbox_8021x</P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$return = $appObj->showNetworkInfo($logincmd, $clientMode);
		$explodeReturn = explode('|', $return);
		echo trim($explodeReturn[2]);
		die;
	}
	//ajax call when click on hideen network checkbox
	public function applyWifihiddenNetworkAction() {
		$hiddenNetworkChkboxVal = trim($_POST['chkVal']);
		$fileName = LIN_WIFI_PATH . FILE_HIDDEN_NETWORK;
		if($hiddenNetworkChkboxVal == 1) {
			$myfile = fopen($fileName, 'w')or die("can't open file");
			$confWrite = fwrite($myfile, $hiddenNetworkChkboxVal);
			echo 'File Created';
		} else {
			unlink($fileName);
			echo 'File Deleted';
		}
		die;
	}
	//ajax call when wifi is OFF
	public function wifiOffAction() {
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');			
		
		$appObj = new ApplicationController();
		if(file_exists(LIN_WIFI_PATH . FILE_APMODE_READ_STANDALONE)) {
			unlink(LIN_WIFI_PATH.FILE_APMODE_READ_STANDALONE);
		}
		if($session->offsetGet('isWifi_ON_OFF') == 1) {
			unlink(LIN_WIFI_PATH.FILE_FIND_WIFI);
		}
		if(CHECK_WIFI_NEWAP_CONFIG == 1) {
			unlink(LIN_WIFI_PATH .FILE_NEW_AP_CONFIG);
		}
		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$appModeApplyMode = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>WifiOffReset</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		echo $return = $appObj->showNetworkInfo($logincmd, $appModeApplyMode);
		die;
		$explodeReturn = explode('|', $return);
		echo $explodeReturn[1];
		exit;
	}

	//ajax call when wifi is ON
	/*public function wifiOnAction() {
		$session = new Container('userinfo');
		$session->offsetSet('isWifi_ON_OFF', 1);
		$fileName = LIN_WIFI_PATH . FILE_FIND_WIFI;
		$myfile = fopen($fileName, 'w')or die("can't open file");
		$content = "";
		$confWrite = fwrite($myfile, $content);
		echo 'FileCreated';
		die;
	}*/

	//set a session to maintaine wifi tabs
	public function wifiOnAction() {
		$session = new Container('userinfo');
		$session->offsetSet('wifi_onOff_btn', 1);
		echo 1; die;
	}

	//this will create a wifie.txt when apply AP mode, Client mode & WD mode
	public function createWifiFile(){
		$session = new Container('userinfo');
		//$session->offsetSet('isWifi_ON_OFF', 1);
		$fileName = LIN_WIFI_PATH . FILE_FIND_WIFI;
		$myfile = fopen($fileName, 'w');
		$content = "";
		$confWrite = fwrite($myfile, $content);
		return true;
	}
	
        
	//network function using for set dual network form linux	
	public function manageDualNetworkFileAction(){
		$dualNetworkChkboxVal=trim($_POST['dualNetworkChkboxVal']);	
		$fileName=DEST_PATH.FILE_DUAL_NETWORK;
		if($dualNetworkChkboxVal==1){
			$myfile = fopen($fileName, 'w') or die("can't open file");		
			$confWrite= fwrite($myfile, $dualNetworkChkboxVal);
			echo 'File Created';		
		}else{
			unlink($fileName);
			echo 'File Deleted';
		}
		die;
	}	
        
	//network function using for showing wifi ip tab	
	public function showWifiIpModeAction(){
		$appObj = new ApplicationController();
		$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$ipInfo_cmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>IpInfo</Cmd><P1>wlan0</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$returnResult=$appObj->showNetworkInfo($logincmd,$ipInfo_cmd);
		if($returnResult===0){
			echo 'noconnection';
			die;
		}else if($returnResult=='loginerror'){
			echo 'loginerror';
			die;
		}
		else{
			list($ipaddrArr,$subnetmaskArr,$defgatewayArr,$DNS1Arr,$DNS2Arr)=explode("|",$returnResult);
			list($tagnameIP,$ipaddr)=explode(':',$ipaddrArr);
			list($tagnameSubnetMask,$subnetmask)=explode(':',$subnetmaskArr);
			list($tagnameDefGateWay,$defgateway)=explode(':',$defgatewayArr);
			list($tagnameDNS1,$dns1)=explode(':',$DNS1Arr);
			// DNS2 has been removed so we use for Hostname
			list($tagnameDNS2,$dns2)=explode(':',$DNS2Arr);

			$wifistr='<br /><table cellspacing="0" border="1" width="734px" cellpadding="0" id="netSettingTbl">';
			$wifistr.='<tr><td class="netsettinglabel3" width="320px">&nbsp;'.STR_GATEWAY_IP.'&nbsp;</td><td class="netsettinglabel3" width="400px" style="padding-left:11px">&nbsp;'.$ipaddr.'&nbsp;</td></tr>';
			$wifistr.='<tr><td class="netsettinglabel3" width="320px">&nbsp;'.STR_SUBNET_MASK.'&nbsp;</td><td class="netsettinglabel3" width="400px" style="padding-left:11px">&nbsp;'.$subnetmask.'&nbsp;</td></tr>';
			$wifistr.='<tr><td class="netsettinglabel3" width="320px">&nbsp;'.STR_DEFAULT_GATEWAY.'&nbsp;</td><td class="netsettinglabel3" width="400px" style="padding-left:11px">&nbsp;'.$defgateway.'&nbsp;</td></tr>';
			$wifistr.='<tr> <td class="netsettinglabel3" width="320px">&nbsp;'.STR_DNS_SERVER1.'&nbsp;</td><td class="netsettinglabel3" width="400px" style="padding-left:11px">&nbsp;'.$dns1.'&nbsp;</td></tr>';
			$wifistr.='</table>';
			$wifistr.='<table><tr><td><span class="redmsg">'.MSG_LINK6_NOTE.' '.STR_WIFI_INFO_NOTE.'</span></td></tr></table>';
			echo $wifistr;
			die;
		}		
	}
	
	//Ajax Call for fetching client mode on change
	public function showWifiSettingOnChangeAction() {
		$appObj = new ApplicationController();
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');	
		
		//showing changeel based on network.json
		if(file_exists(DEST_PATH.'/network.json')){
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			$showHiddenNetwork=$arrayNetworkJson['Hidden'];			
			$showDualNetworkLin=$arrayNetworkJson['DualNetworkWifi'];
			$showDualNetworkWin=$arrayNetworkJson['DualNetworkLAN'];						
		}		
		
		$networkVal = trim($_POST['networkVal']);	
		$logincmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$getListCmd='<P><UN>websetting</UN><Pwd></Pwd><Cmd>GetNetworkList</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>';	
		$currentNwCmd="<P><UN>websetting</UN><Pwd></Pwd><Cmd>CurrentWLAN</Cmd><P1>Get</P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		
		// get Current network info	
		$currentNwInfo=$_COOKIE['current_network'];//showNetworkInfo($logincmd,$currentNwCmd);
		$checkCurentNetwork='';
		if(!strstr($currentNwInfo,'Error')){
			$currentNwInfoArr=explode('|',$currentNwInfo);
			$checkCurentNetwork= trim($currentNwInfoArr[2]);
		}
	
		/* code added by niraj to get network list from file ## 06/02/2023 */	
		$networkListFilePath = BASE_PATH . "/public/uploads/networklist_".$session->offsetGet('LoginName').".txt";
		$cmdOutput = file_get_contents($networkListFilePath);// get Wifi list from the file.
		/* end code added by niraj to get network list from file ## 06/02/2023 */	

		// $cmdOutput=$_COOKIE['current_network_list'];//showNetworkInfo($logincmd,$getListCmd);	
		$netwirkInfoArr=explode('|',$cmdOutput);
		$networkArrList=array();
		//now getting json as a response from GetNetworkList command
		$returnResultArray = json_decode($cmdOutput);
		$currentNwBasicInfoStr="";
		foreach($returnResultArray->WifiList as $returnKey=>$returnVal){
			$networkArrList[$returnKey]=trim($returnVal->SSID);	
		}
		
		foreach($networkArrList as $getNetworkKey=>$getNetwrokValue){
			if($getNetwrokValue==$networkVal){
				$currentNwBasicInfoStr.=$returnResultArray->WifiList[$getNetworkKey]->SSID.'#'.$returnResultArray->WifiList[$getNetworkKey]->ChannelCount."#".$returnResultArray->WifiList[$getNetworkKey]->Rate.'#'.$returnResultArray->WifiList[$getNetworkKey]->SignalStrength."#".$returnResultArray->WifiList[$getNetworkKey]->SecurityType;
			}
		}
		
		
		
		/*$currentNwBasicInfoStr='';
		for($i=0;$i<count($netwirkInfoArr);$i++){
			if($i!=0){
				$explodeNetwork=explode('#',$netwirkInfoArr[$i]);
				//$networkArrList[]=$explodeNetwork[0];
				
				// Matched with current network and get details of that network
				if($explodeNetwork[0]==$networkVal){
					$currentNwBasicInfoStr=$netwirkInfoArr[$i];
					//$currentNwBasicInfoArr[]='';
				}
				
			}	
		}*/
		
	$explodeCurrentNetworkInfo=explode('#',$currentNwBasicInfoStr);	
	//echo "<pre>";print_r($explodeCurrentNetworkInfo);die;
	$cmodeStr = '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="padding-left:28px">';
	/*$cmodeStr .= '<tr height="30px">&nbsp;';
	$cmodeStr .= '<td width="100%" align="left">Client Mode changes will take effect once the VIA is rebooted or the VIA session reset</td>';
	$cmodeStr .= '</tr>';
	*/
	$cmodeStr .= '<tr height="20px"><td class="style14" colspan="2"><div id="networkMsgSpan" class="text-danger" style="margin-top:10px;">' . $networkMsg . '</div></td></tr>';
	
	$cmodeStr .= '<tr height="200px"><td valign="top" width="100%" align="left">';
		//Once a user unchecked the hidden box  then we are treating it as normal case. fixed bug id 0011917. unchecking it  
		// added for hidden network
		/*if(CHECK_HIDDEN_NETWORK == 1) {
			$cmodeHiddenNetworkDiv1Block = 'none';
			$cmodeInfoDivStatus = 'none';
			$cmodeHiddenNetworkDiv2Block = 'block';
			$showHiddenSSID=($sessionNetworkData['SSID']!='')?$sessionNetworkData['SSID']:'';
		} else {*/
			$cmodeHiddenNetworkDiv1Block = 'block';
			$cmodeInfoDivStatus = 'block';
			$cmodeHiddenNetworkDiv2Block = 'none';
		//}

		$networkArrList = array_unique($networkArrList);
		$networkListDD = '';

		foreach($networkArrList as $val) {
			$sel = '';
			if($val == $networkVal)
				$sel = 'selected';
			$networkListDD .= '<option value="' . $val . '" ' . $sel . '>' . $val . '</option>';
		}

		//added on 25Jun2020. fixed bug id 0011917. unchecking it 
		$checkHiddenNw ='';//(CHECK_HIDDEN_NETWORK == 1)? 'checked' : '';
		$chkDualNw =(trim(CHECK_DUAL_NETWORK) == 1)? 'checked' : 0;
		$cmodeStr .= '<div id="cmodeHiddenNetworkDiv1" style="display:' . $cmodeHiddenNetworkDiv1Block . '">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
		$cmodeStr .= '<tr>';
		$cmodeStr .= '<td width="100%" id="showNetworkList">';
		$cmodeStr .= '<div class="selectdiv"> <select name="networkList" id="networkList" class="form-control m-b styl">' . $networkListDD . '</select><label class="ddlabelCss">' . STR_NETWORK . '</label></div>&nbsp;&nbsp;';
		//$cmodeStr.='<div style="margin-top:2px; padding-left:60px"><span id="refreshList">&nbsp;&nbsp;<img src="'.PUBLIC_URL.'/img/refresh.png" class="pointer"/></span></div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';

		$cmodeStr .= '<tr height="20px">';
		$cmodeStr .= '<td width="100%"><span id="refreshList" class="pointer"><i class="fa fa-refresh" style="font-size:16px;"></i>&nbsp;&nbsp;'.STR_WIFI_SCAN.'</span></td>';
		$cmodeStr .= '</tr>';

		if(trim($showHiddenNetwork)==1){
		$cmodeStr .= '<tr height="50px">';
		$cmodeStr .= '<td width="100%"><span id="hiddennetworkSpan"><input type="checkbox" name="hiddennetworkChkbox" id="hiddennetworkChkbox" ' . $checkHiddenNw . ' class="hidenChkBox"/><label for="hiddennetworkChkbox" class="style14 m-r-sm m-l-n" ><span></span>' . STR_HIDDEN_NETWORK . '</label> </span></td>';
		$cmodeStr .= '</tr>';
		}
	
		if($explodeCurrentNetworkInfo[4] != '') {
			if(strstr(strtolower($explodeCurrentNetworkInfo[4]), '802.1x') || strstr(strtolower($explodeCurrentNetworkInfo[4]), '802.11x')) {
				$cmodeStr .= '<tr height="40px">';
				$cmodeStr .= '<td width="100%"><span id="checkbox_8021x_Span"><input type="checkbox" name="checkbox_8021x" id="checkbox_8021x" class="checkbox_8021x_css"/><label for="checkbox_8021x" class="style14 m-r-sm m-l-n pointer" ><span></span>'.NETWRK_802_1x_Txt.'</label> </span>  </td>';
				$cmodeStr .= '</tr>';
			
			
			
			
				$cmodeStr .= '<tr height="50px" id="showUnameField">';
				//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
				$cmodeStr .= '<td width="100%" colspan=2><fieldset class="form-group"><input type="text"  name="uname" id="uname" value="" class="form-control styl" maxlength="50"><label for="uname" class="animate-lbl activeCss 8021x_identity">' . STR_USERMAME . '</label></fieldset></td>';
				$cmodeStr .= '</tr>';
			}
			
		
			//added on 24Feb2021 for 802.1x implementation
			$cmodeStr .= '<form method="POST" name="upload8021xFrm" action="upload8021xCertificate" enctype="multipart/form-data" id="upload8021xFrm"><tr height="50px" id="showAuthorityFileField" style="display:none">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2><div class="row hide_802_settings_css"><div class="col-md-6"><label class="custom-upload"><input type="file" name="authorityFile" id="authorityFile" class="pointer" multiple="multiple" accept=".pem">'.NETWRK_802_1x_USR_CERT_FILE2.'</div><div class="col-md-6"> <span class="text-dark align-middle" id="showAuthorityFileName"></span> </div></div></td>';
			$cmodeStr .= '</tr>';
			
			$cmodeStr .= '<tr height="50px" id="showPasswordField">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_PASSWORD.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2>';
			//$cmodeStr .= '<div style="float:left;">';
			$cmodeStr .= '<div class="form-group m-b-xs"><div class="input-group" style="width:100%;"><fieldset class="form-group" style="margin-bottom: 0px;"><input type="password"  name="networkPassword" id="networkPassword" value="" class="form-control styl" maxlength="50"><label for="networkPassword" class="animate-lbl activeCss 8021x_pass">' . STR_PASSWORD . '</label></fieldset><div id="showPasswordToggle" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div>';
			//$cmodeStr .= '</div>&nbsp;&nbsp;<div id="showPasswordToggle" style="margin-top:-15px; padding-left:30px"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div>';
			
			$cmodeStr .= '</td>';
			$cmodeStr .= '</tr>';
		
			$cmodeStr .= '<tr height="50px" id="showUserCertificateField" style="display:none">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2><div class="row hide_802_settings_css"><div class="col-md-6"><label class="custom-upload"><input type="file" name="userCertificateFile" id="userCertificateFile" class="pointer" multiple="multiple" accept=".pem">'.NETWRK_802_1x_USR_CERT_FILE1.'</div><div class="col-md-6"> <span class="text-dark align-middle" id="showUserCertificateFileName"></span> </div></div></td>';
			$cmodeStr .= '</tr>';
		
			$cmodeStr .= '<tr height="50px" id="showClientKeyFileField" style="display:none">';
			//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_USERMAME.'</td>';
			$cmodeStr .= '<td width="100%" colspan=2><div class="row hide_802_settings_css"><div class="col-md-6"><label class="custom-upload"><input type="file" name="clientKeyFile" id="clientKeyFile" class="pointer" multiple="multiple" accept=".key">'.NETWRK_802_1x_USR_CERT_FILE3.'</div><div class="col-md-6"> <span class="text-dark align-middle" id="showClientKeyFileName"></span> </div></div></td>';
			$cmodeStr .= '</tr></form>';
			
			
		}

		if(GET_OS == 'LIN') {
			if(trim($showDualNetworkLin)==1){
			$cmodeStr .= '<tr height="50px">';
			$cmodeStr .= '<td width="100%" class="style14" colspan="2"><input type="checkbox" name="enableDualNetworkChkboxLinux" id="enableDualNetworkChkboxLinux" value="' . CHECK_DUAL_NETWORK . '" ' . $chkDualNw . '/><label for="enableDualNetworkChkboxLinux" class="style14 m-l-n"><span></span></label>' . STR_ENABLE_DUAL_NETWORK . '</td>';
			$cmodeStr .= '</tr>';
			}
		}

		$cmodeStr .= '<tr height="50px">';
		$cmodeStr .= '<td align="left" width="100%" colspan=2 class="net-bt-15">';
		$cmodeStr .= '<div class="form-group m-b-xs"><button type="button" name="applyNetworkSettings" id="applyNetworkSettings" class="btn btn-viablue makeDisabled">' . APPLY_BTN . '</button></div></td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
	//end first part

		$cmodeStr .= '<div id="cmodeHiddenNetworkDiv2" style="display:' . $cmodeHiddenNetworkDiv2Block . '">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" width="100%">';
		$cmodeStr .= '<tr height="30px">';
		//$cmodeStr.='<td width="15%" class="style14" style="padding-left:20px">'.STR_NETWORK.'</td>';
		$cmodeStr .= '<td width="100%" colspan=2>';
		$cmodeStr .= '<div><fieldset class="form-group"><input type="text"  name="hiddenNetworkName" id="hiddenNetworkName" value="" class="form-control styl"><label for="hiddenNetworkName" class="animate-lbl activeCss">' . STR_NETWORK . '</label></fieldset>	</div>';
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';

		$cmodeStr .= '<tr height="30px">';
		$cmodeStr .= '<td width="100%" colspan=2><span id="hiddennetworkSpan"><input  class="hidenChkBox" type="checkbox" name="hiddennetworkChkbox" id="hiddennetworkChkbox" ' . $checkHiddenNw . ' /><label for="hiddennetworkChkbox" class="style14 m-l-n"><span></span>' . STR_HIDDEN_NETWORK . '</label> </span></td>';
		$cmodeStr .= '</tr>';

		$cmodeStr .= '<tr height="60px" id="showUnameField"><td width="100%" colspan=2><fieldset class="form-group m-b"><input type="text"  name="hiddenUname" id="uname" value="" class="form-control styl" placeholder="Optional"><label for="hiddenUname" class="animate-lbl activeCss">' . STR_USERMAME . '</label></fieldset></td></tr>';

		$cmodeStr .= '<tr height="40px" id="showPasswordField"><td width="100%" colspan=2><div><div class="form-group m-b-xs"><div class="input-group" style="width:100%;"><fieldset class="form-group" style="margin-bottom: 0px;"><input type="password"  name="hiddenPassword" id="hiddenPassword" value="" class="form-control styl"> <label for="hiddenPassword" class="animate-lbl activeCss">' . STR_PASSWORD . '</label></fieldset><div id="hiddennnetworkToggle" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div></div></div>&nbsp;&nbsp;</td></tr>';

		if(GET_OS == 'LIN') {
			$cmodeStr .= '<tr height="80px"><td width="100%" class="style14" colspan="2"><input type="checkbox" name="enableDualNetworkHiddenBoxLinux" id="enableDualNetworkHiddenBoxLinux" value="' . CHECK_DUAL_NETWORK . '"  ' . $chkDualNw . '/><label for="enableDualNetworkHiddenBoxLinux" class="style14 m-r-sm m-l-n"><span></span></label>&nbsp;' . STR_ENABLE_DUAL_NETWORK . '</td></tr>';
		}
		
		$cmodeStr .= '<tr><td>&nbsp;</td></tr>';

		$cmodeStr .= '<tr height="40px"><td align="left" width="300px" colspan=2><div class="form-group m-b-xs"><button type="button" name="applyHiddenNetworkSettings" id="applyHiddenNetworkSettings" class="btn btn-viablue">' . APPLY_BTN . '</button></div> </td></tr>';

		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		
		$cmodeStr .= '</td>';
		$cmodeStr .= '</tr>';
		$cmodeStr .= '</table>';

		$cmodeStr .= '<div style="padding-left:28px;"><div style="display:' . $cmodeInfoDivStatus . '" class="sepraterDiv"></div></div>';
		$cmodeStr .= '<div style="width:100%; display:' . $cmodeInfoDivStatus . ';" id="cmodeInfoDiv">';
		$cmodeStr .= '<table cellpadding="0" cellspacing="0" border="0" height="80px" width="100%" id="showNetworkInfoTbl" style="padding-left:28px">';
		if(count($explodeCurrentNetworkInfo)> 0) {			
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14" colspan="2"><strong>Network Info</strong></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14"><span>SSID</span>&nbsp;:&nbsp;<span>'.$explodeCurrentNetworkInfo[0].'</span></td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14"><span>Channel</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[1] . '</span></td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14">Signal</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[3] . '</td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
			$cmodeStr .= '<tr height="40px"><td valign="middle" width="40%" align="left" class="style14">Security</span>&nbsp;:&nbsp;<span>' . $explodeCurrentNetworkInfo[4] . '</td><td valign="middle" style="padding-left:20px;" width="70%" align="left" class="style14"></td></tr>';
		}
		$cmodeStr .= '</table>';
		$cmodeStr .= '</div>';
		echo $cmodeStr;
		die();
	}
	
	//Ajax Call for fetching channel data 
	public function changeChannelvaluesAjaxAction() {
		$channelVal=trim($_POST['channelval']);
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');	
		$appObj = new ApplicationController();
		//showing changeel based on network.json
		if(file_exists(DEST_PATH.'/network.json')){
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			$channel2_4_Array=$arrayNetworkJson['Band_Channel_2.4'];			
			if($arrayNetworkJson['Band_Channel_2.4']!='' && $arrayNetworkJson['Band_Channel_5']!=''){								
				$channel_5_Array=$arrayNetworkJson['Band_Channel_5'];
			}	
		}			
		//echo "<pre>";print_r($channel2_4_Array);die;
		$ddbox = '<option value="" selected=selected>Select</option>';
		if($channelVal=='channels_2_4'){
			for($k = 0;	$k <=count($channel2_4_Array);$k++ ) {
				//$sel1 = '';
				//if($k == $read_apmodeChannelFile)
				//if($channel2_4_Array[$k] == $sessionNetworkData['Channel'])
				//	$sel1 = 'selected';
				if($channel2_4_Array[$k]!=''){	
				$ddbox .= '<option ' . $sel1 . ' value=' . $channel2_4_Array[$k] . '>' . $channel2_4_Array[$k] . '</option>';
				}
			}
		}else{
			for($m = 0;	$m <=count($channel_5_Array);$m++ ) {
				//$sel1 = '';
				//if($k == $read_apmodeChannelFile)
				//if($channel_5_Array[$m] == $sessionNetworkData['Channel'])
				//	$sel1 = 'selected';
				if($channel_5_Array[$m]!=''){	
					$ddbox .= '<option ' . $sel1 . ' value=' . $channel_5_Array[$m] . '>' . $channel_5_Array[$m] . '</option>';
				}
			}
		
		}
		echo '<select name="apModeChannelList" id="apModeChannelList" class="form-control m-b styl">'.$ddbox.'</select><label class="ddlabelCss">' . STR_CHANNELS . '</label>	';	
		die;
	}

// uoload certifictae file for 802.1x
	public function upload8021xCertificateAction(){
		if($this->getRequest()->isPost()) {
			$session = new Container('userinfo');
		    $user_id = $session->offsetGet('usrid');
			ini_set('max_execution_time', 0);			
			$path = LIN_WIFI_PATH;
			$appObj = new ApplicationController();			
			$postData = $this->getRequest()->getPost()->toArray();			
			//print_r($_FILES); die;
			//die($postData['fileFlag']);
			if(trim($postData['fileFlag'])==1){		
				$file = $this->params()->fromFiles('authorityFile');
			}
			if(trim($postData['fileFlag'])==2){		
				$file = $this->params()->fromFiles('userCertificateFile');
			}
			if(trim($postData['fileFlag'])==3){		
				$file = $this->params()->fromFiles('clientKeyFile');
			}
							
			$filename = $file['name'];
			//die($path . $file['name']);
			if(!empty($filename)){
				//Upload and extract the file
				 $filepath = $path . $file['name'];
				 $up = move_uploaded_file($file['tmp_name'], $path . $file['name']);
				 //authority file	
				 if(trim($postData['fileFlag'])==1){
				 	rename($path.$file['name'],$path.'ca.pem');
				 }
				 //certificate file
				 if(trim($postData['fileFlag'])==2){
				 	rename($path . $file['name'],$path.'client.pem');
				 }
				 //key file
				 if(trim($postData['fileFlag'])==3){
				 	rename($path . $file['name'],$path.'client.key');					
				 }	
			}		
		
		}
		die;
	}
	
	
	//Ajax Call for fetching wifidirect data
	public function showWifidirectsettingmodeAction(){
		
		$session = new Container('userinfo');
		$sessionNetworkData=$session->offsetGet('networkData');	
		$appObj = new ApplicationController();		

		/*if(file_exists(DEST_PATH.'network.json')){
			$arrayNetworkJson=$appObj->readJsonFile(DEST_PATH.'network.json');
			$bandFlag=strtolower($arrayNetworkJson['Band']);
		}*/

		$read_wifiDirectPass1='';
		$read_wifiDirectPass2='';
		$read_wifiDirectPass3='';
		$read_wifiDirectPass4='';
		$read_wifiDirectSSIDFile = file_exists(LIN_WIFI_PATH.FILE_WD_SSID) ? str_replace("VIA_D_", "", $appObj->file_read(LIN_WIFI_PATH.FILE_WD_SSID)):'';
		$read_wifidModeFrequency = file_exists(LIN_WIFI_PATH.FILE_WD_FEQWD) ? $appObj->file_read(LIN_WIFI_PATH.FILE_WD_FEQWD):'';
		if(file_exists(LIN_WIFI_PATH.FILE_AP_KEY_WD)){
			$read_wifiDirectPassFile = trim($appObj->file_read(LIN_WIFI_PATH.FILE_AP_KEY_WD));
			$read_wifiDirectPass1=substr($read_wifiDirectPassFile, 0, 1);
			$read_wifiDirectPass2=substr($read_wifiDirectPassFile, 1, 1);
			$read_wifiDirectPass3=substr($read_wifiDirectPassFile, 2, 1);
			$read_wifiDirectPass4=substr($read_wifiDirectPassFile, 3, 1);
		}

		$standAloneChecked = "";
		$withLANChecked = "";
		if(file_exists(LIN_WIFI_PATH.FILE_WD_ENABLE) && !file_exists(LIN_WIFI_PATH.FILE_WD_ONLY)){
			$withLANChecked = "checked";	
		}else{
			$standAloneChecked = "checked";
		}

		$str = '';
		$str .= '<form name="wifiDirectModeFrm" id="wifiDirectModeFrm" method="post">';
		$str .= '<table cellpadding="0" cellspacing="0" border="0" width="100%" style="padding-left:28px";>';

		$str.='<tr height="60px">&nbsp;&nbsp;<td width="100%" colspan=2 class="m-l-md"><div style="width:400px" class="d-flex">
				<span style="padding-left:0px">
				<input type="radio" name="wifidirect_mode" id="wd_standalone" value="2" class="radio3" '.$standAloneChecked.'>
				<label for="wd_standalone" class="d-flex-g-10"><span class="text-dark">'.STR_WD_STANDALONE.'</span></label>
				</span>
				<span style="padding-left:30px">
				<input type="radio" name="wifidirect_mode" value="3" class="radio3" id="wd_withnlan" '.$withLANChecked.'>
				<label for="wd_withnlan" class="d-flex-g-10"><span class="text-dark">'.STR_WD_WITHLAN.'</span></label>
				</span></div></td></tr>';

		$str .= '<tr height="30px">';
		$str .= '<td width="100%" align="left" colspan="2"><table width="100%"><tr class="ssidNameTr"><td width="14%"><fieldset class="form-group m-t m-b-lg"><input type="text" name="vialebel_wifiDirect" id="vialebel_wifiDirect" value="VIA_D_" class="form-control styl" disabled="disabled"/><label for="vialebel_wifiDirect" class="animate-lbl activeCss"></label></fieldset></td><td style="padding-left:5px;"><fieldset class="form-group m-t m-b-lg"><input type="text" name="wifiDirectSSID" id="wifiDirectSSID" value="'.$read_wifiDirectSSIDFile.'" class="form-control styl" maxlength="20" /><label for="wifiDirectSSID" class="animate-lbl activeCss">'.STR_SSID.'*</label></fieldset></td></tr></table></td>';
		$str .= '</tr>';
		$str .= '<tr height="30px">';
		
		/*$str .= '<td width="100%" colspan=2>';
		$str .= ' <div class="form-group m-b-md"><div class="input-group" style="width:100%;"><fieldset class="form-group m-b-none"><input type="password" name="wifiDirectPass" id="wifiDirectPass" value="' . $read_wifiDirectPassFile . '" class="form-control styl" maxlength="4"/><label for="wifiDirectPass" class="animate-lbl activeCss">' . STR_PASWORD . '</label></fieldset><div id="showPasswordToggleWifiDirectMode" class="input-group-addon"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show Password"/></div></div></div>';
		$str .= '</td>';*/

		$str .= '<td width="100%" colspan=2>';
		$str .= ' <div class="form-group m-b-md">
		<div class="input-group" style="width:100%;">
		<label for="wifiDirectPass" class="wifiDirectPass">'.STR_WD_PIN.'*</label>
		<div class="wd-pin-div">
			<input type="password" value="'.$read_wifiDirectPass1.'" name="wifiDirectPass1" id="wifiDirectPass1" class="form-control styl" maxlength="1"/>
			<input type="password" value="'.$read_wifiDirectPass2.'" name="wifiDirectPass2" id="wifiDirectPass2" class="form-control styl" maxlength="1"/>
			<input type="password" value="'.$read_wifiDirectPass3.'" name="wifiDirectPass3" id="wifiDirectPass3" class="form-control styl" maxlength="1"/>
			<input type="password" value="'.$read_wifiDirectPass4.'" name="wifiDirectPass4" id="wifiDirectPass4" class="form-control styl" maxlength="1"/>
			<div id="showPasswordToggleWifiDirectMode" class="wd-pin-view"><img src="' . PUBLIC_URL . '/img/passwordView.png" class="pointer" title="Show PIN"/></div>
		</div>
		
		</div>
		</div>';
		$str .= '</td>';



		$str .= '</tr>';
		/*$str .= '<tr height="20px"><td width="100%" colspan=2><div style="font-size: 12px"> <span class="text-danger">Note:</span><span class="ssidnote" style="font-style: italic;"><span> '.MSG_SSID_4_20_LONG.'.</span><p><span style="padding-left:30px;">'.STR_WDPASS_TEXT.'</span></span></p></div></td></tr>';*/

		$str .= '<tr height="20px"><td width="100%" colspan=2><div style="font-size: 12px"><span class="ssidnote" style="font-style: italic;"><span> '.MSG_SSID_4_20_LONG.'.</span></span></p></div></td></tr>';
		
		//if($bandFlag=='dual'){
		$channel24Checked='';
		$channel5Checked='';	
		if($read_wifidModeFrequency == 5){
			$channel5Checked='checked';
		}else{
			$channel24Checked='checked';
		}		
		$str.='<tr height="60px"><td width="100%" colspan=2 class="m-l-md">	
		<div style="width:400px" class="d-flex">
			<span style="padding-left:0px">
			<input type="radio" name="wifidirect_channels" channel-id="channels_2_4" id="wifidirect_channels_2_4" value="24" class="radio3" '.$channel24Checked.'>
			<label for="wifidirect_channels_2_4" class="d-flex-g-10"><span class="text-dark">2.4 GHz Channels</span></label>
			</span>
			<span style="padding-left:30px">
			<input type="radio" name="wifidirect_channels" channel-id="channels_5" id="wifidirect_channels_5" value="5" class="radio3" '.$channel5Checked.'>
			<label for="wifidirect_channels_5" class="d-flex-g-10"><span class="text-dark">5 GHz Channels</span></label>
			</span>		
		</div>	
		</td></tr>';	  
		//}

		$str .= '<tr height="40px">';
		$str .= '<td width="100%" align="left" colspan=2><div><button type="button" name="wifiDirectApply" id="wifiDirectApply" class="btn btn-viablue makeDisabled pull-right">' . APPLY_BTN . '</button></div></td>';
		$str .= '</tr>';
		$str .= '</table>';
		$str .= '</form>';
		echo $str;
		die();
	}


	function applyWifidirectsettingmodeAction(){
		$appObj = new ApplicationController();
		$serviceObj = new ServicesController();	
		$ssid = htmlspecialchars(trim($_POST['ssid']));
		$security = trim($_POST['security']);
		$channel = trim($_POST['channel']);
		$mode = trim($_POST['mode']); 
		$overwrite = trim($_POST['overwrite']); 

		//Create wifi file - Added by niraj 7 july,2024
		$this->createWifiFile();
		$logincmd = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>Login</Cmd><P1></P1><P2></P2><P3></P3><P4></P4><P5></P5><P6></P6><P7></P7><P8></P8><P9></P9><P10></P10></P>";
		$wdApplyMode = "<P><UN>websetting</UN><Pwd></Pwd><Cmd>SetSSID</Cmd><P1>$ssid</P1><P2>$security</P2><P3>$channel</P3><P4>0</P4><P5>0</P5><P6>$mode</P6><P7>$overwrite</P7><P8></P8><P9></P9><P10></P10></P>";
		echo $return = trim($appObj->showNetworkInfo($logincmd, $wdApplyMode));
		die;
	}
			

}