<?php
use Webapp\Controller\ApplicationController;
use Zend\Session\Container; // for session

/*----- set Anti-clickjacking Header by Niraj Gautam on 22-08-2022 */
header("X-Frame-Options: SAMEORIGIN");
/*----- end set Anti-clickjacking Header by Niraj Gautam on 22-08-2022 */

/**
 * This makes our life easier when dealing with paths. Everything is relative
 * to the application root now.
 */
chdir(dirname(__DIR__));

// Decline static file requests back to the PHP built-in webserver
if (php_sapi_name() === 'cli-server') {
    $path = realpath(__DIR__ . parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
    if (__FILE__ !== $path && is_file($path)) {
        return false;
    }
    unset($path);
}

error_reporting(E_ALL ^ (E_NOTICE | E_WARNING | E_DEPRECATED));
ini_set('display_errors', true);

// Setup autoloading
require 'init_autoloader.php';
require "config/global_constants.php";
$session = new Container('userinfo');
$lang=$session->offsetGet('lang');
//set lang file based on lang
if( PRODUCT_TYPE=='vsm' && GET_OS=='WIN' && empty($lang) ){
	$lang="eng";
	$session->offsetSet('lang', $lang);	
}else{
	if(empty($lang)) {
		$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
		if(strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 5))=="zh-tw"){
		$lang="trchi";
		}
		else if(strtolower(substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 10))=="zh-hant-tw"){
		$lang="trchi";
		} 
		else if($lang=="en"){
		$lang="eng";	  
		}
		else if($lang=="ja"){
		$lang="jap";	  
		}
		else if($lang=="zh"){
		$lang="chi";	  
		}
		else if($lang=="es"){
		$lang="spa";	  
		} 
		else if($lang=="de"){
		$lang="ger";	  
		}
		else if($lang=="ru"){
		$lang="rus";	 
		}
		else if($lang=="pl"){
		$lang="pol";	  
		}
		else if($lang=="fr"){
		$lang="fre";	 
		}
		else if($lang=="pt"){
		$lang="por";		  
		}
		else if($lang=="zh-TW"){
		$lang="trchi";
		}else{
			$lang="eng";
		}
		$session->offsetSet('lang', $lang);	 

	}
}
$imgdir="img/".PRODUCT_TYPE."/$lang/";
$includelangFile=LANG_DIR.PRODUCT_TYPE.'/'.$lang."/global.inc.php";
if(file_exists(BASE_PATH.'/public/'.$includelangFile)){
	require BASE_PATH.'/public/'.$includelangFile;
}else{
	require LANG_DIR.PRODUCT_TYPE."/eng/global.inc.php";

}

/*code for user access level --- added by niraj */
if(PRODUCT_TYPE == "via" && !file_exists(DEST_PATH.FILE_SESSION_MANAGER)){
	require_once 'module/Webapp/src/Webapp/Controller/ApplicationController.php';
	$appObj = new ApplicationController();
	$appObj->checkUserAccess();
}
/*end code for user access level --- added by niraj */

// Run the application!
Zend\Mvc\Application::init(require 'config/application.config.php')->run();
