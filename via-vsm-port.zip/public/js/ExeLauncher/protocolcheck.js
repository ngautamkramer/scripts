    function _registerEvent(target, eventType, cb) {
try
{
 
        if (target.addEventListener) {
            target.addEventListener(eventType, cb);
            return {
                remove: function () {
                    target.removeEventListener(eventType, cb);
                }
            };
        } else {
            target.attachEvent(eventType, cb);
            return {
                remove: function () {
                    target.detachEvent(eventType, cb);
                }
            };
        }
}
catch(ex)
{
alert(ex);
}

}

    function _createHiddenIframe(target, uri) {
        var iframe = document.createElement("iframe");
        iframe.src = uri;
        iframe.id = "hiddenIframe";
        iframe.style.display = "none";
        target.appendChild(iframe);
        return iframe;
    }

/*Here the logic of the Function is that when an exe is launch by webpage then onblur 
event is fire and if the exe has not launch then we have used here the settime out function 
to check if in particular time that exe has launch or not and if not then we show the message 
of installing the file again */

function openUriWithTimeoutHack(uri, failCb) {

try
{

     var timeout = setTimeout(function () {
		//if (confirm('You Need a Custom Program. Do you want to install?')){			
			alert('Please install via application');
		//} 

            //window.location="SafariSetup.exe";
			//alert('aaaaa');
			
            handler.remove();
        }, 500);

        var iframe = document.querySelector("#hiddenIframe");
        if (!iframe) {
            iframe = _createHiddenIframe(document.body, "about:blank");
        }

        var handler = _registerEvent(window, "blur", onBlur);

        function onBlur() {
            clearTimeout(timeout);
            handler.remove();
        }

        iframe.contentWindow.location.href = uri;
}
catch(ex)
{
//alert(ex);
}
}

function openUriUsingFirefox(uri, failCb) {
try
{

window.document.location= uri ;
}

catch(ex) 
{

  		// Firefox alert
	   //document.location = 'SafariSetup.exe';
	   alert('Please install via application');
   

        
		

}

}

/* Here the function is used to get the version of the IE installed on the Client Machine
*/

function openUriUsingIE(uri, failCb) {

        //check if OS is Win 8 or 8.1
try
{
        var ua = navigator.userAgent.toLowerCase();
        var isWin8 = /windows nt 6.2/.test(ua) || /windows nt 6.3/.test(ua);

        if (isWin8) {
            openUriUsingIEInWindows8(uri, failCb);
        } else {
            if (getInternetExplorerVersion() === 10) {
                openUriUsingIE10InWindows7(uri, failCb);
            } else if (getInternetExplorerVersion() === 9 || getInternetExplorerVersion() === 11) {

            //openUriWithHiddenFrame(uri, failCb);
         openUriUsingIE10InWindows7(uri, failCb) 
        
            } else {
                openUriInNewWindowHack(uri, failCb);
            }
        }
}
catch(ex)
{
alert(ex);
}
   
}

function openUriUsingIE10InWindows7(uri, failCb) 
{
try
{
var timeout = setTimeout(failCb, 2000);
        window.addEventListener("blur", function () {
            clearTimeout(timeout);
        });

        var iframe = document.querySelector("#hiddenIframe");
        if (!iframe) {
            iframe = _createHiddenIframe(document.body, "about:blank");
        }
        try {
            iframe.contentWindow.location.href = uri;
        } catch (e) {

            failCb();
            clearTimeout(timeout);
        }
}
catch(ex)
{
alert(ex);
if (confirm('You Need a Custom Program. Do you want to install?')) 

        ///document.location = 'SafariSetup.exe';
		alert('Please install via setup');

}
        
}

 function openUriInNewWindowHack(uri, failCb)
 {
try
{
        var myWindow = window.open('', '', 'width=0,height=0');

        myWindow.document.write("<iframe src='" + uri + "'></iframe>");
        setTimeout(function () {
            try {
                myWindow.location.href;
                myWindow.setTimeout("window.close()", 100);
            } catch (e) {
                myWindow.close();
                failCb();
            }
        },100);
}
catch(ex)
{
alert(ex);
}
    }

/*Here in this Function for IE >10 We have used the API MSLaunchURI which 
is used to Launch the URI it calls a function if it get sucess to Launch or If it
fails to Launch URI */

    function openUriUsingIEInWindows8(uri, failCb) {
        navigator.msLaunchUri(uri, 
  function() 
  { 
    //Success
  }, 
  function()
  {
    	//IE and Chrome
		alert('Please install via application');
       // document.location = 'SafariSetup.exe';
  } 
); 
    }
    
// Check the browser and based on that call the different Function

    function checkBrowser() {
        var isOpera = !!window.opera || navigator.userAgent.indexOf(' OPR/') >= 0;
        return {
            isOpera: isOpera,
            isFirefox: typeof InstallTrigger !== 'undefined',
            isSafari: Object.prototype.toString.call(window.HTMLElement).indexOf('Constructor') > 0,
            isChrome: !!window.chrome && !isOpera,
            isIE: /*@cc_on!@*/false || !!document.documentMode   // At least IE6
        }
    }
    
    /*This Function is used here to get the Version of the IE installed on the Client 
     and according to that call the different methods associated with it*/
    
    function getInternetExplorerVersion() {
        var rv = -1;
        if (navigator.appName === "Microsoft Internet Explorer")           {
            var ua = navigator.userAgent;
            var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
            if (re.exec(ua) != null)
                rv = parseFloat(RegExp.$1);
        }
        else if (navigator.appName === "Netscape") {
            var ua = navigator.userAgent;
            var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
            if (re.exec(ua) != null) {
                rv = parseFloat(RegExp.$1);
            }
        }
        return rv;
    } 

    function protocolCheck(uri, failCb) {
        var browser = checkBrowser();

//FailCallback function will be used when the Exe file which has to be open is Missing

function failCallback() {
            failCb && failCb();
        }

        if (browser.isFirefox) {

           openUriUsingFirefox(uri, failCallback);

        } else if (browser.isChrome) {
            openUriUsingFirefox(uri, failCallback);
        } else if (browser.isIE) {
            openUriUsingFirefox(uri, failCallback);
        } else {
openUriWithTimeoutHack(uri, failCallback);
        }
    }

