$( document ).ready(function() {
	$('#smtpConfigForm').submit(function(){
        
        resetError();
		var mailerName=jQuery('#mailerName').val();									  
		var mailerHost=jQuery('#mailerHost').val();									  
		var mailerPort = jQuery('#mailerPort').val();		
		var mailerAuth=jQuery('#mailerAuth').val();
		var mailerUserName=jQuery('#mailerUserName').val();
		var mailerPassword=jQuery('#mailerPassword').val();
		var mailerSSL=jQuery('#mailerSSL').val();
		var fromMail=jQuery('#mailerFromMail').val();
		
		var usernamePattern = /^[a-zA-Z0-9\-_@.\/\r\n]+$/;
		var NamePattern=/^[a-zA-Z0-9\-\/\r\n]+$/;
		var numericPattern=/^[0-9]+$/;
		var ipAddressPattern=/^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/;
		var WhiteSpacePattern=/^[^\s]+$/;
		var emailPattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
		var dnsPattern=/^[a-zA-Z0-9. \-]+$/;
		var msg=$('#invalidmsg').val();	
		if($("#mailerAuth").is(':checked')){
            
			if(mailerUserName==""){			
				$('#errmailerUserName').html(msg);
				$('#mailerUserName').focus();
				$('#mailerUserName').addClass('errorClass');
				return false;
			}
			if(mailerPassword==""){		
                $('#errmailerUserName').html('');
                $('#errmailerPassword').html(msg);				
				jQuery('#mailerPassword').addClass('errorClass');
				jQuery('#mailerPassword').focus();
				return false;
			}
			if(!mailerPassword.match(WhiteSpacePattern)){			
				$('#errmailerUserName').html('');
                $('#errmailerPassword').html('Invalid value');				
				jQuery('#mailerPassword').addClass('errorClass');
				jQuery('#mailerPassword').focus();
				return false;
			}
			if(!mailerUserName.match(usernamePattern)){
                $('#errmailerUserName').html('Invalid value');
				$('#mailerUserName').focus();
				$('#mailerUserName').addClass('errorClass');
				return false;
			
			}
			
		}
		
			if(!mailerName.match(NamePattern)){		
                $('#errmailerUserName').html('');
                $('#errmailerPassword').html('');
                $('#errmailerName').html(msg);
				$('#mailerName').focus();
				$('#mailerName').addClass('errorClass');
				return false;
			}else if(mailerHost==""){	
                $('#errmailerUserName').html('');
                $('#errmailerPassword').html('');
                $('#errmailerName').html('');	
                $('#errmailerHost').html(msg);
				$('#mailerHost').focus();
				$('#mailerHost').addClass('errorClass');
				return false;
				
			}else if(!mailerHost.match(dnsPattern)){
                $('#errmailerUserName').html('');
                $('#errmailerPassword').html('');
                $('#errmailerName').html('');				
                $('#errmailerHost').html('Invalid Host name');
				$('#mailerHost').focus();
				$('#mailerHost').addClass('errorClass');
				return false;
			}
			else if(!mailerPort.match(numericPattern)){	
                $('#errmailerUserName').html('');
                $('#errmailerPassword').html('');		
				$('#errmailerName').html('');
                $('#errmailerHost').html('');
                $('#errmailerPort').html(msg);
				$('#mailerPort').focus();
				$('#mailerPort').addClass('errorClass');
                return false;
                
			}else if(mailerSSL==""){			
				$('#errMaileName').html('');
				$('#errMailerHost').html('');
				$('#errMailerPort').html('');
				$('#errMailerPassword').html('');
				$('#mailerUsername').html();
				$('#mailerPassword').html();
				$('#mailerSSL').focus();
                return false;
                
			}else if(!fromMail.match(emailPattern)){
                $('#errMaileName').html('');
				$('#errMailerHost').html('');			
				$('#errMailerName').html('');
				$('#errMailerHost').html('');
				$('#errmailerPort').html('');
				$('#errmailerFromMail').html(msg);
				$('#mailerFromMail').addClass('errorClass');
				$('#mailerFromMail').focus();
				return false;
			}
			else{
				$('#errmailerName').html('');
				$('#errmailerHost').html('');
				$('#errmailerUsername').html();
				$('#errmailerPassword').html();
				$('#errmailerSSL').html();
				$('#errmailerPort').html('');
				$('#errmailerFromMail').html('');
				
				$('#mailerHost').removeClass('errorClass');
				$('#mailerPassword').removeClass('errorClass');
				$('#mailerUserName').removeClass('errorClass');
				$('#mailerPort').removeClass('errorClass');
				$('#mailerName').removeClass('errorClass');
				$('#mailerFromName').removeClass('errorClass');
				
				var querystring = jQuery('#smtpConfigForm').serialize();
				//if(pageAction=='addSmtp'){
				 addSmtpConfig(querystring);	
				//}
				//if(pageAction=='editSmtp'){
				//	jQuery.updateSmtpConfig(querystring);
				//}
				
				//return false;
			}
		return false;
    });	

    function addSmtpConfig(querystring){
      $.ajax({
            type:'POST',
            url:'addSmtpConfig',
            data:querystring,
            dataType:'html',
            beforeSend:function(){				
            },
            success:function(responseData, status, XMLHttpRequest){
              

                if(responseData=="empty"){
                    alert("All fields are necessary");	
                    return false;
                }else if(responseData=="Bad request"){
                    alert("Bad Request");	
                    return false;
                    
                }else if(responseData=="success"){
                    jQuery('#successmsg').html($('#createRecordAlert').val());	
                    jQuery('#successmsg').fadeIn().delay(1000).fadeOut('slow');						
                    setTimeout(function(){ window.location = 'smtpConfiguration';}, 1000);
                    return false;	
                    
                }else if(responseData=="update"){
                    $('#successmsg').html($('#updatedRecordAlert').val());
                    $('#successmsg').fadeIn().delay(1000).fadeOut('slow');
                    setTimeout(function(){window.location = 'smtpConfiguration';},1000);
                    return false;
                
                }else{
                    alert(responseData);
                }
            }
        
        });

	}
	
	function resetError()
	{	
		$('#errmailerName').html('');
				$('#errmailerHost').html('');
				$('#errmailerUsername').html();
				$('#errmailerPassword').html();
				$('#errmailerSSL').html();
				$('#errmailerPort').html('');
				$('#errmailerFromMail').html('');
				
				$('#mailerHost').removeClass('errorClass');
				$('#mailerPassword').removeClass('errorClass');
				$('#mailerUserName').removeClass('errorClass');
				$('#mailerPort').removeClass('errorClass');
				$('#mailerName').removeClass('errorClass');
				$('#mailerFromName').removeClass('errorClass');
}
});