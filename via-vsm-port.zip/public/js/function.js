$(document).ready(function(){
	$('.main-menu').each(function(){
		if($(this).hasClass('active') || $(this).hasClass('submenu')){
			$(this).find('.fa-angle-down').removeClass('text').addClass('text-active');
			$(this).find('.fa-angle-up').removeClass('text-active').addClass('text');
		}else{
			$(this).find('.fa-angle-down').addClass('text').removeClass('text-active');
			$(this).find('.fa-angle-up').addClass('text-active').removeClass('text');
		}
	});
	$('.menu').click(function(){
		$('.left-menu-footer').toggleClass('hide');
	});
	$('input[type=text], input[type=password],textarea').each(function(){
       if (this.value) {
           $(this).parent().find('.animate-lbl').addClass('activeCss');
       } 
    });
	
	$('input[type=text], input[type=password],textarea').on('focusin', function() {
		$(this).parent().find('.animate-lbl').addClass('activeCss');
	});
  
	$('input[type=text], input[type=password],textarea').on('focusout', function() {
		if (!this.value) {
			$(this).parent().find('.animate-lbl').removeClass('activeCss');
		}
	});
   
	setTimeout(function() {
      $('#slide-bottom-popup').modal('show');
    }, 1000);
	
	$(document).on('click','#closebtn, .cancel',function(){
		var imageUrl = $('#baseUrl').val()+"/public/img/icon_add.png";
		$('.media').html('<img src="'+imageUrl+'" width="40px" />');
		$('.registererror').html('');
	});
	// $(document).on('click','.addItemCss, .editItemCss',function(){
	// 	var imageUrl = $('#baseUrl').val()+"/public/img/icon_add_disabled.png";
	// 	$('.media').html('<img src="'+imageUrl+'" width="40px" />');
	// });
	// $('.addItemCss, .editItemCss').hover(function(){
	// 	var imageUrl = $('#baseUrl').val()+"/public/img/icon_add_hover.png";
	// 	$('.media').html('<img src="'+imageUrl+'" width="40px"/>');
	// }, function(){
	// 	var imageUrl = $('#baseUrl').val()+"/public/img/icon_add.png";
	// 	$('.media').html('<img src="'+imageUrl+'" width="40px"/>');
	// });

    if(jQuery("#currentPageName").val()=='liscenceInfo') {
			// $('a[data-toggle="tab"]').on('click', function(e) {				
			// 	localStorage.setItem('activeDssLicenseFont', $(e.target).attr('href'));
			// });
			// var activeLicenseFontTab = localStorage.getItem('activeDssLicenseFont');	
			// if(activeLicenseFontTab) {
			// 	let active = activeLicenseFontTab.replace(activeLicenseFontTab.substr(activeLicenseFontTab.length-7), 'Tab');				

			// 	$('#dssLicenseSetting').hide();
				
			// 	$('#dssLicenseTab').removeClass('active');			
			// 	$(active).addClass('active');
			// 	$(activeLicenseFontTab).show();
			// 	if(active == "#dssLicenseTab") {
			// 		$('#device_listing').show();
			// 	} else {
			// 		$('#device_listing').hide();
			// 	}				
			// }
			// $('#configTab').on('click', function(e) {
			// 	var clickedTabId = e.target.getAttribute('id');				
			// 	if(clickedTabId == "dssLicenseTab") {
			// 		$('#device_listing').show();
			// 		$("#dssFontSetting").hide();
			// 		$("#dssFontTab").removeClass("active");
			// 		$("#dssLicenseSetting").show();
			// 		$("#dssLicenseTab").addClass("active");
			// 	} else if (clickedTabId == "dssFontTab") {
			// 		$('#device_listing').hide();
			// 		$("#dssLicenseSetting").hide(); 
			// 		$("#dssLicenseTab").removeClass("active");
			// 		$("#dssFontSetting").show();
			// 		$("#dssFontTab").addClass("active");					
			// 	}
			// })			
		}
		// this is the functionality of click event on anchor tag on the liscenceInfo page extreme left ends
		
		// this is the functionality of click event on anchor tag on the dss template management page extreme left starts
		if(jQuery("#currentPageName").val()=='templateList') {
			$('a[data-toggle="tab"]').on('click', function(e) {				
				localStorage.setItem('dssTemplateType', $(e.target).attr('href'));
			});
			var activeTemplateTab = localStorage.getItem('dssTemplateType');	
			if(activeTemplateTab) {
				let active = activeTemplateTab.replace(activeTemplateTab.substr(activeTemplateTab.length-7), 'Tab');				
				$('#predefinedTemplateSetting').hide();
				$('#predefinedTemplateTab').removeClass('active');			
				$(active).addClass('active');
				$(activeTemplateTab).show();				
			}
			$('#configTab').on('click', function(e) {
				var clickedTabId = e.target.getAttribute('id');				
				if(clickedTabId == "predefinedTemplateTab") {
					$("#predefinedTemplateSetting").show();
					$("#predefinedTemplateTab").addClass("active");
					$("#customTemplateSetting").hide();
					$("#customTemplateTab").removeClass("active");
				} else if (clickedTabId == "customTemplateTab") {
					$("#predefinedTemplateSetting").hide(); 
					$("#predefinedTemplateTab").removeClass("active");
					$("#customTemplateSetting").show();
					$("#customTemplateTab").addClass("active");					
				}
			})			
		}
		// this is the functionality of click event on anchor tag on the dss template management page extreme left ends
});

	function passwordValidate(alphanumericVal,specialCharVal,capitalLtrVal,minCharVal,getBasicModeFlag,basicAuthPassword){
		var WhiteSpacePattern=/^[^\s]+$/;
		var alphanumricNoSpecial=/^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$/;
		var alphanumricPattern=/^(?=.*[0-9])(?=.*[a-z]).*$/i;
     	var specialCharPattern=/^(?=.*[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]).*$/;
		var capitalLtrPattern=/^(?=.*[A-Z]).*$/;
			if(getBasicModeFlag==1 && basicAuthPassword==''){
				//alert('Enter password!');
				$('#errminpassword').html('');
				$('#errbasicpass').html('Enter password!');
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();				
				return false;		
			}
            else if(basicAuthPassword.substring(0, 1)==' ') {
				$('#errminpassword').html('');
				$('#errbasicpass').html(jQuery('#spacemsg').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;
            }else if(basicAuthPassword.length>0 && !basicAuthPassword.match(WhiteSpacePattern)){
				$('#errminpassword').html('');
				$('#errbasicpass').html(jQuery('#spacemsg').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;
			}else if(alphanumericVal==1 && getBasicModeFlag==1 && !basicAuthPassword.match(alphanumricNoSpecial) && specialCharVal!=1 ){
		        $('#errminpassword').html('');
				$('#errbasicpass').html($('#AlphanumricMsg').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;			
			}else if(alphanumericVal==1 && getBasicModeFlag==1 && !basicAuthPassword.match(alphanumricPattern) && specialCharVal==1 ){
		        $('#errminpassword').html('');
				$('#errbasicpass').html($('#AlphanumricMsg').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;				
			}else if(specialCharVal==1 && getBasicModeFlag==1 && !basicAuthPassword.match(specialCharPattern)){
				$('#errminpassword').html('');
				$('#errbasicpass').html($('#specialCharMsg').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;			
    		}else if(capitalLtrVal==1 && getBasicModeFlag==1 && !basicAuthPassword.match(capitalLtrPattern)){
				$('#errminpassword').html('');
				$('#errbasicpass').html($('#capitalLtrMsg').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;
			}else if(getBasicModeFlag==1 && basicAuthPassword.length<minCharVal){
				$('#errminpassword').html('');
				$('#errbasicpass').html($('#minCharMsg1').val()+" "+minCharVal+" "+ $('#minCharMsg2').val());
				// $('#security').show();
				// $('#mainDiv section').not('#security').hide();
				// $('.systemIosCls').find('span').css('border-bottom','3px solid #f1c909');				
				// $('.tab').find('span').css('border-bottom','transparent');
				// $("a[href$='security']").find('span').css('border-bottom','3px solid #f1c909');
				openValidateTab('security');
				$('#viaBasicPassword1').focus();
				return false;		
		}
	}

	//Created by Ashu on 17May22. It is using for showing waiting image and page lock 
	function run_waitMe(effect){
		$('#loading_container').waitMe({
			effect: 'img',
			text: 'Please wait...',
			bg: '#38373785',
			color:'#69ffc3',
			source: '../public/img/bar-circle.gif'
		});
	}
	
	//Created by Ashu on 17May22. It is using for closing waiting image and page lock 
	function closewithme(){
		$('#loading_container').waitMe('hide')
	}

	//Created by Naveen on 23Sep22. It is used to remove XSS tags.
	function htmlEncode(str){
		return String(str).replace(/(<([^>]+)>)/ig,"");
	}

	//Created by Naveen on 12June24. Show custom popup update message.
	function updateMsg(msg){
		$('.update-message').remove();
		var html = '<div class="update-message closeNotifier"><span style="font-size:15px;">' + msg + '</span><button type="button" title="dismiss" class="close_btn"><svg viewBox="0 0 24 24" width="20" height="20"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></button></div>';
		$('body').append(html);
		setTimeout(function() { $(".update-message").remove(); }, 2000);
	}

	function updateRedMsg(msg){
		$('.updateRed-message').remove();
		var html = '<div class="updateRed-message closeNotifier"><span style="font-size:15px;line-height: 32px;">' + msg + '</span><button type="button" title="dismiss" class="close_btn"><svg viewBox="0 0 24 24" width="20" height="20" style="fill:#fff;"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></button></div>';
		$('body').append(html);
		setTimeout(function() { $(".updateRed-message").hide(); }, 1000);
	}

	$(document).on('click', '.close_btn', function(){
		$('.closeNotifier').hide();
	});

	//added by niraj to open error tab
	function openValidateTab(tab){
		$('.custom-tab[data-tab="settings"]').click();
		$('.via-settings-tab section').not('#'+tab).hide();
		$('#'+tab).show();
		$('.via-settings-tab .tab').find('span').css('color','#b2b9bf');
		$("a[href$='"+tab+"']").find('span').css('color','#69ffc3');
	}