		$( document ).ready( function( ) {
			var grp_id=[];
			var newResponseData="";
			var myResponseData="";
			var myResponseArray=[];
		 
			//end auth file code						  
		
				// $( '.tree li' ).each( function() {
				// 		$( this ).toggleClass( 'active' );
				// 		$( this ).children( 'ul' ).slideToggle( 'fast' );
				// });
		
				// $( '.tree li.parent > a' ).click( function( ) {
				// 		$( this ).parent().toggleClass( 'active' );
				// 		$( this ).parent().children( 'ul' ).slideToggle( 'fast' );
				// });
				
				// $( '#all' ).click( function() {
					
				// 	$( '.tree li' ).each( function() {
				// 		$( this ).toggleClass( 'active' );
				// 		$( this ).children( 'ul' ).slideToggle( 'fast' );
				// 	});
				// });
				$('.openTreeCss').parent("ul").children("ul").toggle(500);
				
				$(document).on("click",'.openTreeCss',function(){
				//$('.openTreeCss').click(function(){
					
					var val=$(this).children('i').attr('sign');
					if(val=='-'){
						$(this).find('.fa-angle-up').removeClass('fa-angle-up').addClass('fa-angle-down');
						$(this).children('i').attr('sign','+');
					}else{
						$(this).find('.fa-angle-down').removeClass('fa-angle-down').addClass('fa-angle-up');
						$(this).children('i').attr('sign','-');
					}
					
					$(this).parent("ul").children("ul").toggle(500);
					return false;
				});
			
			
			// check and uncheck the all checkboxes --start--
			$(document).on('click','#selAllChkBox',function(event){
			//$('#selAllChkBox').on('click',function(event) {  
				if(this.checked) { 
					$('.chkbox').each(function() { 
						this.checked = true;  
					});
				}else{
					$('.chkbox').each(function() { 
						this.checked = false; 
					});
				}
				});
			// check and uncheck the all checkboxes --end--
			
			//click on particular checkbox 
			$(document).on('click','.myalertcss',function(){
							
                            if($('#checLastClickSide').val()=='gatewaySide'){
                                    $('.chkbox').attr('checked',false);
                                    $('#selAllChkBox').attr('checked',false);
                                    $('#checLastClickSide').val('GroupSide');
                            }	
                            if($('#checLastClickSide').val()==''){
                                    $('#checLastClickSide').val('GroupSide');
                            }
                            if(jQuery(this).is(':checked')==true){
								
					var chkBoxName=$(this).attr('value');	
					
					jQuery.ajax({
                                                type:'POST',
                                                url:'getAllNestedChild',
                                                data:'grpName='+chkBoxName+'&flag=whenchecked',
                                                dataType:'html',
                                                async: false,
                                                success:function(responseData, status, XMLHttpRequest){
													
														var splitesp = responseData.split(',');
                                                        for(var i=0; i< splitesp.length; i++) {
															if(splitesp[i]!="")
                                                            $(".myalertcss:checkbox[value="+splitesp[i]+"]").prop("checked","true");
                                                        }	
                                                         //get the checked check boxes value
                                                            var checked_test_ids=[];
                                                            $('.myalertcss:checked').each(function () {
                                                                checked_test_ids.push($(this).val());
                                                            });

                                                        newResponseData += responseData+"#";
                                                        $("#hiddenBox").val(newResponseData);

                                                    jQuery.ajax({
                                                            type:'POST',
                                                            url:'getAlertByGroups',
                                                            data:'grpName='+checked_test_ids,
                                                            dataType:'html',
                                                            async: false,
                                                            success:function(responseData, status, XMLHttpRequest){
																
																$('#punchHtml').html(responseData);
                                                            }
                                                    });
                                                }					
					});
				}else{
					
					// unchecked right side gateway select all
					$('#selAllChkBox').attr('checked',false);
					var chkBoxName=$(this).attr('value');			
					$('.selAllGroupsCss').attr('checked',false);
					jQuery.ajax({
                                                type:'POST',
                                                url:'getAllNestedChild',
                                                data:'grpName='+chkBoxName+'&flag=whenUnchecked',
                                                dataType:'html',
                                                async: false,
                                                beforeSend : function(){
                                                },
                                                success:function(responseData, status, XMLHttpRequest){
													
                                                        //uncheck the child checkbox
                                                        var splitesp = responseData.split(',');
                                                        for(var i=0; i< splitesp.length; i++) {
															if(splitesp[i]!="")
                                                             $(".myalertcss:checkbox[value="+splitesp[i]+"]").prop("checked",false);
                                                        }
                                                                 //get the checked check boxes value	
                                                        var chkBoxName=[];
                                                        $('.myalertcss:checked').each(function () {
                                                            chkBoxName.push($(this).val());
                                                        });

                                                        jQuery.ajax({
                                                                type:'POST',
                                                                url:'getAlertByGroups',
                                                                data:'grpName='+chkBoxName,
                                                                dataType:'html',
                                                                async: false,
                                                                success:function(responseData, status, XMLHttpRequest){
																	
																	$('#punchHtml').html(responseData);
                                                                }
                                                        });
                                                }					
                                        });	
				  }
                        });
                        
                        
		// end of click myalertcss	
			$('.selAllGroupsCss').click(function(){	
				//alert('hi');
														 
				if($('#checLastClickSide').val()==''){
					$('#checLastClickSide').val('GroupSide');
				}							 
				var chkBoxName = [];								 
				if(this.checked) { // check select status
					$('.myalertcss').each(function() { //loop through each checkbox	
						if(!$(this).parent('.radio').hasClass('dis22')){						
						chkBoxName.push($(this).attr('value'));
						$('.'+$(this).attr('rel')).attr('checked',true);
						this.checked = true;  //select all checkboxes with class "checkbox1" 
						}						
					});
					var flag='whenCheckedAll';
					// check right side gateway select all
					$('#selAllChkBox').attr('checked',true);
				}else{
					$('.myalertcss').each(function() { //loop through each checkbox
						this.checked = false; //deselect all checkboxes with class "checkbox1"  
						$('.'+$(this).attr('rel')).attr('checked',false);
						$('.chkbox').attr('checked',false);
					});  
					var flag='whenUnCheckedAll';
					// check right side gateway unselect all
					$('#selAllChkBox').attr('checked',false);
				}
				
                            var chkBoxName=[];
                            $('.myalertcss:checked').each(function () {
                                chkBoxName.push($(this).val());
                            });
                            jQuery.ajax({
                                        type:'POST',
                                        url:'getAlertByGroups',
                                        data:'grpName='+chkBoxName,
                                        dataType:'html',
                                        async: false,
                                        success:function(responseData, status, XMLHttpRequest){
                                            $('#punchHtml').html(responseData);
                                        }
                                });
			});

    
});
 