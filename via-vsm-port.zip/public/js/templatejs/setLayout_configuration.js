$(document).ready(function(){
	var checkRoomCode=(jQuery('#activationRoomCode').is(':checked'))?1:0;
	if(checkRoomCode==0){
		$('.activationRoomCodeGrouping').attr('disabled',true);
		$('#alwaysShowOnWallp').attr('checked',false);		
	}else{
		$('.activationRoomCodeGrouping').attr('disabled',false);
	}

$(document).on('click','.colpick_cancel,.colpick_submit',function(){
    $('.colpick').hide();
});
$(document).on('mouseover','.color-box-level',function(event) {
        var spanValLevel=jQuery(this).attr('rev');
        spanValLevel=spanValLevel.substr(0, spanValLevel.length-2);
        if(spanValLevel=='backgroundColor_level'){
            $(".colpick_show_bor").css('display','block');
        }else{
            $(".colpick_show_bor").css('display','none');
        }
	$('.color-box-level').colpick({
		colorScheme:'dark',
		layout:'rgbhex',
		color:'ffffff',
		onSubmit:function(hsb,hex,rgb,el,colorNoneFlag) {	

		var getspanVal=el.id;//jQuery(this).attr('rev');
		//alert(getspanVal);
		var splitgetspanValbydash=getspanVal.split('-');		
		var splitgetspanValbyUnderscore=getspanVal.split('_');
		var getElementId='backgroundColor_level-'+splitgetspanValbydash[1];
		var getElementIdFont='fontColor_level-'+splitgetspanValbydash[1];
		var getElementIdBorder='borderColor_level-'+splitgetspanValbydash[1];
		
		var getbackgroundid=splitgetspanValbyUnderscore[1]+'-txt';	
			//for set background color
			if(getspanVal==getElementId){
				//add condition for making background color tranparent when set 'None' from color picker
				if(colorNoneFlag==1){
					$('.'+getbackgroundid).css('background-color', 'transparent');
					$('#'+getspanVal).css('background-color', 'transparent');	
					$(".showBorder").prop('checked',false);
					$(".showBorder").val(0);
					var hex='transparent';
				}else{	
					$('.'+getbackgroundid).css('background-color', '#'+hex);
					$('#'+getbackgroundid.replace("txt", "opacity")).prop('disabled','');
					$('#'+getbackgroundid.replace("txt", "opacity")).val(1);					
				}
			}	
			//for set font color
			if(getspanVal==getElementIdFont){
				//font format 'level-1-txt'
				$('.'+splitgetspanValbyUnderscore[1]+'-txt').css('color', '#'+hex);				
			
			}
			//for set border color
			if(getspanVal==getElementIdBorder){
				//font format 'level-1-txt'
				$('.'+splitgetspanValbyUnderscore[1]+'-txt').css('border-color', '#'+hex);				
			
			}
			$(el).css('background-color', '#'+hex);
			$(el).colpickHide();
		}						
	});
});


	$('.color-box').click(function(){
	//$(document).on('click','.color-box',function(event) {								   
		spanVal=jQuery(this).attr('rev');
		if(spanVal=='backgroundColor_roomname-1' || spanVal=='backgroundColor_roomname-2' || spanVal=='backgroundColor_roomcode-1' || spanVal=='backgroundColor_datetime-1' || spanVal=='backgroundColor_datetime-1' || spanVal=='backgroundColor_time-1' || spanVal=='backgroundColor_meetingtitle-1' || spanVal=='backgroundColor_label-1' || spanVal=='backgroundColor_label-2' || spanVal=='backgroundColor_roomcodepopup-1' ||  spanVal=='backgroundColor_datetimecombined-1'){
			$(".colpick_show_bor").css('display','block');
			}else{
				$(".colpick_show_bor").css('display','none');
			}
	
	})
						   
	$('.color-box').colpick({
		colorScheme:'dark',
		layout:'rgbhex',
		color:'ffffff',
		onSubmit:function(hsb,hex,rgb,el,colorNoneFlag) {						
			var getFrameValue=jQuery('#getFrameValue').val();	
			//$.appendFile(spanVal,hex);
			if(spanVal=='backgroundColor_meetingtitle-1' || spanVal=='fontColor_meetingtitle-1'){
				var getFrameValue='meeting_topHeader1_css';
			}
			if(spanVal=='backgroundColor_meeting-1'){
				var getFrameValue='meeting-1-css';
			}
			
			if(spanVal=='backgroundColor_roomname-1' || spanVal=='backgroundColor_roomname-2' || spanVal=='backgroundColor_roomcode-1' || spanVal=='backgroundColor_datetime-1' || spanVal=='backgroundColor_datetime-1' || spanVal=='backgroundColor_time-1' || spanVal=='backgroundColor_meetingtitle-1' || spanVal=='backgroundColor_meeting-1' || spanVal=='backgroundColor_label-1' || spanVal=='backgroundColor_label-2' || spanVal=='backgroundColor_roomcodepopup-1' || spanVal=='backgroundColor_meetingNotify-1' || spanVal=='backgroundColor_datetimecombined-1' || spanVal=='backgroundColor_remainingTime-1'){
				//add condition for making background color tranparent when set 'None' from color picker
				if(colorNoneFlag==1){
					$('.'+getFrameValue).css('background-color', 'transparent');
					$('#'+spanVal).css('background-color', 'transparent');	
					$(".showBorder").prop('checked',false);
					$(".showBorder").val(0);
					var hex='transparent';
				}else{
					$('.'+getFrameValue).css('background-color', '#'+hex);
					var splitbackgroundColor=spanVal.split('_');
					//alert(splitbackgroundColor);
					$('#'+splitbackgroundColor[1]+'_opacity').attr('disabled',false);
					$('#'+splitbackgroundColor[1]+'_opacity').val(1);					
				}
			}
			
			if(spanVal=='borderColor_roomname-1'|| spanVal=='borderColor_roomname-2' || spanVal=='borderColor_roomcode-1' || spanVal=='borderColor_datetime-1' || spanVal=='borderColor_datetime-1' || spanVal=='borderColor_time-1' || spanVal=='borderColor_label-1' || spanVal=='borderColor_label-2' || spanVal=='borderColor_roomcodepopup-1' || spanVal=='borderColor_meetingNotify-1' || spanVal=='borderColor_datetimecombined-1' || spanVal=='borderColor_remainingTime-1'){
				$('.'+getFrameValue).css('border-color', '#'+hex);
			}
			if(spanVal=='fontColor_roomname-1' || spanVal=='fontColor_roomname-2' || spanVal=='fontColor_roomcode-1' || spanVal=='fontColor_datetime-1' || spanVal=='fontColor_datetime-1' || spanVal=='fontColor_time-1' || spanVal=='fontColor_meetingtitle-1' || spanVal=='fontColor_label-1' || spanVal=='fontColor_label-2' || spanVal=='fontColor_roomcodepopup-1' || spanVal=='fontColor_meetingNotify-1' || spanVal=='fontColor_datetimecombined-1' || spanVal=='fontColor_remainingTime-1'){				
				$('.'+getFrameValue).css('color', '#'+hex);
                if(spanVal=='fontColor_meetingNotify-1'){
					$('.meetingNotify-1_top').css('color', '#'+hex);
					$('.meetingNotify-1_middle').css('color', '#'+hex);
					$('.meetingNotify-1_bottom').css('color', '#'+hex);
				}
                if(spanVal=='fontColor_remainingTime-1'){
					$('.remainingTime-1_top').css('color', '#'+hex);
					$('.remainingTime-1_middle').css('color', '#'+hex);
					$('.remainingTime-1_bottom').css('color', '#'+hex);
				}
			}
				
			var meetingRecords=$('#showEventsRecords').val();
			//alert(spanVal)
			for(var r=1;r<=meetingRecords;r++){
				//$("#upcomingeventsRow-"+r);
				if(r==1){
					if(spanVal=='inusecolorSpan'){
						$('#upcomingeventscolor-'+r).css({"color": "#"+hex, "border-left": "5px solid "+"#"+hex})
					}
					if(spanVal=='inusefontcolorSpan'){						
						$('#upcomingeventsfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsTitlefontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsOrgfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsBookedfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsBookedfontcolor-'+r).css({"color": "#"+hex})
					}
					
				}
				if(r==2){
					if(spanVal=='availablecolorSpan'){
						$('#upcomingeventscolor-'+r).css({"color": "#"+hex, "border-left": "5px solid "+"#"+hex})
					}
					if(spanVal=='availablefontcolorSpan'){
						$('#upcomingeventsfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsTitlefontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsOrgfontcolor-'+r).css({"color": "#"+hex})
                        $('#upcomingeventsBookedfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsBookedfontcolor-'+r).css({"color": "#"+hex})
					}					
				}
				
				if(r>2){
					if(spanVal=='upcomingcolorSpan'){
						$('#upcomingeventscolor-'+r).css({"color": "#"+hex, "border-left": "5px solid "+"#"+hex})
					}
					if(spanVal=='upcomingfontcolorSpan'){
						$('#upcomingeventsfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsTitlefontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsOrgfontcolor-'+r).css({"color": "#"+hex})
						$('#upcomingeventsBookedfontcolor-'+r).css({"color": "#"+hex})
					}
				}	
			}//end of for loop
			
			$(el).css('background-color', '#'+hex);
			$(el).colpickHide();	
		}
	});

	$("#refreshTime").change(function(){
		var selRevName=$(this).attr('rev');
		var selBoxVal=$('#refreshTime').val();		
		//jQuery.serverConfiguration(selRevName,selBoxVal);
	});
	
					   
	jQuery('#applyBtn').click(function(){		
		var hostNamePattern=/^[a-zA-Z0-9. \-]+$/;
		var fileName=$(this).attr('rev');				
		var inputFieldVal=jQuery('#ipAddress').val();
		if(inputFieldVal==""){
			alert(jQuery('#alertRoomName').val());
			jQuery('#ipAddress').focus();
			return false;
		}else if(!inputFieldVal.match(hostNamePattern)){
			alert('Invalid hostname entered. Only alphanumeric,dot,space and dash is allowed.');
			jQuery('#ipAddress').focus();
			return false;
		}
	});

	jQuery('.overlayCss').click(function(){		
		var overlayChkBoxVal = jQuery(this).prop('checked')?1:0;			
		if(overlayChkBoxVal==1){
			$('#overlayChkBoxVal').val(1);
			jQuery('#autoHideDD').attr('disabled',false);
            //jQuery('#autoHideDD').css('background-color','#404042');
			$('#activateAutoHideVal').val(1);
		}else{
			$('#overlayChkBoxVal').val(0);
			$('#autoHideDD').val(0);
			jQuery('#autoHideDD').attr('disabled',true);
            //jQuery('#autoHideDD').css('background-color','#707070');
			$('#activateAutoHideVal').val(0)	
		}
	});
	
	//$('.commontogglecss').click(function(){
	$(document).on('click','.commontogglecss',function(event) {										 
		var getToggleBoxVal=jQuery(this).prop('checked')?1:0;
		if(jQuery(this).attr('id')=='showOrgBtn' || jQuery(this).attr('id')=='showTitleBtn'){
			var inusefontcolor=rgb2hex($('#inusefontcolorSpan').css('backgroundColor'));
			var availablefontcolor=rgb2hex($('#availablefontcolorSpan').css('backgroundColor'));
			var upcomingfontcolor=rgb2hex($('#upcomingfontcolorSpan').css('backgroundColor'));			
			
			var meetingtitlefontsize=$('#meetingtitle-1_fontsize').val();
			var meetingTitleOrgfont=parseInt(parseInt(meetingtitlefontsize)/1.5)+'px';			
			var meetingRecords=$('#showEventsRecords').val();
			if(jQuery(this).attr('id')=='showOrgBtn' && getToggleBoxVal==1){
				for(var r=1;r<=meetingRecords;r++){
					if(r==1){
						var strfontcolor=inusefontcolor;
					}
					if(r==2){
						var strfontcolor=availablefontcolor;
					}
					if(r>2){
						var strfontcolor=upcomingfontcolor;
					}
					if($("#upcomingeventsOrgRow-"+r).length==0){
                        $('#upcomingeventsBookedRow-'+r).remove();
						if( $("#upcomingeventsTitleRow-"+r).length ) {
							$("#upcomingeventsTitleRow-"+r).after('<div class="divTableRow" id=upcomingeventsOrgRow-'+r+'><div class="divTableCell"><span id=upcomingeventsOrgfontcolor-'+r+' style="color:'+strfontcolor+';font-size:'+meetingTitleOrgfont+';vertical-align:top;"> Organizer</span></div></div>');
							
						}else{
							$("#upcomingeventsRow-"+r).after('<div class="divTableRow" id=upcomingeventsOrgRow-'+r+'><div class="divTableCell"><span id=upcomingeventsOrgfontcolor-'+r+' style="color:'+strfontcolor+';font-size:'+meetingTitleOrgfont+';vertical-align:top;"> Organizer</span></div></div>');	
						}
					}
				}
			}
			if(jQuery(this).attr('id')=='showTitleBtn' && getToggleBoxVal==1){	
				for(var r=1;r<=meetingRecords;r++){
					if(r==1){
						var strfontcolor=inusefontcolor;
					}
					if(r==2){
						var strfontcolor=availablefontcolor;
					}
					if(r>2){
						var strfontcolor=upcomingfontcolor;
					}					
					if($("#upcomingeventsTitleRow-"+r).length==0){
                        $('#upcomingeventsBookedRow-'+r).remove();
						$("#upcomingeventsRow-"+r).after('<div class="divTableRow" id=upcomingeventsTitleRow-'+r+'><div class="divTableCell"><span id=upcomingeventsTitlefontcolor-'+r+' style="color:'+strfontcolor+';font-size:'+meetingTitleOrgfont+';vertical-align:top;"> Title</span></div></div>');
					}
				}
			}
		}
		
		if((jQuery(this).attr('id')=='showOrgBtn' && getToggleBoxVal==0) || (jQuery(this).attr('id')=='showTitleBtn' && getToggleBoxVal==0)){
			var inusefontcolor=rgb2hex($('#inusefontcolorSpan').css('backgroundColor'));
            var availablefontcolor=rgb2hex($('#availablefontcolorSpan').css('backgroundColor'));
			var upcomingfontcolor=rgb2hex($('#upcomingfontcolorSpan').css('backgroundColor'));
			var meetingBookedfontsize=parseInt(parseInt($('#meetingtitle-1_fontsize').val())/1.5)+'px';
			var meetingRecords=$('#showEventsRecords').val();
			//alert(meetingRecords);
			if(jQuery(this).attr('id')=='showOrgBtn' && getToggleBoxVal==0){
				for(var r=1;r<=meetingRecords;r++){
                    if(r==1){
						var strfontcolor=inusefontcolor;
					}
					if(r==2){
						var strfontcolor=availablefontcolor;
					}
					if(r>2){
						var strfontcolor=upcomingfontcolor;
					}
					 $('#upcomingeventsOrgRow-'+r).remove();
                     $('#upcomingeventsBookedRow-'+r).remove();
					 if(jQuery('#showTitleBtn').prop('checked')==false){
						$("#upcomingeventsRow-"+r).after('<div class="divTableRow" id=upcomingeventsBookedRow-'+r+'><div class="divTableCell"><span id=upcomingeventsBookedfontcolor-'+r+' style="color:'+strfontcolor+';font-size:'+meetingBookedfontsize+';vertical-align:top;"> Booked</span></div></div>');
					 }
				}
			}
			if(jQuery(this).attr('id')=='showTitleBtn' && getToggleBoxVal==0){	
				for(var r=1;r<=meetingRecords;r++){
                    if(r==1){
						var strfontcolor=inusefontcolor;
					}
					if(r==2){
						var strfontcolor=availablefontcolor;
					}
					if(r>2){
						var strfontcolor=upcomingfontcolor;
					}
					$('#upcomingeventsTitleRow-'+r).remove();
					$('#upcomingeventsBookedRow-'+r).remove();
					if(jQuery('#showOrgBtn').hasClass('active')){
						$("#upcomingeventsRow-"+r).after('<div class="divTableRow" id=upcomingeventsBookedRow-'+r+'><div class="divTableCell"><span id=upcomingeventsBookedfontcolor-'+r+' style="color:'+strfontcolor+';font-size:'+meetingBookedfontsize+';vertical-align:top;"> Booked</span></div></div>');
					}
				}
			}	
		}

		var toggleId=jQuery(this).attr('id');		
		if(getToggleBoxVal==1){
			jQuery('#'+toggleId).prop('checked',true);
		}else{
			jQuery('#'+toggleId).prop('checked',false);
		}		
	});
	
	
	jQuery('#autoHideDD').change(function(){			
			var autoHideDD=$('#autoHideDD').val();
			
	});
	
// Disabled all elements when select HQ in cinfiguration. Added on 7Dec16. Move from  upside

	if($("#selConfigSettingOption").val()==1){	
		  jQuery('.makeDisabled').prop("disabled", true);
	}

 	$('.userTooltip').hover(function(){
                // Hover over code
                var title = $(this).attr('rel');
                $(this).data('tipText', title).removeAttr('title');
                $('<p class="tooltip"></p>')
                .text(title)
                .appendTo('body')
                .fadeIn('slow');
        }, function() {
                // Hover out code
                $(this).attr('rel', $(this).data('tipText'));
                $('.tooltip').remove();
        }).mousemove(function(e) {
                var width=$(window).width();
                var mousex = e.clientX-parseInt(width/5);//Get X coordinates
                var mousey = e.clientY-10;               //Get Y coordinates   
                $('.tooltip')
                .css({ position: 'fixed', top: mousey, left: mousex, width: '100px', })
      });
	


    $(document).on('click','.qrActivateClass',function(event) {	
		var getFeatureName = jQuery(this).attr('id');		
		//alert(getFeatureName)
		var getFeatureNamevalue = $('#'+getFeatureName).prop( "checked" )?1:0;
		//alert(getFeatureNamevalue);
		if(getFeatureName=='qrCodeChkbox' && getFeatureNamevalue==1){			
			jQuery('#qrBypassChkbox').prop('checked',true);		
		}
		if(getFeatureName=='qrCodeChkbox' && getFeatureNamevalue==0){
			jQuery('#qrBypassChkbox').prop('checked',false);
			jQuery('#qrTopChkbox').prop('checked',false);
		}
	});											   

        
		$(document).on('click','.propertytab',function(event) {								 
			//alert($('#tabVal').val());	
			//alert($(this).attr('id'));
			if($('#tabVal').val()=='roomname-1'){
			   if($(this).attr('id')=='roomname-1-propertytab'){
					$('#roomname-1-propertytab').removeClass("inactive_tab");
					$('#roomname-1-propertytab').addClass("active_tab");
					$('#roomname-1-colortab').removeClass("active_tab");
					$('#roomname-1-colortab').addClass("inactive_tab");	
					$('.roomname-1-propertytab').show();
					$('.roomname-1-colortab').hide();
				   
			   }
			   
			   if($(this).attr('id')=='roomname-1-colortab'){
					$('#roomname-1-colortab').removeClass("inactive_tab");
					$('#roomname-1-colortab').addClass("active_tab");
					$('#roomname-1-propertytab').removeClass("active_tab");
					$('#roomname-1-propertytab').addClass("inactive_tab");
					
					$('.roomname-1-colortab').show();
					$('.roomname-1-propertytab').hide();  
			   } 
			}
			
			if($('#tabVal').val()=='roomname-2'){
			   if($(this).attr('id')=='roomname-2-propertytab'){
					$('#roomname-2-propertytab').removeClass("inactive_tab");
					$('#roomname-2-propertytab').addClass("active_tab");
					$('#roomname-2-colortab').removeClass("active_tab");
					$('#roomname-2-colortab').addClass("inactive_tab");	
					$('.roomname-2-propertytab').show();
					$('.roomname-2-colortab').hide();
				   
			   }
				
			   if($(this).attr('id')=='roomname-2-colortab'){
					$('#roomname-2-colortab').removeClass("inactive_tab");
					$('#roomname-2-colortab').addClass("active_tab");
					$('#roomname-2-propertytab').removeClass("active_tab");
					$('#roomname-2-propertytab').addClass("inactive_tab");
					
					$('.roomname-2-colortab').show();
					$('.roomname-2-propertytab').hide();
				   
			   }
				
				
			}
			   
			if($('#tabVal').val()=='roomcode-1'){
			   if($(this).attr('id')=='roomcode-1-propertytab'){
					$('#roomcode-1-propertytab').removeClass("inactive_tab");
					$('#roomcode-1-propertytab').addClass("active_tab");
					$('#roomcode-1-colortab').removeClass("active_tab");
					$('#roomcode-1-colortab').addClass("inactive_tab");	
					$('.roomcode-1-propertytab').show();
					$('.roomcode-1-colortab').hide();
				   
			   }
				
			   if($(this).attr('id')=='roomcode-1-colortab'){
					$('#roomcode-1-colortab').removeClass("inactive_tab");
					$('#roomcode-1-colortab').addClass("active_tab");
					$('#roomcode-1-propertytab').removeClass("active_tab");
					$('#roomcode-1-propertytab').addClass("inactive_tab");
					$('.roomcode-1-colortab').show();
					$('.roomcode-1-propertytab').hide();   
			   }	
			}
			   
			if($('#tabVal').val()=='meeting-1'){
			   if($(this).attr('id')=='meeting-1-propertytab'){
					$('#meeting-1-propertytab').removeClass("inactive_tab");
					$('#meeting-1-propertytab').addClass("active_tab");
					$('#meeting-1-colortab').removeClass("active_tab");
					$('#meeting-1-colortab').addClass("inactive_tab");	
					$('.meeting-1-propertytab').show();
					$('.meeting-1-colortab').hide();
			   }
				
			   if($(this).attr('id')=='meeting-1-colortab'){
					$('#meeting-1-colortab').removeClass("inactive_tab");
					$('#meeting-1-colortab').addClass("active_tab");
					$('#meeting-1-propertytab').removeClass("active_tab");
					$('#meeting-1-propertytab').addClass("inactive_tab");
					
					$('.meeting-1-colortab').show();
					$('.meeting-1-propertytab').hide();
			   }
			}
			   
			if($('#tabVal').val()=='datetime-1'){
			   if($(this).attr('id')=='datetime-1-propertytab'){
					$('#datetime-1-propertytab').removeClass("inactive_tab");
					$('#datetime-1-propertytab').addClass("active_tab");
					$('#datetime-1-colortab').removeClass("active_tab");
					$('#datetime-1-colortab').addClass("inactive_tab");	
					$('.datetime-1-propertytab').show();
					$('.datetime-1-colortab').hide();   
			   }
				
			   if($(this).attr('id')=='datetime-1-colortab'){
					$('#datetime-1-colortab').removeClass("inactive_tab");
					$('#datetime-1-colortab').addClass("active_tab");
					$('#datetime-1-propertytab').removeClass("active_tab");
					$('#datetime-1-propertytab').addClass("inactive_tab");
					
					$('.datetime-1-colortab').show();
					$('.datetime-1-propertytab').hide();
			   }
			}
			
			if($('#tabVal').val()=='meetingNotify-1'){
			   if($(this).attr('id')=='meetingNotify-1-propertytab'){
					$('#meetingNotify-1-propertytab').removeClass("inactive_tab");
					$('#meetingNotify-1-propertytab').addClass("active_tab");
					$('#meetingNotify-1-colortab').removeClass("active_tab");
					$('#meetingNotify-1-colortab').addClass("inactive_tab");	
					$('.meetingNotify-1-propertytab').show();
					$('.meetingNotify-1-colortab').hide();   
			   }
				
			   if($(this).attr('id')=='meetingNotify-1-colortab'){
					$('#meetingNotify-1-colortab').removeClass("inactive_tab");
					$('#meetingNotify-1-colortab').addClass("active_tab");
					$('#meetingNotify-1-propertytab').removeClass("active_tab");
					$('#meetingNotify-1-propertytab').addClass("inactive_tab");
					
					$('.meetingNotify-1-colortab').show();
					$('.meetingNotify-1-propertytab').hide();
			   }
			}
                        
            if($('#tabVal').val()=='remainingTime-1'){
			   if($(this).attr('id')=='remainingTime-1-propertytab'){
					$('#remainingTime-1-propertytab').removeClass("inactive_tab");
					$('#remainingTime-1-propertytab').addClass("active_tab");
					$('#remainingTime-1-colortab').removeClass("active_tab");
					$('#remainingTime-1-colortab').addClass("inactive_tab");	
					$('.remainingTime-1-propertytab').show();
					$('.remainingTime-1-colortab').hide();	   
			   }
				
			   if($(this).attr('id')=='remainingTime-1-colortab'){
					$('#remainingTime-1-colortab').removeClass("inactive_tab");
					$('#remainingTime-1-colortab').addClass("active_tab");
					$('#remainingTime-1-propertytab').removeClass("active_tab");
					$('#remainingTime-1-propertytab').addClass("inactive_tab");
					
					$('.remainingTime-1-colortab').show();
					$('.remainingTime-1-propertytab').hide();
			   }
			}
			
			if($('#tabVal').val()=='time-1'){
			   if($(this).attr('id')=='time-1-propertytab'){
					$('#time-1-propertytab').removeClass("inactive_tab");
					$('#time-1-propertytab').addClass("active_tab");
					$('#time-1-colortab').removeClass("active_tab");
					$('#time-1-colortab').addClass("inactive_tab");	
					$('.time-1-propertytab').show();
					$('.time-1-colortab').hide();	   
			   }
				
			   if($(this).attr('id')=='time-1-colortab'){
					$('#time-1-colortab').removeClass("inactive_tab");
					$('#time-1-colortab').addClass("active_tab");
					$('#time-1-propertytab').removeClass("active_tab");
					$('#time-1-propertytab').addClass("inactive_tab");
					
					$('.time-1-colortab').show();
					$('.time-1-propertytab').hide();
			   }
			}
			
		if($(this).attr('id').substring(0,5)=='level'){	
			//alert(getspanVal);
			var splitidbydash=$(this).attr('id').split('-');	
			var propertyTabId=splitidbydash[0]+'-'+parseInt(splitidbydash[1])+'-propertytab';
			var colorTabId=splitidbydash[0]+'-'+parseInt(splitidbydash[1])+'-colortab';
		
			   if($(this).attr('id')==propertyTabId){
					$('#'+propertyTabId).removeClass("inactive_tab");
					$('#'+propertyTabId).addClass("active_tab");
					$('#'+colorTabId).removeClass("active_tab");
					$('#'+colorTabId).addClass("inactive_tab");					
					$('.'+propertyTabId).show();
					$('.'+colorTabId).hide();
				   
			   }
				
			   if($(this).attr('id')==colorTabId){	
					$('#'+colorTabId).removeClass("inactive_tab");
					$('#'+colorTabId).addClass("active_tab");
					$('#'+propertyTabId).removeClass("active_tab");
					$('#'+propertyTabId).addClass("inactive_tab");					
					$('.'+colorTabId).show();
					$('.'+propertyTabId).hide();
				   
			   }
			}
			
			   

			if($('#tabVal').val()=='roomcodepopup-1'){
			   if($(this).attr('id')=='roomcodepopup-1-propertytab'){
					$('#roomcodepopup-1-propertytab').removeClass("inactive_tab");
					$('#roomcodepopup-1-propertytab').addClass("active_tab");
					$('#roomcodepopup-1-colortab').removeClass("active_tab");
					$('#roomcodepopup-1-colortab').addClass("inactive_tab");	
					$('.roomcodepopup-1-propertytab').show();
					$('.roomcodepopup-1-colortab').hide();
				   
			   }
				
			   if($(this).attr('id')=='roomcodepopup-1-colortab'){
					$('#roomcodepopup-1-colortab').removeClass("inactive_tab");
					$('#roomcodepopup-1-colortab').addClass("active_tab");
					$('#roomcodepopup-1-propertytab').removeClass("active_tab");
					$('#roomcodepopup-1-propertytab').addClass("inactive_tab");					
					$('.roomcodepopup-1-colortab').show();
					$('.roomcodepopup-1-propertytab').hide();
				   
			   }
			}
			
			if($('#tabVal').val()=='datetimecombined-1'){
			   if($(this).attr('id')=='datetimecombined-1-propertytab'){
					$('#datetimecombined-1-propertytab').removeClass("inactive_tab");
					$('#datetimecombined-1-propertytab').addClass("active_tab");
					$('#datetimecombined-1-colortab').removeClass("active_tab");
					$('#datetimecombined-1-colortab').addClass("inactive_tab");	
					$('.datetimecombined-1-propertytab').show();
					$('.datetimecombined-1-colortab').hide();
				   
			   }
				
			   if($(this).attr('id')=='datetimecombined-1-colortab'){
					$('#datetimecombined-1-colortab').removeClass("inactive_tab");
					$('#datetimecombined-1-colortab').addClass("active_tab");
					$('#datetimecombined-1-propertytab').removeClass("active_tab");
					$('#datetimecombined-1-propertytab').addClass("inactive_tab");
					
					$('.datetimecombined-1-colortab').show();
					$('.datetimecombined-1-propertytab').hide();  
			   }	
			}	
        });
		
		$(document).on('click','.borderchkboxcss',function(event) {	
			var getToggleBoxVal=jQuery(this).prop('checked')?1:0;
			var clickid=$(this).attr('id');
			//alert(clickid +' and '+jQuery('#'+clickid).is(':checked'))
			var splitId=clickid.split('-');
			var getWidgetid=splitId[0]+'-'+splitId[1]+'-txt';
			if(getToggleBoxVal==1){
				//hide colorpicker for widget
				$('#'+splitId[0]+'-'+splitId[1]+'-html').show();
				$('.'+getWidgetid.replace("txt", "css")).css('border-color', '#35acf8');
				$('#borderColor_'+splitId[0]+'-'+splitId[1]).css('background-color', '#35acf8');	
			}else{
				//show colorpicker on false
				$('#'+splitId[0]+'-'+splitId[1]+'-html').hide();
				$('.'+getWidgetid.replace("txt", "css")).css('border-color', '#35acf8');
				$('#borderColor_'+splitId[0]+'-'+splitId[1]).css('background-color', '#35acf8');
			}
		})

});

function rgb2hex(rgb){
 rgb = rgb.match(/^rgba?[\s+]?\([\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?,[\s+]?(\d+)[\s+]?/i);
 return (rgb && rgb.length === 4) ? "#" +
  ("0" + parseInt(rgb[1],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[2],10).toString(16)).slice(-2) +
  ("0" + parseInt(rgb[3],10).toString(16)).slice(-2) : '';
}
