$(document).ready(function(){
    jQuery('#caleSettingNote').html($("#calSettingMsgTxt").val());
    //$(".stepthree").prop('disabled', true);
    jQuery('#caleSettingNote').html($("#calSettingMsgTxt").val());
    $("#calname").prop('disabled', true);
    //$('#calname').css("background-color","#707070"); 

    $(document).on('change', '#access_type', function(){
        var access_val=$('#access_type').val();
        if (access_val==1 || access_val==2) {
            $("#calname").prop('disabled', false);
            //$('#calname').css("background-color","#404042");
        }else{
            $("#calname").val('');
            $("#calname").prop('disabled', true);
            //$('#calname').css("background-color","#707070");
        }
    });
   
   $(document).on('change', '#access', function(){
	var access_val=$('#access').val();
        if (access_val==1 || access_val==2) {
            $("#calname1").prop('disabled', false);
            //$('#calname1').css("background-color","#404042");
        }else{
            $("#calname1").val('');
            $("#calname1").prop('disabled', true);
            //$('#calname1').css("background-color","#707070");
        }
   });
	
	var emailPattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,10}$/;
	$(document).on('click', '#btnOk', function(){
		var caluserid=$('#caluserid').val();
		var caluserpass=$('#caluserpass').val();
		var permission_type=$('#access_type').val();
		var calname="";
		if(permission_type !=0){
			calname=$('#calname').val();
			if(calname==''){
				jQuery('#calname').removeClass('normalmsg').addClass('redmsg');
				jQuery('#errcalname').html("Enter Calendar name");
				$('#calname').focus();					
				return false;
			}
		}
		
		if(caluserid==''){
			jQuery('#caluserid').removeClass('normalmsg').addClass('redmsg');
			jQuery('#erruname').html($("#jqryMsgEntrName").val());
			$('#caluserid').focus();					
			return false;	
		}else if(!caluserid.match(emailPattern)){
			jQuery('#caluserid').removeClass('normalmsg').addClass('redmsg');
			jQuery('#erruname').html('Invalid email id');
			$('#caluserid').focus();			
			return false;
		}else if(caluserpass==''){
			jQuery('#erruname').html('');
			jQuery('#caluserid').removeClass('redmsg').addClass('normalmsg');
			jQuery('#caluserpass').removeClass('normalmsg').addClass('redmsg');
			jQuery('#errpassword').html('Enter password');
			$('#caluserpass').focus();
			return false;
		}else{
			$("#btnOk").val("Wait...");
			var caluserid=jQuery('#caluserid').val();
			var caluserpass=jQuery('#caluserpass').val();
			var accessType=jQuery('#access_type').val();
			var calName=jQuery('#calname').val();
			if(caluserid !=""){
				 $.ajax({
					 type:'POST',
					 url:'../wowews/testconnection.php',
					 data:{'caluserid':caluserid,'caluserpass':caluserpass,'testBtn':'testBtn'},
					 dataType:'html',
					 success:function(responseData){
						 var response=$.trim(responseData);
						 if(response==1){
							 $("#btnOk").val("Test & Save");
							 alert("Please enter password");return false;
						 }else if(response==200){
							alert("Connection Successful.");
							$("#btnOk").val("Test & Save");
							$.ajax({
								type:'POST',
								url:'../wowews/officeIntegrationOnEditor.php',
								data:{'caluserid':caluserid,'caluserpass':caluserpass,'accessType':accessType,'calName':calName},
								dataType:'html',
								success:function(response){
									$('.googletab').html(response);
									$('#showsuccessmsg').html("Usename and password saved successfully.");
									$('#showsuccessmsg').fadeIn().delay(1000).fadeOut('slow');
									$('#templateDisplayName').hide(1).delay(2000).show(1);		
								}
							});
						 }else{
							alert(response);
							$("#btnOk").val("Test & Save");
						 }			
					 }
				 });
			}else{
				 $("#testBtn").val("Test & Save");
				 alert("Please enter username");return false;
			}
		}	
		return false;
	});
	$(document).on('click', '#btnExchangeOk', function(){
		var caluserid=$('#caluserid1').val();
		var caluserpass=$('#caluserpass1').val();
		var hosturl=$('#hosturl').val();
		var exchangeVer=$('#exchangeVer').val();
		var permission_type=$('#access').val();
		var calname="";
		if(permission_type !=0){
			calname=$('#calname1').val();
			if(calname==''){
				jQuery('#calname1').removeClass('normalmsg').addClass('redmsg');
				jQuery('#errcalname').html("Enter Calendar name");
				$('#calname1').focus();					
				return false;
			}
		}
		if(hosturl==''){
			jQuery('#hosturl').removeClass('normalmsg').addClass('redmsg');
			jQuery('#errhosturl').html("Enter Exchange Server URL");
			$('#hosturl').focus();					
			return false;
		}else if(exchangeVer==''){
			jQuery('#hosturl').removeClass('redmsg').addClass('normalmsg');
			jQuery('#exchangeVer').removeClass('normalmsg').addClass('redmsg');
			jQuery('#errhostverison').html("Select Exchange Version");
			$('#exchangeVer').focus();
			jQuery('#errhosturl').html('');			
			return false;
		}
		else if(caluserid==''){
			jQuery('#hosturl').removeClass('redmsg').addClass('normalmsg');
			jQuery('#exchangeVer').removeClass('redmsg').addClass('normalmsg');
			jQuery('#caluserid1').removeClass('normalmsg').addClass('redmsg');
			jQuery('#erruname1').html(jQuery('#urnamemsg').val());
			$('#caluserid1').focus();
			jQuery('#errhosturl').html('');						
			jQuery('#errhostverison').html('');						
			return false;
			
		}else if(!caluserid.match(emailPattern)){
			jQuery('#hosturl').removeClass('redmsg').addClass('normalmsg');
			jQuery('#exchangeVer').removeClass('redmsg').addClass('normalmsg');
			jQuery('#caluserid1').removeClass('normalmsg').addClass('redmsg');
			jQuery('#erruname1').html('Invalid email id');
			$('#caluserid1').focus();
			jQuery('#errhosturl').html('');						
			jQuery('#errhostverison').html('');											
			return false;
			
		}else if(caluserpass==''){
			jQuery('#erruname').html('');
			jQuery('#hosturl').removeClass('redmsg').addClass('normalmsg');
			jQuery('#exchangeVer').removeClass('redmsg').addClass('normalmsg');
			jQuery('#caluserid1').removeClass('redmsg').addClass('normalmsg');
			jQuery('#caluserpass1').removeClass('normalmsg').addClass('redmsg');
			jQuery('#errpassword1').html('Enter password');
			$('#caluserpass1').focus();
			jQuery('#errhosturl').html('');						
			jQuery('#errhostverison').html('');		
			jQuery('#erruname1').html('');	
			return false;
		}else{
			var caluserid=jQuery('#caluserid1').val();
			var caluserpass=jQuery('#caluserpass1').val();
			var accessType=jQuery('#access').val();
			var hosturl=jQuery('#hosturl').val();
			var exchangeVer=jQuery('#exchangeVer').val();
			var calName=jQuery('#calname1').val();
			$("#btnExchangeOk").val("Wait...");
			if(caluserid !=""){
				$.ajax({
					type:'POST',
					url:'../wowews/testconnection.php',
					data:{'caluserid':encodeURI(caluserid),'caluserpass':encodeURI(caluserpass),'testBtn':'testBtn','hosturl':encodeURI(hosturl),'exchangeVer':encodeURI(exchangeVer)},
					dataType:'html',
					success:function(responseData){
						var response=$.trim(responseData);
						if(response==1){
							$("#btnExchangeOk").val("Test & Save");
							alert("Please enter password");return false;
						}else if(response==200){
							alert('Connection Successful.');
							$("#btnExchangeOk").val("Test & Save");
							$.ajax({
								type:'POST',
								url:'../wowews/exchangeIntegrationOnEditor.php',
								data:{'caluserid':caluserid,'caluserpass':caluserpass,'hosturl':hosturl,'exchangeVer':exchangeVer,'accessType':accessType,'calName':calName},
								dataType:'html',
								success:function(response){
									$('.googletab').html(response);
									$('#showsuccessmsg').html("Usename and password saved successfully.");
									$('#showsuccessmsg').fadeIn().delay(1000).fadeOut('slow');
									$('#templateDisplayName').hide(1).delay(2000).show(1);			
								}
							});
						}else{
							alert(response);
							$("#btnExchangeOk").val("Test & Save");
						}			
					}
				});
		   }
		}	
		return false;
	});
 
    $(document).on('click', '#chkAdministrator', function(){
		if($("#chkAdministrator").is(':checked')==true){
		  $('#audianceResponse').attr('checked',true);
		  $('#audianceResponse').attr('disabled', true);
		  $('#dss').attr('checked',true);
		  $('#dss').attr('disabled', true);
		}else{
		  $('#audianceResponse').attr('checked',false);
		  $('#audianceResponse').attr('disabled', false);
		  $('#dss').attr('checked',false);
		  $('#dss').attr('disabled', false);
		  jQuery('.makedisabled').attr("disabled",false);	
		}
    });
   //Test the usename password is valid or not.
	$(document).on('click', '#testBtn', function(){
	   $("#testBtn").val("Wait...");
	   var caluserid=$('#caluserid').val();
	   var caluserpass=$('#caluserpass').val();
	   if(caluserid !=""){
			$.ajax({
				type:'POST',
				url:'../wowews/testconnection.php',
				data:{'caluserid':caluserid,'caluserpass':caluserpass,'testBtn':'testBtn'},
				dataType:'html',
				success:function(response){	
					if(response==1)	{
						$("#testBtn").val("Test Connection");
						alert("Please enter password");return false;
					}else{
						alert('Connection Successful.');
						$("#testBtn").val("Test Connection");
					}			
				}
			});
		}else{
			$("#testBtn").val("Test Connection");
			alert("Please enter username");return false;
		}
   }); 
	//Test the usename password is valid or not.
	$(document).on('click', '#testBtn2', function(){
           $("#testBtn2").val("Wait...");
           var caluserid=$('#caluserid1').val();
           var caluserpass=$('#caluserpass1').val();
           var hosturl=$('#hosturl').val();
           var exchangeVer=$('#exchangeVer').val();
           if(hosturl !=""){
                if(exchangeVer !=""){
                     if(caluserid !=""){
                         $.ajax({
                              type:'POST',
                              url:'../wowews/testconnection.php',
                              data:{'caluserid':encodeURI(caluserid),'caluserpass':encodeURI(caluserpass),'testBtn':'testBtn','hosturl':encodeURI(hosturl),'exchangeVer':encodeURI(exchangeVer)},
                              dataType:'html',
                              success:function(response){	
                                 if(response==1)	{
                                    $("#testBtn2").val("Test Connection");
                                    alert("Please enter password");return false;
                                 }else{
                                    alert('Connection Successful.');
                                    $("#testBtn2").val("Test Connection");
                                 }			
                              }
                          });
                     }else{
                         $("#testBtn2").val("Test Connection");
                         alert("Please enter username");return false;
                     }	
				}else{
					$("#testBtn2").val("Test Connection");
					alert("Please select exchange version");return false;
				}
           }else{
                $("#testBtn2").val("Test Connection");
                alert("Please enter exchange server url");return false;
           }
   });
   

    $(document).on('click', '.icon', function(){
    	var imgPath = $('.icon').find('img').attr('src');
        if($('#caluserpass').attr('type')=="password"){
				$('#caluserpass').get(0).type='text';
				$('.icon').find('img').attr('src', imgPath.replace("passwordView.png", "passwordHide.png"));
            }else{
				$('#caluserpass').get(0).type='password';
				$('.icon').find('img').attr('src', imgPath.replace("passwordHide.png", "passwordView.png"));
            }
    });
    $(document).on('click', '.icon2', function(){
    	var imgPath = $('.icon2').find('img').attr('src');
        if($('#caluserpass1').attr('type')=="password"){
				$('#caluserpass1').get(0).type='text';
				$('.icon2').find('img').attr('src', imgPath.replace("passwordView.png", "passwordHide.png"));
            }else{
				$('#caluserpass1').get(0).type='password';
				$('.icon2').find('img').attr('src', imgPath.replace("passwordHide.png", "passwordView.png"));
            }
    });
    
    $(document).on('change', '#calType', function(){
		  var cal_type=$(this).val();
		  if(cal_type=="google"){ 
			  $('.officecls').css('display','none');
			  $('.googlecls').css('display','block');
			  $('.exchangecls').css('display','none');
			  $('.office365auth2cls').css('display','none');
		  }else if(cal_type=="msexchange"){
			  $('.officecls').css('display','none');
			  $('.googlecls').css('display','none'); 
			  $('.office365auth2cls').css('display','none');
			  $('.exchangecls').css('display','block');
		  }else if(cal_type=="office365auth2"){
			  $('.officecls').css('display','none');
			  $('.googlecls').css('display','none'); 
			   $('.exchangecls').css('display','none');
			  $('.office365auth2cls').css('display','block');
		  }else{
			  $('.officecls').css('display','block');
			  $('.googlecls').css('display','none');
			  $('.exchangecls').css('display','none');
			   $('.office365auth2cls').css('display','none');
		  }
	});

    $(document).on('click', '.getCodeClass', function(){
		  $(".getCodeClass").val("Wait..");
		  var val=$("#code").val();
		  var baseURL=$('#baseUrl').val();			  
		  if(val){
			   jQuery.ajax({
					type:'GET',
					async:false,
					url:'/calendar/accountLogin?code='+val,
					dataType:'html',
					beforeSend : function(){
					},
					success:function(responseData, status, XMLHttpRequest){
						 //var responseData = $.trim(responseData);
						 if(responseData==500){
							$(".getCodeClass").val("Get Calendar");
							alert("Invalid code.");return false;
						 }
						 if(responseData){
							  $("#selCal").html(responseData);
							  $(".getCodeClass").val("Get Calendar");
							  $(".stepthree").prop('disabled', false);
						 }
					}					
		       });			
		  }else{
			    $(".getCodeClass").val("Get Calendar");
			    alert("Please enter the code.");return false;
		  }
	});
	
	 $(document).on('click', '.associateCal', function(){
		  var val=$("#selCal").val();
		  if(val && val !=0){
			   jQuery.ajax({
					type:'POST',
					async:false,
					url:'../wowews/googleIntegrationOnEditor.php',
					data:{'val':val},
					dataType:'html',
					beforeSend : function(){
					},
					success:function(responseData, status, XMLHttpRequest){
						  var res = responseData.charAt(0);
						  var html = responseData.substr(1);
						  if(res==1){
							  alert("Calendar associated successfully.");
							  $('.googletab').html(html);
						  }else if(responseData==2){
							    alert("Something went wrong.");return false;
						  }
					}					
		       });			
		  }else{
			    alert("Please select the calendar.");return false;
		  }
	});

	//Reset the calendar
	$(document).on('click', '.resetcalendar', function(){
		var calType=$("#calType").val();
		var activeTemp=jQuery('#activeTemp').val();
		ConfirmBox('After reset ,calendar will not be  visible on VIA gateway. Do you want to reset calendar account ?', 'No', 'Yes',calType);
	});
	
	//get office 365 calenders	
   $(document).on('click','.getoffice365CodeClass',function(){
		  if($(this).attr('rel') == 'edit'){
			  var val=$(".office365codeEdit").val();
		  }else{
			  var val=$("#office365code").val();
		  }
		   //$(".getoffice365CodeClass").val("Wait..");
		   
		  if(val){
			   jQuery.ajax({
					type:'GET',
					async:false,
					url:'../calendar2.0/callback.php?code='+val,
					dataType:'html',
					beforeSend : function(){
					},
					success:function(responseData, status, XMLHttpRequest){	
					     if(responseData==500){
							$(".getoffice365CodeClass").val("Get Calendar");
							alert("Invalid code.");return false;
						 }
						 
						 if(responseData){
							  $("#selOffice365Cal").html(responseData);
							  $(".getoffice365CodeClass").val("Get Calendar");
							  $(".office365stepthree").prop('disabled', false);
						 }
						
					}					
		       });			
		  }else{
			    alert("Please Enter the code.");
				$(".getoffice365CodeClass").val("Get Calendar");
				return false;
		  }
	});		

   $(document).on('click', '.associateOffice365Cal', function(){
		  var val=$("#selOffice365Cal").val();
		  if(val && val !=0){
			   jQuery.ajax({
					type:'POST',
					async:false,
					//url:'../wowews/googleIntegrationOnEditor.php',
					url:'../calendar2.0/associateCalendarEditor.php',
					data:{'val':val},
					dataType:'html',
					beforeSend : function(){
					},
					success:function(responseData, status, XMLHttpRequest){
						  var res = responseData.charAt(0);
						  var html = responseData.substr(1);
						  if(res==1){
							  alert("Calendar associated successfully.");
							  $('.googletab').html(html);
						  }else if(responseData==2){
							    alert("Something went wrong.");return false;
						  }
					}					
		       });			
		  }else{
			    alert("Please select the calendar.");return false;
		  }
	});
	//Associate office 365 calendar
    $(document).on('click', '.associateOffice365Cal_bk', function(){
		  var val=$("#selOffice365Cal").val();
		  if(val && val !=0){
			   jQuery.ajax({
					type:'POST',
					async:false,
					url:'../calendar2.0/associateCalendarEditor.php',					
					data:{'val':val},
					dataType:'html',
					beforeSend : function(){
					},
					success:function(responseData, status, XMLHttpRequest){
						  var responseData = $.trim(responseData);
						  alert(responseData)
						  if(responseData==1){
							  alert("Calendar associated successfully.");
							  //location.reload();
						  }else if(responseData==2){
							    alert("Something went wrong.");return false;
						  }
					}					
		       });			
		  }else{
			    alert("Please select the calendar.");return false;
		  }
	});

	
});

 
    function hexc(colorval) {
	   var parts = colorval.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
	   delete(parts[0]);
	   for (var i = 1; i <= 3; ++i) {
		   parts[i] = parseInt(parts[i]).toString(16);
		   if (parts[i].length == 1) parts[i] = '0' + parts[i];
	   }
	   color = '#' + parts.join('');
	   return color;
    } 
