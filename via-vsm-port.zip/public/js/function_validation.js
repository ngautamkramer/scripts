jQuery(document).ready(function(){	
			var numericPattern=/^[0-9]+$/;						
			//alert(jQuery('#lastnavinput').val());				
			if(jQuery('#lastnavinput').val()==0){
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#locnavdiv').hide();
				jQuery('#reportnavdiv').hide();
				jQuery('#amentiesnavdiv').hide();
                jQuery('#settingnavdiv').hide();					
				jQuery('#orgnavdiv').show();
				jQuery('.orgnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
			}else if($('#lastnavinput').val()==1){
				jQuery('#calnavdiv').hide();				
				jQuery('#roomnavdiv').hide();
				jQuery('#locnavdiv').hide();
				jQuery('#reportnavdiv').hide();
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#settingnavdiv').hide();	
				jQuery('#usernavdiv').show();
				jQuery('.usernavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
							
			}else if(jQuery('#lastnavinput').val()==2){
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();
				jQuery('#roomnavdiv').hide();				
				jQuery('#reportnavdiv').hide();
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#settingnavdiv').hide();	
				jQuery('#locnavdiv').show();
				jQuery('.locnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
			}else if(jQuery('#lastnavinput').val()==3){
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#locnavdiv').hide();
				jQuery('#reportnavdiv').hide();
				jQuery('#orgnavdiv').hide();
				jQuery('#settingnavdiv').hide();	
				jQuery('#amentiesnavdiv').show();					
				jQuery('.amentiesnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
				
			}else if(jQuery('#lastnavinput').val()==4){				
				jQuery('#usernavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#locnavdiv').hide();
				jQuery('#reportnavdiv').hide();
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#settingnavdiv').hide();	
				jQuery('#calnavdiv').show();
				jQuery('.calnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
				
			}
			else if(jQuery('#lastnavinput').val()==5){
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();				
				jQuery('#locnavdiv').hide();
				jQuery('#reportnavdiv').hide();
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#settingnavdiv').hide();	
				jQuery('#roomnavdiv').show();
				jQuery('.roomnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
				
			}
			else if(jQuery('#lastnavinput').val()==6){
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();				
				jQuery('#locnavdiv').hide();				
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#settingnavdiv').hide();	
				jQuery('#reportnavdiv').show();
				jQuery('.reportnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
				
			}else if(jQuery('#lastnavinput').val()==7){
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();				
				jQuery('#locnavdiv').hide();				
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#devicenavdiv').hide();
				jQuery('#settingnavdiv').show();
				jQuery('.settingnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
				
			}else if(jQuery('#lastnavinput').val()==8){ 
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();				
				jQuery('#locnavdiv').hide();				
				jQuery('#amentiesnavdiv').hide();	
				jQuery('#orgnavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#devicenavdiv').hide();
				jQuery('#settingnavdiv').hide();
				//jQuery('#settingnavdiv').show();
				jQuery('.homenavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
				
			}
			
			else{
				jQuery('#calnavdiv').hide();
				jQuery('#usernavdiv').hide();
				jQuery('#roomnavdiv').hide();
				jQuery('#locnavdiv').hide();
				jQuery('#devicenavdiv').hide();
				jQuery('#amentiesnavdiv').hide();
                jQuery('#settingnavdiv').hide();				
				jQuery('#orgnavdiv').show();
				jQuery('.orgnavdivCSS').removeClass('navDefaultBgColor').addClass('navSelTabBgColor');
			}
			
		
	$("#firstpane p.hello").click(function()
    {
		if(false == $(this).next().is(':visible')) {
			$('#firstpane div.menu_body').slideUp(300);
		}
			$(this).next().slideToggle(300);
		//jQuery(this).next("div.menu_body").slideToggle(300).siblings("div.menu_body").slideUp("slow");
       	
	});
	
	$("#accordion > li.clk").click(function(){
	if(false == jQuery(this).next().is(':visible')) {
		$('#accordion > ul').slideUp(300);
	}
	$(this).next().slideToggle(300);
	});
	

});

