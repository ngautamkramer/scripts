$(document).ready(function(){	
if(jQuery("#currentPageName").val()=='viaConfiguration'){
        var miracastConfigStatus=($('#miracastStatus').val()==1)?$('#miracastFrequencyDiv').show():$('#miracastFrequencyDiv').hide();
	// js addded for pop up showing when managaed from VSM 
        var hqserver=$('#selConfigSettingOption').val();
        if(hqserver==1){
                var overlay = $('<div id="overlay"></div>');
                overlay.show();
                overlay.appendTo(document.body);
                $('.popup').show();
                $('.close').click(function(){
                $('.popup').hide();
                overlay.appendTo(document.body).remove();
                return false;
                });

                $('.x').click(function(){
                        $('.popup').hide();
                        overlay.appendTo(document.body).remove();
                        return false;
                });
        }
        
	jQuery('.mirroringCss').click(function(){
		var mirrorChkBoxVal=jQuery(this).attr('rev');	
		if(mirrorChkBoxVal==1){
			jQuery('#mirroringOff').removeClass('active');
			jQuery('#mirroringON').addClass('active');
			jQuery('#maxNoOfMirrors').val(jQuery('#hiddenMaxMirrorCon').val());

			jQuery('.enabledElements').prop("disabled", false);
			var keyword='create';
			jQuery.createRemoveMirrorFiles(keyword);
		}else{
			jQuery('#mirroringON').removeClass('active');
			jQuery('#mirroringOff').removeClass('active');
			jQuery('#mirroringOff').addClass('active');
			
			jQuery('#maxNoOfMirrors').val('');
			jQuery('.enabledElements').prop("disabled", true);
			var keyword='delete';
			jQuery.createRemoveMirrorFiles(keyword);
		}
		
	});
	
	$('.chromeCss').click(function(){
		var optValue=($(this).attr('id')=='enableChrome')?1:0;
		$('#pollingTabVal').val(optValue);	
		if(optValue==1){
			$('#disableChrome').removeClass('active').addClass('inActive');				
			$('#enableChrome').removeClass('inActive').addClass('active');
		}else{		
			$('#enableChrome').removeClass('active').addClass('inActive');
			$('#disableChrome').removeClass('inActive').addClass('active');
		}
		jQuery.advancedServerConfiguration('setChromeSettings',optValue);		
		
	});
	
	$('.miracastCss').click(function(){		
		var checkWifi=$("#check_wifiExist").val();
		var checkViaGo=$("#check_viagoFile").val();
		var optValue=($(this).attr('id')=='enableMiracast')?1:0;	
		if(optValue==1){
			//added on 11jan2018 for restrict Miracast switch 'ON' if wifi is alraedy ON
			if(checkWifi==1 && checkViaGo!=1){
				alert($("#alertWhenwifiOn").val());
				return false;
			}
			$('#disableMiracast').removeClass('active').addClass('inActive');				
			$('#enableMiracast').removeClass('inActive').addClass('active');
			$('#miracastFrequencyDiv').show();					
			
		}else{			
			$('#enableMiracast').removeClass('active').addClass('inActive');
			$('#disableMiracast').removeClass('inActive').addClass('active');
			$('#miracastFrequencyDiv').hide();
			
		}
		jQuery.advancedServerConfiguration('setMiracastSettings',optValue);		
		
	});
        
        jQuery('.advConfigBox').change(function(){		
		var ddName=jQuery(this).attr('id');		
		var ddVal=jQuery('#'+ddName).val();
		jQuery.advancedServerConfiguration(ddName,ddVal);
	});
        
        jQuery('.advChkbox').click(function(){	
		var chkBoxName=jQuery(this).attr('id');
		//alert(chkBoxName);		
		var chkBoxVal=(jQuery('#'+chkBoxName).is(':checked'))?1:0;		
		if(chkBoxVal==1){		
			jQuery('#autoSave').attr("disabled", true);
			jQuery('#autoSave').attr("checked", false);			
			jQuery('#discardChanges').attr('disabled',false);
			jQuery('#doNothing').attr('disabled',false);
			jQuery('#doNothing').prop("checked", true);
		// added on 21Dec2016 for showing warning if cloud option already selected from recroding	
		var recTransferOption=$('#recTransferOption').val();				
		  if(recTransferOption=='cloud'){
		  	var act=confirm($('#alertCloudRecPath').val());
			if(act==false){
				return false;
			}	
		  }
			
			
                // added on 21Dec2016 to enable cloud option in recording transfer
                $('#autoCleanCloud').val(1);
					
			
		}else{
			jQuery('#autoSave').attr("disabled", false);
			jQuery('#discardChanges').attr('disabled',false);
			jQuery('#doNothing').attr('disabled',false);
			jQuery('#doNothing').attr("checked", true);	
			// added on 21Dec2016 to enable cloud option in recording transfer
			$('#autoCleanCloud').val(0);
				
		}
		jQuery.advancedServerConfiguration(chkBoxName,chkBoxVal);
		
	});	
	
	jQuery('.closeWhiteBoardBtnCss').click(function(){
		var selectRadiobtnval = jQuery("input[name='closeWhiteBoardBtn']:checked").val();
		jQuery.advancedServerConfiguration('setWhiteBoardOptions',selectRadiobtnval);
									 
	});
        
        // added for file sharing
	jQuery('.fileSharingCss').click(function(){
		var getSelectRadiobtnval = jQuery(this).attr('rev');			
		if(getSelectRadiobtnval==0){
			jQuery.ajax({
					type:'POST',
					url:'applyDefaultFileTypeConfig',
					data:'',
					dataType:'html',
					beforeSend : function(){
					
					},
					success:function(responseData, status, XMLHttpRequest){
						// added on 19Dec2016
						if(responseData=='sessionExpired'){
							alert($('#alertSessionExpired').val());
							jQuery(window.location).attr('href','index');
						}else{							
							$('#fileSharingTextArea').html(responseData);
							$('#fileSharingSelected').prop('checked',false);	
							$('#fileSharingAll').prop('checked',true);
							alert($('#applySettingsAlert').val());
						}	
					}					
				});
			
		}
											   
	 });
	
	$(document).on('click','#selAll',function(event) {  //on click
            if(this.checked) { // check select status
                $('.fileTypeChkboxCss').each(function() { //loop through each checkbox
                    this.checked = true;  //select all checkboxes with class "checkbox1"              
                });
            }else{
                $('.fileTypeChkboxCss').each(function() { //loop through each checkbox
                    this.checked = false; //deselect all checkboxes with class "checkbox1"                      
                });        
            }
	});	
	
	$(document).on('click','.fileTypeChkboxCss',function(){
            $('#selAll').attr('checked',false);
	});
	
 	jQuery(document).on('click','#applyExtBtn', function(){
		var checkedCheckbox = jQuery("input[name='fileType']:checked");
		var checkedBox = "";
		var chkCounter = 1;
		var countChkBox = "";
		checkedCheckbox.each(function(){				
			countChkBox = chkCounter++;
			if(countChkBox == 1){
				 checkedBox = jQuery(this).val();					
			}
			if(countChkBox > 1){
				checkedBox = checkedBox+','+jQuery(this).val();					
			}
		})	
					
		if(checkedBox == ""){
			alert($('#selAtLeastOneChkboxAlert').val());
			return false;
		}else{
			jQuery.ajax({
					type:'POST',
					url:'applySelectedFileTypeConfig',
					data:'textareaValues='+encodeURIComponent(checkedBox),
					dataType:'html',
					beforeSend : function(){
						//jQuery('#loadingImg').html("<img src='images/icoLoader.gif'> You are going to Logout...");
					},
					success:function(responseData, status, XMLHttpRequest){
                                                var responseData=$.trim(responseData);
						// added on 19Dec2016
						if(responseData=='sessionExpired'){
							alert($('#alertSessionExpired').val());
							jQuery(window.location).attr('href','index');
						}
						
						if(responseData=='success'){
							$('#fileSharingTextArea').html(checkedBox);	
							$('#fileSharingAll').prop('checked',false);
							$('#fileSharingSelected').prop('checked',true);										
							//alert(jQuery('#applySettingsAlert').val());
                                                        alert('Settings applied successfully');
							$(window.location).attr('href','viaConfiguration');
						}	
					}					
				});
				
		}
		return false;
	});
	
	
	$(document).on('click','#addCustomBtn',function(){
		var textareaValues=$('#customBox').val();				
		var alphaNumericReg=/^[a-zA-Z0-9,]+$/;
		if(textareaValues.substring(0,1)==' '){
			alert('space not allowed');
			$('#customBox').val('');
			$('#customBox').focus();
			return false;
		}else if(textareaValues.length==0){
			alert($('#alertEnterValue').val());
			$('#customBox').focus();
			return false;					
		}else if(textareaValues.toLowerCase().match("png")!=null || textareaValues.toLowerCase().match("jpeg")!=null || textareaValues.toLowerCase().match("pdf")!=null || textareaValues.toLowerCase().match("jpg")!=null){		
    		alert($('#alertTypeFormat').val());
			return false;
		}else if(!textareaValues.match(alphaNumericReg)){
			alert($('#alerAlphanumeric').val());
			$('#customBox').focus();
			return false;				
			
		}
		else{			
			jQuery.ajax({
					type:'POST',
					url:'addCustomFileTypes',
					data:'chkBoxName=fileSharing&chkBoxVal=1&textareaValues='+encodeURIComponent(textareaValues),
					dataType:'html',
					beforeSend : function(){
					
					},
					success:function(responseData, status, XMLHttpRequest){
						var newResponse =responseData.split("#@#@#");
						var extExist=$.trim(newResponse[0]);
						if(responseData=='sessionExpired'){
							alert($('#alertSessionExpired').val());
							$(window.location).attr('href','index');
						}
						else if(extExist.length > 2 ){
						     alert(extExist+" already exists.");
						}
						else{						
                                                    $('#customBox').val('');
                                                    $('#custom').html(newResponse[1]);						
                                                    alert('File extension added successfully');
                                                    $(window.location).attr('href','viaConfiguration');
						}	
					}					
				});	
		}		
	
	});
	

// delete file types
	$(document).on('click','.userDefined',function(){		
		var chkBoxId=$(this).attr('rev');		
		jQuery.ajax({
				type:'POST',
				url:'deleteCustomFileTypes',
				data:'chkBoxId='+encodeURIComponent(chkBoxId),
				dataType:'html',				
				success:function(responseData, status, XMLHttpRequest){
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}else{					
						alert($('#alertDeleteSuccess').val());
						$('#custom').html(responseData);
                                                $(window.location).attr('href','viaConfiguration');
					}	
				}					
			});
		
	});
        
        // added for api setting command
	jQuery('.apiCmdCss').click(function(){
		var getApiCmdBtnval = jQuery(this).attr('rev');
		jQuery.ajax({
				type:'POST',
				url:'applyApiCmd',
				data:'getApiCmdBtnval='+getApiCmdBtnval,
				dataType:'html',
				beforeSend : function(){
					
				},
				success:function(responseData, status, XMLHttpRequest){
					if(responseData=='sessionExpired'){
                                            alert($('#alertSessionExpired').val());
                                            jQuery(window.location).attr('href','index');
					}else{							
                                            alert(jQuery('#applySettingsAlert').val());						
					}
					
				}					
			});
											   
	 });
	
	$('.resetSessionCss').click(function(){
		var optValue=($(this).attr('id')=='enableResetSession')?1:0;
		$('#pollingTabVal').val(optValue);
		//alert(optValue);		
		if(optValue==1){
			$('#disableResetSession').removeClass('active').addClass('inActive');				
			$('#enableResetSession').removeClass('inActive').addClass('active');
		}else{			
			$('#enableResetSession').removeClass('active').addClass('inActive');
			$('#disableResetSession').removeClass('inActive').addClass('active');
			
		}
		jQuery.advancedMoreFeatureConfiguration('setResetSessionSettings',optValue);		
		
	});
        
	                    // added for jpeg/H264 setting command
	jQuery('.jpegSupportCss').click(function(){
		var getjpegCmdBtnval = jQuery(this).attr('rev');			
		var actionName='setjpegH264';		
		 jQuery.advancedMoreFeatureConfiguration(actionName,getjpegCmdBtnval);
											   
	 }); 
 	//miracast frequency set 
 	jQuery('.miracastFrequencyCss').click(function(){
		var getmiracastBtnval = jQuery(this).attr('rev');					
		var actionName='setmiracastFrequency';		
		 jQuery.advancedMoreFeatureConfiguration(actionName,getmiracastBtnval);
											   
	 });
        
	jQuery('#setDefaultAudioLevel').change(function(){
		 var defaultAudioVal=jQuery('#setDefaultAudioLevel').val();		
		 var actionName='setAudioLevel';		
		 jQuery.advancedMoreFeatureConfiguration(actionName,defaultAudioVal);
								 
	});
        
        $('.recordingcss').click(function(){
		var optValue=($(this).attr('id')=='enableRecording')?1:0;
		$('#recordingTabVal').val(optValue);
		//alert(optValue);		
		if(optValue==1){			
			$('#disableRecording').removeClass('active').addClass('inActive');				
			$('#enableRecording').removeClass('inActive').addClass('active');
		}else{			
			$('#enableRecording').removeClass('active').addClass('inActive');
			$('#disableRecording').removeClass('inActive').addClass('active');
		}
		jQuery.advancedServerConfiguration('setRecordingConfiguration',optValue);
	});
        
        $('.transferRecordingcss').click(function(){
		  var optValue=$(this).attr('id');	
		  //added on 21Dec2016 to showing warning when clean cloud option in advance configuration already selected	
		  $('#tranferRecordingVal').val(optValue);  
		  var autoCleanCloud=$('#autoCleanCloud').val();
		  $('#recDiv').show();	
		  if(optValue=='vsm'){
		  	$('#recDiv').hide();
		  }
		 // if(autoCleanCloud!=1)	{
		  	$('#recTransferOption').val(optValue);
		 // }	
		  if(optValue=='cloud' && autoCleanCloud==1){
		  	var act=confirm($('#alertCloudRecProcess').val());
			if(act==false){
				return false;
			} 
		  }
		  //end	  
			$.ajax({
				type:'POST',
				url:'transferRecording',
				data:'optValue='+optValue,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
				
					
					if(responseData=='success'){
						//alert(jQuery('#applySettingsAlert').val());
                                                alert("Setting applied successfully!");
					}
							
				}					
			});
			
	  }); 
	
	//streaming configuration
	var getStreamOptValue=$("#getOs").val();
	//alert(getStreamOptValue)
	
	$('.streamingcss').click(function(){
		var getOS='';
		var check_dualDisplay_file=$("#dualDisplayFile").val();
		
		var optValue=($(this).attr('id')=='enableStreaming')?1:0;			
		//alert(optValue);	
		if(optValue==1){		
			$('.disabledStreamingCss').prop('disabled',false);
			var url1=($('#txtUrl1').val()!=undefined)?$('#txtUrl1').val():'';
			var url2=($('#txtUrl2').val()!=undefined)?$('#txtUrl2').val():'';
			
			if(check_dualDisplay_file==1){			
				if(url1==''){			
					alert('Please enter url');
					$('#txtUrl1').attr('readonly',false);
					$('#txtUrl1').focus();
					return false;	
				}else if(url1.indexOf('udp://')==-1 && url1.indexOf('tcp://')==-1 && url1.indexOf('rtp://')==-1){
					alert('Please enter correct url');
					$('#txtUrl1').focus();
					return false;
				}else{
					if(url1.indexOf('udp://')==0){
						var url1Str=url1.split('udp://');
						if(url1Str[1].length<5){
							alert('Please enter correct url');
							$('#txtUrl1').focus();
							return false;
						}
						
					}
					if(url1.indexOf('tcp://')==0){
						var url1Str=url1.split('tcp://');						
						if(url1Str[1].length<5){
							alert('Please enter correct url');
							$('#txtUrl1').focus();
							return false;
						}
						
					}
					if(url1.indexOf('rtp://')==0){
						var url1Str=url1.split('rtp://');						
						if(url1Str[1].length<5){
							alert('Please enter correct url');
							$('#txtUrl1').focus();
							return false;
						}	
					}
				}			
			}
				
			if(check_dualDisplay_file==2){
				if(url1==''){
					$('#txtUrl1').attr('readonly',false);
					alert('Please enter correct url 1');
					$('#txtUrl1').focus();
					return false;
				}else if(url1.indexOf('udp://')==-1 && url1.indexOf('tcp://')==-1 && url1.indexOf('rtp://')==-1){
					alert('Please enter correct url 1');
					$('#txtUrl1').focus();
					return false;
				}else{
					if(url1.indexOf('udp://')==0){
						var url1Str=url1.split('udp://');
						if(url1Str[1].length<5){
							alert('Please enter correct url 1');
							$('#txtUrl1').focus();
							return false;
						}
						
					}
					if(url1.indexOf('tcp://')==0){
						var url1Str=url1.split('tcp://');						
						if(url1Str[1].length<5){
							alert('Please enter correct url 1');
							$('#txtUrl1').focus();
							return false;
						}
						
					}
					if(url1.indexOf('rtp://')==0){
						var url1Str=url1.split('rtp://');						
						if(url1Str[1].length<5){
							alert('Please enter correct url 1');
							$('#txtUrl1').focus();
							return false;
						}
						
					}
				}

				
				if(url2==''){
					$('#txtUrl2').attr('readonly',false);	
					alert('Please enter correct url 2');
					$('#txtUrl2').focus();
					return false;
				}else if(url2.indexOf('udp://')==-1 && url2.indexOf('tcp://')==-1 && url2.indexOf('rtp://')==-1){
					alert('Please enter correct url 2');
					$('#txtUrl2').focus();
					return false;
				}else{
					if(url2.indexOf('udp://')==0){
						var url2Str=url2.split('udp://');
						if(url2Str[1].length<5){
							alert('Please enter correct url 2');
							$('#txtUrl2').focus();
							return false;
						}
					}
					if(url2.indexOf('tcp://')==0){
						var url2Str=url2.split('tcp://');						
						if(url2Str[1].length<5){
							alert('Please enter correct url 2');
							$('#txtUrl2').focus();
							return false;
						}
					}
				        if(url2.indexOf('rtp://')==0){
						var url2Str=url2.split('rtp://');						
						if(url2Str[1].length<5){
							alert('Please enter correct url 2');
							$('#txtUrl2').focus();
							return false;
						}	
					} 	
				}
			}
			
			$('#txtUrl1').attr('disabled',true);
			$('#txtUrl2').attr('disabled',true);
			
			$('#disableStreaming').removeClass('active').addClass('inActive');				
			$('#enableStreaming').removeClass('inActive').addClass('active');
			$('#streamingTabVal').val(optValue);		
			
		}else{
			var url1=($('#txtUrl1').val()!=undefined)?$('#txtUrl1').val():'';
			var url2=($('#txtUrl2').val()!=undefined)?$('#txtUrl2').val():'';

			$('#streamingTabVal').val(optValue);
			//$('.disabledStreamingCss').prop('disabled',true);
			$('#enableStreaming').removeClass('active').addClass('inActive');
			$('#disableStreaming').removeClass('inActive').addClass('active');
			$('#txtUrl1').attr('disabled',false);
			$('#txtUrl2').attr('disabled',false);
			
			
		}				
		jQuery.setStreamingConfiguration('setStramingConfiguration',optValue,url1,url2);		
		
	});
	
	jQuery('#mirrorApplyBtn').click(function(){
			var mirrorName=jQuery('#mirrorName').val();	
			var maxNoOfMirrors=jQuery('#maxNoOfMirrors').val();
			var numberPattern=/^[0-9]+$/;
			var NamePattern=/^[a-zA-Z0-9._(), {}\-\/\r\n]+$/;			
			if(mirrorName==""){
				alert(jQuery('#alertMirrorName').val());
				jQuery('#mirrorName').focus();
				return false;
			}else if(!mirrorName.match(NamePattern)){
				alert(jQuery('#wifialphanumeric').val());
				jQuery('#mirrorName').focus();
				return false;				
			}else if(maxNoOfMirrors==""){
				alert(jQuery('#alertMaxMirrorNo').val());
				jQuery('#maxNoOfMirrors').focus();
				return false;				
			}else if(parseInt(maxNoOfMirrors)==0 || parseInt(maxNoOfMirrors)>12){
				alert(jQuery('#alertMaxMirrorNo_numeric').val());
				jQuery('#maxNoOfMirrors').focus();
				return false;
			}else if(parseInt(maxNoOfMirrors)>4 && jQuery('#ostype').val()=='WIN'){
				var act=confirm(jQuery('#alertMaxMirrorNo_limit').val());
				if(act==true){
					var keyword="newMirrorSettings";
					jQuery.createNewMirrorSettings(keyword,mirrorName,maxNoOfMirrors);					
					return false;
				}else{
					jQuery('#maxNoOfMirrors').focus();
					return false;
				}				
				
			}else if(parseInt(maxNoOfMirrors)>2 && jQuery('#ostype').val()=='LIN'){
				var act=confirm(jQuery('#alertMirrorSettingsLin_txt').val());
				if(act==true){
					var keyword="newMirrorSettings";
					jQuery.createNewMirrorSettings(keyword,mirrorName,maxNoOfMirrors);					
					return false;
				}else{
					jQuery('#maxNoOfMirrors').focus();
					return false;
				}				
				
			}else if(!maxNoOfMirrors.match(numberPattern)){
				alert(jQuery('#alertMaxMirrorNo_numeric').val());
				jQuery('#maxNoOfMirrors').focus();
				return false;				
			}else{
				var keyword="newMirrorSettings";
				jQuery.createNewMirrorSettings(keyword,mirrorName,maxNoOfMirrors);
					
			}
											 
	});

	if(jQuery('#mirroringON').attr('rel')==1){
		jQuery('.enabledElements').prop("disabled", false);
	}else{
		jQuery('.enabledElements').prop("disabled", true);
	}
	
	
	

// Disabled all elements when select HQ in cinfiguration
	if($("#selConfigSettingOption").val()==1){	
		  jQuery('.makeDisabled').prop("disabled", true);
	}

}

if(jQuery("#currentPageName").val()=='gatewayFeatures'){
                $('.gwayFeatureCss').click(function(){
                    var featureId = $(this).attr('id');
                    var idStatus = featureId.substr(featureId.length - 1);
                    var feature = featureId.substr(0, featureId.length-1);
                    var optValue=(idStatus==='T')?1:0;
                    var getFeatureId=jQuery(this).attr('rev');
			
                    var iconID=$(this).parent().attr("id");
                    var delFlag = (getFeatureId==0) ? 1 : 2;
                    $.deactivateGatewayFeatures(iconID,delFlag);
                    
                    if(optValue==1){
                            $('#'+feature+'T').removeClass('inActive').addClass('active');				
                            $('#'+feature+'F').removeClass('active').addClass('inActive');
                    }else{		
                            $('#'+feature+'T').removeClass('active').addClass('inActive');
                            $('#'+feature+'F').removeClass('inActive').addClass('active');
                    }
                });
                
                jQuery('#applyFeatures').bind('click',function(){
                        var reorderFeatures = [];
                        $('#gwayFeaturesList>li').each(function(){
                            reorderFeatures.push($(this).attr('id'));
                        });
                        //alert(reorderFeatures);
			var myact=confirm(jQuery('#confirmProceed').val());
                        if(myact){
                            var flag=2;

                            $.ajax({
                                    type:'POST',
                                    url:'applyGatewayFeaturesToFile',
                                    data:'flag='+flag+'&reorderFeatures='+reorderFeatures,
                                    dataType:'html',
                                    beforeSend : function(){
                                    },
                                    success:function(responseData, status, XMLHttpRequest){	
                                            var responseData= $.trim(responseData);
                                            if(responseData=="success"){
                                                alert(jQuery('#savedFeatuesAlert').val());						
                                                setTimeout(function(){window.location = 'gatewayFeatures';}, 1000);
                                            }else{
                                                alert(responseData);
                                            }					
                                    }					
                            });
				
                        }	
		});
		
		jQuery('#resetFeatures').click(function(){
                        var resetFlag=1;
                                jQuery.ajax({
                                type:'POST',
                                url:'resetGatewayOrClientsFeatures',
                                data:'resetFlag='+resetFlag,
                                dataType:'html',
                                beforeSend : function(){
                                },
                                success:function(responseData, status, XMLHttpRequest){	
                                        var responseData= $.trim(responseData);
                                        if(responseData=="success"){
                                                jQuery('#msg').html(jQuery('#resetFeatureAlert').val());	
                                                jQuery('#msg').fadeIn().delay(1000).fadeOut('slow');
                                                        //jQuery('#icon_'+iconID).fadeOut('slow');
                                                setTimeout(function(){window.location = 'gatewayFeatures';}, 1000);

                                        }else{
                                                alert(responseData);
                                        }					
                                }					
                        });	
		});		
}

if(jQuery("#currentPageName").val()=='clientFeatures'){
                $('.clientFeatureCss').click(function(){
                        var featureId = $(this).attr('id');
                        var idStatus = featureId.substr(featureId.length - 1);
                        var feature = featureId.substr(0, featureId.length-1);
                        var optValue=(idStatus==='T')?1:0;
                        var getFeatureId=jQuery(this).attr('rev');

                        var iconID=$(this).parent().attr("id");
                        var delFlag = (getFeatureId==0) ? 1 : 2;
                        $.deactivateClientFeatures(iconID,delFlag);

                        if(optValue==1){
                                $('#'+feature+'T').removeClass('inActive').addClass('active');				
                                $('#'+feature+'F').removeClass('active').addClass('inActive');
                        }else{		
                                $('#'+feature+'T').removeClass('active').addClass('inActive');
                                $('#'+feature+'F').removeClass('inActive').addClass('active');
                        }
                });
                
                jQuery('#applyFeatures').bind('click',function(){
                        var reorderFeatures = [];
                        $('#clientFeaturesList>li').each(function(){
                            reorderFeatures.push($(this).attr('id'));
                        });
                        //alert(reorderFeatures);
			var myact=confirm(jQuery('#confirmProceed').val());
                        if(myact){
                            var flag=2;

                            $.ajax({
                                    type:'POST',
                                    url:'applyClientFeaturesToFile',
                                    data:'flag='+flag+'&reorderFeatures='+reorderFeatures,
                                    dataType:'html',
                                    beforeSend : function(){
                                    },
                                    success:function(responseData, status, XMLHttpRequest){	
                                            var responseData= $.trim(responseData);
                                            if(responseData=="success"){
                                                alert(jQuery('#savedFeatuesAlert').val());						
                                                setTimeout(function(){window.location = 'clientFeatures';}, 1000);
                                            }else{
                                                alert(responseData);
                                            }					
                                    }					
                            });
				
                        }	
		});
		
		jQuery('#resetFeatures').click(function(){
				var resetFlag=2;
					jQuery.ajax({
					type:'POST',
					url:'resetGatewayOrClientsFeatures',
					data:'resetFlag='+resetFlag,
					dataType:'html',
					beforeSend : function(){
					},
					success:function(responseData, status, XMLHttpRequest){	
						//alert(responseData);
                                                var responseData= $.trim(responseData);
						if(responseData=="success"){
							jQuery('#msg').html(jQuery('#resetFeatureAlert').val());	
							jQuery('#msg').fadeIn().delay(1000).fadeOut('slow');
								//jQuery('#icon_'+iconID).fadeOut('slow');
							setTimeout(function(){window.location = 'clientFeatures';}, 1000);
							
						}else{
							alert(responseData);
						}					
					}					
				});
		});		
		
}

if(jQuery("#currentPageName").val()=='mobileFeatures'){
                $('.mobileFeatureCss').click(function(){
                        var featureId = $(this).attr('id');
                        var idStatus = featureId.substr(featureId.length - 1);
                        var feature = featureId.substr(0, featureId.length-1);
                        var optValue=(idStatus==='T')?1:0;
                        var getFeatureId=jQuery(this).attr('rev');

                        var iconID=$(this).parent().attr("id");
                        var delFlag = (getFeatureId==0) ? 1 : 2;
                        jQuery.ajax({
				type:'POST',
				url:'deactivateMobileFeatues',
				data:'iconID='+iconID+'&delFlag='+delFlag,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){
                                    if(responseData=="via" || responseData=="collab8"){
                                        //alert(jQuery('#deactivateFeatureAlert').val());
                                    }else{
                                        alert(responseData);
                                    }
				}					
			});
                        if(optValue==1){
                                $('#'+feature+'T').removeClass('inActive').addClass('active');				
                                $('#'+feature+'F').removeClass('active').addClass('inActive');
                        }else{		
                                $('#'+feature+'T').removeClass('active').addClass('inActive');
                                $('#'+feature+'F').removeClass('inActive').addClass('active');
                        }
                });
                
                jQuery('#applyFeatures').bind('click',function(){
                        var reorderFeatures = [];
                        $('#mobileFeaturesList>li').each(function(){
                            reorderFeatures.push($(this).attr('id'));
                        });
			var myact=confirm(jQuery('#confirmProceed').val());
                        if(myact){
                            var flag=2;

                            $.ajax({
                                    type:'POST',
                                    url:'applyMobileFeaturesToFile',
                                    data:'flag='+flag+'&reorderFeatures='+reorderFeatures,
                                    dataType:'html',
                                    beforeSend : function(){
                                    },
                                    success:function(responseData, status, XMLHttpRequest){	
                                            var responseData= $.trim(responseData);
                                            if(responseData=="success"){
                                                alert(jQuery('#savedFeatuesAlert').val());						
                                                setTimeout(function(){window.location = 'mobileFeatures';}, 1000);
                                            }else{
                                                alert(responseData);
                                            }					
                                    }					
                            });
				
                        }	
		});
		
		jQuery('#resetFeatures').click(function(){
                        var resetFlag=2;
                        jQuery.ajax({
                            type:'POST',
                            url:'resetMobileFeatures',
                            data:'resetFlag='+resetFlag,
                            dataType:'html',
                            beforeSend : function(){
                            },
                            success:function(responseData, status, XMLHttpRequest){
                                    var responseData= $.trim(responseData);
                                    if(responseData=="success"){
                                        alert($('#resetFeatureAlert').val());
                                        setTimeout(function(){window.location = 'mobileFeatures';}, 1000);

                                    }else{
                                        alert(responseData);
                                    }					
                            }					
                        });
		});		
}

if($('#autoPowerOffChkBoxVal').val()==0){
	jQuery('#selhoursdd').attr('disabled',true);
	jQuery('#selminsdd').attr('disabled',true);	

}else{
	if($("#selConfigSettingOption").val()==1){
	 	jQuery('.makeDisabled').prop("disabled", true);
	}else{
		jQuery('#selhoursdd').attr('disabled',false);
		jQuery('#selminsdd').attr('disabled',false);
	}
}
jQuery('.autopoweroffCss').change(function(){		
		//var isCheckedAutpPowerChkBox=(jQuery('#autoPowerOff').is(':checked'))?1:0;
		var isCheckedAutpPowerChkBox=$('#autoPowerOffChkBoxVal').val();
		//alert($('#autoPowerOffChkBoxVal').val());
		if(isCheckedAutpPowerChkBox==1){
			var ddhour=jQuery('#selhoursdd').val();
			var ddmins=jQuery('#selminsdd').val();
			var concatVal=ddhour+':'+ddmins;
			//alert(concatVal);
			jQuery.autoPowerOff(isCheckedAutpPowerChkBox,concatVal);
			
		}
		
});

	jQuery('.autoPowerCss').click(function(){
		var autpPowerChkBoxVal=jQuery(this).attr('rev');		
		if(autpPowerChkBoxVal==1){
			$('#autoPowerOffChkBoxVal').val(1);
			jQuery('#selhoursdd').attr('disabled',false);
			jQuery('#selminsdd').attr('disabled',false);	

			jQuery('#chkAutoPowerOff').removeClass('active').addClass('inActive');
			jQuery('#chkAutoPowerON').removeClass('inActive').addClass('active');
			var ddhour=jQuery('#selhoursdd').val();
			var ddmins=jQuery('#selminsdd').val();				
			var concatVal=ddhour+':'+ddmins;
			
		}else{
			$('#autoPowerOffChkBoxVal').val(0);
			jQuery('#chkAutoPowerON').removeClass('active').addClass('inActive');
			jQuery('#chkAutoPowerOff').removeClass('inActive').addClass('active');
			jQuery('#selhoursdd').val('00');
			jQuery('#selminsdd').val('00');
			jQuery('#selhoursdd').attr('disabled',true);
			jQuery('#selminsdd').attr('disabled',true);	
			var concatVal='00'+':'+'00';
		}

		jQuery.autoPowerOff(autpPowerChkBoxVal,concatVal);
		
	});
        
        $('.zoomCss').click(function(){
		var optValue=($(this).attr('id')=='enableZoom')?1:0;
		//$('#pollingTabVal').val(optValue);		
		if(optValue==1){
			$('#disableZoom').removeClass('active').addClass('inActive');				
			$('#enableZoom').removeClass('inActive').addClass('active');
		}else{			
			$('#enableZoom').removeClass('active').addClass('inActive');
			$('#disableZoom').removeClass('inActive').addClass('active');
		}
		jQuery.advancedMoreFeatureConfiguration('ZoomSettings',optValue);		
		
	});
        
        $('.blueJeansCss').click(function(){
		var optValue=($(this).attr('id')=='enableBlueJeans')?1:0;
		//$('#pollingTabVal').val(optValue);		
		if(optValue==1){
			$('#disableBlueJeans').removeClass('active').addClass('inActive');				
			$('#enableBlueJeans').removeClass('inActive').addClass('active');
		}else{			
			$('#enableBlueJeans').removeClass('active').addClass('inActive');
			$('#disableBlueJeans').removeClass('inActive').addClass('active');
		}
		jQuery.advancedMoreFeatureConfiguration('BlueJeansSettings',optValue);		
		
	});
        
        $('.MSTeamsCss').click(function(){
		var optValue=($(this).attr('id')=='enableMSTeamsCss')?1:0;
		//$('#pollingTabVal').val(optValue);		
		if(optValue==1){
			$('#disableMSTeamsCss').removeClass('active').addClass('inActive');				
			$('#enableMSTeamsCss').removeClass('inActive').addClass('active');
		}else{			
			$('#enableMSTeamsCss').removeClass('active').addClass('inActive');
			$('#disableMSTeamsCss').removeClass('inActive').addClass('active');
		}
		jQuery.advancedMoreFeatureConfiguration('MSTeams',optValue);		
		
	});

if($('#autoRebootChkBoxVal').val()==0){
	jQuery('#selAutoRebootHoursList').attr('disabled',true);
	jQuery('#selAutoRebootMinsList').attr('disabled',true);	

}else{	
	jQuery('#selAutoRebootHoursList').attr('disabled',false);
	jQuery('#selAutoRebootMinsList').attr('disabled',false);

}

jQuery('.autoRebootOffCss').change(function(){	
		//var isCheckedAutpPowerChkBox=(jQuery('#autoPowerOff').is(':checked'))?1:0;
		var isCheckedAutpRebootChkBox=$('#autoRebootChkBoxVal').val();		
		if(isCheckedAutpRebootChkBox==1){
			var ddRebootHours=jQuery('#selAutoRebootHoursList').val();
			var ddRebootMins=jQuery('#selAutoRebootMinsList').val();
			var autoRebootConcatVal=ddRebootHours+':'+ddRebootMins;			
			jQuery.autoReboot(isCheckedAutpRebootChkBox,autoRebootConcatVal);
			
		}
		
});

	jQuery('.autoRebootCss').click(function(){
		var autoRebootChkBoxVal=jQuery(this).attr('rev');
		if(autoRebootChkBoxVal==1){
			$('#autoRebootChkBoxVal').val(1);
			jQuery('#selAutoRebootHoursList').attr('disabled',false);
			jQuery('#selAutoRebootMinsList').attr('disabled',false);
			jQuery('#chkAutoRebootOff').removeClass('active').addClass('inActive');
			jQuery('#chkAutoRebootON').removeClass('inActive').addClass('active');
			var ddRebootHours=jQuery('#selAutoRebootHoursList').val();
			var ddRebootMins=jQuery('#selAutoRebootMinsList').val();				
			var autoRebootConcatVal=ddRebootHours+':'+ddRebootMins;
			
		}else{
			$('#autoRebootChkBoxVal').val(0);
			jQuery('#chkAutoRebootON').removeClass('active').addClass('inActive');
			jQuery('#chkAutoRebootOff').removeClass('inActive').addClass('active');
			jQuery('#selAutoRebootHoursList').val('00');
			jQuery('#selAutoRebootMinsList').val('00');
			jQuery('#selAutoRebootHoursList').attr('disabled',true);
			jQuery('#selAutoRebootMinsList').attr('disabled',true);	
			var autoRebootConcatVal='00'+':'+'00';
		}
		jQuery.autoReboot(autoRebootChkBoxVal,autoRebootConcatVal);
		
	});		
		
	
	jQuery('#selDateFormatDD').change(function(){
		 var dateFormatDDVal=jQuery('#selDateFormatDD').val();		
		 var actionName='setDateFormat';		
		 jQuery.serverConfiguration(actionName,dateFormatDDVal);
								 
	});	
	jQuery('#selTimeFormatDD').change(function(){
		var timeFormatDDVal=jQuery('#selTimeFormatDD').val();
		var actionName='setTimeFormat';		
		jQuery.serverConfiguration(actionName,timeFormatDDVal);
	});	

	jQuery('.showAMPMBtnCSS').click(function(){
		var amPMradioBtnVal=$(this).attr('rev');
		var actionName='setAMPM';		
		jQuery.serverConfiguration(actionName,amPMradioBtnVal);
	});	
	
	jQuery('#setLang').change(function(){
		var langName=jQuery('#setLang').val();
		jQuery.setLanguage(langName);	
	});
	jQuery('#setDynamicLayout').change(function(){				   
		var optName=jQuery('#setDynamicLayout').val();
		if(optName==0){
			$('#dynamicLayoutChkbox').prop("disabled", true);
		}else{
			$('#dynamicLayoutChkbox').prop("disabled", false);		
		}		
		jQuery.setDisplayLayout(optName);	
	});
	
	jQuery('.activateClass').change(function(){				
		var getChkBoxName=jQuery(this).attr('id');		
		var getChkBoxVal=(jQuery('#'+getChkBoxName).is(':checked'))?1:0;
		jQuery.serverConfiguration(getChkBoxName,getChkBoxVal);
	});


	jQuery('.chkbox').click(function(){		
		var chkBoxName=jQuery(this).attr('id');
		var spanname=chkBoxName+'Span';
		
		var chkBoxVal=(jQuery('#'+chkBoxName).is(':checked'))?1:0;	
		if((chkBoxName=="showRoomName") && (chkBoxVal==0)){			
			jQuery('.enableIPBox').prop("disabled", true);
		}else if((chkBoxName=="showRoomName") && (chkBoxVal==1)){
			jQuery('.enableIPBox').prop("disabled", false);
		}
		$('#'+spanname).css('background-color',"#000000")
		jQuery.serverConfiguration(chkBoxName,chkBoxVal);
		
	});
	
	$("#refreshTime").change(function(){
		var selRevName=$(this).attr('id');
		var selBoxVal=$('#refreshTime').val();		
		jQuery.serverConfiguration(selRevName,selBoxVal);
	});
	
	
	jQuery('#applyBtn').click(function(){
		var fileName=$(this).attr('id');				
		var inputFieldVal=jQuery('#ipAddress').val();
		if(inputFieldVal==""){
			alert(jQuery('#alertRoomName').val());
			jQuery('#ipAddress').focus();
			return false;
		}
		var action=confirm(jQuery('#confirmProceed').val());
		if(action==true){
			jQuery.createRNameValShowFile(inputFieldVal,fileName);
		}
		
		
	});
	jQuery('#resetPIPBtn').click(function(){
		var fileName=$(this).attr('rev');		
		var operation="resetPIPSettings";		
		jQuery.serverConfiguration(operation,fileName);		
	});
	
$('.chkall').click(function(){
			if(this.checked) { // check select status
				$('.enableMychkbox').each(function() { //loop through each checkbox
					this.checked = true;  //select all checkboxes with class "checkbox1"              
				});
			}else{
				$('.enableMychkbox').each(function() { //loop through each checkbox
					this.checked = false; //deselect all checkboxes with class "checkbox1"                      
				});        
			}
								
});


	
	jQuery('.qrActivateClass').change(function(){			
		var getChkBoxName=jQuery(this).attr('id');	
		//alert(getChkBoxName);
		var getChkBoxVal=(jQuery('#'+getChkBoxName).is(':checked'))?1:0;
		if(getChkBoxName=='qrCodeChkbox'){
			if(getChkBoxVal==1){
				jQuery('#qrBypassChkbox').prop("disabled", false);
				jQuery('#qrTopChkbox').prop("disabled", false);
				jQuery('#qrBypassChkbox').prop("checked", true);				
			}else{
				jQuery('#qrBypassChkbox').prop("checked", false);				
				jQuery('#qrTopChkbox').prop("checked", false);
				//jQuery('#qrBypassChkbox').prop("disabled", false);
				//jQuery('#qrTopChkbox').prop("disabled", false);				
				
			}
		}
		//var getChkBoxVal=(jQuery('#'+getChkBoxName).is(':checked'))?1:0;
		jQuery.serverConfiguration(getChkBoxName,getChkBoxVal);

		//jQuery.serverDBConfiguration(getChkBoxName,getChkBoxVal,osType);
	});

// added on 6dec16 to make setting db based	
	if($('#overlayChkBoxVal').val()==0){
		jQuery('#overlayON').removeClass('active').addClass('inActive');
		jQuery('#overlayOff').removeClass('inActive').addClass('active');
		jQuery('#autoHideDD').attr('disabled',true)
	
	}else{	
		jQuery('#overlayOff').removeClass('active').addClass('inActive');
		jQuery('#overlayON').removeClass('inActive').addClass('active');
		jQuery('#autoHideDD').attr('disabled',false)
	
	}


	jQuery('.overlayCss').click(function(){
		var overlayChkBoxVal=jQuery(this).attr('rev');			
		if(overlayChkBoxVal==1){
			$('#overlayChkBoxVal').val(1);
			jQuery('#autoHideDD').attr('disabled',false);
			jQuery('#overlayOff').removeClass('active').addClass('inActive');
			jQuery('#overlayON').removeClass('inActive').addClass('active');

		}else{
			$('#overlayChkBoxVal').val(0);
			$('#autoHideDD').val(0);
			jQuery('#autoHideDD').attr('disabled',true);
			jQuery('#overlayON').removeClass('active').addClass('inActive');
			jQuery('#overlayOff').removeClass('inActive').addClass('active');
			
		}		
		
		jQuery.setConfigurationDB('overlayOnOff',overlayChkBoxVal);
		
	});
	
	jQuery('#autoHideDD').change(function(){			
			var autoHideDD=$('#autoHideDD').val();
			jQuery.setConfigurationDB('overlayValueChange',autoHideDD);
			
	});
	
        // Disabled all elements when select HQ in cinfiguration. Added on 7Dec16. Move from  upside
	if($("#selConfigSettingOption").val()==1){	
		  jQuery('.makeDisabled').prop("disabled", true);
	}
        //Disabled modal
        $('#mymodal').on('show.bs.modal', function (e) {
            var button = e.relatedTarget;
            if($(button).hasClass('makeDisabled')) {
              e.stopPropagation();
            }  
        });

        
        jQuery('.activateHDMIChkbox').change(function(){
                var getChkBoxVal=jQuery(this).attr('id');
                var optValue=(jQuery('#'+getChkBoxVal).is(':checked'))?1:0;		
                jQuery.advancedMoreFeatureConfiguration('DefHDMIMod',optValue);
        });

        $('#saveProxySetting').click(function(){
            var serverName=jQuery('#proxyServerName').val();
            var serverPort=jQuery('#proxyPort').val();
            var username=jQuery('#proxyUserName').val();
            var password=jQuery('#proxyPassword').val();
            var WhiteSpacePattern=/^[^\s]+$/;
            
            var portRegex=/^([0-9]{1,4}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$/
            if(serverName==""){
                    jQuery('#proxyServerName').removeClass('netSetNormalmsg').addClass('netSetRedmsg');
                    jQuery('#proxyPort').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPassword').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyServerName').focus();
                    alert('Please enter server name');
                    return false;									
            }else if(!serverName.match(WhiteSpacePattern)){
                    jQuery('#proxyServerName').removeClass('netSetNormalmsg').addClass('netSetRedmsg');
                    jQuery('#proxyPort').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPassword').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyServerName').focus();
                    alert(jQuery('#spacemsg').val());
                    return false;					
            }else if(serverPort==""){
                    jQuery('#proxyPort').removeClass('netSetNormalmsg').addClass('netSetRedmsg');
                    jQuery('#proxyServerName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPassword').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    alert('Please enter port number');
                    jQuery('#proxyPort').focus();
                    return false;									
            }else if(!serverPort.match(portRegex)){
                    jQuery('#proxyPort').removeClass('netSetNormalmsg').addClass('netSetRedmsg');
                    jQuery('#proxyServerName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPassword').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    alert('Please enter valid port number from 0 to 65535');
                    jQuery('#proxyPort').focus();
                    return false;					
            }else if(username!="" && password==""){
                    jQuery('#proxyPassword').removeClass('netSetNormalmsg').addClass('netSetRedmsg');
                    jQuery('#proxyServerName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPort').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPassword').focus();
                    alert('Please enter password');
                    return false;									
            }else if(username=="" && password!=""){
                    jQuery('#proxyUserName').removeClass('netSetNormalmsg').addClass('netSetRedmsg');
                    jQuery('#proxyPassword').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyServerName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPort').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').focus();
                    alert('Please enter username');
                    return false;									
            }else{
                    jQuery('#proxyServerName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPort').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyUserName').removeClass('netSetRedmsg').addClass('netSetNormalmsg');
                    jQuery('#proxyPassword').removeClass('netSetRedmsg').addClass('netSetNormalmsg');                   
                    jQuery.ajax({
                        type:'POST',
                        url:'proxySetting',
                        data:'servername='+serverName+'&port='+serverPort+'&username='+username+'&password='+encodeURIComponent(password),
                        dataType:'html',
                        success: function(responseData, status, XMLHttpRequest){
                            alert(jQuery('#applySettingsAlert').val());
                            $('#resetProxySetting').attr('disabled',false);
                            //$('#resetProxySetting').css('background-color','#35acf8');
                            //$('#resetProxySetting').css('color','#fff');
                        }
                    })
            }
        });
        var hqserver = $("#hqserver").val();
	if($('#proxyServerName').val()==''){
            $('#resetProxySetting').attr('disabled',true);
        }else{
            if(hqserver==1){
                $('#resetProxySetting').attr('disabled',true);
                $('#saveProxySetting').attr('disabled',true);
            }else{
                $('#resetProxySetting').attr('disabled',false);
                $('#saveProxySetting').attr('disabled',false);
            }
        }
        $('#resetProxySetting').click(function(){
            jQuery.ajax({
                type:'POST',
                url:'resetProxySetting',
                dataType:'html',
                success: function(responseData, status, XMLHttpRequest){
                    if($.trim(responseData)=='success'){
                        alert("Reset successfully");
                        jQuery('#proxyServerName').val('');
                        jQuery('#proxyPort').val('');
                        jQuery('#proxyUserName').val('');
                        jQuery('#proxyPassword').val('');
                        $('#resetProxySetting').attr('disabled',true);
                    }
                }
            });
        });

});
(function(jQuery){
	jQuery.serverConfiguration = function(chkBoxName,chkBoxVal){
		jQuery.ajax({
				type:'POST',
                                async:false,
				url:'serverConfiguration',
				data:'chkBoxName='+chkBoxName+'&chkBoxVal='+chkBoxVal,
				dataType:'html',
				beforeSend : function(){
					//jQuery('#loadingImg').html("<img src='images/icoLoader.gif'> You are going to Logout...");
				},
				success:function(responseData, status, XMLHttpRequest){
                                        var responseData = responseData.trim();
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
					if(responseData=='pmodesuccess'){
						var myip=jQuery('#ipFromFile').val();
						var myport=jQuery('#portFromFile').val();
						jQuery(window.location).attr('href','authentication');
					}
					if(responseData=='settingApply'){
						alert(jQuery('#applySettingsAlert').val());
					}
					if(responseData=='qrcodeEnable'){
						$('#showQRDownloadDiv').show();
					}
					if(responseData=='qrcodeDisable'){
						$('#showQRDownloadDiv').hide();
					}
					if(responseData=='File Updated'){
                                            location.reload();
                                        }
						
				}					
			});
	
	}
})(jQuery);

(function(jQuery){
	jQuery.autoPowerOff=function(autpPowerChkBoxVal,concatVal){	
		jQuery.ajax({
				type:'POST',
				url:'autoPowerOff',
				data:'autpPowerChkBoxVal='+autpPowerChkBoxVal+'&concatVal='+concatVal,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
					
				}					
			});
		
	}			
		  
})(jQuery);

(function(jQuery){
	jQuery.autoReboot=function(autoRebootChkBoxVal,autoRebootConcatVal){	
		jQuery.ajax({
                        type:'POST',
                        url:'autoReboot',
                        data:'autoRebootChkBoxVal='+autoRebootChkBoxVal+'&concatVal='+autoRebootConcatVal,
                        dataType:'html',
                        beforeSend : function(){
                        },
                        success:function(responseData, status, XMLHttpRequest){
                                // added on 19Dec2016
                                if(responseData=='sessionExpired'){
                                        alert($('#alertSessionExpired').val());
                                        jQuery(window.location).attr('href','index');
                                }
                        }					
                });	
	}			
		  
})(jQuery);



(function(jQuery){
	jQuery.createRemoveMirrorFiles=function(keyword){	
		jQuery.ajax({
				type:'POST',
				url:'enableDisabledMirrorFiles',
				data:'keyword='+keyword,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}else{
						if(keyword=='create'){
							$('#mirrorName').val(responseData);
                                                        $('#mirrorName').next().addClass('activeCss');
						}
						if(keyword=='delete'){
							$('#mirrorName').val('');
                                                        $('#mirrorName').next().removeClass('activeCss');
						}
					}
					
				}					
			});
		
	}			
		  
})(jQuery);

(function(jQuery){
	jQuery.createNewMirrorSettings=function(keyword,mirrorName,maxNoOfMirrors){
		jQuery.ajax({
				type:'POST',
				url:'enableDisabledMirrorFiles',
				data:'keyword='+keyword+'&mirrorName='+mirrorName+'&maxNoOfMirrors='+maxNoOfMirrors,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){
					if(responseData=='success'){
						jQuery(window.location).attr('href','viaConfiguration');
					}
				}					
			});
		
	}			
		  
})(jQuery);

(function(jQuery){
	jQuery.setLanguage=function(langName){	
		jQuery.ajax({
				type:'POST',
				url:'setLanguage',
				data:'langName='+langName,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){	
					// added on 19Dec2016
					if(responseData=='sessionExpired'){						
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
				
				}					
			});
		
	}			
		  
})(jQuery);
(function(jQuery){
	jQuery.setDisplayLayout=function(optName){	
		jQuery.ajax({
				type:'POST',
				url:'setDisplayLayout',
				data:'optName='+optName,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){	
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
				}					
			});
		
	}			
		  
})(jQuery);


(function(jQuery){
	jQuery.advancedServerConfiguration = function(chkBoxName,chkBoxVal){
		jQuery.ajax({
				type:'POST',
				url:'advancedConfiguration',
				data:'chkBoxName='+chkBoxName+'&chkBoxVal='+encodeURIComponent(chkBoxVal),
				dataType:'html',
				beforeSend : function(){
					//jQuery('#loadingImg').html("<img src='images/icoLoader.gif'> You are going to Logout...");
				},
				success:function(responseData, status, XMLHttpRequest){
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
					
					if(responseData=='success'){
						alert(jQuery('#applySettingsAlert').val());
					}
					if(responseData=='successAndReboot'){
						alert(jQuery('#alert_applyAndReboot').val());
					}
					if(responseData=='unsuccess'){
						alert(jQuery('#alert_apply_unsuccess').val());
					}
					
					
				}					
			});
	
	}
})(jQuery);

(function(jQuery){
	jQuery.advancedServerConfigurationFileSharing = function(chkBoxName,chkBoxVal,textareaValues){
		jQuery.ajax({
				type:'POST',
				url:'advancedConfiguration',
				data:'chkBoxName='+chkBoxName+'&chkBoxVal='+encodeURIComponent(chkBoxVal)+'&textareaValues='+encodeURIComponent(textareaValues),
				dataType:'html',
				beforeSend : function(){
					//jQuery('#loadingImg').html("<img src='images/icoLoader.gif'> You are going to Logout...");
				},
				success:function(responseData, status, XMLHttpRequest){
				
					if(responseData=='success'){
						alert(jQuery('#applySettingsAlert').val());
						$(window.location).attr('href','advancedConfiguration');
					}
					
					
				}					
			});
	
	}
})(jQuery);


(function(jQuery){
	jQuery.setStreamingConfiguration = function(chkBoxName,chkBoxVal,url1,url2){
		jQuery.ajax({
				type:'POST',
				url:'advancedConfiguration',
				data:'chkBoxName='+chkBoxName+'&chkBoxVal='+encodeURIComponent(chkBoxVal)+'&url1='+url1+'&url2='+url2,
				dataType:'html',
				beforeSend : function(){
					//jQuery('#loadingImg').html("<img src='images/icoLoader.gif'> You are going to Logout...");
				},
				success:function(responseData, status, XMLHttpRequest){					
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
					
					if(responseData=='success'){
						alert(jQuery('#applySettingsAlert').val());
					}
					if(responseData=='successAndReboot'){
						alert(jQuery('#alert_applyAndReboot').val())
					}
					if(responseData=='unsuccess'){
						alert(jQuery('#alert_apply_unsuccess').val())
					}
					
					
				}					
			});
	
	}
})(jQuery);

(function(jQuery){
	jQuery.advancedMoreFeatureConfiguration = function(settingName,settingVal){
		jQuery.ajax({
				type:'POST',
				url:'advancedMoreConfiguration',
				data:'settingName='+settingName+'&settingVal='+settingVal,
				dataType:'html',
				beforeSend : function(){
					//jQuery('#loadingImg').html("<img src='images/icoLoader.gif'> You are going to Logout...");
				},
				success:function(responseData, status, XMLHttpRequest){
					
					// added on 19Dec2016
					if(responseData=='sessionExpired'){
						alert($('#alertSessionExpired').val());
						jQuery(window.location).attr('href','index');
					}
					
					if(responseData=='success'){
						alert(jQuery('#applySettingsAlert').val());
					}
					if(responseData=='successAndReboot'){
						alert(jQuery('#alert_applyAndReboot').val())
					}
					if(responseData=='unsuccess'){
						alert(jQuery('#alert_apply_unsuccess').val())
					}
					
					
				}					
			});
	
	}
})(jQuery);
(function(jQuery){
	jQuery.deactivateGatewayFeatures=function(iconID,delFlag){
		jQuery.ajax({
                        type:'POST',
                        url:'deactivateGatewayFeatures',
                        data:'iconID='+iconID+'&delFlag='+delFlag,
                        dataType:'html',
                        beforeSend : function(){
                        },
                        success:function(responseData, status, XMLHttpRequest){	
                                if(responseData=="via" || responseData=="collab8"){
                                    //alert($('#deactivateFeatureAlert').val());
                                }else{
                                    alert(responseData);
                                }
                        }					
                });		
	}		  
})(jQuery);

(function(jQuery){
	jQuery.deactivateClientFeatures=function(iconID,delFlag){
		jQuery.ajax({
                        type:'POST',
                        url:'deactivateClientFeatues',
                        data:'iconID='+iconID+'&delFlag='+delFlag,
                        dataType:'html',
                        beforeSend : function(){
                        },
                        success:function(responseData, status, XMLHttpRequest){
                            if(responseData=="via" || responseData=="collab8"){
                                //alert('hi');
                            }else{
                                alert(responseData);
                            }
                        }					
                });
		
	}			
		  
})(jQuery);
