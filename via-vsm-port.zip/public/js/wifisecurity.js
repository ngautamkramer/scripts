$(document).ready(function(){
	var chkAutoconnectChkbox=(jQuery('#txtAutoconnect').is(':checked'))?1:0;
	if(chkAutoconnectChkbox==0){
			jQuery('#ssidRow').hide();
			jQuery('#authModeRow').hide();
			jQuery('#encryptionRow').hide();
			jQuery('#keyRow').hide();
		
	}
	
	$('#txtAutoconnect').click(function(){
		var chkAutoconnectChkbox=(jQuery('#txtAutoconnect').is(':checked'))?1:0;
		if(chkAutoconnectChkbox==1){
			jQuery('#ssidRow').show();
			jQuery('#authModeRow').show();
			jQuery('#encryptionRow').show();
			jQuery('#keyRow').show();
		}else{	
			jQuery('#ssidRow').hide();
			jQuery('#authModeRow').hide();
			jQuery('#encryptionRow').hide();
			jQuery('#keyRow').hide();
		
		}
										
	});	
	
	if($('#encryptionDDBox').val()=='none' || $('#encryptionDDBox').val()==''){
		jQuery('#keyRow').hide();		
	}else{
		jQuery('#keyRow').show();
	}					   
	$('#authentiationMode').change(function(){
			var authentiationMode=$('#authentiationMode').val();
			jQuery.changeEncryptionBoxByAction(authentiationMode);
												   
	});	
	$(document).on('change','#encryptionDDBox', function(){
		var encryptionDDBoxVal=$('#encryptionDDBox').val();	
		if(encryptionDDBoxVal=='none'){			
			$('#txtKey').val('');
			$('#keyRow').hide();
		}else{
			$('#keyRow').show();
		}
	});
	
	$('#wifisecurityFrm').submit(function(){
		var txtKey='';
		var txtKey='';	
		
		var authentiationMode=$('#authentiationMode').val();
		var encryptionDDBoxVal=$('#encryptionDDBox').val();
		//alert(encryptionDDBoxVal);
		var autoconnectChkbox=($('#txtAutoconnect').is(':checked'))?1:0;
		var txtGuest=($('#txtGuest').is(':checked'))?1:0;
		var txtSSID=htmlEncode($('#txtSSID').val());
		var txtKey=$('#txtKey').val();	
		
		var txtRoomcode=($('#roomcodeDD').is(':checked'))?0:1;
		var txtRoomName=$('#txtRoomname').val();

		var ssid=$('#ssid').val();
		var invalidssid=$('#invalidssid').val();
		var authMode=$('#authmode').val();
		var encryptiontype=$('#encryptiontype').val();
		var keytext=$('#keytext').val();
		var invalidkey=$('#invalidkey').val();
		var invalidchar=$('#invalidchar').val();

	if(autoconnectChkbox==1){	
		if(txtSSID==''){
				$('#err2').html(ssid);
				return false;	
		}
		if(txtSSID.length>35){
				$('#err2').html(invalidssid);
				return false;
		}
		if(authentiationMode==""){
				$('#err2').html('');
				$('#err1').html(authMode);
				return false;
		}
		if(encryptionDDBoxVal==''){
			$('#err1').html('');
			$('#err2').html('');
			$('#err4').html(encryptiontype);
			return false;
		}
		if(encryptionDDBoxVal!='none'){
			if(txtKey==''){
				$('#err1').html('');
				$('#err2').html('');
				$('#err4').html('');
				$('#err3').html(keytext);
				return false;
			}else if(txtKey.length>50){
				$('#err1').html('');
				$('#err2').html('');
				$('#err4').html('');
				$('#err3').html(invalidkey);
				return false;				
			}else if(txtKey.search("<")!=-1 || txtKey.search(">")!=-1){
				$('#err1').html('');
				$('#err2').html('');
				$('#err4').html('');
				$('#err3').html(invalidchar);
				return false;	
			}
			else{
				$('#err1').html('');
				$('#err2').html('');
				$('#err3').html('');
				$('#err4').html('');
				var act=confirm(jQuery('#confirmProceed').val());
				if(act==true){					
					$.settingWiFiSecurityAction(authentiationMode,encryptionDDBoxVal,autoconnectChkbox,txtSSID,txtKey,txtRoomcode,txtGuest,txtRoomName);
				}else{
					return false;
				}
				return false;
			}
			
		}else{		
			$('#err1').html('');
			$('#err2').html('');
			$('#err3').html('');
			$('#err4').html('');
			var act=confirm($('#confirmProceed').val());
			if(act==true){
				jQuery.settingWiFiSecurityAction(authentiationMode,encryptionDDBoxVal,autoconnectChkbox,txtSSID,txtKey,txtRoomcode,txtGuest,txtRoomName);
				
			}else{
				return false;
			}			
			
			return false;
			
		}
	}// end of if condition if autoconnect is checked
	if(autoconnectChkbox==0){	
			var act=confirm(jQuery('#confirmProceed').val());
			if(act==true){
				jQuery.settingWiFiSecurityAction(authentiationMode='',encryptionDDBoxVal='',autoconnectChkbox,txtSSID='',txtKey='',txtRoomcode,txtGuest,txtRoomName);
				
			}else{
				return false;
			}			
	
	}
return false;
});	
						   
	$('#uploadWifiSecurityFrm').submit(function(){		
		var uploadedfile=jQuery('#uploadedfile').val();
		if(uploadedfile==''){
			alert(jQuery('#selFileAlert').val());	
			return false;
		}else{
			return true;
		}
		return false;
	});
	
	
		$('#showViaPadPassword').click(function(){
			var base_url = $('#baseUrl').val();
			var passwordField = document.getElementById('txtKey');
			var value = passwordField.value;	
			if(passwordField.type == 'password') {
				passwordField.type = 'text';
				$(this).attr("src", base_url+"/public/img/passwordHide.png");
			}
			else {
				passwordField.type = 'password';
				$(this).attr("src", base_url+"/public/img/passwordView.png");
			}	
		
		});
	
            if($('#txtGuest').is(':checked')){
                $('#roomcodeDD').prop('checked', true);
                $('#roomcodeDD').prop('readonly', 'readonly');
                $('#roomcodeDD').prop('disabled', 'disabled');
            }else{
                $('#roomcodeDD').prop('readonly', false);
                $('#roomcodeDD').prop('disabled', false);
            }

            $('#txtGuest').change(function(){
               if($(this).is(':checked')){
                   $('#roomcodeDD').prop('checked', true);
                   $('#roomcodeDD').prop('readonly', 'readonly');
                   $('#roomcodeDD').prop('disabled', 'disabled');
               }else{
                   $('#roomcodeDD').prop('readonly', false);
                   $('#roomcodeDD').prop('disabled', false);
               }
            });

});

// unction for Reset Configuration
(function(jQuery){
	jQuery.changeEncryptionBoxByAction=function(authentiationMode){
		jQuery.ajax({
				type:'POST',
				url:'changeEncryptionBox',
				data:'authentiationMode='+authentiationMode,
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){	
				jQuery('#encryptionBox').html(responseData);
					if(authentiationMode=='shared' || authentiationMode=='WPAPSK' || authentiationMode=='WPA2PSK'){
						jQuery('#keyRow').show();	
					}else{
						jQuery('#keyRow').hide();	
					}
					
					
				}					
			});
		
	}			
		  
})(jQuery);

(function(jQuery){
	jQuery.settingWiFiSecurityAction=function(authentiationMode,encryptionDDBoxVal,autoconnectChkbox,ssid,securityKey,txtRoomcode,txtGuest,txtRoomName){
		jQuery.ajax({
				type:'POST',
				url:'settingWiFiSecurity',
				data:'authentiationMode='+authentiationMode+'&encryption='+encryptionDDBoxVal+'&autoconnect='+autoconnectChkbox+'&ssid='+encodeURIComponent(ssid)+'&securityKey='+encodeURIComponent(securityKey)+'&txtRoomcode='+txtRoomcode+'&txtGuest='+txtGuest+'&txtRoomName='+encodeURIComponent(txtRoomName),
				dataType:'html',
				beforeSend : function(){
				},
				success:function(responseData, status, XMLHttpRequest){
					if(responseData==1){
                                                alert(jQuery('#applySettingsAlert').val());						
                                                setTimeout(function(){window.location = 'viapadSettings';}, 1000);							
					}
					if(responseData==0){
						alert($("#alertEncryptionOrKeyNotDef").val());
					}
				
				}
			});
		
	}			
		  
})(jQuery);
