$(document).ready(function(){
    $('#showViaPassword').on('click',function(){
            var passwordField = document.getElementById('txtRegPassword');
            var value = passwordField.value;	
            if(passwordField.type == 'password') {
                    passwordField.type = 'text';
            }
            else {
                    passwordField.type = 'password';
            }	

    });
	
	
    $('#btnOk').click(function(){	
	
        var email=$('#txtRegEmail').val();
		var passwd = $('#txtRegPassword').val();	
		var emailPattern = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/;
		var WhiteSpacePattern=/^[^\s]+$/;
		if(email==""){
            $('#txtRegEmail').focus();
            $('#txtRegEmail').addClass('errorClass');
			$('#erremail').html($('#emailmsg').val());					
            return false;
            
		}else if(!email.match(WhiteSpacePattern)){
            $('#txtRegEmail').focus();
            $('#txtRegEmail').addClass('errorClass');
			$('#erremail').html($('#invalidmsg').val());
			
			return false;					
		}else if(!email.match(emailPattern)){
            $('#txtRegEmail').focus();
            $('#txtRegEmail').addClass('errorClass');
			$('#erremail').html($('#invalidmsg').val());
			return false;					
		}else if(passwd==""){
                        $('#erremail').html('');
                        $('#txtRegEmail').removeClass('errorClass');
                        $('#txtRegPassword').addClass('errorClass');
                        $('#txtRegPassword').focus();
                        $('#errpasswd').html($('#urpassmsg').val());
                        return false;				
		}else if(!passwd.match(WhiteSpacePattern)){
                        $('#erremail').html('');
                        $('#txtRegEmail').removeClass('errorClass');
                        $('#txtRegPassword').addClass('errorClass');
                        $('#errpasswd').html($('#spacemsg').val());
                        $('#txtRegPassword').focus();
                        return false;	
		
		}else{
                        $('#erremail').html('');
                        $('#txtRegEmail').removeClass('errorClass');			
                        $('#errpasswd').html('');
                        $('#txtRegPassword').removeClass('errorClass');
						
						
	
             $.ajax({
                    type:'POST',
                    url:'saveRegisterUnit',
                    data:'email='+encodeURIComponent(email)+'&password='+encodeURIComponent(passwd),
                    dataType:'html',
                    success:function(responseData, status, XMLHttpRequest){
                            if(responseData=="success"){
                             $('#msg').html(jQuery('#successMsg').val());		
                              $('#msg').fadeIn().delay(2000).fadeOut('slow');
										setTimeout(function(){ location.reload()}, 2000);
                            }else if(responseData=="empty"){
                                $('#msg').html(jQuery('#unreachableMsg').val());	
				$('#msg').fadeIn().delay(2000).fadeOut('slow');
                            }else if(responseData == "sessionout"){
								alert("Your session has expired. Please login again.");
								location.reload();
							}else{
                                $('#msg').html($('#failedMsg').val());	
				$('#msg').fadeIn().delay(2000).fadeOut('slow');
                            }					
                    }					
            });
        }
        			
    });
    
    $("#btnReset").click(function(){
        var btnReset = $('#btnReset').val();
       
        var returnVal = confirm($('#confirmDeleteMsg').val());
        if(returnVal==true){
            $('#txtRegEmail').val('');
            $('#txtRegPassword').val('');
            $('#txtRegPassword').next().removeClass('activeCss');
            $('#txtRegEmail').next().removeClass('activeCss');
            $.ajax({
                        type:'POST',
                        url:'resetUnit',
                        data:'btnVal='+btnReset,
                        dataType:'html',
                        success:function(responseData, status, XMLHttpRequest){
                                if(responseData=="success"){
                                    $('#msg').html($('#resetSuccessMsg').val());
                                    $('#msg').fadeIn().delay(2000).fadeOut('slow');
                                    setTimeout(function(){ location.reload()}, 2000);
                                }else{
                                    $('#msg').html($('#resetFailMsg').val());
                                    $('#msg').fadeIn().delay(2000).fadeOut('slow');
                                }					
                        }					
                });           
        }
        
    });
   
});