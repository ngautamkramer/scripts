$(document).ready(function(){
    $(function () {
                 
            var myTest=JSON.parse($('#myTest').val());  //JSON_NUMERIC_CHECK- remove the quotes from numeric value.
            var myT=JSON.parse($('#mygName').val());
            console.log(myTest);
            Highcharts.setOptions({
                colors: ['#C40F39']
             });
             $('#container').highcharts({
                     chart: {
                             type: 'column'
                     },
                     title: {
                             text: ''
                     },
                     credits: {
                             enabled: false
                     },
                     exporting: { 
                             enabled: false 
                     },
                     tooltip: {
                             pointFormat: false
                     },
                     xAxis: {
                             categories: myT,
                             title: {
                                     text: 'Gateway name'
                             },
                             type: 'category',
                             labels: {
                                     rotation:-20,

                                     style: {
                                             fontSize: '13px',
                                             fontFamily: 'Verdana, sans-serif'
                                     }
                             }
                     },
                     yAxis: {																									
                             min: .01,
                             title: {
                                     text: 'Total Hours'
                             }
                     },
                     legend: {
                             enabled: false
                     },
                     series: [{
                             name: 'Test',
                             data: myTest,
                             dataLabels: {
                                     enabled: true,
                                     rotation:0,
                                     color: '#5B5B5B',
                                     align: 'right',
                                     y: 1, // 10 pixels down from the top
                                     formatter: function () {
                                             return Highcharts.numberFormat(this.y,2);
                                     },
                                     style: {
                                             fontSize: '13px',
                                             fontFamily: 'Verdana, sans-serif'
                                     }
                             }
                     }]
             });
    });
});