$(document).ready(function(){
    $(function () {
                 
            var myTest=JSON.parse($('#myTest').val());  //JSON_NUMERIC_CHECK- remove the quotes from numeric value.
            console.log(myTest);
            Highcharts.setOptions({
                colors: ['#C40F39']
            });
             $('#container').highcharts({
                     chart: {
                             type: 'column'
                     },
                     title: {
                             text: ''
                     },
                     credits: {
                             enabled: false
                     },
                     exporting: { 
                             enabled: false 
                     },
                     tooltip: {
                             pointFormat: false
                     },
                     xAxis: {
                             title: {
                                     text: 'UserName'
                             },
                             type: 'category',
                             labels: {
                                     rotation:-30,

                                     style: {
                                             fontSize: '13px',
                                             fontFamily: 'Verdana, sans-serif'
                                     }
                             }
                     },
                     yAxis: {																									
                             min: .01,
                             title: {
                                     text: 'Total Count'
                             }
                     },
                     legend: {
                             enabled: false
                     },
                     series: [{
                             name: 'Test',
                             data: myTest,
                             dataLabels: {
                                     enabled: true,
                                     rotation:0,
                                     color: '#5B5B5B',
                                     align: 'center',
                                     format: '{point.y}', // one decimal
                                     y: -30, // 10 pixels down from the top
                                     style: {
                                             fontSize: '13px',
                                             fontFamily: 'Verdana, sans-serif'
                                     }
                             }
                     }]
             });
    });
});