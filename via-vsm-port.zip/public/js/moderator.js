
$(document).ready(function(){

		/* *********************************************************** Authentication Page Code ******************************* */
	// Disabled all if auth mode is HQ
	if($("#selAuthSettingOption").val()==1){	
		
			$("input[name=radioBtn]").prop('disabled', true);
			$("input[name=presentationMode]").prop('disabled', true);
			
			//$("input[name=chkboxAuthentiCation]").prop('disabled', true);
			$("#activatemoderatorF").attr("disabled", true);
			$("#activatemoderatorT").attr("disabled", true);
			//$('.ui-segment').prop('disabled',true);
			$(".chkboxAuthentiCation").attr("disabled", "disabled").off('click');
			
			$("input[name= participantConfChkbox]").prop('disabled', true);
			$("input[name=disableAllFeaturesChkbox]").prop('disabled', true);
			$("input[name=activatepolling]").prop('disabled', true);
			$("input[name=activateChatChkbox]").prop('disabled', true);
			$('.txtpassword').css('display','none');
	        $('#labelYes').prop('disabled',true);
		   // jQuery('.enabled').prop("disabled", true);
			if(jQuery('#pmodeFileData').val()==1){
				$("input[name=radioBtn][value="+1+"]").prop('checked', true);
			}
			if(jQuery('#pmodeFileData').val()==2){
				$("input[name=radioBtn][value="+2+"]").prop('checked', true);
			}
			if(jQuery('#pmodeFileData').val()==3){		
				 $("input[name=radioBtn][value="+3+"]").prop('checked', true);
			}
			
	}
		
		//var presentationModeCheckBox=(jQuery('#presentationMode').is(':checked'))?1:0;
		var presentationModeCheckBox=$('#presentationMode').val();
		var file_strADSettings=jQuery('#file_strADSettings').val();
		var file_strOUGroup=jQuery('#file_strOUGroup').val();
		var pmodeFileData=jQuery('#pmodeFileData').val();
		
		/********************************** If presentationModeCheckBox already checked ******************** */
		
      	if(presentationModeCheckBox==1 && $("#selAuthSettingOption").val()==2){
			if(pmodeFileData==1){
				$("input[name=radioBtn][value="+1+"]").prop('checked', true);
				$('.activedirectorysetting').css('display','none');
				$('.txtpassword').css('display','none');
			}

			if(pmodeFileData==2){
				$('.activedirectorysetting').css('display','block');
				$('.txtpassword').css('display','none');
				$("input[name=radioBtn][value="+2+"]").prop('checked', true);
			}
                        
			if(pmodeFileData==3){
				$('.txtpassword').css('display','block');
				$('.activedirectorysetting').css('display','block');
				$('.directorycss').css('display','none');
				$('.disableAllFeatures').css('display','none');
			    $("input[name=radioBtn][value="+3+"]").prop('checked', true);
			}
		}
		else{
			if($("#selAuthSettingOption").val()!=1){
			$('.activedirectorysetting').hide();
			$("input[name=radioBtn]").prop('checked', false);
			$("input[name=radioBtn]").prop('disabled', true);
			$("input[name= participantConfChkbox]").prop('disabled', true);
			$("input[name=disableAllFeaturesChkbox]").prop('disabled', true);
			$("input[name=radioBtn]").prop('checked', false);
			$("input[name=activatepolling]").prop('disabled', true);
			$("input[name=activateChatChkbox]").prop('disabled', true);
	        $('#labelYes').prop('disabled',true);
			}
		}
		
	$('.chkboxAuthentiCation').click(function(){
	    var featureId = $(this).attr('id');
		var idStatus = featureId.substr(featureId.length - 1);
		var feature = featureId.substr(0, featureId.length-1);
					
		var optValue=(idStatus==='T')?1:0;

	

		
		var myaction=confirm(jQuery('#switchModeAlert').val());
	     if(myaction==true){
		if(optValue==1){
		$('#'+feature+'T').removeClass('inActive').addClass('active');				
		$('#'+feature+'F').removeClass('active').addClass('inActive');
		}										   
		var chkBoxName=jQuery(this).attr('id');
		var file_strADSettings=jQuery('#file_strADSettings').val();
		var file_strOUGroup=jQuery('#file_strOUGroup').val();
		var spanname=chkBoxName+'Span';
		var chkBoxVal=optValue;
		//var chkBoxVal=(jQuery('#'+chkBoxName).is(':checked'))?1:0;
		
		jQuery.serverConfiguration('presentationMode',chkBoxVal);	
		if(chkBoxVal==1){
		  jQuery('#fieldset2').hide();	
		  $('.activedirectory').prop('disabled',false);
		  jQuery('#dbBased').prop("disabled", false);
		  jQuery('#adBased').prop("disabled", false);
		  jQuery('#dbBased').prop("checked", true);
		
	}else{
	      jQuery('#fieldset2').hide();
		 $('.activedirectory').prop('disabled',true);
		 $('#applybtn').prop('disabled',true);
	     $('#password').css('display','none');
		 $('#applybtn').css('display','none');
	}		
		//jQuery.serverConfiguration(chkBoxName,chkBoxVal);
		}else{
		return false;	
		}
		
	});
	
$("input[name='radioBtn']").click(function(){
	var val =$('input:radio[name=radioBtn]:checked').val();
	if(val==1)
	{
	    $('.activedirectorysetting').css('display','none');
	    $('.txtpassword').css('display','none');
	     var operation='deleteAuthenticationFiles';
	     var numOfFiles=2;
	     jQuery.serverConfiguration('appendPresentationMode',val);
		 jQuery.serverConfiguration(operation,numOfFiles);
	}
	if(val==3)
	{
		 $('.txtpassword').css('display','block');
	     $('.activedirectorysetting').css('display','block');
		 $('.directorycss').css('display','none');
		 $('.disableAllFeatures').css('display','none');
	     var operation='deleteAuthenticationFiles';
	     var numOfFiles=2;				  
	     jQuery.serverConfiguration('appendPresentationMode',val);
	    jQuery.serverConfiguration(operation,numOfFiles);
	}
	
		$('.activedirectorysetting').css('display','block');
		$('.txtpassword').css('display','none');
		 jQuery.serverConfiguration('appendPresentationMode',val);
	
	
	
});

	$('#applyAuthPassBtn').click(function(){	

		var basicAuthPassword=$('#password').val();
	
		var WhiteSpacePattern=/^[^\s]+$/;
		var alphanumricNoSpecial=/^(?=.*[a-zA-Z])(?=.*[0-9])[a-zA-Z0-9]+$/;
		var alphanumricPattern=/^(?=.*[0-9])(?=.*[a-z]).*$/i;
     	var specialCharPattern=/^(?=.*[!"#$%&'()*+,-./:;<=>?@[\]^_`{|}~]).*$/;
		var capitalLtrPattern=/^(?=.*[A-Z]).*$/;
		var alphanumericVal=$('#alphanumericVal').val();
	    var specialCharVal=$('#specialCharVal').val();
     	var capitalLtrVal=$('#capitalLtrVal').val();
		var minCharVal=$('#minCharVal').val();
		var basicModeVal=$('#basicModeVal').val();
	
    	if(basicAuthPassword.substring(0,1)==' '){
			alert(jQuery('#spacemsg').val());
		$('#password').focus();
		}else if(basicAuthPassword.length>0 && !basicAuthPassword.match(WhiteSpacePattern)){
			alert(jQuery('#spacemsg').val());
			$('#password').focus();
		}else if(alphanumericVal==1 && basicModeVal==1 && !basicAuthPassword.match(alphanumricNoSpecial) && specialCharVal!=1 ){
		        alert($('#AlphanumricMsg').val());
			$('#password').focus();				
		}else if(alphanumericVal==1 && basicModeVal==1 && !basicAuthPassword.match(alphanumricPattern) && specialCharVal==1 ){
		        alert($('#AlphanumricMsg').val());
			$('#password').focus();				
		}else if(specialCharVal==1 && basicModeVal==1 && !basicAuthPassword.match(specialCharPattern)){
			alert($('#specialCharMsg').val());
			$('#password').focus();				
    	}else if(capitalLtrVal==1 && basicModeVal==1 && !basicAuthPassword.match(capitalLtrPattern)){
			alert($('#capitalLtrMsg').val());
			$('#password').focus();
		}else if(basicModeVal==1 && basicAuthPassword.length<minCharVal){
			alert($('#minCharMsg1').val()+" "+minCharVal+" "+ $('#minCharMsg2').val());
			$('#password').focus();		
		}else{
			if(basicAuthPassword==''){
			
			var md5pass='';
			}else{
			var md5pass=CryptoJS.MD5(basicAuthPassword);
			
		}
			
			jQuery.applyBasicModePassword(md5pass);
	}
	});

(function(jQuery){
	jQuery.applyBasicModePassword=function(pass){
		$.ajax({
            type: "POST",
            url: "applyPassBasicMode",
			async: false,
			data:'pass='+pass,
            error: function (req, status, err) {
                console.log(req.error);
            },
            success: function (response) {
				if(response.status)
				{
					alert($('#alertUpdatePass').val());
				}
            }
        });
		
	}			
		  
})(jQuery);	
		jQuery('.activateClass1').change(function(){		
		//var getChkBoxName=jQuery(this).attr('rev');	
		var getChkBoxName=    $(this).attr('name');
		var getChkBoxVal=(jQuery('#'+getChkBoxName).is(':checked'))?1:0;
		
		jQuery.serverConfiguration(getChkBoxName,getChkBoxVal);
	});
	
	(function(jQuery){
	jQuery.serverConfiguration = function(chkBoxName,chkBoxVal){
		var dataSetting=[];
		dataSetting[0]=chkBoxName;
		dataSetting[1]=chkBoxVal;
		$.ajax({
            type: "POST",
            url: "serverConfigurationAjax",
			async: false,
            data:{data:dataSetting},
            error: function (req, status, err) {
                console.log(req.error);
            },
            success: function (response) {
				if(response.status)
				{
					window.location='viaAdsettings';
				}
            }
        });
	}
})(jQuery);
	
       jQuery('#applyADbtn').click(function() {
	    var operationName = $(this).attr('rev');
	    var name = $(this).attr('name');
	    var adDomain = jQuery('#adDomain').val();
	    var adModerator = jQuery('#adModerator').val();
	    var adParticipant = jQuery('#adParticipant').val();
	    var grp_OuBased = $("input:radio[name='adRadioBtn']").is(":checked") ? 1 : 0;
	    var accRadioBtn = $("input:radio[name='accRadioBtn']").is(":checked") ? 1 : 0;
	    var accRadioBtnval = $("input[name='accRadioBtn']:checked").val();
	    if(grp_OuBased == 0 || accRadioBtn == 0) {
	        //	//alert(jQuery('#authPGTxtBoxAlert').val());
	        alert("Please provide all details");
	        return false;
	    } else if(adDomain == "") {
	        $("#adDomain").focus();
	        alert("Please provide all details");
	        return false;
	    } else if(adModerator == "") {
	        $("#adModerator").focus();
	        alert("Please provide all details");
	        return false;
	    } else if(adParticipant == "") {
	        $("#adParticipant").focus();
	        alert("Please provide all details");
	        return false;
	    } else {
	        $('#file_strADSettings').val(1);
	        var concatAllThree =
	            adDomain + ',' + adModerator + ',' + adParticipant + ',' + accRadioBtnval + ',' + grp_OuBased;
	        jQuery.serverConfigurationApply(operationName, concatAllThree);
	    }

        });

    	
	(function(jQuery){
	jQuery.serverConfigurationApply = function(chkBoxName,chkBoxVal){
		dataSetting=[];
		dataSetting[0]=chkBoxName;
		dataSetting[1]=chkBoxVal;
			$.ajax({
            type: "POST",
            url: "serverConfigurationAdSetting",
			async: false,
            data:{data:dataSetting},
            error: function (req, status, err) {
                console.log(req.error);
            },
            success: function (response) {
				if(response.status=='validationerror')
				{
					alert('please provide all details');
					return false;
				}
				if(response.status)
				{
					alert('Setting applied successfully!');
					window.location='viaAdsettings';
				}
            }
        });
	}
	})(jQuery);
	
	
		(function(jQuery){
	    jQuery.groupOuBassedSetting= function(chkBoxName,chkBoxVal){
		dataSetting=[];
		dataSetting[0]=chkBoxName;
		dataSetting[1]=chkBoxVal;
			$.ajax({
            type: "POST",
            url: "groupOuBassedSetting",
			async: false,
            data:{data:dataSetting},
            error: function (req, status, err) {
                console.log(req.error);
            },
            success: function (response) {
				if(response.status)
				{
				}
            }
        });
	}
	})(jQuery);
	
	
	
	$("input[name='adRadioBtn']").click(function(){								
				//var selection=jQuery(this).attr('name');
				var selection;
				var val=jQuery(this).val();	
				if(val==1)
				{
					selection='groupBased';
				}
				else{
					selection='ouBased';
				}
				if((selection=='groupBased') || (selection=='ouBased')){
					$('#file_strOUGroup').val(1);
				}
				jQuery.groupOuBassedSetting(selection,val);

		});

	});