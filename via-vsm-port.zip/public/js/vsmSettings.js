$(document).ready(function(){
		$("#dssHQ").click(function(){
		  if($("#dssHQ").is(':checked')){
			  $("#enableDSS").removeClass("hide");
		  }
		});
		$("#dssL").click(function(){
		 if($("#dssL").is(':checked')){
			  $("#enableDSS").removeClass("hide");
		  }
		});
		// Code for HQ master Validation
		$('.chkAllHQmaster').click(function(){
                var getClickOptID=$(this).attr('id');
                if(getClickOptID=='selAllHQ'){
                        //unchecked other checkbox
                        $('#selAllLocal').prop('checked',false);
                        if(this.checked) { // check select status
							$('.chkHQ').each(function() { //loop through each checkbox
								this.checked = true;  //select all checkboxes with class "checkbox1"              
							});
                        }else{
							$('.chkHQ').each(function() { //loop through each checkbox
								this.checked = false; //deselect all checkboxes with class "checkbox1"                      
							});        
                        }

                }
                if(getClickOptID=='selAllLocal'){
					$('#selAllHQ').prop('checked',false);
					if(this.checked) { // check select status
						$('.chkLocal').each(function() { //loop through each checkbox
							this.checked = true;  //select all checkboxes with class "checkbox1"              
						});
					}else{
						$('.chkLocal').each(function() { //loop through each checkbox
							this.checked = false; //deselect all checkboxes with class "checkbox1"                      
						});        
					}
                }							
		});
        // Code for apply HQ Master Settings	
        $('#settingHQMasterApply').click(function(){ 
			var WhiteSpacePattern=/^[^\s]+$/;
			var ipAddressPattern=/^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/;
			var NamePattern=/^[a-zA-Z0-9._(), {}\-\/\r\n]+$/;
			var definedLinServerIP="";
			var definedBoxID="";
			definedLinServerIP=$('#definedLinServerIP').val();
			definedBoxID=$('#definedBoxID').val();
			var ostype=$('#ostype').val();
			var modeltype=$('#modeltype').val();

			var selectedItems = new Array();									   
			$('input:radio:checked').each(function() {
				selectedItems.push($(this).val());
			});
			var getWallpBtnIsChked = ($("input[name='wallpaperSetting']").is(':checked'))?$("input[name='wallpaperSetting']:checked").val():0;
			var getConfigBtnIsChked = ($("input[name='configSetting']").is(':checked'))?$("input[name='configSetting']:checked").val():0;
			var getDSSBtnIsChked = ($("input[name='dssSetting']").is(':checked'))?$("input[name='dssSetting']:checked").val():0;
			var getCalendarBtnIsChked = ($("input[name='calendarSettings']").is(':checked'))?$("input[name='calendarSettings']:checked").val():0;
			if(ostype=='LIN' && modeltype=='via'){
				if($('#hardwaretype').val()=='fc20'){
					var getDSSBtnIsChked=2;
				}
				var getPollBtnIsChked=2;
			}
			
			if($('#validateHQandIDFlag').val()==0){
				alert($("#alertValidateHQipGatewayID").val());	
				return false;
			}
			if(getWallpBtnIsChked==0){
				alert($("#alertSelectWallpaper").val());	
				return false;
			}else if(getConfigBtnIsChked==0){
				alert($("#alertSelectConfiguration").val());	
				return false;				
			}
			else if(getDSSBtnIsChked==0){
				alert($("#alertSelectDigitalSignage").val());	
				return false;
           }else if(getCalendarBtnIsChked==0){
				alert($("#alertSelectCalendar").val());	
				return false;        
			}else{
				var conf=confirm($('#confirmProceed').val());
				if(conf==true){
					$.applyHQMasterSettings(selectedItems);
				}else{
					$(window.location).attr('href','vsmSettings');
					return false;	
				}	
			}										   
		});
		// Validate HQ_IP and ID of HQ Master
		$('#validateBtn').click(function(){
				var WhiteSpacePattern=/^[^\s]+$/;
				var ipAddressPattern=/^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/;
				var NamePattern=/^[0-9]+$/;
				var definedLinServerIP=htmlEncode($('#definedLinServerIP').val());
				if($('#modeltype').val()=='kds' && $('#definedLinServerIP').val()!=''){					
						var definedLinServerIP=$('#definedLinServerIP').val()+$('#serverDomain').html();					
				}		
				
				var definedBoxID=$('#definedBoxID').val();
				if(definedLinServerIP==""){
					$('#hqIPspan').html($("#alertValidateHQipGatewayID").val());
					$('#spanBoxID').html("");
					$('#definedLinServerIP').focus();
					$('#definedLinServerIP').addClass('errorClass');
					return false;									
				}else if(!definedLinServerIP.match(WhiteSpacePattern)){
					$('#hqIPspan').html($('#spacemsg').val());
					$('#spanBoxID').html("");
					$('#definedLinServerIP').focus();
					$('#definedLinServerIP').addClass('errorClass');
					return false;					
				}else if(definedBoxID==""){
					$('#hqIPspan').html("");
					$('#spanBoxID').html($("#alertValidateHQipGatewayID").val());
					$('#definedBoxID').focus();
					$('#definedBoxID').addClass('errorClass');
					return false;									
				}else if(!definedBoxID.match(WhiteSpacePattern)){
					$('#spanBoxID').html($("#spacemsg").val());
					$('#definedBoxID').focus();
					$('#definedBoxID').addClass('errorClass');
					return false;					
				}else if(!definedBoxID.match(NamePattern)){
					$('#hqIPspan').html("");
					$('#spanBoxID').html($("#numericMsg").val());
					$('#definedBoxID').focus();
					$('#definedBoxID').addClass('errorClass');
					return false;								
				}else if(definedBoxID.substring(0,1)==0){
					$('#hqIPspan').html("");
					$('#spanBoxID').html('Zero is not allowed in starting');
					$('#definedBoxID').focus();
					$('#definedBoxID').addClass('errorClass');
					return false;		
				}else{								  
					//alert('ok');				  
					$('#hqIPspan').html("");
					$('#spanBoxID').html("");
					$('#definedLinServerIP').removeClass('errorClass');
					$('#definedBoxID').removeClass('errorClass');
					$.validateHQandGwayID(definedLinServerIP,definedBoxID);	
				}
							
	});
	
	
	$('#resetHQIP').click(function(){
		var definedLinServerIP=$('#definedLinServerIP').val();
		var definedBoxID=$('#definedBoxID').val();
		//alert(definedLinServerIP);
		var conf=confirm($('#confirmProceed').val());
		if(conf==true){
			$.resetHQIPandGwayID(definedLinServerIP,definedBoxID);
		}else{
			return false;	
		}
								   
	});
   
  	$('#saveWithoutValidate').click(function(){
			var WhiteSpacePattern=/^[^\s]+$/;
			var ipAddressPattern=/^(?!0)(?!.*\.$)((1?\d?\d|25[0-5]|2[0-4]\d)(\.|$)){4}$/;
			//var NamePattern=/^[a-zA-Z0-9._(), {}\-\/\r\n]+$/;
			var NamePattern=/^[0-9]+$/;
			var definedLinServerIP=htmlEncode($('#definedLinServerIP').val());
			if($('#modeltype').val()=='kds' && $('#definedLinServerIP').val()!=''){	
				var definedLinServerIP=$('#definedLinServerIP').val()+$('#serverDomain').html();
			}			
		
			
			var definedBoxID=$('#definedBoxID').val();
			if(definedLinServerIP==""){
				$('#hqIPspan').html($("#alertValidateHQipGatewayID").val());
				$('#spanBoxID').html("");
				$('#definedLinServerIP').focus();
				$('#definedLinServerIP').addClass('errorClass');
				return false;									
			}else if(!definedLinServerIP.match(WhiteSpacePattern)){
				$('#hqIPspan').html($('#spacemsg').val());
				$('#spanBoxID').html("");
				$('#definedLinServerIP').focus();
				$('#definedLinServerIP').addClass('errorClass');
				return false;					
			}else if(definedBoxID==""){
				$('#hqIPspan').html("");
				$('#spanBoxID').html($("#alertValidateHQipGatewayID").val());
				$('#definedBoxID').focus();
				$('#definedBoxID').addClass('errorClass');
				$('#spanBoxID').html();
				return false;									
			}else if(!definedBoxID.match(WhiteSpacePattern)){
				$('#spanBoxID').html($("#spacemsg").val());
				$('#definedBoxID').focus();
				$('#definedBoxID').addClass('errorClass');
				return false;					
			}else if(!definedBoxID.match(NamePattern)){
				$('#hqIPspan').html("");
				$('#spanBoxID').html($("#numericMsg").val());
				$('#definedBoxID').focus();
				$('#definedBoxID').addClass('errorClass');
				return false;								
			}else if(definedBoxID.substring(0,1)==0){
				$('#spanBoxID').html('Zero is not allowed in starting');
				$('#definedBoxID').focus();
				$('#definedBoxID').addClass('errorClass');
				return false;	
			}else{								  
				//alert('ok');				  
				$('#hqIPspan').html("");
				$('#spanBoxID').html("");
				$('#definedLinServerIP').removeClass('errorClass');
				$('#definedBoxID').removeClass('errorClass');
				$.updateDeviceInventoryWithoutValidate(definedLinServerIP,definedBoxID);						
			}					
	});

		$('#checkPortStatus').click(function(){
			$('#portStatusModel').modal('show');
			var definedLinServerIP=$('#definedLinServerIP').val();
			var public_url=$('#public_url').val();
			
			jQuery.ajax({
				type:'POST',
				url:'checkport',
				data:'definedLinServerIP='+definedLinServerIP,
				dataType:'html',
				beforeSend : function(){					
					$('#processbar').html("<img src='"+public_url+"/img/bar-circle.gif'><br> Processing...");				},				
				success:function(responseData, status, XMLHttpRequest){	
					$('#responseData').html(responseData);
					 $('#processbar').hide();
				}					
			});
		})				   	

	

});

// HQ Master Page. Validate GatewayID and HQ IP
(function(jQuery){
	jQuery.validateHQandGwayID = function(HQserverIP,gwayBoxID){		
		jQuery.ajax({
				type:'POST',
				url:'validateGwayIPandIDCurl',
				data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID,
				dataType:'html',
				beforeSend : function(){
					$('#showbackgroundMsg').show();
					$('#showbackgroundMsg').html('<i class="fa fa-spinner" style="color:#69FFC3"></i><br><span class="text-dark">Request is processing...</span>');
				},

				success:function(responseData, status, XMLHttpRequest){
					var responseData = $.trim(responseData);
					$('#showbackgroundMsg').hide();
					if(responseData=='urlError'){
						alert($('#msgHqServerIpIncorrect').val());
						$('#showbackgroundMsg').hide();
						return false;
					}

					if(responseData=='NoMacAddr'){
						alert($("#alertNoMacAddressAssoc").val());
						$('#showbackgroundMsg').hide();
						return false;
					}
					//return false;
					if(responseData=='assignedToSelf'){						
						$.updateDeviceInventory(HQserverIP,gwayBoxID);
						return false;

					}else if(responseData=='assignedToOther'){
						var act=confirm(jQuery('#alertMsgHQ2').val());
						if(act==true){							
							var takeAction='updateExistMac';
							$.overWriteBoxID(HQserverIP,gwayBoxID,takeAction);
						}else{	
							$('#showbackgroundMsg').hide();
							return false;	
						}
					}else if(responseData=='success'){
						var ch=confirm($('#alertMsgHQ3').val());
						if(ch==true){
							var takeAction='updateBlankMac';
							$.overWriteBoxID(HQserverIP,gwayBoxID,takeAction);
						}else{
							return false;
						}
					}else if(responseData=='failure'){
						alert($('#alertMsgHQ4').val());	
						$('#showbackgroundMsg').hide();
						return false;
					}
				}					
		});
	
	}
})(jQuery);
// Overwrite Gateway Box ID
(function(jQuery){
	jQuery.overWriteBoxID = function(HQserverIP,gwayBoxID,takeAction){
		jQuery.ajax({
			type:'POST',
			url:'overwriteBoxIDCurl',
			data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID+'&takeAction='+takeAction,
			dataType:'html',
			success:function(responseData, status, XMLHttpRequest){
				var responseData = $.trim(responseData);
				//alert(responseData);
				if(responseData=='success'){
					$.saveHQinfo(HQserverIP,gwayBoxID);
					//alert(jQuery('#alertMsgHQ5').val());
				}
			}					
		});
	}
})(jQuery);
//Save HQ Info in deviceInventory Table
(function(jQuery){
	jQuery.saveHQinfo = function(HQserverIP,gwayBoxID){
		jQuery.ajax({
			type:'POST',
			url:'saveHQinfo',
			data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID,
			dataType:'html',
			success:function(responseData, status, XMLHttpRequest){
				var responseData = $.trim(responseData);
				//alert(responseData);
				if(responseData=='success'){
					$('#validateHQandIDFlag').val(1);
					jQuery('#msg').html(jQuery('#alertMsgHQ6').val());	
					jQuery('#msg').fadeIn().delay(2000).fadeOut('slow');
					alert(jQuery('#alertMsgHQ6').val());
					jQuery(window.location).attr('href','vsmSettings');
				}
			}					
		});
	}
})(jQuery);


// Code for apply HQ Master Settings
(function(jQuery){
	jQuery.applyHQMasterSettings=function(selectedItems){
		jQuery.ajax({
			type:'POST',
			url:'applyHQMasterSetting',
			data:'selectedItems='+selectedItems,
			dataType:'html',
			success:function(responseData, status, XMLHttpRequest){	
				//alert(responseData);
				var responseData= $.trim(responseData);
				if(responseData=="success"){
					alert($('#applySettingsAlert').val()+' Please reboot your system.');						
					setTimeout(function(){window.location = 'vsmSettings';}, 1000);
					return false;
				}
			}					
		});	
	}			
		  
})(jQuery);

// Code for Reset from HQ IP and ID
(function(jQuery){
	jQuery.resetHQIPandGwayID = function(HQserverIP,gwayBoxID){
		/*jQuery.ajax({
				type:'POST',
				url:'resetBoxIDCurl',
				data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID,
				dataType:'html',
				success:function(responseData, status, XMLHttpRequest){
					var responseData = $.trim(responseData);
					if(responseData=='success'){
						jQuery.resetBoxIDFromLocal(HQserverIP,gwayBoxID);
						//alert(jQuery('#alertMsgHQ5').val());
					}
				}					
			});*/
			jQuery.resetBoxIDFromLocal(HQserverIP,gwayBoxID);
	
	}
})(jQuery);
// Reset From Local
(function(jQuery){
	jQuery.resetBoxIDFromLocal=function(HQserverIP,gwayBoxID){
		jQuery.ajax({
			type:'POST',
			url:'resetBoxIDFromLocal',
			data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID,
			dataType:'html',
			success:function(responseData, status, XMLHttpRequest){	
				//alert(responseData);
				var responseData= $.trim(responseData);
				if(responseData=="success"){
					alert($('#msgServerIpReset').val());
					setTimeout(function(){window.location = 'vsmSettings';}, 2000);
					return false;
				}	
				
			}					
		});	
	}	  
})(jQuery);


// Update deviceinventory table
(function(jQuery){
	jQuery.updateDeviceInventory=function(HQserverIP,gwayBoxID){
		jQuery.ajax({
			type:'POST',
			url:'saveHQinfo',
			data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID,
			dataType:'html',
			success:function(responseData, status, XMLHttpRequest){
				var responseData = $.trim(responseData);
				if(responseData=="success"){						
					alert(jQuery('#alertMsgHQ1').val());
					$('#showbackgroundMsg').hide();
					jQuery(window.location).attr('href','vsmSettings');
				}	
			}					
		});	
	}		  
})(jQuery);



(function(jQuery){
	jQuery.updateDeviceInventoryWithoutValidate=function(HQserverIP,gwayBoxID){
		jQuery.ajax({
			type:'POST',
			url:'saveHQinfo',
			data:'HQserverIP='+HQserverIP+'&gwayBoxID='+gwayBoxID,
			dataType:'html',
			success:function(responseData, status, XMLHttpRequest){
				var responseData = $.trim(responseData);
				if(responseData=="success"){
					alert(jQuery('#updatedRecordAlert').val());
					setTimeout(function(){window.location = 'vsmSettings';}, 2000);
				}	
				
			}					
		});
	}			
		  
})(jQuery);