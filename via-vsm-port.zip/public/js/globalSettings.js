$(document).ready(function(){
	// js addded for pop up showing when managaed from VSM 
        var globalSettingsVal=$("#globalSettingsVal").val();
        if(globalSettingsVal==1){
		$('.makeDisabled').attr('disabled',true);
                $(".editClass").removeClass("editNtp"); 
                $(".deleteClass").removeClass("deleteNtp"); 
	}else{
		jQuery('.makeDisabled').attr('disabled',false);
                $(".editClass").addClass("editNtp"); 
                $(".deleteClass").addClass("deleteNtp"); 
	}
        if(globalSettingsVal==1){
                var overlay = $('<div id="overlay"></div>');
                overlay.show();
                overlay.appendTo(document.body);
                $('.popup').show();
                $('.close').click(function(){
                $('.popup').hide();
                overlay.appendTo(document.body).remove();
                return false;
                });

                $('.x').click(function(){
                        $('.popup').hide();
                        overlay.appendTo(document.body).remove();
                        return false;
                });
        }
        
        //Session and broadcast
        $('#logoutTime').change(function(){
            $.sessionBroadcastSetting();
        })
       
        $('.broadcastcss').click(function(){	  
                var optBroadcastValue=($(this).attr('id')=='enableBroadcast')?1:0;				
                if(optBroadcastValue==1){			
                    $('#disableBroadcast').removeClass('active').addClass('inActive');				
                    $('#enableBroadcast').removeClass('inActive').addClass('active');
                    $('#broadcastVal').val(1);
                }else{			
                    $('#enableBroadcast').removeClass('active').addClass('inActive');
                    $('#disableBroadcast').removeClass('inActive').addClass('active');
                    $('#broadcastVal').val(0);
                }
                $.sessionBroadcastSetting();
        });
        //End session and broadcast
        
        //Certificate tab
        $('input[type=file]').change(function () {
            if($('#certificateCertFile').val()!=''){			
                $('#showFile1').html($('#certificateCertFile').val());
            } 
            if($('#certificateKeyFile').val()!=''){
                $('#showFile2').html($('#certificateKeyFile').val());
            }	 
        });

        $('#uploadCertCertificateBtn').click(function () {
                var certificateFile=$('#certificateCertFile').val();
                var count=0;
                var act=false;
                if(certificateFile==''){
                    alert($("#alertSelectCertificate").val());
                    return false;
                }
                if(certificateFile!=''){
                    if(certificateFile.toLowerCase().indexOf(".crt")==-1){
                         alert($("#allowedCertFile").val());
                        return false;		
                    }
                }
                $.ajax({
                        type:'POST',
                        url:'checkCertifiacteFile',
                        data:'certificateFile='+certificateFile,					
                        dataType:'html',					
                        success:function(responseData, status, XMLHttpRequest){							
                            if(responseData=='exists'){
                                act=confirm($("#certExist").val());
                                if(act==1){
                                    setTimeout(function(){alert($("#certSuccess").val());}, 1000);
                                    $("#certificateForm").submit();
                                    
                                }else{
                                    return false;
                                }
                            }else{
                                setTimeout(function(){alert($("#certSuccess").val());}, 1000);
                                $("#certificateForm").submit();							
                            }		
                        }					
                });	
                if(act!=1)
                    return false;
        });
        
        $('#uploadKeyCertificateBtn').click(function () { 
                var act=false;
                var certificateKeyFile=$('#certificateKeyFile').val();
                if(certificateKeyFile==''){
                    alert($("#alertSelectCertificateKey").val());
                    return false;			
                }
                if(certificateKeyFile!=''){
                    if(certificateKeyFile.toLowerCase().indexOf(".key")==-1){
                        alert($("#allowedKeyFile").val());
                        return false;		
                    }
                }
                $.ajax({
                        type:'POST',
                        url:'checkCertifiacteKeyFile',
                        data:'certificateKeyFile='+certificateKeyFile,					
                        dataType:'html',					
                        success:function(responseData, status, XMLHttpRequest){							
                            if(responseData=='exists'){
                                act=confirm($("#keyExist").val());						
                                if(act==1){
                                    setTimeout(function(){alert($("#keySuccess").val());}, 1000);
                                    $("#certificateKeyForm").submit();
                                }else{
                                    return false;
                                }
                            }else{
                                setTimeout(function(){alert($("#keySuccess").val());}, 1000);
                                $("#certificateKeyForm").submit();							
                            }		
                        }					
                });
                if(act!=1)
                    return false;
        });
        
        $('#resetCertificateBtn').click(function(){
                    $.ajax({
                            type:'POST',
                            url:'resetCertifiacteFile',
                            data:'',					
                            dataType:'html',					
                            success:function(responseData, status, XMLHttpRequest){
                                    if(responseData==1){							
                                        alert($("#alertCertificateResetSuccess").val());
                                    }
                                    if(responseData==0){							
                                        alert($("#alertCertificateResetFailed").val());
                                    }							


                            }					
                    });			

    });

        //NTP tab
        $('.editNtp').click(function(){
                $('#addNTPModal').modal('show');
                $('#addNTPModalLabel').text('Edit NTP Server');
                $('#netServerBtn').text('Update');
                $('#ntpmode').val('editmode');
                $('#netServer').val('');
                $('#netServer').attr('disabled',false);
                var ntpId=$(this).attr("rev");
                $('#ntpid').val(ntpId);
                
                $.ajax({
                        type:'POST',
                        url:'getNtp',			
                        data:'ntpId='+ntpId,
                        dataType:'html',				
                        success:function(responseData, status, XMLHttpRequest){			
                                var splitResponseData=responseData.split('#');	
                                var ntpId=splitResponseData[0];
                                var ntpName=splitResponseData[1];
                                $('#netServer').val(ntpName);	
                                $('#netServer').next().addClass('activeCss');	
                                $('#ntpid').val(ntpId);
                        }					
                });
        });
        
        $(document).on('submit','#ntpSettingsForm',function(e) {
                e.preventDefault();
                var ntpServer = $('#netServer').val();		
                var ntpmode=$('#ntpmode').val();
                var ntpServer=$('#netServer').val();
                var WhiteSpacePattern=/^[^\s]+$/;
                if(ntpmode=='addmode'){
                        if(ntpServer==""){
                            alert($("#ntpBlank_msg").val());
                            $('#netServer').focus();
                            return false;				
                        }else if(!ntpServer.match(WhiteSpacePattern) ){
                            alert($('#spacemsg').val());
                            $('#netServer').focus();
                            return false;			
                        }else{
                            $.ajax({
                                type:'POST',
                                url:'saveNTPServerSetting',
                                data:'ntpServer='+encodeURIComponent(ntpServer),
                                dataType:'html',
                                success:function(responseData, status, XMLHttpRequest){
                                    if(responseData=='serverExist'){
                                        alert($("#serverExist").val());
                                        $('#netServer').focus();
                                        return false;
                                    }else{
                                        $('#netServer').val('');
                                        alert($("#createRecordAlert").val());						
                                        setTimeout(function(){window.location = 'globalSettings';}, 1000);     
                                    }
                                }					
                        });

                        return false;
                        }		

                }//end add mode
                //edit mode
                if(ntpmode=='editmode'){
                    var ntpId=$('#ntpid').val();
                    if(ntpServer==''){
                        alert($("#ntpBlank_msg").val());
                        $('#netServer').focus();
                        return false;				
                    }else if(!ntpServer.match(WhiteSpacePattern) ){
                            alert(jQuery('#spacemsg').val());
                            $('#netServer').focus();
                            return false;			
                    }else{
                        $.ajax({
                                type:'POST',
                                url:'updateNTPServerSetting',
                                data:'ntpServer='+encodeURIComponent(ntpServer)+'&ntpId='+ntpId,
                                dataType:'html',
                                success:function(responseData, status, XMLHttpRequest){	
                                //alert(responseData);
                                        if(responseData=='serverExist'){
                                            alert($("#serverExist").val());
                                            $('#netServer').focus();
                                            return false;
                                        }else{
                                            alert($("#updatedRecordAlert").val());
                                            setTimeout(function(){window.location = 'globalSettings';}, 1000);							
                                            return false;
                                        }
                                }					
                        });  
                        return false;
                }
            }//end edit mode
            
	});
        
        $('.addNtpCss').click(function(){
                $('#netServer').val('');
                $('#netServer').attr('disabled',false);
                $('#addUserModal').modal('show');
                $('#addNTPModalLabel').text('Add NTP Server');
                $('#netServerBtn').text('Save');
                $('#ntpmode').val('addmode');
                $('#netServer').next().removeClass('activeCss');
        });
        
        $(".deleteNtp").click(function(){
            var act=confirm($("#confmsg").val());
            if(act==0){
                    return false;
            }
            var optValue=$(this).attr('rev');
            var splitoptValue=optValue.split('#');
            var getOptValue=splitoptValue[0];
            var ntpId=splitoptValue[1];
            jQuery.ajax({
                        type:'POST',
                        url:'deleteNTPServer',
                        data:'ntpId='+ntpId+'&getOptValue='+getOptValue,
                        dataType:'html',
                        success:function(responseData, status, XMLHttpRequest){	
                            var responseData = $.trim(responseData);
                            if(responseData=='success'){
                            alert($("#deleteRecordAlert").val());
                            setTimeout(function(){window.location = 'globalSettings';}, 1000);
                            }
                            if(responseData==0){
                                setTimeout(function(){window.location = 'globalSettings';}, 1000);	
                            }

                        }					
                });
        });
        //End NTP tab
        
        //Security tab
        $('.captchacss').click(function(){
                var optValue=($(this).attr('id')=='enableCaptcha')?1:0;
                if(optValue==1){			
                    $('#disableCaptcha').removeClass('active').addClass('inActive');				
                    $('#enableCaptcha').removeClass('inActive').addClass('active');
                    $('#captchaVal').val(1);
                }else{			
                    $('#enableCaptcha').removeClass('active').addClass('inActive');
                    $('#disableCaptcha').removeClass('inActive').addClass('active');
                    $('#captchaVal').val(0);
                }				
        });
        
        $('.aplhanumriccss').click(function(){	  
                var alphanumricValue=($(this).attr('id')=='enableAlphanumricPass')?1:0;				
                if(alphanumricValue==1){			
                    $('#disableAlphanumricPass').removeClass('active').addClass('inActive');				
                    $('#enableAlphanumricPass').removeClass('inActive').addClass('active');
                    $('#alphanumericVal').val(1);
                }else{			
                    $('#enableAlphanumricPass').removeClass('active').addClass('inActive');
                    $('#disableAlphanumricPass').removeClass('inActive').addClass('active');
                    $('#alphanumericVal').val(0);
                }				
        });
	
	$('.specialCharcss').click(function(){	  
                var specialCharValue=($(this).attr('id')=='enableSpecialChar')?1:0;				
                if(specialCharValue==1){			
                    $('#disableSpecialChar').removeClass('active').addClass('inActive');				
                    $('#enableSpecialChar').removeClass('inActive').addClass('active');
                    $('#specialCharVal').val(1);
                }else{			
                    $('#enableSpecialChar').removeClass('active').addClass('inActive');
                    $('#disableSpecialChar').removeClass('inActive').addClass('active');
                    $('#specialCharVal').val(0);
                }				
        });
	
	$('.capitalLtrcss').click(function(){	  
                var capitalLtrValue=($(this).attr('id')=='enableCapitalLtr')?1:0;				
                if(capitalLtrValue==1){			
                    $('#disableCapitalLtr').removeClass('active').addClass('inActive');				
                    $('#enableCapitalLtr').removeClass('inActive').addClass('active');
                    $('#capitalLtrVal').val(1);
                }else{			
                    $('#enableCapitalLtr').removeClass('active').addClass('inActive');
                    $('#disableCapitalLtr').removeClass('inActive').addClass('active');
                    $('#capitalLtrVal').val(0);
                }				
        });
	
	$('.basicModecss').click(function(){	  
                var basicModeValue=($(this).attr('id')=='enableBasicMode')?1:0;				
                if(basicModeValue==1){			
                    $('#disableBasicMode').removeClass('active').addClass('inActive');				
                    $('#enableBasicMode').removeClass('inActive').addClass('active');
                    $('#basicModeVal').val(1);
                }else{			
                    $('#enableBasicMode').removeClass('active').addClass('inActive');
                    $('#disableBasicMode').removeClass('inActive').addClass('active');
                    $('#basicModeVal').val(0);
                }				
        });
        
        $('#applySecuritySettingsBtn').click(function(){
                var numberPattern=/^[0-9]+$/;
                var captchaValue=$('#captchaVal').val();
                var alphanumericValue=$('#alphanumericVal').val();
                var specialCharValue=$('#specialCharVal').val();
                var capitalLtrValue=$('#capitalLtrVal').val();
                //var checkOldPassValue=$('#checkOldPassVal').val();
                var minimumCharValue=$('#minimumChar').val();
                //var passValidityValue=$('#passValidity').val();
                var basicModeValue=$('#basicModeVal').val();

                if(minimumCharValue<4){
                alert($("#minCharmsg").val());
                return false;
                }else if(!minimumCharValue.match(numberPattern)){
                        alert($("#alertEnterNumericValue").val());
                        return false;			
                }else if(minimumCharValue>150){
                        alert($("#maxCharmsg").val());
                        return false;
                }
                $.ajax({
                    type:'POST',
                    url:'securitySettings',
                    data:'captchaVal='+captchaValue+'&alphanumericVal='+alphanumericValue+'&specialCharVal='+specialCharValue+'&capitalLtrVal='+capitalLtrValue+'&minimumCharVal='+minimumCharValue+'&basicModeVal='+basicModeValue,
                    dataType:'html',
                    success:function(responseData, status, XMLHttpRequest){
                        alert($("#applySettingsAlert").val());
                        setTimeout(function(){window.location = 'globalSettings';}, 1000);
                        }
                }); 
	 })
        
});

(function(jQuery){
	jQuery.sessionBroadcastSetting=function(){
            var timeValue=$('#logoutTime').val();      				
            var broadcastValue=$('#broadcastVal').val(); 
            jQuery.ajax({
                    type:'POST',
                    url:'sessionBroadcastSetting',
                    data:'timeVal='+timeValue+'&broadcastValue='+broadcastValue,
                    dataType:'html',
                    success:function(responseData, status, XMLHttpRequest){
                        alert($('#applySettingsAlert').val());
                        setTimeout(function(){window.location = 'globalSettings';}, 1000);
                    }					
            });
		
	}		  
})(jQuery);
