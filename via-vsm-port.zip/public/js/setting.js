$(document).ready(function(){
	// js addded for pop up showing when managaed from VSM 
	//pass=$("#currentPageName").val();

         if(jQuery("#currentPageName").val()=='settings'){
            $('a[data-toggle="tab"]').on('click', function(e) {
                    localStorage.setItem('activeSetting', $(e.target).attr('href'));
            });
            // $('#sessionBroadcastSetting').removeClass('hide');
            // $('#sessionBroadcastTab').addClass('active');
             $('#deviceSetting').removeClass('hide');
             $('#deviceTab').addClass('active');
            $('#globalSettingsTab').on('click', function(e) {
                var idAttr = e.target.getAttribute('id');
                if(idAttr!=null){
                    $('#sessionBroadcastSetting').addClass('hide');
                    $('#securitySetting').addClass('hide');
					
                    let unselectedTag = ($(this).children()).children();
                    for (let i = 0; i < unselectedTag.length; ++i) {
                            unselectedTag[i].classList.remove("active");
                    }
                    e.target.classList.add("active");
                    let tabId = e.target.id;
                    if(tabId == 'sessionBroadcastTab'){
                        $('#sessionBroadcastSetting').removeClass('hide');
						$('#securitySetting').addClass('hide');
						$('#viaDiscoverySetting').addClass('hide');
                        $('#deviceSetting').addClass('hide');
                        
                    }
                    if(tabId == 'securityTab'){
                        $('#securitySetting').removeClass('hide');
						$('#viaDiscoverySetting').addClass('hide');
						$('#sessionBroadcastSetting').addClass('hide');
                        $('#deviceSetting').addClass('hide');
                    }
					if(tabId == 'viaDiscoveryTab'){
                        $('#viaDiscoverySetting').removeClass('hide');
						$('#sessionBroadcastSetting').addClass('hide');
						$('#securitySetting').addClass('hide');
                        $('#deviceSetting').addClass('hide');
                    }
                    if(tabId=='deviceTab'){
                        $('#deviceSetting').removeClass('hide');
                        $('#viaDiscoverySetting').addClass('hide');
						$('#sessionBroadcastSetting').addClass('hide');
						$('#securitySetting').addClass('hide');
                    }
                }
            });
            var activeTab = localStorage.getItem('activeSetting');
            if(activeTab){
                let active = activeTab.replace(activeTab.substr(activeTab.length-7),'Tab');
                
                // $('#sessionBroadcastSetting').addClass('hide');
                // $('#sessionBroadcastTab').removeClass('active');
                $('#deviceSetting').addClass('hide');
                $('#deviceTab').removeClass('active');
                $(active).addClass('active');
                $(activeTab).removeClass('hide');
                $(activeTab).addClass('active');
            }
	}
        //Session 
        $('#logoutTime').change(function(){
			
            $.sessionBroadcastSetting();
			
        });

        //frequency alert
        $('#frequencyalert').change(function(){
			
            $.frequencyAlertSetting();
			
        });

       
        $('.gwayidcss').click(function(){	  
                var enablegwayIdValue = $(this).prop('checked')?1:0;	
                if(enablegwayIdValue==1){
                    $('#gwayIdVal').val(1);
                }else{
                    $('#gwayIdVal').val(0);
                }
                $.sessionBroadcastSetting();
        });
        //End session and broadcast
        

 
  
        //Security tab
        $('.captchacss').click(function(){
                var optValue = $(this).prop('checked')?1:0;
                if(optValue==1){
                    $('#captchaVal').val(1);
                }else{
                    $('#captchaVal').val(0);
                }				
        });
        
        $('.aplhanumriccss').click(function(){	  
                var alphanumricValue = $(this).prop('checked')?1:0;				
                if(alphanumricValue==1){
                    $('#alphanumericVal').val(1);
                }else{
                    $('#alphanumericVal').val(0);
                }				
        });
	
		$('.specialCharcss').click(function(){	  
                var specialCharValue = $(this).prop('checked')?1:0;				
                if(specialCharValue==1){
                    $('#specialCharVal').val(1);
                }else{
                    $('#specialCharVal').val(0);
                }				
        });
	
		$('.capitalLtrcss').click(function(){	  
                var capitalLtrValue = $(this).prop('checked')?1:0;				
                if(capitalLtrValue==1){
                    $('#capitalLtrVal').val(1);
                }else{
                    $('#capitalLtrVal').val(0);
                }				
        });
	
	$('.basicModecss').click(function(){	  
                var basicModeValue = $(this).prop('checked')?1:0;				
                if(basicModeValue==1){
                    $('#basicModeVal').val(1);
                }else{
                    $('#basicModeVal').val(0);
                }				
        });
        
		
        $('#applySecuritySettingsBtn').click(function(){
			
                var numberPattern=/^[0-9]+$/;
                var captchaValue=$('#captchaVal').val();
				
				
                var alphanumericValue=$('#alphanumericVal').val();
				
                var specialCharValue=$('#specialCharVal').val();
                var capitalLtrValue=$('#capitalLtrVal').val();
                //var checkOldPassValue=$('#checkOldPassVal').val();
                var minimumCharValue=$('#minimumChar').val();
                //var passValidityValue=$('#passValidity').val();
                //var basicModeValue=$('#basicModeVal').val();
				
                if(minimumCharValue<4){
                alert($("#minCharmsg").val());
                return false;
                }else if(!minimumCharValue.match(numberPattern)){
                        alert($("#alertEnterNumericValue").val());
                        return false;			
                }else if(minimumCharValue>150){
                        alert($("#maxCharmsg").val());
                        return false;
                }
			
				
                $.ajax({
                    type:'POST',
                    url:'securitySettings',
                    data:'captchaVal='+captchaValue+'&alphanumericVal='+alphanumericValue+'&specialCharVal='+specialCharValue+'&capitalLtrVal='+capitalLtrValue+'&minimumCharVal='+minimumCharValue,
                    dataType:'html',
                    success:function(responseData, status, XMLHttpRequest){
                        $('#msg').html($("#applySettingsAlert").val());
                        setTimeout(function(){window.location = 'settings';}, 1000);
                        }
                }); 
	 });
        
});

(function(jQuery){
	jQuery.sessionBroadcastSetting=function(){
            var timeValue=$('#logoutTime').val(); 
			var gwayId=	$('#gwayIdVal').val();
            jQuery.ajax({
                    type:'POST',
                    url:'sessionSetting',
                    data:'timeVal='+timeValue+'&gwayValue='+gwayId,
                    dataType:'html',
                    success:function(responseData, status, XMLHttpRequest){
                        $('#msg').html($('#applySettingsAlert').val());
                        setTimeout(function(){window.location = 'settings';}, 1000);
                    }					
            });
		
	}		  
})(jQuery);

(function(jQuery){
	jQuery.frequencyAlertSetting=function(){
            var alertValue=$('#frequencyalert').val(); 
                    jQuery.ajax({
                    type:'POST',
                    url:'frequencyAlertSetting',
                    data:'alertVal='+alertValue,
                    dataType:'html',
                    success:function(responseData, status, XMLHttpRequest){
                        if(responseData=="success"){
                        alert($('#applySettingsAlert').val());
                        setTimeout(function(){window.location = 'settings';}, 1000);
                    }	
                }				
            });
		
	}		  
})(jQuery);



